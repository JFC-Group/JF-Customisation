--[[
#### Copyright (c) 2010, TeamF1, Inc.
#### Oct 12, 2010
#### File: qos.lua
#### Description: QoS 
#### Revisions:
o1b 19apr11, bng added config import and export for qos entries
01a 12Oct10, sam written
]]--

--************* Requires *************
require "teamf1lualib/db"
require "teamf1lualib/util"
require "qosLib"

--************* Initial Code *************

--************* Global Variables *************
qos = {}
qos.debug = 0
qos.globals = {}

require "teamf1lualib/qosIf"
require "teamf1lualib/qosBwTest"
require "teamf1lualib/qosProfile"
require "teamf1lualib/qosClassQueue"
require "teamf1lualib/qosRule"
require "teamf1lualib/qosMap"
require "teamf1lualib/qosSw"

-------------------------------------------------------------------------------
-- @name qos.globals.get
--
-- @description This function get the gloabl configuration of the qos module
--
-- @param 
--
-- @return N/A
--

function qos.globals.get()
    local globals = {}
    local query = "_ROWID_=1"

    globals = db.getRowWhere("qosGlobalCfg", query, false)
    if (globals == nil) then
        return nil
    end        

    return globals
end

-------------------------------------------------------------------------------
-- @name qos.globals.set
--
-- @description This function sets the gloabl configuration of the qos module
--
-- @param 
--
-- @return N/A
--

function qos.globals.set(cfg)
    local globals = {}

    globals = qos.globals.get()
    if (globals == nil) then
        return "ERROR", "QOS_ERR_GLOBAL_CFG_GET"
    end        
    
    if (cfg["MeasureBwOnStart"] ~= nil) then
        globals["MeasureBwOnStart"] = cfg["MeasureBwOnStart"]
        if (tonumber(globals["MeasureBwOnStart"]) > 0) then
            local status, errCode, bwMtrConf = qos.bwTest.confGet()
            if (status ~= "OK") then
                return status, errCode
            end 
            
            bwMtrConf["MeasureBandwidth"] = "1"
            
            status, errCode = qos.bwTest.configure (bwMtrConf) 
            if (status ~= "OK") then
                return status, errCode
            end
        end                        
    end        

    if (cfg["Dot1pRemarkStatus"] ~= nil) then
        globals["Dot1pRemarkStatus"] = cfg["Dot1pRemarkStatus"]
    end

    if (cfg["MaxUpstreamBwPercentage"] ~= nil) then
        globals["MaxUpstreamBwPercentage"] = cfg["MaxUpstreamBwPercentage"]
    end

    globals = util.addPrefix(globals, "qosGlobalCfg.")
    local valid, errstr = db.update("qosGlobalCfg", globals, "1")
    if (not valid) then
        return "ERROR", errstr
    end        

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name qos.import
--
-- @description This function imports qos configuration
--
-- @param 
--
-- @return N/A
--

function qos.import (configTable, defaultConfigTable, removeCfg)

    if (configTable == nil) then
        configTable = defaultConfigTable
    end

    if (configTable == nil) then
        return
    end
            
    if (configTable.global ~= nil) then
        local globalTmp = config.update (configTable.global, 
                                         defaultConfigTable.global, 
                                         removeCfg.global)
    	for i,v in ipairs (globalTmp) do	
            v = util.addPrefix (v, "qosGlobalCfg.");
            db.insert  ("qosGlobalCfg", v)
        end
    end

    if (configTable.qosProfile ~= nil) then
        local qosProfileTbl = config.update (configTable.qosProfile, 
                                             defaultConfigTable.qosProfile, 
                                             removeCfg.qosProfile) 
    	for i,v in ipairs (qosProfileTbl) do	
            v["_ROWID_"] = nil
            v = util.addPrefix (v, "qosProfile.");
            db.insert  ("qosProfile", v)
        end
    end

    if (configTable.qosQueueManagement ~= nil) then
        local qosQueueMgmtTbl = config.update (configTable.qosQueueManagement, 
                                               defaultConfigTable.qosQueueManagement, 
                                               removeCfg.qosQueueManagement)
        for i,v in ipairs (qosQueueMgmtTbl) do	
            v["_ROWID_"] = nil
            v = util.addPrefix (v, "qosQueueManagement.");
            db.insert  ("qosQueueManagement", v)
        end
    end

    if (configTable.qosClassQueue ~= nil) then
        local qosClassQueueTbl = config.update (configTable.qosClassQueue, 
                                                defaultConfigTable.qosClassQueue, 
                                                removeCfg.qosClassQueue)
        for i,v in ipairs (qosClassQueueTbl) do	
            v["_ROWID_"] = nil
            v = util.addPrefix (v, "qosClassQueue.");
            db.insert  ("qosClassQueue", v)
        end

    end

    if (configTable.qosClassification ~= nil) then
        local qosClassificationTbl = config.update (configTable.qosClassification, 
                                                    defaultConfigTable.qosClassification, 
                                                    removeCfg.qosClassification)
        for i,v in ipairs (qosClassificationTbl) do	
            v["_ROWID_"] = nil
            v = util.addPrefix (v, "qosClassification.");
            db.insert  ("qosClassification", v)
        end
    end

    if (configTable.cosMarkMap ~= nil) then
        local cosMarkMapTbl = config.update (configTable.cosMarkMap, 
                                             defaultConfigTable.cosMarkMap, 
                                             removeCfg.cosMarkMap)
        for i,v in ipairs (cosMarkMapTbl) do	
            v["_ROWID_"] = nil
            v = util.addPrefix (v, "cosMarkMap.");
            db.insert  ("cosMarkMap", v)
        end
    end

    if (configTable.dscpMarkMap ~= nil) then
        local dscpMarkMapTbl = config.update (configTable.dscpMarkMap, 
                                              defaultConfigTable.dscpMarkMap, 
                                              removeCfg.dscpMarkMap)
        for i,v in ipairs (dscpMarkMapTbl) do	
            v["_ROWID_"] = nil
            v = util.addPrefix (v, "dscpMarkMap.");
            db.insert  ("dscpMarkMap", v)
        end
    end

    if (configTable.qosBwMtrConf ~= nil) then
        local qosBwMtrConfTmp = config.update (configTable.qosBwMtrConf, 
                                               defaultConfigTable.qosBwMtrConf, 
                                               removeCfg.qosBwMtrConf)
        for i,v in ipairs (qosBwMtrConfTmp) do	
            v["_ROWID_"] = nil
            v = util.addPrefix (v, "qosBwMtrConf.");
            db.insert  ("qosBwMtrConf", v)
        end
    end


end

-------------------------------------------------------------------------------
-- @name qos.export
--
-- @description This function exports qos configuration
--
-- @param 
--
-- @return N/A
--

function qos.export ()
    local qosConfig = {}
    qosConfig["global"] =  db.getTable ("qosGlobalCfg", false)
    qosConfig["qosProfile"] =  db.getTable ("qosProfile", false)
    qosConfig["qosQueueManagement"] = db.getTable ("qosQueueManagement",false)
    qosConfig["qosClassQueue"] = db.getTable ("qosClassQueue",false)
    qosConfig["qosClassification"] = db.getTable ("qosClassification",false)
    qosConfig["cosMarkMap"] = db.getTable ("cosMarkMap",false)
    qosConfig["dscpMarkMap"] = db.getTable ("dscpMarkMap",false)
    qosConfig["qosBwMtrConf"] = db.getTable ("qosBwMtrConf",false)

    return qosConfig
end

if (config.register) then
   config.register("qos", qos.import, qos.export)
end

--[[
*******************************************************************************
-- @name qos.dprintf
--
-- @description 
--
-- @param 
--
-- @return 
--
--]]

function qos.dprintf(str)
    if (str == nil) then
        return
    end

    if ((qos.debug == 1) or
        ((gui ~= nil) and  (gui.console_debug == 1))) then

        if (str)  then
            print ("QOS: " .. str)

            require "syslog"
            syslog.syslog("LOG_INFO", str)
        end

        return
    end        

    if ((gui ~= nil) and (gui.web_debug == 1)) then
        util.appendDebugOut ("QOS: "  .. str .. "<br>")
    end        

    return 
end
