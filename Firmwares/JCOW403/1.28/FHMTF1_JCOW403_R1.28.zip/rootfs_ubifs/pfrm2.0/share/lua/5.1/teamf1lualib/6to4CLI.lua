-- 6to4CLI.lua
-- Samer Sayeed
-- TeamF1
-- www.TeamF1.com
--
-- Modification History
-- 07jan09,ss written 
--
-- Description
-- CLI interface set and get routines

require "teamf1lualib/nimfView"

function sixToFourTunnelCfgInit (args)
    configRow = db.getRow("sixToFourTunnel", "_ROWID_", "1")
    if (configRow == nil) then
        configRow = db.getDefaults(true, "sixToFourTunnel")
    end
    return 1, configRow
end
    
function sixToFourTunnelCfgSave (configRow)
    DBTable = "sixToFourTunnel"
    errorFlag, statusCode = nimfView.sixtoFourTunnelConfig (configRow, "1", "edit");
    -- save db if no error
    if (errorFlag == "OK") then db.save() end
    statusMessage = db.getAttribute("stringsMap", "stringId", statusCode, LANGUAGE)
    return errorFlag, statusMessage
end

function sixToFourTunnelCfgInputVal(configRow)
    local ipMode = db.getAttribute ("networkInfo", "_ROWID_", "1", "netWorkMode")
    if (ipMode == "1") then
        printCLIError ("Please Set IP Mode to IPv4/IPv6 to configure IPv6 Tunnels.")
        return false
    end
    return true
end

function ipv6TunnelsCfgGet (args)
    local resultTab = {}
    local row = db.getRow ("sixToFourTunnel", "_ROWID_", "1")
    printLabel ("IPv6 Tunnels")
    if (sixToFourTunnelCfgInputVal()) then
    print("6 to 4 Tunneling\n")
    if(row["sixToFourTunnel.tunnelStatus"] == "1")then
        print ("Automatic Tunneling is Enabled\n")
    elseif (row["sixToFourTunnel.tunnelStatus"] == "0") then 
	print ("Automatic Tunneling is Disabled\n")
    end
    print("List of Available ISATAP Tunnels\n")
    local i = 0
    local table = db.getTable("isatapTunnel")
    for k,v in pairs(table) do
	i = i + 1
	local row = table[i]
	local endpoint = row["isatapTunnel.localIPv4Address"] or ''
	if (row["isatapTunnel.useLanAddress"] == "1") then
		local lanConf = db.getRowWhere ("ipAddressTable","LogicalIfName='LAN' AND AddressFamily=2")
		if (lanConf ~= nil) then
			endpoint = lanConf["ipAddressTable.ipAddress"] or ''
		end
	end	
    resTab.insertField (resultTab, "ROW ID",  row["isatapTunnel._ROWID_"] or "")
    resTab.insertField (resultTab, "LocalEndpoint",  endpoint)
    resTab.insertField (resultTab, "ISATAP Subnet Prefix", row["isatapTunnel.isatapPrefix"] or "")
    end
    resTab.print (resultTab, 0)
    end
end

function ipv6TunnelsStatusGet (args)
    local resultTab = {}
    local i = 0
    printLabel("IPv6 Tunnels")
    print ("IPv6 Tunnels Status")
    if (sixToFourTunnelCfgInputVal()) then 
    local table = db.getRowsWhere ("networkInterface","ifType='tunnel'")
    for k,v in pairs(table) do
	i = i + 1
	local row = table[i]
	local tunnelName = row["networkInterface.LogicalIfName"] or ''
	local table1 = db.getRowsWhere ("ipAddressTable","LogicalIfName='" .. tunnelName .. "'")
	local ipaddr = ""
	local j = 0
	for m,n in pairs(table1) do
	j = j + 1
        local row1 = table1[j]
	if (ipaddr == "") then
	ipaddr = row1["ipAddressTable.ipAddress"] .. "/" .. row1["ipAddressTable.ipv6PrefixLen"]
	else
	ipaddr = ipaddr .. ", " .. row1["ipAddressTable.ipAddress"] .. "/" .. row1["ipAddressTable.ipv6PrefixLen"]
	end
	end
    resTab.insertField (resultTab, "Tunnel Name",  tunnelName)
    resTab.insertField (resultTab, "IPv6 Address(es)", ipaddr)
    end
    resTab.print (resultTab, 0)
    end
end
