-- userdbCLI.lua
-- Gaurav Mathur
-- TeamF1
-- www.TeamF1.com
--
-- Modification History
-- 24dec07,gnm Added userdbPassChange(), userdbPassCfgInit(),
--	       userdbToConfigInit() and userdbToConfigSave()
-- 28nov07,gnm written
--
-- Description
-- CLISH userdb LUA routines

-- load required library
require "teamf1lualib/userdb"

--
-- This routine save user password configuration information
function userdbPassChange (configRow)
    local errorFlag = "ERROR"
    local statusCode = "USERDB_CONFIG_FAILED"
    local user = configRow["users.username"]

    statusMessage = db.getAttribute("stringsMap", "stringId", statusCode, LANGUAGE)
    if (configRow["users._ROWID_"] == nil) then
        return errorFlag, statusMessage
    end

    printCLIError ("Enter Current Password:")
    local currentPass = io.stdin:read'*l'
    if (currentPass ~= configRow["users.password"]) then
	    printCLIError ("Incorrect current password.")
        return errorFlag, statusMessage
    end

    printCLIError ("Enter New Password:")
    local newPass = ""
    while (newPass == "") do 
        newPass = io.stdin:read'*l'
	if (newPass == "") then
	   printCLIError ("Invalid new password. " .. user .. 
			 " password cannot be empty. Please enter a valid new " .. 
			 user .. " password")
        end
    end

    local newPassConfirm = ""
    printCLIError ("Retype New Password:")
    while (newPassConfirm == "") do 
        newPassConfirm = io.stdin:read'*l'
	if (newPassConfirm == "") then
	   printCLIError ("Invalid new password. " .. user .. " password" ..
			 " cannot be empty. Please re-enter the new " .. user 
			 "password you chose.")
        end
    end
        
    if (newPass ~= newPassConfirm) then
        printCLIError ("New password mismatch.")
	return errorFlag, statusMessage
    end

    configRow["users.oldpassword"] = configRow["users.password"]
    configRow["users.password"] = newPass
    errorFlag, statusCode = userdb.users_config(configRow, 
		   configRow["users._ROWID_"], "edit")
    if (errorFlag == "OK") then db.save() end

    statusMessage = db.getAttribute("stringsMap", "stringId", statusCode, LANGUAGE)
    return errorFlag, statusMessage    
end

--
-- This routine takes in one argument that is the value of the
-- primary key for the object table.
function userdbPassCfgInit (args)
    local configRow = {}
    local primKey = args[1]

    local editId = db.getAttribute("users", "groupname", primKey, "_ROWID_")
    
    if (nil == editId) then 
       editId = -1 
    else
       configRow = db.getRow("users", "users._ROWID_", editId)
    end
    -- clear fields we do not want with current values in database
    return editId, configRow
end

--
-- This routine saves user idle logout time configuration
function userdbToConfigSave (configRow, args)
    local errorFlag = "ERROR"
    local statusCode = ""
    local statusMessage = ""
    
    configRow["users.loginTimeout"] = args[1]
    -- Save to database
    errorFlag, statusCode = userdb.users_config(configRow, 
	       configRow["users._ROWID_"], "edit")
    statusMessage = db.getAttribute("stringsMap", "stringId", statusCode, LANGUAGE)
    return errorFlag, statusMessage
end

--
-- This routine takes in one argument that is the value of the
-- primary key for the object table.
function userdbToConfigInit (args)
    local configRow = {}
    local rowId = nil
    
    rowId = db.getAttribute("users", "groupname", "admin", "_ROWID_")
    if (nil == rowId) then 
       rowId = -1 
    else
       configRow = db.getRow("users", "users._ROWID_", rowId)
    end
    return rowId, configRow
end
