--[[
-- Copywrite (c) 2013-2014 TeamF1, Inc.

--Copyright (c) 2013-2014, TeamF1 Networks Pvt. Ltd.
--(Subsidiary of D-Link India)
--
-- modification history
-- --------------------
-- 01c, 23Nov17, swr changes for spr 62635(XSS vulnerability) and 61441
-- 01b, 24sep14, mmk Added fwRuleScript.lua to manage firewall rules
-- 01a, 12Mar13, sen dervied from reference solution. for RIL.
]]--

--************* Requires *************

require "teamf1lualib/qos"
require "teamf1lualib/network"

--************* Initial Code *************

--************* Global Variables *************
gui.qos = {}

--
-- Manages status of QoS
--
gui.qos.bwMgmt = {}

-- 
--
-- Rate limiting WAN uplink
gui.qos.bwMeasurement = {}

--
-- The bandwidth profile add/deletes entires in the 
-- qosClassQueue table.
--
gui.qos.bwProfile = {}
gui.qos.bwProfile.add = {}
gui.qos.bwProfile.edit = {}

--
-- The qos classification add/deletes entires in the 
-- qosClassification table.
--
gui.qos.classification = {}
gui.qos.classification.add = {}
gui.qos.classification.edit = {}
gui.qos.prioQueue = {}
gui.qos.pauseFrame = {}

gui.qos.matchType = {}
gui.qos.matchType = {
    QOS_MATCH_TYPE_IP_SUBNET = 1,
    QOS_MATCH_TYPE_MAC_ADDR = 2,
    QOS_MATCH_TYPE_DSCP = 5,
    QOS_MATCH_TYPE_NETWORK = 6,
    QOS_MATCH_TYPE_SSID = 7,
}

gui.qos.prio = {}
gui.qos.prio = {
    URGENT  = 0,
    HIGH    = 1,
    MEDIUM  = 2,
    LOW     = 3,
}

local fwRulesScript = "/pfrm2.0/etc/fwRuleScript.lua"
local fwRulesCmd = "/pfrm2.0/bin/lua " .. fwRulesScript
--
--[[
--*****************************************************************************
-- gui.qos.bwMgmt.profileListGet - get info for bandwidthMgmt page
--            
-- This function gets general bandwidth management information.
--
-- RETURN: 
--  - table of wan bandwidth information
]]--

function gui.qos.bwMgmt.profileListGet()
    local status
    local errCode
    local iface = {}
    local rows = {}
    local profTbl = {}
    local cfg = {}
    local index = 1

    -- Get BandWidth Profiles List
	index  = 1
    status, errCode, rows = qos.classQueue.tableGet ()
    if (status ~= "OK") then
        return "OK", "STATUS_OK", profTbl
    end
            
	for k,v in pairs (rows) do
	    if (v["ConfigDefault"] ~= "1") then
            local record = {}
        	local recordTmp = {}
        	recordTmp["QueueName"] = util.filterXSSChars(v["QueueName"])
        	recordTmp["QueueKey"] = v["QueueKey"]
        	recordTmp["_ROWID_"] = v["_ROWID_"]

            if (tonumber (v["HTBClassPrecedence"]) ==  gui.qos.prio.URGENT) then
                recordTmp["HTBClassPrecedence"] = "Urgent"
            elseif (tonumber (v["HTBClassPrecedence"]) == gui.qos.prio.HIGH) then
                recordTmp["HTBClassPrecedence"] = "High"
            elseif (tonumber (v["HTBClassPrecedence"]) ==  gui.qos.prio.MEDIUM) then
                recordTmp["HTBClassPrecedence"] = "Medium"
            elseif (tonumber (v["HTBClassPrecedence"]) ==  gui.qos.prio.LOW) then
                recordTmp["HTBClassPrecedence"] = "Low"
            end

            recordTmp["HTBShapingRate"] = v["HTBShapingRate"]
            recordTmp["HTBShapingRateMax"] = v["HTBShapingRateMax"]
            if (tonumber(v["QueueEnabled"]) == 1) then
                recordTmp["percentage"] = util.filterXSSChars(v["HTBShapingRateMax"])
            else
                recordTmp["percentage"] = "Disabled"
            end                

            status, errCode, iface  = qos.profile.ifaceGet(v["ProfileKey"])
            if (status == "OK") then
                recordTmp["InterfaceName"] = iface["InterfaceName"]
                recordTmp["NetworkName"] = network.nameGet(iface["InterfaceName"])
            end
            profTbl[index] = {}
            profTbl[index] = recordTmp
            index = index + 1
        end
	end 

    gui.dprintf ("profTbl " .. util.tableToStringRec (profTbl))

    return "OK", "STATUS_OK", profTbl
end

--[[
--*****************************************************************************
-- gui.qos.bwMgmt.get - get info for bandwidthMgmt page
--            
-- This function gets general bandwidth management information.
--
-- RETURN: 
--  - status of bandwidth management
--  - table of wan bandwidth information
--  - table of all the bandwidth profiles
]]--

function gui.qos.bwMgmt.get()
    require "teamf1lualib/qos"
	local bwMgmtTbl = {}
	local wanBwTbl = {}
	local profTbl = {}

    -- Get the status of bandwidth limiting in the system
	bwMgmtTbl["BandwidthProfileStatus"] = qos.profile.bwLimitStatusGet("1")
	bwMgmtTbl["wanBwTbl"] = {}
	bwMgmtTbl["profTbl"] = {}

	-- Get list of interfaces on which bandwidth limiting is enabled
    local status, errCode, rows = qos.iface.tableGet()
	if (rows ~= nil) then
		for k,v in pairs (rows) do
			wanBwTmp = {}	
			wanBwTmp["UpstreamBandwidth"] = v["UpstreamBandwidth"]
			wanBwTmp["DownstreamBandwidth"] = v["DownstreamBandwidth"]
			wanBwTmp["ProfileKey"] = v["ProfileKey"]
			wanBwTmp["InterfaceName"] = v["InterfaceName"]
            table.insert(wanBwTbl, wanBwTmp)
		end 
		bwMgmtTbl["wanBwTbl"] = wanBwTbl
	end
	
    -- Get the list of all the bandwidth classes
    local status, errCode, rows = qos.classQueue.tableGet()
	if (rows ~= nil) then
		for k,v in pairs (rows) do
			if (v["ConfigDefault"] ~= "1") then
				local recordTmp = {}
				recordTmp["QueueName"] = v["QueueName"]
				recordTmp["QueueKey"] = v["QueueKey"]
				recordTmp["HTBClassPrecedence"] = v["HTBClassPrecedence"]
				recordTmp["HTBShapingRate"] = v["HTBShapingRate"]
				recordTmp["HTBShapingRateMax"] = v["HTBShapingRateMax"]
				recordTmp["percentage"] = v["HTBShapingRateMax"]

                --
                -- TODO: Optimise by looking into bwMgmtTbl["wanBwTbl"]
                --
                recordTmp["InterfaceName"] = qos.profile.idToName(v["ProfileKey"])
                recordTmp["NetworkName"] = network.nameGet(iface["InterfaceName"])
                table.insert(profTbl, recordTmp)
			end
		end 
		bwMgmtTbl["profTbl"] = profTbl
	end
	
    return  bwMgmtTbl
end

--[[
--**************************************************************************
-- gui.qos.bwmgmt.statusSet - ENABLE/DISABLE BandWidth Management.
--
--  Enables/Disables QoS on WAN interfaces.
--
-- INPUT: bwProfStatus 
--
-- OUTPUT: Configures the Bandwidth Management on WAN interfaces.
--
-- RETURN: result,errorCode.
--
]]--

function gui.qos.bwMgmt.statusSet (qosStatus)
	local ifTbl = {}
	local ret
	local errCode
    local status
	
    -- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end
    
    -- Check if input is valid
	if (qosStatus == nil) then
		return "ERROR", "BWPROF_INPUT_INVALID"
	end
  
    gui.dprintf ("InputTable is " .. util.tableToStringRec(qosStatus))

    status, errCode, ifTbl = qos.iface.tableGet()
	if (ifTbl ~= nil) then
		for k,v in pairs(ifTbl) do
	        -- change qos status on the interfaces
			ret, errCode = qos.iface.statuschange(v["InterfaceName"], 
                                                  qosStatus["bwProfileStatus"])
			if (ret < 0) then
				return "ERROR", "BWPROF_IF_DISABLE_FAILED"
			end
		end
	end

    db.save2()
    os.execute(fwRulesCmd)

	return "OK", "STATUS_OK"
end

--[[
--*****************************************************************************
-- gui.qos.bwMgmt.statusGet - get info for bandwidthMgmt page
--            
-- This function gets general bandwidth management information.
--
-- RETURN: 
--  - status of bandwidth management
]]--

function gui.qos.bwMgmt.statusGet()
    local bwMgmtTbl = {}
    local status
    local errCode
    local query =  nil

    query = "_ROWID_=1"
    status, errCode, iface  = qos.iface.cfgByQueryGet(query)
    if (status ~= "OK") then
        return "ERROR", errCode        
    end        

    bwMgmtTbl.bwProfileStatus = iface["Enable"]
    bwMgmtTbl.UpstreamBandwidth = util.filterXSSChars(iface["UpstreamBandwidth"])
    gui.dprintf ("Bandwidth Profile Status is " .. bwMgmtTbl.bwProfileStatus)

    return "OK", "STATUS_OK", bwMgmtTbl
end

--[[
--**************************************************************************
--gui.qos.wanBwConfig - Configures the WAN interfaces BandWidth.
--
-- INPUT: qosQueueManagement Lua Table.
--
--		qosQueueManagement[rowId]["InterfaceName"] = <interfacename>
--  	qosQueueManagement[rowId]["UpstreamBandwidth"] = <value>
--		qosQueueManagement[rowId]["DownstreamBandwidth"] = <value>	
--
-- OUTPUT: Configures the Bandwidth Management on WAN interfaces.
--
-- RETURN: result,errorCode.
--
]]--

function gui.qos.wanBwConfig (wanBwTbl)
	local result
	local errCode
	
    -- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end
   
    -- Check if input is valid
    if (wanBwTbl == nil) then
        return "ERROR","BWPROF_INPUT_INVALID"
    end
    
    -- Configure Bandwidth for each interface
    for k,v in pairs(wanBwTbl) do

    	result, errorCode = qos.iface.bwchange(v["InterfaceName"], 
											   v["UpstreamBandwidth"],
											   v["DownstreamBandwidth"])
	    if (result < 0) then
			return "ERROR", errCode
	    end
    end

    return "OK", "STATUS_OK"
end

--[[
--**************************************************************************
--gui.qos.bwProfile.add.set - Adds the configured bandwidth profile in the backend.
--
-- INPUT: bwprof Table.
--
--		bwprof["QueueName"] = <Queuename>
--		bwprof["HTBClassPrecedence"] = <HTBClassPrecedence>
--		bwprof["HTBShapingRateMax"] = <HTBShapingRateMax>
--		bwprof["HTBShapingRate"] = <HTBShapingRate>
--		bwprof["InterfaceName"] = <InterfaceName>
--
-- OUTPUT: Configures the Bandwidth Management on WAN interfaces.
--
-- RETURN: result,errorCode.
--
]]--

function gui.qos.bwProfile.add.set(bwprof)
    require "teamf1lualib/network"
   	local queue = {}
	local ret
	local errCode
 
    -- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end
   
    -- Check if input is valid
    if (bwprof == nil) then
        return "ERROR","BWPROF_INPUT_INVALID"
    end

	-- check if the classQueue with the
	-- same name exists
	ret   = qos.classQueue.getByName(bwprof["QueueName"])
	if (ret ~= nil) then
        return "ERROR","BWPROF_PROFILE_EXISTS"
	end

    gui.dprintf ("InputTable is" .. util.tableToStringRec(bwprof))

	queue["QueueName"] =  bwprof["QueueName"]
    local LogicalIfName = network.logicalIfNameGet(bwprof["NetworkName"])
    if (LogicalIfName == nil) then
        return "ERROR", "BWPROF_ERR_DB_BUSY"
    end

    gui.dprintf ("bwprof.add.set: Looking up profile for: " .. bwprof["NetworkName"])
    queue["ProfileKey"] = qos.profile.NameToId(LogicalIfName)
    if (queue["ProfileKey"] == nil) then

        -- create a new profile
        gui.dprintf ("bwprof.add.set: creating profile=" .. LogicalIfName)
        status, errCode, profile = qos.profile.create(LogicalIfName)
        if (status ~= 0) then
            return "ERROR", errCode
        end            

        -- set it on the interface
        gui.dprintf ("bwprof.add.set: setting profile on " .. LogicalIfName)
        status, errCode = qos.iface.profileSet(LogicalIfName, 
                                               profile["ProfileKey"])
        if (status ~= "OK") then
            return "ERROR", errCode
        end            
        queue["ProfileKey"] = profile["ProfileKey"]
    end
            
    queue["ParentId"] = queue["ProfileKey"] .. ":1"
    classId =  qos.profile.newClassIDGet(queue["ProfileKey"])
    if (classId == nil) then
        return "ERROR", "BWPROF_CLASSID_CREATE_FAILED"
    end
    queue["QueueId"] = queue["ProfileKey"] .. ":" .. classId

	queue["QosEleType"] = "3" -- sfq/red qdisc + htb class

    local percentage = tonumber(bwprof["percentage"])
    queue["RateUnitType"] = qos.classQueue.rateType.QOS_RATE_TYPE_PERCENT
	queue["HTBShapingRateMax"] =  percentage
	queue["HTBShapingRate"] = percentage

	if (tonumber(bwprof["HTBClassPrecedence"]) == gui.qos.prio.URGENT) then
		-- we will use FIFO qdisc for urgent with
		-- queuelen 2 for urgent traffic
		-- FIF0 limit must be > 1, so we choose 2
		queue["QosQdiscType"] = "4"
		queue["FIFOLimit"] = "2"
	elseif (tonumber(bwprof["HTBClassPrecedence"]) == gui.qos.prio.HIGH) then
		-- RED qdisc with latency 200ms
		queue["REDlatency"] = "200"
		queue["QosQdiscType"] =  "2"
	elseif (tonumber(bwprof["HTBClassPrecedence"]) == gui.qos.prio.MEDIUM) then
		-- RED qdisc with latency 350ms
		queue["REDlatency"] =  "350"
		queue["QosQdiscType"] =  "2"
	elseif (tonumber(bwprof["HTBClassPrecedence"]) == gui.qos.prio.LOW) then
		-- RED qdisc with latency 500ms
		queue["REDlatency"] =  "500"
		queue["QosQdiscType"] =  "2"
	end

	queue["QosClassType"] = "1" -- HTB Class 
	queue["HTBClassPrecedence"] = bwprof["HTBClassPrecedence"] 
	queue["QueueLevel"] = "2"

    if (tonumber(bwprof["RateLimitingStatus"]) ~= 0) then
    	queue["QueueEnabled"] = "1"
    else
    	queue["QueueEnabled"] = "0"
    end        

    queue["ConfigDefault"] = "0"
	
    ret, errCode = qos.classQueue.add(queue)
	if (ret < 0) then
		return "ERROR", errCode
	end

    db.save2()

	return "OK", "STATUS_OK"
end

--[[
--**************************************************************************
--gui.qos.bwProfile.edit.get - get bandwidth profile 
--
-- INPUT: 
-- QueueKey - identifier for the bw profile
--
-- RETURN: 
]]--

function gui.qos.bwProfile.edit.get (QueueKey)
	bwprof = {}
    local status
    local errCode
    local queue = {}

	-- Check if we have a key or classId
    if (QueueKey == 0 or QueueKey == nil) then
        return "ERROR","BWPROF_ID_INVALID"
    end

    gui.dprintf("Get Queue " .. QueueKey)

	-- get the class Queue from the database 
    queue =  qos.classQueue.get(QueueKey)
	if (queue == nil) then
		return "ERROR", "BWPROF_NOT_FOUND"
	end

	bwprof["QueueKey"] = QueueKey
	bwprof["QueueName"] = util.filterXSSChars(queue["QueueName"])
	bwprof["HTBClassPrecedence"] = queue["HTBClassPrecedence"]
	bwprof["HTBShapingRate"] = queue["HTBShapingRate"]
	bwprof["HTBShapingRateMax"] = queue["HTBShapingRateMax"]
    bwprof["percentage"] = util.filterXSSChars(queue["HTBShapingRate"])

    if (tonumber(queue["QueueEnabled"]) == 0) then
        bwprof["RateLimitingStatus"] =  "0"
    else
        bwprof["RateLimitingStatus"] =  "1"
    end                

    bwprof["LogicalIfName"] = qos.profile.idToName(queue["ProfileKey"])

    local networkName = network.nameGet(bwprof["LogicalIfName"])
    if (networkName == nil) then
        return "ERROR", "BWPROF_ERR_DB_BUSY"
    end

    bwprof["InterfaceName"] = networkName
    --errCode, statusCode, bwprof["networkList"] = gui.networking.network.ListGet ()
	
    gui.dprintf("Finished Query .. " .. util.tableToStringRec(bwprof))

	return "OK", "STATUS_OK", bwprof
end

--[[
--**************************************************************************
--gui.qos.bwProfile.add.get - get  info for add page
--
-- This function gets info that is required to display the add page
--
-- RETURN: 
]]--

function gui.qos.bwProfile.add.get()
	local page = {}

    page["RateLimitingStatus"] = "0"
	--errCode, statusCode, page["networkList"] = gui.networking.network.ListGet ()

	return "OK", "STATUS_OK", page
end

--[[
--**************************************************************************
--gui.qos.bwProfile.edit.set - edit bandwidth profile.
--
-- INPUT: bwprof Lua Table
--		bwprof["QueueKey"] = <QueueKey>
--		bwprof["QueueName"] = <Queuename>
--		bwprof["HTBClassPrecedence"] = <HTBClassPrecedence>
--		bwprof["HTBShapingRateMax"] = <HTBShapingRateMax>
--		bwprof["HTBShapingRate"] = <HTBShapingRate>
--		bwprof["InterfaceName"] = <InterfaceName>
--
-- OUTPUT: Edits the Bandwidth Profile configuration
--
-- RETURN: result,errorCode
--
]]--

function gui.qos.bwProfile.edit.set (rowid, bwprof)

    local query
    local errCode
    local res
    -- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end
   
	local queue = {}
    
    -- Check if input is valid
    if (bwprof == nil) then
        return "ERROR","BWPROF_INPUT_INVALID"
    end
  
    --
    -- check if the profile is being used by
    -- an classification rule
    --
    query = "QueueKey='" ..rowid.. "'"
    status, errCode, res =  qos.rule.cfgByQueryGet(query) 
    if (res ~= nil) then
        return "OK", "BWPROF_PROFILE_IN_USE" 
	end

    gui.dprintf ("Queue Information " .. util.tableToStringRec(bwprof))

	-- Check if we have a key or classId
    if (bwprof["QueueName"] == nil) then
        return "ERROR","BWPROF_ID_INVALID"
    end

	-- get the class Queue from the database 
    queue = qos.classQueue.getByName(bwprof["QueueName"])
	if (queue == nil) then
		return "ERROR", "BWPROF_NOT_FOUND"
	end

	-- if name has changed, check if the profile with the
	-- same name exists
	if (queue["QueueName"] ~= bwprof["QueueName"]) then
		ret = qos.classQueue.getByName(bwprof["QueueName"])
		if (ret ~= nil) then
        	return "ERROR","BWPROF_PROFILE_EXISTS"
		end
	end

	queue["QueueName"] = bwprof["QueueName"]

    local percentage = tonumber(bwprof["percentage"])
    queue["RateUnitType"] = qos.classQueue.rateType.QOS_RATE_TYPE_PERCENT
	queue["HTBShapingRateMax"] =  percentage
	queue["HTBShapingRate"] = percentage
	queue["HTBClassPrecedence"] = bwprof["HTBClassPrecedence"] 
	
	--Load New Class Queue information.
    local LogicalIfName = network.logicalIfNameGet(bwprof["NetworkName"])
    if (LogicalIfName == nil) then
        return "ERROR", "BWPROF_ERR_IFNAME_NOT_FOUND"
    end

    ProfileKey = qos.profile.NameToId(LogicalIfName)
    if (queue["ProfileKey"] == nil) then
        return "ERROR", "BWPROF_INPUT_INVALID"
    end

    -- if the profile has changed, change the queueId */
    if (tonumber(ProfileKey) ~= tonumber(queue["ProfileKey"])) then

        if (qos.classQueue.inUse(queue["QueueKey"]) == true) then
    		return "ERROR", "BWPROF_IN_USE"
        end            

        queue["ParentId"] = ProfileKey .. ":1"
        classId =  qos.profile.newClassIDGet(ProfileKey)
        if (classId == nil) then
            return "ERROR", "BWPROF_CLASSID_CREATE_FAILED"
        end
        queue["QueueId"] = ProfileKey .. ":" .. classId
        queue["ParentId"] = ProfileKey .. ":1"
        queue["ProfileKey"] = ProfileKey
    end

    if (tonumber(bwprof["RateLimitingStatus"]) ~= 0) then
    	queue["QueueEnabled"] = "1"
    else
    	queue["QueueEnabled"] = "0"
    end        

	queue["QosEleType"] = "3" -- sfq/red qdisc + htb class

	if (tonumber(bwprof["HTBClassPrecedence"]) == gui.qos.prio.URGENT) then
		-- we will use FIFO qdisc for urgent with
		-- queuelen 2 for urgent traffic
		-- FIF0 limit must be > 1, so we choose 2
		queue["QosQdiscType"] = "4"
		queue["FIFOLimit"] = "2"
	elseif (tonumber(bwprof["HTBClassPrecedence"]) == gui.qos.prio.HIGH) then
		-- RED qdisc with latency 200ms
		queue["REDlatency"] = "200"
		queue["QosQdiscType"] =  "2"
	elseif (tonumber(bwprof["HTBClassPrecedence"]) == gui.qos.prio.MEDIUM) then
		-- RED qdisc with latency 350ms
		queue["REDlatency"] =  "350"
		queue["QosQdiscType"] =  "2"
	elseif (tonumber(bwprof["HTBClassPrecedence"]) == gui.qos.prio.LOW) then
		-- RED qdisc with latency 500ms
		queue["REDlatency"] =  "500"
		queue["QosQdiscType"] =  "2"
	end

    gui.dprintf ("New Queue configuration " .. util.tableToStringRec(queue))

	-- call the qos API
	ret, errCode  = qos.classQueue.edit(queue);
	if (ret < 0) then
		return "ERROR", errCode
	end

    db.save2()

	return "OK", "STATUS_OK"
end

--[[
--**************************************************************************
-- gui.qos.bwProfile.delete - deletes selected bandwidth profiles
--
-- This function deletes multiple(selected) bandwidth profile.
--
-- RETURNS
]]--

function gui.qos.bwProfile.delete (QueueKeyTbl)

    -- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end
   
	local ret
	local errCode
	local QueueKey

    --
    -- check if the profile is being used by
    -- an classification rule
    --
    if (gui.qos.bwProfile.bwProfileInUseCheck(QueueKeyTbl) == true) then
	    return "OK", "BWPROF_PROFILE_IN_USE"
    end        

	--QueueKeyTbl is a table
	if (QueueKeyTbl ~= nil) then
		for k,v in pairs(QueueKeyTbl) do
			if v~= nil then 
			    QueueKey = v
    			ret, errCode = qos.classQueue.delete(QueueKey)
	    		if (ret < 0) then
		    		return "ERROR", errCode
			    end
			end
		end
	end

    db.save2()

	return "OK", "STATUS_OK"
end

--[[
--**************************************************************************
-- gui.qos.bwProfile.bwProfileInUseCheck - Checks the selected bandwidth profiles are in
--                                  use by any traffic selectors
--
-- This function checks whether bandwidth profile is in use with any traffic
-- selectors.
--
-- RETURNS
]]--

function gui.qos.bwProfile.bwProfileInUseCheck (QueueKeyTbl)
	local res
	local errCode
	local QueueKey
    local query

    -- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end
   
	--QueueKeyTbl is a table
	if (QueueKeyTbl ~= nil) then
		for k,v in pairs(QueueKeyTbl) do
			if v~= nil then 
			    QueueKey = v
            	-- get the list of traffic selectors with this QueueKey 
                -- from the database

	            query = "QueueKey='" ..QueueKey.. "'"
                status, errCode, res =  qos.rule.cfgByQueryGet(query) 
                if (res ~= nil) then
                    return true  --Given profile is in Use
			    end
		    end
        end
        return false --No Profile is in Use
    end
end

--[[
--**************************************************************************
-- gui.qos.classification.getSvcTbl - get services table
--
-- The function gets the list of service names.
--
-- RETURNS: a table having service names or nil
]]--

function gui.qos.classification.getSvcTbl()
	local svcTbl = {}
	local index = 1

	local services = db.getTable("Services", false)
	if (services == nil) then
		return nil
	end

	for k,v in pairs(services) do
        if (v["PortType"] == "1") then
            svcTbl[index] = {}
            svcTbl[index]["serviceName"] = util.filterXSSChars(v["ServiceName"])
            index =  index + 1
        end
    end

	return svcTbl
end

--[[
--**************************************************************************
-- gui.qos.classification.trafSelLoad - load a rule into traffic selector
--
-- This function loads a rule into the traffic selector as required
-- by the GUI.
-- 
-- RETURNS: traffic selector table
]]--


function gui.qos.classification.trafSelLoad (rule)
	local row = {}

	row["ClassificationKey"]  = rule["ClassificationKey"]
 	row["serviceName"] =  rule["Service"]
 	row["_ROWID_"] =  rule["_ROWID_"]
    row["MatchTypeStr"] = ""
	if (rule["IngressInterface"] ~= nil and 
        (string.find(rule["IngressInterface"], "phyif") ~= nil)) then
		local splitparts = util.split(rule["IngressInterface"], ":")
		row["VapName"] = splitparts[2]
		row["MatchType"] = tostring(gui.qos.matchType.QOS_MATCH_TYPE_SSID)
		row["MatchTypeStr"] = "SSID"
	elseif (rule["DSCPCheck"] ~= nil and rule["DSCPCheck"] ~= "") then
		row["DSCP"] = rule["DSCPCheck"]
		row["MatchType"] = tostring(gui.qos.matchType.QOS_MATCH_TYPE_DSCP)
		row["MatchTypeStr"] = "DSCP"
	elseif (rule["IngressInterface"] ~= nil and rule["IngressInterface"] ~= "") then
        if (string.find(rule["IngressInterface"], "LOCAL") ~= nil) then
            local splitparts = util.split(rule["IngressInterface"], ":")
    		row["networkName"] = network.nameGet(splitparts[2])
        else
    		row["networkName"] = network.nameGet(rule["IngressInterface"])
        end            
		row["MatchType"] = tostring(gui.qos.matchType.QOS_MATCH_TYPE_NETWORK)
		row["MatchTypeStr"] = "Network"
	elseif (rule["SourceMACAddress"] ~= nil and rule["SourceMACAddress"] ~= "") then
		row["MAC"] = rule["SourceMACAddress"] 
		row["MatchType"] = tostring(gui.qos.matchType.QOS_MATCH_TYPE_MAC_ADDR)
		row["MatchTypeStr"] = "MAC Address"
	elseif (rule["SourceIP"] ~= nil and rule["SourceIP"] ~= "") then
		row["startIP"] =  rule["SourceIP"]
		row["endIP"] =  rule["SourceMask"]
		row["MatchType"] = tostring(gui.qos.matchType.QOS_MATCH_TYPE_IP_SUBNET)
		row["MatchTypeStr"] = "IP Subnet"
	end

    if (tonumber(rule["ForwardingPolicy"]) < 0) then
        row["DisableFastForwardingStatus"] = "1"
    else        
        row["DisableFastForwardingStatus"] = "0"
    end

    local queue = qos.classQueue.get(rule["QueueKey"])
    if (queue ~= nil) then
    	row["QueueName"] = queue["QueueName"]
    end
                     
	return row
end

--[[
--**************************************************************************
-- gui.qos.classification.ruleLoad - load a qos rule
--
-- This function load a qos rule from the traffic selector that is 
-- provided by the GUI
--
-- RETURNS: status, error code, rule
--   
]]--

function gui.qos.classification.ruleLoad (row)
	local rule = {}
	local queue = {}
	local ret
	local errCode
	
	-- get the service from the database
	local query  = "ServiceName='" .. row["serviceName"] .."'"
	local service = db.getRowWhere("Services", query, false)
	if (service == nil) then
		return "ERROR","TRAF_SEL_INVALID_INPUT"
	end		

	-- get the queue from the database
    queue = qos.classQueue.getByName(row["QueueName"])
	if (queue == nil) then
		return "ERROR","BWPROF_NOT_FOUND"
	end

	-- fill the service into the rule
	rule["Protocol"] = service["Protocol"]
	rule["DestPort"] = service["DestinationPortStart"]
	rule["DestPortRangeMax"] = service["DestinationPortEnd"]
	rule["Service"] = row["serviceName"]
	if (row["ClassificationKey"] ~= nil) then
		rule["ClassificationKey"] = row["ClassificationKey"]
	end
    rule["ProfileKey"] = queue["ProfileKey"]
	rule["ClassificationEnable"] = "1"
	rule["QueueKey"] = queue["QueueKey"]

    --[[
    --
    -- Suggested mapping:
    -- 802.1p=7 -> Urgent - Gives us ability to use highest priority 802.1p value, 
    --             and have a priority available for internal applications only.
    -- 802.1p=6 -> [Unused] - Not really needed when we already have 802.1p=7.
    -- 802.1p=5 -> High - Gives us ability to use the 802.1p value intended for Voice.
    -- 802.1p=4 -> Medium - Gives us ability to use the 802.1p value intended for video.
    -- 802.1p=3 -> [Unused] - Not needed when Voice/Video is covered by above values.
    -- 802.1p=2 -> Low - Gives us ability to give internal traffic lower priority 
    --             than LAN side traffic.
    -- 802.1p=1 -> [Unused]
    -- 802.1p=0 -> Background - Gives us ability to shape traffic with bandwidth 
    --             profiles (tc), with the lowest possible 
    --             priority (e.g. torrents etc.). We also use the 802.1p value 
    --             intended for such traffic. The 802.1p value=0 will map to 
    --             hardware queue "Low".
    ]]--

    if (tonumber(queue["HTBClassPrecedence"]) == gui.qos.prio.URGENT) then
        rule["EthernetPriorityMark"] = "7"
    elseif (tonumber(queue["HTBClassPrecedence"]) == gui.qos.prio.HIGH) then
        rule["EthernetPriorityMark"] =  "5"
    elseif (tonumber(queue["HTBClassPrecedence"]) ==  gui.qos.prio.MEDIUM) then
        rule["EthernetPriorityMark"] =  "4"
    elseif (tonumber(queue["HTBClassPrecedence"]) ==  gui.qos.prio.LOW) then
        rule["EthernetPriorityMark"] =  "0"
    end

	if (rule["QueueKey"] == nil) then
		return "ERROR","TRAF_SEL_INVALID_INPUT"
	end
	
    if ((row["DisableFastForwardingStatus"] ~= nil) and 
        (tonumber(row["DisableFastForwardingStatus"]) > 0)) then
        rule["ForwardingPolicy"] = "-1"
    else        
        rule["ForwardingPolicy"] = "0"
    end
            
    rule["ConfigDefault"] = "0"
	rule["SourceIP"] = "" 
	rule["SourceMask"] = "" 
	rule["SourceMACAddress"] = ""
	rule["IngressInterface"] = ""
	rule["DSCPCheck"] = ""
	rule["IngressInterface"] = ""
	if (tonumber(row["MatchType"]) == gui.qos.matchType.QOS_MATCH_TYPE_IP_SUBNET) then
		rule["SourceIP"] = row["startIP"]
		rule["SourceMask"] = row["endIP"]
		if ((util.fileExists("/pfrm2.0/BRCMJCO300")) or (util.fileExists("/pfrm2.0/ECONET")) ) then
        	rule["ForwardingPolicy"] = "-1"
		end
	elseif (tonumber(row["MatchType"]) == gui.qos.matchType.QOS_MATCH_TYPE_MAC_ADDR) then
		if (row["MAC"] ~= nil) then 
            require "ifDevLib"
            if (ifDevLib.isMulticastEtherAddr(row["MAC"]) or
                ifDevLib.isBroadcastEtherAddr(row["MAC"])) then
                return "ERROR","INVALID_ACL_MAC"
            else
                rule["SourceMACAddress"] = row["MAC"]
            end

        rule["ForwardingPolicy"] = "-1"
        end
	elseif(tonumber(row["MatchType"]) == gui.qos.matchType.QOS_MATCH_TYPE_NETWORK) then
		status, errCode, conf = network.ifConfGet(row["networkName"])
    		if (status ~= "OK") then
        		return status, errCode
    		end
        if (gui.qos.isWANIf(row["interfaceName"])) then
		rule["IngressInterface"] = "LOCAL:" .. conf["interfaceName"]
        else      
    		rule["IngressInterface"] = conf["interfaceName"]
        end
	elseif(tonumber(row["MatchType"]) == gui.qos.matchType.QOS_MATCH_TYPE_DSCP) then
		rule["DSCPCheck"] = row["DSCP"]
        rule["ForwardingPolicy"] = "-1"
	elseif(tonumber(row["MatchType"]) == gui.qos.matchType.QOS_MATCH_TYPE_SSID) then
		rule["IngressInterface"] = "phyif:" .. row["VapName"]
        rule["ForwardingPolicy"] = "-1"
	end

	return "OK","STATUS_OK", rule
end

--[[
--**************************************************************************
-- gui.qos.classification.add.get - get info required for add page
--
-- This function gets the info required for the add page.
-- 
-- RETURNS: page
]]--

function gui.qos.classification.add.get ()
	local page = {}

	page["Services"] = {}
	page["Services"] = gui.qos.classification.getSvcTbl()

    page["DisableFastForwardingStatus"] = "0"

	page["bandwithProfilesTbl"] = {}
	page["bandwithProfilesTbl"] = gui.qos.classification.getProfTbl()

    if (UNIT_INFO ~= "ODU") then
        page["ssidTbl"] = {}
        page["ssidTbl"] = gui.qos.ssidTblGet()
    end

    page["netTbl"] =  {}
    page["netTbl"] =  gui.qos.netIngressTblGet()

	return "OK", "STATUS_OK", page
end

--[[
--**************************************************************************
-- gui.qos.ssidTblGet - 
--
-- This function gets the list of SSID available 
-- 
-- RETURNS: page
]]--

function gui.qos.ssidTblGet()
    require "teamf1lualib/dot11"
    local ssidList = {}
    local vap = {}

    vapTbl = dot11.accessPointGet()
    if (vapTbl == nil) then
        return ssidList
    end        

    for k,v in pairs(vapTbl) do
        vap = {}
        vap["ssid"] = v["ssid"]
        vap["VapName"] = dot11Profile.ifNameGet(v["profileName"])
        table.insert(ssidList, vap)
    end    

    return ssidList
end

--[[
--**************************************************************************
-- gui.qos.netIngressTblGet - 
--
-- 
-- RETURNS: page
]]--

function gui.qos.netIngressTblGet()
    require "teamf1lualib/ifDev"
    local netList = {}
    local net = {}        
    local ifTbl = {}

    -- get a list of LAN,Routed networks
    local status, errCode, ifTbl = ifDev.netListGet()
    if (status ~= "OK") then
        return netList
    end        

    for k,v in pairs(ifTbl) do
        net = {}
        if (ifDev.isRouted(v["connectionType"])) then
            net["interfaceName"] = v["interfaceName"]
            net["networkName"] = v["networkName"]
            table.insert(netList, net)
        end            
    end        

    return netList
end

--[[
--**************************************************************************
-- gui.qos.classification.getProfTbl - get profile list
--
-- This function gets the list of all the profiles.
--  
-- RETURNS: profile list
]]--

function gui.qos.classification.getProfTbl()
	local record = {}
	local index = 1

	local status, errCode, rows = qos.classQueue.tableGet()
	if (rows ~= nil) then
		for k,v in pairs (rows) do
			if (v["ConfigDefault"] ~= "1") then
				record[index]  = {}
				record[index]["QueueName"] = util.filterXSSChars(v["QueueName"])
				record[index]["QueueEnabled"] = util.filterXSSChars(v["QueueEnabled"])
				index = index + 1
			end
		end
	end

	return record
end

--[[
--**************************************************************************
-- gui.qos.classification.add.set -  add a classification rule
--
-- This function adds a classifcation rule into the qos subsystem. The
-- input to the function is the following table.
-- 		row["serviceName"]  
--		row["ClassificationKey"] 
--		row["QueueName"] 
--		row["VapName"]
--		row["DSCPCheck"] 
--		row["VLANIDCheck"]
--		row["PortName"] 
--		row["SourceMACAddress"]
--		row["SourceIP"] 
--		row["MatchType"] 
--      row["DisableFastForwardingStatus"]
--
-- RETURNS: status, error code
]]--

function gui.qos.classification.add.set (row)
	local rule = {}
	
    -- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end
  
    gui.dprintf("classification rule add: " .. util.tableToStringRec(row))

	-- load the rule
	ret, errCode, rule  = gui.qos.classification.ruleLoad(row)
	if (ret == "ERROR") then
		return ret, errCode
	end

    gui.dprintf("classification rule: " .. util.tableToStringRec(rule))


	-- add the qos rule to the system
	ret, errCode = qos.rule.add(rule)
	if (ret < 0) then
		return "ERROR", errCode
	end

    db.save2()

	return "OK", "STATUS_OK"
end

--[[
--**************************************************************************
-- gui.qos.classification.edit.set - edit a traffic selector
--
-- This function edits a traffic selector.
--
-- RETURNS: status, error code.
]]--

function gui.qos.classification.edit.set (row)
	local rule = {}

	
    -- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end
   
    gui.dprintf("classification rule edit input: " .. util.tableToStringRec(row))

	-- load the rule
	ret, errCode, rule  = gui.qos.classification.ruleLoad(row)
	if (ret == "ERROR") then
		return ret, errCode
	end

    gui.dprintf("classification rule: " .. util.tableToStringRec(rule))

	-- edit the qos rule
	ret, errCode = qos.rule.edit(rule)
	if (ret < 0) then
		return "ERROR", errCode
	end

    db.save2()

	return "OK", "STATUS_OK"
end

--[[
--**************************************************************************
-- gui.qos.classification.edit.get - get a traffic selector
--
-- This function gets the traffic selector with a given ruleId
-- 
-- RETURNS: traffic selector
]]--

function gui.qos.classification.edit.get (ruleId)
	local query 
	local rule = {}
	local trafTmp = {}
	local traf = {}

	-- get the rule
    rule = qos.rule.get(ruleId)
	if (rule == nil) then
		return "ERROR", "TRAF_SEL_INVALID_INPUT"
	end

	-- load the rule into traffic selector
	traf = gui.qos.classification.trafSelLoad (rule)

	traf["Services"] = {} 
	traf["Services"] = gui.qos.classification.getSvcTbl()

	traf["bandwithProfilesTbl"] = {}
	traf["bandwithProfilesTbl"] = gui.qos.classification.getProfTbl()

    if (UNIT_INFO ~= "ODU") then
        traf["ssidTbl"] = {}
        traf["ssidTbl"] = gui.qos.ssidTblGet()
    end

    traf["netTbl"] =  {}
    traf["netTbl"] =  gui.qos.netIngressTblGet()

    gui.dprintf ("Classification Get: " .. util.tableToStringRec(traf))
        
    traf["startIP"] = util.filterXSSChars(traf["startIP"])
    traf["endIP"] = util.filterXSSChars(traf["endIP"])
    traf["MAC"] = util.filterXSSChars(traf["MAC"])

	return "OK", "STATUS_OK", traf
end

--[[
--**************************************************************************
-- gui.qos.classification.delete - delete a traffic selector
--
-- This function deletes a traffic selector.
--
-- RETURNS:  status, errCode
]]--

function gui.qos.classification.delete(QueueKeyTbl)
	local ret
	local errCode
	local ruleId
	
    -- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end
   	
	-- edit the qos rule
	if (QueueKeyTbl ~= nil) then
		for k,v in pairs (QueueKeyTbl) do
			if (v~= nil) then 
    			ruleId = v
	    		ret, errCode = qos.rule.delete(ruleId)
		    	if (ret < 0) then
			    	return "ERROR", errCode
    			end
			end
		end
	end
	
    db.save2()

	return "OK", "STATUS_OK"
end

--[[
--**************************************************************************
-- gui.qos.classification.getList - get all traffic selectors
--
-- This function gets all the qos traffic selectors in the system
--
-- RETURNS: table of traffic selectors
]]--

function gui.qos.classification.getList()  
	local selectors = {}
	local rules = {}
    local status
    local errCode

    status, errCode, rules = qos.rule.tableGet()
	if (rules == nil) then
		return "OK", "STATUS_OK", selectors
	end

	for k,v in pairs(rules) do
		local row = {}
        if ((v["ConfigDefault"] == nil) or
            (tonumber(v["ConfigDefault"]) == 0)) then
		    row = gui.qos.classification.trafSelLoad(v)
		    if (row ~= nil) then
                table.insert(selectors, row)
            end            
		end
	end

    for i,v in ipairs (selectors) do
        selectors[i] = {}
        selectors[i] = v
        selectors[i].serviceName = util.filterXSSChars(v["serviceName"])
        selectors[i].MatchTypeStr = util.filterXSSChars(v["MatchTypeStr"])
        selectors[i].QueueName = util.filterXSSChars(v["QueueName"])
    end

	return "OK", "STATUS_OK", selectors
end

--[[
--**************************************************************************
-- gui.qos.bwMeasurement.systemStartStatusConfigure
--
--
-- 
]]--

function gui.qos.bwMeasurement.systemStartStatusConfigure (cfg)

    cfg["MeasureBwOnStart"] = cfg["measureBwOnReboot"]

    gui.dprintf("QoS Global Cfg: " .. util.tableToStringRec(cfg))
    local status, errCode = qos.globals.set(cfg)

    db.save2()

	return status, errCode
end

--[[
--**************************************************************************
-- gui.qos.bwMeasurement.systemStartStatusGet
--
--
-- @return status
-- @return errCode
-- @return cfg={}
--         cfg["measureBwOnReboot"] = 
]]--

function gui.qos.bwMeasurement.systemStartStatusGet ()
    local cfg = {}
    local qosGlobals = qos.globals.get()

    cfg["measureBwOnReboot"] = qosGlobals["MeasureBwOnStart"]

	return "OK", "STATUS_OK", cfg
end

--[[
--**************************************************************************
-- gui.qos.bwMeasurement.rateLimitShareSet 
--
--
-- 
]]--

function gui.qos.bwMeasurement.rateLimitShareSet (inputTable)
    local status
    local errCode
    local globals = {}

    if (inputTable == nil or inputTable["rateLimitShare"] == nil) then 
        return "ERROR", "QOS_ERR_RATE_LIMIT_SET_INVALID_ARGS"
    end

    globals["MaxUpstreamBwPercentage"] = inputTable["rateLimitShare"]
    
    status, errCode = qos.globals.set(globals)
    
	return status, errCode
end
--[[
--**************************************************************************
-- gui.qos.bwMeasurement.rateLimitShareGet 
--
--
-- 
-- @return status
-- @return errCode
-- @return cfg={}
--         cfg["rateLimitShare"] = 
]]--

function gui.qos.bwMeasurement.rateLimitShareGet () 
    local cfg = {}
    local tbl = {}
    
    tbl = qos.globals.get()
    if tbl == nil then
        return "ERROR", "QOS_ERR_GLOBAL_CFG_GET"
    end

    cfg ["rateLimitShare"] = tbl["MaxUpstreamBwPercentage"]

	return "OK", "STATUS_OK", cfg
end

--[[
--**************************************************************************
-- gui.qos.bwMeasurement.wanBwCfgSet
--
--
-- cfg={}
-- cfg["dynamicBwMeasure"] = 0 or 1
-- cfg["upstreamBandwidth"] =  <value>
-- cfg["downstreamBandwidth"] =  <value>
-- cfg["networkName"] =  <value>
-- 
]]--

function gui.qos.bwMeasurement.wanBwCfgSet (cfg)
    require "teamf1lualib/ifDev"

    -- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end
   	
    gui.dprintf("QoS Bandwidth: " .. util.tableToStringRec(cfg))
    
    local status, errCode, ifcfg = ifDev.cfgByNameGet(cfg["networkname"])
    if (status ~= "OK") then
        return "ERROR", errCode
    end            

    local conf = {}
    conf["LogicalIfName"] = ifcfg["LogicalIfName"]
    conf["MeasureBandwidth"] = cfg["dynamicBwMeasure"]
    cfg["DownstreamBandwidth"] = "1024000"

    status , errCode = qos.bwTest.configure (conf)
    if (status ~= "OK") then
        return "ERROR", errCode
    end            
    
    -- update bandwidth of all interfaces
    if (tonumber(conf["MeasureBandwidth"]) == 0)  then

        local query = "Enable=1"
        local status, errCode, rows = qos.iface.tableGet(query)
        if (status ~= "OK") then
            return "ERROR", errCode
        end

        for k,v in pairs(rows) do
            status, errCode = qos.iface.bwchange (v["InterfaceName"], 
                                                  cfg["UpstreamBandwidth"], 
                                                  cfg["DownstreamBandwidth"])
            if (status < 0) then
                return "ERROR", errCode
            end                 
        end        
    end

    db.save2()

	return "OK", "STATUS_OK"
end

--[[
--**************************************************************************
-- gui.qos.bwMeasurement.wanBwCfgGet
--
--
-- @return status
-- @return errCode
-- @return cfg={}
--         cfg["NetworkName"] = 
--         cfg["dynamicBwMeasure"] = 
--         cfg[i] = {}
--         cfg[i]["NetworkName"] = 
--         cfg[i]["dynamicBwMeasure"] = 
--         cfg[i]["upstreamBandwidth"] = 
--         cfg[i]["downstreamBandwidth"] = 
--         cfg[i]["InterfaceName"] =  <hidden>
-- 
]]--

function gui.qos.bwMeasurement.wanBwCfgGet ()
    require "teamf1lualib/ifDev"
    local wanBwTbl = {}
    local wanBwTmp = {}

    wanBwTbl.ifTbl = {}
    -- Get the interface selected for bandwidth measurement
    local status, errCode, bwMtrConf = qos.bwTest.confGet()
    if (status ~= "OK") then
        return status, errCode
    end        

    wanBwTbl["dynamicBwMeasure"] = bwMtrConf["MeasureBandwidth"]

	-- Get list of interfaces on which bandwidth limiting is enabled
    local status, errCode, rows = qos.iface.tableGet()
	if (rows ~= nil) then
		for k,v in pairs (rows) do
            local status, errCode, cfg = ifDev.cfgByNameGet(v["InterfaceName"])
            if ((cfg ~= nil) and 
                (gui.networking.zoneTypeToNetworkType (cfg["zoneType"]) == "WAN")) then
			    wanBwTmp = {}	
    			wanBwTmp["NetworkName"] = cfg["networkName"]
			    wanBwTmp["InterfaceName"] = v["InterfaceName"]
	            wanBwTmp["upstreamBandwidth"] = v["UpstreamBandwidth"]
                wanBwTmp["downstreamBandwidth"] = v["DownstreamBandwidth"]
                if (bwMtrConf["LogicalIfName"] == v["InterfaceName"]) then
                    wanBwTbl["NetworkName"] = cfg["networkName"]
	    		    wanBwTbl["InterfaceName"] = v["InterfaceName"]
	                wanBwTbl["upstreamBandwidth"] = v["UpstreamBandwidth"]
                    wanBwTbl["downstreamBandwidth"] = v["DownstreamBandwidth"]
                end                
                table.insert(wanBwTbl.ifTbl, wanBwTmp)
            end
		end 
	end

	return "OK", "STATUS_OK", wanBwTbl
end

--[[
--**************************************************************************
-- gui.qos.isWANIf
--
--
-- 
]]--

function gui.qos.isWANIf (ifName) 
    require "teamf1lualib/ifDev"
    local status, errCode, cfg = ifDev.cfgByNameGet(ifName)
    if (status ~= "OK") then
        return false
    end        

    if (gui.networking.zoneTypeToNetworkType(cfg["zoneType"]) == "WAN") then
        return true                
    end        

    return false
end

--[[
--**************************************************************************
-- @name gui.qos.prioQueue.get
--
-- @description This API returns the scheduling method configured for a switch port Queue
--
-- @return status
-- @return errCode
-- @return prioQueue -- Scheduling Method information
--         prioQueue["scheduleMode"]        = Scheduling Method (WRR (1) / SP (2) / Mixed (3))
--         prioQueue["lowQueueWeight"]      = Weight of the low priority Queue
--         prioQueue["mediumQueueWeight"]   = Weight of the medium priority Queue
--         prioQueue["highQueueWeight"]     = Weight of the high priority Queue
--         prioQueue["urgentQueueWeight"]   = Weight of the urgetn priority Queue
--
--@seealso gui.qos.prioQueue.set
--]]

function gui.qos.prioQueue.get ()
    require "teamf1lualib/swPort"
    local status
    local errCode
    local prioQueue = {}
    local cfg = {}

    status, errCode, cfg = swPort.queueScheduling.get ("PSE")
    if (status ~= "OK" or cfg == nil or cfg[1] == nil) then 
        return status, errCode
    end

    if (tonumber (cfg[1].scheduleMode) == swPort.scheduleMode.STRICT_PRIORITY) then
        prioQueue["scheduleMode"] = "2"
    elseif (tonumber (cfg[1].scheduleMode) == swPort.scheduleMode.WRR) then
        prioQueue["scheduleMode"] = "1"
    elseif (tonumber (cfg[1].scheduleMode) == swPort.scheduleMode.Q3_SP_Q2Q1Q0_WRR) then
        prioQueue["scheduleMode"] = "3"
    end
    
    prioQueue["lowQueueWeight"]     = cfg[1].queue1Weight
    prioQueue["mediumQueueWeight"]  = cfg[1].queue2Weight
    prioQueue["highQueueWeight"]    = cfg[1].queue3Weight
    prioQueue["urgentQueueWeight"]  = cfg[1].queue4Weight
    
    return status, errCode, prioQueue
end

--[[
--**************************************************************************
--@name gui.qos.prioQueue.set 
--
--@description This API configures the switch port Queue Scheduling Method.
--
--@param prioQueue -- Input configuration table with following values
--              scheduleMode - Scheduling Method
--              lowQueueWeight      - Weight of the low priority Queue
--              mediumQueueWeight   - Weight of the medium priority Queue
--              highQueueWeight     - Weight of the high priority Queue
--              urgentQueueWeight   - Weight of the urgetn priority Queue
--
--@return status OK on success, ERROR on Failure
--@retrun errCode Error String
--
--@seealso gui.qos.prioQueue.get
--]]

function gui.qos.prioQueue.set (prioQueue)
    require "teamf1lualib/swPort"
    local status
    local errCode
    local cfg = {}

    if (prioQueue == nil) then
        return "ERROR", "SWMGR_ERR_INVALID_ARG"
    end

    -- TOD0: Remaining validations on the queue weights

    if (tonumber(prioQueue["scheduleMode"]) == 2) then
        cfg["scheduleMode"] = swPort.scheduleMode.STRICT_PRIORITY
    elseif (tonumber(prioQueue["scheduleMode"]) == 1) then
        cfg["scheduleMode"] = swPort.scheduleMode.WRR
    elseif (tonumber(prioQueue["scheduleMode"]) == 3) then
        cfg["scheduleMode"] = swPort.scheduleMode.Q3_SP_Q2Q1Q0_WRR
    else
        return "ERROR", "SWMGR_ERR_INVALID_ARG"
    end

    cfg["queue1Weight"] = prioQueue["lowQueueWeight"] or "0"
    cfg["queue2Weight"] = prioQueue["mediumQueueWeight"] or "0"
    cfg["queue3Weight"] = prioQueue["highQueueWeight"] or "0"
    cfg["queue4Weight"] = prioQueue["urgentQueueWeight"] or "0"
    cfg["numQueues"]    = 4
    
    status, errCode = swPort.queueScheduling.set ("PSE", false, cfg)
    if (status ~= "OK") then
        gui.dprintf("prioQueue.set: Failed apply the priority Queue Information")
        return status, errCode
    end
    
    return "OK", "STATUS_OK"
end

--[[
--**************************************************************************
-- @name gui.qos.pauseFrame.get 
--
-- @description This API get the configured value of pause frames in the switch
--
--
-- @return status   "OK" on success, "ERROR" on Failure
-- @return errCode  Error String
-- @return row      output table 
--                  @field ["pauseFrameStatus"] 1-Enable 0-Disable
--
-- @seealso gui.qos.pauseFrame.set 
--]]

function gui.qos.pauseFrame.get ()
    local status 
    local errCode
    local pauseFrameStatus

    -- We are using pause frames for now in bcm switch only
    require "teamf1lualib/switch"
    status, errCode, pauseFrameStatus = switch.pauseFrame.get ("BCM")
    if (status ~= "OK" or pauseFrameStatus == nil) then
        gui.dprintf("pauseFrame.get: Failed to get the pause frame information");
        return status, errCode
    end

    local row = {}
    row["pauseFrameStatus"] = pauseFrameStatus

    return "OK", "STATUS_OK", row
end

--[[
--**************************************************************************
-- @name gui.qos.pauseFrame.set 
--
-- @description This API enable/disable the pause frames in the switch
-- 
-- @param  inputTable  output table 
--                     @field ["pauseFrameStatus"] 1-Enable 0-Disable
--
-- @return status   "OK" on success, "ERROR" on Failure
-- @return errCode  Error String
--
-- @seealso gui.qos.pauseFrame.set 
--]]

function gui.qos.pauseFrame.set (inputTable)
    local status 
    local errCode
    
    if (inputTable == nil) then 
        return "ERROR", "SWMGR_ERR_INVALID_ARG"
    end

    require "teamf1lualib/switch"
    status, errCode = switch.pauseFrame.set ("BCM", inputTable["pauseFrameStatus"])
    if (status ~= "OK") then
        gui.dprintf("pauseFrame.get: Failed to set the pause frame information");
        return status, errCode
    end

    return "OK", "STATUS_OK"
end
