-- @copyright Copyright (c) 2012, TeamF1, Inc. 

require "teamf1lualib/pppoe"

nimfConn.pppAuth = {
    NIMF_PPPOE_AUTO_NEG         =   0,
    NIMF_PPPOE_PLAIN_AUTH       =   1,
    NIMF_PPPOE_PAP_AUTH         =   2,
    NIMF_PPPOE_CHAP_AUTH        =   3,
    NIMF_PPPOE_MSCHAP_AUTH      =   4,
    NIMF_PPPOE_MSCHAPV2_AUTH    =   5,
    NIMF_PPPOE_AUTH_MAX         =   6,
}

nimfConn.pppoEMaxMtu = 1492

--[[
*******************************************************************************
-- @name nimfConn.ipv4PPPoECfgInit
--
-- @description The function initialises the static configuration.
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv4PPPoECfgInit(cur, conf)
    local cfg = {}

    if (cur ==  nil) then
        cfg["LogicalIfName"] = conf["LogicalIfName"]
    else
        cfg = cur        
    end                

    cfg["UserName"] = conf["UserName"]
    cfg["Password"] = conf["Password"]
    cfg["AccountName"]  = conf["AccountName"]
    cfg["DomainName"]   = conf["DomainName"]
    cfg["ServiceName"]   = conf["ServiceName"]
    cfg["GetIpFromIsp"] = conf["GetIpFromIsp"]
    cfg["GetDnsFromIsp"] = conf["GetDnsFromIsp"]
    cfg["PrimaryDns"] = conf["PrimaryDns"]
    cfg["SecondaryDns"] = conf["SecondaryDns"]
    cfg["Mtu"] = conf["Mtu"]
    cfg["IdleTimeOutFlag"] = conf["IdleDisconnect"]
    if (conf["IdleDisconnectTime"] ~= nil and tonumber(conf["IdleDisconnectTime"]) > 0) then
        cfg["IdleTimeOutValue"] = conf["IdleDisconnectTime"]
    end
    
    cfg["AuthOpt"] = tonumber(conf["AuthOpt"])

    return cfg
end

--[[
*******************************************************************************
-- @name nimfConn.ipv4PPPoEConfigure
--
-- @description This function conigures the PPPoE Connection
--
-- @param conf configuration table with the following fields
-- <ul>
-- <li><i> LogicalIfName</i>     Logical name of the network.
-- <li><i> AddressFamily</i>     network protocol of the connection
-- <li><i> Enable</i>            enable/disable connection
-- <li><i> ConnectionType</i>    type of the network connection. see nimf.method table   
-- <li><i> PrimaryDns</i>        Primary DNS server IP address of this network
-- <li><i> SecondaryDns</i>      Secondary DNS server IP address of this network
-- <li><i> IdleDisconnectTime</i> Idle Timeout in case of PPP connections   
-- <li><i> Username</i>          username for PPP authentication
-- <li><i> Password</i>          password for PPP authentication
-- <li><i> GetIpFromIsp</i>      1 if this network gets IP parameters from ISP
-- <li><i> GetDnsFromIsp</i>     1 if this network gets DNS from ISP
-- <li><i> AccountName</i>       account name to be used for the PPP connection
-- <li><i> DomainName</i>        domain name to be used for the PPP connection
-- <li><i> AuthOpt</i>           list of authentication protocol to be used for PPP
-- <li><i> Mtu</i>               MTU of the connection
-- </ul>
--
-- @return  OK or ERROR
-- @errCode error string.
--]]

function nimfConn.ipv4PPPoEConfigure(conf)
    local query = nil
    local record = {}
    local cfg = {}
    local errstr = ""
    local valid
    local rowid

    query = "LogicalIfName='" .. conf["LogicalIfName"].."'"
    nimf.dprintf ("Configuring PPPoE connection for " ..  conf["LogicalIfName"])

    record = db.getRowWhere("Pppoe", query, false)
    if (record == nil) then
        -- initialize configuration
        cfg = nimfConn.ipv4PPPoECfgInit(record, conf)
    if (cfg["Password"] ~= nil) then
        if (util.isAllMasked (cfg["Password"])) then
            cfg["Password"] = db.getAttribute ("Pppoe","_ROWID_",cfg["_ROWID_"],"Password")
        end
    end

        -- add configuration
        cfg = util.addPrefix(cfg, "Pppoe.")

        nimf.dprintf ("PPPoE connection " ..  util.tableToStringRec(cfg))
        valid, errstr, rowid = pppoe.config (cfg, nil, "add")
    else
        -- initialize configuration
        cfg = nimfConn.ipv4PPPoECfgInit(record, conf)

        local changed = nimf.hasTableChanged("Pppoe", cfg, cfg["_ROWID_"])
        if (not changed) then
            return "OK","STATUS_OK", false
        end            
        
        if (cfg["Password"] ~= nil) then
            if (util.isAllMasked (cfg["Password"])) then
                cfg["Password"] = db.getAttribute ("Pppoe","_ROWID_",cfg["_ROWID_"],"Password")
            end
        end

        --
        -- Set this to true to indicate configuration has changed
        --
        rowid = true

        -- update configuration
        cfg = util.addPrefix(cfg, "Pppoe.")
        valid, errstr = pppoe.config (cfg, cfg["Pppoe._ROWID_"], "edit")
    end                

    if (not valid) then
        nimf.dprintf("nimfConn.ipv4PPPoEConfigure: " ..
                     "IPv4 PPPoE Connection configuration failed")
        return "ERROR", errstr
    end
            
    return "OK", "STATUS_OK", rowid
end

--[[
*******************************************************************************
-- @name  nimfConn.ipv4PPPoEDeconfigure
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv4PPPoEDeconfigure(conf)
    local query = nil
    local errstr = ""
    local valid

    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "'"

    nimf.dprintf ("Deleting IPv4 PPPoE connection for " ..  conf["LogicalIfName"])

    valid, errstr = db.deleteRowWhere("Pppoe", query)
    if (not valid) then
        return "ERROR", errstr
    end
            
    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- nimfConn.ipv4PPPoEConfValidate
--
-- @description This function validates parameters for IPv4 PPPoE configuration
--
-- @param conf configuration table with the following fields
-- <ul>
-- <li><i> LogicalIfName</i>     Logical name of the network.
-- <li><i> AddressFamily</i>     network protocol of the connection
-- <li><i> Enable</i>            enable/disable connection
-- <li><i> ConnectionType</i>    type of the network connection. see nimf.method table   
-- <li><i> PrimaryDns</i>        Primary DNS server IP address of this network
-- <li><i> SecondaryDns</i>      Secondary DNS server IP address of this network
-- <li><i> IdleDisconnectTime</i> Idle Timeout in case of PPP connections   
-- <li><i> Username</i>          username for PPP authentication
-- <li><i> Password</i>          password for PPP authentication
-- <li><i> GetIpFromIsp</i>      1 if this network gets IP parameters from ISP
-- <li><i> GetDnsFromIsp</i>     1 if this network gets DNS from ISP
-- <li><i> AccountName</i>       account name to be used for the PPP connection
-- <li><i> DomainName</i>        domain name to be used for the PPP connection
-- <li><i> AuthOpt</i>           list of authentication protocol to be used for PPP
-- <li><i> Mtu</i>               MTU of the connection
-- </ul>
--
-- @return  OK or ERROR
-- @errCode error string.
--]]

function nimfConn.ipv4PPPoEConfValidate(conf)
    local ipAddr=nil

    if ((conf["UserName"] == nil) or (conf["Password"] == nil))  then
        return "ERROR", "NIMF_ERR_INVALID_PPP_CRED"
    end        

    -- check if primary DNS is valid
    ipAddr = conf["PrimaryDns"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv4AddrCheck(ipAddr) == nil)) then
        return "ERROR", "NIMF_ERR_INVALID_PRIMARY_DNS"
    end        

    -- check if secondary DNS is valid
    ipAddr = conf["SecondaryDns"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv4AddrCheck(ipAddr) == nil)) then
        return "ERROR", "NIMF_ERR_INVALID_SECONDARY_DNS"
    end        

    -- check idle timeout
    local idleTimeout = conf["IdleDisconnectTime"]
    if ((idleTimeout ~= nil) and (tonumber(idleTimeout) < 0)) then
        return "ERROR", "NIMF_ERR_INVALID_IDLE_TIMEOUT"
    end        

    -- check authentication options
    local authOpt = conf["AuthOpt"]
    if ((authOpt ~= nil) and 
        ((tonumber(authOpt) < nimfConn.pppAuth.NIMF_PPPOE_AUTO_NEG) and 
         (tonumber(authOpt) >= nimfConn.pppAuth.NIMF_PPPOE_AUTH_MAX))) then
        return "ERROR", "NIMF_ERR_INVALID_IDLE_TIMEOUT"
    end        

    -- check MTU
    local mtu = conf["Mtu"]
    if ((mtu ~= nil) and (tonumber(mtu) > nimfConn.pppoEMaxMtu)) then
        return "ERROR", "NIMF_ERR_INVALID_MTU"
    end        

    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- @name nimfConn.pppoeConfGet
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.pppoeConfGet(conf)
    local query = nil
    local record = {}
    local cfg = {}

    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "'"
    record = db.getRowWhere("Pppoe", query, false)
    if (record ~= nil) then
        cfg["LogicalIfName"] = record["LogicalIfName"]
        cfg["AddressFamily"] = record["AddressFamily"]
        cfg["IspName"] = record["IspName"]
        cfg["UserName"] = record["UserName"]
        cfg["Password"] = util.mask (record["Password"])
        cfg["AccountName"] = record["AccountName"]
        cfg["ServiceName"] = record["ServiceName"]
        cfg["DomainName"] = record["DomainName"]
        cfg["GetIpFromIsp"] = record["GetIpFromIsp"]
        cfg["GetDnsFromIsp"] = record["GetDnsFromIsp"]
        cfg["StaticIp"] = record["StaticIp"]
        cfg["NetMask"] = record["NetMask"]
        cfg["IdleDisconnect"] = record["IdleTimeOutFlag"]
        cfg["IdleDisconnectTime"] = record["IdleTimeOutValue"]
        cfg["ProfileName"] = record["ProfileName"]
        cfg["AuthOpt"] = record["AuthOpt"]
        cfg["Mtu"] = record["Mtu"]
        cfg["PrimaryDns"] = record["PrimaryDns"]
        cfg["SecondaryDns"] = record["SecondaryDns"]
    end        

    return "OK", "STATUS_OK", cfg
end

--[[
*******************************************************************************
-- @name nimfConn.ipv4PPPoEConfGet
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv4PPPoEConfGet(conf)
    return nimfConn.pppoeConfGet(conf)
end


