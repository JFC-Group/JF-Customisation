
nscanTr = {}

require "nscanLib"

function nscanTr.leaseTimeGet (input)
    local status = "0"
    local value = "1"
    local param = input["param"]
    local rowId = nil
    local instanceMap =  tr69Glue.instanceMapLoad()
    local query = nil

    -- get rowid
    rowId = instanceMap[param]
    if (rowId == nil) then
        return status, value
    end

    -- get row
    query = "_ROWID_='" ..rowId .. "'"
    local lanhost = db.getRowWhere (input["table"], query, false);
    if (lanhost == nil) then
        return status, value
    end        

    value = nscanLib.dhcpLeaseTimeGet(lanhost.LeaseEnds)

    return status, value
end
