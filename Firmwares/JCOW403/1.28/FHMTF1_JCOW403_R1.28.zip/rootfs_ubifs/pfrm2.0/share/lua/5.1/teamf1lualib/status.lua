-- gui.status.lua - lua wrapper calls for status t

-- Copyright (c) 2017, TeamF1 Networks Pvt. Ltd. 
-- [Subsidiary of D-Link (India) Ltd]

--
-- modification history
-- --------------------
-- 01g, 30aug17, ar changes for SPR#62213
-- 01f, 10may17, aks changes for SPR#56429
-- 01e, 03jan17, MSV Changes for IPv6 CAS Support
-- 01d, 27aug13, ash Changes for SPR#39683.
-- 01c, 10aug13, ash Changes for bandwidth monitoring.
-- 01b, 18June13, ash Changes for displaying loggin user and firmware.
-- 01a, 12Mar13, sen dervied from reference solution. for RIL.
--

---------------------------------------------------------------------------------
-- The routines in this lua wrapper are called by htm(user interface) layer to
-- get the information to display System Information, CPU Utilization and
-- Memory Utilization
---------------------------------------------------------------------------------
gui.status= {}

--[[ Router Status ]]--
-- System Summary
gui.status.sysInfo = {}
gui.status.cpuInfo = {}
gui.status.memInfo = {}
gui.status.flashInfo = {}
gui.status.hardwareInfo = {}

 -- Network Information
 gui.status.networkInfo = {}
--View Logs
gui.status.logging = {}
--gui.status.logging.policy = {}
-- Device Status
gui.status.deviceStatus = {}

--[[ Network Status ]]--
--Statistics
gui.status.statistics = {}
-- wireless
gui.status.statistics.wifi = {}
-- ethernet
gui.status.statistics.port = {}
-- network
gui.status.statistics.network = {}
--Available LAN Hosts
gui.status.availableLanHosts = {}

-- DHCP Leased clients
gui.status.dhcpLeasedClients = {}

-- DHCP Active Leased Clients
gui.status.dhcpActiveLeasedClients = {}

-- DHCPv6 Leased clients
gui.status.dhcpv6LeasedClients = {}

--open ports
gui.status.openPorts = {}
gui.status.openPorts.upnp = {}
-- routing information
gui.status.routing = {}
gui.status.routing.ipv4 = {}
gui.status.routing.ipv6 = {}

 --account status
gui.status.account = {}

 --maptPort status
gui.status.maptPorts = {}

MAX_TRUNCATE_LENGTH = 10
lanLogicalIfName = "IF2"

-------------------------------------------------------------------------------
-- @name gui.status.sysInfo.get
--
-- @description This function gets information about the system
--
-- @return
--
function gui.status.sysInfo.get ()

    -- require
 require "teamf1lualib/platform"


 -- locals
 local sysInfoTbl = {} --local table containing the detail of the system info

 -- get the system information from platform
 sysInfoTbl = platform.sysInfoGet()
 if (sysInfoTbl == nil) then
        return "OK", "DB_ERROR_TRY_AGAIN"
 end
 
 sysInfoTbl["serialNumber"] = "N.A"
 local serialFilep = io.open("/tmp/deviceSerial", "r")
 if (serialFilep ~= nil) then
     serial = serialFilep:read("*all")
	 sysInfoTbl["serialNumber"] = serial
 end


 -- return
 return sysInfoTbl

end

-------------------------------------------------------------------------------
-- @name gui.status.cpuInfo.get
--
-- @description This function gets cpu utilization information by processes
-- running in device.
--
-- @return
--
function gui.status.cpuInfo.get ()

   -- require
 require "teamf1lualib/cpuMemUsage"

 -- locals
 local cpuInfoTbl = {} --local table containing details of the system info
 -- get the cpu information
 cpuInfoTbl = cpuMemUsage.cpuUtilInfoGet()
    if (cpuInfoTbl == nil) then
        return "OK", "DB_ERROR_TRY_AGAIN"
 end

 --return
 return "OK", "STATUS_OK", cpuInfoTbl
end

-------------------------------------------------------------------------------
-- @name gui.status.memInfo.get
--
-- @description This function gets memory utilization by processes running in
-- device.
--
-- @return
--
function gui.status.memInfo.get ()

    -- require
 require "teamf1lualib/cpuMemUsage"

 -- locals
 local memInfoTbl = {} --local table containing the details about the memory

 -- get the memory information
 memInfoTbl = cpuMemUsage.cpuMemInfoGet()
 if (memInfoTbl == nil) then
  return "ERROR", "DB_ERROR_TRY_AGAIN"
 end

 --return
 return "OK", "STATUS_OK", memInfoTbl
end

-------------------------------------------------------------------------------
-- @name gui.status.flashInfo.get
--
-- @description This function gets memory utilization by processes running in
-- device.
--
-- @return
--
function gui.status.flashInfo.get ()

    -- require
 require "teamf1lualib/cpuMemUsage"

 -- locals
 local flashInfoTbl = {} --local table containing the details about the flash memory

 -- get the memory information
 flashInfoTbl = cpuMemUsage.configInfoGet()
 if (flashInfoTbl == nil) then
  return "ERROR", "DB_ERROR_TRY_AGAIN"
 end

 --return
 return "OK", "STATUS_OK", flashInfoTbl
end

-------------------------------------------------------------------------------
-- @name gui.status.hardwareInfo.get
--
-- @description This function gets informations about the hardware details.
--
-- @return
--
function gui.status.hardwareInfo.get ()

 -- locals
 local hardwareTbl = {} --local table containing the details about the hardware
    local envTbl = {} --local table containing the details about the environment table
    local wifiMac --local variable containing the mac address of wifi0

 -- get the environment information
 envTbl = db.getTable ("environment", false);
    if (envTbl == nil) then
  return "ERROR", "DB_ERROR_TRY_AGAIN"
 end

    for i,v in ipairs (envTbl) do

        -- get serial number
        if(v.name == "serial#") then
            hardwareTbl["serialNumber"] = v.value;
        end

        -- get model name
        if (v.name == "model_name") then
            hardwareTbl["modelName"] = v.value;
        end

        --get manufacturer name
        if (v.name == "manufacturer") then
            hardwareTbl["manufacturer"] = v.value;
        end

        -- get LAN MAC
        if (v.name == "ethaddr") then
            hardwareTbl["lanMac"] = v.value;
        end

        -- get WAN MAC
        if (v.name == "eth1addr") then
            hardwareTbl["wanMac"] = v.value;
        end

        -- get ACCESS MAC
        if (v.name == "eth2addr") then
            hardwareTbl["accessMac"] = v.value;
        end

        -- get WI-FI MAC
       -- if (v.name == "wifiaddr") then
       -- hardwareTbl["wifiMac"] = v.value;
      -- end
    end
    if (UNIT_NAME == "HA01") then
        wifiMac = db.getAttribute("dot11Interface", "interfaceName", "vap0", "macAddress" ) -- vap0 has the same mac address as wifi0
        if(wifiMac == nil) then
            -- require
            require "teamf1lualib/dot11"

            wifiMac = dot11.wifiMacGet()
        end
        hardwareTbl["wifiMac"] = wifiMac
        if (hardwareTbl == nil) then
            return "ERROR", "DB_ERROR_TRY_AGAIN"
        end
    end

 --return
 return "OK", "STATUS_OK", hardwareTbl
end

--------------------------------------------------------------------------------
-- @name gui.status.networkInfo.get
--
-- @description This function gets network information.
--
-- @return
--
function gui.status.networkInfo.get()

    --require
    require "teamf1lualib/networking"
    require "teamf1lualib/security"
    --require "teamf1lualib/wireless"

    --locals
    local errorCode,statusMsg
    local errMsg,statusCode
    local networkInfoTbl = {}
    local radioInfoTbl = {}
    local accessTable = {}
    local nilTable = {}
    local networkLanInfoTbl = {}
    local networkWanInfoTbl = {}
    local errorCode,statusMsg,networkLanInfoTbl = gui.networking.network.statusGet("Local")
    local errMsg,statusCode,networkWanInfoTbl = gui.networking.network.statusGet("Internet")
    if(networkLanInfoTbl ~= nil) then
        if(networkLanInfoTbl.ipv4 == nil) then
            networkLanInfoTbl.ipv4.addrs[1]["StaticIp"] = "0.0.0.0"
            networkLanInfoTbl.ipv4.addrs[1]["NetMask"] = "0.0.0.0"
            networkLanInfoTbl.ipv4["dhcpServer"] = "N/A"
        end
        if(networkLanInfoTbl == nil) then
            networkLanInfoTbl.ipv6["ipv6address"] = "00::00"
            networkLanInfoTbl.ipv6["dhcpv6Server"] = "N/A"
        end
        networkInfoTbl.networkLanInfoTbl = networkLanInfoTbl
    else
		networkLanInfoTbl = {}
		networkLanInfoTbl.ipv4 = {}
		networkLanInfoTbl.ipv6 = {}
		networkLanInfoTbl.ipv4.addrs = {}
		networkLanInfoTbl.ipv4.addrs[1] = {}
        networkLanInfoTbl["mac"] = "00:00:00:00:00"
        networkLanInfoTbl.ipv4.addrs[1]["StaticIp"] = "0.0.0.0"
        networkLanInfoTbl.ipv4.addrs[1]["NetMask"] = "0.0.0.0"
        networkLanInfoTbl.ipv4["dhcpServer"] = "N/A"
		networkLanInfoTbl.ipv4["ConnectionTime"] = "N/A"
        networkLanInfoTbl.ipv6["ipv6address"] = nil
        networkLanInfoTbl.ipv6["dhcpv6Server"] = "N/A"
		networkInfoTbl.networkLanInfoTbl = networkLanInfoTbl
    end
    if(networkWanInfoTbl ~= nil)then
        if(networkWanInfoTbl.ipv4 ~= nil) then
            if(networkWanInfoTbl.ipv4.addrs[1] == nil) then
                networkWanInfoTbl.ipv4.addrs[1]["StaticIp"] = "0.0.0.0"
                networkWanInfoTbl.ipv4.addrs[1]["NetMask"] = "0.0.0.0"
                networkWanInfoTbl.ipv4.addrs[1]["Gateway"] = "0.0.0.0"
            end

            local natModeChk = {}
            --check routing mode and set value accordingly
            errMsg, statusCode, natModeChk = gui.security.routingMode.get()
            if (natModeChk ~= nil) then
                if(natModeChk.natSetting == "1") then
                    networkWanInfoTbl.ipv4["nat"] = "Enabled"
                else
                    networkWanInfoTbl.ipv4["nat"] = "Disabled"
                end
            else
                networkWanInfoTbl.ipv4["nat"] = "N/A"
            end
        else
            networkWanInfoTbl.ipv4.addrs[1]["StaticIp"] = "0.0.0.0"
            networkWanInfoTbl.ipv4.addrs[1]["NetMask"] = "0.0.0.0"
            networkWanInfoTbl.ipv4.addrs[1]["Gateway"] = "0.0.0.0"
            networkWanInfoTbl.ipv4["ConnectionTime"] = "N/A"
            networkWanInfoTbl.ipv4["ConnectionType"] = "N/A"
            networkWanInfoTbl.ipv4["ConnectionStatus"] = "N/A"
            networkWanInfoTbl.ipv4["PrimaryDns"] = "0.0.0.0"
            networkWanInfoTbl.ipv4["SecondaryDns"] = "0.0.0.0"
            networkWanInfoTbl.ipv4["nat"] = "N/A"
        end
        if(networkWanInfoTbl.ipv6 == nil) then
            networkWanInfoTbl.ipv6["ipv6address"] = "00::00"
            networkWanInfoTbl.ipv6["connectiontimeipv6"] = "N/A"
            networkWanInfoTbl.ipv6["ipv6connectionType"] = "N/A"
            networkWanInfoTbl.ipv6["ipv6connectionstatus"] = "N/A"
            networkWanInfoTbl.ipv6["ipv6connectiongateway"] = "00::00"
            networkWanInfoTbl.ipv6["ipv6connectionprimarydnsserver"] "00::00"
        end
        networkInfoTbl.networkWanInfoTbl = networkWanInfoTbl
    else
		networkWanInfoTbl = {}
		networkWanInfoTbl.ipv4 = {}
		networkWanInfoTbl.ipv4.addrs = {}
		networkWanInfoTbl.ipv4.addrs[1] = {}
		networkWanInfoTbl.ipv6 = {}
        networkWanInfoTbl["mac"] = "00::00::00::00::00"
        networkWanInfoTbl.ipv4["ConnectionTime"] = "N/A"
        networkWanInfoTbl.ipv4["ConnectionType"] = "N/A"
        networkWanInfoTbl.ipv4["ConnectionStatus"] = "N/A"
        networkWanInfoTbl.ipv4.addrs[1]["StaticIp"] = "0.0.0.0"
        networkWanInfoTbl.ipv4.addrs[1]["NetMask"] = "0.0.0.0"
        networkWanInfoTbl.ipv4.addrs[1]["Gateway"] = "0.0.0.0"
        networkWanInfoTbl.ipv4["PrimaryDns"] = "0.0.0.0"
        networkWanInfoTbl.ipv4["SecondaryDns"] = "0.0.0.0"
        networkWanInfoTbl.ipv4["nat"] = "N/A"
        networkWanInfoTbl.ipv6["ipv6address"] = nil
        networkWanInfoTbl.ipv6["connectiontimeipv6"] = "N/A"
        networkWanInfoTbl.ipv6["ipv6connectionType"] = "N/A"
        networkWanInfoTbl.ipv6["ipv6connectionstatus"] = "N/A"
        networkWanInfoTbl.ipv6["ipv6connectiongateway"] = "00::00"
        networkWanInfoTbl.ipv6["ipv6connectionprimarydnsserver"] = "00::00"
		networkInfoTbl.networkWanInfoTbl = networkWanInfoTbl
    end

    local linkLAN = 0
    local kvalue =0
    if(networkLanInfoTbl.ipv6["ipv6address"] ~= nil ) then 
        for k,v in pairs (networkLanInfoTbl.ipv6["ipv6address"]) do              
            local i = string.find(v,"fe80")                                
            if( i == 1 ) then  
                linkLAN =1
            end
            kvalue = k
        end
        
    if( linkLAN == 0 ) then
        local link = "ifconfig bdg2 |grep -i inet6 |grep Link | awk '{print($3)}' > /tmp/linklocal"
        os.execute(link)
        local fp4 = io.open("/tmp/linklocal")
        if (fp4 ~= nil ) then 
             networkLanInfoTbl.ipv6["ipv6address"][kvalue+1] =  fp4:read("*line")                                   
        end                                                                                   
        fp4:close()
    end
    end
    local linkWAN = 0
    local kvalue1 = 0
    if(networkWanInfoTbl.ipv6["ipv6address"] ~= nil ) then 
        for k,v in pairs (networkWanInfoTbl.ipv6["ipv6address"]) do              
            local  i = string.find(v,"fe80")
            if( i == 1 ) then
               linkWAN = 1
            end  
        kvalue1 = k
        end
    if (linkWAN == 0 ) then
        local link = "ifconfig bdg1 |grep -i inet6 |grep Link | awk '{print($3)}' > /tmp/linklocal"
        os.execute(link)
        local fp4 = io.open("/tmp/linklocal")
        if (fp4 ~= nil ) then 
            networkWanInfoTbl.ipv6["ipv6address"][kvalue1+1] =  fp4:read("*line")                                   
        end                                                                                   
        fp4:close()
    end
    end
    --errorCode,statusMsg,radioInfoTbl = gui.wireless.radio.get()
    if(radioInfoTbl ~= nil)then
        networkInfoTbl.radioInfoTbl = radioInfoTbl
    else
        networkInfoTbl.radioInfoTbl = nilTable
    end
    --errMsg,statusCode,accessTable = gui.wireless.apProfileInfo.get ()
    if(accessTable ~= nil)then
        networkInfoTbl.accessTable = accessTable
    else
        networkInfoTbl.accessTable = nilTable
    end

    -- return
    return networkInfoTbl
end

-------------------------------------------------------------------------------
-- @name gui.status.logging.view
--
-- @description This function gets device activity/event logs.
-- device.
--
-- @return
--
function gui.status.logging.view ()

 -- require
 require "teamf1lualib/logging"

 -- locals
 local logs = {}
    local errMsg = nil
    local statusMsg = nil

    db.connect("/tmp/logging.db")

 -- get the logs from logging
 logs = logging.loggingView()
 if (logs == nil) then
  return "ERROR", "DB_ERROR_TRY_AGAIN"
 end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

    db.connect("/tmp/system.db")
 --return
 return errMsg, statusMsg, logs
end

-------------------------------------------------------------------------------

-- @name gui.status.logging.show
--
-- @description This function gets logs on the basis of particular facility and
-- severity.
--
-- @return
--
--[[function gui.status.logging.show(facilityId,severityLevel)

 -- require
 require "teamf1lualib/logging"

 -- locals
 local logs = ""
    local errMsg = nil
    local statusMsg = nil

    db.connect("/tmp/logging.db")
 -- get the logs from logging
 logs = logging.loggingShow(facilityId,severityLevel)
 if (logs == "") then
  return "ERROR", "DB_ERROR_TRY_AGAIN"
 end
    errMsg = "OK"
    statusMsg = "STATUS_OK"

 --return
 return errMsg, statusMsg, logs
end]]--



--------------------------------------------------------------------------------
-- @name gui.status.logging.clear
--
-- @description This function deletes the logs in device.
-- device.
--
-- @return
--
function gui.status.logging.clear ()

 -- require
 require "teamf1lualib/logging"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

 -- locals
 local status, err

    db.connect("/tmp/logging.db")

 -- delete the logs from device
 status, err = logging.loggingClear()

 --return
 return status, err

end

-------------------------------------------------------------------------------
-- @name gui.status.logging.refresh
--
-- @description This function will provide the more latest logs in device.
-- device.
--
-- @return
--
function gui.status.logging.refresh ()

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

 --return
 return "OK", "STATUS_OK"
end


-------------------------------------------------------------------------------
-- @name gui.status.statistics.wifi.get
--
-- @description This function gets the wifi statisitcs such as Network Name,
-- Packets Recieved, Packets transmitted, Bytes received, Bytes transmitted
-- by device.
--
-- @return
--
function gui.status.statistics.wifi.get ()

 -- require
 require "teamf1lualib/ifDev"

 -- locals
 local wifiTbl = {}
    local localTbl = {}
    local errMsg, status
    local total = {}
    total["rx_packets"] = 0
    total["rx_errors"] = 0
    total["rx_dropped"] = 0
    total["tx_packets"] = 0
    total["tx_errors"] = 0
    total["tx_dropped"] = 0
    total["rx_bytes"] = 0
    total["tx_bytes"] = 0
    total["multicast"] = 0

 -- get the wifi statistics
 errMsg, status, wifiTbl = ifDev.wifiStatsGet()
 if (wifiTbl == nil) then
  return "ERROR", "DB_ERROR_TRY_AGAIN", localTbl
 end

    for i,v in pairs (wifiTbl.statsTbl) do
        total["rx_packets"] = total["rx_packets"] + v["rx_packets"]
        total["rx_errors"] = total["rx_errors"] + v["rx_errors"]
        total["rx_dropped"] = total["rx_dropped"] + v["rx_dropped"]
        total["tx_packets"] = total["tx_packets"] + v["tx_packets"]
        total["tx_errors"] = total["tx_errors"] + v["tx_errors"]
        total["tx_dropped"] = total["tx_dropped"] + v["tx_dropped"]
        total["rx_bytes"] = total["rx_bytes"] + v["rx_bytes"]
        total["tx_bytes"] = total["tx_bytes"] + v["tx_bytes"]
        total["multicast"] = total["multicast"] + v["multicast"]
    end

    wifiTbl.total = total
    errMsg = "OK"
    status = ""

 --return
 return errMsg, status, wifiTbl

end

-------------------------------------------------------------------------------
-- @name gui.status.statistics.wired.get
--
-- @description This function gets the wired (ethernet) statisitcs such as
-- Network Name, Packets Recieved, Packets transmitted, Bytes received,
-- Bytes transmitted by device.
--
-- @return
--
function gui.status.statistics.port.get ()

    -- include
    require "teamf1lualib/ifDev"

 -- locals
 local wiredTbl = {}
 local localTbl = {}
    local errMsg, status

 -- get the ethernet statistics
 errMsg, status, wiredTbl = ifDev.wiredStatsGet()
 if (wiredTbl == nil) then
  return "ERROR", "DB_ERROR_TRY_AGAIN", localTbl
 end

    errMsg = "OK"
    status = ""

 --return
 return errMsg, status, wiredTbl

end

-------------------------------------------------------------------------------
-- @name gui.status.statistics.network.get
--
-- @description This function gets the network statisitcs such as Network Name,
-- Packets Recieved, Packets transmitted, Bytes received, Bytes transmitted
-- by device.
--
-- @return
--
function gui.status.statistics.network.get ()

    -- include
    require "teamf1lualib/ifDev"

 -- locals
 local networkStatsTbl = {}
    local localTbl = {}
    local errMsg, status

 -- get the wifi statistics
 errMsg, status, networkStatsTbl = ifDev.networkStatsGet()
 if (networkStatsTbl == nil) then
  return "ERROR", "DB_ERROR_TRY_AGAIN", localTbl
 end

    errMsg = "OK"
    status = ""

 --return
 return errMsg, status, networkStatsTbl

end

-------------------------------------------------------------------------------
-- @name gui.status.availableLanHosts.get
--
-- @description This function gets the list of available lan hosts connected to
-- deivce.
--
-- @return
--
function gui.status.availableLanHosts.get ()

 -- require
 require "teamf1lualib/nscan"

 -- locals gui.firmware.manual_upgrade(inputTable)

 local lanhostTbl = {}
    local errMsg = nil
    local statusMsg = nil
    local nilTable = {}

 -- get the available lan hosts
 status, errCode, lanhostTbl = nscan.hostsGet()

 if (lanhostTbl == nil) then
  return "ERROR", "DB_ERROR_TRY_AGAIN",nilTable
 end

    for k,v in pairs(lanhostTbl) do
        v.networkName = network.nameGet(v.LogicalIfName)
    end

 errMsg = "OK"
    statusMsg = "STATUS_OK"

 --return
 return errMsg, statusMsg, lanhostTbl

end

-------------------------------------------------------------------------------
-- @name gui.status.dhcpLeasedClients.get()
--
-- @description This function gets the list dhcp leased clients of the
-- deivce.
--
-- @return
function gui.status.dhcpLeasedClients.get()

    --require
    require"teamf1lualib/dhcp"

    --locals
    local dhcpClientTbl = {}
    local networkNameTbl = {}
    local nilTable = {}
    local errorCode,statusMsg

    dhcpClientTbl = db.getTable("DhcpLeasedClients",false)
    if (dhcpClientTbl == nil) then
  return "ERROR","DB_ERROR_TRY_AGAIN",nilTable
 end
    errorCode = "OK"
    statusMsg = "STATUS_OK"

    --return
    return errorCode,statusMsg,dhcpClientTbl
end

-------------------------------------------------------------------------------
-- @name gui.status.dhcpActiveLeasedClients.get()
--
-- @description This function gets the list dhcp leased clients of the
-- deivce.
--
-- @return
function gui.status.dhcpActiveLeasedClients.get()

    --locals
    local dhcpClientTbl = {}
    local activeTbl = {}
    local nilTable = {}
    local count = 1
    local errorCode,statusMsg

    dhcpClientTbl = db.getTable("lanhosts",false)
    if (dhcpClientTbl == nil) then
        return "ERROR","DB_ERROR_TRY_AGAIN",nilTable
    end
    errorCode = "OK"
    statusMsg = "STATUS_OK"

    for p,q in pairs (dhcpClientTbl) do
        activeTbl[count] = {}
        if ((q.AddressSource ~= nil) and (q.AddressSource ~= "IPv6") and (q.IPAddress ~= "")) then
            activeTbl[count]["IPAddr"] = q.IPAddress
            activeTbl[count]["MacAddr"] = q.MACAddress
            if ((q.IPv6Address ~= nil) and (q.IPv6Address ~= "")) then
                activeTbl[count]["IPv6Addr"] = q.IPv6Address
            else
                activeTbl[count]["IPv6Addr"] = "Not Available"
            end
        else
            if ((q.IPv6Address ~= nil) and (q.IPv6Address ~= "")) then
                activeTbl[count]["MacAddr"] = q.MACAddress
                activeTbl[count]["IPv6Addr"] = q.IPv6Address
                activeTbl[count]["IPAddr"] = "Not Available"
            end
        end
        count = count + 1
    end

    --return
    return errorCode,statusMsg,activeTbl
end

-------------------------------------------------------------------------------
-- @name gui.status.dhcpv6LeasedClients.get()
--
-- @description This function gets the list dhcpv6 leased clients of the
-- deivce.
--
-- @return
function gui.status.dhcpv6LeasedClients.get()

    --locals
    local dhcpv6ClientTbl = {}
    local networkNameTbl = {}
    local page = {}
    local nilTable = {}
    local errorCode,statusMsg
    page.dhcpv6ClientTbl = {}

    dhcpv6ClientTbl = db.getTable("Dhcpv6LeasedClients",false)
    if (dhcpv6ClientTbl == nil) then
        return "ERROR","DB_ERROR_TRY_AGAIN",nilTable
    end
    errorCode = "OK"
    statusMsg = "STATUS_OK"

    -- iterate over all the entries 
    for k,v in pairs (dhcpv6ClientTbl) do
        page.dhcpv6ClientTbl[k] = {}
        page.dhcpv6ClientTbl[k].DUID = v.DUID
        if (v.Statefull == "1") then
            page.dhcpv6ClientTbl[k].AddressType = "Statefull"
            page.dhcpv6ClientTbl[k].Addr = v.IPAddr
        else
            if (v.PrefixDelegation == "1") then
                page.dhcpv6ClientTbl[k].AddressType = "Stateless-PD"
                page.dhcpv6ClientTbl[k].Addr = v.IPAddr
            else
                page.dhcpv6ClientTbl[k].AddressType = "Stateless"
                page.dhcpv6ClientTbl[k].Addr = ""
            end
        end        
    end

    --return
    return errorCode,statusMsg,page
end

-------------------------------------------------------------------------------
-- @name gui.status.openPorts.get
--
-- @description This function gets the list of openports in deivce.
--
-- @return
--gui.firmware.manual_upgrade(inputTable)

function gui.status.openPorts.get ()

 -- require
 require "teamf1lualib/firewall"

 -- locals
    local page = {}
    local portTrigTbl = {}
    local errMsg = nil
    local statusMsg = nil
 page.openPortsTbl = {}

 -- get the open ports in system
 portTrigTbl = firewall.openPortsGet()
 if (portTrigTbl == nil) then
     return "ERROR", "DB_ERROR_TRY_AGAIN"
 end

    -- iterate over all the entries in stats file
    for k,v in pairs (portTrigTbl) do
        page.openPortsTbl[k] = {}
        page.openPortsTbl[k].networkName = v.networkName
        page.openPortsTbl[k].ipAddr = v.ipAddr
        page.openPortsTbl[k].openPortsRange = v.openPortsRange
        page.openPortsTbl[k].timeRemaining = v.timeRemaining
    end

 errMsg = "OK"
    statusMsg = "STATUS_OK"

 --return
 return errMsg, statusMsg, page

end


-------------------------------------------------------------------------------
-- @name gui.status.openPorts.upnp.get
--
-- @description This function gets the list of upnp openports in deivce.
--
-- @return
--
function gui.status.openPorts.upnp.get ()

 -- require
 require "teamf1lualib/upnp"

 -- locals
 local upnpTbl = {}
    local localTbl = {}
    local errMsg, status


 -- get the upnp open ports info
 errMsg, status, upnpTbl = upnp.openPortsGet()
 if (upnpTbl == nil) then
  return "ERROR", "DB_ERROR_TRY_AGAIN", localTbl
 end

    errMsg = "OK"
    status = ""

 --return
 return errMsg, status, upnpTbl

end

-------------------------------------------------------------------------------
-- @name gui.status.routing.ipv4.get
--
-- @description This function gets ipv4 routing table in device.
--
-- @return
--
function gui.status.routing.ipv4.get ()

 -- require
 require "teamf1lualib/iproute"

 -- locals
 local ipv4routeTbl = {} -- local table containing ipv4 routing information

 -- we only write the routing information into a file
 ipv4routeTbl = iproute.ipv4RouteGet()

    -- get the detail of the file location from the environment table
 -- ROUTE_FILE_NAME as the macro

    return "OK", "STATUS_OK", ipv4routeTbl

end

-------------------------------------------------------------------------------
-- @name gui.status.routing.ipv6.get
--
-- @description This function gets ipv6 routing table in device.
--
-- @return
--
function gui.status.routing.ipv6.get ()

 -- require
 require "teamf1lualib/iproute"

 -- locals
 local ipv6routeTbl = {} -- local table containing ipv6 routing information

 -- we only write the routing information into a file
 ipv6routeTbl = iproute.ipv6RouteGet()

    -- get the detail of the file location from the environment table
 -- ROUTE6_FILE_NAME as macro

    return "OK", "STATUS_OK", ipv6routeTbl
end

-------------------------------------------------------------------------------
-- @name gui.status.deviceStatus.get()
--
-- @description This function gets the deviceStatus in the router.
--
-- @return
--
function gui.status.deviceStatus.get()

    local statusTbl = {}
    statusTbl.system = {}
    statusTbl.networkInfoTbl = {}
    statusTbl.wirelessInfo = {}
    local errorCode,statusMsg, linkStatus

    --getting system info
    statusTbl.system = gui.status.sysInfo.get()

    -- getting networkinfo
    statusTbl.networkInfoTbl = gui.status.networkInfo.get()
    if (statusTbl.networkInfoTbl.networkLanInfoTbl == nil) then
        statusTbl.networkInfoTbl.networkLanInfoTbl.ipv4 = {}
        statusTbl.networkInfoTbl.networkLanInfoTbl.ipv4.addrs = {}
        statusTbl.networkInfoTbl.networkLanInfoTbl.ipv6 = {}
    end
    if (statusTbl.networkInfoTbl.networkWanInfoTbl == nil) then
        statusTbl.networkInfoTbl.networkWanInfoTbl.ipv4 = {}
        statusTbl.networkInfoTbl.networkWanInfoTbl.ipv4.addrs = {}
        statusTbl.networkInfoTbl.networkWanInfoTbl.ipv6 = {}
    end

    -- include the dhcpRelay table
    require "teamf1lualib/dhcpRelay"
    status, errCode, statusTbl.lanDhcpRelay = dhcpRelay.confGet(lanLogicalIfName)

    -- include the dhcpv6Relay table
    require "teamf1lualib/dhcpv6Relay"
    status, errCode, statusTbl.lanDhcpv6Relay = dhcpv6Relay.confGet(lanLogicalIfName)


    --wireless Info
	local radioTable = nil
	if (HAVE_WIRELESS == "1") then
		radioTable = db.getRowWhere ("dot11Radio", "_ROWID_", "1", false)
	end
	if (radioTable == nil) then
            statusTbl.networkInfoTbl.radioInfoTbl = {}
            statusTbl.networkInfoTbl.radio1Install = "0"
	else
            statusTbl.networkInfoTbl.radioInfoTbl = {}
            statusTbl.networkInfoTbl.radio1Install = "1"
	    if (radioTable["dot11Radio.band"] == "b" ) then
                statusTbl.networkInfoTbl.radioInfoTbl["band"] = "2.4 GHz"
		if (string.find(radioTable["dot11Radio.opMode"], "1")) then
      		    statusTbl.networkInfoTbl.radioInfoTbl["opMode"] = "g and b"
	    	elseif (string.find(radioTable["dot11Radio.opMode"], "2")) then
		    statusTbl.networkInfoTbl.radioInfoTbl["opMode"] = "b only"
	    	elseif (string.find(radioTable["dot11Radio.opMode"], "3")) then
		    statusTbl.networkInfoTbl.radioInfoTbl["opMode"] = "b/g/n"
	    	elseif (string.find(radioTable["dot11Radio.opMode"], "4")) then
		    statusTbl.networkInfoTbl.radioInfoTbl["opMode"] = "n only"
	    	elseif (string.find(radioTable["dot11Radio.opMode"], "5")) then
		    statusTbl.networkInfoTbl.radioInfoTbl["opMode"] = "ng"
	    	elseif (string.find(radioTable["dot11Radio.opMode"], "6")) then
		    statusTbl.networkInfoTbl.radioInfoTbl["opMode"] = "g only"
                end
            else
                statusTbl.networkInfoTbl.radioInfoTbl["band"] = "5 GHz"
		if (string.find(radioTable["dot11Radio.opMode"], "1")) then
      		    statusTbl.networkInfoTbl.radioInfoTbl["opMode"] = "a only"
	    	elseif (string.find(radioTable["dot11Radio.opMode"], "2")) then
		    statusTbl.networkInfoTbl.radioInfoTbl["opMode"] = "a/n/ac"
	    	elseif (string.find(radioTable["dot11Radio.opMode"], "3")) then
		    statusTbl.networkInfoTbl.radioInfoTbl["opMode"] = "ac only"
	    	elseif (string.find(radioTable["dot11Radio.opMode"], "4")) then
		    statusTbl.networkInfoTbl.radioInfoTbl["opMode"] = "n only"
	    	elseif (string.find(radioTable["dot11Radio.opMode"], "5")) then
		    statusTbl.networkInfoTbl.radioInfoTbl["opMode"] = "a/n"
	    	elseif (string.find(radioTable["dot11Radio.opMode"], "6")) then
		    statusTbl.networkInfoTbl.radioInfoTbl["opMode"] = "n/ac"
                end
            end

            if (radioTable["dot11Radio.puren"] == "1" ) then
                statusTbl.networkInfoTbl.radioInfoTbl["opMode"] = "n only"
            end

            local ifname = db.getAttribute("dot11Interface", "_ROWID_", "1", "interfaceName")
            os.execute ("/bin/echo -n `/bin/wl -i " .. radioTable["dot11Radio.interfaceName"] .. " status |grep Channel: | awk '{print$13}' ` > /tmp/channel1")
            local radioInterfaceName = radioTable["dot11Radio.interfaceName"]
            local firstEnabledVapRow = db.getRowWhere("dot11VAP","radioList='"..radioTable["dot11Radio.radioNo"].."' and vapEnabled='1'",false)
            if(firstEnabledVapRow ~= nil)then
                local vapInterfaceName = db.getAttribute("dot11Interface","vapName",firstEnabledVapRow["vapName"],"interfaceName")
                os.execute ("/bin/echo -n `/bin/wl -i " .. vapInterfaceName .. " status |grep Channel | awk '{print$13}' ` > /tmp/channel1")
            else
                os.execute ("/bin/echo -n `/bin/wl -i " .. radioInterfaceName .. " status |grep grep Channel | awk '{print$13}' ` > /tmp/channel1")
            end
            channel = util.fileToString("/tmp/channel1")
            if (channel ~= nil) then
                statusTbl.networkInfoTbl.radioInfoTbl["currentChannel"] = channel
            else
                statusTbl.networkInfoTbl.radioInfoTbl["currentChannel"] = "Not Available"
            end
	end

        -- radio 2 
        local radioTable2 = nil
        if (HAVE_WIRELESS == "1") then
            radioTable2 = db.getRow ("dot11Radio", "_ROWID_", "2", false)
        end
        if (radioTable2 == nil) then
            statusTbl.networkInfoTbl.radioInfoTbl2 = {}
            statusTbl.networkInfoTbl.radio2Install = "0"
        else
            statusTbl.networkInfoTbl.radioInfoTbl2 = {}
            statusTbl.networkInfoTbl.radio2Install = "1"
            if (radioTable2["dot11Radio.band"] == "b" ) then
                statusTbl.networkInfoTbl.radioInfoTbl2["band"] = "2.4 GHz"
                if (string.find(radioTable2["dot11Radio.opMode"], "1")) then
                    statusTbl.networkInfoTbl.radioInfoTbl2["opMode"] = "g and b"
                elseif (string.find(radioTable2["dot11Radio.opMode"], "2")) then
                    statusTbl.networkInfoTbl.radioInfoTbl2["opMode"] = "b only"
                elseif (string.find(radioTable2["dot11Radio.opMode"], "3")) then
                    statusTbl.networkInfoTbl.radioInfoTbl2["opMode"] = "b/g/n"
                elseif (string.find(radioTable2["dot11Radio.opMode"], "4")) then
                    statusTbl.networkInfoTbl.radioInfoTbl2["opMode"] = "n only"
                elseif (string.find(radioTable2["dot11Radio.opMode"], "5")) then
                    statusTbl.networkInfoTbl.radioInfoTbl2["opMode"] = "ng"
                elseif (string.find(radioTable2["dot11Radio.opMode"], "6")) then
                    statusTbl.networkInfoTbl.radioInfoTbl2["opMode"] = "g only"
                end
            else
                statusTbl.networkInfoTbl.radioInfoTbl2["band"] = "5 GHz"
                if (string.find(radioTable2["dot11Radio.opMode"], "1")) then
                    statusTbl.networkInfoTbl.radioInfoTbl2["opMode"] = "a only"
                elseif (string.find(radioTable2["dot11Radio.opMode"], "2")) then
                    statusTbl.networkInfoTbl.radioInfoTbl2["opMode"] = "a/n/ac"
                elseif (string.find(radioTable2["dot11Radio.opMode"], "3")) then
                    statusTbl.networkInfoTbl.radioInfoTbl2["opMode"] = "ac only"
                elseif (string.find(radioTable2["dot11Radio.opMode"], "4")) then
                    statusTbl.networkInfoTbl.radioInfoTbl2["opMode"] = "n only"
                elseif (string.find(radioTable2["dot11Radio.opMode"], "5")) then
                    statusTbl.networkInfoTbl.radioInfoTbl2["opMode"] = "a/n"
                elseif (string.find(radioTable2["dot11Radio.opMode"], "6")) then
                    statusTbl.networkInfoTbl.radioInfoTbl2["opMode"] = "n/ac"
                end
            end

            if (radioTable2["dot11Radio.puren"] == "1" ) then
                statusTbl.networkInfoTbl.radioInfoTbl2["opMode"] = "n only"
            end

            local radioInterfaceName = radioTable2["dot11Radio.interfaceName"]
            local firstEnabledVapRow = db.getRowWhere("dot11VAP","radioList='"..radioTable2["dot11Radio.radioNo"].."' and vapEnabled='1'",false)
            if(firstEnabledVapRow ~= nil)then
                local vapInterfaceName = db.getAttribute("dot11Interface","vapName",firstEnabledVapRow["vapName"],"interfaceName")
                if (util.fileExists ("/pfrm2.0/HW_JCOW401") or util.fileExists ("/pfrm2.0/HW_JCOW403")) then
                    os.execute ("/bin/echo -n `/bin/wl -i " .. vapInterfaceName .. " status |grep Channel | awk '{print$13}'|cut -d / -f 1 ` > /tmp/channel2")
                else
                    os.execute ("/bin/echo -n `/bin/wl -i " .. vapInterfaceName .. " status |grep Channel | awk '{print$13}' ` > /tmp/channel2")
                end
            else
                if (util.fileExists ("/pfrm2.0/HW_JCOW401") or util.fileExists ("/pfrm2.0/HW_JCOW403")) then
                    os.execute ("/bin/echo -n `/bin/wl -i " .. radioInterfaceName .. " status |grep Channel | awk '{print$13}'|cut -d / -f 1 ` > /tmp/channel2")
                else
                    os.execute ("/bin/echo -n `/bin/wl -i " .. radioInterfaceName .. " status |grep Channel | awk '{print$13}' ` > /tmp/channel2")
                end
            end
            channel = util.fileToString("/tmp/channel2")
            if (channel ~= nil) then
                statusTbl.networkInfoTbl.radioInfoTbl2["currentChannel"] = channel
            else
                statusTbl.networkInfoTbl.radioInfoTbl2["currentChannel"] = "Not Available"
            end
        end

	local dot11APInfo = {} --dot11.accessPointGet()
	if (HAVE_WIRELESS == "1") then
		dot11APInfo = dot11.accessPointGet()
	end
    statusTbl.networkInfoTbl.apInfoTbl = {}
	for i,v in ipairs (dot11APInfo)
	do
		statusTbl.networkInfoTbl.apInfoTbl[i] = {}
		statusTbl.networkInfoTbl.apInfoTbl[i]["ssid"] = v["ssid"]
		statusTbl.networkInfoTbl.apInfoTbl[i]["security"] = v["security"]
		statusTbl.networkInfoTbl.apInfoTbl[i]["encryption"] = v["pairwiseCiphers"]
		statusTbl.networkInfoTbl.apInfoTbl[i]["authentication"] = v["authMethods"]
	end
    statusTbl.wirelessInfo.radioInfoTbl = statusTbl.networkInfoTbl.radioInfoTbl
    statusTbl.wirelessInfo.radioInfoTbl2 = statusTbl.networkInfoTbl.radioInfoTbl2
    statusTbl.wirelessInfo.apInfoTbl = statusTbl.networkInfoTbl.apInfoTbl
    statusTbl.wirelessInfo.radio1Install = statusTbl.networkInfoTbl.radio1Install
    statusTbl.wirelessInfo.radio2Install = statusTbl.networkInfoTbl.radio2Install

    local lStat = ""
	local gponState = ""
	local fp = io.open("/var/wan")
    if (fp ~= nil) then
        lStat = fp:read("*line")
	    fp:close()
    end
    if (platformLib.strcasecmp(lStat, "yes") == 0) then
        linkStatus = "LINK UP"
    elseif (platformLib.strcasecmp(lStat, "no")) then
        linkStatus = "LINK DOWN"
    else
        linkStatus = "N/A"
    end

    statusTbl.networkInfoTbl.networkWanInfoTbl.ipv4["linkState"] = linkStatus

	if (UNIT_INFO ~= "ODU") then
        local gponRow = db.getRow ("gpon", "_ROWID_", "1")
        if (gponRow["gpon.status"] == "1") then
            statusTbl.networkInfoTbl.networkWanInfoTbl.gpon = "1"
            os.execute("a=`/bin/gponctl getState|grep Operational|cut -d ':' -f 2`;/bin/echo -n $a > /tmp/gponstate")
            local fp1 = io.open("/tmp/gponstate")
            if (fp1 ~= nil) then
                gponState = fp1:read("*line")
                fp1:close()
            end
            statusTbl.networkInfoTbl.networkWanInfoTbl.gponState = gponState
            if(util.fileExists("/pfrm2.0/ae_wan_type")) then
                statusTbl.networkInfoTbl.networkWanInfoTbl.gponState = linkStatus
            end
        end
        -- To set the Model Name:
        if (util.fileExists ("/pfrm2.0/GPON_ONLY_NEW")) then
            statusTbl.modelName = "JCO101"
        elseif (util.fileExists ("/pfrm2.0/HW_FIBERHOME_JEO300")) then
            statusTbl.modelName = "JEO300"
        elseif (util.fileExists ("/pfrm2.0/GPON_ONLY")) then
            statusTbl.modelName = "JCO100"
        elseif (util.fileExists ("/pfrm2.0/ETHERNET_ONLY")) then
            statusTbl.modelName = "JCE100"
        elseif (util.fileExists ("/pfrm2.0/HW_FOXCONN_JCO500")) then
            statusTbl.modelName = "JCO500"
        elseif (util.fileExists ("/pfrm2.0/HW_FOXCONN")) then
            statusTbl.modelName = "JCS5100"
        elseif (util.fileExists ("/pfrm2.0/HW_FIBERHOME_JCO300")) then
            statusTbl.modelName = "JCO300"
        elseif (util.fileExists ("/pfrm2.0/HW_JCO110")) then
            statusTbl.modelName = "JCO110"
        elseif (util.fileExists ("/pfrm2.0/HW_HG260ES")) then
            statusTbl.modelName = "HG260ES"
        elseif (util.fileExists ("/pfrm2.0/HW_ALU")) then
            statusTbl.modelName = "G240WA"
        elseif (util.fileExists ("/pfrm2.0/HW_HG261GU")) then
            statusTbl.modelName = "HG261GU"
        elseif (util.fileExists ("/pfrm2.0/HW_JCOW206")) then
            statusTbl.modelName = "JCOW206"
        elseif (util.fileExists ("/pfrm2.0/HW_JCOW401")) then
            statusTbl.modelName = "JCOW401"
        elseif (util.fileExists ("/pfrm2.0/HW_JCOW403")) then
            statusTbl.modelName = "JCOW403"
        elseif (util.fileExists ("/pfrm2.0/HW_JCOW404")) then
            statusTbl.modelName = "JCOW404"
        elseif (util.fileExists ("/pfrm2.0/BRCMJCO300")) then
            statusTbl.modelName = "HG260X"
        else
            statusTbl.modelName = "PR711AAW"
        end
    end
	local hwversion = ""
	if (UNIT_INFO == "ODU") then
		local fp2 = io.open("/tmp/hwversion")
        if (fp2 ~= nil) then
       		hwversion = fp2:read("*line")
            fp2:close()
        end
		if 	(hwversion == "" or hwversion == nil or hwversion == " ") then
			hwversion = "N.A"
		end
		statusTbl.system["hwVersion"] = hwversion		
    end

		local fp2 = io.open("/tmp/hwVersion")
        if (fp2 ~= nil) then
       		hwversion = fp2:read("*line")
            fp2:close()
        end
		if 	(hwversion == "" or hwversion == nil or hwversion == " ") then
			hwversion = "N.A"
		end
		statusTbl.system["hwVersion"] = hwversion		

    if (UNIT_INFO == "ODU") then
         local lteSignalColor = ""
                local fp3 = io.open("/tmp/LteLedColor")
         if (fp3 ~= nil) then
                lteSignalColor = fp3:read("*line")
            fp3:close()
         end
      
         statusTbl["lteSignalStrength"] = lteSignalColor
    end

    errorCode = "OK"
    statusMsg = ""

    --return
    return errorCode,statusMsg,statusTbl
end

-------------------------------------------------------------------------------
-- @name gui.status.truncateValues()
--
-- @description This function truncates the values extending in length.
--
-- @return
--

function gui.status.truncateValues (stringToTruncate, tuncateLength)

    if (stringToTruncate == nil or stringToTruncate == "") then
        return "0", "0"
    end

    local titleVal = stringToTruncate

    local len = #(tostring (stringToTruncate))

    if (len > tuncateLength) then
        stringToTruncate = string.sub (stringToTruncate, 1, tuncateLength) .. "..."
    end

    return titleVal, stringToTruncate
end

-------------------------------------------------------------------------
-- @name gui.status.account.traffGet (accountName)
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--
function gui.status.account.traffGet (accountName)

    debug.Debugger (accountName)
    require "teamf1lualib/ifDev"
    local bwCounters = {}
    local bwMonCustom = {}
    local query
    local accName
    local appNames = db.getDistinctValues("BwMonStat", "AppName")
    local idx = 1
    for k,v in pairs (appNames) do
        local counterSum = nil
        bwCounters[idx] = {}
        bwCounters[idx]["BwMonStat.AppName"] = v["BwMonStat.AppName"] or ''

        if (accountName == "ALL") then
            counterSum = db.getTable("BwMonStat", false, "SELECT sum(Counter) Counter FROM BwMonStat where AppName='" .. v["BwMonStat.AppName"] .. "'")
		else
            if (ifDevLib.macAddrCheck (accountName) == nil) then
                query = "ipAddr='" .. accountName .. "'"
            else
                query = "macAddr='".. accountName .. "'"
            end
            bwMonCustom = db.getRowWhere ("BwMonCustom", query, false)
            accName = bwMonCustom["AccName"]
            counterSum = db.getTable("BwMonStat", false, "SELECT sum(Counter) Counter FROM BwMonStat where AccName='" .. accName .. "' and AppName='" .. v["BwMonStat.AppName"] .. "'")
        end

        if (counterSum ~= nil and #counterSum == 1) then
            bwCounters[idx]["BwMonStat.Counter"] = counterSum[1]["Counter"] or '0'
        else
            bwCounters[idx]["BwMonStat.Counter"] = '0'
        end

        idx = idx + 1
    end

    --return
    return "OK", "STATUS_OK" ,bwCounters

end

-------------------------------------------------------------------------
-- @name gui.status.account.accNameGet ()
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--
function gui.status.account.accNameGet()
    local page = {}
    local idx = 1
    
    page[idx] = {}
    page[idx].accName = "ALL"
    local bwMonCustomTbl = db.getTable ("bwMonCustom", false)
    if (bwMonCustomTbl ~= nil) then
        for k,v in pairs (bwMonCustomTbl) do
            page[k+idx] = {}
            if  (v["accType"] == "1") then
                page[k+idx].accName = util.filterXSSChars(v["ipAddr"])
            else
                page[k+idx].accName = util.filterXSSChars(v["macAddr"])
            end
        end
    end

    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------
-- @name gui.status.maptPorts.get ()
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--
function gui.status.maptPorts.get ()
    -- require
    require "teamf1lualib/maptConfig"
    --locals
    local configTbl = {}

    local maptStatus = db.getAttribute("maptConfig", "_ROWID_", "1", "enable")

    if (maptStatus == 0) then
        return "ERROR", "MAPT_DISABLED",nil
    end

    --getting the values from maptPortStats table
    configTbl = maptPortStats.availablePortget ()
    if(configTbl == nil) then
        return "ERROR", "NO_ACTIVE_PORTS_FOR_MAPT"
    end

    --return
    return "OK", "STATUS_OK", configTbl
end

-------------------------------------------------------------------------
-- @name gui.status.maptPorts.statsGet ()
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--
function gui.status.maptPorts.statsGet ()
    -- require
    require "teamf1lualib/maptConfig"
    --locals
    local configTbl = {}

    local maptStatus = db.getAttribute("maptConfig", "_ROWID_", "1", "enable")

    if (maptStatus == 0) then
        return "ERROR", "MAPT_DISABLED",nil,0,0
    end

    --getting the values from median
    local median = maptPortStats.medianget ()
     if(median == nil) then
        return "ERROR", "NO_ACTIVE_PORTS_FOR_MAPT",nil,0,0
    end

    --getting the values from peak
    local peak = maptPortStats.peakget ()
    
    --getting the values from maptPortStats table
    configTbl = maptPortStats.activePortsget ()
    if(configTbl == nil) then
        return "ERROR", "NO_ACTIVE_PORTS_FOR_MAPT",nil,0,0
    end
    --return
    return "OK", "STATUS_OK", configTbl, median, peak
end
