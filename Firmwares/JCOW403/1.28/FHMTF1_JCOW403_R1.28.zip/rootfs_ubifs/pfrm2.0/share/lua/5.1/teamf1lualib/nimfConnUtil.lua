
require "teamf1lualib/nimfConnType"

local DHCLIENT_FORCE_RUN="/tmp/dhclientForceRun"

--[[
*******************************************************************************
-- @name nimfConn.cfgAdd 
--
-- @description This function adds a new connection to the network. If
-- the network does not already exists, then it creates one.
--
-- @param conf network configuration
-- @field LogicalIfName NET ID
-- @field AddressFamily Protocol 
-- @field ConnectionKey unique connection number
--
-- @return  status, errCode
--
--]]

function nimfConn.cfgAdd (conf)
    local valid
    local errstr
    local rowid

    nimf.dprintf("Adding configuration: " .. util.tableToStringRec(conf))

    conf = util.addPrefix(conf, "NimfConf.")

    valid, errstr, rowid = nimf.config (conf, -1, "add")
    if (not valid) then
        if (errstr) then 
            nimf.dprintf("nimfConn.cfgAdd: add failed. reason:" .. errstr) 
        end
        return "ERROR", nimf.err.NIMF_ERR_DB_ADD
    end        

    return "OK","STATUS_OK"
end

--[[
*******************************************************************************
-- @name nimfConn.cfgDelete 
--
-- @description  This function delete a connection.
--  
-- @param connID    Connection ID
-- @field LogicalIfName NET ID
-- @field AddressFamily Protocol 
-- @field ConnectionKey unique connection number
--
-- @return  status, errCode
--
--]]

function nimfConn.cfgDelete (connID)
    local valid
    local errstr
    local query = nil

    -- generate query 
    query = "LogicalIfName='" .. connID["LogicalIfName"] .. "' AND " ..
            "AddressFamily='" .. connID["AddressFamily"] .. "' "

    if (connID["ConnectionKey"] ~= nil) then
        query = query .. " AND ConnectionKey=" .. connID["ConnectionKey"]
    end
            
    -- delete the configuration
    valid, errstr = db.deleteRowWhere("NimfConf", query)
    if (not valid) then
        if (errstr) then 
            nimf.dprintf("nimfConn.cfgDelete: delete failed. reason:" .. errstr) 
        end
        return "ERROR", nimf.err.NIMF_ERR_DB_DELETE         
    end        

    return "OK","STATUS_OK"
end

--[[
*******************************************************************************
-- @name nimfConn.cfgUpdate 
--
-- @description This function updates connection properties.
--
-- @param connID    Connection ID
-- @field LogicalIfName NET ID
-- @field AddressFamily Protocol 
-- @field ConnectionKey unique connection number
--
-- @return  status, errCode
--
--]]

function nimfConn.cfgUpdate (conf)
    local valid
    local errstr=""

    changed = nimf.hasTableChanged("NimfConf", conf, conf["_ROWID_"])
    if (not changed) then
        return "OK","STATUS_OK", false
    end        

    -- update the configuration
    conf = util.addPrefix(conf, "NimfConf.")
    if (conf == nil) then
        return "ERROR", nimf.err.NIMF_ERR_INVALID_ARG   
    end        

    -- commit 
    valid, errstr = nimf.config(conf, conf["NimfConf._ROWID_"], "edit")
    if (not valid) then
        if (errstr) then 
            nimf.dprintf("nimfConn.cfgUpdate: update failed. reason:" .. errstr) 
        end
        nimf.dprintf("nimfConn.cfgUpdate: failed to update connection configuration")
        return "ERROR", nimf.err.NIMF_ERR_DB_UPDATE
    end
    
    return "OK","STATUS_OK", true
end

--[[
*******************************************************************************
-- @name nimfConn.cfgGet 
--
-- @description This function gets the cofiguration of a connection
--
-- @param connID    Connection ID
-- @field LogicalIfName NET ID
-- @field AddressFamily Protocol 
-- @field ConnectionKey unique connection number
--
-- @return  status, errCode
--
--]]

function nimfConn.cfgGet (connID)
    local status
    local errCode
    local record = {}
    local query = nil

    status, errCode = nimfConn.IDValidate (connID) 
    if (status ~= "OK") then
        nimf.dprintf("cfgGet: invalid Connection " ..  nimf.connStrGet(connID))
        return "ERROR", errCode
    end        

    query = "LogicalIfName='" .. connID["LogicalIfName"] .. "' AND " ..
            "AddressFamily='" .. connID["AddressFamily"] .. "'"

    if (connID["ConnectionKey"] ~= nil) then
        query = query .. " AND ConnectionKey=" .. connID["ConnectionKey"]
    end

    record = db.getRowWhere("NimfConf", query, false)
    if (record == nil) then
        nimf.dprintf("cfgGet:failed to query NimfConf table: " .. query)
        return "ERROR",nimf.err.NIMF_ERR_DB_QUERY
    end        
            
    return "OK","STATUS_OK", record
end

--[[
*******************************************************************************
-- @name nimfConn.cfgByQueryGet 
--
-- @description The function gets the configuration of the connections matching
-- the query
--
-- @param  query  custom database query
--
-- @return  status, errCode
--
--]]

function nimfConn.cfgByQueryGet (query)
    local records = {}

    if (query == nil) then
        records = db.getTable("NimfConf", false)
    else        
        records = db.getRowsWhere("NimfConf", query, false)
        if (records == nil) then
            return "ERROR", nimf.err.NIMF_ERR_DB_QUERY        
        end        
    end

    return "OK", "STATUS_OK", records
end

--[[
*******************************************************************************
-- @name nimfConn.cfgValidate - validate connection 
--
-- @description 
--
-- @param 
--
-- @return  0 for success else -1
--
--]]

function nimfConn.cfgValidate(conf)

    local status = -1

    if (conf == nil) then
        return -1        
    end        

    status, errCode = nimfConn.IDValidate(conf)
    if (status ~= "OK") then
        nimf.dprintf("nimfConn.cfgValidate: Invalid connection ID")
        return -1
    end        

    local ConnectionType = conf["ConnectionType"]
    status = nimfConn.isMethodSupported(ConnectionType)
    if (status == nil) then
        nimf.dprintf("nimfConn.cfgValidate: Invalid connection method")
        return -1        
    end        

    local Enable = conf["Enable"]
    if (Enable == nil) then
        nimf.dprintf("nimfConn.cfgValidate: Connection status not provided")
        return -1        
    end
            
    if ((tonumber(Enable) ~= 0) and (tonumber(Enable) ~= 1)) then
        nimf.dprintf("nimfConn.cfgValidate: Connection status must be 0 or 1")
        return -1        
    end        

    return 0
end

--[[
*******************************************************************************
-- @name nimfConn.IDValidate 
--
-- @description This function validates the connection ID
--
-- @param connID    Connection ID
-- @field LogicalIfName NET ID
-- @field AddressFamily Protocol 
-- @field ConnectionKey unique connection number
--
-- @return  status, errCode
--]]

function nimfConn.IDValidate (connID)

    if (connID == nil) then
        return "ERROR", nimf.err.NIMF_ERR_INVALID_ARG
    end
            
    if (type(connID) ~= "table") then
        return "ERROR", nimf.err.NIMF_ERR_INVALID_ARG
    end
                        
    local LogicalIfName = connID["LogicalIfName"]
    local AddressFamily = connID["AddressFamily"]

    status = nimf.LogicalNameValidate(LogicalIfName) 
    if (status < 0) then
        return "ERROR", nimf.err.NIMF_ERR_INVALID_NETID
    end        
    
    status = nimf.protocolValidate(AddressFamily)
    if (status < 0) then
        return "ERROR", nimf.err.NIMF_ERR_INVALID_PROTOCOL
    end        

    return "OK","STATUS_OK"
end

--[[
*******************************************************************************
-- @name nimfConn.ipAddrGet 
--
-- @description  This function gets the ip information for the given connection.
--
-- @param connID    Connection ID
-- @field LogicalIfName NET ID
-- @field AddressFamily Protocol 
-- @field ConnectionKey unique connection number
--
-- @return  status, errCode
--]]

function nimfConn.ipAddrGet (connID)
    local status
    local errCode
    local records = {}
    local query = nil

    status, errCode = nimfConn.IDValidate (connID) 
    if (status ~= "OK") then
        return status, errCode        
    end        

    query = "LogicalIfName='" .. connID["LogicalIfName"] .. "' AND " ..
            "AddressFamily='" .. connID["AddressFamily"] .. "'"

    if (connID["ConnectionKey"] ~= nil) then
        query = query .. " AND ConnectionKey=" .. connID["ConnectionKey"]
    end

    records = db.getRowsWhere("ipAddressTable", query, false)
    if (records == nil) then
        return "ERROR", nimf.err.NIMF_ERR_DB_QUERY        
    end        

    return "OK", "STATUS_OK", records
end

--[[
*******************************************************************************
-- @name nimfConn.dnsGet 
--
-- @description  This function gets the DNS information for the given connection.
--
-- @param connID Connection ID
-- @field LogicalIfName NET ID
-- @field AddressFamily Protocol 
-- @field ConnectionKey unique connection number
--
-- @return  status, errCode
--]]

function nimfConn.dnsGet (connID)
    local status
    local errCode
    local record = {}
    local dnsTbl = {}
    local query = nil

    status, errCode = nimfConn.IDValidate (connID) 
    if (status ~= "OK") then
        return status, errCode        
    end        

    query = "LogicalIfName='" .. connID["LogicalIfName"] .. "' AND " ..
            "AddressFamily='" .. connID["AddressFamily"] .. "'"

    if (connID["ConnectionKey"] ~= nil) then
        query = query .. " AND ConnectionKey=" .. connID["ConnectionKey"]
    end

    record = db.getRowWhere("resolverConfig", query, false)
    if (record == nil) then
        return "ERROR", nimf.err.NIMF_ERR_DB_QUERY        
    end        

    dnsTbl["nameserver1"] = record["nameserver1"]
    dnsTbl["nameserver2"] = record["nameserver2"]

    return "OK", "STATUS_OK", dnsTbl
end

--[[
*******************************************************************************
-- @name nimfConn.confInit 
--
-- @description 
--
-- @param conf
--
-- @return  
--]]

function nimfConn.confInit (cur, conf)
    local cfg = {}
    local ConnectionKey = conf["ConnectionKey"]

    if (ConnectionKey == nil) then
        ConnectionKey = "0"
    end        

    if (cur ==  nil) then
        cfg["LogicalIfName"] = conf["LogicalIfName"]
        cfg["AddressFamily"] = conf["AddressFamily"]
        cfg["ConnectionKey"] = ConnectionKey
        cfg["Enable"] = conf["Enable"]
        cfg["ConnectionType"] = conf["ConnectionType"]
        cfg["WarnDisconnectDelay"] = conf["WarnDisconnectDelay"]
        cfg["ConfigureDNS"] = conf["ConfigureDNS"]
        cfg["ConfigureRoute"] = conf["ConfigureRoute"]
        cfg["DefaultConnection"] = conf["DefaultConnection"]
    else
        cfg = cur
        cfg["Enable"] = conf["Enable"]
        cfg["ConnectionType"] = conf["ConnectionType"]
        cfg["WarnDisconnectDelay"] = conf["WarnDisconnectDelay"]
        cfg["ConfigureDNS"] = conf["ConfigureDNS"]
        cfg["ConfigureRoute"] = conf["ConfigureRoute"]
        cfg["DefaultConnection"] = conf["DefaultConnection"]
    end                

    return cfg
end

--[[
*******************************************************************************
-- @name nimfConn.confUpdate
--
-- @description 
--
-- @param conf
--
-- @return  
--]]

function nimfConn.confUpdate(conf)
    local status = "ERROR"
    local errCode = ""
    local query = nil
    local cfg = {}
    local methodChanged = nil
    local dhclientForceRestart = nil

    -- check if the configuration exists 
    status, errCode, cfg = nimfConn.cfgGet(conf) 
    if (cfg == nil) then

        -- initialize the configuration
        cfg = nimfConn.confInit(cfg, conf)

        -- add the connection
        status, errCode = nimfConn.cfgAdd(cfg)
        if (status ~= "OK") then
            nimf.dprintf("nimfConn.confUpdate: failed to add connection configuration")
            return "ERROR", errCode        
        end        

        -- configure the method
        status, errCode = nimfConn.methodConfigure(conf) 
        if (status ~= "OK") then
            nimf.dprintf("nimfConn.confUpdate: failed to update method configuration")
            return "ERROR", errCode        
        end        
    else
        --Disable old method
        status, errCode = nimfConn.methodDeInit(cfg)
        if (status ~= "OK") then
            nimf.dprintf("nimfConn.confUpdate: failed to deinit method")
            return "ERROR", errCode        
        end 

        -- initialize the configuration
        cfg = nimfConn.confInit(cfg, conf)

        -- update the method
        status, errCode, methodChanged = nimfConn.methodConfigure(conf) 
        if (status ~= "OK") then
            nimf.dprintf("nimfConn.confUpdate: failed to update method configuration")
            return "ERROR", errCode        
        end        

        --Enable current method
        status, errCode = nimfConn.methodInit(cfg)
        if (status ~= "OK") then
            nimf.dprintf("nimfConn.confUpdate: failed to Init method")
            return "ERROR", errCode        
        end

        -- update the connection
        status, errCode, confChanged= nimfConn.cfgUpdate(cfg)
        if (status ~= "OK") then
            nimf.dprintf("nimfConn.confUpdate: failed to update connection configuration")
            return "ERROR", errCode        
        end        

        -- dhclient keep alive changes to forcely start dhclient process
        if util.fileExists(DHCLIENT_FORCE_RUN) then
            dhclientForceRestart =  true
        end

        --
        -- restart the connection if the method configuration has changed.
        -- If nimf configuration has changed then, nimf daemon will
        -- restart the connection automatically.
        --
        if (methodChanged) or (dhclientForceRestart) then
            -- restart the connection.
            nimf.dprintf("nimfConn.confUpdate: restarting connection")
            nimfConn.stop(conf)
            nimfConn.start(conf)
        else
            nimf.dprintf("nimfConn.confUpdate: connection type configuration unchanged")
        end
    end        

    return "OK","STATUS_OK"
end

--[[
*******************************************************************************
-- @name nimfConn.confDelete
--
-- @description 
-- Make sure that the connections have stopped, before deleting it.
-- @param conf
--
-- @return  
--]]

function nimfConn.confDelete(conf)
    local status = "ERROR"
    local errCode = ""
    local cfg = {}

    nimf.dprintf("network.confDelete:Deleting configuration for " .. nimf.connStrGet(conf))

    status, errCode, cfg = nimfConn.cfgGet(conf) 
    if (cfg == nil) then
        return "OK","STATUS_OK"
    end
    
    status, errCode = nimfConn.methodDeconfigure(cfg) 
    if (status ~= "OK") then
        return "ERROR", errCode        
    end        

    status, errCode = nimfConn.cfgDelete(cfg)
    if (status ~= "OK") then
        return "ERROR", errCode        
    end        

    return "OK","STATUS_OK"
end

--[[
*******************************************************************************
-- @name nimfConn.confValidate
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--
--]]

function nimfConn.confValidate (conf)
    local status = "ERROR"
    local errCode = ""

    -- validate connection configuration
    status = nimfConn.cfgValidate(conf)
    if (status < 0) then
        nimf.dprintf("nimfConn.confValidate: Connection configuration failed")
        return "ERROR", errCode        
    end        

    -- validate connection parameters
    status, errCode = nimfConn.methodValidate(conf) 
    if (status ~= "OK") then
        nimf.dprintf("nimfConn.methodValidate: Connection parameters configuration failed")
        return "ERROR", errCode        
    end        

    return "OK","STATUS_OK"
end

--[[
*******************************************************************************
-- @name nimfConn.defCfgGet
--
-- @description This function gets the cofiguration of a connection
--
-- @param connID    Connection ID
-- @field LogicalIfName NET ID
-- @field AddressFamily Protocol 
-- @field ConnectionKey unique connection number
-- @field ConnectionType  type of connection.
--
-- @return  status, errCode
--
--]]

function nimfConn.defCfgGet (connID)
    local cfg = {}
    
    cfg["LogicalIfName"] = connID["LogicalIfName"]
    cfg["AddressFamily"] = connID["AddressFamily"]
    cfg["ConnectionKey"] = connID["ConnectionKey"] or "0"
    cfg["ConnectionType"] = connID["ConnectionType"]
    cfg["DefaultConnection"] = "0"
    cfg["Enable"] = "0"
    cfg["ConfigureDNS"] = "1"
    cfg["ConfigureRoute"] = "1"
    cfg["WarnDisconnectDelay"] = "0"
            
    return cfg
end

--[[
*******************************************************************************
-- @name nimfConn.isIpInNetwork
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--
--]]

function nimfConn.isIpInNetwork (LogicalIfName, addr)
	require "nimfLib"
    local   inNetwork = -1
    local   connID = {}

    connID["LogicalIfName"] = LogicalIfName
    if (nimfLib.ipv4AddrCheck(addr) == 1) then
        connID["AddressFamily"] = "2"
        connID["ConnectionKey"] = "0"

        -- get the connection interface name
        local ifname = nimfLib.connIfNameGet(connID)
        if (ifname == nil) then
            return -1, "NIMF_ERR_IF_NOT_FOUND"
        end
                    
        -- check if ip is in network                    
        inNetwork = nimfLib.isIpInNetwork(ifname, addr)
        if (inNetwork == nil) then
            inNetwork = -1
        end            
    end    

    return inNetwork
end    
