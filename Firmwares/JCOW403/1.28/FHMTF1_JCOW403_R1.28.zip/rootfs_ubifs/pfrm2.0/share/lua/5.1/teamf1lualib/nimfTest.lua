#! /pfrm2.0/bin/lua

module( "nimf-test", package.seeall, lunit.testcase)

require "lunit"
require "teamf1lualib/util"
require "teamf1lualib/db"
require "teamf1lualib/nimf"
require "teamf1lualib/ifDev"
require "teamf1lualib/network"
require "teamf1lualib/nimfConn"

local nimfTest = {}

nimfTest.static = {}
nimfTest.static.conn4 = {}
nimfTest.static.conn6 = {}

nimfTest.dhcpc = {}
nimfTest.dhcpc.conn4 = {}
nimfTest.dhcpc.conn6 = {}

nimfTest.connTbl = {}

function setup_ipv4_static()
    local conn4 = {}

    conn4["AddressFamily"]=2
    conn4["Enable"] = "1"
    conn4["ConnectionType"] = "ifStatic"
    conn4["StaticIp"] = "192.168.1.10"
    conn4["NetMask"] = "255.255.255.0"
    conn4["Gateway"] = "192.168.1.1"
    conn4["PrimaryDns"] = "192.168.1.1"
    conn4["SecondaryDns"] = "192.168.1.1"
    conn4["ConfigureDNS"] =  "1"
    conn4["ConfigureRoute"] =  "1"
    conn4["DefaultConnection"] =  "1"

    nimfTest.static.conn4 = conn4

    return
end

function setup_ipv6_static()
    local conn6 = {}

    conn6["AddressFamily"]=10
    conn6["Enable"] = "1"
    conn6["ConnectionType"] = "ifStatic6"
    conn6["StaticIp"] = "2000::1"
    conn6["PrefixLength"] = 64
    conn6["Gateway"] = "2000::2"
    conn6["PrimaryDns"] = "2000::2"
    conn6["SecondaryDns"] = "2000::2"
    conn6["ConfigureDNS"] =  "1"
    conn6["ConfigureRoute"] =  "1"
    conn6["DefaultConnection"] =  "1"
    conn6["NetMask"] = ""

    nimfTest.static.conn6 = conn6

    return
end

function setup_ipv4_dhcpc()
    local conn4 = {}

    conn4["AddressFamily"]=2
    conn4["Enable"] = "1"
    conn4["ConnectionType"] = "dhcpc"
    conn4["PrimaryDns"] = ""
    conn4["SecondaryDns"] = ""

    nimfTest.dhcpc.conn4 = conn4
end

function setup()

    db.connect("/tmp/system.db")
    setup_ipv4_static()
    setup_ipv6_static()
    setup_ipv4_dhcpc()
end

function testConnTblGet()
    local index
    local records = {}
    local connTbl = {}
    local confTbl = {}

    -- get the configuration
    records = nimf.export ()
    index = 1
    for k,v in pairs(records) do
        confTbl[index] = {}
        confTbl[index]["LogicalIfName"] = v["LogicalIfName"]
        confTbl[index]["AddressFamily"] = v["AddressFamily"]
        confTbl[index]["ConnectionKey"] = v["ConnectionKey"]
        index = index + 1
    end
    assert_not_nil(confTbl, "No Connections configured")

    -- get the status
    index = 1
    for k,v in pairs(confTbl) do
        connTbl[index] = {}
        status, errCode, statusTbl = nimfConn.statusGet(v)
        assert_match(status, "OK") 

        connTbl[index] = statusTbl
        index = index + 1
    end    

    nimfTest.connTbl = connTbl
end

--[[
]]--
function test_ipv6_static()
    local status, errCode = network.configure("Internet", nimfTest.static.conn6)
    assert_match(status, "OK") 
    os.execute("sleep 5")
end

function test_ipv4_static()
    local status, errCode = network.configure("Internet", nimfTest.static.conn4)
    assert_match(status, "OK") 
    os.execute("sleep 5")
end

function test_ipv4_disable()
    local status, errCode = network.disable("Internet")
    assert_match(status, "OK") 
    os.execute("sleep 5")
end

function test_ipv4_enable()
    local status, errCode = network.enable("Internet")
    assert_match(status, "OK") 
    os.execute("sleep 5")
end

function test_ipv4_dhcpc()
    local status, errCode = network.configure("Internet", nimfTest.dhcpc.conn4)
    assert_match(status, "OK") 
    os.execute("sleep 5")
end

--[[
function teardown()
    local status, errCode = network.deconfigure("Internet")
    assert_match(status, "OK") 
    os.execute("sleep 5")
end
]]--
