--[[ easyMeshTopologyInfoLib.lua - Process the Easy Mesh Topology JSON data to Lua
-- Table and Vice versa.
--
-- Copyright (c) 2008-2019, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: easyMeshTopologyInfoLib.lua
-- Description: Process the Easy Mesh Topology JSON data to Lua Table and Vice versa.
-- 
-- modification history
-- --------------------
-- 01a, 03Jun2020, vin written.
--
--]]
require "ifDevLib"
require "teamf1lualib/easyMeshClientInfoLib"

easyMeshTopologyInfoLib = {} 

TOPOLOGY_INFO_NODE  = "topology information"
DEVICE_ROLE         = "Device role"
AL_MAC              = "AL MAC"
NODE_DISTANCE       = "Distance from controller"
NO_OF_RADIOS        = "Number of radios"
UPSTREAM_1905_DEVICE= "Upstream 1905 device"
RADIO_INFO_NODE     = "Radio Info"
RADIO_WIRELESS_MODE = "wireless mode"
RADIO_IDENTIFIER    = "identifier"
RADIO_BW            = "BW"
RADIO_CHANNEL       = "channel"
RADIO_RX_STREAMS    = "Rx Spatial streams"
RADIO_TX_STREAMS    = "Tx Spatial streams"
RADIO_BSSINFO_NODE  = "BSSINFO"
BSSNODE_STAINFO_NODE= "connected sta info"

BH_STA              = "BH STA"
STA_MAC             = "STA MAC address"
STA_UPLINK_RSSI     = "uplink rssi"
STA_LAST_ASSOC_TIME = "last assoc time"
STA_MEDIUM          = "Medium"

BH_IFACE_APCLI_NODE = "BH Interface(APCLI)"
BH_INFO_NODE        = "BH Info"
BH_MEDIUM_TYPE      = "Backhaul Medium Type"
BH_INFO_NODE_RSSI   = "RSSI"

BH_IFACE_AP_NODE        = "BH Interface(AP)"
BH_IFACE_AP_MACADDR     = "MAC address"
BH_IFACE_AP_IFACENAME   = "interface name"

BH_LINK_METRICS_NODE= "backhaul link metrics"
BH_METRICS_NODE= "metrics"

CLIENTS_INFO_NODE   = "Other Clients Info" 

WIFISON_NODE = "Topology"
WIFISON_INTERNET = "WiFiSON_Internet"
WIFISON_NUMBER = "WiFiSON_Number"
WIFISON_NODE_DEVICE_NAME = "Device_Name"
WIFISON_NODE_HOP_COUNT = "Hop_Count"
WIFISON_NODE_MODEL_NUMBER = "Device_ModelNumber"
WIFISON_NODE_PARENT_MAC = "ParentAPMAC"
WIFISON_NODE_DEVICE_MAC = "Device_MAC"
WIFISON_NODE_DEVICE_UPLINK = "Device_Uplink"
WIFISON_NODE_DEVICE_PORT = "Port"
WIFISON_NODE_SIGNAL_STRENGTH = "SignalStrength"
WIFISON_NODE_COMMON_NODE = "Common"
WIFISON_NODE_RADIO_NODE = "radios"
WIFISON_NODE_RADIO_TYPE = "radio_type"
WIFISON_NODE_RADIO_BASE_MAC = "base_mac"
WIFISON_RADIO_24G_STR = "radio_24"
WIFISON_RADIO_5G_STR = "radio_5"
WIFISON_AP_NAME = "AP_Name"
WIFISON_AP_ENABLE = "WiFi_AP_Enable"
WIFISON_RESULT = "Result"
WIFISON_RESPONSE_CODE = "Response_Code"
WIFISON_ERROR_MSG = "Error_Message"


MESH_OBJ_ID         = "id"
MESH_OBJ_LABEL      = "label"
MESH_OBJ_GROUP      = "group"
MESH_OBJ_TITLE      = "title"
MESH_OBJ_MAC        = "mac"
MESH_OBJ_PARENT_MAC = "parent_mac"
MESH_OBJ_SIGNALSTRENGTH = "SignalStrength"
MESH_OBJ_BSSID = "BSSID"
MESH_OBJ_SSID = "SSID"
MESH_OBJ_MEDIUM = "Medium"
MESH_OBJ_SECURITY = "Security"
MESH_OBJ_ENCRYPTION = "Encryption"
MESH_OBJ_CHANNEL = "channel"

PARENT_EDGE = "from"
CHILD_EDGE  = "to"

INTERNET_GROUP   = "0"
CAP_GROUP   = "1"
AGENT_GROUP = "2"
STA_GROUP   = "3"

WiFiSonNode_t = {
    [WIFISON_NODE_DEVICE_NAME] = "",
    [WIFISON_NODE_HOP_COUNT] = "",
    [WIFISON_NODE_MODEL_NUMBER] = "",
    [WIFISON_NODE_PARENT_MAC] = "",
    [WIFISON_NODE_DEVICE_MAC] = "",
    [WIFISON_NODE_SIGNAL_STRENGTH] = "",
    [WIFISON_NODE_COMMON_NODE] = {
        [WIFISON_NODE_RADIO_NODE] = {
            {
                [WIFISON_NODE_RADIO_TYPE] = "radio_24",
                [WIFISON_NODE_RADIO_BASE_MAC] = ""
            },
            {
                [WIFISON_NODE_RADIO_TYPE] = "radio_5",
                [WIFISON_NODE_RADIO_BASE_MAC] = ""
            }
        }
    }
}

meshNodes_t = {
[MESH_OBJ_ID]           = "",
[MESH_OBJ_LABEL]        = "",
[MESH_OBJ_GROUP]        = "",
[MESH_OBJ_TITLE]        = "",
[MESH_OBJ_MAC]          = "",
[MESH_OBJ_PARENT_MAC]   = ""
}

meshEdges_t = {
[PARENT_EDGE]   = "",
[CHILD_EDGE]    = ""
}


CAP_NODE = 1
meshNodes = {}
CAPNode = {}
AgentNodes = {}

--[[ Lua Tables for Web Processing ]]--
meshTopology={}
meshTopology["nodes"]={}
meshTopology["edges"]={}

meshObjsCnt=0



function getClientAppInfo(client_info, clientNode)

    local clientInfo_t = {}
    clientInfo_t["MAC"]="" 
    
    if (client_info["MAC"] ~= nil) then
        clientInfo_t["MAC"] = client_info["MAC"]
        local deviceIpAddr = db.getAttribute("LanHosts" ,"MACAddress",string.lower(clientInfo_t["MAC"]),"IPAddress")
        local deviceIpv6Addr = db.getAttribute("LanHosts" ,"MACAddress",string.lower(clientInfo_t["MAC"]),"IPv6Address")
        clientInfo_t["IPv4Address"] = deviceIpAddr or ""
        clientInfo_t["IPv6Address"] = deviceIpv6Addr or ""
    end

    if (client_info["ul_rate"] ~= nil) then
        clientInfo_t["LinkRateTx"] = client_info["ul_rate"]
    end

    if (client_info["dl_rate"] ~= nil) then
        clientInfo_t["LinkRateRx"] = client_info["dl_rate"]
    end

    if (clientNode[MESH_OBJ_LABEL] ~= nil) then
        labelInfo = util.split(clientNode[MESH_OBJ_LABEL],"\n")
        if (labelInfo ~= false) then
            if(labelInfo[1] == "") then
                local hostName = ""
                if(clientInfo_t["MAC"] ~= nil) then
                    hostName = db.getAttribute("LanHosts" ,"MACAddress",string.lower(clientInfo_t["MAC"]),"HostName") 
                end

                if(hostName == "") then
                    clientInfo_t["Device_NickName"] = clientInfo_t["MAC"] or ""
                else
                    clientInfo_t["Device_NickName"] = hostName or ""
                end
            else
                clientInfo_t["Device_NickName"] = labelInfo[1]
            end
        end
    end

    if (client_info["RRM"] ~= nil and client_info["BTM"] ~= nil) then
        if (client_info["RRM"] == "YES" and client_info["BTM"] == "YES") then
            clientInfo_t["client_type"] = "KV"
        else
            clientInfo_t["client_type"] = "NKV"
        end
    end
 
    --[[
    if(client_info["Currentchan"] ~= nil) then
        if (client_info["channelList"] ~= nil )then
            for i,chanInfo in pairs(client_info["channelList"]) do
                if(chanInfo["Channel"] == client_info["Currentchan"])then
                    local rssiInfo = util.split(chanInfo["RSSI"],"(")
                    if(rssiInfo ~= false) then
                        clientInfo_t["SignalStrength"] = rssiInfo[1]
                    end
                end
            end
        end
    end
    ]]--

    if (clientNode[MESH_OBJ_SIGNALSTRENGTH] ~= nil) then
        clientInfo_t["SignalStrength"] = clientNode[MESH_OBJ_SIGNALSTRENGTH]
    end


    clientInfo_t["Connection Type"] = "wireless"
    clientInfo_t["Port"] = ""
    
    if ((clientNode[MESH_OBJ_BSSID] ~= nil) and 
        (clientNode[MESH_OBJ_MEDIUM] ~= nil)) then

        clientInfo_t["Common"] = {}
        clientInfo_t["Common"]["radios"] = {}

        local tmp = {}
        if (clientNode[MESH_OBJ_MEDIUM] == "2.4G") then
            tmp["radio_type"] = "radio_24"
            tmp["base_mac"] = clientNode[MESH_OBJ_BSSID]
        elseif(clientNode[MESH_OBJ_MEDIUM] == "5G") then
            tmp["radio_type"] = "radio_5"
            tmp["base_mac"] = clientNode[MESH_OBJ_BSSID]
        elseif(clientNode[MESH_OBJ_MEDIUM] == "Ethernet") then
            tmp["radio_type"] = ""
            tmp["base_mac"] = ""
        end
        --mesh.dprintf(baseMacType)
        table.insert(clientInfo_t["Common"]["radios"],tmp)
    end

    return clientInfo_t
end

            
function VapEnableTest(profileNameStr)

    local vapEnabled = db.getAttribute("dot11VAP","profileName", profileNameStr,"vapEnabled")
    
    if(vapEnabled == "1") then
        return "True"
    else
        return "False"
    end

end



function getDeviceSerial()
    local serialFilep = io.open("/tmp/deviceSerial", "r")
    local serial = "N.A"
    if (serialFilep ~= nil) then
        serial = serialFilep:read("*all")
    end
    return serial
end

function getDeviceHwVersion()
    local hwFilep = io.open("/tmp/hwVersion", "r")
    local hwVersion = "N.A"
    if (hwFilep ~= nil) then
        hwVersion = hwFilep:read("*all")
    end
    return hwVersion
end


function getDeviceIPAddress()

    local ipAddr = nil

    local iprow = db.getRowWhere("ifstatic", "LogicalIfName='IF2' and AddressFamily=2", false)
    if (iprow ~= nil and iprow["StaticIp"] ~= nil and iprow["StaticIp"] ~= "") then
        ipAddr = iprow["StaticIp"]
    end
   
    return ipAddr
end



function getDeviceIPV6Address()

    local ipAddr = nil

    local iprow = db.getRowWhere("ifstatic", "LogicalIfName='IF2' and AddressFamily=10", false)
    if (iprow ~= nil and iprow["StaticIp"] ~= nil and iprow["StaticIp"] ~= "") then
        ipAddr = iprow["StaticIp"]
    end
   
    return ipAddr
end


function getDeviceUplinkSignalStrength(topology_t, deviceMac)

    local topologyRoot = {}
    local currNode = {}
    local upLink = ""
    local signalStrength = ""
    
    topologyRoot = topology_t[TOPOLOGY_INFO_NODE]
    for i=1,#topologyRoot do
        currNode = topologyRoot[i]
        if (string.upper(currNode[AL_MAC]) == string.upper(deviceMac)) then
            break
        end
    end

    if ((currNode[BH_INFO_NODE] ~= nil) and (currNode[BH_INFO_NODE][1] ~= nil) 
        and (currNode[BH_INFO_NODE][1]["RSSI"] ~= nil) and 
	(currNode[BH_INFO_NODE][1]["Backhaul Medium Type"] ~= nil)) then
        upLink =  currNode[BH_INFO_NODE][1]["Backhaul Medium Type"]
        signalStrength =  currNode[BH_INFO_NODE][1]["RSSI"]
    end

    return upLink, signalStrength
end


function easyMeshTopologyInfoLib.getStaNodeInfo(WiFiSonNode, radioNode, bssNode, STANode, meshObjsCnt)

    local staObjNode = {}
    staObjNode[MESH_OBJ_ID] = meshObjsCnt
    staObjNode[MESH_OBJ_GROUP] = STA_GROUP
    staObjNode[MESH_OBJ_MAC]=string.upper(STANode[STA_MAC])

    local deviceName = ""
    local tmpName = db.getAttribute("easyMeshDevices", "macAddr", staObjNode[MESH_OBJ_MAC], "deviceName")
    if (tmpName ~= nil) then
        deviceName = tmpName
    end
    staObjNode[MESH_OBJ_LABEL]= deviceName .. "\n" .. "AL_MAC-" .. string.upper(STANode[STA_MAC])
    staObjNode[MESH_OBJ_TITLE]=staObjNode[MESH_OBJ_LABEL]

    staObjNode[MESH_OBJ_SIGNALSTRENGTH]=STANode[STA_UPLINK_RSSI]
    staObjNode[MESH_OBJ_MEDIUM]=STANode[STA_MEDIUM]
    staObjNode[MESH_OBJ_BSSID]=string.upper(bssNode["BSSID"])
    staObjNode[MESH_OBJ_SSID]=bssNode["SSID"]
    staObjNode[MESH_OBJ_SECURITY]=bssNode["Security"]
    staObjNode[MESH_OBJ_ENCRYPTION]=bssNode["Encryption"]
    staObjNode[MESH_OBJ_CHANNEL]=radioNode[RADIO_CHANNEL]
    staObjNode[MESH_OBJ_PARENT_MAC]=WiFiSonNode[WIFISON_NODE_DEVICE_MAC]

    return staObjNode
end

function easyMeshTopologyInfoLib.getMeshTopologyNodes(topology_t)
   
    local topologyRoot = {}
    local WiFiSonResponse = {}
    WiFiSonResponse[WIFISON_NODE] = {}

    if ((topology_t == nil) or (topology_t[TOPOLOGY_INFO_NODE] == nil)) then
        return "ERROR", nil
    end

    topologyRoot = topology_t[TOPOLOGY_INFO_NODE]

    for meshDevice=1,#topologyRoot do
        -- save individaul mesh Devices info in the topology to a seperate Table
        meshNodes[meshDevice] = {}
        meshNodes[meshDevice] = topologyRoot[meshDevice]            -- topology_t["topology information"][i]
        currNode = meshNodes[meshDevice]
        if (meshDevice == CAP_NODE) then
            CAPNode = currNode                                      -- topology_t["topology information"][1] -- CAP Node is Always ONE
        end

        meshObjsCnt = meshObjsCnt + 1
        
        local meshObjNode = {}
        meshObjNode[MESH_OBJ_ID] = meshObjsCnt

        -- WiFiSon Processing Device Node
        -- Initialise WiFiSonNode entries
        local WiFiSonNode = {}

        if (currNode[DEVICE_ROLE] == "01") then
            WiFiSonNode[WIFISON_NODE_DEVICE_NAME] = ""
	    if(util.fileExists("/pfrm2.0/HW_JCO4032")) then
                    WiFiSonNode[WIFISON_NODE_MODEL_NUMBER] = "JCO4032"
            elseif(util.fileExists("/pfrm2.0/HW_JCOW407")) then
                    WiFiSonNode[WIFISON_NODE_MODEL_NUMBER] = "JCOW407"
            elseif(util.fileExists("/pfrm2.0/HW_JCOW402")) then
                    WiFiSonNode[WIFISON_NODE_MODEL_NUMBER] = "JCOW402"
            elseif(util.fileExists("/pfrm2.0/HW_JCOW401")) then
                    WiFiSonNode[WIFISON_NODE_MODEL_NUMBER] = "JCOW401"
            elseif(util.fileExists("/pfrm2.0/HW_JCOW404")) then
                    WiFiSonNode[WIFISON_NODE_MODEL_NUMBER] = "JCOW404"
            elseif(util.fileExists("/pfrm2.0/HW_JCOW403")) then
                    WiFiSonNode[WIFISON_NODE_MODEL_NUMBER] = "JCOW403"
            end
            WiFiSonNode[WIFISON_NODE_PARENT_MAC] = "00:00:00:00:00:00"

            WiFiSonNode["Device_Type"] = "CAP"
            meshObjNode[MESH_OBJ_GROUP] = CAP_GROUP
        
            WiFiSonNode["Device"] = {}
            WiFiSonNode["Device"]["Device_HWVersion"] = getDeviceHwVersion()
            WiFiSonNode["Device"]["Device_FWVersion"] = db.getAttribute ("system", "_ROWID_", "1", "firmwareVer") or ""
            WiFiSonNode["Device"]["Device_IPv4Address"] = getDeviceIPAddress()
            WiFiSonNode["Device"]["Device_IPv6Address"] = getDeviceIPV6Address() or ""
            WiFiSonNode["Device"]["Device_SN"] = getDeviceSerial()
	        --WiFiSonNode["Device"]["Device_Uplink"] = "Wired" 

        else
            WiFiSonNode[WIFISON_NODE_DEVICE_NAME] = ""
            WiFiSonNode[WIFISON_NODE_MODEL_NUMBER] = currNode["model number"] or ""
            WiFiSonNode[WIFISON_NODE_PARENT_MAC] = currNode[UPSTREAM_1905_DEVICE] or ""

            WiFiSonNode["Device_Type"] = "RE"
            meshObjNode[MESH_OBJ_GROUP] = AGENT_GROUP
            
            WiFiSonNode["Device"] = {}
            WiFiSonNode["Device"]["Device_HWVersion"] = ""
            WiFiSonNode["Device"]["Device_FWVersion"] = ""
            local deviceIpAddr = db.getAttribute("LanHosts" ,"MACAddress",string.lower(currNode[AL_MAC]),"IPAddress")            
            local deviceIpv6Addr = db.getAttribute("LanHosts" ,"MACAddress",string.lower(currNode[AL_MAC]),"IPv6Address")            
            WiFiSonNode["Device"]["Device_IPv4Address"] = deviceIpAddr or ""
            WiFiSonNode["Device"]["Device_IPv6Address"] = deviceIpv6Addr or ""
            WiFiSonNode["Device"]["Device_SN"] = currNode["model serial number"] or ""

	        --WiFiSonNode["Device"]["Device_Uplink"], WiFiSonNode["Device"]["SignalStrength"] = getDeviceUplinkSignalStrength(topology_t,currNode[AL_MAC])

        end
   
        WiFiSonNode[WIFISON_NODE_HOP_COUNT] = currNode[NODE_DISTANCE]
        WiFiSonNode[WIFISON_NODE_DEVICE_MAC] = currNode[AL_MAC] or ""

	local deviceName
	deviceName = db.getAttribute("easyMeshDevices", "macAddr", string.upper(WiFiSonNode[WIFISON_NODE_DEVICE_MAC]), "deviceName")
	if (deviceName ~= nil) then
	    WiFiSonNode[WIFISON_NODE_DEVICE_NAME] = deviceName
	end

        WiFiSonNode[WIFISON_NODE_SIGNAL_STRENGTH] = ""
        WiFiSonNode[WIFISON_NODE_DEVICE_UPLINK] = ""
        WiFiSonNode[WIFISON_NODE_DEVICE_PORT] = ""
        WiFiSonNode[WIFISON_NODE_COMMON_NODE] = {}

        if (currNode[DEVICE_ROLE] == "01") then
            WiFiSonNode[WIFISON_NODE_DEVICE_UPLINK] = "Wired"
        end

        meshObjNode[MESH_OBJ_LABEL]=WiFiSonNode[WIFISON_NODE_DEVICE_NAME] .. "\n" .. "AL_MAC-" .. WiFiSonNode[WIFISON_NODE_DEVICE_MAC]
        meshObjNode[MESH_OBJ_TITLE]=meshObjNode[MESH_OBJ_LABEL]
        meshObjNode[MESH_OBJ_MAC]=WiFiSonNode[WIFISON_NODE_DEVICE_MAC]
        meshObjNode[MESH_OBJ_PARENT_MAC]=WiFiSonNode[WIFISON_NODE_PARENT_MAC]
        table.insert(meshTopology["nodes"],meshObjNode)

            --[[
            for field, value in pairs(currNode) do
                print(field .. string.rep("\t",3), value)
            end
            ]]--

        -- [Mesh Device][Radio Info]  Node Parsing
        if (currNode[RADIO_INFO_NODE] ~= nil) then                   -- topology_t["topology information"][i]["Radio Info"]
        
            numOfRadios =  #currNode[RADIO_INFO_NODE]    

            if (numOfRadios > 0) then
                WiFiSonNode[WIFISON_NODE_COMMON_NODE][WIFISON_NODE_RADIO_NODE] = {}
            end

            for radio=1,numOfRadios do

                local WiFiSonRadioNode = {}

                radioNode = currNode[RADIO_INFO_NODE][radio]        -- topology_t["topology information"][i]["Radio Info"][i]
                    --[[
                    for field, value in pairs(radioNode) do
                        print(field .. string.rep("\t",3), value)
                    end
                    ]]--

                if(currNode[DEVICE_ROLE] == "01") then
                    if (radioNode[RADIO_WIRELESS_MODE] == "2") then
                        local radioInfoNode = {} 
                        radioInfoNode[1] ={}
                        radioInfoNode[1][WIFISON_NODE_RADIO_TYPE] = WIFISON_RADIO_24G_STR
                        radioInfoNode[1][WIFISON_NODE_RADIO_BASE_MAC] = ifDevLib.getMac("wl0") or ""
                        radioInfoNode[1][WIFISON_AP_NAME] = "1"
                        radioInfoNode[1][WIFISON_AP_ENABLE] = "True" or ""
                        table.insert(WiFiSonNode[WIFISON_NODE_COMMON_NODE][WIFISON_NODE_RADIO_NODE],radioInfoNode[1])
                        WiFiSonRadioNode[WIFISON_NODE_RADIO_TYPE] = WIFISON_RADIO_24G_STR
                        WiFiSonRadioNode[WIFISON_NODE_RADIO_BASE_MAC] = ifDevLib.getMac("wl0") or ""
                        WiFiSonRadioNode[WIFISON_AP_NAME] = "0"
                        WiFiSonRadioNode[WIFISON_AP_ENABLE] = VapEnableTest("Jio_1") or ""
                    else
                        local radioInfoNode = {}
                        radioInfoNode[1]={}
                        radioInfoNode[1][WIFISON_NODE_RADIO_TYPE] = WIFISON_RADIO_5G_STR
                        radioInfoNode[1][WIFISON_NODE_RADIO_BASE_MAC] = ifDevLib.getMac("wl1.1") or ""
                        radioInfoNode[1][WIFISON_AP_NAME] = "1"
                        radioInfoNode[1][WIFISON_AP_ENABLE] = "True" or ""
                        table.insert(WiFiSonNode[WIFISON_NODE_COMMON_NODE][WIFISON_NODE_RADIO_NODE], radioInfoNode[1])
                        WiFiSonRadioNode[WIFISON_NODE_RADIO_TYPE] = WIFISON_RADIO_5G_STR
                        WiFiSonRadioNode[WIFISON_NODE_RADIO_BASE_MAC] = ifDevLib.getMac("wl1") or ""
                        WiFiSonRadioNode[WIFISON_AP_NAME] = "0"
                        WiFiSonRadioNode[WIFISON_AP_ENABLE] = VapEnableTest("Jio_4") or ""
                    end
                else
                    if (tonumber(radioNode[RADIO_WIRELESS_MODE]) == 2) then
                        local radioInfoNode = {}                        
                        radioInfoNode[1] ={}
                        radioInfoNode[1][WIFISON_NODE_RADIO_TYPE] = WIFISON_RADIO_24G_STR
                        radioInfoNode[1][WIFISON_AP_NAME] = "1"
                        radioInfoNode[1][WIFISON_NODE_RADIO_BASE_MAC] = radioNode[RADIO_BSSINFO_NODE][1][MESH_OBJ_BSSID] or ""
                        table.insert(WiFiSonNode[WIFISON_NODE_COMMON_NODE][WIFISON_NODE_RADIO_NODE],radioInfoNode[1])
                        WiFiSonRadioNode[WIFISON_NODE_RADIO_TYPE] = WIFISON_RADIO_24G_STR
                        WiFiSonRadioNode[WIFISON_AP_NAME] = "0"
                    else
                        local radioInfoNode = {}                        
                        radioInfoNode[1] ={}
                        radioInfoNode[1][WIFISON_NODE_RADIO_TYPE] = WIFISON_RADIO_5G_STR
                        radioInfoNode[1][WIFISON_AP_NAME] = "1"
                        radioInfoNode[1][WIFISON_NODE_RADIO_BASE_MAC] = radioNode[RADIO_BSSINFO_NODE][1][MESH_OBJ_BSSID] or ""
                        table.insert(WiFiSonNode[WIFISON_NODE_COMMON_NODE][WIFISON_NODE_RADIO_NODE],radioInfoNode[1])
                        radioInfoNode[2] ={}
                        if(currNode["BH Interface(APCLI)"] ~= nil) then
                            if(currNode["BH Interface(APCLI)"][1] ~= nil) then
                                radioInfoNode[2][WIFISON_NODE_RADIO_BASE_MAC] = currNode["BH Interface(APCLI)"][1]["MAC address"] or ""
                            else
                                radioInfoNode[2][WIFISON_NODE_RADIO_BASE_MAC] = ""
                            end
                        else
                            radioInfoNode[2][WIFISON_NODE_RADIO_BASE_MAC] = ""
                        end
                        radioInfoNode[2][WIFISON_AP_NAME] = "2"
                        table.insert(WiFiSonNode[WIFISON_NODE_COMMON_NODE][WIFISON_NODE_RADIO_NODE],radioInfoNode[2])
                        WiFiSonRadioNode[WIFISON_NODE_RADIO_TYPE] = WIFISON_RADIO_5G_STR
                        WiFiSonRadioNode[WIFISON_AP_NAME] = "0"
                    end
                    WiFiSonRadioNode[WIFISON_NODE_RADIO_BASE_MAC] = radioNode[RADIO_IDENTIFIER] or ""
                end
                
                if (radioNode[RADIO_BSSINFO_NODE] ~= nil) then          -- topology_t["topology information"][i]["Radio Info"][i]["BSSINFO"]
                
                    numOfBssPerRadio = #radioNode[RADIO_BSSINFO_NODE]   

                    for bss=1,numOfBssPerRadio do
                        bssNode = radioNode[RADIO_BSSINFO_NODE][bss]    -- topology_t["topology information"][i]["Radio Info"][i]["BSSINFO"][i]
                            --[[
                            for field, value in pairs(bssNode) do
                                print(field .. string.rep("\t",3), value)
                            end
                            ]]--

                        --[[COMMENT: topology_t["topology information"][i]["Radio Info"][i]["BSSINFO"][i]["connected sta info"]  ]]--
                        if (bssNode[BSSNODE_STAINFO_NODE] ~= nil) then
                            numOfSTAsPerBss = #bssNode[BSSNODE_STAINFO_NODE]
                            for STA=1,numOfSTAsPerBss do
                                STANode = bssNode[BSSNODE_STAINFO_NODE][STA]
                                    --[[
                                    for field, value in pairs (STANode) do
                                        print(field .. string.rep("\t",3), value)
                                    end
                                    ]]--
                                if (STANode[BH_STA] ~= "Yes") then
                                    local staObjNode = {}
                                    meshObjsCnt = meshObjsCnt + 1
                                    --[[
                                    staObjNode[MESH_OBJ_ID] = meshObjsCnt
                                    staObjNode[MESH_OBJ_GROUP] = STA_GROUP
                                    staObjNode[MESH_OBJ_LABEL]="STA\n" .. "AL_MAC-" .. string.upper(STANode[STA_MAC])
                                    staObjNode[MESH_OBJ_TITLE]=staObjNode[MESH_OBJ_LABEL]
                                    staObjNode[MESH_OBJ_MAC]=string.upper(STANode[STA_MAC])
                                    staObjNode[MESH_OBJ_PARENT_MAC]=WiFiSonNode[WIFISON_NODE_DEVICE_MAC]
                                    ]]--
                                    staObjNode = easyMeshTopologyInfoLib.getStaNodeInfo(WiFiSonNode, radioNode, bssNode, STANode, meshObjsCnt)
                                    table.insert(meshTopology["nodes"],staObjNode)
                                
                                    local staEdgeNode = {}
                                
                                    staEdgeNode[PARENT_EDGE]=meshObjNode[MESH_OBJ_ID]
                                    staEdgeNode[CHILD_EDGE]=staObjNode[MESH_OBJ_ID]
                                    table.insert(meshTopology["edges"],staEdgeNode)
                            
                                end
                            end
                        end
                    end
                end
                table.insert(WiFiSonNode[WIFISON_NODE_COMMON_NODE][WIFISON_NODE_RADIO_NODE], radio, WiFiSonRadioNode)
            end
        end
   
       WiFiSonNode["Clients"] = {}
       local staCount = 0
    
       for i,edge in pairs(meshTopology["edges"]) do
         if (tonumber(edge[PARENT_EDGE]) == meshObjNode[MESH_OBJ_ID]) then
              for i,node in pairs(meshTopology["nodes"]) do
                  if (node[MESH_OBJ_GROUP] == STA_GROUP) then
                      if (edge[CHILD_EDGE] == node[MESH_OBJ_ID]) then
                          local client_info = getClientInfo(node[MESH_OBJ_MAC])
                          if (client_info ~= nil) then
                              local staAppInfo = getClientAppInfo(client_info, node)
                              if (staAppInfo ~= nil) then
                                  table.insert(WiFiSonNode["Clients"],staAppInfo)
                                   staCount = staCount+1
                              end 
                          end        
                      end         
                  end     
              end              
          end                             
      end                                 
                               
                                          
    WiFiSonNode["Client_Numbers"] = tostring(staCount)
 


        -- [Mesh Device][BH Interface(APCLI)] Node Parsing
        -- The Presence of this node suggests that this device is connected to its
        -- parent over this BH AP CLI Interface, and the BH Link is active for 1905
        -- messages exchange.
        if (currNode[BH_IFACE_APCLI_NODE] ~= nil) then           -- topology_t["topology information"][i]["BH Interface(APCLI)"]
            numOfBHApCliIface = #currNode[BH_IFACE_APCLI_NODE]
        
            for BHApCliIface=1,numOfBHApCliIface do
            
                BHApCliIfaceNode = currNode[BH_IFACE_APCLI_NODE][BHApCliIface]   -- topology_t["topology information"][i]["BH Interface(APCLI)"][i]
                    --[[
                    for field, value in pairs (BHApCliIfaceNode) do
                        print(field .. string.rep("\t",3), value)
                    end
                    ]]--
            end
        end

    
        -- [Mesh Device][BH Info] Node Parsing
        if (currNode[BH_INFO_NODE] ~= nil) then           -- topology_t["topology information"][i]["BH Info"]
            numOfBHInfos = #currNode[BH_INFO_NODE]

            for BHinfo=1,numOfBHInfos do
            
                BHInfoNode = currNode[BH_INFO_NODE][BHinfo]   -- topology_t["topology information"][i]["BH Info"][i]
                    --[[
                    for field, value in pairs (BHInfoNode) do
                        print(field .. string.rep("\t",3), value)
                    end
                    ]]--
        	WiFiSonNode[WIFISON_NODE_SIGNAL_STRENGTH] = BHInfoNode[BH_INFO_NODE_RSSI]
        	WiFiSonNode[WIFISON_NODE_DEVICE_UPLINK] = BHInfoNode[BH_MEDIUM_TYPE]
        	WiFiSonNode[WIFISON_NODE_DEVICE_PORT] = ""
            end
        end


        -- [Mesh Device][BH Interface(AP)] Node Parsing
        -- The Presence of this Node gives the info of whether if any child nodes are connected to this
        -- device over this BH AP Interface. And the BH Link is active for 1905
        -- messages exchange.
        if (currNode[BH_IFACE_AP_NODE] ~= nil) then                   -- topology_t["topology information"][i]["BH Interface(AP)"]
            numOfBHAPIface = #currNode[BH_IFACE_AP_NODE]

            for BHAPIface=1,numOfBHAPIface do
            
                BHAPIfaceNode = currNode[BH_IFACE_AP_NODE][BHAPIface]   -- topology_t["topology information"][i]["BH Interface(AP)"][i]
                    --[[
                    for field, value in pairs (BHAPIfaceNode) do
                        print(field .. string.rep("\t",3), value)
                    end
                    ]]--
            end
        end


        -- [Mesh Device][backhaul link metrics] Node Parsing
        -- The Presence of this Node gives the info of who are the child devices of this
        -- mesh device.
        if (currNode[BH_LINK_METRICS_NODE] ~= nil) then                   -- topology_t["topology information"][i]["backhaul link metrics"]
             
            numOfBHLinks = #currNode[BH_LINK_METRICS_NODE]

            for BHLink=1,numOfBHLinks do
                BHLinkNode = currNode[BH_LINK_METRICS_NODE][BHLink]   -- topology_t["topology information"][i]["backhaul link metrics"][i]
                    --[[
                    for field, value in pairs (BHLinkNode) do
                        print(field .. string.rep("\t",3), value)
                    end
                    ]]--

                if( BHLinkNode[BH_METRICS_NODE] ~= nil ) then       -- topology_t["topology information"][i]["backhaul link metrics"][i]["metrics"]
                
                    numOfBHMetrics = #BHLinkNode[BH_METRICS_NODE]
                    for BHMetrics=1,numOfBHMetrics do
                        BHMetricNode = BHLinkNode[BH_METRICS_NODE][BHMetrics]
                            --[[
                            for field, value in pairs (BHMetricNode) do
                                print(field .. string.rep("\t",3), value)
                            end
                            ]]--
                    end
                end
            end
        end


        -- [Mesh Device][backhaul link metrics] Node Parsing
        if (currNode[CLIENTS_INFO_NODE] ~= nil) then                   -- topology_t["topology information"][i]["Other Clients Info"]
        
            numOfOtherClients = tostring(#currNode[CLIENTS_INFO_NODE])

            for otherClient=1,numOfOtherClients do
                BHAPIfaceNode = currNode[CLIENTS_INFO_NODE][otherClient]   -- topology_t["topology information"][i]["Other Clients Info"][i]
                    --[[
                    for field, value in pairs (BHAPIfaceNode) do
                        print(field .. string.rep("\t",3), value)
                    end
                    ]]--
            end
        end

        table.insert(WiFiSonResponse[WIFISON_NODE], meshDevice, WiFiSonNode)
    end

    return "OK", WiFiSonResponse, meshTopology
end

function easyMeshTopologyInfoLib.getEasyMeshTopologyNodesAndEdges()
    local json = require ("teamf1lualib/json")

	if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then
		TOPOLOGY_DUMP_GENERATE_CMD = "/bin/sh /pfrm2.0/bin/brcmGenerateDump.sh"
	else
		TOPOLOGY_DUMP_GENERATE_CMD = "/userfs/bin/mapd_cli /tmp/mapd_ctrl dump_topology_v1"
	end
    TOPOLOGY_DUMP_FILE = "/tmp/dump.txt"
    INTERNET_FILE_CHECK = "/tmp/gponFailed"

    local status
    local topology_t
    local meshTopology_t
    local WiFiSonResponse_t
    local internetStatus
    local internetNode = {}
    -- generate topology dump.txt by executing below command.
    util.runShellCmd(TOPOLOGY_DUMP_GENERATE_CMD, "/dev/null")

    if (not (util.fileExists (TOPOLOGY_DUMP_FILE))) then
        return "ERROR", "FAILED_TO_GENERATE_TOPOLOGY"
    end

    -- convert the generated topology dump.txt file to a Lua Table
    topology_t = json.decode(util.fileToString (TOPOLOGY_DUMP_FILE))

    if (topology_t == nil) then
        return "ERROR", "FAILED_TO_DECODE_TOPOLOGY"
    end

    status, WiFiSonResponse_t, meshTopology_t = easyMeshTopologyInfoLib.getMeshTopologyNodes(topology_t)
    if ((status ~= "OK") or (meshTopology_t == nil)) then
        return "ERROR", "FAILED_TO_GET_TOPOLOGY"
    end

    --[[ Fill the complete edges here ]]--
    for i, row in pairs(meshTopology_t["nodes"]) do
        if (row[MESH_OBJ_GROUP] == AGENT_GROUP) then
            for itr, node in pairs (meshTopology_t["nodes"]) do
                if (row[MESH_OBJ_PARENT_MAC] == node[MESH_OBJ_MAC]) then
                    local meshEdge_t = {}
                    meshEdge_t[PARENT_EDGE] = node[MESH_OBJ_ID]
                    meshEdge_t[CHILD_EDGE] = row[MESH_OBJ_ID]
                    table.insert(meshTopology_t["edges"],meshEdge_t)
                end
            end
        end
    end

    --[[ Now fill the Internet Node and edge details to meshTopology ]]--
    internetNode[MESH_OBJ_ID] = 0 -- Internet Object ID.
    internetNode[MESH_OBJ_LABEL]= "Internet"
    internetNode[MESH_OBJ_TITLE]= "Internet"
    internetNode[MESH_OBJ_MAC]= ""
    internetNode[MESH_OBJ_PARENT_MAC]= ""
    
    if (util.fileExists (INTERNET_FILE_CHECK)) then
    	internetNode[MESH_OBJ_GROUP] = "-1"
    else
        internetNode[MESH_OBJ_GROUP] = INTERNET_GROUP
    end

    table.insert(meshTopology_t["nodes"],internetNode)

    local internetEdge_t = {}
    internetEdge_t[PARENT_EDGE] = internetNode[MESH_OBJ_ID]
    internetEdge_t[CHILD_EDGE] = 1 -- CAP Object ID.
    table.insert(meshTopology_t["edges"],internetEdge_t)

    return "OK", "TOPOLOGY_GET_SUCCESS", meshTopology_t
end

