-- tr69HealthMonitor.lua - for self test diagnostics
--
-- Copyright (c) 2017, TeamF1 Networks Pvt. Ltd.
-- (Subsidiary of D-Link India)
--
-- modification history
-- --------------------
-- 01h, 13Feb19, mou  changes for SPR 65387
-- 01g, 15Nov18, swr  changes for SPR 64848(wget page load time issue)
-- 01f, 18Apr18, swr  changes for SPR 63646(csv result format)
-- 01e, 17Apr18, swr  changes for SPR 63646(csv result format)
-- 01d, 19Mar18, swr  changes for SPR 63393(traceroute timeout fix)
-- 01c, 17Oct17, swr  changes for SPR 62549
-- 01b, 08Aug17, swr  changes for SPR 60819
-- 01a, 08Aug17, swr  written, changes for SPR 60819(health monitoring)


--package tr69HealthMonitor
tr69HealthMonitor = {}
tr69HealthMonitor.statResultsFile = "/tmp/statResultsFile.txt" 
tr69HealthMonitor.echo = "/bin/echo" 
tr69HealthMonitor.cat = "/bin/cat" 
tr69HealthMonitor.lua = "/pfrm2.0/bin/lua" 
tr69HealthMonitor.cliLua = "/tmp/trcli.lua" 
tr69HealthMonitor.successFile = "/tmp/hm_success_result.txt" 
tr69HealthMonitor.errorFile = "/tmp/hm_error_result.txt" 
tr69HealthMonitor.speed = "/tmp/speed.txt" 
tr69HealthMonitor.pageLoadTime = "/tmp/pageLoadTime.txt" 
tr69HealthMonitor.topCommand = "top -d 1 -n 1" 
tr69HealthMonitor.psCommand = "ps" 
tr69HealthMonitor.freeCommand = "free" 
tr69HealthMonitor.udpClientCommand = "/pfrm2.0/bin/udpClient" 
tr69HealthMonitor.udpTimeout = "1" 
tr69HealthMonitor.udpDSCP = "0" 
tr69HealthMonitor.udpDataBlockSize = "24" 
tr69HealthMonitor.pingCommand = "ping -c 5" 
tr69HealthMonitor.ping6Command = "ping6 -c 5" 
tr69HealthMonitor.traceRouteCommand = "/usr/bin/traceroute -m 20 -w 1" 
tr69HealthMonitor.traceRoute6Command = "/usr/bin/traceroute -6 -m 20 -w 1" 
tr69HealthMonitor.nsLookUpCommand = "/pfrm2.0/bin/nslookup -sil -tf -q=any " 
tr69HealthMonitor.wgetFile = "/tmp/cpe3/wgetFile" 
tr69HealthMonitor.wgetCommand = "/pfrm2.0/bin/wget --no-check-certificate -O "..tr69HealthMonitor.wgetFile 
tr69HealthMonitor.speedResultBin = "/pfrm2.0/bin/nvelocity"
tr69HealthMonitor.speedResultBin2 = "/pfrm2.0/bin/nvelocity2"
tr69HealthMonitor.speedScript = "/pfrm2.0/bin/speedtest.sh"
tr69HealthMonitor.fileSize = "/tmp/wgetFileSize"
tr69HealthMonitor.maxFileSize = "/tmp/trDiaMaxFileSize"
tr69HealthMonitor.curlBinary = "/pfrm2.0/bin/curl"
tr69HealthMonitor.defaulltMaxfileSize = 20*1024*1024 --20MB
tr69HealthMonitor.minFreeMemFile = "/proc/sys/vm/min_free_kbytes"
tr69HealthMonitor.hg261gu = "/pfrm2.0/HW_HG261GU"
tr69HealthMonitor.brcm = "/pfrm2.0/BRCMJCO300"
tr69HealthMonitor.tcpspdtest = "/pfrm2.0/BRCM_TCPSPDTEST"
tr69HealthMonitor.userAuthVerifyBin = "/pfrm2.0/bin/userAuthVerify "

--require
require "teamf1lualib/utilsCLI"
require "teamf1lualib/dot11ShowCLI"
require "teamf1lualib/ifDevCLI"
require "teamf1lualib/tr69Glue"

-------------------------------------------------------------------------------
-- @name : tr69HealthMonitor.download
--
-- @description : executes the commands for health monitoring and creates a file
-- which can later be collected from upload RPC
--
-- @return : 
--
function tr69HealthMonitor.download (filename, resultsFileName)
    tr69Glue.tf1Dbg("Entering tr69Glue.healthMonitorDownload..")
    
    local t1 = {}
    local t2 = {}
    local status = OK

    tr69HealthMonitor.hmResultsFile = "/tmp/cpe3/"..resultsFileName
    local file = io.open (filename, "r")
    if (file == nil) then
        status = ERROR
        return status
    end
    file:close()

    tr69Glue.tf1Dbg("filename = "..filename)
    tr69Glue.tf1Dbg("tr69HealthMonitor.hmResultsFile = "..tr69HealthMonitor.hmResultsFile)

    status = tr69HealthMonitor.hmExecuteCmds(filename, tr69HealthMonitor.hmResultsFile)

    tr69Glue.tf1Dbg("Leaving tr69Glue.healthMonitorDownload with status = "..status)
    return status
end

-------------------------------------------------------------------------------
-- @name : tr69HealthMonitor.removeFiles
--
-- @description : removes files after executing commands
--
-- @return : 
--
function tr69HealthMonitor.removeFiles()
    --remove files
    os.remove(tr69HealthMonitor.successFile)
    os.remove(tr69HealthMonitor.errorFile)
    os.remove(tr69HealthMonitor.pageLoadTime) 
    os.remove(tr69HealthMonitor.wgetFile)
    os.remove(tr69HealthMonitor.fileSize)
    os.remove(tr69HealthMonitor.statResultsFile)
    os.remove(tr69HealthMonitor.cliLua)
end

-------------------------------------------------------------------------------
-- @name : tr69HealthMonitor.fileSizeCheck
--
-- @description : This function checks if file size is within limits and if CPE
-- has enough memory to download the file
--
-- @return : status (success:OK, error:ERROR)
--
function tr69HealthMonitor.fileSizeCheck (URL)
    local t1 = {}
    local status = OK
    local fileSize = nil
    local file1 = nil
    local file2 = nil
    local file3 = nil
    local fileSizeCmd = ""
    local freeMem = nil
    local minFreeMem = nil
  
    file1 = io.open (tr69HealthMonitor.maxFileSize,"r");
    if(file1 ~= nil) then
        tr69HealthMonitor.defaulltMaxfileSize = file1:read("*line")
        tr69HealthMonitor.defaulltMaxfileSize = tr69HealthMonitor.defaulltMaxfileSize*1024*1024
        file1:close()
    end
    tr69Glue.tf1Dbg("tr69HealthMonitor.defaulltMaxfileSize = " .. tr69HealthMonitor.defaulltMaxfileSize)

    -- get the file size 
    fileSizeCmd = tr69HealthMonitor.curlBinary.." -gsIk "..URL
    util.runShellCmd(fileSizeCmd, tr69HealthMonitor.fileSize, nil, nil)
    
    file2 = io.open (tr69HealthMonitor.fileSize, "r")
    if (file2 ~= nil) then
        for line in file2:lines () do
            if (string.find (line, "Content%-Length:")) then
                t1 = util.split(line, " ")
                fileSize = t1[2]
                fileSize = tonumber(fileSize)
                break;
            end
        end
        file2:close()
    end
 
    freeMemStatus, freeMem = util.freeMemGet()
    tr69Glue.tf1Dbg("freeMem in bytes = " .. freeMem)
    if(freeMem ~= nil and freeMem ~= "") then
        freeMem = tonumber(freeMem)
        freeMem = freeMem*1024

        file3 = io.open (tr69HealthMonitor.minFreeMemFile,"r");
        if(file3 ~= nil) then
            minFreeMem = file3:read("*line")
            minFreeMem = tonumber(minFreeMem)
            minFreeMem = minFreeMem*1024
            tr69Glue.tf1Dbg("minFreeMem in bytes = " .. minFreeMem)
            file3:close()
        end

        if(minFreeMem ~= nil and minFreeMem ~= "") then
            tr69Glue.tf1Dbg("freeMem + minFreeMem in bytes = " .. (freeMem + minFreeMem))
            -- check if server has sent the "Content-Length" or not
            if(fileSize ~= nil) then
                tr69Glue.tf1Dbg("fileSize in bytes = " .. fileSize)
                -- check if cpe is having enough free mem to download the file
                if (fileSize > (freeMem + minFreeMem) or fileSize > tr69HealthMonitor.defaulltMaxfileSize) then
                    status = ERROR
                end
            else
                -- if max free mem is not available
                if (tr69HealthMonitor.defaulltMaxfileSize > (freeMem + minFreeMem)) then
                    status = ERROR
                end
            end
        else
            status = ERROR
        end
    else
        status = ERROR
    end

    return status
end

function tr69HealthMonitor.runShellCmd(command, outputFile, errorFile, options)        
    local charsToReplace = ";`$&|><"
    -- command = string.gsub(command, "&", "\\&")
    
    if (options) then
        command = command .. " " .. options
        end

    if (outputFile) then
        command = command .. " >" .. string.gsub(outputFile, "[" .. charsToReplace .. "]", "")
    end

    if (errorFile) then
        command = command .. " 2>" .. string.gsub(errorFile, "[" .. charsToReplace .. "]", "")
    end

    return os.execute (command)
end

-------------------------------------------------------------------------------
-- @name : tr69HealthMonitor.hmExecuteCmds
--
-- @description : executes the commands for health monitoring
--
-- @return : 
--
function tr69HealthMonitor.hmExecuteCmds(filename, hmResultsFile)
    local status = OK

    local file = io.open (filename, "r")
    if (file == nil) then
        status = ERROR
        return status
    end
   
    tr69HealthMonitor.hmResultsFile = hmResultsFile
    for line in file:lines () do
        --remove files
        tr69HealthMonitor.removeFiles()

        if ((string.sub(line, 1, -1)) == "show lan clients") then
            -- get lan clients
            os.execute(tr69HealthMonitor.echo.." 'LANCLIENTS,MAC,IPv4,IPv6' >> "..tr69HealthMonitor.hmResultsFile)

            local lanClientsTab = db.getTable("lanHosts", false)
            for k,v in pairs(lanClientsTab) do
                os.execute(tr69HealthMonitor.echo.." ,"..v["MACAddress"]..","..v["IPAddress"]..","..v["IPv6Address"].." >> "..tr69HealthMonitor.hmResultsFile)
            end
        elseif ((string.sub(line, 1, -1)) == "show lan stats") then
            -- get lan stats
            os.execute(tr69HealthMonitor.echo.." 'LAN_STATS,OUTPUT,,' >> "..tr69HealthMonitor.hmResultsFile)
            
            os.execute(tr69HealthMonitor.echo.." 'require \"teamf1lualib/tr69HealthMonitor\"' > "..tr69HealthMonitor.cliLua)
            os.execute(tr69HealthMonitor.echo.." 'lanStatsGet()' >> "..tr69HealthMonitor.cliLua)
            os.execute(tr69HealthMonitor.lua.." "..tr69HealthMonitor.cliLua.." > "..tr69HealthMonitor.statResultsFile)
            os.execute(tr69HealthMonitor.echo.." -n ,'\"' >> "..tr69HealthMonitor.hmResultsFile)
            os.execute(tr69HealthMonitor.cat.." "..tr69HealthMonitor.statResultsFile.." >> "..tr69HealthMonitor.hmResultsFile)
            os.execute(tr69HealthMonitor.echo.." '\",,' >> "..tr69HealthMonitor.hmResultsFile)
        elseif ((string.sub(line, 1, -1)) == "show wlan clients" and ((not(util.fileExists(tr69HealthMonitor.hg261gu))) or (not(util.fileExists(tr69HealthMonitor.hg261gu)))) ) then
            -- get wlan clients
            os.execute(tr69HealthMonitor.echo.." 'WLAN_CLIENTS,AP_NAME,MAC,SECURITY,ENCRYPTION,AUTH,TIME_CONNECTED' >> "..tr69HealthMonitor.hmResultsFile)

            local errorFlag, statusCode, dot11STATab = gui.wireless.clients.get()
            for k,v in pairs(dot11STATab) do
                os.execute(tr69HealthMonitor.echo.." ,"..v["vapName"]..","..v["macAddress"]..","..v["security"]..","..v["cipher"]..","..v["authentication"]..", '\"'"..v["timeConnected"].."'\"' >> "..tr69HealthMonitor.hmResultsFile)
            end
        elseif ((string.sub(line, 1, -1)) == "show wlan stats" and ((not(util.fileExists(tr69HealthMonitor.hg261gu))) or (not(util.fileExists(tr69HealthMonitor.hg261gu))))) then
            -- get wlan stats
            os.execute(tr69HealthMonitor.echo.." 'WLAN_STATS,OUTPUT,,' >> "..tr69HealthMonitor.hmResultsFile)
            
            os.execute(tr69HealthMonitor.echo.." 'require \"teamf1lualib/tr69HealthMonitor\"' > "..tr69HealthMonitor.cliLua)
            os.execute(tr69HealthMonitor.echo.." 'dot11WlanStatsGet()' >> " ..tr69HealthMonitor.cliLua)
            os.execute(tr69HealthMonitor.lua.." "..tr69HealthMonitor.cliLua.." > "..tr69HealthMonitor.statResultsFile)
            os.execute(tr69HealthMonitor.echo.." -n ,'\"' >> "..tr69HealthMonitor.hmResultsFile)
            os.execute(tr69HealthMonitor.cat.." "..tr69HealthMonitor.statResultsFile.." >> "..tr69HealthMonitor.hmResultsFile)
            os.execute(tr69HealthMonitor.echo.." '\",,' >> "..tr69HealthMonitor.hmResultsFile)
        elseif ((string.sub(line, 1, -1)) == "show top_processess") then
            -- get top output
            os.execute(tr69HealthMonitor.echo.." 'TOP_PROC,OUTPUT,,' >> "..tr69HealthMonitor.hmResultsFile)

            util.runShellCmd(tr69HealthMonitor.topCommand, tr69HealthMonitor.successFile, nil,  nil)
            if(util.fileExists(tr69HealthMonitor.successFile)) then
                os.execute(tr69HealthMonitor.echo.." -n ,'\"' >> "..tr69HealthMonitor.hmResultsFile)
                os.execute(tr69HealthMonitor.cat.." "..tr69HealthMonitor.successFile.." >> "..tr69HealthMonitor.hmResultsFile)
                os.execute(tr69HealthMonitor.echo.." '\",,' >> "..tr69HealthMonitor.hmResultsFile)
            else
                os.execute(tr69HealthMonitor.echo.." ',Failed to get the top output' >> "..tr69HealthMonitor.hmResultsFile)
            end
        elseif ((string.sub(line, 1, -1)) == "show process_status") then
            -- get ps output
            os.execute(tr69HealthMonitor.echo.." 'PROC_STATUS,OUTPUT,,' >> "..tr69HealthMonitor.hmResultsFile)

            util.runShellCmd(tr69HealthMonitor.psCommand, tr69HealthMonitor.successFile, nil,  nil)
            if(util.fileExists(tr69HealthMonitor.successFile)) then
                os.execute(tr69HealthMonitor.echo.." -n ,'\"' >> "..tr69HealthMonitor.hmResultsFile)
                os.execute(tr69HealthMonitor.cat.." "..tr69HealthMonitor.successFile.." >> "..tr69HealthMonitor.hmResultsFile)
                os.execute(tr69HealthMonitor.echo.." '\",,' >> "..tr69HealthMonitor.hmResultsFile)
            else
                os.execute(tr69HealthMonitor.echo.." ',Failed to get the ps output' >> "..tr69HealthMonitor.hmResultsFile)
            end
        elseif ((string.sub(line, 1, -1)) == "show memory_status") then
            -- get memory status
            os.execute(tr69HealthMonitor.echo.. " 'MEM_STATUS,OUTPUT,,' >> " ..tr69HealthMonitor.hmResultsFile)

            util.runShellCmd(tr69HealthMonitor.freeCommand, tr69HealthMonitor.successFile, nil,  nil)
            if(util.fileExists(tr69HealthMonitor.successFile)) then
                os.execute(tr69HealthMonitor.echo.." -n ,'\"' >> "..tr69HealthMonitor.hmResultsFile)
                os.execute(tr69HealthMonitor.cat.." "..tr69HealthMonitor.successFile.." >> "..tr69HealthMonitor.hmResultsFile)
                os.execute(tr69HealthMonitor.echo.." '\",,' >> "..tr69HealthMonitor.hmResultsFile)
            else
                os.execute(tr69HealthMonitor.echo.." ',Failed to get the memory output' >> "..tr69HealthMonitor.hmResultsFile)
            end
        elseif (string.find (line, "show ping_result")) then
            -- get ping results
            os.execute(tr69HealthMonitor.echo.. " 'PING_RES,OUTPUT,,' >> " ..tr69HealthMonitor.hmResultsFile)

            local t1 = util.split(line, " ")
            local hostname = t1[3]
            local noOfColumns = table.getn(t1)

            if(hostname ~= nil and hostname ~= "" and noOfColumns == 3) then
                local cmd = tr69HealthMonitor.pingCommand.." "..hostname
                local stat = util.runShellCmd(cmd, tr69HealthMonitor.successFile, tr69HealthMonitor.errorFile,  nil)
                if(stat == 0) then
                    os.execute(tr69HealthMonitor.echo.." -n ,'\"' >> "..tr69HealthMonitor.hmResultsFile)
                    os.execute(tr69HealthMonitor.cat.." "..tr69HealthMonitor.successFile.." >> "..tr69HealthMonitor.hmResultsFile)
                    os.execute(tr69HealthMonitor.echo.." '\",,' >> "..tr69HealthMonitor.hmResultsFile)
                else
                    os.execute(tr69HealthMonitor.echo.." ',Error_CannotResolveHostName' >> "..tr69HealthMonitor.hmResultsFile)
                end
            else
                os.execute(tr69HealthMonitor.echo.." ',Invalid command syntax' >> "..tr69HealthMonitor.hmResultsFile)
            end
        elseif (string.find (line, "show ping6_result")) then
            -- get ping6 results
            os.execute(tr69HealthMonitor.echo.. " 'PING6_RES,OUTPUT,,' >> " ..tr69HealthMonitor.hmResultsFile)

            local t1 = util.split(line, " ")
            local hostname = t1[3]
            local noOfColumns = table.getn(t1)

            if(hostname ~= nil and hostname ~= "" and noOfColumns == 3) then
                local cmd = tr69HealthMonitor.ping6Command.." "..hostname
                local stat = util.runShellCmd(cmd, tr69HealthMonitor.successFile, tr69HealthMonitor.errorFile,  nil)
                if(stat == 0) then
                    os.execute(tr69HealthMonitor.echo.." -n ,'\"' >> "..tr69HealthMonitor.hmResultsFile)
                    os.execute(tr69HealthMonitor.cat.." "..tr69HealthMonitor.successFile.." >> "..tr69HealthMonitor.hmResultsFile)
                    os.execute(tr69HealthMonitor.echo.." '\",,' >> "..tr69HealthMonitor.hmResultsFile)
                else
                    os.execute(tr69HealthMonitor.echo.." ',Error_CannotResolveHostName' >> "..tr69HealthMonitor.hmResultsFile)
                end
            else
                os.execute(tr69HealthMonitor.echo.." ',Invalid command syntax' >> "..tr69HealthMonitor.hmResultsFile)
            end
        elseif (string.find (line, "show traceroute_result")) then
            -- get traceroute results
            os.execute(tr69HealthMonitor.echo.. " 'TRCT_RES,OUTPUT,,' >> " ..tr69HealthMonitor.hmResultsFile)

            local t1 = util.split(line, " ")
            local hostname = t1[3]
            local noOfColumns = table.getn(t1)

            if(hostname ~= nil and hostname ~= "" and noOfColumns == 3) then
                local cmd = tr69HealthMonitor.traceRouteCommand.." "..hostname
                local stat = util.runShellCmd(cmd, tr69HealthMonitor.successFile, tr69HealthMonitor.errorFile,  nil)
                if(stat == 0) then
                    os.execute(tr69HealthMonitor.echo.." -n ,'\"' >> "..tr69HealthMonitor.hmResultsFile)
                    os.execute(tr69HealthMonitor.cat.." "..tr69HealthMonitor.successFile.." >> "..tr69HealthMonitor.hmResultsFile)
                    os.execute(tr69HealthMonitor.echo.." '\",,' >> "..tr69HealthMonitor.hmResultsFile)
                else
                    os.execute(tr69HealthMonitor.echo.." ',Error_CannotResolveHostName' >> "..tr69HealthMonitor.hmResultsFile)
                end
            else
                os.execute(tr69HealthMonitor.echo.." ',Invalid command syntax' >> "..tr69HealthMonitor.hmResultsFile)
            end
        elseif (string.find (line, "show traceroute6_result")) then
            -- get traceroute6 results
            os.execute(tr69HealthMonitor.echo.. " 'TRCT6_RES,OUTPUT,,' >> " ..tr69HealthMonitor.hmResultsFile)

            local t1 = util.split(line, " ")
            local hostname = t1[3]
            local noOfColumns = table.getn(t1)

            if(hostname ~= nil and hostname ~= "" and noOfColumns == 3) then
                local cmd = tr69HealthMonitor.traceRoute6Command.." "..hostname
                local stat = util.runShellCmd(cmd, tr69HealthMonitor.successFile, tr69HealthMonitor.errorFile,  nil)
                if(stat == 0) then
                    os.execute(tr69HealthMonitor.echo.." -n ,'\"' >> "..tr69HealthMonitor.hmResultsFile)
                    os.execute(tr69HealthMonitor.cat.." "..tr69HealthMonitor.successFile.." >> "..tr69HealthMonitor.hmResultsFile)
                    os.execute(tr69HealthMonitor.echo.." '\",,' >> "..tr69HealthMonitor.hmResultsFile)
                else
                    os.execute(tr69HealthMonitor.echo.." ',Error_CannotResolveHostName' >> "..tr69HealthMonitor.hmResultsFile)
                end
            else
                os.execute(tr69HealthMonitor.echo.." ',Invalid command syntax' >> "..tr69HealthMonitor.hmResultsFile)
            end
        elseif (string.find (line, "show nslookup_result")) then
            -- get nslookup results
            os.execute(tr69HealthMonitor.echo.. " 'DNSLKP_RES,OUTPUT,,' >> " ..tr69HealthMonitor.hmResultsFile)

            local t1 = util.split(line, " ")
            local hostname = t1[3]
            local noOfColumns = table.getn(t1)

            if(hostname ~= nil and hostname ~= "" and noOfColumns == 3) then
                local cmd = tr69HealthMonitor.nsLookUpCommand.." "..hostname
                local stat = util.runShellCmd(cmd, tr69HealthMonitor.successFile, tr69HealthMonitor.errorFile,  nil)
                
                local sval, serrcode = pcall(loadfile ("/var/nsLookUp.out"))
                if (sval) then
                    dofile ("/var/nsLookUp.out")
                    local nslookTbl = util.getLuaVariable("nslook")

                    if (nslookTbl ~= nil) then
                        if(nslook["AnswerType"] ~= nil and (nslook["IPAddresses"] ~= nil or nslook["IPv6Address"] ~= nil)) then
                            os.execute(tr69HealthMonitor.echo.." -n ,'\"' >> "..tr69HealthMonitor.hmResultsFile)
                            
                            for line in io.lines(tr69HealthMonitor.successFile) do
                                line = string.gsub(line, "\"", "")
                                --print(line)
                                os.execute(tr69HealthMonitor.echo.." " ..line.. " >> "..tr69HealthMonitor.hmResultsFile)
                            end

                            --os.execute(tr69HealthMonitor.cat.." "..tr69HealthMonitor.successFile.." >> "..tr69HealthMonitor.hmResultsFile)
                            os.execute(tr69HealthMonitor.echo.." '\",,' >> "..tr69HealthMonitor.hmResultsFile)
                        elseif(nslook["IPAddresses"] == nil) then
                            os.execute(tr69HealthMonitor.echo.." ',Error_HostNameNotResolved' >> "..tr69HealthMonitor.hmResultsFile)
                        elseif(nslook["AnswerType"] == nil) then
                            os.execute(tr69HealthMonitor.echo.." ',Error_DNSServerNotResolved' >> "..tr69HealthMonitor.hmResultsFile)
                        else
                            os.execute(tr69HealthMonitor.echo.." ',Error_Other' >> "..tr69HealthMonitor.hmResultsFile)
                        end
                    else
                        os.execute(tr69HealthMonitor.echo.." ',Error_Other' >> "..tr69HealthMonitor.hmResultsFile)
                    end
                else
                    os.execute(tr69HealthMonitor.echo.." ',Error_DNSServerNotAvailable' >> "..tr69HealthMonitor.hmResultsFile)
                end
            else
                os.execute(tr69HealthMonitor.echo.." ',Invalid command syntax' >> "..tr69HealthMonitor.hmResultsFile)
            end
        elseif (string.find (line, "show speed_results")) then
            -- get speed results
            os.execute(tr69HealthMonitor.echo.." 'SPEEDRESULTS,DOWNLOAD_SPEED,UPLOAD_SPEED' >> "..tr69HealthMonitor.hmResultsFile)

            local t1 = util.split(line, " ")
            local hostname = t1[3]
            local test_type_1 = t1[4]
            local benchMark_1 = t1[5]
            local test_type_2 = t1[6]
            local benchMark_2 = t1[7]
            local noOfColumns = table.getn(t1)
            local t2 = {}
            local t3 = {}
            local cmd = ""

            if(hostname ~= nil and hostname ~= "" and noOfColumns <= 7) then
                if(benchMark_1 ~= nil and benchMark_1 ~= "" and  benchMark_2 ~= nil and benchMark_2 ~= "") then
                    if (test_type_1 ~= nil and test_type_1 ~= "" and test_type_2 ~= nil and test_type_2 ~= "") then
                        cmd = tr69HealthMonitor.speedResultBin.. " "..hostname.." ".. test_type_1 .. " " .. benchMark_1 .. " " .. test_type_2 .. " "..benchMark_2
                    end
                elseif (benchMark_1 ~= nil and benchMark_1 ~= "") then
                        cmd = tr69HealthMonitor.speedResultBin.. " "..hostname.." ".. test_type_1 .. " " .. benchMark_1
                else
                    cmd = tr69HealthMonitor.speedResultBin.. " "..hostname
                end

                util.runShellCmd(cmd, tr69HealthMonitor.successFile, tr69HealthMonitor.errorFile, nil)
                
                if(util.fileExists(tr69HealthMonitor.successFile)) then
                    local speedResFile = io.open (tr69HealthMonitor.successFile, "r")
                    for line in speedResFile:lines () do
                        if (string.find (line, "Download")) then
                            t2 = util.split(line, ":")
                        end
                        if (string.find (line, "Upload")) then
                            t3 = util.split(line, ":")
                        end
                    end
                    speedResFile:close()
                    if(t2[2] ~= nil and t3[2] ~= nil) then
                        os.execute(tr69HealthMonitor.echo.." ,"..t2[2]..","..t3[2].." >> "..tr69HealthMonitor.hmResultsFile)
                    else
                        os.execute(tr69HealthMonitor.echo.." ',Failed to get download speed, Failed to get upload speed' >> "..tr69HealthMonitor.hmResultsFile)
                    end
                else
                    os.execute(tr69HealthMonitor.echo.." ',Failed to get download speed, Failed to get upload speed' >> "..tr69HealthMonitor.hmResultsFile)
                end 
            else
                os.execute(tr69HealthMonitor.echo.." ',Invalid command syntax' >> "..tr69HealthMonitor.hmResultsFile)
            end
        elseif (string.find (line, "show speedtest")) then
            -- get speed test results
            os.execute(tr69HealthMonitor.echo.." 'SPEEDTEST,DOWNLOAD_SPEED,UPLOAD_SPEED' >> "..tr69HealthMonitor.hmResultsFile)
            local noOfColumns = table.getn(util.split(line, " "))
            local i=1
            local iline={}
            if (noOfColumns >= 6) then
                if (util.fileExists(tr69HealthMonitor.brcm)) then
                    if (util.fileExists(tr69HealthMonitor.tcpspdtest)) then
                        cmd = string.gsub(line, "show speedtest", tr69HealthMonitor.speedResultBin2)
                    else
                        cmd = string.gsub(line, "show speedtest", tr69HealthMonitor.speedResultBin)
                    end
                else
                    cmd = string.gsub(line, "show speedtest", tr69HealthMonitor.speedScript)
                end
                if (util.fileExists(tr69HealthMonitor.tcpspdtest)) then
                    tr69HealthMonitor.runShellCmd(cmd, tr69HealthMonitor.successFile, tr69HealthMonitor.errorFile, nil)
                else
                    util.runShellCmd(cmd, tr69HealthMonitor.successFile, tr69HealthMonitor.errorFile, nil)
                end
                if(util.fileExists(tr69HealthMonitor.successFile)) then
                    local speedResFile = io.open (tr69HealthMonitor.successFile, "r")
                    if (util.fileExists(tr69HealthMonitor.tcpspdtest)) then
                        for line in speedResFile:lines () do
                            if (string.find (line, "download speed")) then
                                t1 = util.split(line, " ")
                                iline[1] = t1[5]
                                iline[2] = "0"
                                break
                            elseif (string.find (line, "upload speed")) then
                                t1 = util.split(line, " ")
                                iline[1] = "0"
                                iline[2] = t1[5]
                                break
                            end
                        end
                    else
                        for line in speedResFile:lines () do
                            iline[i] = line
                            i = i+1
                        end
                    end
                    speedResFile:close()
                    if(iline[1] ~= nil and iline[2] ~= nil and tonumber(iline[1]) ~= nil and tonumber(iline[2]) ~= nil) then
                        os.execute(tr69HealthMonitor.echo.." ,"..iline[1].." KB/s,"..iline[2].." KB/s >> "..tr69HealthMonitor.hmResultsFile)
                    elseif (iline[1] ~= nil and string.find (iline[1], "ERR")) then
                        os.execute(tr69HealthMonitor.echo.." ',Failed to get download speed,Failed to get upload speed' >> "..tr69HealthMonitor.hmResultsFile)
                    else
                        os.execute(tr69HealthMonitor.echo.." ',Invalid command syntax' >> "..tr69HealthMonitor.hmResultsFile)
                    end                
                else
                    os.execute(tr69HealthMonitor.echo.." ',Failed to get download speed,Failed to get upload speed' >> "..tr69HealthMonitor.hmResultsFile)
                end 
            else
                os.execute(tr69HealthMonitor.echo.." ',Invalid command syntax' >> "..tr69HealthMonitor.hmResultsFile)
            end
        elseif (string.find (line, "show page_load_time")) then
            -- get page load time
            os.execute(tr69HealthMonitor.echo.." 'PGLD_TIME,OUTPUT,,' >> "..tr69HealthMonitor.hmResultsFile)

            local t1 = util.split(line, " ")
            local hostname = t1[3]
            local noOfColumns = table.getn(t1)

            -- check file size before downloading it
            getSizeStatus = tr69HealthMonitor.fileSizeCheck (hostname)
            if(getSizeStatus == ERROR) then
                os.execute(tr69HealthMonitor.echo.." ',Invalid file size or CPE out of memory' >> "..tr69HealthMonitor.hmResultsFile)
            else
                if(hostname ~= nil and hostname ~= "" and noOfColumns == 3) then
                    local pageLoadTime = ""
                    local cmd = tr69HealthMonitor.wgetCommand.." "..hostname
                    util.runShellCmd(cmd, tr69HealthMonitor.successFile, tr69HealthMonitor.errorFile, nil)
                    if(util.fileExists(tr69HealthMonitor.pageLoadTime)) then
                        local fileHandle = io.open(tr69HealthMonitor.pageLoadTime, "r")
                        if (fileHandle ~= nil) then
                            pageLoadTime = fileHandle:read("*line")
                            fileHandle:close()
                        end

                        tr69Glue.tf1Dbg("pageLoadTime = " .. pageLoadTime)
                        if(pageLoadTime == "s" or pageLoadTime == "0s") then
                            pageLoadTime = "1s"
                        end
                        tr69Glue.tf1Dbg("pageLoadTime == " .. pageLoadTime)
                        os.execute(tr69HealthMonitor.echo.." ,"..pageLoadTime.." >> "..tr69HealthMonitor.hmResultsFile)
                    else
                        os.execute(tr69HealthMonitor.echo.." ',Could not get the page load time' >> "..tr69HealthMonitor.hmResultsFile)
                    end
                else
                    os.execute(tr69HealthMonitor.echo.." ',Invalid command syntax' >> "..tr69HealthMonitor.hmResultsFile)
                end
            end
        elseif (string.find (line, "show packet_stats")) then
            -- get packet stats
            os.execute(tr69HealthMonitor.echo.. " 'PKT_STATS,OUTPUT,,' >> " ..tr69HealthMonitor.hmResultsFile)

            local t1 = util.split(line, " ")
            local t2 = {}
            local hostname = t1[4]
            local port = t1[6]
            local interface = t1[8]
            local iter = t1[10]
            local statInterval = t1[12]
            local protoVersion = t1[14]
            local resultFlag = 0

            port = tonumber(port)
            iter = tonumber(iter)
            statInterval = tonumber(statInterval)

            noOfColumns = table.getn(t1)

            if(hostname ~= nil and hostname ~= "" and port ~= nil and port ~= "" and interface ~= nil and interface ~= "" and iter ~= nil and iter ~= "" and statInterval ~= nil and statInterval ~= "" and protoVersion ~= nil and protoVersion ~= "" and noOfColumns == 14) then
                if((port < 1 or port > 65535) or (iter < 1 or iter > 5) or (interface ~= "bdg1" and interface ~= "bdg2") or (statInterval < 1 or statInterval > 65535) or (protoVersion ~= "IPv4" and protoVersion ~= "IPv6" and protoVersion ~= "Any")) then
                    os.execute(tr69HealthMonitor.echo.. " 'Invalid data' >> "..tr69HealthMonitor.hmResultsFile)
                else
                    local cmd = tr69HealthMonitor.udpClientCommand.." " ..hostname.. " " .. port .. " " .. interface .. " "..tr69HealthMonitor.udpTimeout.." "..tr69HealthMonitor.udpDSCP.." "..tr69HealthMonitor.udpDataBlockSize.." " .. iter .. " " .. statInterval .. " " .. protoVersion

                    util.runShellCmd(cmd, tr69HealthMonitor.successFile, nil,  nil)

                    local pktStatsFile = io.open (tr69HealthMonitor.successFile, "r")
                    if (pktStatsFile ~= nil) then
                        for line in pktStatsFile:lines () do
                            if (string.find (line, "Success:")) then
                                t2 = util.split(line, " ")
                                if(tonumber(t2[2]) > 0) then
                                    os.execute(tr69HealthMonitor.echo.. " ',successfully sent udpEcho data' >> "..tr69HealthMonitor.hmResultsFile)
                                    resultFlag = 1
                                else
                                    os.execute(tr69HealthMonitor.echo.. " ',could not send udpEcho data' >> "..tr69HealthMonitor.hmResultsFile)
                                    resultFlag = 1
                                end
                            end
                        end
                        pktStatsFile:close()
                    else
                        os.execute(tr69HealthMonitor.echo.. " ',could not send udp echo data' >> "..tr69HealthMonitor.hmResultsFile)
                        resultFlag = 1
                    end
                    if(resultFlag == 0) then
                        os.execute(tr69HealthMonitor.echo.. " ',could not send udp echo data' >> "..tr69HealthMonitor.hmResultsFile)
                    end
                end
            else
                os.execute(tr69HealthMonitor.echo.." ',Invalid command syntax' >> "..tr69HealthMonitor.hmResultsFile)
            end
        elseif(string.find (line, "raw_cmd")) then
            
            local t1 = util.split(line, " ")
            local credTable = util.split(t1[2], ":")
            local username = credTable[1]
            local password = credTable[2]
            local a = string.find (line, '%[') 
            local b = string.find (line, '%]') 
            local authenticateCmd = nil
            local rawCmd = nil
            local stat = nil 
            local status = nil

            tr69Glue.tf1Dbg("line = " .. line)

            tr69Glue.tf1Dbg("username = " .. username)
            tr69Glue.tf1Dbg("password = " .. password)
            tr69Glue.tf1Dbg("a = " .. a)
            tr69Glue.tf1Dbg("b = " .. b)

            authenticateCmd = tr69HealthMonitor.userAuthVerifyBin ..username.. " " .. password

            tr69Glue.tf1Dbg("authenticateCmd = " .. authenticateCmd)

            stat = util.runShellCmd(authenticateCmd, tr69HealthMonitor.successFile, tr69HealthMonitor.errorFile,  nil)
        
            tr69Glue.tf1Dbg("stat = " .. stat)
                
            rawCmd = string.sub(line, a+1, b-1)
            tr69Glue.tf1Dbg("rawCmd = " .. rawCmd)

            os.execute(tr69HealthMonitor.echo.. " 'RAW_CMD, ["..rawCmd .. "] OUTPUT,,' >> " ..tr69HealthMonitor.hmResultsFile)

            if (stat == 0) then 
                if((string.find (line, "update")) or (string.find (line, "UPDATE"))) then
                    status = os.execute(rawCmd)
                    tr69Glue.tf1Dbg("update status = " .. status)
                    
                    os.execute(tr69HealthMonitor.echo.." -n ,'\"' >> "..tr69HealthMonitor.hmResultsFile)
                    if(status == 0) then
                        os.execute(tr69HealthMonitor.echo.." 'SET is Success' >> "..tr69HealthMonitor.hmResultsFile)
                    else
                        os.execute(tr69HealthMonitor.echo.." 'SET Failed' >> "..tr69HealthMonitor.hmResultsFile)
                    end
                    os.execute(tr69HealthMonitor.echo.." '\",,' >> "..tr69HealthMonitor.hmResultsFile)
                else
                    os.execute(tr69HealthMonitor.echo.." -n ,'\"' >> "..tr69HealthMonitor.hmResultsFile)
                
                    status = os.execute(rawCmd.." >> "..tr69HealthMonitor.hmResultsFile)
                    tr69Glue.tf1Dbg("status = " .. status)
                    if(status ~= 0) then
                        os.execute(tr69HealthMonitor.echo.." 'Invalid Command' >> "..tr69HealthMonitor.hmResultsFile)
                    end

                    os.execute(tr69HealthMonitor.echo.." '\",,' >> "..tr69HealthMonitor.hmResultsFile)
                end
            else
                os.execute(tr69HealthMonitor.echo.." ',Authentication Failed' >> "..tr69HealthMonitor.hmResultsFile)
            end
        else
            os.execute(tr69HealthMonitor.echo.." 'UNKNOWN_COMMAND,OUTPUT,,,' >> " ..tr69HealthMonitor.hmResultsFile)
            os.execute(tr69HealthMonitor.echo.." ,'"..line.." :: Command not supported' >> "..tr69HealthMonitor.hmResultsFile)
        end -- if
    end -- for

    tr69HealthMonitor.removeFiles()
    file:close()
    return status
end
