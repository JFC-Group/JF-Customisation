--[[

-- Copyright (c) 2013-2017, TeamF1 Networks Pvt. Ltd.
-- (Subsidiary of D-Link India)

#### File: platform.lua
#### Description: lua functions for platform component

#### Revisions:
01e,17Feb17,ar Add function to get result of the traceroute action.
01d,29Aug13,ash Changes for SPR#39736
01c,24Aug13,sen added set/get func for unauthorized usage
01b,15dec11,adi added the sysInfoGet function
01a,10feb09,rks written
]]--


--package

platform = {}

--*****************************************************************************************
--@name platform.sysInfoGet()
--
--@description The function will read the system name and firmware version
--
--@return

function platform.sysInfoGet() 	
	--locals
	local sysInfoTbl = {}
	local inputTbl = {}
			
	-- get general system information
    local query = "_ROWID_='1'"
    inputTbl = db.getRowWhere ("system", query, false);
    if (inputTbl == nil) then
        return sysInfoTbl
    end

    -- fill in system name and firmware version
	sysInfoTbl["systemName"] =  inputTbl["name"];
	sysInfoTbl["firmwareVersion"] = inputTbl ["firmwareVer"];
	
	--return 
	return sysInfoTbl 	
end

--*****************************************************************************************
	--Adding the functions for ping, dnslookup & traceroute
--****************************************************************************************

--*****************************************************************************************
--@name platform.availableNetworkGet()
--
--@description The function will get all the available networks are currently
--created in the system.
--
--@return This function returns the lua table which contains are the available 
--IPv4 and IPv6 networks information.
function platform.availableNetworkGet ()
    
    --locals
    local networkTbl = {}
	local localTable = {}

	--getting the networks info from the networkInterface table
	networkTbl = db.getTable("networkInterface", false)
	if (networkTbl == nil) then
		return localTable
	end

	--return
	return networkTbl
end
    
--*****************************************************************************************
--@name platform.availableIPv_X_NetworkGet()
--
--@description The function will get all the available networks of type 'X'
--(IPv4 or IPv6).
--
--@return
function platform.availableIPv_X_NetworkGet (X)
--function platform.availableIPv4NetworkGet ()
    
    --locals
    local networkTbl = {}
    local ipv4NetTbl = {}
	local localTable = {}
    local query 
   
    if(tonumber(X) == 4) then
        query= " AddressFamily = 2 AND ConnectionKey = 0"
    elseif (tonumber(X) == 6) then
        query= " AddressFamily = 10 AND ConnectionKey = 0"
    else
        return localTable
    end
        
    --getting the ipv4/ipv6 network info from the nimfConf table
    networkTbl = db.getRowsWhere("nimfConf", query, false)
	if (networkTbl == nil) then
		return localtable
	end
    
    for i,v in ipairs (networkTbl)
    do
        query = "LogicalIfName = '" .. v["LogicalIfName"] .. "'"
        ipv4NetTbl[i] = db.getRowWhere ("networkInterface", query, false)
	end

	--return
	return ipv4NetTbl
end

--*****************************************************************************************
--@name platform.availableIPv4NetworkGet()
--
--@description The function will return all the IPv4 networks that are currently
--available in the system.
--
--@return
function platform.availableIPv4NetworkGet()
    --locals
    local networkTbl = {}
    
    networkTbl = platform.availableIPv_X_NetworkGet (4)

    return networkTbl

end

--*****************************************************************************************
--@name platform.availableIPv6NetworkGet()
--
--@description The function will return all the IPv6 networks that are currently
--available in the system.
--
--@return
function platform.availableIPv6NetworkGet()
    --locals
    local networkTbl = {}
    
    networkTbl = platform.availableIPv_X_NetworkGet (6)

    return networkTbl

end


function platform.pingTest (inputTable)
	
	--locals
	local ipToPing = {}
	local pingfile = {}
	local pingprog = {}
	local statusMsg, errMsg
	local rowTbl = {}
	-- local nwName = inputTable["networkname"]
	local query = " networkName = '" .. inputTable["networkname"] .. "'"
	--for RGW vpnEnable = 0
	
	local Vpn = false
	rowTbl = db.getRowWhere("networkInterface", query, true)
    local query2 = "LogicalIfName = '" .. rowTbl["networkInterface.LogicalIfName"] .. "' and addressFamily = 2"
    local rowTbl2 = db.getRowWhere("ipAddressTable",query2,false)
    if(rowTbl2 == nil) then
        return "NET_DOWN","SEL_NW_IS_DOWN"
    end
	ipToPing = inputTable["ipaddress"]
 	pingfile = db.getAttribute("environment", "name", "PING_FILE_NAME", "value")	
	pingprog = db.getAttribute("environment", "name", "PING_PROGRAM", "value")
	
	--if vpn is avaliable then the local variable is changed to true
	if (inputTable["vpnEnable"] == "1") then
		Vpn = true
	end
	
	-- ping    
	-- case if ipv6 address is given
    if(ipToPing:find(":")) then
			--if vpn enabled
    	if (Vpn) then
			statusMsg = "IPv6_SUPPORT_NOT_AVALIABLE"
			errMsg = "ERROR"
			return statusMsg, errMsg
		--if vpn disabled
    	else
	        pingprog = db.getAttribute("environment", "name", "PING6_PROGRAM", "value")
		    os.execute(pingprog .. " " .. ipToPing .. " -I " .. rowTbl["networkInterface.interfaceName"] .. " > " .. pingfile)
			util.appendDebugOut("PING_IPv6_SUCCESSFUL....")
			statusMsg = "PING_IPv6_SUCCESSFUL"
			errMsg = "STATUS_OK"
			return statusMsg, errMsg
	    end
	--case if ipv4 address is given
    else
			--if vpn is enabled
    	if (Vpn) then
	        pingprog = db.getAttribute("environment", "name", "VPN_PING_PROGRAM", "value")
			local lanConfig = db.getRowWhere ("ifStatic","LogicalIfName = 'LAN' and AddressFamily = 2")
			if (lanConfig ~= nil and pingprog ~= nil) then
				local lanIpAddr = lanConfig["ifStatic.StaticIp"]
			    os.execute(pingprog .. " " .. lanIpAddr .. " " .. ipToPing .. " " .. pingfile)
				util.appendDebugOut("PING_IPv4_THROUGH_VPN_SUCCESSFUL.... ")
					statusMsg = "PING_IPv4_THROUGH_VPN_SUCCESSFUL"
					errMsg = "STATUS_OK"
					return statusMsg, errMsg
			else
					statusMsg = "PING_THROUGH_VPN_FAILED"
					errMsg = "ERROR"
					return statusMsg, errMsg
			end
			--if vpn is disabled
    	else
	        if (pingprog ~= nil) then
                -- This check is only for interface IP address
                if(rowTbl2["ipAddress"] == ipToPing) then
                    os.execute(pingprog .. " " .. ipToPing .. " > " .. pingfile)
					statusMsg = "PING_IPv4_SUCCESSFUL"
					errMsg = "STATUS_OK"
					return statusMsg, errMsg
                else
                    os.execute(pingprog .. " " .. ipToPing .. " -I " .. rowTbl["networkInterface.interfaceName"] .. " > " .. pingfile)
					statusMsg = "PING_IPv4_SUCCESSFUL"
					errMsg = "STATUS_OK"
					return statusMsg, errMsg
                end
			else
					statusMsg = "PING_IPv4_FAILED"
					errMsg = "ERROR"
					return statusMsg, errMsg
			end
		end
	end
  
end

--******************************************************************************
function platform.diagnosticResultGet(utility)

    local utilityFile = {}
    local pFile

    if (utility ~= nil) then
        if(utility == "ping") then
            -- get the detail of the file location from the environment table
            -- PING_FILE_NAME as the macro
            utilityFile = db.getAttribute("environment", "name", "PING_FILE_NAME", "value")

        elseif(utility == "traceroute") then
            -- get the detail of the file location from the environment table
            -- TRACE_ROUTE_FILE_NAME as the macro
            utilityFile = db.getAttribute("environment", "name", "TRACE_ROUTE_FILE_NAME", "value")

        elseif(utility == "nslookup") then
            -- get the detail of the file location from the environment table
            -- NSLOOKUP_FILE_NAME as the macro
            utilityFile = db.getAttribute("environment", "name", "NSLOOKUP_FILE_NAME", "value")
        else
            return UNKNOWN_DIAGNOSTICS_UTILITY
        end
        
        -- open the file from which data needs to manipulated
        pFile = assert(io.open(utilityFile,"r"));
    else
        return nil
    end

    local dataToWrite

    -- read the complete file
    dataToWrite = pFile:read("*a");
    dataToWrite = tostring (dataToWrite);

    -- close the file
    io.close (pFile);

    return dataToWrite;	
end

--******************************************************************************

function platform.traceroute (inputTable)

	--locals
	local options = " -m 5 -q 1 -i "
	local options2 = " 2>&1 | grep -v argc > "
	local ipToTraceRoute = {}
	local traceRouteProg = ""
	local outputfile
	local statusMsg, errMsg	
        -- querying networkname from inputTable
	local rowTbl = {}
	local query = " networkName = '" .. inputTable["networkname"] .. "'"

	rowTbl = db.getRowWhere("networkInterface", query, true)

    local query2 = "LogicalIfName = '" .. rowTbl["networkInterface.LogicalIfName"] .. "' and addressFamily = 2"
    local rowTbl2 = db.getRowWhere("ipAddressTable",query2,false)
    if(rowTbl2 == nil) then
        return "NET_DOWN","SEL_NW_IS_DOWN"
    end

	-- join fields
    	ipToTraceRoute = inputTable["ipaddress"]

	--if ipv4 address is given
	if(ipToTraceRoute:find(".")) then
	    traceRouteProg = db.getAttribute("environment", "name", "TRACEROUTE_PROGRAM", "value")
	--if ipv6 address is given
	elseif(ipToTraceRoute:find(":")) then
	    traceRouteProg = db.getAttribute("environment", "name", "TRACEROUTE6_PROGRAM", "value")
	end
	--execution of the command
	if (traceRouteProg ~= "") then
		outputfile = db.getAttribute("environment", "name", "TRACE_ROUTE_FILE_NAME", "value")
		util.appendDebugOut(traceRouteProg .. ipToTraceRoute)
		-- os.execute(traceRouteProg .. " " .. ipToTraceRoute .. " " .. options .. rowTbl["networkInterface.interfaceName"] .. options2 .. outputfile)
		query = traceRouteProg .. " " .. ipToTraceRoute .. " " .. options .. rowTbl["networkInterface.interfaceName"] .. options2 .. outputfile
		os.execute (query)
		statusMsg = "EXECUTION_SUCCESSFUL"
		errMsg = "STATUS_OK"
		return statusMsg, errMsg
	end
	
end


--******************************************************************************

function platform.tracerouteRes(tracerouteFile, ipToTraceRoute)
    
    local firstLn = ""
    local lastln = ""
    local resStr = ""
    local index = 1
    local result = "OK"

    for line in io.lines(tracerouteFile) do

        if (line == nil) then
            return "OK", ""
        end

        if (index == 1) then
            firstLn = string.format("%q", line)
        else
            lastln = string.format("%q", line)
        end
            
        index=index+1
    end
        
    -- Get Resolved address of the IP to trace. (xx.xx.xx.xx)
    if (firstLn == nil) then
        return "OK", ""
    end

    local firstTrace = string.match(firstLn, "%((.-)%)")
    
    if (firstTrace ~= nil) then
        if(string.find(lastln,firstTrace) == nil) then
            result = "NOT_TRACED"
            resStr = "\n Unable to trace " .. ipToTraceRoute .. " in 30 hops"
        else    
            result = "OK"
            resStr = ""
        end
    end
    
    return result, resStr
end

--******************************************************************************

function platform.nslookup(inputTable)

	--locals
	local nslookupTbl = {}
	local internetNameToNsLookup = {}	
	local nsLookupProg 
	local nsLookupFile
	local statusMsg, errMsg

	nslookupTbl["dnsname"] = inputTable["dnsname"]
	internetNameToNsLookup = nslookupTbl["dnsname"]
	
	 -- dnslookup
	nsLookupProg = db.getAttribute("environment", "name", "NSLOOKUP_PROGRAM", "value")
	nsLookupFile = db.getAttribute("environment", "name", "NSLOOKUP_FILE_NAME", "value")
	util.appendDebugOut(nsLookupProg .. " " .. internetNameToNsLookup .. ">" .. nsLookupFile)
	os.execute(nsLookupProg .. " " .. internetNameToNsLookup .. " > " .. nsLookupFile)
	statusMsg = "EXECUTION_SUCCESSFUL"
	errMsg = "STATUS_OK"
	return statusMsg, errMsg

end

--*******************************************************************************
--@name platform.getDefSysCfg ()
--
--@description The function will get the system info from various tables
--
--@name

function platform.getDefSysCfg () 

	--locals
	local sysTbl = {}
    local ntpTbl = {}
    local query = "_ROWID_=1"

	--getting the values from different tables
	sysTbl["name"] =  db.getAttribute("system","_ROWID_", 1, "name")
	sysTbl["admin_password"] =  db.getAttribute("users","username", "admin", "password")
    ntpTbl = db.getRowWhere("ntp", query, false)
	sysTbl["time_zone"] =  ntpTbl["timezone"]
	sysTbl["daylight_savings_flag"] =  ntpTbl["autoDaylight"]
	
	--return
	return sysTbl
end

--******************************************************************************

function platform.sysInfoSet(inputTable)

		--locals
		sysinfoTbl = {}
        query = "_ROWID_=1" 
        sysinfoTbl = db.getRowWhere("system", query, false)
		sysinfoTbl["name"] = inputTable["system_name"]

        -- adding prefix
        sysinfoTbl = util.addPrefix(sysinfoTbl, "system.")
		--updating the table
		db.update ("system", sysinfoTbl, 1)
end

--******************************************************************************

function platform.unAuthorizedUsageGet(inputTable)

		--locals
		sysinfoTbl = {}
        query = "_ROWID_=1" 
        sysinfoTbl = db.getRowWhere("unauthorizedUsage", query, false)

		return sysinfoTbl

end

--******************************************************************************

function platform.unAuthorizedUsageSet(inputTable)

		--locals
		sysinfoTbl = {}
		local valid = false
        query = "_ROWID_=1" 
        sysinfoTbl = db.getRowWhere("unauthorizedUsage", query, false)
		sysinfoTbl["status"] = inputTable["tf1_unauthorized"]

        -- adding prefix
        sysinfoTbl = util.addPrefix(sysinfoTbl, "unauthorizedUsage.")
		--updating the table
		valid = db.update ("unauthorizedUsage", sysinfoTbl, 1)
		if (valid) then
			return "OK", "STATUS_OK"
		else
			return "ERROR", "ERROR"
		end
end

--*******************************************************************************
	--END	
--*******************************************************************************

--******************************************************************************

function platform.multisubnetGet(inputTable)

		--locals
		multisubnetInfo = {}
        query = "_ROWID_=1" 
        multisubnetInfo = db.getRowWhere("MultiSubnetTbl", query, false)

		return multisubnetInfo

end

--******************************************************************************

function platform.multisubnetSet(inputTable)

		--locals
		multisubnetInfo = {}
		local valid = false
        query = "_ROWID_=1" 
        multisubnetInfo = db.getRowWhere("MultiSubnetTbl", query, false)
		multisubnetInfo["status"] = inputTable["status"]

        -- adding prefix
        multisubnetInfo = util.addPrefix(multisubnetInfo, "MultiSubnetTbl.")
		--updating the table
		valid = db.update ("MultiSubnetTbl", multisubnetInfo, 1)
		if (valid) then
			return "OK", "STATUS_OK"
		else
			return "ERROR", "ERROR"
		end
end



function platform.import (configCfg, defaultCfg, removeCfg)
    
    if (configCfg == nil) then
        configCfg = defaultCfg
    end

    --Note :- The code is added to load the user configuration when trying to
    --load the image from 1.0.40 to 1.0.42.
    if (configCfg.system == nil) then
        configCfg.system                = {}
        configCfg.system[1]                = {}
        configCfg.system[1]["name"]        = configCfg["name"]
        configCfg.system[1]["domain"]      = configCfg["domain"]
        configCfg.system[1]["firmwareVer"] = configCfg["firmwareVer"]
        configCfg.system[1]["vendor"]      = configCfg["vendor"]
        configCfg.system[1]["description"] = configCfg["description"]
        configCfg.system[1]["sysLoc"]      = configCfg["sysLoc"]
        configCfg.system[1]["sysContact"]  = configCfg["sysContact"]
    end
    
    local systemTbl = {}
    systemTbl = config.update (configCfg.system, defaultCfg.system, removeCfg.system)

    if (systemTbl ~= nil and #systemTbl ~= 0) then
        for i,v in ipairs (systemTbl) do
            v = util.addPrefix (v, "system.");
            db.insert ("system", v)
        end
    end

	local unauthorizedUsageTbl = {}
	unauthorizedUsageTbl = config.update (configCfg.unauthorizedUsage, defaultCfg.unauthorizedUsage, removeCfg.unauthorizedUsage)

    if (unauthorizedUsageTbl ~= nil and #unauthorizedUsageTbl ~= 0) then
        for i,v in ipairs (unauthorizedUsageTbl) do
            v = util.addPrefix (v, "unauthorizedUsage.");
            db.insert ("unauthorizedUsage", v)
        end
    end
	
	if (util.fileExists ("/pfrm2.0/ECONET")) then
    local voipSettingTbl = {}
    local value = ""
    local logLevel = 1;
    voipSettingTbl = config.update (configCfg.voipSetting, defaultCfg.voipSetting, removeCfg.voipSetting)
    if (voipSettingTbl ~= nil and #voipSettingTbl ~= 0) then
        for i,v in ipairs (voipSettingTbl) do
            for ii,vv in pairs(v) do
                if(ii == "DialingTimeout") then
                    os.execute("echo " ..vv.. " > /tmp/voipdialingTimeOut.config")
                end
                if(ii == "WatchDogEnable") then
                    if (tonumber(vv) == 1) then
                        os.execute("tcwdog -t 1 /dev/watchdog &");
                    else
                        os.execute("killall -9 tcwdog");
                    end
                end
                if(ii == "LogLevel") then
                    local filep = io.open("/pfrm2.0/firmVersion", "r")
                    local firmwareVersion = filep:read("*l")
                    filep:close()
                    if(string.find(firmwareVersion, "_D")) then
                        logLevel = 4;
                    elseif(string.find(firmwareVersion, "_R")) then
                        logLevel = 1;
                    end
                    if (tonumber(vv) > logLevel) then
                        logLevel = vv;
                    end
                    v["LogLevel"] = logLevel;
                    os.execute("echo " ..logLevel.. " > /tmp/currentkLogLevel")
                end
            end
            v = util.addPrefix (v, "voipSetting.");
            db.insert ("voipSetting", v)
        end
    end
	end
	if (util.fileExists ("/pfrm2.0/HW_JCOW401") or util.fileExists ("/pfrm2.0/HW_JCOW403")) then
    local miscSettingTbl = {}
    local value = ""
    local logLevel = 1;
    miscSettingTbl = config.update (configCfg.miscSetting, defaultCfg.miscSetting, removeCfg.miscSetting)
    if (miscSettingTbl ~= nil and #miscSettingTbl ~= 0) then
        for i,v in ipairs (miscSettingTbl) do
            for ii,vv in pairs(v) do
                if(ii == "LogLevel") then
                    local filep = io.open("/pfrm2.0/firmVersion", "r")
                    local firmwareVersion = filep:read("*l")
                    filep:close()
                    if(string.find(firmwareVersion, "_D")) then
                        logLevel = 4;
                    elseif(string.find(firmwareVersion, "_R")) then
                        logLevel = 1;
                    end
                    if (tonumber(vv) > logLevel) then
                        logLevel = vv;
                    end
                    v["LogLevel"] = logLevel;
                    os.execute("echo " ..logLevel.. " > /tmp/currentkLogLevel")
                end
            end
            v = util.addPrefix (v, "miscSetting.");
            db.insert ("miscSetting", v)
        end
	end	
	end
end

function platform.export ()
    local snmpSytemTbl = {}
    snmpSytemTbl["system"] = db.getTable ("system", false)
    snmpSytemTbl["unauthorizedUsage"] = db.getTable ("unauthorizedUsage", false)
	if (util.fileExists ("/pfrm2.0/ECONET")) then
    	snmpSytemTbl["voipSetting"] = db.getTable ("voipSetting", false)
	end
	if (util.fileExists ("/pfrm2.0/HW_JCOW401") or util.fileExists ("/pfrm2.0/HW_JCOW403")) then
    	snmpSytemTbl["miscSetting"] = db.getTable ("miscSetting", false)
	end
    return snmpSytemTbl
end

if (config.register) then
   config.register("system", platform.import, platform.export, "1")
end
