--[[
#### smv
#### TeamF1
#### www.TeamF1.com
#### Nov 06, 2007

#### File: cron.lua
#### Description: Cron Functions.

#### Revisions:
None
]]--
-- modification history
-- --------------------
-- 01a, 10aug13, ash added import/export fns 

--************* Requires *************

require "teamf1lualib/login"

--************* Initial Code *************

-- package cron
crontab = {}

--************* Functions *************
--[[
-- Assumes login validation already done.
-- Currently we are not allowing setting of intervals in the crontab table (i.e.
-- events cannot be scheduled at say 5 mins, every 2 days etc) through the user interfaces.
-- The only type of scheduling possible is hourly, weekly, day of a month/week
-- etc. We do this by setting the interval field of the crontab entry to 0.
function crontab.config (inputTable, RowId, operation, commandString)

    if (operation == "delete") then
        valid = db.deleteRow ("crontab", "_ROWID_", RowId)
    else
        inputTable["crontab.minute"] = 0
        inputTable["crontab.month"] = -1
        inputTable["crontab.dayOfMonth"] = -1
        inputTable["crontab.command"] = commandString
        if (inputTable["crontab.meridiem"] == "1") then
            inputTable["crontab.hour"] = 12 + inputTable["crontab.hour"]
        end

        if (inputTable["crontab.unit"] == "1" ) then
            inputTable["crontab.hour"] = -1
        end

        --util.tableToStringRec (inputTable)
        if (RowId == "-1" or RowId == -1 ) then
            valid = db.insert ("crontab", inputTable)
        else  -- edit
            valid = db.update ("crontab", inputTable, RowId)
        end
    end

    -- return
    if (valid) then
        return "OK", "12265"
    else
        return "ERROR", "10485"
    end
end

function crontab.getSchedule (RowId,configRow)
    local getTable = db.getRow ("crontab","_ROWID_",RowId)
    configRow ["crontab.hour"] = "-1"
    configRow ["crontab.unit"] = "-1"
    configRow ["crontab.dayOfWeek"] = "-1"
    configRow ["crontab.meridiem"] = "-1"

    if (getTable["crontab.hour"] == "-1" ) then 
        configRow["crontab.unit"] = "1"
        return configRow
    else
        hour = tonumber(getTable["crontab.hour"])
        if (hour > 11) then
        configRow["crontab.hour"] =  tostring(hour-12)
        configRow ["crontab.meridiem"] = "1"
        else
            configRow["crontab.hour"] = getTable["crontab.hour"]
            configRow["crontab.meridiem"] = "0"
        end
        if (getTable["crontab.dayOfWeek"] == "-1") then
            configRow ["crontab.unit"] = "2"
            return configRow
        else
            configRow ["crontab.unit"] = "3"
            configRow ["crontab.dayOfWeek"] = getTable["crontab.dayOfWeek"]
            return configRow
        end
    end
    return configRow
end

function crontab.getScheduleByCmd (cmd)
    schedRow = db.getRowWhere ("crontab", "command='" .. cmd .."'");

    if (schedRow == nil) then
        util.appendDebugOut ("crontab.getScheduleByCmd: ERROR: No Record <br>")
        return nil
    end

    hour = tonumber(schedRow["crontab.hour"])
    if (hour > 11) then
        schedRow["crontab.hour"] =  tostring(hour - 12)
        schedRow["crontab.meridiem"] = "1"
    else
        schedRow["crontab.meridiem"] = "0"
    end

    util.appendDebugOut ("Schedule:Unit: " .. schedRow["crontab.unit"] .. "<br>")
    
    return schedRow
end
]]--

function crontab.config (inputTable, rowid, operation)
    -- validate
    --if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
            return db.insert("crontab", inputTable)
        elseif (operation == "edit") then
            return db.update("crontab", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("crontab",inputTable)
        end
    --end
    return false
end


function crontab.import (configTable)
    if (configTable ~= nil) then
        for i,v in ipairs (configTable) do
            v = util.addPrefix (v, "crontab.");
            crontab.config (v, -1, "add")
        end
    end
end

function crontab.export ()
    return db.getTable ("crontab", false)
end

if (config.register) then
   config.register("crontab", crontab.import, crontab.export, "1")
end



