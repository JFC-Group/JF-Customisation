-- @copyright Copyright (c) 2013, TeamF1, Inc. 
--
-- modification history
-- --------------------
-- 01a, 09May18, aks added support for ndppd
-- 01a, 10aug13, ash added support for dhcpv6relay

AppExtnClassRegistry = {}

local appExtnClassTable = {
    -- classId   -- Lua class           
    thttpd      =   { dsClass = "ThttpdExtn"    },
    dhcpd       =   { dsClass = "DhcpdExtn"     },
    dhcpv6s     =   { dsClass = "Dhcpv6sExtn"   },
    radvd       =   { dsClass = "RadvdExtn"     },
    --nscan       =   { dsClass = "NscanExtn"     },
    --sshd        =   { dsClass = "SshdExtn"      },
    upnp        =   { dsClass = "UpnpExtn"      },
    --ripng       =   { dsClass = "RipngExtn"     },
    --ddns        =   { dsClass = "DdnsExtn"      },
    igmp        =   { dsClass = "IgmpExtn"      },
    --snmp        =   { dsClass = "SnmpExtn"      },
    rip         =   { dsClass = "RipExtn"       },
    mediaServer =   { dsClass = "MediaServerExtn"},
    smbServer   =   { dsClass = "SmbServerExtn"},
    dhcpr       =   { dsClass = "DhcpRelayExtn"},
    dhcp6r      =   { dsClass = "Dhcpv6RelayExtn"},
    ndppd      =   { dsClass = "NdppdExtn"},
}

function AppExtnClassRegistry.getDsClassTbl()
   return appExtnClassTable
end

return AppExtnClassRegistry 
