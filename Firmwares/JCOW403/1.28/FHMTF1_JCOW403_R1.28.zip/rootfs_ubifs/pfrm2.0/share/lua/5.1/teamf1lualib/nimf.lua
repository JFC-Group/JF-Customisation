--[[
#### Copyright (c) 2012, TeamF1, Inc
#### www.TeamF1.com
#### Jan11, 2012
#### Description: Network Manager

#### Revisions: None
]]--

require "teamf1lualib/db"
require "teamf1lualib/util"

nimf = {}
nimf.limits = {}
nimf.limits.NIMF_NET_NAME_SZ= 32
nimf.debug = 0

require "teamf1lualib/nimfUtil"
require "nimfLib"
require "teamf1lualib/nimfConn"

--------------------------------------------------------------------------------
-- Enumeration for nimf.proto
-- @class table
-- @name nimf.proto
--
-- @field  nimf.proto.NIMF_PROTO_TYPE_IPV4 =   2,
-- @field  nimf.proto.NIMF_PROTO_TYPE_IPV6 =   10,
--

nimf.proto = {
    NIMF_PROTO_TYPE_IPV4 = 2,
    NIMF_PROTO_TYPE_IPV6 = 10,
}

--------------------------------------------------------------------------------
-- Enumeration for nimf.method
-- @class table
-- @name nimf.method
--
-- @field  nimf.method.NIMF_CONN_NONE                   =   0,
-- @field  nimf.method.NIMF_IPV4_CONN_STATIC            =   1,
-- @field  nimf.method.NIMF_IPV6_CONN_STATIC            =   2,
-- @field  nimf.method.NIMF_IPV4_CONN_DHCP              =   3,
-- @field  nimf.method.NIMF_IPV6_CONN_DHCP              =   4,
-- @field  nimf.method.NIMF_IPV4_CONN_PPPOE             =   5,
-- @field  nimf.method.NIMF_IPV4_CONN_PPTP              =   6,
-- @field  nimf.method.NIMF_IPV4_CONN_L2TP              =   7,
-- @field  nimf.method.NIMF_IPV6_CONN_DHCP_STATELESS    =   8,
-- @field  nimf.method.NIMF_IPV6_CONN_AUTO              =   9,
-- @field  nimf.method.NIMF_CONN_MAX                    =  10,
--
nimf.method = {
    NIMF_CONN_NONE                      = 0,
    NIMF_IPV4_CONN_STATIC               = 1,        
    NIMF_IPV6_CONN_STATIC               = 2,        
    NIMF_IPV4_CONN_DHCP                 = 3,        
    NIMF_IPV6_CONN_DHCP                 = 4,        
    NIMF_IPV4_CONN_PPPOE                = 5,
    NIMF_IPV4_CONN_PPTP                 = 6,       
    NIMF_IPV4_CONN_L2TP                 = 7,
    NIMF_IPV6_CONN_DHCP_STATELESS       = 8,
    NIMF_IPV6_CONN_AUTO                 = 9,
    NIMF_CONN_MAX                       =10,
}

--------------------------------------------------------------------------------
-- Enumeration for nimf.err
-- @class table
-- @name nimf.err
--
-- @field  nimf.err.NIMF_ERR_INVALID_ARG        =   -1,
-- @field  nimf.err.NIMF_ERR_INVALID_NETID      =   -2,
-- @field  nimf.err.NIMF_ERR_INVALID_PROTOCOL   =   -3,
-- @field  nimf.err.NIMF_ERR_INVALID_CONNKEY    =   -4,
-- @field  nimf.err.NIMF_ERR_DB_QUERY           =   -5,
-- @field  nimf.err.NIMF_ERR_DB_DELETE          =   -6,
-- @field  nimf.err.NIMF_ERR_DB_ADD             =   -7,
-- @field  nimf.err.NIMF_ERR_DB_UPDATE          =   -8,
--

nimf.err = {
    NIMF_ERR_INVALID_ARG        = -1,
    NIMF_ERR_INVALID_NETID      = -2,
    NIMF_ERR_INVALID_PROTOCOL   = -3,
    NIMF_ERR_INVALID_CONNKEY    = -4,
    NIMF_ERR_DB_QUERY           = -5,    
    NIMF_ERR_DB_DELETE          = -6,    
    NIMF_ERR_DB_ADD             = -7,    
    NIMF_ERR_DB_UPDATE          = -8,    
}

--------------------------------------------------------------------------------
-- Enumeration for nimf.iface
-- @class table
-- @name nimf.iface
--
-- @field  nimf.iface.NIMF_IF_STATE_DOWN    =   1,
-- @field  nimf.iface.NIMF_IF_STATE_UP      =   2,
--

nimf.iface = {
    NIMF_IF_STATE_DOWN      = 1,
    NIMF_IF_STATE_UP        = 2,
}

-------------------------------------------------------------------------------
-- @name nimf.netStart 
--
-- @description This function starts the network
--
-- @param LogicalIfName NET ID
--
-- @return  status, errCode
--

function nimf.netStart (LogicalIfName)
    local status

    -- validate the parameters
    if (nimf.LogicalNameValidate(LogicalIfName) < 0) then
        return "ERROR",nimf.err.NIMF_ERR_INVALID_NETID
    end        

    -- send message to the NIMF daemon
    status = nimfLib.netStart(LogicalIfName)
    if (status ~= 0) then
        return "ERROR", status
    end        

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name nimf.netStop 
--
-- @description This function stops the network
--
-- @param LogicalIfName NET ID
--
-- @return  status, errCode
--

function nimf.netStop (LogicalIfName)
    local status

    -- validate the parameters
    if (nimf.LogicalNameValidate(LogicalIfName) < 0) then
        return "ERROR",nimf.err.NIMF_ERR_INVALID_NETID
    end        

    -- send message to the NIMF daemon
    status = nimfLib.netStop(LogicalIfName)
    if (status ~= 0) then
        return "ERROR", status
    end        

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name nimf.netEnable
--
-- @description This function enables the network
--
-- @param LogicalIfName NET ID
--
-- @return  status, errCode
--

function nimf.netEnable (LogicalIfName)
    local connTbl = {}
    local query =  nil
    local status = "ERROR"
    local errCode = "NIMF_ERR_INVALID_PARAMS"

    if (LogicalIfName == nil) then
        return status, errCode
    end

    require "teamf1lualib/nimfConn"
    -- get list of all the connection(s) 
    query = "LogicalIfName='" .. LogicalIfName .. "'"
    status, errCode, connTbl = nimfConn.cfgByQueryGet(query)
    if (status ~= "OK") then
        return status, errCode
    end        

    -- enable each one of them
    for k,v in pairs(connTbl) do
        if (tonumber(v["Enable"]) ~= 1) then
            v["Enable"] = "1"
            status, errCode = nimfConn.cfgUpdate (v)
            if (status ~= "OK") then
                nimf.dprintf("Failed to update network connection: " ..  nimf.connStrGet(v))
            end                
        end
    end

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name nimf.netDisable
--
-- @description This function enables the network
--
-- @param LogicalIfName NET ID
--
-- @return  status, errCode
--

function nimf.netDisable (LogicalIfName)
    local connTbl = {}
    local query =  nil
    local status = "ERROR"
    local errCode = "NIMF_ERR_INVALID_PARAMS"

    if (LogicalIfName == nil) then
        return status, errCode
    end

    require "teamf1lualib/nimfConn"
    -- get list of all the connection(s) 
    query = "LogicalIfName='" .. LogicalIfName .. "'"
    status, errCode, connTbl = nimfConn.cfgByQueryGet(query)
    if (status ~= "OK") then
        return status, errCode
    end        

    -- disable each one of them
    for k,v in pairs(connTbl) do
        if (tonumber(v["Enable"]) ~= 0) then
            v["Enable"] = "0"
            status, errCode = nimfConn.cfgUpdate (v)
            if (status ~= "OK") then
                nimf.dprintf("Failed to update network connection: " ..  nimf.connStrGet(v))
            end                
        end
    end

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name nimf.connListGet
--
-- @description This function gets the list of all connections
--
-- @param nil
--
-- @return  status, errCode, connList
--

function nimf.connListGet ()
    local connTbl = {}
    local connList = {}
    local status = "ERROR"
    require "teamf1lualib/nimfConn"
    require "nimfLib"

    -- get list of all the connection(s) 
    status, errCode, connTbl = nimfConn.cfgByQueryGet()
    if (status ~= "OK") then
        return status, errCode
    end        

    for k,v in pairs(connTbl) do
        local conn = nimfLib.connGet(v)
        if (conn ~= nil) then
            table.insert(connList, conn)
        end            
    end

    return "OK","STATUS_OK", connList
end

--------------------------------------------------------------------------------
--@name  dot11.getDefWifiCfg () 
--
--@description The function will get the default configuration from the various tables
--
--@return

function nimf.getDefConnCfg () 

	--locals
	local row = {}
	local inputTable = {}
	local nimfTable = {}
	local query = nil
	
	--getting the connection type
	query = "LogicalIfName='IF1' AND addressFamily=2"	
    row = db.getRowWhere("NimfConf", query, false)
    if (row == nil) then
		return inputTable
    end
	
	nimfTable["connection_type"] = row["ConnectionType"]
	--getting the values from ipAddressTable
	query = "LogicalIfName='IF1' AND addressFamily=2 AND ConnectionKey=0"	
	row =  db.getRowWhere("ipAddressTable", query, false)
	if (row ~= nil) then
		nimfTable["ipAddress"] = row["ipAddress"]		
		nimfTable["subnetMask"] = row["subnetMask"]			
    else
    	nimfTable["ipAddress"] = ""		
		nimfTable["subnetMask"] = ""			
    end

	--getting the dns names from resolverConfig
	query = "LogicalIfName='IF1' AND addressFamily=2 AND ConnectionKey=0"	
	row = db.getRowWhere("resolverConfig", query, false)
	if (row ~= nil) then
		nimfTable["nameserver1"] = row["nameserver1"]			
		nimfTable["nameserver2"] = row["nameserver2"]
    else
    	nimfTable["nameserver1"] = ""			
		nimfTable["nameserver2"] = ""
    end


	--getting the gateway from defaultRouters
	query = "LogicalIfName='IF1' AND addressFamily=2 AND ConnectionKey=0"	
	row = db.getRowWhere("defaultRouters", query, false)
	if (row ~= nil) then
		nimfTable["Gateway"] = row["nextHopGateway"]
    else
		nimfTable["Gateway"] = ""
    end

	
	--getting the values from Pppoe table
	query = "LogicalIfName='IF1'"
	row = db.getRowWhere("Pppoe", query, false)
	if (row ~= nil) then
		nimfTable["pppoe_GetIpFromIsp"] = row["GetIpFromIsp"]
		nimfTable["pppoe_StaticIp"] = row["StaticIp"]
		nimfTable["pppoe_NetMask"] = row["NetMask"]
		nimfTable["pppoe_UserName"] = row["UserName"]
		nimfTable["pppoe_Password"] =	row["Password"]
		nimfTable["pppoe_DomainName"] = row["DomainName"]
		nimfTable["pppoe_IdleTimeOutFlag"] = row["IdleTimeOutFlag"]
		nimfTable["pppoe_IdleTimeOutValue"] = row["IdleTimeOutValue"]
	else
        nimfTable["pppoe_GetIpFromIsp"] = ""
        nimfTable["pppoe_StaticIp"] = ""
		nimfTable["pppoe_NetMask"] = ""
		nimfTable["pppoe_UserName"] = ""
		nimfTable["pppoe_Password"] =	""
		nimfTable["pppoe_DomainName"] = ""
        nimfTable["pppoe_IdleTimeOutFlag"] =	""
		nimfTable["pppoe_IdleTimeOutValue"] = ""
	end


	--getting the values from Pptp table
	query = "LogicalIfName='IF1'"
	row = db.getRowWhere("Pptp", query, false)
	if (row ~= nil) then
		nimfTable["pptp_UserName"] = row["UserName"]
		nimfTable["pptp_Password"] = row["Password"]
		nimfTable["pptp_MyIp"] = row["MyIp"]
		nimfTable["pptp_ServerIp"] = row["ServerIp"]
		nimfTable["pptp_StaticIp"] = row["StaticIp"]
		nimfTable["pptp_NetMask"] = row["NetMask"]
		nimfTable["pptp_PrimaryDns"] = row["PrimaryDns"]
		nimfTable["pptp_SecondaryDns"] = row["SecondaryDns"]
		nimfTable["pptp_IdleTimeOutFlag"] = row["IdleTimeOutFlag"]
		nimfTable["pptp_IdleTimeOutValue"] = row["IdleTimeOutValue"]
	else
		nimfTable["pptp_UserName"] = ""
		nimfTable["pptp_Password"] = ""
		nimfTable["pptp_MyIp"] = ""
		nimfTable["pptp_ServerIp"] = ""
		nimfTable["pptp_StaticIp"] = ""
		nimfTable["pptp_NetMask"] = ""
		nimfTable["pptp_PrimaryDns"] = ""
		nimfTable["pptp_SecondaryDns"] = ""
		nimfTable["pptp_IdleTimeOutFlag"] = ""
		nimfTable["pptp_IdleTimeOutValue"] = ""
	end

    --getting the values from Pptp table
	query = "LogicalIfName='IF1'"
	row = db.getRowWhere("L2tp", query, false)
	if (row ~= nil) then
		nimfTable["l2tp_UserName"] = row["UserName"]
		nimfTable["l2tp_Password"] = row["Password"]
		nimfTable["l2tp_MyIp"] = row["MyIp"]
		nimfTable["l2tp_ServerIp"] = row["ServerIp"]
		nimfTable["l2tp_StaticIp"] = row["StaticIp"]
		nimfTable["l2tp_NetMask"] = row["NetMask"]
		nimfTable["l2tp_PrimaryDns"] = row["PrimaryDns"]
		nimfTable["l2tp_SecondaryDns"] = row["SecondaryDns"]
		nimfTable["l2tp_IdleTimeOutFlag"] = row["IdleTimeOutFlag"]
		nimfTable["l2tp_IdleTimeOutValue"] = row["IdleTimeOutValue"]
	else
		nimfTable["l2tp_UserName"] = ""
		nimfTable["l2tp_Password"] = ""
		nimfTable["l2tp_MyIp"] = ""
		nimfTable["l2tp_ServerIp"] = ""
		nimfTable["l2tp_StaticIp"] = ""
		nimfTable["l2tp_NetMask"] = ""
		nimfTable["l2tp_PrimaryDns"] = ""
		nimfTable["l2tp_SecondaryDns"] = ""
		nimfTable["l2tp_IdleTimeOutFlag"] = ""
		nimfTable["l2tp_IdleTimeOutValue"] = ""
	end

    -- TODO
	--getting the status
    require "teamf1lualib/network"
	local name  =  db.getAttribute("networkInterface", "LogicalIfName", "IF1" , "networkName")
    local statusTbl = {}
    local err, statusMsg
    err, statusMsg, statusTbl = network.statusGet(name)
    if ((err == "OK") and (statusTbl ~= nil)) then
        nimfTable["status"] = statusTbl["Status"]   
    end

    --return
	return nimfTable	
end

-------------------------------------------------------------------------------
-- @name nimf.validateAddrInNetwork  
-- 
-- @description This function checks if the address belongs to the subnet/prefix
-- configured on the given interface
-- 
-- @param addr    address to be validated
-- @param ifname  interface being configured
--
-- @return 
-- -3 other errors
-- -2 invalid addresss
-- -1 no address configured on the interface
--  0 address does not belong to the same network
--  1 if the address belongs to same subnet/network 
--

function nimf.validateAddrInNetwork (addr, ifname)
	local ipRows = {}
	local family = nimfLib.addrFamilyGet(addr)
    local where = "LogicalIfName = '" .. ifname .. "' and addressFamily=" .. family 

	-- get all the addresses that belong to the 
	-- specified interface
	ipRows = db.getRowsWhere("ipAddressTable", where, false)
	if (ipRows == nil) then
		return -1
	end

	for k,v in pairs(ipRows) do 
		if (family == 2) then
			
			if (nimfLib.subnetCompare(addr, v["ipAddress"], v["subnetMask"]) == 1) then
				return 1
			end
		else
			-- get the network prefix of the address on the interface
			addr1 = nimfLib.prefixGet(v["ipAddress"], v["ipv6PrefixLen"])
			if (addr1 == nil) then
				return -3
			end

			-- get the network prefix of the given address
			addr2 = nimfLib.prefixGet(addr, v["ipv6PrefixLen"])
			if (addr2 == nil) then
				return -2
			end
		
			-- check if both the prefixes are equal
			if (nimfLib.prefixCompare(addr1, addr2) == 1) then
				return 1
			end
		end
	end

	return 0
end

-------------------------------------------------------------------------------
-- @name nimf.import
--
-- @description This function  imports nimf configuration.
--
-- @param conftable nimf configuration
--

function nimf.import (inputTable, defaultCfg, remCfg)
    if (inputTable == nil) then
        inputTable = defaultCfg
    end

    -- Array of Ethernet based WAN devices.
    local ethWANBoardIds = {"/pfrm2.0/HW_HG260ES", "/pfrm2.0/ETHERNET_ONLY", "/pfrm2.0/HW_JCE410", "/pfrm2.0/DEVICE_REPEATER"}
    local ethernetDevice = 0
	local  configMergeDone = "0"
    local singleApSupport = "0"
    singleApSupport = db.getAttribute ("environment", "name", "SINGLE_AP_SUPPORT" ,"value")


   --initializing a temp table
    local configTable = {}

    configTable = config.update (inputTable, defaultCfg, remCfg)
   
    if (configTable ~= nil and #configTable ~= 0) then
        
        for key,value in pairs (ethWANBoardIds) do
            if (util.fileExists (value) ) then
                ethernetDevice = 1
            end
        end

        for i,v in ipairs (configTable) do
            v = util.addPrefix (v, "NimfConf.");
	        -- RJIL needs default mode as stateless, for Ethernet devices
            if (v["NimfConf.LogicalIfName"] == "IF1" and v["NimfConf.AddressFamily"] == "10") then
                if(util.fileExists("/flash/configMerge/ipv6WanDefaults") == false) then
                    if (tonumber(ethernetDevice) == 1) then
                        v["NimfConf.ConnectionType"] = "dhcp6c-stateless"
                    else
                        v["NimfConf.ConnectionType"] = "dhcp6c"
                    end
                    configMergeDone = "1"
                else
                    if (tonumber(ethernetDevice) == 0) then
                        v["NimfConf.ConnectionType"] = "dhcp6c"
                    end
                end

                if (v["NimfConf.ConnectionType"] == "ifStatic6") then
                    os.execute("touch /tmp/wanStatic")
                end                
            end
            if (singleApSupport ~= nil and singleApSupport == "1") then
                if (v["NimfConf.LogicalIfName"] ~= "IF4" and v["NimfConf.LogicalIfName"] ~= "IF5") then
                    local valid, errstr, rowid = nimf.config (v, -1, "add")
                end
            else
                if (v["NimfConf.LogicalIfName"] ~= "IF4" and v["NimfConf.LogicalIfName"] ~= "IF5" and v["NimfConf.LogicalIfName"] ~= "IF6" and v["NimfConf.LogicalIfName"] ~= "IF7") then
                    local valid, errstr, rowid = nimf.config (v, -1, "add")
                end
            end
            if (not valid and errstr ~= nil) then
                nimf.dprintf ("ERR: " .. errstr)
            end            
        end
		if (configMergeDone == "1") then
			local ipv6WanDefaults = io.open("/flash/configMerge/ipv6WanDefaults", "w")                                                          
            if(ipv6WanDefaults ~= nil) then                                                                       
            	ipv6WanDefaults:close()                                                                           
            end
			-- touch saveDB flag to do a DB export to flash after import is complete
			local saveDBFile  = io.open("/tmp/callDbSave", "w")                                                          
            if(saveDBFile ~= nil) then                                                                       
            	saveDBFile:close()                                                                           
           	end	
		end

    end
end

-------------------------------------------------------------------------------
-- @name nimf.export
--
-- @description This function exports nimf configuration
--
-- @return nimf configuration
--

function nimf.export ()
	return db.getTable ("NimfConf", false)
end

--
--
--      INTERNAL FUNCTIONS
--
--

require "teamf1lualib/config"
if (config.register) then
   config.register("nimf", nimf.import, nimf.export, "1")
end
