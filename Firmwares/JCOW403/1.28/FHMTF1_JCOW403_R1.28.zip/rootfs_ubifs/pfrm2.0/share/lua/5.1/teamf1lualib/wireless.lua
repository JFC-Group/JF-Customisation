-- gui.Wireless.lua - lua wrapper calls for Wireless of Main Firmware

-- Copywrite (c) 2013 TeamF1, Inc.

--
-- modification history
-- --------------------
-- 01o, 23Nov17, swr changes for spr 62635(XSS vulnerability)  and 61441
-- 01n, 29Aug17, sjr changes for WIFI optimization
-- 01m, 26May17, sjr Added support for the Custom LAN feature for AP's.
-- 01l, 18Apr17, sjr removed WEP/WPA information on WPS warning message.
-- 01k, 28Mar16, sjr removed PIN information WPS page
-- 01j, 07Dec16, sjr Fixed Lua error in WLAN clients page
-- 01i, 30Nov16, sjr Added to get channel info from Driver 
-- 01h, 23Nov16, sjr Added changes for ALU project
-- 01g, 31Aug16, sjr Fixed Lua error in AP page
-- 01f, 23Aug16, vip Added nil check for WPA password
-- 01e, 25Jul16, sjr Added changes to profile password related changes (#56837)
-- 01d, 08Oct14, sjr added logic for security as WEP/TKIP its operating in legacy mode
-- 01c, 02Sep13, sen do not allow RADIUS if WPS is enabled on AP.
-- 01b, 20Aug13, sen corrected logic for displaying client from multiple APs
-- 01a, 12Mar13, sen dervied from reference solution. for RIL.
--


---------------------------------------------------------------------------------
--  The routines in this lua wrapper are called by htm(user interface) layer to 
--  get the information to display Wireless Information
---------------------------------------------------------------------------------


gui.wireless = {}
gui.helper = {}

--[[Wireless settings]]--
--Access Point Setup
gui.wireless.apProfileInfo = {}
gui.wireless.apProfileInfo.edit = {}
gui.wireless.wizardProfileInfo = {}
gui.wireless.wizardProfileInfo.edit = {}

-- Profiles Setup
gui.wireless.profileInfo = {}
gui.wireless.profileInfo.edit = {}
--Radio Setup
gui.wireless.radio = {}
--WIFI Protection Setup
gui.wireless.wps = {}
gui.wireless.wpsStatus = {}
--Access Control List
gui.wireless.acl = {}
gui.wireless.acl.add = {}

-- Connected Clients
gui.wireless.clients = {}
-- EoGRE Setup
gui.wireless.profileInfoeogre = {}

-- wmm settings
gui.wireless.wmm = {}

-- dscp remark setting
gui.wireless.dscpMap = {}

-- cos remark setting
gui.wireless.cosMap = {}

-- cos remark setting
gui.wireless.dscpToCosMap = {}

-- apgroupname setting
gui.wireless.apgroupname = {}

-- Wireless mesh 
gui.wireless.easyMesh = {}
gui.wireless.easyMesh.topology = {}

local CMD_EXEC_SCRIPT = "/tmp/cmdExecscript.sh"
local SH_BIN          = "/bin/sh "

function gui.wireless.easyMesh.topology.get()
      local json = require ("teamf1lualib/json")
      require "teamf1lualib/easyMeshTopologyLib"

      local meshTopology_t = {}
      local topologyJson = nil
      local status , errorCode
      status, errorCode, meshTopology_t = easyMeshTopologyLib.getEasyMeshTopologyNodesAndEdges()
      if(status == "ERROR") then
          return status, errorCode, nil
      end

      topologyJson = json.encode(meshTopology_t)
      return "OK", "TOPOLOGY_GET_SUCCESS", topologyJson
end

function convertModes(band, modeValue, flag)
    if(flag == "1") then
      if band == "a" then
        if modeValue == '65536' then --a only
            return "1"
        elseif modeValue == '983040' then --a/n/ac
            return "2"
        elseif modeValue == '983041' then --ac only
            return  "3"
       --[[ elseif modeValue == '983040' then --n only
            return "4"
        elseif modeValue == '983040' then --a/n
            return "5"
        elseif modeValue == '983040' then --n/ac
            return "6" ]]--
        end
      end
      if band == "b" then
        if modeValue == '212992' then -- b and g
            return "1"
        --[[elseif modeValue == '196608' then -- b only
            return "2"
        elseif modeValue == '196608' then -- b/g/n
            return "3" ]]--
        elseif modeValue == '131072' then --n only
            return  "4"
        elseif modeValue == '475136' then --ng
            return  "5"
        elseif modeValue == '196608' then -- g only
            return "6"
        end
      end
      return "1"
    end
    if(flag == "0") then
      if band == "a" then
        if modeValue == "1" then --a only
            return "65536"
        elseif modeValue == "2" then --a/n/ac
            return "983040"
        elseif modeValue == "3" then --ac only
            return  "983041"
        --[[elseif modeValue == "4" then --n only
            return "983040"
        elseif modeValue == "5" then --a/n
            return  "983041"
        elseif modeValue == "6" then -- n/ac 
            return  "983041"]]--
        end
      end
      if band == "b" then
        if modeValue == "1" then -- b and g
            return "212992"
        --[[elseif modeValue == "2" then -- b only
            return "196608"
        elseif modeValue == "3" then -- b/g/n
            return  "131072"]]--
        elseif modeValue == "4" then --n only
            return  "131072"
        elseif modeValue == "5" then --ng
            return  "475136"
        elseif modeValue == "6" then --g only
            return  "196608"
        end
      end
    return "131072"
    end
end

-------------------------------------------------------------------------------
-- @name gui.wireless.ledConfigure
--
-- @description This function will set led behavior of wps led
--
-- @return 
--
function gui.wireless.ledConfigure ()
    require "dot11Lib"

    local cmd = "echo "
    local radioState = dot11.GetRadioState ();
       
    if (radioState == 1) then
        cmd = cmd .. " WG1 > /proc/led"
    else
        cmd = cmd .. " WG0 > /proc/led"
    end
    
    os.execute (cmd);
end

-------------------------------------------------------------------------------
-- @name gui.wireless.apInfo.status (rows)
--
-- @description This function will enable/disable AP on the system.
--
-- @return 
--
function gui.wireless.apProfileInfo.status (rows, operation, dbFlag)

    --include
    require "teamf1lualib/dot11_ul"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- Making dbFlag 1, to perform db transactions
    if (dbFlag == nil) then
        dbFlag = 1
    end

    --EoGRE Check
    errMsg, status = eogreAPcheck (rows)
    if (errMsg=="ERROR")then
        return errMsg, status
    end

    if (dbFlag == 1) then
        db.beginTransaction() -- begin transcation
    end

    errMsg, status = ul_dot11.apProfileInfo.status (rows, operation)

    --return
    if (errMsg == "OK") then
        -- run led script to take care of updating leds
        os.execute ("echo \'/pfrm2.0/bin/lua /pfrm2.0/bin/led.lua\' >> "..CMD_EXEC_SCRIPT)
	if(util.fileExists("/usr/bin/embedur/wifi_reloaded.sh")) then
	        os.execute ("echo \'/bin/sh /usr/bin/embedur/wifi_reloaded.sh 1\' >> "..CMD_EXEC_SCRIPT)
	end
        if (dbFlag == 1) then 
            db.commitTransaction()
            db.save2()
            util.runShellCmd (SH_BIN..CMD_EXEC_SCRIPT)
            os.remove (CMD_EXEC_SCRIPT)
            if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then
                dot11meshReStart ()
            end
        end
    else
        if (dbFlag == 1) then
            db.rollback()
        end
    end
    return errMsg, status

end

-------------------------------------------------------------------------------
-- @name gui.wireless.profileInfo.delete
--
-- @description This function will remove the given profile(s) from the system
--
-- @return 
--
function gui.wireless.profileInfo.delete (rows)
  --include
  require "teamf1lualib/dot11"

  -- Sanity for privilages
  if (ACCESS_LEVEL ~= 0) then
    return "ACCESS_DENIED", "ADMIN_REQD"
  end

  --locals
  local status = nil
  local errMsg = nil

  db.beginTransaction() -- begin transcation

  --setting the new configuration in the users table
  errMsg, status = dot11.profile_config (rows,nil,"delete")

  if(errMsg == "OK")then
    db.commitTransaction()
    db.save2()
    return errMsg, status
  else
    db.rollback()
    return errMsg, status
  end
  --return
  return errMsg, status
end

-------------------------------------------------------------------------------
-- @name gui.wireless.wmm.set
--
-- @description This function will give configure the given wmm profile in the 
-- system.
--
-- @return 
--
function gui.wireless.wmm.set (inputTable, operation, dbFlag)
  --include
  require "teamf1lualib/dot11_ul"

  -- Sanity for privilages
  if (ACCESS_LEVEL ~= 0) then
    return "ACCESS_DENIED", "ADMIN_REQD"
  end

  -- Making dbFlag 1, to perform db transactions
  if (dbFlag == nil) then
      dbFlag = 1
  end
  --locals
  local status = "ERROR"
  local errMsg = "ERROR"
  local bssid
  local valid = false

  local rowid = db.getAttribute ("dot11Profile", "profileName", inputTable["dot11Profile.profileName"], "_ROWID_")
  if (dbFlag == 1)then
      --db.beginTransaction() -- begin transcation, commented begin, commit and
                              --rollback because only one db table operation.
  end

  bssid = db.getAttribute ("dot11Profile", "profileName", inputTable["dot11Profile.profileName"], "broadcastSSID")
  if (bssid ~= nil ) then
      inputTable["dot11Profile.broadcastSSID"] = bssid
  end
  valid = dot11Profile.config(inputTable, rowid, operation)

  if(valid)then
	if(util.fileExists("/usr/bin/embedur/wifi_reloaded.sh")) then
	      os.execute ("echo \'/bin/sh /usr/bin/embedur/wifi_reloaded.sh 1\' >> "..CMD_EXEC_SCRIPT)
	end
      if (dbFlag == 1)then
          --db.commitTransaction()
          db.save2()
          util.runShellCmd (SH_BIN..CMD_EXEC_SCRIPT)
          os.remove (CMD_EXEC_SCRIPT)
      end
      return "OK", "STATUS_OK"
  else
      if (dbFlag == 1)then
          --db.rollback()
          os.remove (CMD_EXEC_SCRIPT)
      end
      return "ERROR", "DOT11_PROFILE_CONFIG_FAILED"
  end
  
  return errMsg, status
end

-------------------------------------------------------------------------------
-- @name gui.wireless.profileInfo.set
--
-- @description This function will give information of available wireless profiles
-- in system.
--
-- @return 
--
function gui.wireless.profileInfo.set (inputTable, operation, dbFlag)
    --include
    require "teamf1lualib/dot11_ul"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (dbFlag == nil) then
        dbFlag = 1
    end

    --locals
    local status = nil
    local errMsg = nil
    
    -- EoGRE checking
    status, errMsg = eogrecheck (inputTable)
    if (status=="ERROR")then
        return status, errMsg
    end

    if (dbFlag == 1)then
        db.beginTransaction() -- begin transcation
    end
    errMsg, status =  ul_dot11.ProfileInfo.set (inputTable, operation)

    if(errMsg == "OK")then
	if(util.fileExists("/usr/bin/embedur/wifi_reloaded.sh")) then
        	os.execute ("echo \'/bin/sh /usr/bin/embedur/wifi_reloaded.sh 1\' >> "..CMD_EXEC_SCRIPT)
	end
        if (dbFlag == 1)then
            db.commitTransaction()
            db.save2()
            util.runShellCmd (SH_BIN..CMD_EXEC_SCRIPT)
            os.remove (CMD_EXEC_SCRIPT)
            if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then
                dot11meshReStart ()
            end
        end
        return errMsg, status
    else
        if (dbFlag == 1)then
            db.rollback()
            os.remove (CMD_EXEC_SCRIPT)
        end
        return errMsg, status
    end

end

-------------------------------------------------------------------------------
-- @name gui.wireless.profileInfo.editGet
--
-- @description This function will give information of available wireless profiles
-- in system.
--
-- @return 
--
function gui.wireless.profileInfo.editGet (configRowId)
    -- require
    require "teamf1lualib/dot11"

    -- locals
    local inputTbl = {}
    local nilTable = {}
    local err, statusMsg
    -- Logic
    inputTbl = dot11.ProfileGet(configRowId)
    if (inputTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN",nilTable
    end
    err = "OK"
    statusMsg = ""

    inputTbl["ssid"] = util.filterXSSChars(inputTbl["ssid"])
    inputTbl["pskPassAscii"] = util.filterXSSChars(inputTbl["pskPassAscii"])
    inputTbl["profileName"] = util.filterXSSChars(inputTbl["profileName"])
    inputTbl["broadcastSSID"] = util.filterXSSChars(inputTbl["broadcastSSID"])
    inputTbl["security"] = util.filterXSSChars(inputTbl["security"])
    inputTbl["pairwiseCiphers"] = util.filterXSSChars(inputTbl["pairwiseCiphers"])
    inputTbl["authMethods"] = util.filterXSSChars(inputTbl["authMethods"])

    -- return
    return err, statusMsg, inputTbl

end

-------------------------------------------------------------------------------
-- @name gui.wireless.profileInfo.get
--
-- @description This function will give information of available wireless profiles
-- in system.
--
-- @return 
--
function gui.wireless.profileInfo.get ()
    -- require
    require "teamf1lualib/dot11"

    -- locals
    local inputTbl = {}
    local nilTable = {}
    local err, statusMsg
    
    -- Logic
    inputTbl = dot11.ProfilesGet()
	if (inputTbl == nil) then
		return "ERROR", "DB_ERROR_TRY_AGAIN",nilTable
	end
    err = "OK"
    statusMsg = ""

    for i,v in ipairs (inputTbl) do
        inputTbl[i] = {}
        inputTbl[i] = v
        inputTbl[i].profileName = util.filterXSSChars(v["profileName"])
        inputTbl[i].ssid = util.filterXSSChars(v["ssid"])
        inputTbl[i].broadcastSSID = util.filterXSSChars(v["broadcastSSID"])
        inputTbl[i].security = util.filterXSSChars(v["security"])
        inputTbl[i].pairwiseCiphers = util.filterXSSChars(v["pairwiseCiphers"])
        inputTbl[i].authMethods = util.filterXSSChars(v["authMethods"])
    end

    -- return
    return err, statusMsg, inputTbl

end

-------------------------------------------------------------------------------
-- @name gui.wireless.apProfileInfo.get
--
-- @description This function will give information of available wireless access points
-- in system.
--
-- @return 
--
function gui.wireless.apProfileInfo.get ()

	
    -- require
    require "teamf1lualib/dot11"

    -- locals
    local inputTbl = {}
    local nilTable = {}
    local err, statusMsg
    
    -- Logic
    inputTbl = dot11.accessPointGet()
    if (inputTbl == nil) then
      return "ERROR", "DB_ERROR_TRY_AGAIN",nilTable
    end

    for i,v in ipairs (inputTbl) do
        inputTbl[i] = {}
        inputTbl[i] = v
        inputTbl[i].vapName = util.filterXSSChars(v["vapName"])
        inputTbl[i].vapEnabled = util.filterXSSChars(v["vapEnabled"])
        inputTbl[i].ssid = util.filterXSSChars(v["ssid"])
        inputTbl[i].broadcastSSID = util.filterXSSChars (v["broadcastSSID"])
        inputTbl[i].profileName = util.filterXSSChars (v["profileName"])
    end

    err = "OK"
    statusMsg = ""
 
    -- return
    return err, statusMsg, inputTbl
end

--
gui.wireless.apGuestInfo = {}
function gui.wireless.apGuestInfo.get ()
    -- require
    require "teamf1lualib/dot11"

    -- locals
    local inputTbl = {}
    local nilTable = {}
    local err, statusMsg
    
    -- Logic
    inputTbl = dot11.guestAccessPointGet()
    if (inputTbl == nil) then
      return "ERROR", "DB_ERROR_TRY_AGAIN",nilTable
    end
    err = "OK"
    statusMsg = ""
 
    -- return
    return err, statusMsg, inputTbl
end


-------------------------------------------------------------------------------
-- @name gui.wireless.apProfileInfo.edit.get
--
-- @description This function will provide the information for a particular
-- access point which needs to be edited
--
-- @param rowid for which access point configuration has to be queried.
--
-- @return 
--
function gui.wireless.profileInfo.edit.get (rowid)

    -- require
    require "teamf1lualib/dot11"

    -- locals
    local accessPointTbl = {}
    local nilTable = {}
    local err, statusMsg
 
    -- Logic
    accessPointTbl = dot11.profilesEditGet(rowid)
    if (accessPointTbl == nil) then
		return "ERROR", "DB_ERROR_TRY_AGAIN",nilTable
	end
    err = "OK"
    statusMsg = ""
	
    -- return
    return err, statusMsg, accessPointTbl

end

-------------------------------------------------------------------------------
-- @name gui.wireless.apProfileInfo.edit.get
--
-- @description This function will provide the information for a particular
-- access point which needs to be edited
--
-- @param rowid for which access point configuration has to be queried.
--
-- @return 
--
function gui.wireless.apProfileInfo.edit.get (rowid)

    -- require
    require "teamf1lualib/dot11"

    -- locals
    local accessPointTbl = {}
    local profileTbl = {}
    local nilTable = {}
    local err, statusMsg
    local getDefaultSubnet1
    local getDefaultSubnet2
    local getDefaultSubnet3
 
    -- Logic
    if (rowid ~= "-1") then
        accessPointTbl = db.getRow ("dot11VAP", "_ROWID_", rowid)
        accessPointTbl["vapNameEditStatus"] = "DISABLED"
    else
        accessPointTbl = db.getDefaults(true, "dot11VAP")
    end

    profileTbl = db.getTable ("dot11Profile")
    accessPointTbl.profileTbl = profileTbl
    if (accessPointTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN",nilTable
    end
    accessPointTbl["dot11VAP.vapName"] = util.filterXSSChars(accessPointTbl["dot11VAP.vapName"])
    accessPointTbl["dot11VAP.maxClients"] = util.filterXSSChars(accessPointTbl["dot11VAP.maxClients"])
    accessPointTbl["dot11VAP.profileName"] = util.filterXSSChars(accessPointTbl["dot11VAP.profileName"])

    err = "OK"
    statusMsg = ""
    
    accessPointTbl["dot11VAP.defaultSubnet"] = db.getAttribute ("dot11Interface", "vapName", accessPointTbl["dot11VAP.vapName"], "defaultLANSubnet") or ''

    if (accessPointTbl["dot11VAP.vapName"] == "ap2") then
        getDefaultSubnet1 = db.getAttribute ("dot11Interface", "vapName", "ap3", "defaultLANSubnet") or ''
        getDefaultSubnet2 = db.getAttribute ("dot11Interface", "vapName", "ap5", "defaultLANSubnet") or ''
        getDefaultSubnet3 = db.getAttribute ("dot11Interface", "vapName", "ap6", "defaultLANSubnet") or ''
    elseif (accessPointTbl["dot11VAP.vapName"] == "ap3") then
        getDefaultSubnet1 = db.getAttribute ("dot11Interface", "vapName", "ap2", "defaultLANSubnet") or ''
        getDefaultSubnet2 = db.getAttribute ("dot11Interface", "vapName", "ap5", "defaultLANSubnet") or ''
        getDefaultSubnet3 = db.getAttribute ("dot11Interface", "vapName", "ap6", "defaultLANSubnet") or ''
    elseif (accessPointTbl["dot11VAP.vapName"] == "ap5") then
        getDefaultSubnet1 = db.getAttribute ("dot11Interface", "vapName", "ap2", "defaultLANSubnet") or ''
        getDefaultSubnet2 = db.getAttribute ("dot11Interface", "vapName", "ap3", "defaultLANSubnet") or ''
        getDefaultSubnet3 = db.getAttribute ("dot11Interface", "vapName", "ap6", "defaultLANSubnet") or ''
    elseif (accessPointTbl["dot11VAP.vapName"] == "ap6") then
        getDefaultSubnet1 = db.getAttribute ("dot11Interface", "vapName", "ap2", "defaultLANSubnet") or ''
        getDefaultSubnet2 = db.getAttribute ("dot11Interface", "vapName", "ap3", "defaultLANSubnet") or ''
        getDefaultSubnet3 = db.getAttribute ("dot11Interface", "vapName", "ap5", "defaultLANSubnet") or ''
    end

    if ((getDefaultSubnet1 == "1") and (getDefaultSubnet2 == "1") and (getDefaultSubnet3 == "1")) then
        accessPointTbl["dot11VAP.defaultSubnetAll"] = 1
    else
        accessPointTbl["dot11VAP.defaultSubnetAll"] = 0
    end


    -- return
    return err, statusMsg, accessPointTbl

end


----------------------------------------------------------------------------------
-- @name   gui.wireless.apProfileInfo.apAddDelete (row, operation)
--
-- @description This function will set the information for a particular
--
-- access point which is being edited
--
-- @param new configuration table
--
-- @return 
--

function gui.wireless.apProfileInfo.apAddDelete (inputTable, operation)

    --require
    require "teamf1lualib/wifiSecMap"
    require "teamf1lualib/dot11"
    require "dot11Lib"
    
    local rowids = {}
    local query
    local valid = true
    local errorCode, statusMsg

    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (operation == "add" or "delete") then
        if (operation == "add" ) then
            rowid = "-1"
        end
    else
        return "ERROR", "Invalid operation"
    end

	db.beginTransaction() -- begin transcation

    -- add a new access point
    if (rowid == "-1" and operation == "add") then
        -- check if the profile is being used by any other access point
        local matchingRow = db.existsRowWhere("dot11VAP", "profileName = '" .. inputTable["dot11VAP.profileName"] .. "'")
        if (matchingRow) then
            return "ERROR", "Profile already being used by another AP"
        end
        local matchingRow = db.existsRowWhere("dot11Interface", "vapName = '" .. inputTable["dot11VAP.vapName"] .. "'")
        -- if the row does not exist, find new row and mark it used
        if (not matchingRow) then
            local freeRow = db.existsRowWhere("dot11Interface", "vapName = 'unused'")
            if (freeRow) then
                -- if free row exists, mark it used
                row = db.getRowWhere("dot11Interface", "vapName = 'unused'")
                local inTable = {}
                inTable = row
                inTable["dot11Interface.vapName"] = inputTable["dot11VAP.vapName"]
                valid = dot11Interface.config(inTable, freeRow, "edit")
                if (valid) then
                    inTable = util.removePrefix(inTable,"dot11VAP.")
                    errorCode, statusMsg = dot11.VAP_config (inputTable, rowid, operation)
                    config.recOp(dot11.VAP_start, inputTable["dot11VAP.vapName"] , true)
                else
                    return "ERROR", "DOT11_INTERFACE_CONFIG_FAILED"
                end
            else
               -- free access point is not available
               return "ERROR", "Max Access Points limit reached"
            end
        else
           return "ERROR", "Access Point name already exists"
        end
    end

    -- delete a existing access point
    if (rowid ~= "-1" and operation == "delete") then
        --get vap details from rowid
        query = "_ROWID_ = "..inputTable["1"]
        rowid = inputTable["1"]
        local dot11VapEntry = db.getRowWhere("dot11Vap", query, false)

        if(not(dot11VapEntry)) then
            util.appendDebugOut("unable to get dot11Vap Row from rowid - " .. rowid)
            return "ERROR", "DOT11_AP_CONFIG_FAILED"
        end
        inputTbl = util.addPrefix(dot11VapEntry,"dot11VAP.")
        if (inputTbl["dot11VAP.vapName"] == "ap1") then
            return "ERROR", "Cannot delete default Access Point"
        end
        local matchingRow = db.existsRowWhere("dot11Interface", "vapName = '" .. inputTbl["dot11VAP.vapName"] .. "'")
        -- if the row does not exist, return error
        if (not matchingRow) then
            return "ERROR", "AP name does not exists"
        else
            local inTable = {}
            dot11.VAP_start (inputTbl["dot11VAP.vapName"], false)
            inTable["dot11Interface.vapName"] = "unused"
            valid = dot11Interface.config(inTable, matchingRow, "edit")
            if (valid) then
                valid = dot11VAP.config (inputTable, rowid, operation)
            else
                return "ERROR", "DOT11_INTERFACE_CONFIG_FAILED"
            end
            if(valid) then
               errorCode   = "OK"
               statusMsg = "Operation succeeded"
            end
        end
    end

    if(errorCode == "OK")then
        db.commitTransaction()
        db.save2()
		-- run led script to take care of updating leds
 		os.execute ("/pfrm2.0/bin/lua /pfrm2.0/bin/led.lua")
        return errorCode, statusMsg
    else
        db.rollback()
        return errorCode, statusMsg
    end
end

----------------------------------------------------------------------------------
-- @name   gui.wireless.apProfileInfo.edit.set (dot11Table)
--
-- @description This function will set the information for a particular
--
-- access point which is being edited
--
-- @param new configuration table
--
-- @return 
--
 function gui.wireless.apProfileInfo.edit.set (cfgTbl, operation, dbFlag)

    --require
    
    require "teamf1lualib/wifiSecMap"
    require "teamf1lualib/dot11_ul"
    --require "dot11Lib"
    
    local errorCode, statusMsg
    local getDefaultSubnetAllVal = 0

    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD", getDefaultSubnetAllVal
    end

   -- Making dbFlag 1, to perform db transactions 
    if (dbFlag == nil) then
        dbFlag = 1
    end


    if (cfgTbl["dot11VAP.defaultSubnet"] == nil) then
        cfgTbl["dot11VAP.defaultSubnet"] = 1 
    end

    --EOGRE check
    errorCode, statusMsg = eogreAccessPointCheck(cfgTbl)
    if (errorCode == "ERROR")then
        return errorCode, statusMsg, getDefaultSubnetAllVal
    end    

    if(dbFlag == 1) then
        db.beginTransaction() -- begin transcation
    end
    
    errorCode, statusMsg = ul_dot11.apProfileInfo.edit.set (cfgTbl, operation)

    if(errorCode == "OK")then
	if(util.fileExists("/usr/bin/embedur/wifi_reloaded.sh")) then
        	os.execute ("echo \'/bin/sh /usr/bin/embedur/wifi_reloaded.sh 1\' >> "..CMD_EXEC_SCRIPT)
	end
        if (dbFlag == 1) then
            db.commitTransaction()
            db.save2()
            util.runShellCmd (SH_BIN..CMD_EXEC_SCRIPT)
            os.remove (CMD_EXEC_SCRIPT)
        end
        return errorCode, statusMsg, getDefaultSubnetAllVal
    else
        if (dbFlag == 1) then
            os.remove (CMD_EXEC_SCRIPT)
            db.rollback()
        end
        return errorCode, statusMsg, getDefaultSubnetAllVal
    end
end

-------------------------------------------------------------------------------
--@name gui.wireless.clients.get
--
--@description This function will get the connected clients information
--
--@return
--
function gui.wireless.clients.getAPStatus(rowid)
        
        --requires 
        require "teamf1lualib/util"

	local clientTable = {}
	local i  = 0
        local timeElapsed = ''
	local vapRow = db.getRow ("dot11VAP","_ROWID_",rowid)
	local vapName = vapRow ["dot11VAP.vapName"]
	local interfaceName = db.getAttribute ("dot11Interface", "vapName", vapName, "interfaceName")
	local radioNo = db.getAttribute ("dot11Interface", "vapName", vapName, "radioNo")
    	if(tonumber(vapRow ["dot11VAP.vapEnabled"]) == tonumber(1) and interfaceName ~= nil and radioNo ~= nil) then
            local cmd = "wl -i " ..interfaceName.." assoclist > /tmp/connected_clients"
            os.execute (cmd)
            local table1 = {}
            for line in io.lines("/tmp/connected_clients") do 
                table1[#table1 + 1] = string.gsub (line, "assoclist ", "")
            end
            if(table1 ~= nil) then
                for ii,row in pairs(table1) do
                    i = i+1
                    clientTable[i] = {}
                    clientTable[i].radioNo = radioNo
                    clientTable[i].macAddress = row
                    local cmd1= "wl -i " ..interfaceName.. " sta_info " ..clientTable[i].macAddress.. " assoclist | grep \"in\" | awk '{print($3)}' > /tmp/connected_clientInfo"
                    os.execute(cmd1)
                    local file = io.open("/tmp/connected_clientInfo","r")
                    if (file) then
                        timeElapsed = file:read ("*line")                                        
                        file:close()
                    end
                    -- not getting anything from driver, making the list on basis of current configuration
	            local profile = db.getRowWhere ("dot11Profile", "profileName= '"..vapRow["dot11VAP.profileName"].."'", false)
                    clientTable[i].security = profile["security"]
                    clientTable[i].authentication = profile["authMethods"]
                    if (profile["security"] == "WEP") then
                        if (profile["wepAuth"] == "Shared") then
                            clientTable[i].authentication = "Shared"
                        else
                            clientTable[i].authentication = "Open"
                        end	
                        if (profile["groupCipher"] == "64") then
                            clientTable[i].cipher = "64-bit"
                        else
                            clientTable[i].cipher = "128-bit"
                        end	
                    else
                        clientTable[i].cipher = profile ["pairwiseCiphers"]
                    end
                    if (profile["security"] == "OPEN") then
                        clientTable[i].authentication = "N/A"
                        clientTable[i].cipher = "N/A"
                    end
                    clientTable[i].timeConnected = util.timeConversion (timeElapsed)
                end
            end --table1 nil check
        end --vap enabled check
	return "OK", "STATUS_OK" , clientTable
end
-------------------------------------------------------------------------------
--@name gui.wireless.clients.get
--
--@description This function will get the connected clients information
--
--@return
--
function gui.wireless.clients.get()
    
    --requires 
    require "teamf1lualib/util"

    local clientTable = {}
    local i  = 0
    local timeElapsed = ''
    local enabledVAPs = db.getRowsWhere ("dot11VAP", "vapEnabled = 1")
    for m,n in pairs (enabledVAPs) do
        local vapName = n["dot11VAP.vapName"] or ''
        local table = db.getRowsWithJoin({"dot11VAP:dot11Interface:vapName"}, "dot11VAP.vapName", vapName)
        for k,v in pairs(table) do
            -- get the STA macs
            local cmd = "wl -i " ..v["dot11Interface.interfaceName"].." assoclist > /tmp/connected_clients"
            os.execute (cmd)
            local table1 = {}
            for line in io.lines("/tmp/connected_clients") do 
                table1[#table1 + 1] = string.gsub (line, "assoclist ", "")
            end
            if(table1 ~= nil ) then
                for ii,row in pairs(table1) do
                    i = i+1
                    clientTable[i] = {}
                    clientTable[i].vapName = v["dot11VAP.vapName"]
                    clientTable[i].radioNo = v["dot11Interface.radioNo"]
                    clientTable[i].macAddress = row
                    local cmd1= "wl -i " ..v["dot11Interface.interfaceName"].. " sta_info " ..clientTable[i].macAddress.. " assoclist | grep \"in\" | awk '{print($3)}' > /tmp/connected_clientInfo"
                    os.execute(cmd1)
                    local file = io.open("/tmp/connected_clientInfo","r")
                    if (file) then
                        timeElapsed = file:read ("*line")
                        file:close()
                    end

                    -- not getting anything from driver, making the list on basis of current configuration
	            local profile = db.getRowWhere ("dot11Profile", "profileName= '"..v["dot11VAP.profileName"].."'", false)
                    clientTable[i].security = profile["security"]
                    clientTable[i].authentication = profile["authMethods"]
                    if (profile["security"] == "WEP") then
                        if (profile["wepAuth"] == "Shared") then
                            clientTable[i].authentication = "Shared"
                        else
                            clientTable[i].authentication = "Open"
                        end	
                        if (profile["groupCipher"] == "64") then
                            clientTable[i].cipher = "64-bit"
                        else
                            clientTable[i].cipher = "128-bit"
                        end	
                    else
                        clientTable[i].cipher = profile ["pairwiseCiphers"]
                    end
                    if (profile["security"] == "OPEN") then
                        clientTable[i].authentication = "N/A"
                        clientTable[i].cipher = "N/A"
                    end
                    clientTable[i].timeConnected = util.timeConversion (timeElapsed)
                end 
            end -- table1 nil check
        end 
    end --enabled vap check 
    return "OK", "STATUS_OK" , clientTable
end

-------------------------------------------------------------------------------
--@name gui.wireless.radio.advancedGet
--
--@description This function will get the information of a radio for advanced 
--             parameters
--
--@return
--
function gui.wireless.radio.advancedGet(band)
    -- require
    require "teamf1lualib/dot11"

    --locals
	if(band == nil)then
		return "ERROR","DB_ERROR"
	end

    local radioTable = {}
    local query = "band='"..band.."'"
    radioTable = db.getRowWhere ("dot11Radio", query, false)
    if (radioTable == nil) then
        return "ERROR","DB_ERROR_TRY_AGAIN",nilTable
    end

    err = "OK"
    statusMsg = ""
    
    radioTable["beaconInterval"] = util.filterXSSChars (radioTable["beaconInterval"])
    radioTable["dtimInterval"] = util.filterXSSChars (radioTable["dtimInterval"])
    radioTable["rtsThreshold"] = util.filterXSSChars (radioTable["rtsThreshold"])
    radioTable["radioCountryRev"] = util.filterXSSChars (radioTable["radioCountryRev"])

    --return
    return err, statusMsg, radioTable

end

-------------------------------------------------------------------------------
--@name gui.wireless.wmm.get
--
--@description This function will get the wmm info for a given profile .
--
--@return
--
function gui.wireless.wmm.get (configRowId)
    -- require
    require "teamf1lualib/dot11"

    --locals
    local wmmTable = {}
    local query = "_ROWID_="..configRowId
    wmmTable = db.getRowWhere ("dot11Profile", query, false)
    local profileTable = db.getTable ("dot11Profile",false)
    if (wmmTable ~= nil and profileTable ~= nil) then
        wmmTable.profileTable = profileTable
    end
    err = "OK"
    statusMsg = ""
    
    --return
    return err, statusMsg, wmmTable

end

-------------------------------------------------------------------------------
--@name gui.wireless.wmm.get
--
--@description This function will get the wmm info for a given profile .
--
--@return
--

function gui.wireless.dscpMap.get (configRowId)
    -- require
    require "teamf1lualib/dot11"
	
	--locals
	local dscpTable = {}
	local query = "_ROWID_="..configRowId
	local dscpTable =  db.getRowWhere ("dscpToQueueMapping",query,false)
	return err, statusMsg,dscpTable
	
end

-------------------------------------------------------------------------------
--@name gui.wireless.wmm.get
--
--@description This function will get the wmm info for a given profile .
--
--@return
--

function gui.wireless.dscpToCosMap.get (configRowId)
    -- require
    require "teamf1lualib/dot11"
	
	--locals
	local dscpTable = {}
	local query = "_ROWID_="..configRowId
	local dscpTable =  db.getRowWhere ("dscpToCosMapping",query,false)
	return err, statusMsg,dscpTable
	
end

-------------------------------------------------------------------------------
--@name gui.wireless.dscpMap.set
--
--@description This function will get the wmm info for a given profile .
--
--@return
--

function gui.wireless.dscpMap.set (inputTable)
    -- require
    require "teamf1lualib/dot11"

    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    local errorCode = "OK",statusMsg

	db.beginTransaction() -- begin transcation
	dot11.dscpToQueueMapping_config (inputTable, "1", "edit")

	if(errorCode == "OK") then
       db.commitTransaction()
       db.save2 ()
    else
       db.rollback ()
       return errorCode,statusMsg
    end
    --return
    return "OK", "STATUS_OK"

	
end


-------------------------------------------------------------------------------
--@name gui.wireless.wmm.get
--
--@description This function will get the wmm info for a given profile .
--
--@return
--

function gui.wireless.cosMap.get (configRowId)
    -- require
    require "teamf1lualib/dot11"
	
	--locals
	local cosTable = {}
	local query = "_ROWID_="..configRowId
	local cosTable =  db.getRowWhere ("cosToQueueMapping",query,false)
	return err, statusMsg,cosTable
	
end

-------------------------------------------------------------------------------
--@name gui.wireless.dscpMap.set
--
--@description This function will get the wmm info for a given profile .
--
--@return
--

function gui.wireless.cosMap.set (inputTable)
    -- require
    require "teamf1lualib/dot11"

    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    local errorCode = "OK",statusMsg

	db.beginTransaction() -- begin transcation
	dot11.cosToQueueMapping_config (inputTable, "1", "edit")

	if(errorCode == "OK") then
       db.commitTransaction()
       db.save2 ()
    else
       db.rollback ()
       return errorCode,statusMsg
    end
    --return
    return "OK", "STATUS_OK"

	
end

-------------------------------------------------------------------------------
--@name gui.wireless.dscpToCosMap.set
--
--@description This function will get the wmm info for a given profile .
--
--@return
--
 
function gui.wireless.dscpToCosMap.set (inputTable)
    -- require
    require "teamf1lualib/dot11"

    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    local errorCode = "OK",statusMsg

	db.beginTransaction() -- begin transcation
	dot11.dscpToCosMapping_config (inputTable, "1", "edit")

	if(errorCode == "OK") then
       db.commitTransaction()
       db.save2 ()
   else
       db.rollback ()
       return errorCode,statusMsg
    end
    
    return "OK", "STATUS_OK"

	
end

-------------------------------------------------------------------------------
--@name gui.wireless.radio.advancedSet
--
--@description this function eill set the values for radio
--
--@return
--
function gui.wireless.radio.advancedSet (dot11Table, dbFlag)

    --require
    require "teamf1lualib/dot11_ul"

    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (dot11Table == nil or dot11Table["band"] == nil) then
        return "ERROR", "INVALID BAND VALUE"
    end

    -- Making dbFlag 1, to perform db transactions
    if (dbFlag == nil) then
        dbFlag = 1
    end

    if (dbFlag == 1)then
        db.beginTransaction() -- begin transcation
    end

    errorCode,statusMsg = ul_dot11.radio.advancedSet (dot11Table)

    if(errorCode == "OK") then
	if(util.fileExists("/usr/bin/embedur/wifi_reloaded.sh")) then
        	os.execute ("echo \'/bin/sh /usr/bin/embedur/wifi_reloaded.sh 1\' >> "..CMD_EXEC_SCRIPT)
	end
        if (dbFlag == 1)then
            db.commitTransaction()
            db.save2 ()
            -- Setting the configurations into driver.
            util.runShellCmd (SH_BIN..CMD_EXEC_SCRIPT)
            os.remove (CMD_EXEC_SCRIPT)
        end
    else
        if (dbFlag == 1)then
            db.rollback ()
            -- Removing the commands scripts file entry.
            os.remove (CMD_EXEC_SCRIPT)
        end
        return errorCode,statusMsg
    end

    --return
    return "OK", "STATUS_OK"

end

-------------------------------------------------------------------------------
--@name gui.wireless.radio.get
--
--@description This function will get the information of a radio
--
--@return
--
function gui.wireless.radio.get(band)
    
    -- require
    require "teamf1lualib/dot11"

    --locals
    local countryTable = {}
    local radioTable = {}
    local profileTable = {}
    local vapTable = {}
    local nilTable = {}
    local err, statusMsg
    local query = "_ROWID_=1"
    local radioQuery = "band='"..band.."'"
    --Global Table  
    countryTable = db.getRowWhere("dot11GlobalConfig", query, false)
    if (countryTable == nil) then
        return "ERROR","DB_ERROR_TRY_AGAIN",nilTable
    end

    --radio Table Based on band value
    local radioTable = db.getRowWhere ("dot11Radio", radioQuery, false)
    if (radioTable == nil) then
        return "ERROR","DB_ERROR_TRY_AGAIN",nilTable
    end

    -- profile Table
    profileTable = db.getTable("dot11profile", false)
    if (profileTable == nil) then
        return "ERROR","DB_ERROR_TRY_AGAIN",nilTable
    end
	
    --vap Table
    vapTable = db.getTable("dot11VAP", false)
    if (vapTable == nil) then
        return "ERROR","DB_ERROR_TRY_AGAIN",nilTable
    end

    for i,v in pairs(profileTable) do
        for ii,vv in pairs (vapTable) do
            if (v["profileName"] == vv["profileName"] and tonumber(vv["radioList"]) == tonumber(radioTable["radioNo"])) then
                v["vapEnabled"] = vv["vapEnabled"]       
                v["macAddress"] = db.getAttribute("dot11Interface","vapName",vv["vapName"],"macAddress")
                v["LogicalIfName"] = db.getAttribute("dot11Interface","vapName",vv["vapName"],"LogicalIfName")
                v["networkName"] = db.getAttribute("networkInterface","LogicalIfName",v["LogicalIfName"],"networkName")
            end
        end
    end

    radioTable["profileTable"] = profileTable
    radioTable["country"] = countryTable["country"]
    radioTable["countrycode"] = countryTable["countrycode"]
    radioTable["opMode"] = convertModes(radioTable["band"],radioTable["opMode"],"0") --pass 0 for get

    --we should get the channel from interface which is up and running instead of radio interface.
    local firstEnabledVapRow
    local radioInterfaceName
    local channel = radioTable["configuredChannel"] --put channel as 0
    firstEnabledVapRow = db.getRowWhere("dot11VAP","radioList='"..radioTable["radioNo"].."' and vapEnabled='1'",false)
    radioInterfaceName = radioTable["interfaceName"]
    if(firstEnabledVapRow ~= nil)then
        local vapInterfaceName = db.getAttribute("dot11Interface","vapName",firstEnabledVapRow["vapName"],"interfaceName")
        os.execute ("/bin/echo -n `/bin/wl -i " .. vapInterfaceName .. " status |grep Channel | awk '{print$13}' ` > /tmp/channel1")
    else
        os.execute ("/bin/echo -n `/bin/wl -i " .. radioInterfaceName .. " status |grep Channel | awk '{print$13}' ` > /tmp/channel1")
    end
    channel = util.fileToString("/tmp/channel1")
    radioTable["currentChannel"] = channel

    
    if radioTable["sideBand"] == "0" then
        radioTable["contSideBand"] = "Upper"
    else
        radioTable["contSideBand"] = "Lower"
    end

    err = "OK"
    statusMsg = ""
    
    radioTable["txPower"] = util.filterXSSChars(radioTable["txPower"])
    radioTable["maxTxPower"] = util.filterXSSChars(radioTable["maxTxPower"])
    
    --return
    return err, statusMsg, radioTable

end

-------------------------------------------------------------------------------
--@name gui.wireless.radio.set
--
--@description this function eill set the values for radio
--
--@return
--
function gui.wireless.radio.set(dot11Table, dbFlag)

    --require
    require "teamf1lualib/dot11_ul"

    --locals
    local errorCode = "OK"
    local statusMsg = "STATUS_OK"

    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- Making dbFlag 1, to perform db transactions
    if (dbFlag == nil) then
        dbFlag = 1
    end

    if (dot11Table == nil or dot11Table["band"] == nil) then
        return "ERROR", "BAND ERROR"
    end

    --[[if (dot11Table["configuredChannel"] ~= nil) then
        errorCode,statusMsg = channelValidate (inputTable)

    end]]--

    if (dbFlag == 1)then
        db.beginTransaction() -- begin transcation
    end

    errorCode,statusMsg = ul_dot11.radio.set(dot11Table)

    if(errorCode == "OK") then
	if(util.fileExists("/usr/bin/embedur/wifi_reloaded.sh")) then
        	os.execute ("echo \'/bin/sh /usr/bin/embedur/wifi_reloaded.sh 1\' >> "..CMD_EXEC_SCRIPT)
	end
        if (dbFlag == 1)then
            db.commitTransaction()
            db.save2 ()
            -- setting the configuraions in driver.
            util.runShellCmd (SH_BIN..CMD_EXEC_SCRIPT)
            os.remove (CMD_EXEC_SCRIPT)
            if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then
                dot11meshReStart ()
            end
        end
    else
        if (dbFlag == 1)then
            db.rollback ()
            -- removing the commands scripts file.
            os.remove (CMD_EXEC_SCRIPT)
        end
        return errorCode,statusMsg
    end
    --return
    return "OK", "STATUS_OK"

end

-------------------------------------------------------------------------------
--@name gui.wireless.wps.get
--
--@description this function will get the values for WIFI protection setup
--
--@return
--


function gui.wireless.wps.get()

    --require
    require "teamf1lualib/dot11"
    require "teamf1lualib/wps"

    --locals
    local profileInfo = {}
    local nilTable = {}
    local wpsInfoTable = {}
    local wpsInfoTableBkp = {}
    local wpsEnabled,EogreEnabled,ifName, vapName, profName
    local wpsSessTbl = {}
    local apTbl = {}
    local index = 0
    local EogreWpsEnabled = 0
    local query = "_ROWID_=1"
    wpsInfoTable.apTbl = {}
    wpsEnabled = db.getAttribute("dot11WPS", "_ROWID_", 1, "wpsEnabled")
 
    EogreEnabled = db.getAttribute("Eogre", "_ROWID_", 1, "Enable") 
    --get interface name from wps table
    ifName = db.getAttribute("dot11WPS", "_ROWID_", 1,"vapName")

    -- get vapname of the wps interface
    vapName = db.getAttribute("dot11Interface", "interfaceName",ifName,"vapName")

    -- get vap table 
    vapTbl = db.getTable("dot11VAP", false)

    if(EogreEnabled == '1' and ((vapName == 'ap3') or (vapName == 'ap6'))) then                                
        EogreWpsEnabled = 1                                                                                      
    end  
    for k, v in pairs (vapTbl) do
        --if(tonumber(v["vapEnabled"]) == tonumber(1))then
            local security = db.getAttribute("dot11Profile", "profileName", v["profileName"], "security")
            local authMethods = db.getAttribute("dot11Profile", "profileName", v["profileName"], "authMethods")
            local pairwiseCiphers = db.getAttribute("dot11Profile", "profileName", v["profileName"], "pairwiseCiphers")
            if (not (security == "OPEN" or security == "WEP" or security == "WPA" or authMethods == "RADIUS")) then
                apTbl[index] = {}
                apTbl[index]["vapName"] = v["vapName"]
                index = index +1
                -- run this only for first VAP as you have to provide information
                if(tonumber(index) == tonumber(1))then
                    wpsInfoTableBkp["security"] = security
                    wpsInfoTableBkp["authMethods"] = authMethods
                    wpsInfoTableBkp["pairwiseCiphers"] = pairwiseCiphers
                    if(wpsInfoTableBkp["authMethods"] == "") then
                        wpsInfoTableBkp["authMethods"] = "None"
                    end
                    if(wpsInfoTableBkp["pairwiseCiphers"] == "") then
                        wpsInfoTableBkp["pairwiseCiphers"] = "None"
                    elseif(wpsInfoTableBkp["pairwiseCiphers"] == "TKIP+CCMP") then
                        wpsInfoTableBkp["pairwiseCiphers"] = "TKIP+AES"
                    elseif(wpsInfoTableBkp["pairwiseCiphers"] == "CCMP") then
                        wpsInfoTableBkp["pairwiseCiphers"] = "AES"
                    end  
                end
            end --security checks for profile if
        --end--vapEnabled if
    end

    -- get profile from vapname
    profName = db.getAttribute("dot11VAP", "vapName",vapName, "profileName")
  
    --get the information based on profile name
    profileInfo = db.getRowWhere("dot11Profile", "profileName = '" .. profName .. "'", false)
    
    if(profileInfo == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN",nilTable
    end

    -- get wpssessstatus information
    wpsSessTbl = db.getRowWhere("dot11wpssessstatus",query,false)

    wpsInfoTable["vapName"] = util.filterXSSChars(vapName)
    wpsInfoTable["enableDisableWPS"] = wpsEnabled
    if(index == 0) then
        wpsInfoTable["security"] = "N/A"
        wpsInfoTable["authMethods"] = "N/A" 
        wpsInfoTable["pairwiseCiphers"] = "N/A"
    else
        wpsInfoTable["security"] = util.filterXSSChars(profileInfo["security"])
        wpsInfoTable["authMethods"] = util.filterXSSChars(profileInfo["authMethods"])
        wpsInfoTable["pairwiseCiphers"] = util.filterXSSChars(profileInfo["pairwiseCiphers"])
        if(wpsInfoTable["authMethods"] == "") then
            wpsInfoTable["authMethods"] = "None"
        end
        if(wpsInfoTable["pairwiseCiphers"] == "") then
            wpsInfoTable["pairwiseCiphers"] = "None"
        elseif(wpsInfoTable["pairwiseCiphers"] == "TKIP+CCMP") then
            wpsInfoTable["pairwiseCiphers"] = "TKIP+AES"
        elseif(wpsInfoTable["pairwiseCiphers"] == "CCMP") then
            wpsInfoTable["pairwiseCiphers"] = "AES"
        end
        if((wpsInfoTable["security"] == "OPEN") and (wpsInfoTable["security"] == "WEP") ) then
            --get the first VAP settings which is enabled and has security WPA/WPA2 from profile which we have  
            --backup already while checking for enabled VAP's with WPA/WPA2
            wpsInfoTable = wpsInfoTableBkp
        end
    end
	
    wpsInfoTable["sessionMsg"] = wpsSessTbl["sessionMsg"]
    if(wpsInfoTable["sessionMsg"] == '') then
        if (wpsEnabled == '1') then
            wpsInfoTable["sessionMsg"] = "Click on PBC to start a new WPS session"
        else
            wpsInfoTable["sessionMsg"] = "WPS is Disabled"
        end
    end

    if(EogreWpsEnabled == 1) then
        wpsInfoTable["security"] = "N/A"
        wpsInfoTable["authMethods"] = "N/A" 
        wpsInfoTable["pairwiseCiphers"] = "N/A"
        wpsInfoTable["sessionMsg"] = "WPS is Disabled"
         wpsInfoTable["enableDisableWPS"] = "0"
    end

    wpsInfoTable["sessionStatus"] =wpsSessTbl["sessionStatus"]
    wpsInfoTable["enabledVapCount"] =index
    wpsInfoTable.apTbl = apTbl
    err = "OK"

    if(index == 0) then
        statusMsg = "Please configure at least one AP with WPA2 security to use this feature."
    else
        statusMsg = ""
    end
    --return 
    return err, statusMsg, wpsInfoTable

end

--------------------------------------------------------------------------------
--
--@name gui.wwireless.wpsStatus.get 
--
--@description This function will returns the status of wps
--
--@return
--
function gui.wireless.wpsStatus.get()

    --require
    require "teamf1lualib/dot11"
    require "teamf1lualib/wps"

    local wpsTable = {}

    wpsTable["sessionMsg"] = db.getAttribute("dot11WPSSessStatus", "_ROWID_", "1", "sessionMsg")
    wpsTable["sessionStatus"] = db.getAttribute("dot11WPSSessStatus", "_ROWID_", "1", "sessionStatus")
    --return
    return wpsTable

end

---------------------------------------------------------------------------------
--@name gui.wireless.wps.set
--
--@description this function will set the values for WIFI protection setup
--
--@return
--

function gui.wireless.wps.set(inputTable, dbFlag)
    
    --require
    require "teamf1lualib/dot11_ul"
    require "teamf1lualib/wps"
  
    local errorFlag = "ERROR"
    local statusCode = "WPS_CONFIG_FAILED"

    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- Making dbFlag 1, to perform db transactions
    if (dbFlag == nil) then
        dbFlag = 1
    end

    if (dbFlag == 1)then
        db.beginTransaction()
    end
    errorFlag,statusCode = ul_dot11.wps.set(inputTable)

    if(errorFlag == "OK")then
        -- run led script to take care of updating leds
        os.execute ("echo \'/pfrm2.0/bin/lua /pfrm2.0/bin/led.lua\' >> "..CMD_EXEC_SCRIPT)
	if(util.fileExists("/usr/bin/embedur/wifi_reloaded.sh")) then
        	os.execute ("echo \'/bin/sh /usr/bin/embedur/wifi_reloaded.sh 1\' >> "..CMD_EXEC_SCRIPT)
	end
        if (dbFlag == 1)then
            db.commitTransaction()
            db.save2()            
            util.runShellCmd (SH_BIN..CMD_EXEC_SCRIPT)
            os.remove (CMD_EXEC_SCRIPT)
        end
        return errorFlag,statusCode
    else
        if (dbFlag == 1)then
            db.rollback()
            os.remove (CMD_EXEC_SCRIPT)
        end
        return errorFlag,statusCode
    end
end


--------------------------------------------------------------------------------------------------
--@name gui.wireless.wps.pbcConfig - configure via push button connect 
--
--@description This function configures via push button connect
--
--@return

function gui.wireless.wps.pbcConfig (inputTable)

    --require
    require "teamf1lualib/dot11_ul"
    require "teamf1lualib/wps"

    --locals
    local errorCode,statusMsg
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    errorCode,statusMsg = ul_dot11.wpsPbcConfig (inputTable)
    --return 
    return errorCode,statusMsg

end

----------------------------------------------------------------------------------------------------
--@name gui.wireless.wps.pinConfig - configure via PIN 
--
--@description This function configures via PIN
--
--@return


function gui.wireless.wps.pinConfig (inputTable)

    --require
    require "teamf1lualib/dot11_ul"
    require "teamf1lualib/wps"


    --locals
    local status = "OK"
    local errMsg = "STATUS_OK"

    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    status, errMsg = ul_dot11.wpsPinConfig (inputTable)
    --return
    return status, errMsg

end

-------------------------------------------------------------------------------
--@name gui.wireless.acl.get - get the acl policy
--
--@description This function will give the information about 
--
--acl policy & list of cnfgured mac address
--
--@return
--

function  gui.wireless.acl.policyGet(rowid)
    --require
    require"teamf1lualib/dot11"
	
    local aclPolicyTbl = {}
    aclPolicyTbl.aclMAC = {}
    aclPolicyTbl = db.getRow ("dot11VAP", "_ROWID_", rowid)
    aclPolicyTbl.aclMAC = db.getRows ("dot11ACL", "vapName", aclPolicyTbl["dot11VAP.vapName"])

    aclPolicyTbl["dot11VAP.vapName"] = util.filterXSSChars(aclPolicyTbl["dot11VAP.vapName"])
    aclPolicyTbl.aclMAC["dot11ACL.macAddress"] = util.filterXSSChars(aclPolicyTbl.aclMAC["dot11ACL.macAddress"])

    errCode = "OK"
    statusMsg = ""
    --return 
    return errCode,statusMsg,aclPolicyTbl
	
end

-------------------------------------------------------------------------------
--@name gui.wireless.acl.get - get the acl policy
--
--@description This function will give the information about 
--
--acl policy & list of cnfgured mac address
--
--@return
--

function  gui.wireless.acl.get()

    --require
    require"teamf1lualib/dot11"

    --locals 
    local dot11VAP = {}
    local aclPolicyTbl = {}
    local macAddressTbl = {}
    local nilTable = {}
    local query =  "_ROWID_=1" -- using ACL configuration only for admin
    local macTbl = {}
    local index = 1
    local vapName,query1
    local errorCode,statusMsg

    -- we are considering acl policy only for admin
    dot11VAP = db.getRowWhere("dot11VAP", query, false)
    vapName = dot11VAP["vapName"]
    query1 = "vapName=\'" .. vapName .. "\'"
    macAddressTbl = db.getRowsWhere ("dot11ACL",query1 ,false)
    -- loop to get macaddress & other information for a particular access point
    for k,v in pairs(macAddressTbl) do
        macTbl[index] = {}
        macTbl[index]["host_name"] = v["hostName"]
        macTbl[index]["macAddress"] = v["macAddress"]
        macTbl[index]["_ROWID_"] = v["_ROWID_"]
        index = index + 1
    end
   
    aclPolicyTbl["defACLPolicy"] = dot11VAP["defACLPolicy"]
    aclPolicyTbl["macTbl"] = macTbl
    if(aclPolicyTbl == nil) then
       return "ERROR","DB_ERROR_TRY_AGAIN",nilTable
    end
    errCode = "OK"
    statusMsg = ""
    --return 
    return errCode,statusMsg,aclPolicyTbl

end

-------------------------------------------------------------------------------
--@name gui.wireless.acl.set - set the acl policy
--
--@description This function set the acl policy
--
--@return
--

function gui.wireless.acl.set(policy, dbFlag)

    --require
    require "teamf1lualib/dot11_ul" 

    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- Making dbFlag 1, to perform db transactions
    if (dbFlag == nil) then
        dbFlag = 1
        --db.beginTransaction
        db.beginTransaction()
    end

    -- config dot11VAP (default acl policy)
    errorFlag,statusCode = ul_dot11.acl.set(policy)

    if(errorFlag == "OK" ) then
	if(util.fileExists("/usr/bin/embedur/wifi_reloaded.sh")) then
        	os.execute ("echo \'/bin/sh /usr/bin/embedur/wifi_reloaded.sh 1\' >> "..CMD_EXEC_SCRIPT)
	end
        if (dbFlag == 1)then
            db.commitTransaction()
            db.save2()
            -- Setting configurations into nvram & driver.
            util.runShellCmd (SH_BIN..CMD_EXEC_SCRIPT)
            os.remove (CMD_EXEC_SCRIPT)
        end
    else
        if (dbFlag == 1)then
            db.rollback()
            os.remove (CMD_EXEC_SCRIPT)
        end
        return "ERROR", "ERROR_CONFIGURING_ACL_POLICY"
    end

    return "OK","STATUS_OK"

end
    
-------------------------------------------------------------------------------
--@name gui.wireless.acl.add.set
--
--@description This function will allow user to add mac addresses for access
--
--control rule
--
--@return
--
function gui.wireless.acl.add.set(inputTable, dbFlag)

    --require
    require "teamf1lualib/dot11_ul"

    --locals
    local acl = {}
    local dot11VAP = {}
    local vapRowQuery = "_ROWID_="..inputTable["dot11ACL.vaprowId"] -- using ACL configuration only for admin
    local valid = false 
    local radioInterfaceName = nil

    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (dbFlag == nil) then
        dbFlag = 1
        db.beginTransaction()
    end 

    -- add a ACL rule in db
    errorFlag,statusCode = ul_dot11.acl.add.set(inputTable)

    if(errorFlag == "OK")then
	if(util.fileExists("/usr/bin/embedur/wifi_reloaded.sh")) then
        	os.execute ("echo \'/bin/sh /usr/bin/embedur/wifi_reloaded.sh 1\' >> "..CMD_EXEC_SCRIPT)
	end
        if (dbFlag == 1)then
            db.commitTransaction()
            db.save2()
            util.runShellCmd (SH_BIN..CMD_EXEC_SCRIPT)
            os.remove (CMD_EXEC_SCRIPT)
        end
    else
        if (dbFlag == 1)then
            os.remove (CMD_EXEC_SCRIPT)
            db.rollback()
        end
    end
    
    return errorFlag,statusCode

end

-------------------------------------------------------------------------------
--@name gui.wirelessdelete
--
--@description This function will deletes an ACL rule
--
--@return
--

function gui.wireless.acl.delete (rowmacs, dbFlag)

    --require
    require "teamf1lualib/dot11_ul"

    --locals
    local valid = false
    local radioInterfaceName = nil
    local dot11VAP = {}
    local vapNameQuery
    local vapInterfaceName
    local vapName

    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- Making dbFlag 1, to perform db transactions
    if (dbFlag == nil) then
        dbFlag = 1
        db.beginTransaction()
    end

    errorFlag,statusCode = ul_dot11.acl.delete (rowmacs)
 
    if(errorFlag == "OK") then
	if(util.fileExists("/usr/bin/embedur/wifi_reloaded.sh")) then
        	os.execute ("echo \'/bin/sh /usr/bin/embedur/wifi_reloaded.sh 1\' >> "..CMD_EXEC_SCRIPT)
	end
        if (dbFlag == 1) then
            db.commitTransaction()
            db.save2()
            util.runShellCmd (SH_BIN..CMD_EXEC_SCRIPT)
            os.remove (CMD_EXEC_SCRIPT)
        end
    else
        if (dbFlag == 1) then
            db.rollback()
            os.remove (CMD_EXEC_SCRIPT)
        end
    end

    return errorFlag,statusCode

end

--[[helper functions]]--

------------------------------------------------------------------------------------------------------
-- gui.helper.securityGet - get security configuration
--
-- This function gets the security configuration for a given type
-- 
--RETURN: 
--]]--

function gui.helper.securityGet(security,pairwiseCiphers,wepAuth,groupCipher)
    
    --require
    require "teamf1lualib/wifiSecMap"

    for i,v in ipairs(securityStrs) do
        if ((security == v[2]) and (security == "OPEN")) then
            return v
        elseif((security == v[2]) and ((security == "WPA") or (security == "WPA2") or (security == "WPA+WPA2")) and (pairwiseCiphers == v[3])) then
            return v
        elseif ((security == v[2]) and (security == "WEP") and (wepAuth == v[5]) and (groupCipher == v[6])) then
            return v
        end
    end
    --return
    return nil

end

-------------------------------------------------------------------------------
-- gui.helper.securityAuthGet - get security configuration
--
-- This function gets the security and other configuration for an Authorized AP
-- 
--RETURN: 
--]]--

function gui.helper.securityAuthGet(security,pairwiseCiphers,authMethods)
    
    --require
    require "teamf1lualib/wifiSecMap"

    for i,v in ipairs(securityStrsAuthAP) do
        if ((security == v[2]) and ((security == "OPEN") or (security == "WEP"))) then
            util.appendDebugOut("Security : " .. security .. "<br>")
            return v
        elseif((security == v[2]) and (pairwiseCiphers == v[3]) and (authMethods == v[4])) then
            return v
        end
    end
    --return
    return nil

end

-------------------------------------------------------------------------------
function gui.helper.startStopVaps(enable, rowid, security)

    --require
    require "teamf1lualib/dot11"
    local dot11VAP = {}
    local dot11VAPRow = {}
    local query = {}
    local wpsRow = {}

    if(rowid) then
        query="_ROWID_=" .. tostring(rowid)
        dot11VAPRow = db.getRowWhere("dot11VAP",query,false)
        if(not(dot11VAPRow)) then
            return "ERROR","DB_ERROR_TRY_AGAIN"
        end
        dot11VAP[1] = dot11VAPRow
    else
        -- for all rows of dot11VAP
        dot11VAP = db.getTable("dot11VAP",false)
    end

    if (not(dot11VAP)) then
        return "ERROR","DB_ERROR_TRY_AGAIN"
    end

    for _,v in ipairs(dot11VAP) do
        if(v["vapEnabled"] == "1") then
            if(enable == 1) then
                if(security == nil) then
                    profileName = db.getAttribute("dot11VAP","vapName",v["vapName"],"profileName")
                    if(profileName == nil) then
                        return "ERROR","DB_ERROR_TRY_AGAIN"
                    end
                    security = db.getAttribute("dot11Profile","profileName", profileName,"security")
                end
                dot11.VAP_start(v["vapName"],1)
            else
                dot11.VAP_start(v["vapName"],false)

            end
        end
    end
    --return
    return "OK", "STATUS_OK"

end

-------------------------------------------------------------------------------
---- returns true if duplicate ssid is found
-- else returns false
--
function gui.helper.checkDuplicateSsid(ssid,prowid)

    if(not(ssid)) then
        return false
    end

    local ssidRow = db.getRowWhere ("dot11Profile", "ssid='" .. ssid .. "'", false)
    if(not(ssidRow) or prowid == ssidRow["_ROWID_"]) then
        return false
    end
    --return
    return true

end

----------------------------------------------------------------------------------
-- @name   gui.wireless.wizardProfileInfo.edit.set (wirelessTbl,operation)
--
-- @description This function will set the information for a particular
--
-- wireless profile which is being edited
--
-- @param new configuration table
--
-- @return 
--
 function gui.wireless.wizardProfileInfo.edit.set (cfgTbl, operation)

    --require
    
    require "teamf1lualib/wifiSecMap"
    require "teamf1lualib/dot11"
    --require "dot11Lib"
    
    local rowid = cfgTbl["dot11Profile._ROWID_"]
	     
    local rowids = {}
    local errorCode, statusMsg
    rowids[1] = rowid

    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
    
	db.beginTransaction() -- begin transcation
    errorCode, statusMsg = dot11.profile_config(cfgTbl, rowid, "edit")

    if(errorCode == "OK")then
        db.commitTransaction()
        db.save2()
        return errorCode, statusMsg
    else
        db.rollback()
        return errorCode, statusMsg
    end

end
-------------------------------------------------------------------------------
--@name gui.wireless.clients.DashboardGet
--
--@description This function will get the connected clients count
--
--@return count
--
function gui.wireless.clients.DashboardGet()

    local clientTable = {}
    local i  = 1
    local enabledVAPs = {}
    enabledVAPs = db.getRowsWhere ("dot11VAP", "vapEnabled = 1")
    for m,n in pairs (enabledVAPs) do
        local vapName = n["dot11VAP.vapName"] or ''
        local table = db.getRowsWithJoin({"dot11VAP:dot11Interface:vapName"}, "dot11VAP.vapName", vapName)
        for k,v in pairs(table) do
            -- get the STA macs
            local cmd = "wl -i " ..v["dot11Interface.interfaceName"].." assoclist > /tmp/connected_clients"
            os.execute (cmd)
            local table1 = {}
            for line in io.lines("/tmp/connected_clients") do 
                table1[#table1 + 1] = string.gsub (line, "assoclist ", "")
            end
            if(table1 ~= nil ) then
                for ii,row in pairs(table1) do
                    i=i+1
                end 
            end -- table1 nil check
        end 
    end --enabled vap check 
    return i-1

end


function gui.wireless.profileInfoeogre.set (inputTable, operation, dbFlag)
   
    --include
    require "teamf1lualib/dot11"
    
    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- Making dbFlag 1, to perform db transactions
    if (dbFlag == nil) then
        dbFlag =1
    end

    --locals
    local status = nil
    local errMsg = nil
    local rowid = inputTable["_ROWID_"]
    local security = {}
    security =  gui.helper.securityGet(inputTable["dot11Profile.security"],inputTable["dot11Profile.pairwiseCiphers"],inputTable["dot11Profile.wepAuth"],inputTable["dot11Profile.groupCipher"])
    if (not(security)) then
        util.appendDebugOut("Configured security not supported!!")
        return "ERROR", "DOT11_SECURITY_NOTSUPP"
    end

    inputTable["dot11Profile.security"] = security[2]
    if ((inputTable["dot11Profile.security"] == "WEP" or inputTable["dot11Profile.security"] == "OPEN")) then
        inputTable["dot11Profile.authMethods"] = security[4]
    end
    inputTable["dot11Profile.groupCipher"] = security[6]
    inputTable["dot11Profile.pairwiseCiphers"] = security[3]
    inputTable["dot11Profile.wepAuth"] = security[5]
    -- save password into paskPassAscii only if security is wpa(2)
    if ((inputTable["dot11Profile.security"] =="WPA" ) or (inputTable["dot11Profile.security"] =="WPA2" ) or (inputTable["dot11Profile.security"] =="WPA+WPA2")) then
        inputTable ["dot11Profile.pskPassAscii"] = inputTable ["dot11Profile.pskPassAscii"]
    else
        inputTable ["dot11Profile.pskPassAscii"] = ""
    end

    if (dbFlag == 1)then
        db.beginTransaction() -- begin transcation 
    end

    errMsg, status = dot11.profile_config (inputTable, rowid, operation)

    if(errMsg == "OK")then
	if(util.fileExists("/usr/bin/embedur/wifi_reloaded.sh")) then
        	os.execute ("echo \'/bin/sh /usr/bin/embedur/wifi_reloaded.sh 1\' >> "..CMD_EXEC_SCRIPT)
	end
        if (dbFlag == 1)then
            db.commitTransaction()
            db.save2()
            util.runShellCmd (SH_BIN..CMD_EXEC_SCRIPT)
            os.remove (CMD_EXEC_SCRIPT)
        end
        return errMsg, status
    else
        if (dbFlag == 1)then
            db.rollback()
            os.remove (CMD_EXEC_SCRIPT)
        end
        return errMsg, status
    end
		
end

-------------------------------------------------------------------------------
--@name gui.wireless.apgroupname.set
--
--@description This function will allow user to set apgroupname on all profiles
--
--@return
--
function gui.wireless.apgroupname.set(inputTable, dbFlag)

    --include
    require "teamf1lualib/dot11"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- Making dbFlag 1, to perform db transactions
    if (dbFlag == nil) then
        dbFlag = 1
    end

    --locals
    local status = nil
    local errMsg = nil

    if (dbFlag == 1) then
        db.beginTransaction() -- begin transcation
    end

    inputTable["apGroupName.apGroupName"] = inputTable["dot11Profile.apgroupname"]

    errMsg, status = dot11.apGroupName_config (inputTable, "1", "edit")

    if(errMsg == "OK")then
	if(util.fileExists("/usr/bin/embedur/wifi_reloaded.sh")) then
        	os.execute ("echo \'/bin/sh /usr/bin/embedur/wifi_reloaded.sh 1\' >> "..CMD_EXEC_SCRIPT)
	end
        if (dbFlag == 1) then
            db.commitTransaction()
            db.save2()
            util.runShellCmd (SH_BIN..CMD_EXEC_SCRIPT)
            os.remove (CMD_EXEC_SCRIPT)
        end
        return errMsg, status
    else
        if (dbFlag == 1) then
            db.rollback()
            os.remove (CMD_EXEC_SCRIPT)
        end
        return errMsg, status
    end

end 

-------------------------------------------------------------------------------
--@name gui.wireless.apgroupname.get
--
--@description This function will allow user to get apgroupname
--
--@return apgroupname
--
function gui.wireless.apgroupname.get()

    local profileRow = {}
    local apGroupName = {}
    local apGroupNameValue = nil
    apGroupNameValue = db.getAttribute("apGroupName","_ROWID_",1,"apGroupName")    
    if(apGroupNameValue ~= nil)then    
        apGroupName["apgroupname"] = apGroupNameValue 
    end
    return "OK", "STATUS_OK", apGroupName
 
end 

------------------------------------------------------------------
-- @name gui.wireless.eogrecheck
-- @description this function checks profile is ap2/ap5 (if applicable) and if eogre is enabled 
-- returns error
--------------------------------------------------------------------
function eogrecheck (inputTable)

    local rowid1query = "_ROWID_=1"
    local rowid2query = "_ROWID_=2"
    local dot11vap = nil
    local eogreTmp = nil
    local query
    local accesspoint 
    local accesspoint5

    eogreTmp = db.getRowWhere ("Eogre", rowid1query, false)
    if (eogreTmp == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end
    
    local jioPrivateNetSupport = "0"
    jioPrivateNetSupport = db.getAttribute ("Eogre", "_ROWID_", 1, "jioPrivateNet")
    --jioPrivateNetSupport = db.getAttribute ("environment", "name", "JIO_PRIVATE_NET" ,"value")
    if (jioPrivateNetSupport == "1") then
        accesspoint = "ap3"
        accesspoint5 = "ap6"
    else
        accesspoint = "ap2"
        accesspoint5 = "ap5"
    end

    query = "vapName= '" .. accesspoint .. "'"
    dot11vap = db.getRowWhere ("dot11VAP", query, false)
    if (dot11vap == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    if(util.fileExists("/pfrm2.0/HW_JCO110") or util.fileExists("/pfrm2.0/HW_HG260ES") or util.fileExists("/pfrm2.0/HW_ALU"))then
        if (inputTable["dot11Profile.profileName"] == dot11vap["profileName"])then
            if ((tonumber(eogreTmp["Enable"]) == 1) and (tonumber(eogreTmp["ModeOfOperation"]) == 1))then
                return "ERROR", "PLEASE_TURN_OFF_EoGRE"
            end --eogre check
        end
    else
        query = "vapName= '" .. accesspoint5 .. "'"
        local dot11vap5 = db.getRowWhere ("dot11VAP",query, false)
        if (dot11vap5 == nil) then
            return "ERROR", "DB_ERROR_TRY_AGAIN"
        end

        if (inputTable["dot11Profile.profileName"] == dot11vap["profileName"] or inputTable["dot11Profile.profileName"] == dot11vap5["profileName"])then
            if ((tonumber(eogreTmp["Enable"]) == 1) and (tonumber(eogreTmp["ModeOfOperation"]) == 1))then
                return "ERROR", "PLEASE_TURN_OFF_EoGRE"
            end -- eogre check
        end
    end

    return "OK","STATUS_OK"

end

-----------------------------------------------------------------------------------
-- @name eogreAPcheck
--
-- @description Thi function checks EoGRE is enabled or not on AP2 and AP5
-- on configuring table.
--
-- @return OK on Success, ERROR on failure.
------------------------------------------------------------------------------------
function eogreAPcheck (vapRows)

    -- locals
    local dot11vap = nil
    local dot11vap5 = nil
    local eogreTmp = nil
    local vapNameQuery
    local accesspoint 
    local accesspoint5

    -- query to EoGRE table
    eogreTmp = db.getRowWhere ("Eogre",  "_ROWID_=1", false)
    if (eogreTmp == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    local jioPrivateNetSupport = "0"
    jioPrivateNetSupport = db.getAttribute ("Eogre", "_ROWID_", 1, "jioPrivateNet")
    --jioPrivateNetSupport = db.getAttribute ("environment", "name", "JIO_PRIVATE_NET" ,"value")
    if (jioPrivateNetSupport == "1") then
        accesspoint = "ap3"
        accesspoint5 = "ap6"
    else
        accesspoint = "ap2"
        accesspoint5 = "ap5"
    end

    vapNameQuery = "vapName= '" .. accesspoint .. "'"
    dot11vap = db.getRowWhere ("dot11VAP",vapNameQuery, false)
    if (dot11vap == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    -- Single Radio devices 
    if(util.fileExists("/pfrm2.0/HW_JCO110") or util.fileExists("/pfrm2.0/HW_HG260ES") or util.fileExists("/pfrm2.0/HW_ALU"))then
        if (tonumber(vapRows["1"]) == tonumber(dot11vap["_ROWID_"]))then
            if ((tonumber(eogreTmp["Enable"]) == 1) and (tonumber(eogreTmp["ModeOfOperation"]) == 1))then
                return "ERROR", "PLEASE_TURN_OFF_EoGRE"
            end
        end
    -- For the Dual radio devices
    else      
        vapNameQuery = "vapName= '" .. accesspoint5 .. "'"
        dot11vap5 = db.getRowWhere ("dot11VAP",vapNameQuery, false)
        if (dot11vap5 == nil) then
            return "ERROR", "DB_ERROR_TRY_AGAIN"
        end
        if (tonumber(vapRows["1"]) == tonumber(dot11vap["_ROWID_"]) or tonumber(vapRows["1"]) == tonumber(dot11vap5["_ROWID_"]))then
            if ((tonumber(eogreTmp["Enable"]) == 1) and (tonumber(eogreTmp["ModeOfOperation"]) == 1))then
                return "ERROR", "PLEASE_TURN_OFF_EoGRE"
            end
        end
    end

  return "OK", "STATUS_OK"

end
---------------------------------------------------------------------------------
--@name eogreAccessPointCheck
--
--@description this function checks EoGRE is enabled on AP or not.
--
--@return
--
function eogreAccessPointCheck(inputTbl)

    --locals
    local vapNamequery
    local dot11vapRow
    local eogreRow
    local accesspoint 
    local accesspoint5

    local jioPrivateNetSupport = "0"
    jioPrivateNetSupport = db.getAttribute ("Eogre", "_ROWID_", 1, "jioPrivateNet")
    --jioPrivateNetSupport = db.getAttribute ("environment", "name", "JIO_PRIVATE_NET" ,"value")
    if (jioPrivateNetSupport == "1") then
        accesspoint = "ap3"
        accesspoint5 = "ap6"
    else
        accesspoint = "ap2"
        accesspoint5 = "ap5"
    end

    if(inputTbl["dot11VAP.vapName"] == accesspoint or inputTbl["dot11VAP.vapName"] == accesspoint5)then
      eogreRow = db.getRowWhere ("Eogre","_ROWID_=1", false)
      if (eogreRow == nil) then
          return "ERROR", "DB_ERROR_TRY_AGAIN"
      end

      if ((tonumber(eogreRow["Enable"]) == 1) and (tonumber(eogreRow["ModeOfOperation"])== 1 ))then
          vapNamequery = "vapName= '" .. inputTbl["dot11VAP.vapName"] .. "'"          
          dot11vapRow = db.getRowWhere ("dot11VAP",vapNamequery, false)
          if (dot11vapRow == nil) then
              return "ERROR", "DB_ERROR_TRY_AGAIN"
          end
          if ((inputTbl["dot11VAP.profileName"] ~= dot11vapRow["profileName"]) or (inputTbl["dot11VAP.apIsolation"] ~= dot11vapRow["apIsolation"]))then
              return "ERROR", "PLEASE_TURN_OFF_EoGRE"
          end
      end
    end

    return "OK","STATUS_OK"
    
end

