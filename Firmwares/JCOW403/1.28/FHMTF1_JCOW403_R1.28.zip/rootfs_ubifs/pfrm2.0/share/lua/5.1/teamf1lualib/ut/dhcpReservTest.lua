#! /pfrm2.0/bin/lua

module( "dhcpreserv-test", package.seeall, lunit.testcase)

require "lunit"
require "teamf1lualib/util"
require "teamf1lualib/db"
require "teamf1lualib/gui"

dhcpreserv = {}


function setup()
    db.connect("/tmp/system.db")
    setup_reserv()
end

function setup_reserv()
    dhcpreserv[1] = {}
    dhcpreserv[1]["LogicalIfName"] = "IF2"
    dhcpreserv[1]["macAddr"] =  "00:48:54:b2:0e:2c"
    dhcpreserv[1]["startAddr"] = "192.168.176.80"

    return
end

function test_reserv_add()
    local status
    local errCode

    for k,v in pairs(dhcpreserv) do
        status, errCode = gui.networking.reservedDhcpClient.add.set(v)
        assert_match(status, "OK") 
    end    
    os.execute("sleep 1")
end

function test_reserv_get()
    local status, errCode, page = gui.networking.reservedDhcpClient.get()
    assert_match(status, "OK") 
            
    local bindings =  page.reserv
    if (bindings ~= nil) then
        for k,v in pairs(bindings) do
            status, errCode, row = gui.networking.reservedDhcpClient.edit.get(v["_ROWID_"])
            assert_match(status, "OK") 
            row["macAddr"] = "00:48:54:92:0e:" .. k
            row["LogicalIfName"] = "IF2"
            status, errCode = gui.networking.reservedDhcpClient.edit.set(row)
            assert_match(status, "OK") 

            os.execute("sleep 1")
        end                    
    end        
end

function test_reserv_delete()
    local rowids = {}
    rowids[1] = "1"
    status, errCode = gui.networking.reservedDhcpClient.delete(rowids)
    assert_match(status, "OK") 

    os.execute("sleep 1")
end

function teardown()
    os.execute("sleep 1")
end
