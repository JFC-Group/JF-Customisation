--[[
#### Aditya kapoor
#### TeamF1
#### www.TeamF1.com
#### Dec 15, 2011

#### File: nscan.lua
#### Description: nscan functions
]]--

----------------------------------------
--packages
nscan = {}


-------------------------------------------------------------------------------
-- @name nscan.hostsGet
--
-- @description 
--
-- @param query search criteria
--
-- @return OK or ERROR
-- @return errCode
-- @return table of hosts
--

function nscan.hostsGet(query)
    local hostsTbl = {}

    if (query == nil) then
        hostsTbl = db.getTable("LanHosts", false)
    else
        hostsTbl = db.getRowsWhere("LanHosts", query, false)
    end                
	
	return "OK", "STATUS_OK", hostsTbl
end
