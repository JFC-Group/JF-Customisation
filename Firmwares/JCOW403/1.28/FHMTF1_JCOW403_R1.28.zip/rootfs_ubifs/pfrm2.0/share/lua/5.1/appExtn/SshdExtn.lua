-- @copyright Copyright (c) 2012, TeamF1, Inc. 

require "teamf1lualib/evtDsptch"
require "appExtn/AppExtn"
require "sshdLib"

SshdExtn = OoUtil.inheritsFrom(AppExtn)
SshdExtn.name    = "SSH server"
SshdExtn.classId = "sshd"
SshdExtn.className  =  "SshdExtn"
SshdExtn.dbTable = "sshd"
SshdExtn.logger  = nil

local SUPER = require("appExtn.AppExtn")

-- network events
local netEvents = {}
netEvents[evtDsptch.event.IFDEV_EVENT_IP4_NET_UP]   =  1
netEvents[evtDsptch.event.IFDEV_EVENT_IP4_NET_DOWN] =  1
netEvents[evtDsptch.event.IFDEV_EVENT_IP6_NET_UP] =  1
netEvents[evtDsptch.event.IFDEV_EVENT_IP6_NET_DOWN] =  1

-- configuration events
local cfgEvents = {}
cfgEvents[db.event.SQLITE_INSERT] = 1
cfgEvents[db.event.SQLITE_UPDATE] = 1
cfgEvents[db.event.SQLITE_DELETE] = 1

-------------------------------------------------------------------------------
-- @name SshdExtn.cfgEventCallback
--
-- @description 
--
-- @param  
--
-- @return  
--

function SshdExtn.cfgEventCallback(obj, info)
    local status = "ERROR"
    local errcode = ""

    LOG:ddebug(SshdExtn.classId .. " configuration callback called  " .. 
              "for event: " ..  info.event .. " on rowId " .. info.rowId)

    if (info.event == db.event.SQLITE_INSERT) then
        if (obj ~= nil) then 
            assert(nil, SshdExtn.classId .. "(" .. info.rowId  .. ")" ..
                   "already created")
            return -1
        end        

        -- create instance and process event
        obj = SshdExtn:new(info.rowId)
        if (obj) then 
            obj:onCfgEvent(info) 
        end

    elseif (info.event == db.event.SQLITE_UPDATE) then
        if (obj) then 
            obj:onCfgEvent(info) 
        end
    elseif (info.event == db.event.SQLITE_DELETE) then
        -- process event and destroy instance
        if (obj) then
            obj:onCfgEvent(info)
            obj:delete()
        end
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name SshdExtn.bootstrap
--
-- @description This function is called by appd on startup to bootstrap all 
-- instances of this application. 
--
-- @param  
--
-- @return  
--

function SshdExtn.bootstrap()
    local instanceId
    local callbackTable= {}

    sshdLib.killAll()

    local callback = {}
    callback.type = appd.eventType.APPD_EV_CFG
    callback.dbTable = SshdExtn.dbTable
    callback.routine = SshdExtn.cfgEventCallback
    table.insert(callbackTable, callback)
    appd.callbackRegister (SshdExtn.classId, callbackTable)

    local cfg = db.getTable(SshdExtn.dbTable, false)
    if (cfg == nil) then
        return 0
    end        

    for index, record in pairs(cfg) do
        instanceId = record["_ROWID_"]
        local obj = SshdExtn:new(instanceId)
        if (obj and obj:isEnabled()) then
            obj:start()
        end                        
    end

    return 0
end

-------------------------------------------------------------------------------
-- @name SshdExtn:new
--
-- @description This function creates a new instance object for sshd, loads
-- the configuration and event subcriptions
--
-- @return  0 for success and -1 for error
--

function SshdExtn:new(instanceId, props)

    -- create a new instance
    self = SshdExtn.create()

    SUPER.new(self, SshdExtn.classId, instanceId, props)

    self.name  = SshdExtn.name
    self.dbTable =  SshdExtn.dbTable

    -- initialize events for this instance
    self.netEvents = netEvents              
    self.cfgEvents = cfgEvents

    -- load the instance          
    local status, errCode, self = self:load()
    if (status == nil) then
        LOG:error("failed to load " .. classId .. 
                  "(" .. instanceId .. ")")
        return nil
    end        

    -- register with appd
    appd.appExtnRegister(self)                    

    return self
end

-------------------------------------------------------------------------------
-- @name SshdExtn:delete
--
-- @description This function deletes an instance of this extension
--
-- @param instanceId
--
-- @return  
--

function SshdExtn:delete()
    appd.appExtnUnregister(self)
end

-------------------------------------------------------------------------------
-- @name SshdExtn:stop
--
-- @description This function starts sshd
--
-- @return  0 for success and -1 for error
--

function SshdExtn:stop ()
    local props = self:getProps()

    sshdLib.cfgLoad(props)

    LOG:info("Stopping " .. self.name .. 
                "(" ..  self.instanceId .. ")")

    sshdLib.stop()

    return 0
end

-------------------------------------------------------------------------------
-- @name SshdExtn:isEnabled
--
-- @description This function checks if this instance is enabled
--
-- @return  true if enabled else false
--

function SshdExtn:isEnabled()
    require "teamf1lualib/network"

    local props = self:getProps()

    if (tonumber(props.sshdEnable) > 0) then
        return true
    end        

    return false
end

-------------------------------------------------------------------------------
-- @name SshdExtn:start
--
-- @description This function starts sshd
--
-- @return  0 for success and -1 for error
--

function SshdExtn:start ()
    require "teamf1lualib/nimf"
    local props = self:getProps()

    if (self:isEnabled()) then

        -- check if the network is UP
        if (nimfConn.isIPv4Up(props.LogicalIfName) == false) then
            LOG:ddebug("Network:" .. props.LogicalIfName  .. " is not UP")
            return -1
        end        

        if (sshdLib.cfgLoad(props) < 0) then
            return -1
        end            

        LOG:info("Starting " .. self.name ..  "(" ..  self.instanceId .. ")")

        if (sshdLib.start() < 0) then
            return -1
        end            
    end

    return 0
end

-------------------------------------------------------------------------------
-- @name SshdExtn:restart
--
-- @description This function restarts sshd
--
-- @return  0 for success and -1 for error
--

function SshdExtn:restart ()

    -- stop the server
    self:stop() 

    -- start the server
    if (self:start() < 0) then
        return -1
    end                

    return 0
end

-------------------------------------------------------------------------------
-- @name SshdExtn:getAppName
--
-- @description This function gets the name of this extension
--
-- @return  
--

function SshdExtn:getAppName()
   return self.name
end

-------------------------------------------------------------------------------
-- @name SshdExtn:getDbTableName
--
-- @description This function gets the database table name which contains
-- configuration records for all instances of this application.
--
-- @return  
--

function SshdExtn:getDbTableName()
   return self.dbTable
end

-------------------------------------------------------------------------------
-- @name SshdExtn:onNetEvent
--
-- @description This function handles network events
--
-- @param  netevent  network event
--
-- @return  0 for success and -1 for error
--

function SshdExtn:onNetEvent(netevent)

    if (self:isEventSubscribed(netevent) == false) then
        LOG:ddebug(self.classId .. " not subscribed to event: " ..
                  netevent.event .. " on " .. netevent.ifname)
        return 0
    end        

    self:restart()

    return 0
end

-------------------------------------------------------------------------------
-- @name SshdExtn:isEventSubscribed
--
-- @description This function checks if this instance is subcribed to
-- the event pass as input
--
-- @param event event information
--
-- @return  0 for success and -1 for error
--

function SshdExtn:isEventSubscribed(event)
    local props = self:getProps()

    if (event.type == appd.eventType.APPD_EV_NET) then

        if (strlib.strcasecmp(props.LogicalIfName, event.ifname) ~= 0) then
            return false
        end            
        
        local evstate = self.netEvents[event.event]
        if (evstate == nil) then
            return false
        end            
                    
        if (evstate > 0) then
            return true
        end        

    elseif (event.type == appd.eventType.APPD_EV_CFG) then

        -- are we subscribed to this event                        
        local evstate = self.cfgEvents[event.event]
        if (evstate == nil) then
            return false
        end            

        if (evstate > 0) then
            return true
        end        
    end

    return false
end

-------------------------------------------------------------------------------
-- @name SshdExtn:onCfgEvent
--
-- @description This function is to handle configuration events
-- 
-- @param  cfgevent event information
--
-- @return  
--

function SshdExtn:onCfgEvent(cfgevent)
    local props = self:getProps()

    if (self:isEventSubscribed(cfgevent) == false) then
        LOG:ddebug(self.classId .. " not subscribed to event: " ..
                  cfgevent.event .. " on " .. cfgevent.dbTable)
        return
    end        

    if (cfgevent.event == db.event.SQLITE_INSERT) then
       self:start()
    elseif (cfgevent.event == db.event.SQLITE_UPDATE) then
        
        -- stop the old instance 
        self:stop()

        -- start instance with new configuration
        local status, errCode, self  = self:load()
        if (status == "OK") then
            self:start() 
        end            

    elseif (cfgevent.event == db.event.SQLITE_DELETE) then
        self:stop()
    end                

    return
end

-------------------------------------------------------------------------------
-- @name SshdExtn:print
--
-- @description This function prints the properties of this application instance
--
-- @param  
--
-- @return  
--

function SshdExtn:print()
    require "util/strlib"

    LOG:info("Class     : " .. self.classId)
    LOG:info("Instance  : " .. self.instanceId)
    LOG:info("App Name  : " .. self:getAppName())
    LOG:info("Conf      : " .. strlib.serializeTbl(self:getProps()))
    return
end

return SshdExtn
