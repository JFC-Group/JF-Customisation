-- pptpClientCLI.lua
-- Nishant
-- TeamF1
-- www.TeamF1.com
--
-- Modification History
-- 27may11,nis written
--
-- Description
-- CLISH pptp vpn client LUA routines
--

require "teamf1lualib/pptpClient"

function pptpClientCfgInit(args)
	configRow = db.getRow ("pptpClient", "_ROWID_", "1")
	return 1,configRow
end

function pptpClientCfgSave(configRow)
	local errorFlag="ERROR"
	local statusCode=""
	local statusMessage=""
	DBTable="pptpClient"
	errorFlag,statusCode = pptpClient.set (configRow)
	
    if (errorFlag) then
	    -- save db if no error
		db.save() 
		statusMessage = db.getAttribute("stringsMap", "stringId", statusCode, LANGUAGE) or statusCode
		return "OK", statusMessage 
	else
		statusMessage = db.getAttribute("stringsMap", "stringId", statusCode, LANGUAGE) or statusCode
		return "ERROR", statusMessage 
	end
end

function pptpClientInputVal(configRow)
	if (configRow["pptpClient.pptpClientEnable"] == "1") then
		if (configRow["pptpClient.ServerIp"] == nil) then
			printCLIError("Invalid pptp server address")
			return false
		end
		if (configRow["pptpClient.RemoteNetwork"] == nil) then
			printCLIError("Invalid remote network address")
			return false
		end
        if (configRow["pptpClient.RemoteNetmask"] < "2" or configRow["pptpClient.RemoteNetmask"] > "32") then
			printCLIError("Entered value should be between 1-32")
			return false
		end
	end
	return true
end

function pptpClientGet()
	local state
	local resultTab = {}
	configRow = db.getRow ("pptpClient", "_ROWID_", "1")
	printLabel("PPTP Client Configuration")
	if (configRow["pptpClient.pptpClientEnable"] == "0") then
		state="Disabled"
	else
		state="Enabled"
	end
	resTab.insertField (resultTab,"PPTP Client Status:",state)
	resTab.insertField (resultTab,"Server Address:",configRow["pptpClient.ServerIp"] or '')
	resTab.insertField (resultTab,"Remote Network:",configRow["pptpClient.RemoteNetwork"] or '')
	resTab.insertField (resultTab,"Remote Subnet Mask:",configRow["pptpClient.RemoteNetmask"] or '')
	resTab.insertField (resultTab,"Username:",configRow["pptpClient.UserName"] or '')
	resTab.insertField (resultTab,"Password:",configRow["pptpClient.Password"] or '')
	resTab.insertField (resultTab,"Mppe Enable:",configRow["pptpClient.MppeEncryptionEnable"] or '')
	resTab.insertField (resultTab,"Idle Time Out:",configRow["pptpClient.IdleTimeOut"] or '')
	resTab.print (resultTab,0)
end

function pptpClientActionSet(args)
    local actionFlag = db.setAttribute("pptpClientConnectionStatus", "_ROWID_", 1, "action", args[1])
    if (actionFlag) then
	    -- save db if no error
		db.save() 
		return "OK" 
	else
		return "ERROR" 
    end
end

function pptpClientStatusGet()
	local state
	local resultTab={}
	configRow = db.getRow ("pptpClientConnectionStatus", "_ROWID_", "1")
	printLabel("PPTP client connection status")
	if (configRow["pptpClientConnectionStatus.connectionStatus"] == "0") then
		state="Disconnected"
	else
		state="Connected"
	end
	resTab.insertField (resultTab,"PPTP Client Connection Status:",state)
	resTab.print (resultTab,0)
end   
