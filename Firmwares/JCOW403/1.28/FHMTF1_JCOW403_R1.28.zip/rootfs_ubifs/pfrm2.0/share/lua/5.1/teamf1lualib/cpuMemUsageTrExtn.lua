--[[
#### 
#### File: tr181_cpuMemUsageTrExtn.lua
#### Description: 
#### TR-181 handlers for cpu usage. This file is included from tr181_tr69funcs.lua
####
]]--

cpuMemUsageTr = {}

--[[
--*****************************************************************************
-- cpuMemUsageTr.totalMemoryGet - get total Memory
-- 
-- TR69 Parameter: Device.DeviceInfo.MemoryStatus.Total
--
]]--

function cpuMemUsageTr.totalMemoryGet (input)

	local status = "0"
	local value = " "
	local value1 

    os.execute ("/bin/echo -n `/pfrm2.0/bin/mem.sh |grep TOTALMEM|cut -d ' ' -f 2` > /tmp/totalMem")
	local totalMem = ""
    f = io.open("/tmp/totalMem","r")
    if(f ~= nil) then
        totalMem = f:read("*line")
        f:close()
		value = totalMem
		return status, value
	else
		value = "TOTAL_MEM_GET_FAILED"
		return status, value
	end
end

--[[
--*****************************************************************************
-- cpuMemUsageTr.freeMemoryGet - get free Memory
-- 
-- TR69 Parameter: Device.DeviceInfo.MemoryStatus.Free
--
]]--

function cpuMemUsageTr.freeMemoryGet (input)

	local status = "0"
	local value = " "
	local value1 

    os.execute ("/bin/echo -n `/pfrm2.0/bin/mem.sh |grep FREE|cut -d ' ' -f 2` > /tmp/freeMem")
	local freeMem = ""
    f = io.open("/tmp/freeMem","r")
    if(f ~= nil) then
        freeMem = f:read("*line")
        f:close()
		value = freeMem
		return status, value
	else
		value = "FREE_MEM_GET_FAILED"
		return status, value
	end
end

--[[
--*****************************************************************************
-- cpuMemUsageTr.cpuUsageGet - get cpu usage
-- 
-- TR69 Parameter: Device.DeviceInfo.ProcessStatus.CPUUsage
--
]]--

function cpuMemUsageTr.cpuUsageGet (input)

	local status = "0"
	local value = " "
	local value1 

    -- CPU/Mem usage
	os.execute ("/bin/echo -n `/pfrm2.0/bin/cpu.sh |/bin/grep TOTAL_CPU_USAGE|/usr/bin/cut -d ' ' -f 2` > /tmp/cpuusage")
	local cpuUsage = ""
    local f = io.open("/tmp/cpuusage","r")
    if(f ~= nil) then
        cpuUsage = f:read("*line")
        f:close()
        value = cpuUsage
        return status, value
	else
		value = "CPU_USAGE_GET_FAILED"
		return status, value
	end
end
