--[[
                Copyright(c) 2008, 2009 - TeamF1, Inc.
                All rights reserved.

strlib.lua -- Utility string routines

 $Id: strlib.lua 1552 2011-03-30 17:45:18Z prasanna@teamf1.com $ 
]]--
strlib = {}

function strlib.split (str, div)
   assert(str and div)
    if (div=='') then return false end
    local pos,arr = 0,{}
    -- for each divider found
    for st,sp in function() return string.find(str,div,pos,true) end do
	    table.insert(arr,string.sub(str,pos,st-1)) -- Attach chars left of current divider
	    pos = sp + 1 -- Jump past current divider
    end
    table.insert(arr,string.sub(str,pos)) -- Attach chars right of last divider
    return arr
end

-- convert a dot-separated string attribute to a tree structure.
-- I.e., if you pass:
--  obj, "a.b.c.d" 10,
-- result will be: 
--  obj.a.b.c.d = 10
-- if any of the objects in the path do not exist, they will be
-- created.
function strlib.str2tree(obj, name, value) 
   local cursor = obj 
   if (cursor == nil) then
      debug.traceback()
      return
   end
   local pattern = "([%a%d]+%.)"
   local function navigator(match)
      match = match:gsub("([%a%d]+)%.","%1")
      --print("match: " .. tostring(match))
      local newcursor = cursor[match]
      if (newcursor == nil) then
	 -- print("creating new " .. tostring(match))
 	 newcursor = {}
 	 cursor[match] = newcursor
 	 cursor = newcursor
      else
	 -- print(tostring(match) .. " already exists ")
 	 cursor = newcursor
      end
      return ""
   end

   local propName = name:gsub(pattern,navigator)
   -- print("cursor is: " .. tostring(cursor))
   -- at this point, cursor should be the leaf object
   -- and propName should be the property name
   cursor[propName] = value
end

-- go through each property in props, and "unflatten" each property,
-- i.e. props["a.b.c.d"]  will be set to obj.a.b.c.d 
--
function strlib.unflattenTree(obj, props)
   tf1debug.print("unflattening object: " .. tostring(obj))
   for k,v in pairs(props) do
      if (k ~= nil and k~= '') then
	 str2tree(obj,k, v)
      end
   end
end

function strlib.append(str1, str2, separator)
   separator = separator or ''
   return string.format("%s%s%s",tostring(str1),separator,tostring(str2))
end

function strlib.oid2str(oid)
   if (oid == nil) then
      return nil
   end
   return string.format([[%s/%s/%s]],oid.classId, oid.instanceId, oid.deviceId)
end

--[[ Local functions to convert from table to string ]]--
local function val_to_str ( v )
  if "string" == type( v ) then
    v = string.gsub( v, "\n", "\\n" )
    if string.match( string.gsub(v,"[^'\"]",""), '^"+$' ) then
      return "'" .. v .. "'"
    end
    return '"' .. string.gsub(v,'"', '\\"' ) .. '"'
  else
    return "table" == type( v ) and strlib.serializeTbl( v ) or
      tostring( v )
  end
end

local function key_to_str ( k )
  if "string" == type( k ) and string.match( k, "^[_%a][_%a%d]*$" ) then
    return k
  else
    return "[" .. table.val_to_str( k ) .. "]"
  end
end


-- Function Strlib.to serialize a table into a string Useful for serializing
-- a tree to DB, to generate ASCII config files etc.
function strlib.serializeTbl( tbl )
  local result, done = {}, {}
  for k, v in ipairs( tbl ) do
    table.insert( result, val_to_str( v ) )
    done[ k ] = true
  end
  for k, v in pairs( tbl ) do
    if not done[ k ] then
      table.insert( result,
        key_to_str( k ) .. "=" .. val_to_str( v ) )
    end
  end
  return "{" .. table.concat( result, "," ) .. "}"
end

-- Function to convert a serialized table from string back to a Lua
-- table.  Reverse of the serializeTbl() function above.
function strlib.deserialize(str)
    local func = assert(loadstring("return " .. str))
    return func()
end

function strlib.trim (s)
   return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
end

function strlib.splitCamelCase(s)
    assert(s)
    return s:gsub("(%l)(%u)","%1 %2"):gsub("^%l",string.upper)
end

function strlib.strcasecmp(s1, s2) 
    require "platformLib"
    return (platformLib.strcasecmp(s1, s2))
end

return strlib
