--[[
#### Adarsh Uppula
#### TeamF1
#### www.TeamF1.com
#### June 29, 2007

####Copyright (c) 2014, TeamF1 Networks Pvt. Ltd.
####(Subsidiary of D-Link India)

####modification history
####--------------------
####01c,24Aug17,sjr changes for #61523
####01b,31Jul17,swr  Changes for SPR 60117
####01a,06dec14,mmk  Added year field and removed a print which was causing GUI error.

#### File: logging.lua
#### Description: logging functions

#### Revisions:
01a,16dec11 adi added lua specific functions to get,set,view & clear logs
None
]]--


require "loggingLib"

--************* Requires *************
if (db == nil) then
    require "teamf1lualib/db"
end

--package logging
logging = {}
logging.level = {
    ADP_DEBUG_LEVEL_EMERGENCY  = 0x01,
    ADP_DEBUG_LEVEL_ALERT      = 0x02,
    ADP_DEBUG_LEVEL_CRIT       = 0x04,
    ADP_DEBUG_LEVEL_ERROR      = 0x08,
    ADP_DEBUG_LEVEL_WARN       = 0x10,
    ADP_DEBUG_LEVEL_NOTICE     = 0x20,
    ADP_DEBUG_LEVEL_INFO       = 0x40,
    ADP_DEBUG_LEVEL_DEBUG      = 0x80,
    ADP_DEBUG_LEVEL_DEBUG2     = 0x100,
    ADP_EVENT_LEVEL_MSG        = 0x200,
}

--table packages
logConfig = {}
sysLogInfo = {}
emailLogs = {}
logEventConfig = {}
--************* Functions *************

-- logging config
function logging.logConfig_config (inputTable, rowid, operation)
    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
    db.beginTransaction() --begin transaction
    local valid = false

    -- config logConfig
    valid = logConfig.config(inputTable, rowid, operation)

    -- return
    if (valid) then
        db.commitTransaction(true)
        return "OK", "STATUS_OK"
    else
        db.rollback()
        return "ERROR", "LOGGING_CONFIG_FAILED"
    end
end

-- logConfig config
function logConfig.config (inputTable, rowid, operation)
    -- validate
    if (logConfig.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("logConfig", inputTable)
        elseif (operation == "edit") then
            return db.update("logConfig", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("logConfig", inputTable)
        end
    end
    return false
end

-- logConfig inputvalidate
function logConfig.inputvalidate (inputTable, operation)
    if (true) then
        return db.typeAndRangeValidate(inputTable)
    end
    return false
end

--emailLogs config

function logging.emailLogs_config(inputTable)

    local entryName = db.getAttribute ("emailLogs","_ROWID_",1,"entryName")
    emailLogsBinary = db.getAttribute ("environment","name","EMAILLOGS_PROGRAM","value") .. " " .. DB_FILE_NAME

    if(inputTable["emailLogs.mailLogs"] == "0") then
        valid = db.update ("emailLogs", inputTable, 1)
        if (valid == false) then 
            return "ERROR" ,"LOGGING_EMAILLOGS_CONFIG_FAILED"
        end
        
        valid = db.deleteRow("crontab","command",emailLogsBinary)
        if (valid == false) then 
            return "ERROR" ,"CRONTAB_CONFIG_FAILED"
        end

    else

        valid = db.update("emailLogs",inputTable,1)
        if(valid == false) then
            return "ERROR","LOGGING_EMAILLOGS_CONFIG_FAILED"
        end

        inputTable["smtpServer.logFile"] = db.getAttribute("environment","name","LOG_FILE","value")
        if (db.existsRow("smtpServer","entryName",entryName)) then
            local RowId = db.getAttribute ("smtpServer","entryName",entryName,"_ROWID_")
            valid = db.update ("smtpServer",inputTable, RowId)
        else
            inputTable["smtpServer.entryName"]=entryName
            valid = db.insert("smtpServer",inputTable)
        end
        if (valid == false) then
            return "ERROR","LOGGING_SMTP_CONFIG_FAILED"
        end
       
        local errorString = "OK"
        
        if (inputTable["crontab.unit"] == "0") then
            valid = db.deleteRow("crontab","command",emailLogsBinary)
        else
            valid = db.deleteRow("crontab","command",emailLogsBinary)
            errorString = crontab.config(inputTable,-1,"insert",emailLogsBinary)
        end

        if (errorString ~= "OK" or valid == false) then
                return "ERROR","LOGGING_CRONTAB_CONFIG_FAILED"
        end
    end

    -- Set hostname
    if(inputTable["emailLogs.logId"] ~= nil) then
        os.execute("/bin/hostname "..inputTable["emailLogs.logId"])
    end
    
    return "OK","STATUS_OK"
end

--emailLogs getn info() for the logs_config_emails.htm page

function logging.emailLogs_getInfo()
    configRow = {}
    local entryName=db.getAttribute("emailLogs","_ROWID_",1,"entryName")
    
    if (not db.existsRow("smtpServer","entryName",entryName)) then
        configRow['smtpServer.emailServer'] = ''
        configRow['smtpServer.fromAddr'] = ''
        configRow['smtpServer.toAddr'] = ''
        configRow['smtpServer.userName'] = ''
        configRow['smtpServer.passWord'] = ''
        configRow["crontab.unit"] = "0"
        
    else
        
        local currentInfo = db.getRow("smtpServer","entryName",entryName)
        for k,v in pairs(currentInfo) do
            configRow[k] = v
        end
        if (tonumber(configRow['smtpServer.auth']) == -1) then
            configRow['smtpServer.userName'] = ''
            configRow['smtpServer.passWord'] = ''
        end
    end
    
    emailLogsBinary = db.getAttribute("environment","name","EMAILLOGS_PROGRAM","value") .. " " .. DB_FILE_NAME
    configRow["emailLogs.mailLogs"] = db.getAttribute("emailLogs","_ROWID_",1,"mailLogs")
    configRow["emailLogs.logId"] = db.getAttribute("emailLogs","_ROWID_",1,"logId")
    
    if(not db.existsRow("crontab","command",emailLogsBinary)) then
        configRow["crontab.unit"] = "0"
    else
        local RowId = db.getAttribute("crontab", "command", emailLogsBinary,"_ROWID_")
        configRow=crontab.getSchedule(RowId,configRow)
    end
    return configRow
end

-- sysLogInfo_config(), for updating the sysLogInfo table.

function logging.sysLogInfo_config(inputTable, operation)
    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
    
    db.beginTransaction()
    local valid = false
    
    if (operation == "add") then
        valid =  db.insert("sysLogInfo", inputTable)
    elseif (operation == "edit") then
        valid = db.update("sysLogInfo", inputTable, 1)
    end
    
    if (valid) then
        db.commitTransaction(true)
        return "OK", "STATUS_OK"
    else
        db.rollback()
        return "ERROR", "LOGGING_SYSLOG_CONFIG_FAILED"
    end
end

-- VendorLogFile_config(), for updating the VendorLogInfo table.

function logging.VendorLogFile_config(inputTable, operation)
    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
    
    db.beginTransaction()
    local valid = false
    
    if (operation == "add") then
        valid =  db.insert("VendorLogFile", inputTable)
    elseif (operation == "edit") then
        valid = db.update("VendorLogFile", inputTable, 1)
    end
    
    if (valid) then
        db.commitTransaction(true)
        return "OK", "STATUS_OK"
    else
        db.rollback()
        return "ERROR", "VENDOR_LOG_FILE_CONFIG_FAILED"
    end
end

-- VendorConfigFile_config(), for updating the VendorLogInfo table.

function logging.VendorConfigFile_config(inputTable, operation)
    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
    
    db.beginTransaction()
    local valid = false
    
    if (operation == "add") then
        valid =  db.insert("VendorConfigFile", inputTable)
    elseif (operation == "edit") then
        valid = db.update("VendorConfigFile", inputTable, 1)
    end
    
    if (valid) then
        db.commitTransaction(true)
        return "OK", "STATUS_OK"
    else
        db.rollback()
        return "ERROR", "VENDOR_LOG_FILE_CONFIG_FAILED"
    end
end

--logging events config
function logging.logEventsConfig_config(inputTable, rowid, operation)
    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
    db.beginTransaction() --begin transaction
    local valid = false

    -- config logEventEmailConfig
    valid = logEventConfig.config(inputTable, rowid, operation)

    -- return
    if (valid) then
        db.commitTransaction(true)
        return "OK", "STATUS_OK"
    else
        db.rollback()
        return "ERROR", "LOGGING_CONFIG_FAILED"
    end
end

-- logEventConfig config
function logEventConfig.config (inputTable, rowid, operation)
    -- validate
    if (logConfig.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("logEventEmailConfig", inputTable)
        elseif (operation == "edit") then
            return db.update("logEventEmailConfig", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("logEventEmailConfig", inputTable)
        end
    end
    return false
end

-- email Log Config
function logging.emailLogsConfig(inputTable)
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
	
    local valid = false
    db.beginTransaction()

    errorFlag, statusCode = logging.emailLogs_config(inputTable)
    if(errorFlag == "OK") then
	local syslogInfo = db.getTable ("sysLogInfo")
        for k,v in pairs (syslogInfo) do
            if(inputTable["sysLogInfo.Enable".. v["sysLogInfo.serverId"]] ~= nil) then
                v["sysLogInfo.Enable"] = inputTable["sysLogInfo.Enable" .. v["sysLogInfo.serverId"]]
		if(v["sysLogInfo.Enable"] == "1") then
	                v["sysLogInfo.serverName"] = inputTable["sysLogInfo.serverName" .. v["sysLogInfo.serverId"]]
        	        v["sysLogInfo.facilityId"] = inputTable["sysLogInfo.facilityId" .. v["sysLogInfo.serverId"]]
                	v["sysLogInfo.severity"] = inputTable["sysLogInfo.severity" .. v["sysLogInfo.serverId"]]
		end
                valid = db.update("sysLogInfo", v, v["sysLogInfo._ROWID_"])
                if (valid == false) then
                    break
                end
            end
	end	
    end
	
    if (valid and errorFlag == "OK") then
        db.commitTransaction(true)
        return "OK", "STATUS_OK"
    else
        db.rollback()
        return "ERROR", "LOGGING_SYSLOG_CONFIG_FAILED"
    end
end

function logging.emailLogsConfigGet()
    local outTable = logging.emailLogs_getInfo()
    if (outTable == nil) then
        outTable = {}
    end

    local syslogInfo = db.getTable ("sysLogInfo")
    for k,v in pairs(syslogInfo) do
        outTable["sysLogInfo.Enable" .. v["sysLogInfo.serverId"]] = v["sysLogInfo.Enable"]
        outTable["sysLogInfo.serverName" .. v["sysLogInfo.serverId"]] = v["sysLogInfo.serverName"]
        outTable["sysLogInfo.facilityId" .. v["sysLogInfo.serverId"]] = v["sysLogInfo.facilityId"]
        outTable["sysLogInfo.severity" .. v["sysLogInfo.serverId"]] = v["sysLogInfo.severity"]
	end
    return outTable
end

function logging.logMsg (comp, facility, level, message)
    local inputTable = {}
    inputTable ["eventLog.component"] = comp
    inputTable ["eventLog.facilityId"] = facility
    inputTable ["eventLog.logLevel"] = level
    inputTable ["eventLog.time"] = os.time()
    inputTable ["eventLog.textMessage"] = message

    db.insert ("eventLog", inputTable)
end

--**********************************************************************************

--@name  logging.loggingView()
--
--@description The function will return the logs for all the facilities
--
--@return

function logging.loggingView()

    --locals
    local logs = {}
    local logTable = {}
    local nilTable = {}
    local logLevel = ""
    local where = ""
    local customQuery = ""
    if(facilityId == "255") and (severityLevel == "ALL") then
        customQuery = "SELECT *, _ROWID_ AS _ROWID_ FROM eventlog ORDER BY _ROWID_ DESC"
        logs = db.getTable ("eventLog", false, customQuery)
    else
        if((facilityId == "255") and (severityLevel ~= "ALL"))then
            if(severityLevel  == "emergency") then
                logLevel = "1"	
            elseif(severityLevel  == "alert") then
                logLevel = "2"	
            elseif(severityLevel  == "critical") then
                logLevel = "4"	
            elseif(severityLevel  == "error") then
                logLevel = "8"	
            elseif(severityLevel == "warning") then
                logLevel = "16"	
            elseif(severityLevel == "notification") then
                logLevel = "32"	
            elseif(severityLevel == "information") then
                logLevel = "64"	
            elseif( severityLevel == "debugging") then
                logLevel = "128"	
            end   
            where = "logLevel = '" .. logLevel .."' ORDER BY _ROWID_ DESC"
        elseif((severityLevel == "ALL") and (facilityId ~= "255")) then
	    if (facilityId == "3") then
		where = "facilityId IN ( '3', '1', '10', '12', '17', '18', '19', '20', '21', '22', '23')  ORDER BY time DESC"
	    else
            	where = "facilityId = '" .. facilityId .."' ORDER BY time DESC"
	    end
        else
            if(severityLevel  == "emergency") then
                logLevel = "1"	
            elseif(severityLevel  == "alert") then
                logLevel = "2"	
            elseif(severityLevel  == "critical") then
                logLevel = "4"	
            elseif(severityLevel  == "error") then
                logLevel = "8"	
            elseif(severityLevel == "warning") then
                logLevel = "16"	
            elseif(severityLevel == "notification") then
                logLevel = "32"	
            elseif(severityLevel == "information") then
                logLevel = "64"	
            elseif( severityLevel == "debugging") then
                logLevel = "128"	
            end
	    if (facilityId == "3") then
		where = "facilityId IN ( '3', '1', '10', '12', '17', '18', '19', '20', '21', '22', '23') and logLevel = '" .. logLevel .."' ORDER BY _ROWID_ DESC"
	    else
            	where = "facilityId = '" .. facilityId .."' and logLevel = '" .. logLevel .."' ORDER BY _ROWID_ DESC"
	    end 
        end
        logs = db.getRowsWhere ("eventLog", where ,false)
    end
    logTable = logging.getLogs(logs)
    if(logTable == nil) then
        return nilTable
    end
    return logTable
end
--***************************************************************************
--@anme logging.loggingClear()
--
--@description The function will clear the log 
--
--@return

function logging.loggingClear()
	--declaration 
	local statusMsg, errMsg
	--debug statement
    util.appendDebugOut("Delete Logs. ..called")
	--execute the command
    db.execute("DELETE FROM eventLog")

    statusMsg = "OK"
	errMsg = "STATUS_OK"
    return statusMsg, errMsg
end

--********************************************************************************
--@name logging.syslogfacilityGe()
--
--@description The function get the configured facility using the data stored in
--logConfig table.
--
--@param 
--
--@return errorMsg, statusMsg, facilityId
--
function logging.syslogfacilityGet()

    local logConfigTbl ={}
    local resultTbl = {}
    local facilityId = 0
    local facilityCount = 0
    local SYSLOG_DESTINATION_VAL = "5"
    local EVENTLOG_DESTINATION_VAL = "1"

    local i, row
    -- Get the total logConfig table from DB.
    logConfigTbl = db.getTable("logConfig", false)
    if (logConfigTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN", nil
    end

    --Find the facilityId of the configuration
    for i,row in pairs(logConfigTbl) do
        local facilityHit = 0

        if(row["emergency"] == SYSLOG_DESTINATION_VAL or row["alert"] == SYSLOG_DESTINATION_VAL or 
            row["critical"] == SYSLOG_DESTINATION_VAL or row["error"] == SYSLOG_DESTINATION_VAL or 
            row["warning"] == SYSLOG_DESTINATION_VAL or row["notice"] == SYSLOG_DESTINATION_VAL or 
            row["information"] == SYSLOG_DESTINATION_VAL or row["debug"] == SYSLOG_DESTINATION_VAL) then
            facilityHit = 1
        end

        if (facilityHit == 1) then
            facilityId = row["facilityId"]
            --increment the facilityCount we will use this in later stages.
            facilityCount = facilityCount +1
        end
    end

    -- logic/condition for "ALL" facility.
    if(facilityCount == #logConfigTbl) then
        facilityId = 255
    end

   return "OK", "STATUS_OK", facilityId
end

--********************************************************************************
--@name logging.remoteLoggingGet()
--
--@description The function get the info from the syslog table along with the 
--networkname from the networkInterface table.
--
--@param 
--      syslogTbl["Enable"]
--      syslogTbl["serverName"] 
--      syslogTbl["serverPort"] 
--      syslogTbl["facilityId"] 
--      syslogTbl["severity"] 
--      syslogTbl["LogicalIfName"] 
--      syslogTbl["serverId"] 
--      syslogTbl["uniqueID"] 
--      syslogTbl["_ROWID_"] 
--
--@return

function logging.remoteLoggingGet()

    -- require
    require "teamf1lualib/platform"
    --locals
	local logTbl = {}
	local inputTable = {}
	local networkTbl = {}
	local syslogTbl = {}	
    local severity
	-- getting the log Info
	syslogTbl = db.getRowWhere("sysLogInfo", " _ROWID_=1", false)
	if (syslogTbl == nil) then
		return inputTable
   	end
   
	syslogTbl.networks	= {}
    -- Set the Syslog's Remote Log Identifier to uniqueID value from db.
	syslogTbl["hostname"] = syslogTbl["uniqueID"]
	syslogTbl["enable"] = syslogTbl["Enable"]

	-- Get all the available IPv4 network for dropdown display.
	networkTbl = platform.availableIPv4NetworkGet()
	if (networkTbl ~= nil) then		
		for i,v in pairs(networkTbl) do
            if (v["LogicalIfName"] == "IF2" or v["LogicalIfName"] == "IF1") then
                syslogTbl.networks[i] = {}
                syslogTbl.networks[i]["networkname"] = v["networkName"]
                -- set the logical ifname selected by the user.
                -- TODO: What if the earlier user selected network does not exist at
                -- this point ?????? 
                if(syslogTbl["LogicalIfName"] == v["LogicalIfName"]) then
                    syslogTbl["interface"] = v["networkName"]
                end
            end

		end	
	end

	-- return		
	return syslogTbl
end  

--*******************************************************************************
--@name  logging.isValidFacility(syslogTable)
--
--@description The function checks if the configured facility is valid.
--
--@return "OK", "VALID_FACILITYID" on SUCCESS
--@return "ERROR", "INVALID_FACILITY_CONFIGURED" on FAILURE

function logging.isValidFacility(syslogTable)
    local facilityId = syslogTable["facilityId"]

    facilityId = tonumber(facilityId)
    
    if (facilityId == 255) then
        return "OK", "VALID_FACILITYID"
    end
                    
    if ((facilityId < 0) or (facilityId > 23)) then
        return "ERROR", "INVALID_FACILITY_CONFIGURED"
    end        
                            
    return "OK", "VALID_FACILITYID"
end

--*******************************************************************************
--@name  logging.isValidSeverity(syslogTable)
--
--@description The function checks if the configured severity is valid.
--
--@return "OK", "VALID_SEVERITY" on SUCCESS
--@return "ERROR", "INVALID_SEVERITY_CONFIGURED" on FAILURE

function logging.isValidSeverity(syslogTable)

    if (syslogTable["severity"] ~= "emergency" and
        syslogTable["severity"] ~= "alert" and
        syslogTable["severity"] ~= "critical" and
        syslogTable["severity"] ~= "error" and
        syslogTable["severity"] ~= "warning" and
        syslogTable["severity"] ~= "notice" and
        syslogTable["severity"] ~= "information" and
        syslogTable["severity"] ~= "debug" and
        syslogTable["severity"] ~= "ALL") then
        --return
        return "ERROR", "INVALID_SEVERITY_CONFIGURED"
    end    

    return "OK", "VALID_SEVERITY"
end

--********************************************************************************
--@name logging.syslogfacilitySet()
--
--@description The function sets the logconfig table rows as per the user
--configured facilityId.
--
--@param 
--
--@return errorMsg, statusMsg => "ERROR", "LOG_CONFIGURATION_FAILED" on FAILURE
--                               "OK", "STATUS_OK" on SUCCESS
--
function logging.syslogfacilitySet(syslogTable)
    local valid = true
    local logConfigTbl ={}
    local SYSLOG_DESTINATION_VAL = "5"
    local EVENTLOG_DESTINATION_VAL = "1"
    local i,row
    
    -- Get the total logConfig table from DB.
    logConfigTbl = db.getTable("logConfig", false)
    if (logConfigTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end
    
    -- First, set all the severity fields in all the rows to "1" => Log only to
    -- event Table.
    local valid = true
    for i,row in pairs (logConfigTbl) do 
        row["emergency"] = EVENTLOG_DESTINATION_VAL
        row["alert"] = EVENTLOG_DESTINATION_VAL
        row["critical"] = EVENTLOG_DESTINATION_VAL
        row["error"] = EVENTLOG_DESTINATION_VAL
        row["warning"] = EVENTLOG_DESTINATION_VAL
        row["notice"] = EVENTLOG_DESTINATION_VAL
        row["information"] = EVENTLOG_DESTINATION_VAL
        row["debug"] = EVENTLOG_DESTINATION_VAL
       
        row = util.addPrefix(row, "logConfig.")
        if (valid) then
            --db update
            valid = db.update("logConfig", row, row["logConfig._ROWID_"])
        else
            db.rollback()
            return "ERROR", "LOG_CONFIGURATION_FAILED"
        end
    end

    if (syslogTable == nil) then
        return "OK", "STATUS_OK"
    end
            
    -- Now set the particular severity of the selected facility to "5" => log to
    -- event table and syslog server simultaneously.
    for i,ROW in pairs (logConfigTbl) do
        -- Set the severity only for the facility(rows) that are selected by
        -- user. 
        -- facilityID = 255 => user selected for all supported facilities.
        if ((ROW["facilityId"] == syslogTable["facilityId"]) or (syslogTable["facilityId"] == "255")) then
           --Whatever severity level user will select, all the logs above
           --selected severity will also be logged
            if((syslogTable["severity"] == "ALL") or (syslogTable["severity"] == "emergency")) then
                ROW["emergency"] = SYSLOG_DESTINATION_VAL
            elseif (syslogTable["severity"] == "alert") then
                ROW["emergency"] = SYSLOG_DESTINATION_VAL
                ROW["alert"] = SYSLOG_DESTINATION_VAL
            elseif (syslogTable["severity"] == "critical") then
                ROW["emergency"] = SYSLOG_DESTINATION_VAL
                ROW["alert"] = SYSLOG_DESTINATION_VAL
                ROW["critical"] = SYSLOG_DESTINATION_VAL
            elseif (syslogTable["severity"] == "error") then
                ROW["emergency"] = SYSLOG_DESTINATION_VAL
                ROW["alert"] = SYSLOG_DESTINATION_VAL
                ROW["critical"] = SYSLOG_DESTINATION_VAL
                ROW["error"] = SYSLOG_DESTINATION_VAL
            elseif (syslogTable["severity"] == "warning") then
                ROW["emergency"] = SYSLOG_DESTINATION_VAL
                ROW["alert"] = SYSLOG_DESTINATION_VAL
                ROW["critical"] = SYSLOG_DESTINATION_VAL
                ROW["error"] = SYSLOG_DESTINATION_VAL
                ROW["warning"] = SYSLOG_DESTINATION_VAL
            elseif (syslogTable["severity"] == "notice") then
                ROW["emergency"] = SYSLOG_DESTINATION_VAL
                ROW["alert"] = SYSLOG_DESTINATION_VAL
                ROW["critical"] = SYSLOG_DESTINATION_VAL
                ROW["error"] = SYSLOG_DESTINATION_VAL
                ROW["warning"] = SYSLOG_DESTINATION_VAL
                ROW["notice"] = SYSLOG_DESTINATION_VAL
            elseif (syslogTable["severity"] == "information") then
                ROW["emergency"] = SYSLOG_DESTINATION_VAL
                ROW["alert"] = SYSLOG_DESTINATION_VAL
                ROW["critical"] = SYSLOG_DESTINATION_VAL
                ROW["error"] = SYSLOG_DESTINATION_VAL
                ROW["warning"] = SYSLOG_DESTINATION_VAL
                ROW["notice"] = SYSLOG_DESTINATION_VAL
                ROW["information"] = SYSLOG_DESTINATION_VAL
            elseif (syslogTable["severity"] == "debug") then
                ROW["emergency"] = SYSLOG_DESTINATION_VAL
                ROW["alert"] = SYSLOG_DESTINATION_VAL
                ROW["critical"] = SYSLOG_DESTINATION_VAL
                ROW["error"] = SYSLOG_DESTINATION_VAL
                ROW["warning"] = SYSLOG_DESTINATION_VAL
                ROW["notice"] = SYSLOG_DESTINATION_VAL
                ROW["information"] = SYSLOG_DESTINATION_VAL
                ROW["debug"] = SYSLOG_DESTINATION_VAL
            else
                return "ERROR", "INVALID_SEVERITY_CONFIGURED"
            end
            
            ROW = util.addPrefix(ROW, "logConfig.")
            if (valid) then
                valid = db.update("logConfig",ROW,ROW["logConfig._ROWID_"])
            else
                db.rollback()
                return "ERROR", "LOG_CONFIGURATION_FAILED"
            end
        end    
    end

    -- save db if no error
    if (valid) then db.save() end

    return "OK", "STATUS_OK"
end


--*******************************************************************************
--@name  logging.remoteLoggingSet(inputTable)
--
--@description The function update the syslogInfo table
--
--@return

function logging.remoteLoggingSet(syslogTable)

	--locals
	local systemTbl = {}
	local syslogInfo = {}
	local status = nil
	local errMsg = nil
	local netTbl = nil

    if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end

    -- query the SYSLOG INFO configuration
    local query = " _ROWID_=1"

    syslogInfo = db.getRowWhere("sysLogInfo", query, false)
    if (syslogInfo == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

	--begning transaction 	
	db.beginTransaction()

    if (tonumber(syslogTable["enable"]) == 0) then 
        syslogInfo["Enable"] = 0
        errMsg, status = logging.syslogfacilitySet()
    else
        --sanity check for "Facility level"
        errMsg, status = logging.isValidFacility(syslogTable)
        if(errMsg ~= "OK") then
            return errMsg, status
        end
        
        --sanity check for "severity level"
        errMsg, status = logging.isValidSeverity(syslogTable)
        if(errMsg ~= "OK") then
            return errMsg, status
        end

        -- First set the log Facility configuration into logconfig table.
        errMsg, status = logging.syslogfacilitySet(syslogTable)
    
        syslogInfo["Enable"] = 1
        if(syslogTable["interface"] ~= nil) then
            syslogInfo["LogicalIfName"] = db.getAttribute("networkInterface", "networkName", 
                                                          syslogTable["interface"], "LogicalIfName")
        end

        if(syslogTable["serverName"] ~= nil) then
            syslogInfo["serverName"] = syslogTable["serverName"]
        end

        if(syslogTable["serverPort"] ~= nil) then
            syslogInfo["serverPort"] = syslogTable["serverPort"]
        end

        if(syslogTable["severity"] ~= nil) then
          syslogInfo["selSeverity"] = syslogTable["severity"]
       end

       if(syslogTable["facilityId"] ~= nil) then
          syslogInfo["selFacilityId"] = syslogTable["facilityId"]
       end
    end

    local tmpSyslogInfo = util.addPrefix(syslogInfo, "sysLogInfo.")
    local valid = db.update("sysLogInfo",tmpSyslogInfo,1)

    if (valid) then
        db.commitTransaction(true)
        errMsg = "OK"
        status = "STATUS_OK"
        return	errMsg, status 
    else
        db.rollback()
        errMsg = "ERROR"
        status = "SYSLOGINFO_CONFIG_FAILED"
        return	errMsg, status 
    end
end

function logging.import (inputTable, defaultCfg, remCfg)
    if (inputTable == nil) then
        inputTable = defaultCfg
    end
    
    --initializing a temp table
    local logConfigTmp = {}
    local syslogInfoTmp = {}
    local VendorLogFileTmp = {}
   
    -- calling the update functionality
    logConfigTmp = config.update (inputTable.logConfig, defaultCfg.logConfig, remCfg.logConfig)
    syslogInfoTmp = config.update (inputTable.sysLogInfo, defaultCfg.sysLogInfo, remCfg.sysLogInfo)
    VendorLogFileTmp = config.update (inputTable.VendorLogFile, defaultCfg.VendorLogFile, remCfg.VendorLogFile)
    VendorConfigFileTmp = config.update (inputTable.VendorConfigFile, defaultCfg.VendorConfigFile, remCfg.VendorConfigFile)
    
    if (logConfigTmp ~= nil and #logConfigTmp ~= 0) then 
        for i,v in ipairs (logConfigTmp) do
            v = util.addPrefix (v, "logConfig.")
            status,message = logging.logConfig_config (v, "-1", "add");
        end
    end 

    if (syslogInfoTmp ~= nil and #syslogInfoTmp ~= 0) then 
        for i,v in ipairs (syslogInfoTmp) do	
            v = util.addPrefix (v,"sysLogInfo.")
            status,message = logging.sysLogInfo_config(v,"add");
        end	
    end

    if (VendorLogFileTmp ~= nil and #VendorLogFileTmp ~= 0) then 
        for i,v in ipairs (VendorLogFileTmp) do	
            if(v["Name"] == "/var/log/messages") then
                v["Name"] = "/var/dbglog.tgz"
            end
            v = util.addPrefix (v,"VendorLogFile.")
            status,message = logging.VendorLogFile_config(v,"add");
        end	
    end

    if (VendorConfigFileTmp ~= nil and #VendorConfigFileTmp ~= 0) then 
        for i,v in ipairs (VendorConfigFileTmp) do	
            v = util.addPrefix (v,"VendorConfigFile.")
            status,message = logging.VendorConfigFile_config(v,"add");
        end	
    end
end

function logging.export ()
    local logInfo = {}
    logInfo["logConfig"] = db.getTable ("logConfig", false)
    logInfo["sysLogInfo"] = db.getTable ("sysLogInfo", false)	
    logInfo["VendorLogFile"] = db.getTable ("VendorLogFile", false)	
    logInfo["VendorConfigFile"] = db.getTable ("VendorConfigFile", false)	
    return logInfo
end

if (config.register) then
   config.register("logging", logging.import, logging.export, "1")
end



--***********************************************************************************

--@name  logging.loggingShow()
--
--@description The function will return the logs for particular facility and
--particular logLevel
--
--@return

--[[function logging.loggingShow(facilityId,severityLevel)

    --locals
    local logs = {}
    local compName
    local logLevel = ""
    local result = ""
    -- defining logLevel on the basis of severityLevel selected by the user.
	if(severityLevel  == "emergency") then
        logLevel = "1"	
    elseif(severityLevel  == "alert") then
		logLevel = "2"	
	elseif(severityLevel  == "critical") then
		logLevel = "4"	
	elseif(severityLevel  == "error") then
		logLevel = "8"	
	elseif(severityLevel == "warning") then
		logLevel = "16"	
	elseif(severityLevel == "notice") then
		logLevel = "32"	
	elseif(severityLevel == "information") then
		logLevel = "64"	
	elseif( severityLevel == "debug") then
		logLevel = "128"	
	end    
   -- defining facilityId
    if(facilityId == "Kernel") then
        facilityId = "0"
    elseif(facilityId == "System") then
        facilityId = "3"
    elseif(facilityId == "Local0-wireless") then
        facilityId = "16"
    end
    local where = "facilityId = '" .. facilityId .."' and logLevel = '" .. logLevel .."'"
    logs = db.getRowsWhere ("eventLog", where ,false)
    --getting the logs from the eventlog table for selected facilityId and
    --particular logLevel
    result = logging.getLogs(logs)
    return result
end]]--





--***********************************************************************************

--@name  logging.getLogs()
--
--@description The function will return the logs
--
--@return
function logging.getLogs(logs)

    --require
    require "teamf1lualib/logging"
    local nilTable = {}
    if (logs == nil) then
        return nilTable
    end
    for k,v in pairs (logs) do
        if(v.logLevel == "1")then
            v.severity = "Emergency"
        elseif(v.logLevel == "2")then
            v.severity = "Alert"
        elseif(v.logLevel =="4")then
            v.severity = "Critical"
        elseif(v.logLevel == "8")then
            v.severity = "Error"
        elseif(v.logLevel == "16")then
            v.severity = "Warning"
        elseif(v.logLevel == "32")then
            v.severity = "Notice"
        elseif(v.logLevel  == "64")then
            v.severity = "Information"
        elseif(v.logLevel == "128")then
            v.severity = "Debug"
        end
        if(v.facilityId == "0")then
            v.facility = "Kernel"
        elseif((v.facilityId == "3") or (v.facilityId == "1") or (v.facilityId == "10") or (v.facilityId == "12") or (v.facilityId == "17") or (v.facilityId == "18") or (v.facilityId == "19") or (v.facilityId == "20") or (v.facilityId == "21") or (v.facilityId == "22") or (v.facilityId == "23")) then
            v.facility = "System"
        elseif(v.facilityId == "16")then
            v.facility = "Local0-wireless"
        end
        v.component = string.sub (v.component, 10)
		v.time= os.date ("%a %b %e %T %Y", tonumber(v.time))
        if (v.textMessage ~= nil) then
            -- remove "\n" before displaying
            if (string.find (v.textMessage,"\n", -2)) then
                v.textMessage = string.sub (v.textMessage, 1, -2)
            end
			v.textMessage = util.filterXSSChars (v.textMessage)
            
        end
    end
    return logs

end
