-- @copyright Copyright (c) 2013, TeamF1, Inc. 

--************* Packages *************
mapt = {}
maptPortStats = {}
PrefixStart = "0"
ipv4PrefixEnd = "32"
ipv6PrefixEnd = "128"
eabitsAddressEnd = "281474976710656"
eabitsVal = "48"
psidOffsetEnd = "16"

-------------------------------------------------------------------------
-- @name mapt.config
--
-- @description 
--
-- @return 
--

function mapt.config (tableName, inputTable, rowid, operation)
    -- validate
    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
            return db.insert(tableName, inputTable)
        elseif (operation == "edit") then
            return db.update(tableName, inputTable, rowid)
        elseif (operation == "delete") then
           for k,v in pairs(inputTable) do
                valid  = db.deleteRow(tableName, "_ROWID_", v)
                if (not valid) then  return false end
            end
        end
    end

    return false
end

-------------------------------------------------------------------------
-- @name mapt.cfgInit
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function mapt.cfgInit (row, conf)

    if (conf["enable"] ~= nil) then
        row["enable"] = conf["enable"]  
    end 

    if (conf["ipv4Interface"] ~= nil) then
        row["ipv4Interface"] = conf["ipv4Interface"]  
    end  

    if (conf["ipv4Prefix"] ~= nil) then
        row["ipv4Prefix"] = conf["ipv4Prefix"]  
    end        
    
    if (conf["ipv4PrefixLen"] ~= nil) then
        row["ipv4PrefixLen"] = conf["ipv4PrefixLen"]  
    end 

    if (conf["ipv6Interface"] ~= nil) then
        row["ipv6Interface"] = conf["ipv6Interface"]  
    end 

    if (conf["ipv6Prefix"] ~= nil) then
        row["ipv6Prefix"] = conf["ipv6Prefix"]  
    end 

    if (conf["ipv6PrefixLen"] ~= nil) then
        row["ipv6PrefixLen"] = conf["ipv6PrefixLen"]  
    end 

    if (conf["brIpv6Prefix"] ~= nil) then
        row["brIpv6Prefix"] = conf["brIpv6Prefix"]  
    end 

    if (conf["brIpv6PrefixLen"] ~= nil) then
        row["brIpv6PrefixLen"] = conf["brIpv6PrefixLen"]  
    end 

    if (conf["eabitsVal"] ~= nil) then
        row["eabitsVal"] = conf["eabitsVal"]  
    end 
    
    if (conf["eaLength"] ~= nil) then
        row["eaLength"] = conf["eaLength"]  
    end 

    if (conf["offset"] ~= nil) then
        row["offset"] = conf["offset"]  
    end 

    if (conf["maptMode"] ~= nil) then
        row["maptMode"] = conf["maptMode"]  
    end 
    
    return row
end

-------------------------------------------------------------------------
-- @name mapt.defCfgGet
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function mapt.defCfgGet()
    local conf = {}

    conf["enable"] ="0"
    conf["ipv4Interface"] = "IF2"
    conf["ipv4Prefix"] ="202.38.117.0"
    conf["ipv4PrefixLen"] ="24"
    conf["ipv6Interface"] ="IF1"
    conf["ipv6Prefix"] ="2001:da8:b4b6::"
    conf["ipv6PrefixLen"] ="48"
    conf["brIpv6Prefix"] ="2001:da8:b4b6:ffff::"
    conf["brIpv6PrefixLen"] ="64"
    conf["eabitsVal"] ="21"
    conf["eaLength"] ="16"
    conf["offset"] ="5"
    conf["maptMode"] ="1"

    return conf
end




-------------------------------------------------------------------------
-- @name mapt.import
--
-- @description 
--
-- @return 
--

function mapt.import (maptConfig, defaultCfg, removeCfg)
    if (maptConfig == nil) then
        maptConfig = defaultCfg
    end

    local maptConfigTmp = {}

    maptConfigTmp = config.update (maptConfig, defaultCfg, removeCfg)
    if (maptConfigTmp ~= nil and #maptConfigTmp ~= 0) then
        for i,v in ipairs (maptConfigTmp) do
            v = util.addPrefix (v, "maptConfig.");
            mapt.config ("maptConfig", v, -1, "add")
        end
    end
	
end

-------------------------------------------------------------------------
-- @name mapt.export
--
-- @description 
--
-- @return 
--

function mapt.export ()
	local maptConfigTbl = {}
	local table = {}

 	table = db.getTable("maptConfig" , false)
	if (table ~= nil) then
	    maptConfigTbl = table
	end

	return maptConfigTbl
end
 

if (config.register) then
   config.register("maptConfig", mapt.import, mapt.export, "1")
end


-------------------------------------------------------------------------
-- @name mapt.configure
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function mapt.configure (conf)
    local query

    -- Get the mldproxy configuration
    query = "_ROWID_='1'"
    local row = db.getRowWhere("maptConfig", query, false)
    if (row ~= nil) then
        row = mapt.cfgInit(row, conf)

        row = util.addPrefix(row, "maptConfig.")
        local valid, errstr = db.update("maptConfig", row, row["maptConfig._ROWID_"])
        if (not valid) then
            return "ERROR", "IPV6_MLD_CONFIG_FAILED"
        end            
    else
        row = mapt.defCfgGet()
        row = mapt.cfgInit(row, conf)

        util.appendDebugOut ("conf.." .. util.tableToStringRec(row))

        row = util.addPrefix(row, "maptConfig.")
        local valid, errstr, rowid  = db.insert("maptConfig", row)
        if (not valid) then
            return "ERROR", "IPV6_MLD_CONFIG_FAILED"
        end            
    end        

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------------------
-- @name numberRangeCheck 
-- @description Check weather value is in the given range
-- @param min, max, value
-- @return OK for success or else ERROR

function numberRangeCheck (min, max, value)

   value = tonumber (value)
   min = tonumber (min)
   max = tonumber (max)
   if (value == nil) then
        return "ERROR"
   end
 
   if((value > max) or (value < min)) then
       return "ERROR"
   else
       return "OK"
   end
end

-------------------------------------------------------------------------
-- @name mapt.tr69configure
--
-- @description 
--
-- @param conf
--                  
-- @return 
--
function mapt.tr69configure(conf)
    require "teamf1lualib/validations"

    if (conf["brIpv6Prefix"] ~= nil) then
        errorFlag,statusCode = validations.ipv6AddrValidate(conf["brIpv6Prefix"])
	if (errorFlag == 1 ) then
	    return "ERROR"
	end  
    end 

    if (conf["brIpv6PrefixLen"] ~= nil) then
        if (numberRangeCheck(PrefixStart, ipv6PrefixEnd, conf["brIpv6PrefixLen"]) == "ERROR") then
	    return "ERROR"
	end 
    end

    if (conf["ipv4Prefix"] ~= nil) then
        if (validations.is_ipv4_address(conf["ipv4Prefix"]) == false) then
	    return "ERROR"
	end  
    end

    if (conf["ipv6Prefix"] ~= nil) then
        errorFlag,statusCode = validations.ipv6AddrValidate(conf["ipv6Prefix"])
	if (errorFlag == 1 ) then
	    return "ERROR"
	end  
    end 

    if (conf["eaLength"] ~= nil) then
        if (numberRangeCheck(PrefixStart, eabitsVal, conf["eaLength"]) == "ERROR") then
	    return "ERROR"
	end
    end

    if (conf["ipv4PrefixLen"] ~= nil) then
        if (numberRangeCheck(PrefixStart, ipv4PrefixEnd, conf["ipv4PrefixLen"]) == "ERROR") then
	    return "ERROR"
	end 
    end

    if (conf["ipv6PrefixLen"] ~= nil) then
        if (numberRangeCheck(PrefixStart, ipv6PrefixEnd, conf["ipv6PrefixLen"]) == "ERROR") then
	    return "ERROR"
	end 
    end 

    if (conf["eabitsVal"] ~= nil) then
        if (numberRangeCheck(PrefixStart, eabitsAddressEnd, conf["eabitsVal"]) == "ERROR") then
	    return "ERROR"
	end
    end 

    if (conf["offset"] ~= nil) then
        if (numberRangeCheck(PrefixStart, psidOffsetEnd, conf["offset"]) == "ERROR") then
	    return "ERROR"
	end
    end

    errorFlag,statusCode = mapt.configure (conf)
    if (errorFlag == "ERROR") then
	return "ERROR"
    end
    
    return "OK"
end
-------------------------------------------------------------------------
-- @name mapt.get
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function mapt.get ()
   
   local rows = {}
   local index = 1
   local cfgTbl = {}

   cfgTbl = db.getRow ("maptConfig", "ROWID", "1")   

   cfgTbl = util.removePrefix(cfgTbl, "maptConfig.")
   return cfgTbl
end

-------------------------------------------------------------------------
-- @name mapt.get
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function mapt.get ()
   
   local rows = {}
   local index = 1
   local cfgTbl = {}

   cfgTbl = db.getRow ("maptConfig", "ROWID", "1")   

   cfgTbl = util.removePrefix(cfgTbl, "maptConfig.")
   return cfgTbl
end

-------------------------------------------------------------------------
-- @name maptPortStats.availablePortget
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function maptPortStats.availablePortget ()
   
   local availablePortTbl = {}

   availablePortTbl = db.getRowsWhere ("maptPortStats", "inUse = 0",false)   
   return availablePortTbl
end

-------------------------------------------------------------------------
-- @name maptPortStats.medianget
--
-- @description 
--
-- @param conf
--                  
-- @return 
--
function maptPortStats.medianget ()
  
    local temp={}
    temp = db.getRowsWhere ("maptPortStats", "count != 0",false)

    if (temp == nil or #temp <= 1) then
        return nil, "ERROR", "NO_ACTIVE_PORTS_FOR_MAPT"
    end

  -- If we have an even number of table elements or odd.
  if math.fmod(#temp,2) == 0 then
      
    -- return mean value of middle two elements
    return math.ceil(( temp[#temp/2]["portNumber"] + temp[(#temp/2)+1]["portNumber"] ) / 2)
  else
    -- return middle element
    return temp[math.ceil(#temp/2)]["portNumber"]
  end
end

-------------------------------------------------------------------------
-- @name maptPortStats.peakget
--
-- @description 
--
-- @param conf
--                  
-- @return 
--
function maptPortStats.peakget ()
  
    local cur = db.execute(string.format([[SELECT MAX(count) count FROM maptPortStats]]))
    -- check for rows
    local result = nil
    if (cur) then
        local row = cur:fetch ({}, "a")
        cur:close()
        if (row) then result = row["count"] or '' end
    end
    local peak = db.getAttribute("maptPortStats", "count", result , "portNumber" )
    return peak
  end
-------------------------------------------------------------------------
-- @name maptPortStats.activePortsget
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function maptPortStats.activePortsget ()
   
   local portStatsTbl = {}

   portStatsTbl = db.getRowsWhere ("maptPortStats", "inUse != 0",false)   
   return portStatsTbl
end
