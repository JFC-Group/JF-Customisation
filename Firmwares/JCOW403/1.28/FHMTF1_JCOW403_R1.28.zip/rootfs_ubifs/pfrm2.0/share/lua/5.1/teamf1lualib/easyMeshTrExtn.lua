--[[ 
---
-- Copyright (c) 2008-2020, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: easyMeshTrExtn.lua
-- Description: TR 181 Handles For EasyMesh,Included from tr69fucs.lua.
-- 
-- modification history
-- --------------------
-- 01a, 24apr2020 vin written.
--
--]]

easyMeshMgmtTr = {}

require "teamf1lualib/easyMeshMgmt"
------------------------------------------------------------------------------
-- @name : easyMeshMgmtTr.easyMeshGet()
--
-- @description : Reads the status of EasyMesh
--
-- @return : Entire easyMesh Status
-- 
function easyMeshMgmtTr.easyMeshGet (input)
   
    local status = "0"
    local value = "0"
    local row = {}
    local query = nil
	
    --get corresponding db entry from 'easyMesh'
    query = "_ROWID_=1"
    
    row = db.getRowWhere ("easyMesh", query, false)
    
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    
    if(string.find(input["param"], "meshEnable")) then
        value = row["meshEnable"]
    else
        return "1", "DB_ERROR_TRY_AGAIN"                                                                
    end

    return status, value

end

------------------------------------------------------------------------------
-- @name : easyMeshMgmtTr.easyMeshSet()
--
-- @description : setting the status of EasyMesh
--
-- @return : Entire easyMesh Status
-- 
function easyMeshMgmtTr.easyMeshSet (input, rowids, actionType, tr69Param)

    local status = OK
    local row = {}
    local query = nil
    local easyMeshTbl = {}
    local faultTbl = {}
    local index = 0
    local retStatus = OK
    local errorcode = OK
    local rebootFlag = 0

    --get corresponding db entry from 'easyMesh'
    query = "_ROWID_=1"
    easyMeshTbl = db.getRowWhere ("easyMesh", query,true)
    if(easyMeshTbl == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    if(input["easyMesh"]["easyMesh.meshEnable"] ~= nil) then
        row["meshEnable"] = input["easyMesh"]["easyMesh.meshEnable"]   
        retStatus, errorcode = easyMeshMgmt.easyMeshSet(row)
         if(retStatus == "ERROR") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl
        else
            db.save2() 
            rebootFlag = 1
        end
    end

    -- reboot if Mesh  is changed
    if(rebootFlag == 1) then
        require "teamf1lualib/tr69Glue"
        require "teamf1lualib/reboot"
        tr69Glue.reboot(30)
    end

    return status, faultTbl

end

