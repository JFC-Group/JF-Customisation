network.supportedTypes = {}
network.supportedTypes[1]="vlan"
network.supportedTypes[2]="vap"
network.supportedTypes[3]="ethernet"
