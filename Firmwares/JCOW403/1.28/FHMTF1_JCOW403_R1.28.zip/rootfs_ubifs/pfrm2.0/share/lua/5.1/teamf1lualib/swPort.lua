--[[
#### Mohan Kannekanti
#### TeamF1
#### www.TeamF1.com
#### Feb 10, 2012

#### File: swMgr.lua
#### Description: Switch Manager utility functions

#### Revisions:
None
]]--

require "swMgrLib"
require "teamf1lualib/db"
require "teamf1lualib/util"
require "teamf1lualib/switch"

swPort  = {}
swPort.queueScheduling = {}

-- PORT properties
swPort.prop = {}
swPort.prop.portNumber= "portNumber"
swPort.prop.pvid      = "PVID"
swPort.prop.portMode  = "portMode"
swPort.prop.trustMode = "trustMode"
swPort.prop.mirroring = "mirroring"
swPort.prop.switchName= "switchName"
swPort.prop.portType  = "portType"
swPort.prop.interfaceName  = "interfaceName"

--------------------------------------------------------------------------------------
-- Enumeration for switch port property
-- @class table
-- @name swPort.propType
--
-- @field  swPort.propType.SWPORT_PROP_TYPE_STATS           =   0,
-- @field  swPort.propType.SWPORT_PROP_TYPE_LINK_STATE      =   1,
-- @field  swPort.propType.SWPORT_PROP_TYPE_PVID            =   2,
-- @field  swPort.propType.SWPORT_PROP_TYPE_PORT_MODE       =   3,
-- @field  swPort.propType.SWPORT_PROP_TYPE_TRUST_MODE      =   4,
-- @field  swPort.propType.SWPORT_PROP_TYPE_MIRROR_STATE    =   5,
-- @field  swPort.propType.SWPORT_PROP_TYPE_INTERFACE_NAME  =   6,
--

swPort.propType = {
      SWPORT_PROP_TYPE_STATS            =   0,
      SWPORT_PROP_TYPE_LINK_STATE       =   1,
      SWPORT_PROP_TYPE_PVID             =   2,
      SWPORT_PROP_TYPE_PORT_MODE        =   3,
      SWPORT_PROP_TYPE_TRUST_MODE       =   4,
      SWPORT_PROP_TYPE_MIRROR_STATE     =   5,
      SWPORT_PROP_TYPE_INTERFACE_NAME   =   6,
}

--------------------------------------------------------------------------------------
-- Enumaration for Link State
-- @class   table
-- @name    swPort.linkStates
--
-- @field   SWPORT_LINK_DOWN = 0,
-- @field   SWPORT_LINK_UP   = 1,
--

swPort.linkStates = {
    SWPORT_LINK_STATE_DOWN       =   0,
    SWPORT_LINK_STATE_UP         =   1,
}

--------------------------------------------------------------------------------
-- Enumaration for Scheduling Modes
-- @class table
-- @name  swPort.scheduling
--
-- @field   STRICT_PRIORITY = 0,
-- @field   WRR = 1,
-- @field   Q3Q2_SP_Q1Q0_WRR = 2,
-- @field   Q3_SP_Q2Q1Q0_WRR = 3,
--

swPort.scheduleMode = {
    STRICT_PRIORITY = 0,
    WRR = 1,
    Q3Q2_SP_Q1Q0_WRR = 2,
    Q3_SP_Q2Q1Q0_WRR = 3,
}
--------------------------------------------------------------------------------------
-- Enumaration for Mirror State
-- @class   table
-- @name    swPort.mirrorStates
--
-- @field   SWPORT_MIRROR_OFF    = 0,
-- @field   SWPORT_MIRROR_ON     = 1,
--

swPort.mirrorStates = {
    SWPORT_MIRROR_OFF   =   0,
    SWPORT_MIRROR_ON    =   1,
}

--------------------------------------------------------------------------------------
-- Enumaration for Port Mode
-- @class   table
-- @name    swPort.portModes
--
--
-- @field   SWPORT_PORT_MODE_UNKNOWN    =   0,
-- @field   SWPORT_PORT_MODE_ACCESS     =   1,
-- @field   SWPORT_PORT_MODE_TRUNK      =   2,
-- @field   SWPORT_PORT_MODE_HYBRID     =   3,
--

swPort.portModes = {
    SWPORT_PORT_MODE_UNKNOWN    =   0,
    SWPORT_PORT_MODE_ACCESS     =   1,
    SWPORT_PORT_MODE_TRUNK      =   2,
    SWPORT_PORT_MODE_HYBRID     =   3,
}

--------------------------------------------------------------------------------------
-- Enumaration for Trust Mode
-- @class   table
-- @name    swPort.trustModes
--
--
-- @field   SWPORT_TRUST_MODE_UNKNOWN   =   0,
-- @field   SWPORT_TRUST_MODE_8021P     =   1,
-- @field   SWPORT_TRUST_MODE_DSCP      =   2,
-- @field   SWPORT_TRUST_MODE_MAC       =   3,
-- @field   SWPORT_TRUST_MODE_PORT      =   4,
--

swPort.trustModes = {
    SWPORT_TRUST_MODE_UNKNOWN   =   0,
    SWPORT_TRUST_MODE_8021P     =   1,
    SWPORT_TRUST_MODE_DSCP      =   2,
    SWPORT_TRUST_MODE_MAC       =   3,
    SWPORT_TRUST_MODE_PORT      =   4,
}

-------------------------------------------------------------------------------
-- @name  swPort.get
--
-- @description This function gets the Switch Port properties
--
-- @param portNum   port number
-- @param property  property type
--
-- @return status   - OK or ERROR
-- @return errCode   
-- @return value    - the value of the property
--

function swPort.get (portNum, property)
    local status = "ERROR"
    local errCode = "SWMGR_ERR_INVALID_ARG"
    local value = ""

    -- Input validation 
    if (property == nil) then
        return status, errCode
    end

    property = tonumber (property)

    if (portNum == nil) then
        return status, errCode
    end

    portNum  = tonumber (portNum)

    if (property == swPort.propType.SWPORT_PROP_TYPE_STATS) then
        status, value = swMgrLib.statsGet (portNum)
        if (status == "ERROR" or value == nil) then
            errCode = "SWMGR_ERR_PORT_STATS"
            return status, errCode
        end
        
    elseif (property == swPort.propType.SWPORT_PROP_TYPE_LINK_STATE) then
        status, value = swMgrLib.linkStateGet (portNum)
        if (status == "ERROR" or value == nil or 
            (value and not swPort.isLinkStateValid (value))) then
            status  = "ERROR"
            errCode = "SWMGR_ERR_LINK_STATE"
            return status, errCode
        end

    elseif (property == swPort.propType.SWPORT_PROP_TYPE_PVID) then
        value = db.getAttribute (swMgr.SWITCHPORTTBL, 
                                 swPort.prop.portNumber,
                                 portNum, swPort.prop.pvid)
        if (value == nil or
            (value and not swVlan.isValid (value))) then
            status  = "ERROR"
            errCode = "SWMGR_ERR_PORT_PVID"
            return status, errCode
        end

    elseif (property == swPort.propType.SWPORT_PROP_TYPE_INTERFACE_NAME) then
        value = db.getAttribute (swMgr.SWITCHPORTTBL, 
                                 swPort.prop.portNumber,
                                 portNum, swPort.prop.interfaceName)
        if (value == nil) then
            status  = "ERROR"
            errCode = "SWMGR_ERR_INTERFACE_NAME"
            return status, errCode
        end


    elseif (property == swPort.propType.SWPORT_PROP_TYPE_PORT_MODE) then
        value = db.getAttribute (swMgr.SWITCHPORTTBL, 
                                 swPort.prop.portNumber,
                                 portNum, swPort.prop.portMode)
        if (value == nil) then
            status = "ERROR"
            errCode = "SWMGR_ERR_PORT_MODE"
            return status, errCode
        end

    elseif (property == swPort.propType.SWPORT_PROP_TYPE_TRUST_MODE) then
        value = db.getAttribute (swMgr.SWITCHPORTTBL, 
                                 swPort.prop.portNumber,
                                 portNum, swPort.prop.trustMode)
        if (value == nil) then
            status = "ERROR"
            errCode = "SWMGR_ERR_TRUST_MODE"
            return status, errCode
        end

    elseif (property == swPort.propType.SWPORT_PROP_TYPE_MIRROR_STATE) then
        value = db.getAttribute (swMgr.SWITCHPORTTBL, 
                                 swPort.prop.portNumber,
                                 portNum, swPort.prop.mirroring)
        if (value == nil) then
            status = "ERROR"
            errCode = "SWMGR_ERR_MIRROR_STATE"
            return status, errCode
        end

    else
        swMgr.dprintf("get: property: " .. property .. " not supported")
        return status, errCode
    end

    return "OK", "STATUS_OK", value
end

-------------------------------------------------------------------------------
-- @name  swPort.set
--
-- @description This function sets the Switch Port properties
--
-- @param portNum      port number
-- @param property  property type 
-- @param value     property value
--
-- @return status   - OK or ERROR
-- @return errCode   
--

function swPort.set (portNum, property, value)
    local status = "ERROR"
    local errCode = "SWMGR_ERR_INVALID_ARG"

    -- Input validation 
    if (portNum == nil) then
        return status, errCode
    end

    if (property == nil) then
        return status, errCode
    end


    if (value == nil) then
        return status, errCode
    end
    
    property = tonumber (property)

    if (property == swPort.propType.SWPORT_PROP_TYPE_TRUST_MODE) then
        status, errCode = swMgrLib.trustModeSet (portNum, tonumber(value))
        if (status == "ERROR") then
            return status, errCode
        end
    elseif (property == swPort.propType.SWPORT_PROP_TYPE_MIRROR_STATE) then
        status, errCode = swMgrLib.mirrorStateSet (portNum, tonumber(value))
        if (status == "ERROR") then
            return status, errCode
        end
    else
        swMgr.dprintf("set: property: " .. property .. " not supported")
        return status, errCode
    end

    return status, errCode
end


--
--
--
--  LOCAL FUNCTIONS
--
--

--[[
*******************************************************************************
-- @name swPort.isLinkStateValid
--
-- @description This function will check whether the given Link State is valid
--
-- @param linkState
--
-- @return true/false
--
--]]

function swPort.isLinkStateValid (linkState)
    local linkStatus = tonumber (linkState)

    if (linkStatus ==  SWPORT_LINK_DOWN or linkStatus == SWPORT_LINK_UP) then 
        return true
    else
        return false
    end
end

--[[
*********************************************************************************
-- @name swPort.isValid
--
-- @description This function will check whether the given port is valid
--
-- @param name device name
-- @param port port number
--
-- @return true or false
-- ]]

function swPort.isValid (name, port)
    local where = string.format ([[switchName = '%s' and portNumber = %d]], name, port)

    if db.existsRowWhere (swPort.SWITCHPORTTBL, where) then 
        return true
    else
        return false
    end
end

--[[ 
---------------------------------------------------------------------------------
-- @name swPort.queueScheduling.get 
--
--
-- @description This function get the queue scheduling mode for a port
--
-- @param switchName  Switch Name
-- @param portNum   port number (ignore this to get it for all the ports)
--
-- @return status   OK for Success ERROR for Failure
-- @return errCode  Error Code in Failure case
-- @return cfg      queue scheduling information containing following details.
--                  <li>
--                  <ul>scheduleMode</ul>   -- Strict Priority / Weighted Round
--                                          -- Robin / Mixed
--                  <ul>queue1Weight<ul>    -- Weight of Queue1                                      
--                  <ul>queue2Weight<ul>    -- Weight of Queue2                                      
--                  <ul>queue3Weight<ul>    -- Weight of Queue3                                      
--                  <ul>queue4Weight<ul>    -- Weight of Queue4                                      
--                  </li>
-- @seealso swPort.queueScheduling.set()                 
--]]

function swPort.queueScheduling.get (switchName, portNum)
    local status
    local errCode
    local customQuery
    local index = 1
    local cfg = {}
   
    if (switchName == nil) then
        swMgr.dprintf ("queueScheduling.get: Invalid switch name")
        return "ERROR", "SWMGR_ERR_INVALID_ARG"
    end

    customQuery = "select * from " .. swMgr.SWITCHPORTTBL .." where " .. swPort.prop.switchName .. " = '" .. switchName .. "'"

    if (portNum ~= nil) then
        customQuery = customQuery .. " and " .. swPort.prop.portNumber .. " = '" .. portNum .."'" 
    end

    rows = db.getTable (swMgr.SWITCHPORTTBL, false, customQuery)
    if (rows == nil) then
        swMgr.dprintf ("queueScheduling.get: Failed to get the values from DB table")
        return "ERROR", "SWMGR_ERR_QUEUE_CFG_GET"
    end

    for k,v in pairs(rows) do
        cfg[index] = {}
        cfg[index]["scheduleMode"]      = v["schedMode"]
        cfg[index]["queue1Weight"]      = v["queue1Weight"]
        cfg[index]["queue2Weight"]      = v["queue2Weight"]
        cfg[index]["queue3Weight"]      = v["queue3Weight"]
        cfg[index]["queue4Weight"]      = v["queue4Weight"]
        index = index + 1
    end

    return "OK", "STATUS_OK", cfg
end

--[[ 
---------------------------------------------------------------------------------
-- @name swPort.queueScheduling.set 
--
-- @description This function set the queue scheduling mode for a port
--
-- @param switchName switch Name
-- @param cfg       queue scheduling information containing following details.
--                  <ul>scheduleMode</ul>   -- Strict Priority / Weighted Round
--                                          -- Robin / Mixed
--                  <ul>queue1Weight<ul>    -- Weight of Queue1                 
--                  <ul>queue2Weight<ul>    -- Weight of Queue2                 
--                  <ul>queue3Weight<ul>    -- Weight of Queue3                 
--                  <ul>queue4Weight<ul>    -- Weight of Queue4                 
-- @param portNum   port number (ignore this to set it for all the ports)
--
-- @return status   OK for Success ERROR for Failure
-- @return errCode  Error Code in Failure case
--
-- @seealso swPort.queueScheduling.get()                 
--]]

function swPort.queueScheduling.set (switchName, portNum, cfg)
    local status
    local errCode
    local customQuery
    local index = 0
   
    if (cfg == nil or type(cfg) ~= "table" or switchName == nil) then
        swMgr.dprintf ("queueScheduling.set: Invalid configuration")
        return "ERROR", "SWMGR_ERR_INVALID_ARG"
    end
    
    if (portNum == false) then 
        portNum = -1
    end

    cfg["portNum"] = portNum
    status, errCode = swMgrLib.queueSchedulingSet(switchName, cfg)
    if (tonumber(status) < 0 ) then
        swMgr.dprintf ("queueScheduling.set: Failed to configure scheduling mode in switch")
        return status, errCode
    end

    customQuery = "update swPortConfig set schedMode = '".. cfg.scheduleMode .."', queue1Weight = '" .. cfg.queue1Weight .. "', queue2Weight = '" .. cfg.queue2Weight .. "', queue3Weight = '" .. cfg.queue3Weight .. "', queue4Weight = '" .. cfg.queue4Weight .. "'"

    db.execute (customQuery)
    
    return "OK", "STATUS_OK"
end

