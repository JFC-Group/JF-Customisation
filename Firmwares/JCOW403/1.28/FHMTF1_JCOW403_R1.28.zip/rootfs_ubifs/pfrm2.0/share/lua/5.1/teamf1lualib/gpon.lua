--[[
#### Copyright (c) 2014, TeamF1, Inc
#### www.TeamF1.com
#### Jan11, 2012
#### Description: GPON mgmt

#### Revisions: None
]]--
require "teamf1lualib/db"
require "teamf1lualib/util"
require("teamf1lualib/LuaXml")

defaultWANIF = "bdg1"
eogreWANIF = "bdg10"
ponIF = "veip0"
ethWANIF = "eth1"
aeWANIF = "eth4"

gpon = {}
--[[
*******************************************************************************
-- @name gpon.config
--
-- @description 
--
-- @param conf
-- @param rowid
-- @param operation
--
-- @return 
--]]

function gpon.config (conf, rowid, operation)

    if (operation == "add") then
        return db.insert("gpon", conf)
    elseif (operation == "edit") then
        return db.update("gpon", conf, rowid)
    elseif (operation == "delete") then
        return db.delete("gpon", conf)
    end

end

function gpon.get ()

    local gponRow = db.getRow ("gpon", "_ROWID_", "1")

    local jioPrivateNetSupport = "0"
    jioPrivateNetSupport = db.getAttribute ("Eogre", "_ROWID_", 1, "jioPrivateNet")
    --jioPrivateNetSupport = db.getAttribute ("environment", "name", "JIO_PRIVATE_NET" ,"value")
    if (jioPrivateNetSupport == "1") then
        local eogregponRow = db.getRow ("gpon", "_ROWID_", "2")
        if(eogregponRow and eogregponRow["gpon.vlanID"] ~= nil) then
            gponRow["gpon.wifiVlanID"] = eogregponRow["gpon.vlanID"]
        end
    end

    gponRow["gpon.enableDisableSerialNumber"] = "0"
    gponRow["gpon.ponPasswd"] = ""
    gponRow["gpon.serial"] = ""
    
    return gponRow

end

function gpon.configure (inputTable, rowid, operation)
	
    local gponRowOld = {}

	if (util.fileExists ("/pfrm2.0/ae_wan_type")) then
		ponIF = aeWANIF
	end
    if (operation == "edit") then
        gponRowOld = db.getRow ("gpon","_ROWID_","1")
    end

    gpon.config (inputTable, rowid, operation)

    if (operation == "edit") then

        if (inputTable ["gpon.status"] == "1") then
            --remove ethernet wan from bridge
            os.execute("/usr/sbin/brctl delif ".. defaultWANIF .." "..ethWANIF)
            -- update bridge interface for bridge mdoe support
            db.setAttribute ("bridgeMode", "_ROWID_","1","wanIface",defaultWANIF)

            -- if vlan is enabled on pon0 add pon0.X into bdg1
            if (inputTable ["gpon.vlanStatus"] == "1") then
                os.execute ("/sbin/vconfig add ".. ponIF .."."..inputTable ["gpon.vlanID"]..";/sbin/ifconfig "..ponIF.."."..inputTable ["gpon.vlanID"].." up")
                os.execute("/usr/sbin/brctl addif " .. defaultWANIF .." "..ponIF.."."..inputTable ["gpon.vlanID"])
                if (gponRowOld ["gpon.vlanID"] ~= inputTable ["gpon.vlanID"]) then
                    os.execute ("/sbin/vconfig rem "..ponIF.."."..gponRowOld["gpon.vlanID"])		
                end
                if (inputTable ["gpon.vlanPriority"] ~= nil) then
                    os.execute("sbin/vconfig set_egress_map "..ponIF.."."..inputTable ["gpon.vlanID"].." 0 "..inputTable ["gpon.vlanPriority"])
                end

                if (gponRowOld ["gpon.vlanStatus"] == "0") then
                    -- this is case of non vlan gpon to vlan gpon, so switch WAN from pon0 to bdg1
                    db.setAttribute ("networkInterface", "LogicalIfName","IF1","interfaceName",defaultWANIF)
                    db.setAttribute ("ethernet", "LogicalIfName","IF1","interfaceName",ethWANIF)
                    db.setAttribute ("networkInterface", "LogicalIfName","IF1","interfaceName",defaultWANIF)
                end

                -- Set trunk mode on for WAN for VLAN on WAN for GPON
                db.setAttribute ("ethernet", "LogicalIfName","IF1","trunkPort","1")
                db.setAttribute ("ethernet", "LogicalIfName","IF1","interfaceName",defaultWANIF)
            else
                -- this is case of vlan gpon to non vlan gpon, so remove pon0.X
                if (gponRowOld ["gpon.vlanStatus"] == "1") then
                    os.execute ("/sbin/vconfig rem "..ponIF.."."..gponRowOld["gpon.vlanID"])
                end

                -- Set trunk mode to oFF on for WAN for VLAN on WAN for GPON
                db.setAttribute ("ethernet", "LogicalIfName","IF1","trunkPort","0")

                -- wan has to shift from bdg1 to pon0 
                db.setAttribute ("networkInterface", "LogicalIfName","IF1","interfaceName",defaultWANIF)
                db.setAttribute ("ethernet", "LogicalIfName","IF1","interfaceName",defaultWANIF)
                db.setAttribute ("networkInterface", "LogicalIfName","IF1","interfaceName",defaultWANIF)
            end

            local ethernetvlanRows = db.getRows ("ethernetVLAN", "LogicalIfName", "IF1")
            for k,v in pairs (ethernetvlanRows) do
                db.setAttribute("bridgePorts", "interfaceName", ethWANIF.."."..v["ethernetVLAN.vlanId"], "interfaceName", ponIF.."."..v["ethernetVLAN.vlanId"])
            end
            --db.setAttribute ("tcpdump", "interfaceName",defaultWANIF,"phyInterface",ponIF)
        else
            if (operation == "edit") then
                -- update bridge interface for bridge mdoe support
                db.setAttribute ("bridgeMode", "_ROWID_","1","wanIface",ethWANIF)
                db.setAttribute ("ethernet", "LogicalIfName","IF1","interfaceName",ethWANIF)

                local gponRow = db.getRow ("gpon","_ROWID_","1")
                if (gponRow ["gpon.vlanStatus"] == "1" ) then
                    -- remove the pon0 vlan interface
                    os.execute ("/sbin/vconfig rem "..ponIF.."."..gponRow["gpon.vlanID"])
                else
                    -- shift WAn from pon0 to bdg1
                    db.setAttribute ("networkInterface", "LogicalIfName","IF1","interfaceName",defaultWANIF)
                    db.setAttribute ("ethernet", "LogicalIfName","IF1","interfaceName",ethWANIF)
                    db.setAttribute ("networkInterface", "LogicalIfName","IF1","interfaceName",defaultWANIF)
                end
                -- add back eth1 to bridge
                os.execute("/usr/sbin/brctl addif ".. defaultWANIF .." "..ethWANIF)
            end
            local ethernetvlanRows = db.getRows ("ethernetVLAN", "LogicalIfName", "IF1")
            for k,v in pairs (ethernetvlanRows) do
                db.setAttribute("bridgePorts", "interfaceName", ponIF.."."..v["ethernetVLAN.vlanId"], "interfaceName", ethWANIF.."."..v["ethernetVLAN.vlanId"])
            end
            --db.setAttribute ("tcpdump", "interfaceName",defaultWANIF,"phyInterface",ethWANIF)		
        end
    end

    return true

end

function gpon.eogreWanconfigure (inputTable, rowid, operation)
	
    local gponRowOld = {}
    if (operation == "edit") then
        gponRowOld = db.getRow ("gpon","_ROWID_","2")
    end

    gpon.config (inputTable, rowid, operation)

    if (operation == "edit") then
        local wanVLANScript = "/pfrm2.0/bin/vlanUpdateWAN.sh"
		if (util.fileExists ("/pfrm2.0/ae_wan_type")) then
			wanVLANScript = "/pfrm2.0/bin/vlanUpdate_AE_WAN.sh"
			ponIF = aeWANIF
		end
        if (inputTable ["gpon.status"] == "1") then
            -- if vlan is enabled on pon0 add pon0.X into bdg1
            if (inputTable ["gpon.vlanStatus"] == "1") then
                local cmd = wanVLANScript .. " ADD " ..  inputTable ["gpon.vlanID"] .." 1 "
                os.execute (cmd)
                -- gpon is up and we have executed the vlan add script
                os.execute ("/bin/sleep 5")
                os.execute ("/sbin/ifconfig  " .. eogreWANIF .. " down")
                os.execute ("/sbin/ifconfig  " .. eogreWANIF .. " up")

                if (gponRowOld ["gpon.vlanStatus"] == "0") then
                    -- this is case of non vlan gpon to vlan gpon, so switch WAN from pon0 to bdg1
                    db.setAttribute ("networkInterface", "LogicalIfName","IF10","interfaceName",eogreWANIF)
                    db.setAttribute ("networkInterface", "LogicalIfName","IF10","interfaceName",eogreWANIF)
                end
            else
                local cmd = wanVLANScript .. " DEL " ..  inputTable ["gpon.vlanID"]
                os.execute (cmd)
                os.execute ("/bin/sleep 2")
                os.execute ("/sbin/ifconfig " .. eogreWANIF .. " down")
                -- wan has to shift from bdg1 to pon0 
            end
            db.setAttribute ("tcpdump", "interfaceName",eogreWANIF,"phyInterface",ponIF)
        else
            if (operation == "edit") then
                local gponRow = db.getRow ("gpon","_ROWID_","2")
                if (gponRow ["gpon.vlanStatus"] == "1" ) then
                    -- remove the pon0 vlan interface
                    local cmd = wanVLANScript .. " DEL " ..  gponRow ["gpon.vlanID"]
                    os.execute (cmd)
                    os.execute ("/bin/sleep 2")
                    os.execute ("/sbin/ifconfig " .. eogreWANIF .. " down")
                else
                    -- shift WAn from pon0 to bdg1
                    db.setAttribute ("networkInterface", "LogicalIfName","IF10","interfaceName",eogreWANIF)
                    db.setAttribute ("networkInterface", "LogicalIfName","IF10","interfaceName",eogreWANIF)
                end
            end
            db.setAttribute ("tcpdump", "interfaceName",eogreWANIF,"phyInterface",ethWANIF)		
        end
    end

    return true

end

-------------------------------------------------------------------------------
-- @name gpon.import
--
-- @description This function  imports gpon configuration.
--
-- @param conftable gpon configuration
--

function gpon.import (inputTable, defaultCfg, remCfg)
    if (inputTable == nil) then
        inputTable = defaultCfg
    end

   --initializing a temp table
    local configTable = {}

    configTable = config.update (inputTable, defaultCfg, remCfg)
   
    if (configTable ~= nil and #configTable ~= 0) then
        for i,v in ipairs (configTable) do
            v = util.addPrefix (v, "gpon.");
            local valid, errstr, rowid = gpon.configure (v, -1, "add")
        end
    end
end

-------------------------------------------------------------------------------
-- @name gpon.export
--
-- @description This function exports gpon configuration
--
-- @return gpon configuration
--

function gpon.export ()
	return db.getTable ("gpon", false)
end

--
--
--      INTERNAL FUNCTIONS
--
--

require "teamf1lualib/config"
if (config.register) then
   config.register("gpon", gpon.import, gpon.export, "1")
end
