
require "teamf1lualib/db"

db.connect ("/tmp/system.db")

maptPortStats = {}
-------------------------------------------------------------------------
-- @name maptPortStats.updateMaptPortStats
--
-- @description 
--
-- @param conf
--                  
-- @return 
--
function maptPortStats.updateMaptPortStats (port, action, protocol)

    local row =  db.getRowWhere ("maptPortStats", "portNumber = " .. port, true)

    if (row == nil) then
        return false
    end

    os.execute ("echo " .. row["maptPortStats.portNumber"] .. " >> /tmp/dummies")

    row ["maptPortStats.inUse"] = action

    if (action == 1) then
        row["maptPortStats.count"] = row["maptPortStats.count"] + 1
        row["maptPortStats.timeStart"] = os.time ()
    else
        row["maptPortStats.timeEnd"] = os.time ()
        row["maptPortStats.totalTime"] = row["maptPortStats.totalTime"] + (row["maptPortStats.timeEnd"] - row["maptPortStats.timeStart"])
        if (row["maptPortStats.count"] ~= 0) then
            row["maptPortStats.averageUsage"] = row["maptPortStats.totalTime"]/row["maptPortStats.count"]
        else
            row["maptPortStats.averageUsage"] = 0
        end
    end

    local valid,errstr = db.update("maptPortStats", row, row["maptPortStats._ROWID_"])

    return valid
end
