#!/pfrm2.0/bin/lua 

--[[
####File: fwRuleScript.lua

Copyright (c) 2014, TeamF1 Networks Pvt. Ltd.
(Subsidiary of D-Link India)

modification history
--------------------
01a, 24sep14, mmk written.

DESCRIPTION - This script will be called if any of the component(Content Filtering, MAC filtering, Captive Portal, P2P Filtering, dashboard and QoS) is enable or disable.

This script will get the status of all the components mentioned above and if any of the component is enable, script will delete all the RETURN rules from PREROUTING, FORWARD and POSTROUTING of mangle table and ACCEPT rule in fwCustomRuleSkip chain inFILTER table FORWARD chain added to get max performance and if all the components are disable then it will add the rules.
#### Revisions:
None
]]--


--************* Requires *************
require "teamf1lualib/util"
require "teamf1lualib/db"

--************* Initial Code *************

--************* Logic *************
local dbFilename = "/tmp/system.db"

db.connect(dbFilename)

local ContentFilterRow      = {}
local macFilterConfigRow    = {}
local CaptivePortalRow      = {}
local p2pSesLimitRow        = {}
local qosQueueManagementRow = {}
local BwMonRow              = {}

--To get the status of all the component
BwMonRow                = db.getRow("BwMon", "_ROWID_", "1")
ContentFilterRow        = db.getRow("ContentFiltering", "_ROWID_", "1")
macFilterConfigRow      = db.getRow("macFilterConfig", "_ROWID_", "1")
p2pSesLimitRow          = db.getRow("p2pSessionLimit", "_ROWID_", "1")
captivePortalRow        = db.getRow("CaptivePortal", "_ROWID_", "1")
qosQueueManagementRow   = db.getRow("qosQueueManagement", "_ROWID_", "1")

-- if any of the component is enable then Delete the Firewall Rules
if ((tonumber(ContentFilterRow["ContentFiltering.Status"]) + tonumber(macFilterConfigRow["macFilterConfig.MACFilteringStatus"]) + tonumber(p2pSesLimitRow["p2pSessionLimit.p2pSessionLimitStatus"]) + tonumber(captivePortalRow["CaptivePortal.enable"]) +tonumber(qosQueueManagementRow["qosQueueManagement.Enable"]) + tonumber(BwMonRow["BwMon.enable"]))== 1) then
-- Deleting Firewall Rules
    os.execute("/pfrm2.0/bin/fwRulesScript.sh 0 &")
-- if all the component are disable then Add the Firewall Rules
elseif((tonumber(ContentFilterRow["ContentFiltering.Status"]) + tonumber(macFilterConfigRow["macFilterConfig.MACFilteringStatus"]) + tonumber(p2pSesLimitRow["p2pSessionLimit.p2pSessionLimitStatus"]) + tonumber(captivePortalRow["CaptivePortal.enable"]) + tonumber(qosQueueManagementRow["qosQueueManagement.Enable"]) + tonumber(BwMonRow["BwMon.enable"])) == 0) then
    os.execute("/pfrm2.0/bin/fwRulesScript.sh 1 &")
end

