-- locals
local DEVICE_SERIAL_FILE = "/tmp/deviceSerial"
local DEVICE_PRODUCT_CLASS_FILE = "/tmp/cpe3/dps.productclass"

-- if not allowed to edit
if (ACCESS_LEVEL ~= 0) then
	errorFlag, statusMessage = -1, "Administrator Privileges Are Required"
	Page = "backupRestore"
	web.goToPage(Page, true, true)
else
	-- export current db state to flash
	db.save2 ()
	local filename = ""
	local deviceSerial = "DEFAULT_SN"
	local modelName = "DEFAULT_MODEL_NAME"
	if util.fileExists (DEVICE_SERIAL_FILE) then
		deviceSerial = util.fileToString(DEVICE_SERIAL_FILE)
	end

	if util.fileExists (DEVICE_PRODUCT_CLASS_FILE) then
		modelName = util.fileToString(DEVICE_PRODUCT_CLASS_FILE)
	end

	filename = deviceSerial.."_"..modelName

	if util.fileExists ("/flash/teamf1.cfg.ascii") then
		configFile = "/flash/teamf1.cfg.ascii"
	else
		configFile = "/pfrm2.0/etc/teamf1.cfg.defaults.ascii"
	end

    local tmpConfigFile = "/tmp/teamf1.cfg.ascii"
    if (util.fileExists ("/pfrm2.0/BRCMJCO300") or util.fileExists ("/pfrm2.0/HW_JCO410") or util.fileExists ("/pfrm2.0/HW_JCE410")) then
        if util.fileExists ("/flash/dms_xml/access_conf.xml") then
		dmsConfigFile = "/flash/dms_xml/access_conf.xml"
	else
		dmsConfigFile = "/pfrm2.0/etc/dms_xml/access_conf.xml"
	end

    if util.fileExists ("/flash/dms_xml/dms_descr.xml") then
		dmsConfigFile1 = "/flash/dms_xml/dms_descr.xml"
	else
		dmsConfigFile1 = "/pfrm2.0/etc/dms_xml/dms_descr.xml"
	end
    	
		-- before appending , remove exsisting file
		os.execute("/bin/rm -f "..tmpConfigFile)

        local appendCmd = "/bin/cat " .. configFile .. " " .. dmsConfigFile ..  " " .. dmsConfigFile1 .. " >> " .. tmpConfigFile
        os.execute(appendCmd)
    end

    local tmpConfigFile_ECONET = "/tmp/teamf1.cfg.ascii_ECONET"
    if (util.fileExists ("/pfrm2.0/ECONET") and (not(util.fileExists ("/pfrm2.0/HW_NO_WIFI")))) then
        if util.fileExists ("/flash/smartcable/config/sc.cnf") then
		    smartHomeConfigFile = "/flash/smartcable/config/sc.cnf"
	    end
        if util.fileExists ("/flash/dms_xml/access_conf.xml") then
		    dmsConfigFile2 = "/flash/dms_xml/access_conf.xml"
    	else
	    	dmsConfigFile2 = "/pfrm2.0/etc/dms_xml/access_conf.xml"            
        end    

        if util.fileExists ("/flash/dms_xml/dms_descr.xml") then
		    dmsConfigFile3 = "/flash/dms_xml/dms_descr.xml"
	    else
		    dmsConfigFile3 = "/pfrm2.0/etc/dms_xml/dms_descr.xml"
    	end            
		-- before appending , remove exsisting file
		os.execute("/bin/rm -f "..tmpConfigFile_ECONET)
 
        local appendCmd = "/bin/cat " .. configFile .. " " .. smartHomeConfigFile .. " " .. dmsConfigFile2 .. " " .. dmsConfigFile3 .. " >> " .. tmpConfigFile_ECONET
        os.execute(appendCmd)
    end

    
    -- Encrypting conf file
    require "kliteLib"
    local encKey="/pfrm2.0/etc/server.key"
    local outFile="/flash/" .. filename .. ".enc"

    if ((util.fileExists ("/pfrm2.0/BRCMJCO300")  or util.fileExists ("/pfrm2.0/HW_JCO410") or util.fileExists ("/pfrm2.0/HW_JCE410")) and (not(util.fileExists ("/pfrm2.0/HW_NO_DMS")))) then
        kliteLib.openssl ("enc", "-aes-128-cbc", "-pass", "file:" .. encKey, "-in", tmpConfigFile, "-out", outFile)
    elseif (util.fileExists ("/pfrm2.0/ECONET") and (not(util.fileExists ("/pfrm2.0/HW_NO_WIFI")))) then
        kliteLib.openssl ("enc", "-aes-128-cbc", "-pass", "file:" .. encKey, "-in", tmpConfigFile_ECONET, "-out", outFile)
    else
        kliteLib.openssl ("enc", "-aes-128-cbc", "-pass", "file:" .. encKey, "-in", configFile, "-out", outFile)
    end

	web.download(outFile, filename .. ".enc")
end
