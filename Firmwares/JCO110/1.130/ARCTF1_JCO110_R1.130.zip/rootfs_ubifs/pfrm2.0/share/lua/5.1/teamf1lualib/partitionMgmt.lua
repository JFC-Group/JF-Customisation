-- partitionMgmt.lua
-- Copyright (c) 2010 TeamF1, Inc.
-- All rights reserved. 
--
-- Modification History
-- --------------------
-- 01c,30apr10,pnm  adding printer support
-- 01b,31mar10,pnm  adding support for exporting/importing config to partition
-- 01a,25mar10,pnm  written
--
-- Description
-- Disk management component core routines and API
--

--********************** Requires **************************
require "partitionMgmtLib"
require "teamf1lualib/util"

--********************** Packages ***************************
partitionMgmt = {}

--*****************************************************************************
--partitionMgmt.createPartition - create partition.
--
--This routine calls appropriate routines to create partition, given the
--partition related info provided by the user.
--
--RETURN: status and status string
function partitionMgmt.createPartition (partitionInfoTbl)
    -- Local Variables
    local status
    local statusStr
    local statusCode

    -- Check for permission
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- Check if the DB file is defined.
    if (DB_FILE_NAME == nil) then
        return "ERROR", "SYSTEM_ERROR"
    end

    -- Verify the input
    status, statusStr = partitionMgmt.verifyPartCreateData (partitionInfoTbl)
    if (status == "ERROR") then
        return status, statusStr
    end

    -- Need to verify MAX partitions after verifying the input as the disk ID
    -- has to be correct. For invalid disk Id, MAX Partition check might fail.
    status, statusStr = partitionMgmt.verifyMaxPartition ( 
                            partitionInfoTbl["partCreateInfo.diskId"])
    if (status == "ERROR") then
        return status, statusStr
    end

    -- Update some of the entries in the table
    partitionInfoTbl = partitionMgmt.modifyPartitionCreateInput(
                            partitionInfoTbl)

    -- We have verified as much info as we can here. Next set of verification
    -- will be done by the routine being called
    statusCode, partId = partitionMgmtLib.createPartition (DB_FILE_NAME,
                                partitionInfoTbl["partCreateInfo.diskId"],
                                partitionInfoTbl["partCreateInfo.size"],
                                partitionInfoTbl["partCreateInfo.sizeUnit"],
                                partitionInfoTbl["partCreateInfo.startAddr"],
                                partitionInfoTbl["partCreateInfo.addrUnit"],
                                partitionInfoTbl["partCreateInfo.fsType"],
                                partitionInfoTbl["partCreateInfo.partType"],
                                partitionInfoTbl["partCreateInfo.name"])
    statusStr = partitionMgmt.mapCode2String (statusCode)
    if (statusStr == "STATUS_OK") then
        return "OK", "STATUS_OK", partId
    end

    return "ERROR", statusStr, partId
end

--*****************************************************************************
--partitionMgmt.verifyPartCreateData - verifies info provided for create part
--
--This routine verifies as many parameters it can for the partition create
--operation.
--
--RETURN: status and status string
function partitionMgmt.verifyPartCreateData (partitionInfoTbl)

	-- check for arguments 
	if ((partitionInfoTbl["partCreateInfo.fsType"] == nil)) then
        return "ERROR", "PARTITION_MGMT_FS_FORMAT_NOT_SUPPORTED"
	end

    if (db.getRow ("diskMgmtPartitionFSFormat", "fsFormat",
        string.lower (partitionInfoTbl["partCreateInfo.fsType"])) == nil) then
        return "ERROR", "PARTITION_MGMT_FS_FORMAT_NOT_SUPPORTED"
    end

	-- check for arguments 
	if ((partitionInfoTbl["partCreateInfo.sizeUnit"] == nil) or 
		(partitionInfoTbl["partCreateInfo.addrUnit"] == nil)) then
        return "ERROR", "PARTITION_MGMT_INVALID_UNIT"   
	end

    -- Verify that the unit value provided has only 2 letters only. The
    -- backend expects two letters only and will not be able to deal with one
    -- letter.
    if ((string.len (partitionInfoTbl["partCreateInfo.sizeUnit"]) ~= 2) or
        string.len (partitionInfoTbl["partCreateInfo.addrUnit"]) ~= 2) then
        return "ERROR", "PARTITION_MGMT_INVALID_UNIT"   
    end

    -- Verify that the disk ID  provided is correct
    if (db.getRow ("diskMgmtVolume", "deviceId",
        partitionInfoTbl["partCreateInfo.diskId"]) == nil) then
        return "ERROR", "PARTITION_MGMT_INVALID_DISK_ID"
    end

    -- Verify the length of the partition name
    if (util.verifyLength (partitionInfoTbl ["partCreateInfo.name"], 1, 32) ==
                false) then
        return "ERROR", "PARTITION_MGMT_INVALID_NAME_LENGTH"
    end

    -- Verify the characters in the name
    if (string.match (partitionInfoTbl["partCreateInfo.name"],
        "^[0-9a-zA-Z\-_]+$") == nil) then
        return "ERROR", "PARTITION_MGMT_INVALID_NAME"
    end

    return "OK", "STATUS_OK"
end

--*****************************************************************************
--partitionMgmt.verifyMaxPartition - verify that MAX partitions supported
--
--This routine will check if the MAX supported partitions have reached. If so,
--it will report error to the user.
--
--RETURNS: status and statusStr
function partitionMgmt.verifyMaxPartition (diskId)
    -- Get MAX number of partitions supported.
    local maxPartitions = tonumber (db.getAttribute ("environment", "name",
    "MAX_PARTITIONS", "value"))

    -- If the environment variable is not set, SYSTEM ERROR is returned. To
    -- avoid this error message, please set environment table with
    -- MAX_PARTITIONS entry.
    if (maxPartitions == nil) then
        return "ERROR","SYSTEM_ERROR"
    end

    -- We now have the MAX Partition values, let us see if there are already
    -- MAX number of entries in the database for the given disk ID.
    
    -- Get the number of partitions for given table.
    local diskPartTbl = db.getRows ("diskMgmtPartition", "diskId", diskId)
    local numPartition = util.tableSize (diskPartTbl)
    if ((numPartition ~= nil) and (numPartition >= maxPartitions)) then
        return "ERROR", "PARTITION_MGMT_MAX_PARTITION"
    end

    -- Return OK from the function
    return "OK", "STATUS_OK"
end

--*****************************************************************************
--partitionMgmt.mapCode2String - maps code to string.
--
--This routine maps the code to string given the code.
--
--RETURNS: status string
function partitionMgmt.mapCode2String (code)
    -- check if code has some value
    if (code == nil) then
        util.appendDebugOut ("Code value provided is nil<br>")
        return "PARTITION_MGMT_CREATE_PARTITION_FAILED"
    end

    -- This table contains string to be returned from the function. The table
    -- form is {code=<code value>, str=<string value>}
    local codeMapTbl = 
    {
        {code = 0, str = "STATUS_OK"},
        {code = 1, str = "PARTITION_MGMT_INVALID_UNIT_CODE"},
        {code = 2, str = "PARTITION_MGMT_UNIT_CODE_OUTOF_RANGE"},
        {code = 3, str = "PARTITION_MGMT_INVALID_UNIT"},
        {code = 4, str = "SYSTEM_ERROR"},
        {code = 5, str = "PARTITION_MGMT_INVALID_DISK_ID"},
        {code = 6, str = "PARTITION_MGMT_INVALID_SIZE"},
        {code = 7, str = "PARTITION_MGMT_INVALID_PART_TYPE"},
        {code = 8, str = "PARTITION_MGMT_SIZE_N_ADDR_SAME"},
        {code = 9, str = "PARTITION_MGMT_FAILED_TO_CREATE_CMD"},
        {code = 10, str = "PARTITION_MGMT_FAILED_TO_GET_PARTINFO"},
        {code = 11, str = "PARTITION_MGMT_FAILED_TO_CMD"},
        {code = 12, str = "PARTITION_MGMT_FAILED_TO_GET_PARTINFO"},
        {code = 13, str = "PARTITION_MGMT_PART_INFO_UPDATE_FAILED"},
        {code = 14, str = "PARTITION_MGMT_FAILED_TO_GET_DISK_ID"},
        {code = 15, str = "PARTITION_MGMT_INVALID_PART_ID"},
        {code = 16, str = "PARTITION_MGMT_PART_BEING_USED"},
        {code = 17, str = "PARTITION_MGMT_PART_DELETE_FAILED"},
        {code = 18, str = "PARTITION_MGMT_PART_FORMAT_FAILED"},
        {code = 19, str = "PARTITION_MGMT_FAILED_TO_GET_UNALLOC_LIST"}
    }

    -- iterate through the table and get string for given code
    local statusStr = nil
    for i,v in ipairs (codeMapTbl) do
        if (code == v["code"]) then
            statusStr = v["str"]
            break;
        end
    end

    -- Check if the code did not match found
    if (statusStr == nil) then
        util.appendDebugOut ("Code "..code .. " not found in the table <br>")
        return "PARTITION_MGMT_CREATE_PARTITION_FAILED"
    end

    return statusStr
end

--*****************************************************************************
--partitionMgmt.modifyPartitionCreateInput - modifies some of the fields
--
--This routine modifies some of input fields to partition create function.
--This is necessary to ensure backend doesn't have any issue with input data
--provided.
--
--RETURN: updated table
function partitionMgmt.modifyPartitionCreateInput (tbl)
    -- check the value of startAddr
    if (tbl["partCreateInfo.startAddr"] == 0) then
        tbl["partCreateInfo.startAddr"] = tbl["partCreateInfo.sizeUnit"]
    end

    -- Change the unit to upper case letters
    tbl["partCreateInfo.sizeUnit"] = string.upper (
                        tbl["partCreateInfo.sizeUnit"])
    tbl["partCreateInfo.addrUnit"] = string.upper ( 
                        tbl["partCreateInfo.addrUnit"])

    -- Convert the FS type to lower case letters
    tbl["partCreateInfo.fsType"] = string.lower (
                        tbl["partCreateInfo.fsType"])

    -- Convert the partition type to lower case letters
    if (tbl["partCreateInfo.partType"] ~= nil) then
        tbl["partCreateInfo.partType"] = string.lower (
                    tbl["partCreateInfo.partType"])
    end

    -- return the updated table
    return tbl
end

--*****************************************************************************
--partitionMgmt.verifyDeletePartInput - verifies the delete partition input
--
--This routine verifies the delete partition input values are valid.
--RETURN: status and statusStr
function partitionMgmt.verifyDeletePartInput (partId)
    -- Verify the partition Id
    if (db.getRow ("diskMgmtPartition", "partId", partId)
        == nil) then
        return "ERROR","PARTITION_MGMT_INVALID_PART_ID"
    end

    return "OK", "STATUS_OK"
end

--*****************************************************************************
--partitionMgmt.deletePartition - deletes the given partition
--
--This routine calls appropriate routine to delete a partition given the
--partition ID.
--
--RETURN: status and statusStr
function partitionMgmt.deletePartition (tbl)
    -- Check if the DB file is defined.
    if (DB_FILE_NAME == nil) then
        return "ERROR", "SYSTEM_ERROR"
    end

    util.appendDebugOut (util.tableToStringRec (tbl, 1))
    local status
    local statusStr
    for i,v in pairs (tbl) do
        util.appendDebugOut ("Processing ... " .. v["partId"] .. "<br>")
        -- Verify the input
        status, statusStr = partitionMgmt.verifyDeletePartInput (v["partId"])
        if (status == "ERROR") then
            return status, statusStr
        end

        -- Call function to delete the partition
        local statusCode = partitionMgmtLib.deletePartition (DB_FILE_NAME,
        v["partId"])

        statusStr = partitionMgmt.mapCode2String (statusCode)
        if (statusStr ~= "STATUS_OK") then
            return "ERROR", statusStr
        end
    end

    return "OK", "STATUS_OK"
end

--*****************************************************************************
--partitionMgmt.verifyFormatPartInput - verifies the delete partition input
--
--This routine verifies the delete partition input values are valid.
--RETURN: status and statusStr
function partitionMgmt.verifyFormatPartInput (partId, fsType)
    -- Verify the partition Id
    if (db.getRow ("diskMgmtPartition", "partId", partId)
        == nil) then
        return "ERROR","PARTITION_MGMT_INVALID_PART_ID"
    end

    -- Verify the FS type
    if (db.getRow ("diskMgmtPartitionFSFormat", "fsFormat",
        string.lower (fsType)) == nil) then
        return "ERROR", "PARTITION_MGMT_FS_FORMAT_NOT_SUPPORTED"
    end
    return "OK", "STATUS_OK"
end

--*****************************************************************************
--partitionMgmt.formatPartition - formats the given partition
--
--This routine calls appropriate routine to delete a partition given the
--partition ID.
--
--RETURN: status and statusStr
function partitionMgmt.formatPartition (partId, fsType)
    -- Check if the DB file is defined.
    if (DB_FILE_NAME == nil) then
        return "ERROR", "SYSTEM_ERROR"
    end
    
    -- Verify the input
    local status
    local statusStr
    status, statusStr = partitionMgmt.verifyFormatPartInput (partId, fsType)
    if (status == "ERROR") then
        return status, statusStr
    end

    -- Update the FS type
    fsType = string.lower (fsType)
    
    -- Remove already existed files  
    status, statusStr = partitionMgmt.removePartitionFiles ()
    
    -- Call function to delete the partition
    local statusCode = partitionMgmtLib.formatPartition (DB_FILE_NAME, partId,
    fsType)
    

    statusStr = partitionMgmt.mapCode2String (statusCode)
    if (statusStr == "STATUS_OK") then
        return "OK", "STATUS_OK"
    end

    return "ERROR", statusStr
end

--*****************************************************************************
--partitionMgmt.removePartitionFiles - remove all the unwanted file after operation 
--
--This routine gets list of existing file and remove it from tmp directory
--
--RETURNS: status, statusStr
function partitionMgmt.removePartitionFiles (diskId)
   
   local pDiskId = ""
   local diskFilePath = "/tmp/partition."
   local diskTbl = {}
   local delimiter = "/"
   local fileName = ""
   local rm = "/bin/rm -rf "
   local cmd = ""
   local rows = db.getTable ("diskMgmtPartition", false)
   if (rows ~= nil) then  
       for itr, tbl in pairs (rows) do
           -- read each rows and get the diskId
           pDiskId = tbl["diskId"] 
           diskTbl = util.split (pDiskId, delimiter)
           if (diskTbl[3] ~= nil) then
               fileName = diskFilePath .. diskTbl[3]
               if(util.fileExists (fileName) ) then
                   cmd = rm .. fileName
                   os.execute (cmd) 
               end
           end
       end
   end
    
    return "OK", "STATUS_OK"
end
--*****************************************************************************
--partitionMgmt.getUnallocateStatList - get list containing unallocated block
--
--This routine gets list containing allocated blocks for given disk ID.
--
--RETURNS: status, statusStr, and the table
function partitionMgmt.getUnallocateStatList (diskId)
    -- Check the disk ID
    if (diskId == nil) then
        return "ERROR", "PARTITION_MGMT_INVALID_DISK_ID", nil
    end

    -- Call the routine to get the unallocated stat list
    status, fileName = partitionMgmtLib.getUnallocatedSpaceStats (diskId)
    if (status == "ERROR") then
        return "ERROR", "PARTITION_MGMT_FAILED_TO_GET_UNALLOC_LIST", nil
    end

    -- Get the data from the file
    dofile (fileName)
    return "OK", "STATUS_OK", diskMgmtFreeSpace
end

--*****************************************************************************
--partitionMgmt.exportPartition - exports the partition info in the partition
--
--This routine takes the partition ID as an argument. It then reads infor
--related to the partition and exports the data in the main mount directory.
--
--RETURN: status and statusStr
function partitionMgmt.exportPartition (partId)
    -- Get the require packages
    require "teamf1lualib/nasNAS"

	if (partId == nil)  then
        return "ERROR", "PARTITION_MGMT_FAILED_TO_EXPORT"
	end

    -- Get the partition info from DB
    local where = "partId = '" .. partId .. "'"
    local partitionInfo = {}
    partitionInfo["partition"] = db.getRowWhere ("diskMgmtPartition", where, false)
    if (partitionInfo["partition"] == nil) then
        return "ERROR", "PARTITION_MGMT_FAILED_TO_EXPORT"
    end

    -- open the file for writing
    local fileName = partitionInfo["partition"]["mntDir"] ..  "/.teamf1MetaData"
    util.appendDebugOut ("fileName = " .. fileName .. "<br>")
    local filePtr = io.open (fileName, "wb")
	if (filePtr ~= nil) then
	    -- export nas related data
		nas.shareConfigExport (partId, filePtr)

	    -- Write info about the partition
		db.saveTable(filePtr, "config.diskMgmt",partitionInfo, false, 1, 1)
	   filePtr:close()
	end
end

--*****************************************************************************
--partitionMgmt.deletePartitionShares - deletes the partition shares
--
--This routine takes the partition ID as an argument. It then reads infor
--related to the partition and deletes the data from DB.
--
--RETURN: status and statusStr
function partitionMgmt.deletePartitionShares (partId)
    -- Get the require packages
    require "teamf1lualib/nasNAS"

    -- export nas related data
    nas.shareConfigDelete (partId)
end

--*****************************************************************************
--partitionMgmt.configRegister - registers components export/import routines
--
--This routine will be called by any component that wants to register itself
--to do import/export of this configuration. This routine will append the info
--provided to local table. 
--
--RETURN: nothing
function partitionMgmt.shareConfigRegister (compName, importFunc, exportFunc,
    deleteFunc)
    if (partitionMgmt["components"] == nil) then
        partitionMgmt["components"] = {}
    end
    local comp = {}
    comp.compName = compName
    comp.import = importFunc
    comp.export = exportFunc
    comp.delete = deleteFunc
    
    table.insert (partitionMgmt.components, comp)
end

debugFileName = "/tmp/partitionMgmtDebugFile"
filePtr=nil
--*****************************************************************************
--partitionMgmt.importPartition - importss the partition info
--
--This routine imports the partition info from the config file in the
--partition into the DB.
--
--RETURN: status and statusStr
function partitionMgmt.importPartition (partId, mntDir)
    -- Create a file name
    local fileName = mntDir .. "/" .. ".teamf1MetaData"

    
    filePtr = io.open (debugFileName, "a")
	if (filePtr == nil) then
		return -1
	end

    filePtr:write (fileName)
    filePtr:write ("\n")
    -- Load the config file
    config = {}

    util.appendDebugOut ("processing partitionId = " .. partId)
    -- Load the config file
    status, message = pcall (dofile, fileName)
    if (status ~= true) then
        filePtr:write (message)
        filePtr:write ("\n")
        --logging.logMsg ("UMI_COMP_NAS", 18, 8, message)
        return 1
    end

    -- Start loading the info in the DB
    db.beginTransaction()
    globalTransaction = true
    status, status2, message = pcall (partitionMgmt.comps_import, config, partId, mntDir)

    if (status ~= true or status2 == -1) then
        if (status ~= true) then
            message = status2
        end
        filePtr:write (message)
        filePtr:write ("\n")
        globalTransaction = nil
        db.rollback ()
        return 2
    end

    globalTransaction = nil
    db.commitTransaction ()

    filePtr:write (string.gsub (util.getDebugOut (), "<br>", "\n"))
	filePtr:close()
    return 0

end

function partitionMgmt.comps_import (config, partId, mntDir)
    require "teamf1lualib/config_NAScomps"

    -- get the partition info table
    local partitionTbl = config.diskMgmt["partition"]

    -- Replace the partition ID with ID provided
    partitionTbl["partId"] = partId
    partitionTbl["mntDir"] = mntDir

    -- Extract the disk Id
    local diskIdLen = string.len (partitionTbl["diskId"])
    diskIdLen = (-1) * (diskIdLen)
    local startIndex = string.find (partId, "[0-9]+", diskIdLen)
    partitionTbl["diskId"] = string.sub (partId, 1, (startIndex - 1))
    -- changed 'status' specific to RIL
    partitionTbl["status"] = db.getAttribute ("smbGlobalConfig", "LogicalIfName", "IF2", "serverEnable")
	partitionTbl["_ROWID_"] = nil

    -- Add the partition info to DB
    partitionTbl = util.addPrefix (partitionTbl, "diskMgmtPartition.")
    local valid, errstr, rowid = db.insert ("diskMgmtPartition", partitionTbl)
	if (not valid) then
		return -1, errstr
	end

    -- Add the partition related info first
    for i,v in ipairs (partitionMgmt["components"]) do
        status, message = v["import"] (config[v.compName], partId)
        if (status ~= nil and status == -1) then
            print ("error during importing configuration for " .. v.compName)
            return status, message
        end
    end

    -- Update the printer info
    local printerGlobalTbl = db.getTable ("printServerGlobalCfg", true)
    if (printerGlobalTbl ~= nil) then
        require "teamf1lualib/printServer"
        local row = printerGlobalTbl[1]
        if (row ~= nil and (partitionTbl["diskMgmtPartition.timeStamp"] ~= nil) and
			(partitionTbl["diskMgmtPartition.timeStamp"] == row ["printServerGlobalCfg.timeStamp"])) then
            row["printServerGlobalCfg.spoolDiskParitionId"] = partId
            row["printServerGlobalCfg.spoolDiskParitionDir"] = mntDir
            printServer.editPrintServerGlobalCfg (row)
        end
    end
    return true
end

--*****************************************************************************
--partitionMgmt.createPartitionBestSize - create partition with best size
--
--This routine calls appropriate routines to create partition using the best
--size
--
--RETURN: status and status string
function partitionMgmt.createPartitionBestSize (partitionInfoTbl)
    -- Local Variables
    local status = "OK"
    local statusStr = "STATUS_OK"
    local statusCode

    -- Check for permission
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- Check if the DB file is defined.
    if (DB_FILE_NAME == nil) then
        return "ERROR", "SYSTEM_ERROR"
    end

    -- Get the starting size
    local startAddr
    local startAddrUnit
    status, startAddr, startAddrUnit = partitionMgmtLib.getStartAddr (
                                    partitionInfoTbl["partCreateInfo.diskId"],
                                    partitionInfoTbl["partCreateInfo.size"],
                                    partitionInfoTbl["partCreateInfo.sizeUnit"])
    if (status == "ERROR") then
        return "ERROR", "PARTITION_MGMT_FAILED_TO_GET_START_ADDR"
    end
    util.appendDebugOut ("startAddr " .. startAddr .. " startAddrUnit " ..
    startAddrUnit.. "<br>")
    partitionInfoTbl["partCreateInfo.startAddr"] = startAddr
    partitionInfoTbl["partCreateInfo.addrUnit"] = startAddrUnit

    -- Verify the input
    status, statusStr = partitionMgmt.verifyPartCreateData (partitionInfoTbl)
    if (status == "ERROR") then
        return status, statusStr
    end

    -- Need to verify MAX partitions after verifying the input as the disk ID
    -- has to be correct. For invalid disk Id, MAX Partition check might fail.
    status, statusStr = partitionMgmt.verifyMaxPartition ( 
                            partitionInfoTbl["partCreateInfo.diskId"])
    if (status == "ERROR") then
        return status, statusStr
    end

    -- Update some of the entries in the table
    partitionInfoTbl = partitionMgmt.modifyPartitionCreateInput(
                            partitionInfoTbl)

    -- We have verified as much info as we can here. Next set of verification
    -- will be done by the routine being called
    statusCode, partId = partitionMgmtLib.createPartition (DB_FILE_NAME,
                                partitionInfoTbl["partCreateInfo.diskId"],
                                partitionInfoTbl["partCreateInfo.size"],
                                partitionInfoTbl["partCreateInfo.sizeUnit"],
                                partitionInfoTbl["partCreateInfo.startAddr"],
                                partitionInfoTbl["partCreateInfo.addrUnit"],
                                partitionInfoTbl["partCreateInfo.fsType"],
                                partitionInfoTbl["partCreateInfo.partType"],
                                partitionInfoTbl["partCreateInfo.name"])
    statusStr = partitionMgmt.mapCode2String (statusCode)
    if (statusStr == "STATUS_OK") then
        return "OK", "STATUS_OK", partId
    end

    return "ERROR", statusStr, partId
end

