--[[
#### Mohan Kannekanti
#### TeamF1
#### www.TeamF1.com
#### Feb 10, 2012

#### File: swMgr.lua
#### Description: Switch Manager utility functions

#### Revisions:
01a,18Sep18,swr  Changes for SPR 63317(vlan membership conf support)
None
]]--

require "swMgrLib"
require "teamf1lualib/db"
require "teamf1lualib/util"

-- swMgr package
swMgr   = {}

swMgr.SWITCHTBL     = "swGlobalCfg"
swMgr.SWITCHPORTTBL = "swPortConfig"
swMgr.SWITCHVLANTBL = "vlanEncapIf"
swMgr.SWITCHVLANMEMTBL = "vlanMembershipPort"

-------------------------------------------------------------------------------
-- @name  swMgr.import
--
-- @description This function imports the configuration of switch from database 
--
-- @return  None
--

function swMgr.import (inputTable, defaultCfg, removeCfg)
    if (inputTable == nil) then
        inputTable = defaultCfg
    end

    local swGlobalCfgParamsTmp = {}
    local swPortCfgParamsTmp = {}
    local swVlanCfgParamsTmp = {}
    local vlanMembershipPortTmp = {}


    if (inputTable.swGlobalCfgParams ~= nil) then
        swGlobalCfgParamsTmp = config.update (inputTable.swGlobalCfgParams, defaultCfg.swGlobalCfgParams, removeCfg.swGlobalCfgParams) 
        if (swGlobalCfgParamsTmp ~= nil and #swGlobalCfgParamsTmp ~= 0) then
            for i,v in ipairs(swGlobalCfgParamsTmp) do
                v = util.addPrefix (v, swMgr.SWITCHTBL .. ".")
                swMgr.dbConfig (swMgr.SWITCHTBL, v, -1, "add")
            end
        end
    end

    if (inputTable.swPortCfgParams ~= nil) then
        swPortCfgParamsTmp = config.update (inputTable.swPortCfgParams, defaultCfg.swPortCfgParams, removeCfg.swPortCfgParams) 
        if (swPortCfgParamsTmp ~= nil and #swPortCfgParamsTmp ~= 0) then
            for i,v in ipairs(swPortCfgParamsTmp) do
                v = util.addPrefix (v, swMgr.SWITCHPORTTBL .. ".")
                swMgr.dbConfig (swMgr.SWITCHPORTTBL, v, -1, "add")
            end
        end
    end

    if (inputTable.swVlanCfgParams ~= nil) then
        swVlanCfgParamsTmp = config.update (inputTable.swVlanCfgParams, defaultCfg.swVlanCfgParams, removeCfg.swVlanCfgParams) 
        if (swVlanCfgParamsTmp ~= nil and #swVlanCfgParamsTmp ~= 0) then
            for i,v in ipairs(swVlanCfgParamsTmp) do
                v = util.addPrefix (v, swMgr.SWITCHVLANTBL .. ".")

				-- Check  if we are going from some old 2031/4031 image to new image with vlan support
				if (util.fileExists("/pfrm2.0/ECONET")) then

					if (v["vlanEncapIf.fwdMap"] == "1,2,3,7,8,9" ) then
						v["vlanEncapIf.fwdMap"] = "3,4"
					end

					if (v["vlanEncapIf.untagMap"] == "1,2,3,7,8,9" ) then
						v["vlanEncapIf.untagMap"] = "3,4"
					end

					if (v["vlanEncapIf.inSwitchOnly"] == "0" ) then
						v["vlanEncapIf.inSwitchOnly"] = "1"
					end					

				
				end
                swMgr.dbConfig (swMgr.SWITCHVLANTBL, v, -1, "add")
				if (util.fileExists("/pfrm2.0/BRCMJCO300") or util.fileExists("/pfrm2.0/HW_JCO410") or util.fileExists("/pfrm2.0/HW_JCE410")) then
				-- For BRCM HGW we are using SDK tools for vlan management	
				local cmd="/pfrm2.0/bin/vlanUpdate.sh ADD " .. v["vlanEncapIf.vlanId"] .. " " .. v["vlanEncapIf.fwdMap"] .. " " .. v["vlanEncapIf.untagMap"]
				os.execute(cmd)
				end

				if (util.fileExists("/pfrm2.0/ECONET")) then

				local  fwdMap = "NO"
				if (v["vlanEncapIf.fwdMap"] == nil or v["vlanEncapIf.fwdMap"] == "") then
					fwdMap = "NO"
				else
					fwdMap = v["vlanEncapIf.fwdMap"]
				end


				local cmd="/pfrm2.0/bin/vlanUpdate.sh ADD " .. v["vlanEncapIf.vlanId"] .. " " .. fwdMap .. " " .. v["vlanEncapIf.inSwitchOnly"] .. " " .. v["vlanEncapIf.untagMap"]
				os.execute(cmd) 
				end
            end
            if (util.fileExists("/pfrm2.0/HW_JCO410") or util.fileExists("/pfrm2.0/HW_JCE410")) then
				swMgr.l2_vlan_rules_update2 ()
			end
			if (util.fileExists("/pfrm2.0/BRCMJCO300")) then
				-- no need to restart interface during bootup
				swMgr.l2_vlan_rules_update (0)
			end
			if (util.fileExists("/pfrm2.0/ECONET")) then
				-- no need to restart interface during bootup
				swMgr.l2_vlan_rules_update_ECONET (0)
			end
        end
    end

    vlanMembershipPortTmp = config.update (inputTable.vlanMembershipPort, defaultCfg.vlanMembershipPort, removeCfg.vlanMembershipPort) 
    if (vlanMembershipPortTmp ~= nil and #vlanMembershipPortTmp ~= 0) then
        for i,v in ipairs(vlanMembershipPortTmp) do
            v = util.addPrefix (v, swMgr.SWITCHVLANMEMTBL .. ".")
            swMgr.dbConfig (swMgr.SWITCHVLANMEMTBL, v, -1, "add")
        end
    end
end

-------------------------------------------------------------------------------
-- @name swMgr.swTblGet 
--
-- @description  This function gets the list of switches managed by this manager.
--
-- @return status
-- @return errCode
-- @return switch table.
--

function swMgr.swTblGet()
    -- TODO
end

-------------------------------------------------------------------------------
-- @name swMgr.export
--
-- @description  export switch manager configuration tables
--
-- @return 
--

function swMgr.export ()
    local swMgrConfig = {}

    swMgrConfig.swGlobalCfgParams = db.getTable (swMgr.SWITCHTBL, false)
    swMgrConfig.swPortCfgParams = db.getTable (swMgr.SWITCHPORTTBL, false)
    swMgrConfig.swVlanCfgParams = db.getTable (swMgr.SWITCHVLANTBL, false)
    swMgrConfig.vlanMembershipPort = db.getTable (swMgr.SWITCHVLANMEMTBL, false)
    
    return swMgrConfig
end

--
--
--
--  LOCAL FUNCTIONS
--
--

--[[
*******************************************************************************
-- @name swMgr.dbConfig 
--
-- @description This function is helper function to update switch manager tables
--
-- @param tableName table name
-- @param cfg       configuration table
-- @param rowid     row id to update
-- @param operation operation ("add"/"edit"/"delete")
--
-- @return status
-- @return errCode
--]]

function swMgr.dbConfig (tableName, cfg, rowid, operation)
    
	if(ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED","ADMIN_REQD"	
	end

    local valid = false

	-- validate
	if (operation == "add") then
		valid, errstr, rowid = db.insert(tableName, cfg, rowid)
	elseif (operation == "edit") then
		valid, errstr  = db.update(tableName, cfg, rowid)
	elseif (operation == "delete") then
		valid, errstr = db.delete(tableName, cfg)
	end

    -- return
    if (valid) then
        return "OK", "STATUS_OK"
    else
        swMgr.dprintf ("Error String: " .. errstr);
        return "ERROR", "SWMGR_CONFIG_FAILED", errstr
    end
end

--[[
*******************************************************************************
-- @name swMgr.dprintf
--
-- @description This function will print what ever is given to it
--
-- @param data data to print
--
-- @return None
--
--]]

function swMgr.dprintf (data)
    if (data ~= nil) then 
        print ("SWITCH_MANAGER_DEBUG: " .. data)
    end
end

-------------------------------------------------------------------------------
-- @name config.register
--
-- @description register this component with TeamF1 configuration framework.
--
-- @param 
--
-- @return 
--

if (config.register) then
   config.register("swMgr", swMgr.import, swMgr.export, "1")
end

--[[
*******************************************************************************
-- @name swMgr.l2_vlan_rules_update
--
-- @description This function will add ebtables for inter vlan isolation in
--              boards which do not have switch and each port is an intrface
--              This api is currently used for broadcom HGW devices like 
--              Fiberhome/Foxconn ONT 
--
-- @param 
--
-- @return None
--
--]]
function swMgr.l2_vlan_rules_update (restartInterface)

	local EBTABLES_CMD="/bin/ebtables"
	local IFCONFIG="/sbin/ifconfig "
    local cmd1 = nil
    local cmd2 = nil
    local cmd3 = nil
	
	local lanBdgName = db.getAttribute("bridgetable", "LogicalIfName", "IF2", "interfaceName")
	if ( lanBdgName == nil ) then lanBdgName = "bdg2" end

	local BRCTL="/bin/brctl deldynmacs " .. lanBdgName .. " "
  	if (restartInterface) then
    -- adding cmd to down the vlan interface after configuration
    local vlanTable = db.getTable ("vlanEncapIf")
	for k,v in pairs (vlanTable) do
		for i,j in pairs (vlanTable) do
			if (v["vlanEncapIf.vlanId"] ~= j["vlanEncapIf.vlanId"]) then
				local fwdMap = util.split (v["vlanEncapIf.fwdMap"],",")
				for kk,vv in pairs (fwdMap) do
					if (string.find (j["vlanEncapIf.fwdMap"], vv) == nil ) then
						local fwdMap2 = util.split (j["vlanEncapIf.fwdMap"],",")
						for kk1,vv1 in pairs (fwdMap2) do
							if (string.find (v["vlanEncapIf.fwdMap"], vv1) == nil ) then
							    if(cmd1 == nil and cmd2 == nil )then
                                    cmd1 = IFCONFIG .. "eth"..(tonumber(vv)-1).."."..v["vlanEncapIf.vlanId"] .. " down;"
                                    cmd2 = IFCONFIG .. "eth"..(tonumber(vv)-1).."."..v["vlanEncapIf.vlanId"] .. " up;"
                                    cmd3 = BRCTL .. "eth"..(tonumber(vv)-1).."."..v["vlanEncapIf.vlanId"] .. ";"
                                else
                                    cmd1 = cmd1 .. IFCONFIG .. "eth"..(tonumber(vv)-1).."."..v["vlanEncapIf.vlanId"] .. " down;"
                                    cmd2 = cmd2 .. IFCONFIG .. "eth"..(tonumber(vv)-1).."."..v["vlanEncapIf.vlanId"] .. " up;"
                                    cmd3 = cmd3 .. BRCTL .. "eth"..(tonumber(vv)-1).."."..v["vlanEncapIf.vlanId"] .. ";"
                                end
                            end
						end
					end
				end
			end
		end
	end
	--[[
	doing the fllowing to clear up any bridge flows
	1. Ifconfig eth.X down and up.
	2. Flow caching disable and enable
	3. delete dynamic macs from the bridge
	]]--
    os.execute(IFCONFIG .. " "..lanBdgName .. " down")
    os.execute(cmd1)
    os.execute(cmd3)
    os.execute("/bin/fc disable > /dev/null")
    os.execute("/bin/sleep 5")
    os.execute(cmd2)
    os.execute(cmd3)
    os.execute("/bin/fc enable > /dev/null")
    os.execute(IFCONFIG .. " "..lanBdgName .. " up")
	end

	local cmd = EBTABLES_CMD .. " -F FORWARD"
	os.execute(cmd)
	local vlanTable = db.getTable ("vlanEncapIf")
	if (vlanTable ~= nil) then
	for k,v in pairs (vlanTable) do
		for i,j in pairs (vlanTable) do
			if (v["vlanEncapIf.vlanId"] ~= j["vlanEncapIf.vlanId"]) then
				local fwdMap = util.split (v["vlanEncapIf.fwdMap"],",")
				for kk,vv in pairs (fwdMap) do
					if (string.find (j["vlanEncapIf.fwdMap"], vv) == nil ) then
						local fwdMap2 = util.split (j["vlanEncapIf.fwdMap"],",")
						for kk1,vv1 in pairs (fwdMap2) do
							if (string.find (v["vlanEncapIf.fwdMap"], vv1) == nil ) then
                                --Do not decrement fwmap as LAN interface starts from eth1 for HG260ES JCO300 and JCO110
                                if (util.fileExists("/pfrm2.0/HW_HG260ES") or util.fileExists("/pfrm2.0/HW_JCO110") or util.fileExists("/pfrm2.0/HW_FIBERHOME_JCO300")) then
                                    cmd = EBTABLES_CMD .." -A FORWARD -i eth"..(tonumber(vv)).."."..v["vlanEncapIf.vlanId"] .. " -o eth"..(tonumber(vv1)).."."..j["vlanEncapIf.vlanId"].. " -j DROP"
                                elseif (util.fileExists("/pfrm2.0/HW_ALU")) then
                                    cmd = EBTABLES_CMD .." -A FORWARD -i eth"..(4-tonumber(vv)).."."..v["vlanEncapIf.vlanId"] .. " -o eth"..(4-tonumber(vv1)).."."..j["vlanEncapIf.vlanId"].. " -j DROP"
                                else
                                    cmd = EBTABLES_CMD .." -A FORWARD -i eth"..(tonumber(vv)-1).."."..v["vlanEncapIf.vlanId"] .. " -o eth"..(tonumber(vv1)-1).."."..j["vlanEncapIf.vlanId"].. " -j DROP"
                                end
                                os.execute(cmd)
							end
						end
					end
				end
			end
		end
	end
	end
end

function swMgr.l2_vlan_rules_update2 ()
    
    local EBTABLES_CMD="/usr/sbin/ebtables"
    local cmd = EBTABLES_CMD .. " -F FORWARD"
	os.execute(cmd)
	local vlanTable = db.getTable ("vlanEncapIf")
	if (vlanTable ~= nil) then
	    for k,v in pairs (vlanTable) do
		    for kk, vv in pairs (vlanTable) do
                if (v["vlanEncapIf.vlanId"] ~= vv["vlanEncapIf.vlanId"]) then
                    cmd=EBTABLES_CMD .. " -A FORWARD -i eth0." .. v["vlanEncapIf.vlanId"] .. " -o eth0." ..vv["vlanEncapIf.vlanId"] .. " -j DROP"
	                os.execute(cmd)
                end
            end
	    end
	end
end

function swMgr.l2_vlan_rules_update_ECONET (restartInterface)

	local EBTABLES_CMD="/bin/ebtables"
	local IFCONFIG="/sbin/ifconfig "
    local cmd1 = nil
    local cmd2 = nil
    local cmd3 = nil
	
	local lanBdgName = db.getAttribute("bridgetable", "LogicalIfName", "IF2", "interfaceName")
	if ( lanBdgName == nil ) then lanBdgName = "bdg2" end

  	if (restartInterface) then
    -- adding cmd to down the vlan interface after configuration
    local vlanTable = db.getTable ("vlanEncapIf")
	for k,v in pairs (vlanTable) do
		for i,j in pairs (vlanTable) do
			if (v["vlanEncapIf.vlanId"] ~= j["vlanEncapIf.vlanId"]) then
				local fwdMap = util.split (v["vlanEncapIf.fwdMap"],",")
				for kk,vv in pairs (fwdMap) do
					if (string.find (j["vlanEncapIf.fwdMap"], vv) == nil ) then
						local fwdMap2 = util.split (j["vlanEncapIf.fwdMap"],",")
						for kk1,vv1 in pairs (fwdMap2) do
							if (string.find (v["vlanEncapIf.fwdMap"], vv1) == nil ) then
							    if(cmd1 == nil and cmd2 == nil )then
                                    cmd1 = IFCONFIG .. "eth0."..(tonumber(vv)).."."..v["vlanEncapIf.vlanId"] .. " down;"
                                    cmd2 = IFCONFIG .. "eth0."..(tonumber(vv)).."."..v["vlanEncapIf.vlanId"] .. " up;"
                                else
                                    cmd1 = cmd1 .. IFCONFIG .. "eth0."..(tonumber(vv)).."."..v["vlanEncapIf.vlanId"] .. " down;"
                                    cmd2 = cmd2 .. IFCONFIG .. "eth0."..(tonumber(vv)).."."..v["vlanEncapIf.vlanId"] .. " up;"
                                end
                            end
						end
					end
				end
			end
		end
	end
	--[[
	doing the fllowing to clear up any bridge flows
	1. Ifconfig eth.X down and up.
	2. Flow caching disable and enable
	3. delete dynamic macs from the bridge
	]]--
    os.execute(IFCONFIG .. " "..lanBdgName .. " down")
    os.execute(cmd1)
    os.execute(cmd3)
    os.execute("/bin/sleep 5")
    os.execute(cmd2)
    os.execute(cmd3)
    os.execute(IFCONFIG .. " "..lanBdgName .. " up")
	end

	if (util.fileExists("/pfrm2.0/ECONET")) then

		EBTABLES_CMD = "/usr/bin/ebtables"
	end

	local cmd = EBTABLES_CMD .." -F lanTolanDrop"
	os.execute(cmd)
	local vlanTable = db.getTable ("vlanEncapIf")
	if (vlanTable ~= nil) then
	for k,v in pairs (vlanTable) do
		for i,j in pairs (vlanTable) do
			if (v["vlanEncapIf.vlanId"] ~= j["vlanEncapIf.vlanId"]) then
				local fwdMap = util.split (v["vlanEncapIf.fwdMap"],",")
				for kk,vv in pairs (fwdMap) do
					if (string.find (j["vlanEncapIf.fwdMap"], vv) == nil ) then
						local fwdMap2 = util.split (j["vlanEncapIf.fwdMap"],",")
						for kk1,vv1 in pairs (fwdMap2) do
							if (string.find (v["vlanEncapIf.fwdMap"], vv1) == nil ) then
                                    cmd = EBTABLES_CMD .." -A lanTolanDrop -i eth0."..(tonumber(vv)).."."..v["vlanEncapIf.vlanId"] .. " -o eth0."..(tonumber(vv1)).."."..j["vlanEncapIf.vlanId"].. " -j DROP"
                                os.execute(cmd)
							end
						end
					end
				end
			end
		end
	end
	end
end
