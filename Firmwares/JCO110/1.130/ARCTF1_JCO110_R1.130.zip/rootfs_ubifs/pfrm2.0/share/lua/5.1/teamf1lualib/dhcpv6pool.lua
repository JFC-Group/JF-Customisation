-- Copyright (c) 2017, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd] 

-- Revisions:
-- 01a,31Jul17,swr  Changes for SPR 60117 


dhcpv6.pool = {}

-------------------------------------------------------------------------
-- @name dhcpv6.pool.cfgInit
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcpv6.pool.cfgInit(row, conf)

    if (conf["LogicalIfName"] ~= nil) then
        row["LogicalIfName"] = db.getAttribute ("networkInterface", "networkName", conf["NetworkName"], "LogicalIfName")
    end
            
    if (conf["startAddress"] ~= nil) then
        row["startAddress"] = conf["startAddress"]
    end
    
    if (conf["endAddress"] ~= nil) then        
        row["endAddress"] =  conf["endAddress"] 
    end

    if (conf["prefixLength"] ~= nil) then
        row["prefixLength"] = conf["prefixLength"]
    end

    if (conf["delegateEnabled"] ~= nil) then
        row["delegateEnabled"] = conf["delegateEnabled"]
    end

    if (conf["delegationPrefix"] ~= nil) then 
        row["delegationPrefix"] = conf["delegationPrefix"]
    end

    if (conf["delegationPrefixLen"] ~= nil) then
        row["delegationPrefixLen"] = conf["delegationPrefixLen"]
    else
        row["delegationPrefixLen"] = "0"
    end

    return row
end

-------------------------------------------------------------------------
-- @name dhcpv6.pool.defCfgGet
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcpv6.pool.defCfgGet()
    local row = {}

    row["delegateEnabled"] = "0"
    row["delegationPrefix"] = ""
    row["delegationPrefixLen"] = ""

    return  row
end

-------------------------------------------------------------------------
-- @name dhcpv6.pool.configure
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcpv6.pool.configure(conf)
    local query = nil

    if (conf == nil) then
        return "ERROR","DHCPV6D_INVALID_PARAMS"
    end        
    
    status, errCode = dhcpv6.pool.validate(conf)
    if (status ~= "OK") then
        return "ERROR", errCode
    end
    query = "startAddress='" .. conf["startAddress"] .. "'" .. " and " .. "endAddress='" .. conf["endAddress"] .. "'" .. " or " .. "_ROWID_='" .. conf["_ROWID_"] .. "'" 
    local dhcpTbl = db.getTable("dhcpv6sLANAddrPool", false)
    for i,v in pairs (dhcpTbl) do
        if ((v["startAddress"] == conf["startAddress"]) and (v["endAddress"] == conf["endAddress"])) then
            dhcpv6.dprintf("dhcpv6.pool.set: Ipv6 address already exits")
            return "ERROR", "DHCPV6D_IPADDRESS_ALREADY_EXISTS"
        end
    end   

    local row = db.getRowWhere("dhcpv6sLANAddrPool", query, false)

    if (row ~= nil)  then
        dhcpv6.pool.cfgInit(row, conf)

        row = util.addPrefix(row, "dhcpv6sLANAddrPool.")
        local valid, errstr = db.update("dhcpv6sLANAddrPool", row,
                                        row["dhcpv6sLANAddrPool._ROWID_"])
        if (not valid) then
            dhcpv6.dprintf("dhcpv6.pool.add.set: failed to update pool configuration")
            return "ERROR", "DHCPV6D_UPDATE_FAILED"
        end            
    else
        row = dhcpv6.pool.defCfgGet()

        row = dhcpv6.pool.cfgInit(row, conf)

        dhcpv6.dprintf("dhcpv6.pool.add.set: POOL:" .. util.tableToStringRec(row))

        row = util.addPrefix(row, "dhcpv6sLANAddrPool.")
        local valid, errstr, rowid  = db.insert("dhcpv6sLANAddrPool", row)
        if (not valid) then
            dhcpv6.dprintf("dhcpv6.pool.add.set: failed to add pool configuration")
            return "ERROR", "DHCPV6D_ADD_FAILED"
        end            
    end                

    require "teamf1lualib/service"
    service.restart("dhcpv6s", "1")

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name dhcpv6.pool.delete
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcpv6.pool.delete(IDList)

    if (IDList == nil) then
        dhcpv6.dprintf("dhcpv6.pool.delete: invalid arguments")        
        return "ERROR", "DHCPV6D_INVALID_ARG"
    end
            
    --begin transation
    db.beginTransaction()

    -- delete dhcpv6ServerPools row
    retStatus = dhcpv6Tr.deleteDhcpv6ServerPools ("dhcpv6sLANAddrPool", IDList)
    if(retStatus ~= 0) then
        -- rollback transation
        db.rollback() 
        return "ERROR","DHCPV6D_DB_ERR"
    end

    -- delete ipv6PrefixTable row
    retStatus = dhcpv6Tr.deleteIPv6Prefix ("dhcpv6sLANAddrPool", IDList)
    if(retStatus ~= 0) then
        -- rollback transation
        db.rollback() 
        return "ERROR","DHCPV6D_DB_ERR"
    end 

    local valid, errstr = db.delete ("dhcpv6sLANAddrPool", IDList)
    if (not valid) then
        dhcpv6.dprintf("dhcpv6.pool.delete: " ..
                       "failed to delete bindings from db. Err:" .. errstr)
        dhcpv6.dprintf("IDList: " .. util.tableToStringRec(IDList))
        -- rollback transation
        db.rollback()
        return "ERROR","DHCPV6D_DB_ERR"
    else
        -- commit transation
        db.commitTransaction()
    end        

    require "teamf1lualib/service"
    service.restart("dhcpv6s", "1")

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name dhcpv6.pool.get
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcpv6.pool.get(query)
    local pools = {}
    local index = 1
    local rows = {}

    if (query ~= nil) then
        rows = db.getRowsWhere("dhcpv6sLANAddrPool", query, false)
    else
        rows = db.getTable("dhcpv6sLANAddrPool", false)
    end        

    if (rows ~= nil) then
        for k,v in pairs(rows) do
            pools[index] = {}
            pools[index] = v
            index = index + 1
        end
    end        

    return "OK","STATUS_OK", pools
end

-------------------------------------------------------------------------
-- @name dhcpv6.pool.validate
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcpv6.pool.validate(conf)
    require "nimfLib"

    if (conf["LogicalIfName"] == nil) then
        return "ERROR","DHCPV6D_INVALID_PARAMS"
    end        

    local startPrefix = nimfLib.prefixGet(conf["startAddress"], conf["prefixLength"])
    if (startPrefix == nil) then
        return "ERROR","DHCPV6D_INVALID_POOL_STARTADDR"
    end
            
    local endPrefix = nimfLib.prefixGet(conf["endAddress"], conf["prefixLength"])
    if (endPrefix == nil) then
        return "ERROR","DHCPV6D_INVALID_POOL_ENDADDR"
    end
    
    if (nimfLib.prefixCompare(startPrefix, endPrefix) <= 0) then        
        return "ERROR","DHCPV6D_INVALID_RANGE"
    end    
        
    return "OK", "STATUS_OK"    
end
