-- @copyright Copyright (c) 2012, TeamF1, Inc. 

require "teamf1lualib/evtDsptch"
require "nscanLib"
require "appExtn/AppExtn"

NscanExtn = OoUtil.inheritsFrom(AppExtn)
NscanExtn.name    = "LAN Network Scanner"
NscanExtn.className = "NscanExtn"
NscanExtn.classId = "nscan"
NscanExtn.dbTable = nil
NscanExtn.logger  = nil

local SUPER = require("appExtn.AppExtn")

local netEvents  = {}
netEvents[evtDsptch.event.IFDEV_EVENT_IP4_NET_UP] =  1
netEvents[evtDsptch.event.IFDEV_EVENT_IP4_NET_DOWN] =  1

local numScannerInstances = 0
local scannerInstanceList = {}

-------------------------------------------------------------------------------
-- @name scannerInstanceAdd
--
-- @description This function adds the scanner instance
--
-- @param obj scanner object
--
-- @return  0
--

local function scannerInstanceAdd (obj)
    table.insert(scannerInstanceList, obj)
end

-------------------------------------------------------------------------------
-- @name scannerInstanceDelete 
--
-- @description This function deletes the scanner instance
--
-- @param obj scanner object
--
-- @return  scanner object or nil
--

local function scannerInstanceDelete (obj)

    for index, scannerObj in pairs(scannerInstanceList) do
        if (strlib.strcasecmp(scannerObj.LogicalIfName, 
                              obj.LogicalIfName) == 0) then
            table.remove(scannerInstanceList, index)
            return 0
        end            
    end        

    return -1
end

-------------------------------------------------------------------------------
-- @name scannerInstanceFind find the scanner instance
--
-- @description This function finds the scanner instance
--
-- @param  LogicalIfName 
--
-- @return  scanner object or nil
--

local function scannerInstanceFind (LogicalIfName)

    for index, scannerObj in pairs(scannerInstanceList) do
        if (strlib.strcasecmp(LogicalIfName, 
                              scannerObj.LogicalIfName) == 0) then
            return scannerObj                              
        end            
    end        

    return nil
end

-------------------------------------------------------------------------------
-- @name NscanExtn:new
--
-- @description This function creates a new instance object for nscan
--
-- @return  
--

function NscanExtn:new(instanceId, props)

    assert(instanceId, "Instance ID must be specified")

    -- create a new instance
    self = NscanExtn.create()

    SUPER.new(self, NscanExtn.classId, instanceId, props)

    self.name  = NscanExtn.name
    self.dbTable = NscanExtn.dbTable
    self.dbconn = NscanExtn.dbconn
    self.logger = NscanExtn.logger

    -- initialize events for this instance
    self.netEvents = netEvents              

    -- load the configuration
    if (self:load() < 0) then
        return nil
    end
            
    -- register with appd
    appd.appExtnRegister(self)                    

    return self
end

-------------------------------------------------------------------------------
-- @name NscanExtn:delete
--
-- @description This function deletes an instance of this extension
--
-- @return  
--

function NscanExtn:delete() 
    appd.appExtnUnregister(self)
    scannerInstanceDelete(self)
    return 
end        

-------------------------------------------------------------------------------
-- @name NscanExtn:stop
--
-- @description This function stops network scanner
--
-- @return  0 for success and -1 for error
--

function NscanExtn:stop ()

    if (self.ifName == nil) then
        return -1
    end
            
    -- stop the scanner                    
    nscanLib.stop(self.ifName)

    return 0
end

-------------------------------------------------------------------------------
-- @name NscanExtn:load
--
-- @description This function loads the network scanner configuration
--
-- @return  0 for success and -1 for error
--

function NscanExtn:load ()
    require "teamf1lualib/nimf"
    local ifName = nil
    local conn = {}

    conn["LogicalIfName"] = self.LogicalIfName
    conn["AddressFamily"] = nimf.proto.NIMF_PROTO_TYPE_IPV4
    conn["ConnectionKey"] = 0

    self.ifName = nimfLib.connIfNameGet(conn)

    return 0
end

-------------------------------------------------------------------------------
-- @name NscanExtn:start
--
-- @description This function starts network scanner
--
-- @return  0 for success and -1 for error
--

function NscanExtn:start ()
    require "teamf1lualib/nimf"

    -- check if network is UP        
    if (not nimfConn.isIPv4Up(self.LogicalIfName)) then
        return -1
    end        

    -- check if interface name is loaded
    if (self.ifName == nil) then
        self:load()
    end

    if (self.ifName == nil) then
        LOG:error("failed to start " .. self.name)
        return -1
    end
            
    -- start the scanner                    
    nscanLib.start(self.ifName)

    return 0
end

-------------------------------------------------------------------------------
-- @name NscanExtn:restart
--
-- @description This function restarts network scanner
--
-- @return  0 for success and -1 for error
--

function NscanExtn:restart ()
                    
    -- stop nscan daemon                    
    self:stop()

    -- start nscan daemon                    
    if (self:start() < 0) then
        return -1
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name NscanExtn:getAppName
--
-- @description This function gets the name of this extension
--
-- @return  
--

function NscanExtn:getAppName()
   return self.name
end

-------------------------------------------------------------------------------
-- @name NscanExtn:onNetEvent
--
-- @description This function handles network events for nscan
--
-- @param  netevent event info
--
-- @return  0 for success and -1 for error
--

function NscanExtn:onNetEvent(netevent)

    if (self:isEventSubscribed(netevent) == false) then
        LOG:ddebug(self.classId .. " not subscribed to event: " ..
                  netevent.event .. " on " .. netevent.ifname)
        return 0
    end        

    self:restart()

    return 0
end

-------------------------------------------------------------------------------
-- @name NscanExtn:isEventSubscribed
--
-- @description This function checks if the application is subcribed to
-- the event 
--
-- @param event event info
--
-- @return  0 for success and -1 for error
--

function NscanExtn:isEventSubscribed(event)

    if (event.type == appd.eventType.APPD_EV_NET) then

        if (network.isLAN(event.ifname) == false) then
            return false                
        end
                    
        local evstate = self.netEvents[event.event]
        if (evstate == nil) then
            return false
        end            
                    
        if (evstate > 0) then
            return true
        end        
    end

    return false
end

-------------------------------------------------------------------------------
-- @name NscanExtn:print
--
-- @description This function is called by appd to bootstrap all instances of 
-- this application. 
--
-- @param  
--
-- @return  
--

function NscanExtn:print()
    require "util/strlib"

    LOG:info("Class     : " .. self.classId)
    LOG:info("Instance  : " .. self.instanceId)
    LOG:info("App Name  : " .. self:getAppName())

    return
end
-------------------------------------------------------------------------------
-- @name NscanExtn.netEventCallback
--
-- @description This function is called by appd during a network event.
-- If a network is added, then a new instance is created. If a network is
-- deleted then the instance is deleted.
--
-- @param  
--
-- @return  
--

function NscanExtn.netEventCallback(netevent)
    local instanceId 

    if (netevent.event == evtDsptch.event.IFDEV_EVENT_NET_ADD) then
        require "teamf1lualib/network"        
        
        -- if it is not a LAN network, then skip
        if (not network.isLAN(netevent.ifname)) then
            return
        end            
    
        numScannerInstances = numScannerInstances + 1
        instanceId = tostring(numScannerInstances)

        -- create a instance for given network
        local obj = NscanExtn:new(instanceId)
        if (obj ~= nil) then
            obj.LogicalIfName = netevent.ifname
            obj:start()

            -- save the instance for future use
            scannerInstanceAdd(obj)
        end        

    elseif (netevent.event == evtDsptch.event.IFDEV_EVENT_NET_DEL) then

        -- find the instance 
        local obj = scannerInstanceFind(netevent.ifname)
        if (obj) then
            -- stop the scanner
            obj:stop()

            -- delete the instance
            obj:delete()
        end            
    end
                    
    return                    
end

-------------------------------------------------------------------------------
-- @name NscanExtn.bootstrap
--
-- @description This function is called by appd on startup to bootstrap all 
-- instances of this application. 
--
-- @param  
--
-- @return  
--

function NscanExtn.bootstrap()
    local callbackTable= {}

    local callback = {}
    callback.type = appd.eventType.APPD_EV_NET
    callback.routine = NscanExtn.netEventCallback
    callback.netevent  = evtDsptch.event.IFDEV_EVENT_NET_DEL
    table.insert(callbackTable, callback)

    local callback = {}
    callback.type = appd.eventType.APPD_EV_NET
    callback.routine = NscanExtn.netEventCallback
    callback.netevent  = evtDsptch.event.IFDEV_EVENT_NET_ADD
    table.insert(callbackTable, callback)

    appd.callbackRegister (NscanExtn.classId, callbackTable)

    return 0
end

return NscanExtn
