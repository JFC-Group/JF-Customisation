-- tr181_tr69Glue.lua - lua wrapper calls for TR069
--
-- Copyright (c) 2017, TeamF1 Networks Pvt. Ltd.
-- (Subsidiary of D-Link India)
--
-- modification history
-- --------------------
-- 02k, 18Oct18, swr Changes for SPR 64657(Alarms & Faults enhancements)
-- 02j, 27Sep18, swr Changes for SPR 64429(file upload changes)
-- 02i, 21Jun18, swr Changes for SPR 62176(add dynamic routes to route DB table)
-- 02h, 25Apr18, swr changes for SPR 63567(added proper checks for reboot for firmware upgrade case)
-- 02g, 16Jan18, swr changes for SPR 63027(added nil checks)
-- 02f, 31Oct17, swr Changes for SPR 59254(radvd prefixes)
-- 02e, 16Oct17, swr Changes for SPR 62293
-- 02d, 08Sep17, swr Changes for SPR 62295
-- 02c, 18Aug17, swr Changes for SPR 60117
-- 02b, 20Apr17, MSV Made changes for DMS support in LANTIQ SPR#60512
-- 02a, 25Jan17, MSV Made changes for DMS backup/restore SPR#59380
-- 01z, 11Jan17, swr Changes for SPR 59206 
-- 01y, 02Sep16, swr Changes for SPR 56532(FCAPS)
-- 01x, 25Jul16, swr Fix for SPR 56888
-- 01w, 04Jul16, sda Fix for SPR 56649
-- 01v, 02Mar16, swr Fix for SPR 55329
-- 01u, 23Feb16, swr Fix for SPR 55104
-- 01t, 23Feb16, swr Fix for SPR 55249
-- 01s, 17Dec15, swr Fix for SPR 54404 and 54380 
-- 01r, 02Dec15, swr Fix for SPR 54403
-- 01q, 10Oct15, swr Changes for SPR 53725 and 53753 
-- 01p, 28Sep15, swr Changes for SPR 52552, 53202 
-- 01o, 10Sep15, swr Fix for SPR 53469 
-- 01n, 05Aug15, swr Fix for SPR 52782 
-- 01m, 21Jul15, swr Fix for SPR 52486 
-- 01l, 06May15, swr Adding support for UpgradesManaged
-- 01k, 21Jan15, tbp changes made for SPR#49268
-- 01j, 16Jan15, swr commenting out support for UpgradesManaged
-- 01i, 19Dec14, swr changes for SPR 47714
-- 01h, 13Dec14, swr changes for SPR 47714
-- 01g, 08Dec14, tbp changes made for restore from ACS SPR#48074
-- 01f, 27Nov14, tbp reverted restore changes to sync with HGW 
-- 01e, 27Nov14, sen changes for lte firmware upgrade support for ODU
-- 01d, 07Nov14, tbp changes for TR-143 interface support for 
--                   Download and Upload Diagnostics
-- 01c, 31Oct14, swr changes for UpgradesManaged
-- 01b, 15Oct14, swr changes for SPR#47238
-- 01a, 14Oct14, adk changes for SPR#47150
--
--
---------------------------------------------------------------------------------

require "teamf1lualib/util"
require "teamf1lualib/db"
require "luasql.sqlite3"

tr69Glue = {}
db.connect("/tmp/system.db")

ACCESS_LEVEL = 0
SETTINGS_FILE=db.getAttribute("environment", "name", "TEAMF1_CFG_ASCII", "value")

status = -1

local tr69GlueStaticMap = {}
local tr69GlueInstanceMap = {}
local sqlVars = {}
local _TR69_DB_env = luasql.sqlite3()
local ALARM_FILE                = "/tmp/AlarmsOn"
local FAULT_FILE                = "/tmp/FaultsOn"
local INTERNET_RETRIES          = "/tmp/NumberInternetRetries"
local SIGNAL_VALUE              = "/tmp/signalValue"
local internetScriptRestart     = "/tmp/RestartInternetScript"
local wifiScriptRestart         = "/tmp/RestartWifiScript"
local gponScriptRestart         = "/tmp/RestartGPONScript"
local internetRecScriptRestart  = "/tmp/RestartInternetRecoverScript"
local dosScriptRestart          = "/tmp/RestartDosScript"
local icmpScriptRestart         = "/tmp/RestartICMPScript"
local udpScriptRestart          = "/tmp/RestartUDPScript"
local signalDegradationPid      = "/tmp/signalDegradationPid"
local signalDegradationScript   = "/pfrm2.0/bin/signalDegradation.lua"
local dbglogAcsScript           = "/pfrm2.0/bin/dbglogAcs.lua"
local dbglogFile                = "/var/dbglog.tgz"
local dbglogFileName            = "dbglog"

for line in io.lines ("/pfrm2.0/etc/tr69DB.map") do
    for sqlVar,value in string.gfind (line,"(.-)=(.*)") do
        sqlVars[sqlVar] = value
    end
    for param,table,field,sql,getFunc,setFunc in string.gfind (line,"(.*):(.*):(.*):(.*):(.*):(.*)") do
        tr69GlueStaticMap [param] = {}
        tr69GlueStaticMap [param].table = table
        tr69GlueStaticMap [param].field = field
        tr69GlueStaticMap [param].sql = sqlVars[sql] or sql
        tr69GlueStaticMap [param].getFunc = getFunc
        tr69GlueStaticMap [param].setFunc = setFunc
    end
end

local MAC_FILTERING_EDIT = "0"
local MAC_FILTERING_DELETE = "1"
local MAC_FILTERING_DELETE_ALL = "2"

-------------------------------------------------------------------------------
-- @name : tr69Glue.connect
--
-- @description : Connect to the given DB 
--
-- @return : return the DB connection Object.
--
function tr69Glue.connect (dbname)
    return _TR69_DB_env:connect(dbname)
end

local tr69DBConn = tr69Glue.connect("/tmp/cpe3/parameters.db")

-------------------------------------------------------------------------------
-- @name : tr69Glue.disconnect
--
-- @description : Close the database.
--
-- @return : 
--
function tr69Glue.disconnect (_TR69_DB_con)
	_TR69_DB_con:close()
	_TR69_DB_env:close()
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.rollbackTransaction 
--
-- @description : rollback a db transaction
--
-- @return : 
--
function tr69Glue.rollbackTransaction ()
    db.rollback()
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.startTransaction
--
-- @description : begin a db transaction
--
-- @return : 
--
function tr69Glue.startTransaction ()
    db.beginTransaction()
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.commitTransaction
--
-- @description : commit a db transaction
--
-- @return : 
--
function tr69Glue.commitTransaction ()
    db.commitTransaction()
end


-------------------------------------------------------------------------------
-- @name : tr69Glue.execute
--
-- @description : Execute the given query and return the resulting cursor and error message.
--
-- @return : 
--
function tr69Glue.execute (query, _TR69_DB_con)
	cur, errorStr = _TR69_DB_con:execute(query)
	errorStr = errorStr or ""
	if (errorStr ~= "") then
		util.appendDebugOut("DBExecute error message: " .. errorStr .. "<br>")
	end
	if (statusMessage == "" and errorStr ~= "") then
		util.appendDebugOut("statusMessage old = " .. statusMessage .. ", new = " .. errorStr .. "<br>")
		statusMessage = errorStr
	end
	return cur, errorStr
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.AddToInstanceMap
--
-- @description : 
--
-- @return : 
--
function tr69Glue.AddToInstanceMap (name, rowId, staticParam)
    tr69GlueInstanceMap [name] = {}
    tr69GlueInstanceMap [name].rowId = rowId
    tr69GlueInstanceMap [name].staticParam = staticParam
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.getSoftwareVersion 
-- 
-- @description : requests the device for firmwareVer from system
--
-- @return : 
--

-- SoftwareVersion get function
function tr69Glue.getSoftwareVersion (input)
    -- Get function
    local status = "0"
    local value = "0"
    local table = "system"
    local query = "_ROWID_=1"
    local row = {}
    
    row = db.getRowWhere (table, query, false)
    if (row == nil) then
        return "0", " "
    end
    
    if(string.find(input["param"], "SoftwareVersion")) then
        -- Software Version
        value = row["firmwareVer"]
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.setField
--
-- @description : generic set function for updating a field in a table
--
-- @return : 
--
function tr69Glue.setField (intable, rowids)
    for table,value in pairs (intable) do
        status = db.update (table, value, rowids[table])
        -- print ("tr69Glue: updating " .. table)
        if (status == nil) then
            status = -1
            return;
        end
    end
	-- save the set operation.
	SETTINGS_FILE=db.getAttribute("environment", "name", "TEAMF1_CFG_ASCII", "value")
	db.save2()
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.interfaceCheck
--
-- @description : Checks the given interface is a valid interface or not
--
-- @return : 
--

function tr69Glue.interfaceCheck (interface)
    -- load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return 1;
    end

    if(string.len(interface) == 0) then
        return 0;
    end

    local rowId = instanceMap[interface]
    if (rowId == nil) then
        return 1;
    end

    local bridgeTableRow = db.getRow ("bridgeTable", "_ROWID_", rowId)
    if (bridgeTableRow["bridgeTable.interfaceName"] ~= nil) then
        return 0;
    else
        return 1;
    end
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.getMacID
--
-- @description : returns the Instance ID of the MacFilering object and macEventFlag
-- macEventFlag = 0; for Update
-- macEventFlag = 1; for Delete
-- macEventFlag = 2; for Delete All
--
-- @return : 
--

function tr69Glue.getMacID (rowid)
    local value = "0";
    local splitTbl = {}

    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil or rowid == nil or rowid == "") then
        return value
    end

    local query = "_ROWID_='" ..rowid.. "'"
    local macClientRow = db.getRowWhere("clientMacConfig", query, false)

    local name,val
    for name,val in pairs (instanceMap) do
        if(string.find(name, "Device.X_RJIL_MacFiltering.MacFiltering.")) then
            if(tonumber(val) == tonumber(macClientRow["_ROWID_"])) then
                splitTbl = util.split(name, ".")
                value = splitTbl[4]
                break ; 
            end
        end
    end

    local macEventFlag = "0"
    local query = "Deleted=1"
    local macClientRows = db.getRowsWhere("clientMacConfig", query, false)
    local numMacRows = #macClientRows

    if(#macClientRows > 1) then 
        macEventFlag = MAC_FILTERING_DELETE_ALL
    else
        if(macClientRow["Deleted"] == "1") then
            macEventFlag = MAC_FILTERING_DELETE
        else
            macEventFlag = MAC_FILTERING_EDIT
        end
    end

    return value, macEventFlag, numMacRows
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.getMacNotificationVal
--
-- @description : Returns the Notification value of clientMacConfig table
--
-- @return : 
--
function tr69Glue.getMacNotificationVal (rowid)
    local value = "0";
    value = db.getAttribute("clientMacConfig","_ROWID_", rowid, "Notification") 
    return value 
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.getInterfaceName
--
-- @description : gets the Interface Name
--
-- @return : 
--

function tr69Glue.getInterfaceName (interface)
    -- load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return 0;
    end

    local rowId = instanceMap[interface]
    if (rowId == nil) then
        return 1;
    end

    local bridgeTableRow = db.getRow ("bridgeTable", "_ROWID_", rowId)
    if (bridgeTableRow["bridgeTable.interfaceName"] ~= nil) then
        return bridgeTableRow["bridgeTable.interfaceName"]
    else
        return 1;
    end
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.getInterfaceRxStats
--
-- @description : gets the Interface Rx bytes
--
-- @return : 
--

function tr69Glue.getInterfaceRxStats (interface)
    -- load instanceMap
    local value = 0
    local netStatsTbl = {}
    local query = nil

    -- if interface is empty string, use the default interface
    if(string.len(interface) == 0) then
        query = "LogicalIfName='IF1'"
        local bridgeTableRow = db.getRowWhere ("bridgeTable", query, false)
        if (bridgeTableRow["LogicalIfName"] ~= nil) then
            netStatsTbl = ifDevLib.netIfInfoGet(bridgeTableRow["LogicalIfName"])
            value = tonumber(netStatsTbl["rx_bytes"])
            return value
        else
            return value
        end
    end

    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return value
    end

    local rowId = instanceMap[interface]
    if (rowId == nil) then
        return value
    end

    local bridgeTableRow = db.getRow ("bridgeTable", "_ROWID_", rowId)
    if (bridgeTableRow["bridgeTable.LogicalIfName"] ~= nil) then
        netStatsTbl = ifDevLib.netIfInfoGet(bridgeTableRow["bridgeTable.LogicalIfName"])
        value = tonumber(netStatsTbl["rx_bytes"])
        return value
    else
        return value
    end
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.getInterfaceTxStats
--
-- @description : gets the Interface Rx bytes
--
-- @return : 
--

function tr69Glue.getInterfaceTxStats (interface)
    -- load instanceMap
    local value = 0
    local netStatsTbl = {}
    local query = nil

    -- if interface is empty string, use the default interface
    if(string.len(interface) == 0) then
        query = "LogicalIfName='IF1'"
        local bridgeTableRow = db.getRowWhere ("bridgeTable", query, false)
        if (bridgeTableRow["LogicalIfName"] ~= nil) then
            netStatsTbl = ifDevLib.netIfInfoGet(bridgeTableRow["LogicalIfName"])
            value = tonumber(netStatsTbl["tx_bytes"])
            return value
        else
            return value
        end
    end

    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return value
    end

    local rowId = instanceMap[interface]
    if (rowId == nil) then
        return value
    end

    local bridgeTableRow = db.getRow ("bridgeTable", "_ROWID_", rowId)
    if (bridgeTableRow["bridgeTable.LogicalIfName"] ~= nil) then
        netStatsTbl = ifDevLib.netIfInfoGet(bridgeTableRow["bridgeTable.LogicalIfName"])
        value = tonumber(netStatsTbl["tx_bytes"])
        return value
    else
        return value
    end
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.reboot
--
-- @description : requests the device to reboot after delay seconds
--
-- @return : 
--
function tr69Glue.reboot (delay)
    require "teamf1lualib/reboot"
    tr69Glue.tf1Dbg ("Calling Reboot Config ..")
    -- db.setAttribute("reboot", "reboot._ROWID_", "1", "reboot", "1")
    -- db.setAttribute("reboot", "reboot._ROWID_", "1", "rebootTime", delay)
    reboot.rebootConfig (delay)
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.factoryReset
--
-- @description : factory reset the device
--
-- @return : 
--
function tr69Glue.factoryReset()
    require "teamf1lualib/firmware"

    -- remove tr69 persistent data, remove current configuration and send
    -- a signal to reboot the system
    firmware.factoryReset(1)
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.FirmwareCheck
--
-- @description : check the sanity of the provide firmware file
--
-- @return : 
--
function tr69Glue.FirmwareCheck (filename)
    require "teamf1lualib/firmware"

	local UNIT_INFO = db.getAttribute ("webBrandingTags", "_ROWID_", "1", "unitName")

	-- verify if the firmware is valid
    status = firmware.upgrade(filename, 0, 0, 0, " -D ")

	if (UNIT_INFO ~= nil and UNIT_INFO == "ODU") then
		if (status ~= 0) then
			-- check if this is lte firmware
			status = os.execute ("/bin/sh /bin/isLTEFirmware.sh "..filename)
		end
		if (status ~= 0) then
			-- check if this is lte firmware
			status = os.execute ("/bin/sh /bin/isFailSafe.sh "..filename)
		end

	end

    return status
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.FirmwareUpgrade
--
-- @description : upgrade the firmware image in the device and reboot
--
-- @return : 
--
function tr69Glue.FirmwareUpgrade (filename)
    require "teamf1lualib/firmware"

	local UNIT_INFO = db.getAttribute ("webBrandingTags", "_ROWID_", "1", "unitName")

	local statusLTE = 1
	local statusFailsafe = 1

	if (UNIT_INFO ~= nil and UNIT_INFO == "ODU") then
		statusLTE = os.execute ("/bin/sh /bin/isLTEFirmware.sh "..filename)
		statusFailsafe = os.execute ("/bin/sh /bin/isFailSafe.sh "..filename)
		if (statusFailsafe == 0) then
			os.execute ("/sbin/reboot -d 40 &")
			return statusFailsafe
		end
	end



	if (statusLTE == 0) then

		status = firmware.lteUpgrade (filename)

	else

	-- upgrade the firmware
    -- Adding the code for the calculation of md5sum
	local MD5SUM_BIN = "/usr/bin/md5sum"
	local FIRM_MD5_TMP = "/flash/tmp"
	local FIRM_MD5 = "/flash/firmMd5sum"
	local RM = "/bin/rm"
    local UPGRADE_INFO_FILE = "/tmp/upgradeInfo"
    local fp 

    -- executing command to calculate the md5sum of the image
	os.execute(MD5SUM_BIN .." " .. filename .. ">" .. FIRM_MD5_TMP)
	os.execute("cut -d ' ' -f 1" .. " " .. FIRM_MD5_TMP .. ">" .. FIRM_MD5)
	os.execute(RM .. " " ..FIRM_MD5_TMP)


	if (UNIT_INFO ~= nil and UNIT_INFO == "ODU") then
		os.execute("/bin/sh /pfrm2.0/bin/preUpgrade2.sh")
        fp = io.open (UPGRADE_INFO_FILE, "w")
        if (fp ~= nil) then
            fp:close()
        end
	end

-- just a tweak here to start the upgrade process with out reboot. 
    if (util.fileExists ("/pfrm2.0/FIRMWARE_SIGNING_ENABLED1") == true ) then
	status = firmware.upgrade(filename, 0, 0, 0, "-S",2)
    elseif (util.fileExists ("/pfrm2.0/FIRMWARE_SIGNING_ENABLED2") == true ) then
	status = firmware.upgrade(filename, 0, 0, 0, "-S",1)
    else
	status = firmware.upgrade(filename, 0, 0, 0, "-S",0)
    end
	if (UNIT_INFO ~= nil and UNIT_INFO == "ODU") then
        -- stop the keepalive script
        command = "killall -15 tr69KeepAlive.sh"
        tr69Glue.tf1Dbg("script EXEC:  " .. command)
        os.execute(command)

		os.execute ("/sbin/reboot -d 40 &")
	end

	end

    return status
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.configDownload
--
-- @description : updates device with imported configuration
--
-- @return : 
--
function tr69Glue.configDownload (filename, URL)
    tr69Glue.tf1Dbg("Entering tr69Glue.configDownload..")
    
    local inputTable = {}
    local status = "0"
    local statusCode = "OK"
    local urlFileName = ""

    inputTable["file.restore"] = {}
    inputTable["file.restore"]["filename"] = filename
    inputTable["file.restore"]["filesize"] = "0"
    inputTable["file.restore"]["file"] = ""

    -- get file name from URL
    urlTbl = util.split(URL, "/")
    lastColumn = table.getn(urlTbl)
    urlFileName = urlTbl[lastColumn]

    if(string.find (urlFileName, ".enc")) then
        require "teamf1lualib/firmware"

        tr69Glue.tf1Dbg("Calling firmware.tr69Restore..")
        statusCode, errMsg = firmware.tr69Restore (inputTable, urlFileName)
    elseif(string.find (urlFileName, ".xml")) then
        require "teamf1lualib/nimfTrExtn2" 

        tr69Glue.tf1Dbg("Calling gpon set function..")
        statusCode, errMsg = nimfTr.wanGponXmlSet (filename)
    else
        tr69Glue.tf1Dbg("Invalid Config File..")
        statusCode = "ERROR"
    end

    if(statusCode ~= "OK") then
        status = "1"
    end

    tr69Glue.tf1Dbg("Leaving tr69Glue.configDownload..")
    return status
end


-------------------------------------------------------------------------------
-- @name : tr69Glue.getValueFromXml
--
-- @description : read xml file and returns the value
--
-- @return : 
--
function tr69Glue.getValueFromXml (xmlFile, parentObject, childObject, param) 
    -- locals  
    local str
    local val 
    local fp = io.open (xmlFile, "r")
    if (fp == nil) then
        return "ERROR"
    end

    tr69Glue.tf1Dbg("Filename " ..xmlFile.. " Parent " ..parentObject.." ChildObj " .. childObject .. " Param " ..param)
    for line in fp:lines () do
        if (string.find (line, parentObject)) then
            break
        end
    end
    for line in fp:lines () do
        if (string.find (line, childObject)) then
            break
        end
    end
    for line in fp:lines () do
        if (string.find (line, param)) then
            str = line  
            break
        end
    end
    if (str ~= nil) then
        local str = string.gsub (str, param , "")
        str = string.gsub (str, "<" , "")
        str = string.gsub (str, ">" , "")
        str = string.gsub (str, "><" , "")
        str = string.gsub (str, "/" , "")
        str = string.gsub (str, " " , "")
        local tbl = util.split (str, "v=")
		 val = string.gsub (tbl[3], "\"" , "")
		 val = tonumber (val)
    else
        return nil
    end

    return val
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.configUpload
--
-- @description : exports device configuration
--
-- @return : 
--
function tr69Glue.configUpload (filename)
    require "kliteLib"    

	-- export current db state to flash
    db.save2 ()

	if util.fileExists ("/flash/teamf1.cfg.ascii") then
		configFile = "/flash/teamf1.cfg.ascii"
	else
		configFile = "/pfrm2.0/etc/teamf1.cfg.defaults.ascii"
	end

    local tmpConfigFile = "/tmp/teamf1.cfg.ascii"
    if (util.fileExists ("/pfrm2.0/BRCMJCO300") or util.fileExists ("/pfrm2.0/HW_JCO410") or util.fileExists ("/pfrm2.0/HW_JCE410")) then
        if util.fileExists ("/flash/dms_xml/access_conf.xml") then
            dmsConfigFile = "/flash/dms_xml/access_conf.xml"
        else
            dmsConfigFile = "/pfrm2.0/etc/dms_xml/access_conf.xml"
        end

        if util.fileExists ("/flash/dms_xml/dms_descr.xml") then
            dmsConfigFile1 = "/flash/dms_xml/dms_descr.xml"
        else
            dmsConfigFile1 = "/pfrm2.0/etc/dms_xml/dms_descr.xml"
        end

		-- before appending , remove exsisting file
		os.execute("/bin/rm -f "..tmpConfigFile)
    
        local appendCmd = "/bin/cat " .. configFile .. " " .. dmsConfigFile ..  " " .. dmsConfigFile1 .. " >> " .. tmpConfigFile
        os.execute(appendCmd)
    end

    -- Encrypting conf file
    local encKey="/pfrm2.0/etc/server.key"
    local outFile="/tmp/cpe3/config.txt"

    if ((util.fileExists ("/pfrm2.0/BRCMJCO300") or util.fileExists ("/pfrm2.0/HW_JCO410") or util.fileExists ("/pfrm2.0/HW_JCE410")) and (not(util.fileExists ("/pfrm2.0/HW_NO_DMS")))) then
        kliteLib.openssl ("enc", "-aes-128-cbc", "-pass", "file:" .. encKey, "-in", tmpConfigFile, "-out", outFile)
    else
        kliteLib.openssl ("enc", "-aes-128-cbc", "-pass", "file:" .. encKey, "-in", configFile, "-out", outFile)
    end
    os.execute ("cp " .. outFile .."  " .. filename)

    status = 0
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.dbglogUpload
--
-- @description : get dbglogs.tgz
--
-- @return : 
--
function tr69Glue.dbglogUpload (filename)
  
    local command = ""
    local outFile = ""
    local filePathTbl = {}

    command = "/pfrm2.0/bin/lua " .. dbglogAcsScript
    tr69Glue.tf1Dbg("EXEC .." .. command);
    util.runShellCmd(command, nil, nil, nil);
    
    os.execute ("cp " .. dbglogFile .."  " .. filename)

    status = 0
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.getLogs
--
-- @description : creates log file to be exported
--
-- @return : 
--
function tr69Glue.getLogs (filename)
    --Uncomment this when logging is supported in later phases

	db.execute("ATTACH '/tmp/logging.db' AS loggingDB")
    local logs = db.getTable("eventLog", false)
    local s

    local file = io.open(filename,"w")

	if (logs ~= nil) then
	    for k,v in pairs(logs) do
		    s = v["textMessage"]
			file:write(s)
	    end
	end

    file:close()
	db.execute("DETACH '/tmp/logging.db'")

    status = 0
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.logStrGet
--
-- @description : 
--
-- @return : 
--
function tr69Glue.logStrGet ()
	db.execute("ATTACH '/tmp/logging.db' AS loggingDB")
    local logs = db.getTable("eventLog", false)
    value = ""

	if (logs ~= nil) then
	    for k,v in pairs(logs) do
		    value = value .. v["textMessage"] .. "'\n'"
	    end
	end

	db.execute("DETACH '/tmp/logging.db'")
    status = 0

    require "platformLib"

    -- as per tr amendment device log should not exceed 32k bytes
    value = platformLib.checkDvcLogFileSize (value);

    -- strip all non printables before proceeding
    value = platformLib.nonPrintChFilter(value);

    return status, value
end

function tr69Glue.isIpv6Enable()
    local ipv6ConfTbl = {}
    ipv6ConfTbl = db.getTable ("ipConf", false);
    if (ipv6ConfTbl[1]["IPv6Enable"] == "1") then
        return 0;
    else
        return 1;
    end
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.mgmtServerSet
--
-- @description : This function is called to set the following parameters in
-- Device.ManagementServer.
--
-- URL
-- Username
-- Password
-- PeriodicInformInterval
-- DefaultActiveNotificationThrottle
-- ConnectionRequestUsername
-- ConnectionRequestPassword
-- STUNEnable
-- STUNServerAddress
-- STUNServerPort
-- STUNMaximumKeepAlivePeriod
-- STUNMinimumKeepAlivePeriod
--
-- @return : status
--
function tr69Glue.mgmtServerSet (intable, rowids)
    local status = OK
    local query = ""
    local row = {}
    local tr69ConfTbl = {}
    local inRow = {}
    local rebootFlag = "0"
    local statusFlag = "0"
    local DEFAULT_THROTTLE = "10"
    local faultTbl = {}
    local index = 0
     
    local k,v

    query = "_ROWID_=1"
    row = db.getRowWhere ("tr69Config", query, false);
    if(row == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, "Device.ManagementServer.", error_code.INVALID_PARAM_VALUE);
        return status, faultTbl;
    end
    tr69ConfTbl = row

    inRow = intable["tr69Config"]

    -- ACS Status
    if (inRow["tr69Config.tr69Status"] ~= nil) then
        tr69Glue.tf1Dbg("tr69Status has changed..")
        if (inRow["tr69Config.tr69Status"] ~= row["tr69Status"]) then
            rebootFlag = "0"
            statusFlag = "1"
        end
        tr69ConfTbl["tr69Status"] = inRow["tr69Config.tr69Status"]
    end

    -- ACS URL
    if (inRow["tr69Config.URL"] ~= nil) then
        tr69Glue.tf1Dbg("ACS URL has changed..")
        if ((string.match(inRow["tr69Config.URL"], "http:") == nil) and (string.match(inRow["tr69Config.URL"], "https:") == nil)) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, "Device.ManagementServer.URL", error_code.INVALID_PARAM_VALUE);
            tr69Glue.tf1Dbg("Not a valid url, return err..")
	end

        if (inRow["tr69Config.URL"] ~= row["URL"]) then
            rebootFlag = "1"
            tr69Glue.tf1Dbg("Setting reboot flag..")
        end
        os.execute ("touch /flash/urlChangeACS")
        tr69ConfTbl["URL"] = inRow["tr69Config.URL"]
    end

    -- ACS Username
    if (inRow["tr69Config.Username"] ~= nil) then
        if(row["ACSPasswordGeneration"] == "0") then
            tr69Glue.tf1Dbg("ACS username has changed..")
            tr69ConfTbl["Username"] = inRow["tr69Config.Username"]
        elseif(row["ACSPasswordGeneration"] == "1") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, "Device.ManagementServer.Username", error_code.REQUEST_DENIED);
        end
    end

    -- ACS Password
    if(inRow["tr69Config.Password"] ~= nil )then
        if(row["ACSPasswordGeneration"] == "0") then
            tr69Glue.tf1Dbg("ACS Password has changed..")
            tr69ConfTbl["Password"] = inRow["tr69Config.Password"]
        elseif(row["ACSPasswordGeneration"] == "1") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, "Device.ManagementServer.Password", error_code.REQUEST_DENIED);
        end
    end

    -- PeriodicInformEnable
    if(inRow["tr69Config.PeriodicInformEnable"] ~= nil) then
        tr69Glue.tf1Dbg("Periodic Inform Enable has changed..")
        tr69ConfTbl["PeriodicInformEnable"] = inRow["tr69Config.PeriodicInformEnable"]
    end

    -- Periodic Inform Interval
    if (inRow["tr69Config.InformInterval"] ~= nil) then
        if (tonumber(inRow["tr69Config.InformInterval"]) < 60 or tonumber(inRow["tr69Config.InformInterval"]) > 86400) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, "Device.ManagementServer.PeriodicInformInterval", error_code.INVALID_PARAM_VALUE);
        else
            tr69Glue.tf1Dbg("Periodic InformInterval has changed..")
            tr69ConfTbl["InformInterval"] = inRow["tr69Config.InformInterval"]
        end
    end

    -- Periodic Inform Time
    if (inRow["tr69Config.PeriodicInformTime"] ~= nil) then
        tr69Glue.tf1Dbg("Periodic PeriodicInformTime has changed..")
        tr69ConfTbl["PeriodicInformTime"] = inRow["tr69Config.PeriodicInformTime"]
    end

    -- Default ActiveNotification Throttle
    if (inRow["tr69Config.DefaultActiveNotificationThrottle"] ~= nil) then
        if(tonumber(inRow["tr69Config.DefaultActiveNotificationThrottle"]) > 60) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, "Device.ManagementServer.DefaultActiveNotificationThrottle", error_code.REQUEST_DENIED);
        else
            tr69Glue.tf1Dbg("DefaultActiveNotificationThrottle has changed..")
            tr69ConfTbl["DefaultActiveNotificationThrottle"] = inRow["tr69Config.DefaultActiveNotificationThrottle"]
        end
    end

    -- ConnectionRequestUsername
    if (inRow["tr69Config.ConnectionRequestUsername"] ~= nil) then
        tr69Glue.tf1Dbg("ConnectionRequestUsername has changed..")
        tr69ConfTbl["ConnectionRequestUsername"] = inRow["tr69Config.ConnectionRequestUsername"]
    end

    -- ConnectionRequestPassword
    if (inRow["tr69Config.ConnectionRequestPassword"] ~= nil) then
        tr69Glue.tf1Dbg("ConnectionRequestPassword has changed..")
        tr69ConfTbl["ConnectionRequestPassword"] = inRow["tr69Config.ConnectionRequestPassword"]
    end
    
    -- CWMPRetryMinimumWaitInterval
    if (inRow["tr69Config.CWMPRetryMinimumWaitInterval"] ~= nil) then
        if(tonumber(inRow["tr69Config.CWMPRetryMinimumWaitInterval"]) < 1 or tonumber(inRow["tr69Config.CWMPRetryMinimumWaitInterval"]) > 65535) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, "Device.ManagementServer.CWMPRetryMinimumWaitInterval", error_code.INVALID_PARAM_VALUE);
	else
            tr69Glue.tf1Dbg("CWMPRetryMinimumWaitInterval has changed..")
            tr69ConfTbl["CWMPRetryMinimumWaitInterval"] = inRow["tr69Config.CWMPRetryMinimumWaitInterval"]
        end
    end

    -- CWMPRetryIntervalMultiplier
    if (inRow["tr69Config.CWMPRetryIntervalMultiplier"] ~= nil) then
        if(tonumber(inRow["tr69Config.CWMPRetryIntervalMultiplier"]) < 1000 or tonumber(inRow["tr69Config.CWMPRetryIntervalMultiplier"]) > 65535) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, "Device.ManagementServer.CWMPRetryIntervalMultiplier", error_code.INVALID_PARAM_VALUE);
	else
            tr69Glue.tf1Dbg("CWMPRetryIntervalMultiplier has changed..")
            tr69ConfTbl["CWMPRetryIntervalMultiplier"] = inRow["tr69Config.CWMPRetryIntervalMultiplier"]
        end
    end

    -- STUN parameters Configuration
    --
    -- STUNEnable
    if (inRow["tr69Config.STUNEnable"] ~= nil) then
        tr69Glue.tf1Dbg("STUN has been Enabled/Disabled..")
        tr69ConfTbl["STUNEnable"] = inRow["tr69Config.STUNEnable"]
    end  

    -- STUNServerAddress
    if (inRow["tr69Config.STUNServerAddress"] ~= nil) then
        tr69Glue.tf1Dbg("STUN Server Address has been changed ..")
        tr69ConfTbl["STUNServerAddress"] = inRow["tr69Config.STUNServerAddress"]
    end  

    -- STUNUsername
    if (inRow["tr69Config.STUNUsername"] ~= nil) then
        tr69Glue.tf1Dbg("STUN Username has been changed ..")
        tr69ConfTbl["STUNUsername"] = inRow["tr69Config.STUNUsername"]
    end  

    -- STUNPassword
    if (inRow["tr69Config.STUNPassword"] ~= nil) then
        tr69Glue.tf1Dbg("STUN Password has been changed ..")
        tr69ConfTbl["STUNPassword"] = inRow["tr69Config.STUNPassword"]
    end  

    -- UpgradesManaged
    if (inRow["tr69Config.UpgradesManaged"] ~= nil) then
        tr69Glue.tf1Dbg("UpgradesManaged has changed..")
        tr69ConfTbl["UpgradesManaged"] = inRow["tr69Config.UpgradesManaged"]
    end

    -- CRSURLList
    if (inRow["tr69Config.CRSURLList"] ~= nil) then
       tr69ConfTbl["CRSURLList"] = inRow["tr69Config.CRSURLList"]
       local file = io.open("/tmp/tr69URL.txt","w")
       if (file ~= nil) then
          file:write(tr69ConfTbl["CRSURLList"])
          file:close()
       end    
    end

    -- STUNMaximumKeepAlivePeriod
    if (inRow["tr69Config.STUNMaximumKeepAlivePeriod"] ~= nil) then
        tr69Glue.tf1Dbg("STUN STUNMaximumKeepAlivePeriod has been changed ..")
        tr69ConfTbl["STUNMaximumKeepAlivePeriod"] = inRow["tr69Config.STUNMaximumKeepAlivePeriod"]
    end  

    -- STUNMinimumKeepAlivePeriod
    if (inRow["tr69Config.STUNMinimumKeepAlivePeriod"] ~= nil) then
        tr69Glue.tf1Dbg("STUN STUNMinimumKeepAlivePeriod has been changed ..")
        tr69ConfTbl["STUNMinimumKeepAlivePeriod"] = inRow["tr69Config.STUNMinimumKeepAlivePeriod"]
    end  

    if (status == OK) then
       local cnt = 1
       local valid = false

       tr69ConfTbl = util.addPrefix(tr69ConfTbl, "tr69Config.")

       while (not(valid) and cnt <= 100) do
           valid, errorCode = db.update ("tr69Config", tr69ConfTbl, tr69ConfTbl["tr69Config._ROWID_"])
           local tr69Tbl = db.getRowWhere("tr69Config", "_ROWID_=1",false)
           if (not (valid)) then
               tr69Glue.tf1Dbg("updating to db failed, errorCode = " .. errorCode)
               local cmd = "cat /proc/locks"           
               local cmd1 = "ps"                                             
               util.runShellCmd(cmd, "/tmp/lock","/tmp/er_lock", nil)   
               util.runShellCmd(cmd1, "/tmp/ps","/tmp/er_ps", nil) 
               tr69Glue.tf1Dbg ("Iterating for .. " .. cnt)
               cnt = cnt + 1
               os.execute ("usleep 100000")
           end
       end

    -- save the set operation.
	SETTINGS_FILE=db.getAttribute("environment", "name", "TEAMF1_CFG_ASCII", "value")
	db.save2()

    -- reboot the device when url is changed 
       if (rebootFlag == "1") then
        -- remove tr69 persistent data here, not in the beginning
           local cfg = db.getAttribute("environment", "name", "TR69_PERSISTENT_STORE", "value")
           if (cfg ~= nil) then
               os.execute ("rm -Rf " .. cfg)
           end  

           tr69Glue.reboot(10);
       end

       if (statusFlag == "1") then 
           require "teamf1lualib/tr69Mgmt"
           tr69Glue.commitTransaction ()
           tr69Mgmt.stop()
       end
    
    end

    return status, faultTbl;

end

-------------------------------------------------------------------------------
-- @name : tr69Glue.mgmtServerGet
--
-- @description : Get Device.ManagementServer. params from system db
--
-- @return : 
--
function tr69Glue.mgmtServerGet (intable)

   local status = "0"
   local value = " "
   local row = {}
   local rowId
   local param = input["param"]
   local query =  nil 

   local instanceMap =  tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return status, value
    end

    rowId = instanceMap [param]
    if (rowId == nil) then
        return status, value
    end

	query = "_ROWID_=" .. rowId
    row = db.getRowWhere (input["table"], query, false)
	if (row == nil) then
    	return "1" ,"DB_ERROR_TRY_AGAIN"
	end

    if (string.find(input["param"], "URL")) then
        value = row["URL"]
    elseif(string.find(input["param"], "Username")) then
        value = row["Username"]
    elseif(string.find(input["param"], "Password")) then
        value = row["Password"]
    elseif(string.find(input["param"], "ConnectionRequestUsername")) then
        value = row["ConnectionRequestUsername"]
    elseif(string.find(input["param"], "ConnectionRequestPassword")) then
        value = row["ConnectionRequestPassword"]
    elseif(string.find(input["param"], "STUNEnable")) then
        value = row["STUNEnable"]
    elseif(string.find(input["param"], "STUNServerAddress")) then
        value = row["STUNServerAddress"]
    elseif(string.find(input["param"], "STUNUsername")) then
        value = row["STUNUsername"]
    elseif(string.find(input["param"], "STUNPassword")) then
        value = row["STUNPassword"]
    elseif(string.find(input["param"], "CRSURLList")) then
        value = row["CRSURLList"]
    end
    
    return status, value
end

-- load external tr69 functions if available
status, errMsg = pcall(require, 'teamf1lualib/tr69funcs')
if (status == false) then
	print ("Error load tr69funcs: " .. errMsg)
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.stopScripts 
-- 
-- @description : kills the scripts  
--
-- @return : 
--
function tr69Glue.stopScripts(pidFile)
    require "ifDevLib"

    local fp = io.open (pidFile, "r")
    if (fp == nil) then
        return "ERROR"
    end
    local pid = fp:read()
    tr69Glue.tf1Dbg("pid: " .. pid)

    local command = "/bin/kill -15 ".. pid
    local status = 0

    tr69Glue.tf1Dbg("EXEC:  " .. command)
    status = ifDevLib.cmdExec(command, "/dev/null", 1)
    if (status ~= 0) then
        tr69Glue.tf1Dbg("command execution failed with status: " .. status)
    end

    return status
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.startScripts 
-- 
-- @description : starts the scripts
--
-- @return : 
--
function tr69Glue.startScripts(fileName)
    require "ifDevLib"
    local command = "/bin/sh " .. fileName .. " & "
    local status = 0

    tr69Glue.tf1Dbg("EXEC:  " .. command)
    status = ifDevLib.cmdExec(command, "/dev/null", 1)
    if (status ~= 0) then
        tr69Glue.tf1Dbg("command execution failed with status: " .. status)
    end

    return status
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.startLuaScripts 
-- 
-- @description : starts the scripts
--
-- @return : 
--
function tr69Glue.startLuaScripts(fileName)
    require "ifDevLib"
    local command = "/pfrm2.0/bin/lua " .. fileName .. " & "
    local status = 0

    tr69Glue.tf1Dbg("EXEC:  " .. command)
    status = ifDevLib.cmdExec(command, "/dev/null", 1)
    if (status ~= 0) then
        tr69Glue.tf1Dbg("command execution failed with status: " .. status)
    end

    return status
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.ACSAlarmsFaultsGet 
-- 
-- @description : requests the device for ACS Alarms and Faults
--
-- @return : 
--

-- ACSAlarmsFaults get function
function tr69Glue.ACSAlarmsFaultsGet (input)
    -- Get function
    local status = "0"
    local value = "0"
    local table = "ACSAlarmsFaults"
    local query = "_ROWID_=1"
    local row = {}
    local alarmEntries = {}
    local faultEntries = {}
    
    row = db.getRowWhere (table, query, false)
    if (row == nil or row == "") then
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    
    rowAlarmsFaults = db.getRowWhere ("AlarmsFaultsEvents", query, false)
    if (rowAlarmsFaults == nil or rowAlarmsFaults == "") then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    if(string.find(input["param"], "AlarmEnable")) then
        -- AlarmEnable
        value = row["Alarms"]
    elseif(string.find(input["param"], "FaultEnable")) then
        -- FaultEnable
        value = row["Faults"]
    elseif(string.find(input["param"], "AlarmList")) then
        -- AlarmList
        value = rowAlarmsFaults["AlarmList"]
    elseif(string.find(input["param"], "FaultList")) then
        -- FaultList
        value = rowAlarmsFaults["FaultList"]
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.ACSAlarmsFaultsSet
--
-- @description : This function is called to set the following parameters in
-- Device.X_RJIL_COM_AlarmFaultsList.
--
-- Alarms
-- Faults
-- NumberInternetRetries
--
-- @return : status
--

function tr69Glue.ACSAlarmsFaultsSet(input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering ACSAlarmsFaultsSet..")

    local status = OK
    local row = {}
    local query = nil
    local acsRow = {}
    local retries
    local uplinkThreshold
    local downlinkThreshold
    local faultTbl = {}
    local index = 0

    --get corresponding db entry from 'ACSAlarmsFaults'
    query = "_ROWID_=1"
    row = db.getRowWhere ("ACSAlarmsFaults", query, false)
    if(row == nil or row == "") then
        tr69Glue.tf1Dbg("Couldn't fetch corresponding ACSAlarmsFaults row..")
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    acsRow = row

    query = "_ROWID_=1"
    chipsetRow = db.getRowWhere ("chipsetInfo", query, false)
    if(chipsetRow == nil or chipsetRow == "") then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --configure Alarms
    if(input["ACSAlarmsFaults"]["ACSAlarmsFaults.Alarms"] ~= nil) then
        acsRow["Alarms"] = input["ACSAlarmsFaults"]["ACSAlarmsFaults.Alarms"]
        if(acsRow["Alarms"] == "0") then
            os.execute("/bin/rm -rf " .. ALARM_FILE)
        elseif(acsRow["Alarms"] == "1") then
            os.execute ("/bin/touch " .. ALARM_FILE)

            if(chipsetRow["Chipset"] == "Lantiq" or chipsetRow["Chipset"] == "Broadcom" or chipsetRow["Chipset"] == "Marvell") then
                -- restart the internetLed script
                os.execute ("/bin/touch " .. internetScriptRestart)
            
                -- restart the wifiModuleCheck script
                os.execute ("/bin/touch " .. wifiScriptRestart)
            else
                -- restart the signalDegradation script
                tr69Glue.stopScripts(signalDegradationPid)
                tr69Glue.startLuaScripts(signalDegradationScript)
            end
        end
    end

    --configure Faults
    if(input["ACSAlarmsFaults"]["ACSAlarmsFaults.Faults"] ~= nil) then
        acsRow["Faults"] = input["ACSAlarmsFaults"]["ACSAlarmsFaults.Faults"]
        if(acsRow["Faults"] == "0") then
            os.execute("/bin/rm -rf " .. FAULT_FILE)
        elseif(acsRow["Faults"] == "1") then
            os.execute ("/bin/touch " .. FAULT_FILE)
            if(chipsetRow["Chipset"] == "Lantiq" or chipsetRow["Chipset"] == "Broadcom" or chipsetRow["Chipset"] == "Marvell") then
                -- restart the dosAttack script
                os.execute ("/bin/touch " .. dosScriptRestart)
                os.execute ("/bin/touch " .. icmpScriptRestart)
                os.execute ("/bin/touch " .. udpScriptRestart)

                local gponStatus = db.getRowWhere ("gpon", query, false)
                if (gponStatus["status"] == "1") then
                    -- restart the gponLed script
                    os.execute ("/bin/touch " .. gponScriptRestart)
                end

                -- restart the internet recover fault script
                os.execute ("/bin/touch " .. internetRecScriptRestart)
            end
        end
    end

    --setting the new configuration in the table
    acsRow = util.addPrefix (acsRow, "ACSAlarmsFaults.")
    local valid, errstr = db.update("ACSAlarmsFaults", acsRow, "1")
    if (not valid) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    db.save()

    tr69Glue.tf1Dbg("Leaving ACSAlarmsFaultsSet..")
    return status, faultTbl;
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.ACSAlarmsSet
--
-- @description : This function is called to set the following parameters in
-- Device.X_RJIL_COM_AlarmFaultsList.Alarms.{i}.
--
-- UpperLimit
-- LowerLimit
--
-- @return : status
--

function tr69Glue.ACSAlarmsSet(input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering ACSAlarmsSet..")

    local status = OK
    local row = {}
    local rowId
    local query = nil
    local acsRow = {}
    local faultTbl = {}
    local index = 0
 
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --read the rowId mapping to ACSAlarms
    rowId = instanceMap[tr69Param]
    if (rowId == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get corresponding db entry from ACSAlarms
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("ACSAlarms", query, false)
    if(row == nil or row == "") then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end
   
    query = "_ROWID_=1"
    chipsetRow = db.getRowWhere ("chipsetInfo", query, false)
    if(chipsetRow == nil or chipsetRow == "") then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    acsRow = row

    --configure Enable
    if(input["ACSAlarms"]["ACSAlarms.Enable"] ~= nil) then
        acsRow["Enable"] = input["ACSAlarms"]["ACSAlarms.Enable"]
        if(row["AlarmFile"] ~= nil and row["AlarmFile"] ~= "") then
            if(acsRow["Enable"] == "0") then
                os.execute("/bin/rm -rf /tmp/" .. row["AlarmFile"])
            elseif(acsRow["Enable"] == "1") then
                os.execute ("/bin/touch /tmp/" .. row["AlarmFile"])
            end
        end
    end

    --configure UpperLimit
    if(input["ACSAlarms"]["ACSAlarms.UpperLimit"] ~= nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."UpperLimit", error_code.REQUEST_DENIED)
    end

    --configure LowerLimit
    if(input["ACSAlarms"]["ACSAlarms.LowerLimit"] ~= nil) then
        acsRow["LowerLimit"] = input["ACSAlarms"]["ACSAlarms.LowerLimit"]
        if(chipsetRow["Chipset"] == "Lantiq" or chipsetRow["Chipset"] == "Broadcom" or chipsetRow["Chipset"] == "Marvell") then
            if(rowId == "1") then
                local numRetries = tonumber(acsRow["LowerLimit"])
                if((numRetries ~= nil) and (numRetries ~= "") and (numRetries >= 1) and (numRetries <= 5)) then
                    os.execute ("/bin/echo -n "..acsRow["LowerLimit"].." > "..INTERNET_RETRIES.."")
                else
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."LowerLimit", error_code.INVALID_PARAM_VALUE)
                end
            elseif(rowId == "2") then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."LowerLimit", error_code.REQUEST_DENIED)
            end
        else
            if(rowId == "1") then
                os.execute ("/bin/echo -n "..acsRow["LowerLimit"].." > "..SIGNAL_VALUE.."")
            elseif(rowId == "2") then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."LowerLimit", error_code.REQUEST_DENIED)
            end
        end
    end

    if (status == ERROR) then
        return status, faultTbl
    end

    --setting the new configuration in the table
    acsRow = util.addPrefix (acsRow, "ACSAlarms.")
    local valid, errstr = db.update("ACSAlarms", acsRow, acsRow["ACSAlarms._ROWID_"])
    if (not valid) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    db.save()

    tr69Glue.tf1Dbg("Leaving ACSAlarmsSet..")
    return status, faultTbl;
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.ACSFaultsSet
--
-- @description : This function is called to set the following parameters in
-- Device.X_RJIL_COM_AlarmFaultsList.Faults.{i}.
--
-- UpperLimit
-- LowerLimit
--
-- @return : status
--

function tr69Glue.ACSFaultsSet(input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering ACSFaultsSet..")

    local status = OK
    local row = {}
    local rowId
    local query = nil
    local acsRow = {}
    local signalVal
    local faultTbl = {}
    local index = 0
 
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --read the rowId mapping to ACSFaults
    rowId = instanceMap[tr69Param]
    if (rowId == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get corresponding db entry from ACSFaults
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("ACSFaults", query, false)
    if(row == nil or row == "") then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end
    
    acsRow = row

    --configure Enable
    if(input["ACSFaults"]["ACSFaults.Enable"] ~= nil) then
        acsRow["Enable"] = input["ACSFaults"]["ACSFaults.Enable"]
        if(row["FaultFile"] ~= nil and row["FaultFile"] ~= "") then
            if(acsRow["Enable"] == "0") then
                os.execute("/bin/rm -rf /tmp/" .. row["FaultFile"])
            elseif(acsRow["Enable"] == "1") then
                os.execute ("/bin/touch /tmp/" .. row["FaultFile"])
            end
        end
    end

    --configure UpperLimit
    if(input["ACSFaults"]["ACSFaults.UpperLimit"] ~= nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."UpperLimit", error_code.REQUEST_DENIED)
    end

    --configure LowerLimit
    if(input["ACSFaults"]["ACSFaults.LowerLimit"] ~= nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."LowerLimit", error_code.REQUEST_DENIED)
    end

    if (status == ERROR) then
        return status, faultTbl
    end

    --setting the new configuration in the table
    acsRow = util.addPrefix (acsRow, "ACSFaults.")
    local valid, errstr = db.update("ACSFaults", acsRow, acsRow["ACSFaults._ROWID_"])
    if (not valid) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    db.save()

    tr69Glue.tf1Dbg("Leaving ACSFaultsSet..")
    return status, faultTbl;
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.validateBridgeVlanDelete
--
-- @description : check the sanity of the provide firmware file
--
-- @return : 
--
function tr69Glue.validateBridgeVlanDelete (rowId)
    local status = "0" 
    local vlanID = ""
    local isbridgeModeVlanExist

    -- Check here to see if the bridgeModeVlan is in use
    vlanID = db.getAttribute ("bridgeModeVlan", "_ROWID_", rowId, "vlanID")
    if(vlanID == nil or vlanID == "") then
        tr69Glue.tf1Dbg ("bridgeModeVlan delete failed ..")
        return "1"
    end
    
    -- check if the schedule is being used in an IPv4 Firewall Rules
    isbridgeModeVlanExist = db.existsRowWhere("bridgeMode", "vlanID = '" .. vlanID .. "'")
    if (isbridgeModeVlanExist) then
        tr69Glue.tf1Dbg ("bridgeModeVlan " .. vlanID .. " is in use.")
        return "1"
    end

    return status
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.validatedhcpv6ServerPoolsDelete
--
-- @description : delete rows from ipv6PrefixTable, dhcpv6sLANPrefixPool and dhcpv6sLANAddrPool
-- when row from dhcpv6ServerPools is deleted
--
-- @return : 
--
function tr69Glue.dhcpv6ServerPoolsDelete (rowId)
    local status = "0"
    local delegationPrefix = ""
    local startAddress = ""

    local query = "_ROWID_="..rowId
    dhcpv6ServerPoolsRow = db.getRowWhere ("dhcpv6ServerPools", query, false)

    if(dhcpv6ServerPoolsRow["serverPoolType"] == "IAPD") then
        -- delete from dhcpv6sLANPrefixPool table
        delegationPrefix = db.getAttribute("dhcpv6sLANPrefixPool", "delegationPrefix", dhcpv6ServerPoolsRow["prefixPoolAddress"], "delegationPrefix")
        valid = db.deleteRow ("dhcpv6sLANPrefixPool", "delegationPrefix", delegationPrefix)
        if(valid == nil) then
            tr69Glue.tf1Dbg ("dhcpv6sLANPrefixPool delete failed..")
            return "1"
        end

        -- delete from ipv6PrefixTable table
        delegationPrefix = db.getAttribute("ipv6PrefixTable", "delegationPrefix", dhcpv6ServerPoolsRow["prefixPoolAddress"], "delegationPrefix")
        valid = db.deleteRow ("ipv6PrefixTable", "delegationPrefix", delegationPrefix)
        if(valid == nil) then
            tr69Glue.tf1Dbg ("IAPD ipv6PrefixTable delete failed..")
            return "1"
        end
    end
   
    if(dhcpv6ServerPoolsRow["serverPoolType"] == "IANA") then
        -- delete from dhcpv6sLANAddrPool table
        startAddress = db.getAttribute("dhcpv6sLANAddrPool", "startAddress", dhcpv6ServerPoolsRow["addrPoolAddress"], "startAddress")
        valid = db.deleteRow ("dhcpv6sLANAddrPool", "startAddress", startAddress)
        if(valid == nil) then
            tr69Glue.tf1Dbg ("dhcpv6sLANAddrPool delete failed..")
            return "1"
        end

        -- delete from ipv6PrefixTable table
        startAddress = db.getAttribute("ipv6PrefixTable", "startAddress", dhcpv6ServerPoolsRow["addrPoolAddress"], "startAddress")
        valid = db.deleteRow ("ipv6PrefixTable", "startAddress", startAddress)
        if(valid == nil) then
            tr69Glue.tf1Dbg ("IANA ipv6PrefixTable delete failed..")
            return "1"
        end
    end

    require "teamf1lualib/service"
    service.restart("dhcpv6s", "1")

    return status
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.validateVlanTerminationDelete
--
-- @description : check the sanity of the provide firmware file
--
-- @return : 
--
function tr69Glue.validateVlanTerminationDelete (rowId)
    require "teamf1lualib/ethernet"
    require "teamf1lualib/swMgr"
    require "teamf1lualib/bridgeLib"

    local status = "0"
    local networkName = "LAN"
    local inputTable = {}
    inputTable["rowid"] = rowId

    if (networkName == "LAN") then
        for k,v in pairs (inputTable) do
            local vlanRow = db.getRow ("vlanEncapIf", "_ROWID_", v)
            if (vlanRow == nil) then
                tr69Glue.tf1Dbg ("VLAN_DELETE_FAILED..")
                return "1"
            end
            if  (vlanRow["vlanEncapIf.vlanId"] == "1") then
                tr69Glue.tf1Dbg ("DEFAULT_VLAN_CANNOT_BE_DELETED..")
                return "1"
            end
            
            if (vlanRow["vlanEncapIf.untagMap"] ~= "") then
                tr69Glue.tf1Dbg ("SELECTED_VLAN_IS_SET_AS_DEFAULT..")
                return "1"
            end
        end
        
        -- all sanity checks are done, do the delete
        for k,v in pairs (inputTable) do
            local vlanRow = db.getRow ("vlanEncapIf", "_ROWID_", v)
            local LogicalIfName = vlanRow["vlanEncapIf.LogicalIfName"]
            local iface = db.getAttribute ("ethernet", "LogicalIfName", LogicalIfName, "interfaceName")
            local vconf = {}
            local bridgeName= bridge.ifNameGet(LogicalIfName)
            vconf[1] = {}
            vconf[1]["ifname"] =  iface.."."..vlanRow["vlanEncapIf.vlanId"]
            statusCode, errorCode = bridge.portDelete(bridgeName, vconf)
            statusCode, errCode = swMgr.dbConfig ("vlanEncapIf", vlanRow, "" , "delete")
        end
    elseif (networkName == "WAN") then
        statusCode, errCode = ethernetVLAN.ethernetVLAN_config (inputTable, "-1", "delete")
    end

    if(statusCode == "OK")then
        status = "0"
    else
        tr69Glue.tf1Dbg ("configuration failed..")
        status = "1"
    end

    return status
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.routeDeleteCheck
--
-- @description : checks if route to be deleted is default or RIP routes
--
-- @return : ERROR if route is default or RIP route, else SUCCESS
--
function tr69Glue.routeDeleteCheck (rowId)
    local status = "0"
    local delegationPrefix = ""
    local startAddress = ""

    local query = "_ROWID_="..rowId
    routeRow = db.getRowWhere ("route", query, false)

    if(routeRow["routeType"] == "1" or routeRow["routeType"] == "2") then
        tr69Glue.tf1Dbg ("cannot delete default or RIP routes..")
        return "1"
    end

    return status
end

----------------------------------------------------------------------
-- @name tr69Glue.freeMemCheck ()
--
-- @description This function checks the available free Memory in system 
-- before actual download of firmware starts.
--
-- @return "0" on SUCCESS
-- "-1",  on FAILURE
----------------------------------------------------------------------
function tr69Glue.freeMemCheck ()
    -- include
    require "teamf1lualib/util"

    --locals
    local status = "NO"
    local psKilledStatus = "NO"
    local ret = "0"
    local psKilledStatusRet = "0"

    status, psKilledStatus = util.freeMemCheck ()    
    if (status ~= "YES") then
        ret = "-1"
    end
    if (psKilledStatus == "YES") then
        psKilledStatusRet = "-1"
    end
    
    return ret, psKilledStatusRet 
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.getVendorConfigFileInfo
--
-- @description : gets the VendorConfigFile details
--
-- @return : 
--
function tr69Glue.getVendorConfigFileInfo (vendorLogInstanceId)
    local fileName = ""
    local filePath = ""
    local command = ""
    local vendorConfigFileName = ""
    local vendorLogFileParamPath = "Device.DeviceInfo.VendorConfigFile."..vendorLogInstanceId.."."
        
    -- load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return filePath, fileName
    end

    --read the rowId mapping to Device.DeviceInfo.VendorConfigFile.
    local rowId = instanceMap[vendorLogFileParamPath]
    if (rowId == nil) then
        return filePath, fileName
    end

    vendorConfigFileName = db.getAttribute ("VendorConfigFile", "_ROWID_", rowId, "Name")

    if(vendorConfigFileName == "reliance.enc") then
        require "teamf1lualib/tr69Mgmt"

        deviceSerial = tr69Mgmt.serialNumRetrieve()
        prodClass = tr69Mgmt.productClassRetrieve()

        if(deviceSerial ~= nil and deviceSerial ~= "" and prodClass ~= nil and prodClass ~= "") then
            filePath = "/tmp/cpe3/"..deviceSerial.."_"..prodClass
            fileName = deviceSerial.."_"..prodClass
        end
    end

    return filePath, fileName
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.getVendorLogFileInfo
--
-- @description : gets the VendorLogFile details
--
-- @return : 
--
function tr69Glue.getVendorLogFileInfo (vendorLogInstanceId)
    local fileName = ""
    local filePath = ""
    local command = ""
    local vendorLogFilePath = ""
    local vendorLogFileParamPath = "Device.DeviceInfo.VendorLogFile."..vendorLogInstanceId.."."
        
    -- load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return filePath, fileName
    end

    --read the rowId mapping to Device.DeviceInfo.VendorLogFile.
    local rowId = instanceMap[vendorLogFileParamPath]
    if (rowId == nil) then
        return filePath, fileName
    end

    vendorLogFilePath = db.getAttribute ("VendorLogFile", "_ROWID_", rowId, "Name")

    if (vendorLogFilePath ~= nil) then
        filePath = vendorLogFilePath
    end
        
    if(filePath == dbglogFile) then
        fileName = dbglogFileName
        filePathTbl = util.split(filePath, ".")
        filePath = filePathTbl[1]
    end

    return filePath, fileName
end

function tr69Glue.masterCtrlServiceSet (input, rowids, actionType, tr69Param)

    tr69Glue.tf1Dbg("Entering masterCtrlServiceSet.")

    local status = "0"
    local row = {}
    local query = nil
    local masterCtrlRow = {}
    local voipEnable
    local voipChanged
    local status, errMsg

    --get corresponding db entry from 'ACSAlarmsFaults'
    query = "_ROWID_=1"
    row = db.getRowWhere ("MasterCtrlThirdParty", query, false)
    if(row == nil) then
        tr69Glue.tf1Dbg("Couldn't fetch corresponding MasterCtrlThirdParty row..")
        status = "1"
        return "1";
    end

    masterCtrlRow = row
    -- configure voip
    if(input["MasterCtrlThirdParty"]["MasterCtrlThirdParty.VoIPSubscribed"] ~= nil) then
        voipEnable = input["MasterCtrlThirdParty"]["MasterCtrlThirdParty.VoIPSubscribed"]
        if (tonumber(masterCtrlRow["VoIPSubscribed"]) ~= tonumber(voipEnable)) then
            masterCtrlRow["VoIPSubscribed"] = voipEnable
            voipChanged = 1
        end
    end
    
   if (voipChanged) then
        --setting the new configuration in the table
        masterCtrlRow = util.addPrefix (masterCtrlRow, "MasterCtrlThirdParty.")
        local valid, errstr = db.update("MasterCtrlThirdParty", masterCtrlRow, "1")
        if (not valid) then
            tr69Glue.tf1Dbg("Couldn't update MasterCtrlThirdParty row..")
            status = "1"
            return "1";
        end
    end

   db.save()

   tr69Glue.tf1Dbg("Leaving masterCtrlServiceSet.") 

end

function tr69Glue.masterCtrlServiceGet (input)
    -- Get function
    local status = "0"
    local value = "0"
    local rowId
    local row = {}
    local query = nil
    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --read the rowId mapping to ACSAlarms
    rowId = instanceMap[param]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from ACSAlarms
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("MasterCtrlThirdParty", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end


    if(string.find(input["param"], "VoIPSubscribed")) then
        -- Enable
        value = row["VoIPSubscribed"]
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

-------------------------------------------------------------------------------
-- @name : tr69Glue.setEthernetPriority
--
-- @description : sets the ethernet priority for diagnostics
--
-- @return : OK/ERROR 
--
function tr69Glue.setEthernetPriority(priority, command, protocol, interface)
    local status = OK
    local vlans = {}
    local index = 0
    local flag
    local interfaceName = ""
    local cmd = ""
    local iptableCmd = ""
    local gponStatus = ""
    local ifgroup = ""

    if (priority == nil or priority == "" or command == nil or command == "") then
        tr69Glue.tf1Dbg("priority/command received null..");
        status = ERROR
        return status
    end

    if(protocol == "" or protocol == nil or interface == "" or interface == nil) then
        tr69Glue.tf1Dbg("protocol/interface received null..");
        status = ERROR
        return status
    end

    if(tostring(command) == "delete") then
        flag = "-D"
    else
        flag = "-I"
    end

    if(tostring(protocol) == "IPv4") then
       iptableCmd = "iptables"
    else
       iptableCmd = "ip6tables"
    end

    if (tostring(interface) == "IF1") then
        ifgroup = "0x2/0x2"
    elseif (tostring(interface) == "IF2") then
        ifgroup = "0x1/0x1"
    end

    cmd = iptableCmd.." "..flag.." POSTROUTING -t mangle -m ifgroup --ifgroup-out "..ifgroup.." -j CLASSIFY --set-class 0:"..priority
    tr69Glue.tf1Dbg("qos classify cmd - "..cmd);
    util.runShellCmd(cmd, nil, nil, nil);

    local chipsetRow = db.getRowWhere("chipsetInfo", "_ROWID_=1", false)
    if(chipsetRow["Chipset"] == "Broadcom") then
        tr69Glue.tf1Dbg("Chipset is Broadcom");
        return status
    end

    interfaceName = db.getAttribute("ethernet", "LogicalIfName", interface, "interfaceName")
    if (interfaceName == nil or interfaceName == "") then
        tr69Glue.tf1Dbg("Interaface Name not found. Returning..");
        status = ERROR
        return status
    end
    tr69Glue.tf1Dbg("interface name "..interfaceName)

    -- If Ethernet priority set on WAN interface, read gpon table for PON/GPON
    -- interfaces or ethernetVLAN table for ethernet interfaces
    if (tostring(interface) == "IF1") then
        gponStatus = db.getAttribute("gpon", "_ROWID_", "1", "status")
        if (gponStatus == "1") then
            local vlanId = db.getAttribute("gpon", "_ROWID_", "1", "vlanID")
            if (vlanId == nil or vlanId == "") then
                tr69Glue.tf1Dbg("VLAN id not found for gpon. Returning..");
                status = OK
                return status
            end
            cmd = "vconfig set_egress_map "..interfaceName.."."..vlanId.." "..priority.." "..priority
            tr69Glue.tf1Dbg("Command: "..cmd);
            util.runShellCmd(cmd, nil, nil, nil);
            return status
        else
            -- If Trunk Mode VLAN is enabled
            vlans = db.getTable("ethernetVLAN", false)
            if (vlans == nil or vlans == "") then
                tr69Glue.tf1Dbg("VLANS not found in ethernetVLAN. Returning..");
                status = OK
                return status
            end
        end
    end

    -- If VLAN is enabled on LAN interface
    if (tostring(interface) == "IF2") then
       vlans = db.getTable("vlanEncapIf", false)
       if (vlans == nil or vlans == "") then
          tr69Glue.tf1Dbg("VLANS not found in vlanEncapIf. Returning..");
          status = OK
          return status
       end
    end

    for index in pairs(vlans) do
        if (tostring(command) == "delete") then
           cmd = "vconfig set_egress_map "..interfaceName.."."..vlans[index]["vlanId"].." "..priority.." 0 "
        else
           cmd = "vconfig set_egress_map "..interfaceName.."."..vlans[index]["vlanId"].." "..priority.." "..priority
        end
        if (vlans[index]["vlanId"] ~= 1) then
           tr69Glue.tf1Dbg("Command: "..cmd);
           util.runShellCmd(cmd, nil, nil, nil);
        else
           tr69Glue.tf1Dbg("Not adding rule for vlan id "..vlans[index]["vlanId"].." ")
        end
    end


    return status

end

--[[
--*****************************************************************************
-- tr69Glue.vendorLogFileGet - get vendor log file parameters
-- 
-- This function is called to get the following parameters in
-- Device.DeviceInfo.vendorConfigFileGet.0.
--
-- Name
-- MaximumSize 
-- Persistent
-- 
-- Returns: status, value
]]--
function tr69Glue.vendorConfigFileGet(input)
    local status = "0"
    local value = "0"
    local row = {}
    local query = nil
    local param = input["param"]
    local macSplit = {}
    local macStr = ""

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", value
    end

    --read the rowId mapping to Device.DeviceInfo.vendorConfigFile.0.
    rowId = instanceMap[param]
    if (rowId == nil) then
        return "1", value
    end

    query = "_ROWID_=" ..rowId
    row = db.getRowWhere ("vendorConfigFile", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    query = "_ROWID_=1"
    systemRow = db.getRowWhere ("system", query, false)
    if(systemRow == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    if(string.find(input["param"], "Name")) then
        -- Name
        if(row["Name"] == "reliance.enc") then
            require "teamf1lualib/tr69Mgmt"

            deviceSerial = tr69Mgmt.serialNumRetrieve()
            prodClass = tr69Mgmt.productClassRetrieve()

            if(deviceSerial ~= nil and deviceSerial ~= "" and prodClass ~= nil and prodClass ~= "") then
                value = deviceSerial.."_"..prodClass..".enc"
            else
                value = ""
            end
        else
            value = row["Name"] 
        end
    elseif(string.find(input["param"], "Version")) then
        -- Version
        val = util.split(systemRow["firmwareVer"], ".")
        value = val[2]
    elseif(string.find(input["param"], "Description")) then
        -- Description
        value = row["Description"] 
    elseif(string.find(input["param"], "UseForBackupRestore")) then
        -- UseForBackupRestore
        value = row["UseForBackupRestore"] 
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- tr69Glue.servicesRestart - restart services for process
--
-- Returns: 0 
]]--
function tr69Glue.servicesRestart(input)
    require "teamf1lualib/service"
        
    tr69Glue.tf1Dbg ("input : ".. input)

    if((string.find(input, "Device.IP.Interface.") and string.find(input, "IPv6Prefix.") and util.fileExists("/tmp/restartDhcpv6s")) or (string.find(input, "Device.DHCPv6.Server."))) then
        tr69Glue.tf1Dbg ("restarting  dhcpv6s ..")
        service.restart("dhcpv6s", "1") 
        os.remove("/tmp/restartDhcpv6s")
    elseif((string.find(input, "Device.DHCPv4.Server.Pool.")) and (string.find(input, "StaticAddress."))) then
        -- re-write configuration and restart the DHCP server.
        tr69Glue.tf1Dbg ("restarting  dhcpd ..")
        service.restart("dhcpd", "1") 
    elseif((string.find(input, "Device.RouterAdvertisement.InterfaceSetting.") and string.find(input, "Option.")) or (util.fileExists("/tmp/restartRadvd"))) then
        -- re-write configuration and restart the radvd service.
        tr69Glue.tf1Dbg ("restarting  radvd ..")
        service.restart("radvd", "1")
        os.remove("/tmp/restartRadvd")
    end

    return 0;
end
