--[[
#### Copyright (c) 2014-2015, TeamF1 Networks Pvt. Ltd. 
#### (Subsidiary of D-Link India)
#### 
#### File: iputilsTrExtn.lua
#### Description: 
#### TR-181 handlers for diagnostics. This file is included from
#### tr69Glue code.
####
#### Revisions:
01i,06Dec16,sda  Changes for SPR 59425.
01h,06Dec16,swr  Changes for SPR 58454.
01g,11Mar16,swr  Changes for SPR 55407.
01f,02Feb16,swr  Changes for SPR 54833.
01e,20Nov15,srm  Changes for SPR 51848.
01d,02Nov15,swr  Changes for SPR 53930.
01c,13Feb15,swr  changes for IPPing Diagnostics.
01b,28Jan15,swr  changes for SPR 49275.
01a,21Jan15,swr  changes for SPR 49275.
]]--

iputilsTr = {}

function iputilsTr.pingDiagnosticsErr()
    local outRow = {}

    --Update the results to db
    outRow["PingDiagnostics.AverageResponseTime"] = "0"
    outRow["PingDiagnostics.MaximumResponseTime"] = "0"
    outRow["PingDiagnostics.MinimumResponseTime"] = "0"
    outRow["PingDiagnostics.DiagnosticsState"] = "Error_CannotResolveHostName"
    outRow["PingDiagnostics.FailureCount"] = "0"
    outRow["PingDiagnostics.SuccessCount"] = "0"

    db.update ("PingDiagnostics", outRow, "1")
end

function iputilsTr.pingDiagnosticsTimeoutErr()
    local outRow = {}

    --Update the results to db
    outRow["PingDiagnostics.AverageResponseTime"] = "0"
    outRow["PingDiagnostics.MaximumResponseTime"] = "0"
    outRow["PingDiagnostics.MinimumResponseTime"] = "0"
    outRow["PingDiagnostics.DiagnosticsState"] = "Error_Internal"
    outRow["PingDiagnostics.FailureCount"] = "0"
    outRow["PingDiagnostics.SuccessCount"] = "0"

    db.update ("PingDiagnostics", outRow, "1")
end

function iputilsTr.runPingDiagnostics()
    require "teamf1lualib/nimf"

    local query = "_ROWID_='1'"
    local ipAddressQuery
    local pingDiagRow = db.getRowWhere ("PingDiagnostics", query, false);
    local qryRow = {}
    local qryStatus = ""
    local wanDefConn = {}
    local interfaceIPaddr = {}
    local outRow = {}

    --Start the ping diagnostics program. This call should return after the
    --diagnostics is done.
    local cmd = "/pfrm2.0/bin/doPing " .. pingDiagRow["Host"]
    local timeOut = pingDiagRow["Timeout"] / 1000
    cmd = cmd .. " -c " .. pingDiagRow["NumberOfRepetitions"] .. " -w " .. pingDiagRow["NumberOfRepetitions"] .. " -W " .. timeOut
    cmd = cmd .. " -s " .. pingDiagRow["DataBlockSize"] .. " -Q " .. pingDiagRow["DSCP"]

    --Using tr-69 interface parameter determine the device and get the interface
    --IP to use while calling doPing with -I option.
    if (string.len (pingDiagRow["Interface"]) == 0) then
        ipAddressQuery = "LogicalIfName='IF1'" .. "and addressFamily=2"
    else
        ipAddressQuery = "LogicalIfName='".. pingDiagRow["Interface"] .."'" .. "and addressFamily=2"
    end
    interfaceIPaddr = db.getRowWhere ("ipAddressTable", ipAddressQuery, false)
    if(interfaceIPaddr == nil) then
        iputilsTr.pingDiagnosticsErr()
        return
    end

    cmd = cmd .. " -I " .. interfaceIPaddr["ipAddress"]
    tr69Glue.tf1Dbg ("TF1 : Command " .. cmd )
    os.execute ("echo " .. cmd .. " > /var/doPing.cmd")
    --stat = os.execute (cmd)
    stat = util.runShellCmd(cmd, nil, "/var/pingErrOutput.txt", nil)
   
    local file = io.open("/var/pingErrOutput.txt", "r") 
    local line = file:read()
    file:close()
    if(line == "ping: bad linger time.") then
        iputilsTr.pingDiagnosticsTimeoutErr()
        return
    end

    --Update the results to db
    sval,serrcode = pcall (loadfile ("/var/doping.out"))
    if (sval) then
        dofile ("/var/doping.out")

        outRow["PingDiagnostics.DiagnosticsState"] = diag["DiagnosticsState"]
        outRow["PingDiagnostics.FailureCount"] = diag["FailureCount"]
        outRow["PingDiagnostics.SuccessCount"] = diag["SuccessCount"]
        if (outRow["PingDiagnostics.SuccessCount"] == "0") then
            outRow["PingDiagnostics.AverageResponseTime"] = "0"
            outRow["PingDiagnostics.MaximumResponseTime"] = "0"
            outRow["PingDiagnostics.MinimumResponseTime"] = "0"
        else
            outRow["PingDiagnostics.AverageResponseTime"] = diag["AverageResponseTime"]
            outRow["PingDiagnostics.MaximumResponseTime"] = diag["MaximumResponseTime"]
            outRow["PingDiagnostics.MinimumResponseTime"] = diag["MinimumResponseTime"]        
        end
        db.update ("PingDiagnostics", outRow, "1")
    else
        iputilsTr.pingDiagnosticsErr()
        return
    end
end

function iputilsTr.PingDiagnosticsHandler(inTable)
    local inRow = inTable["PingDiagnostics"]
    local rowId = ""
    local ifaceRow = {}
    local logicalIfName = ""
    local diagReqFlag = 0
    local status = "0"

    os.execute ("rm -rf /var/doping.out");
    os.execute ("rm -rf /var/doPing.cmd");
    os.execute ("rm -rf /var/pingErrOutput.txt");

    --check diagnostics state
    if(inRow["PingDiagnostics.DiagnosticsState"] ~= nil) then
        --When writing, the only allowed value is Requested.
       if(inRow["PingDiagnostics.DiagnosticsState"] == "Requested") then
           --set diagReqFlag
           diagReqFlag = 1
       else
           --Unknown state, do no change in CPE
           return error_code.INVALID_PARAM_VALUE;
       end
    end

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return 0;
    end

    --update db with new values
    if (inRow["PingDiagnostics.InterfaceObject"] ~= nil) then
        if (string.len (inRow["PingDiagnostics.InterfaceObject"]) == 0) then
            inRow["PingDiagnostics.InterfaceObject"] = ""
            inRow["PingDiagnostics.Interface"] = "IF1"
        else
            local len = string.len (inRow["PingDiagnostics.InterfaceObject"])
            local interfaceStr = string.sub(inRow["PingDiagnostics.InterfaceObject"],1,len-1)
            if ("Device.IP.Interface." ~= interfaceStr) then
                return error_code.INVALID_PARAM_VALUE;
            end

            local mapInterfaceObj = inRow["PingDiagnostics.InterfaceObject"] .. "."

            rowId = instanceMap[mapInterfaceObj]
            if (rowId == nil) then
                return error_code.INVALID_PARAM_VALUE;
            end

            logicalIfName = db.getAttribute ("bridgeTable", "_ROWID_", rowId, "LogicalIfName")
            if (logicalIfName ~= nil) then
                inRow["PingDiagnostics.Interface"] = logicalIfName
            else
                iputilsTr.pingDiagnosticsErr()
                return
            end
        end
    end

    if (inRow["PingDiagnostics.Host"] ~= nil) then
        if (string.len (inRow["PingDiagnostics.Host"]) == 0) then
            return error_code.INVALID_PARAM_VALUE;
        end
    end

    if (inRow["PingDiagnostics.NumberOfRepetitions"] ~= nil) then
        if (tonumber (inRow["PingDiagnostics.NumberOfRepetitions"]) < 1) then
            return error_code.INVALID_PARAM_VALUE;
        end
    end

    if (inRow["PingDiagnostics.Timeout"] ~= nil) then
        if (tonumber (inRow["PingDiagnostics.Timeout"]) < 1) then
            return error_code.INVALID_PARAM_VALUE;
        end
    end

    if (inRow["PingDiagnostics.DataBlockSize"] ~= nil) then
        if ((tonumber (inRow["PingDiagnostics.DataBlockSize"]) < 1)  or (tonumber (inRow["PingDiagnostics.DataBlockSize"]) > 65535)) then
            return error_code.INVALID_PARAM_VALUE;
        end
    end

    if (inRow["PingDiagnostics.DSCP"] ~= nil) then
        if ((tonumber (inRow["PingDiagnostics.DSCP"]) < 0)  or (tonumber (inRow["PingDiagnostics.DSCP"]) > 63)) then
            return error_code.INVALID_PARAM_VALUE;
        end
    end

    db.update ("PingDiagnostics", inRow, "1")
    --Do NOT perform db.save here. PingDiagnostics tbl is not meant to be
    --persistent across reboot

    --if state is "Requested", run diagnostics & update results to db
    if(diagReqFlag == 1) then
        iputilsTr.runPingDiagnostics()
    end
end

function iputilsTr.traceRouteDiagnosticsErr()
    local outRow = {}

    --Update the results to db
    outRow["TraceRouteDiagnostics.ResponseTime"] = "0"
    outRow["TraceRouteDiagnostics.DiagnosticsState"] = "Error_CannotResolveHostName"

    db.update ("TraceRouteDiagnostics", outRow, "1")
end

function iputilsTr.runTraceRouteDiagnostics()
    require "teamf1lualib/nimf"

    local query = "_ROWID_='1'"
    local ipAddressQuery
    local tracerouteDiagRow = db.getRowWhere ("TraceRouteDiagnostics", query, false);
    local qryRow = {}
    local qryStatus = ""
    local wanDefConn = {}
    local interfaceIPaddr = {}
    local outRow = {}

    --kill traceroute
    os.execute("/usr/bin/killall traceroute")

    --Start the traceroute diagnostics program. This call should return after the
    --diagnostics is done.
    local timeout = tonumber(tracerouteDiagRow["Timeout"]) / 1000
    local cmd = "(" .. "time /usr/bin/traceroute " .. tracerouteDiagRow["Host"]
    cmd = cmd .. " -q " .. tracerouteDiagRow["NumberOfTries"] .. " -w " .. timeout .. " -t " .. tracerouteDiagRow["DSCP"]
    cmd = cmd .. " -m " .. tracerouteDiagRow["MaxHopCount"] .. " " .. tracerouteDiagRow["DataBlockSize"] .. ")" .. "2> /var/trRespTime.txt"

    --Using tr-69 interface parameter determine the device and get the interface
    --IP to use while calling doPing with -I option.
    ipAddressQuery = "LogicalIfName='".. tracerouteDiagRow["Interface"] .."'" .. "and addressFamily=2"
    interfaceIPaddr = db.getRowWhere ("ipAddressTable", ipAddressQuery, false)
    if(interfaceIPaddr == nil) then
        iputilsTr.pingDiagnosticsErr()
        return
    end

    --cmd = cmd .. " -s " .. interfaceIPaddr["ipAddress"]
    --tr69Glue.tf1Dbg ("TF1 : Command " .. cmd )
    --os.execute ("echo " .. cmd .. " > /var/doTraceRoute.cmd")
    stat = os.execute (cmd)

    --Update the results to db
    sval,serrcode = pcall (loadfile ("/var/doTraceRoute.out"))
    if (sval) then
        dofile ("/var/doTraceRoute.out")
        
        outRow["TraceRouteDiagnostics.ResponseTime"] = "0"
        outRow["TraceRouteDiagnostics.DiagnosticsState"] = "Complete"
        local file = io.open("/var/trRespTime.txt", "r") 
        local line = file:read()
        local resTime, tmp = string.sub(line, 6)
        local time = util.split(resTime, " ")
        local min = string.gsub(time[1],'m', '')
        local sec = string.gsub(time[2],'s', '')
        local responseTime = (min*60000) + (sec*1000)
        file:close()

        outRow["TraceRouteDiagnostics.ResponseTime"] = responseTime  or '0'

        db.update ("TraceRouteDiagnostics", outRow, "1")
    else
        iputilsTr.traceRouteDiagnosticsErr()
        return
    end
end

function iputilsTr.TraceRouteDiagnosticsHandler(inTable)
    local inRow = inTable["TraceRouteDiagnostics"]
    local rowId = ""
    local ifaceRow = {}
    local logicalIfName = ""
    local diagReqFlag = 0
    local status = "0"

    os.execute ("rm -rf /var/doTraceRoute.out");
    os.execute ("rm -rf /var/doTraceRoute.cmd");
    os.execute ("rm -rf /var/trRespTime.txt");

    --check diagnostics state
    if(inRow["TraceRouteDiagnostics.DiagnosticsState"] ~= nil) then
        --When writing, the only allowed value is Requested.
       if(inRow["TraceRouteDiagnostics.DiagnosticsState"] == "Requested") then
           --set diagReqFlag
           diagReqFlag = 1
       else
           --Unknown state, do no change in CPE
           return 0;
       end
    end

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return 0;
    end

    --update db with new values
    if (inRow["TraceRouteDiagnostics.InterfaceObject"] ~= nil) then
        rowId = instanceMap[inRow["TraceRouteDiagnostics.InterfaceObject"]]
        if (rowId == nil) then
            return 0;
        end

        logicalIfName = db.getAttribute ("NimfConf", "_ROWID_", rowId, "LogicalIfName")
        if (logicalIfName ~= nil) then
            inRow["TraceRouteDiagnostics.Interface"] = logicalIfName
        else
            iputilsTr.traceRouteDiagnosticsErr()
            return
        end
    end

    db.update ("TraceRouteDiagnostics", inRow, "1")
    --Do NOT perform db.save here. TraceRouteDiagnostics tbl is not meant to be
    --persistent across reboot

    --if state is "Requested", run diagnostics & update results to db
    if(diagReqFlag == 1) then
        iputilsTr.runTraceRouteDiagnostics()
    end
end

function iputilsTr.nsLookUpDiagnosticsErr()
    local outRow = {}

    --Update the results to db
    outRow["NSLookupDiagnostics.DiagnosticsState"] = "Error_DNSServerNotResolved"
    outRow["NSLookupDiagnostics.SuccessCount"] = "0"

    db.update ("NSLookupDiagnostics", outRow, "1")
end

function iputilsTr.runNSLookupDiagnostics()
    local query = "_ROWID_='1'"
    local ipAddressQuery
    local nslookDiagRow = db.getRowWhere ("NSLookupDiagnostics", query, false);
    local qryRow = {}
    local qryStatus = ""
    local wanDefConn = {}
    local interfaceIPaddr = {}
    local outRow = {}
    local maxIP = 10

    --Start the nslookup diagnostics program. This call should return after the
    --diagnostics is done.

    local timeOut = nslookDiagRow["Timeout"] / 1000
    local cmd = "time nslookup -sil -tf -query=any " .. nslookDiagRow["HostName"] .. " " .. nslookDiagRow["DNSServer"] .. " -timeout=" .. timeOut 

    local tries = nslookDiagRow["NumberOfRepetitions"]
    local cnt = 1
    local confRow = {}

    local chipsetRow = db.getRowWhere("chipsetInfo", "_ROWID_=1", false)

    if (chipsetRow == "" or chipsetRow == nil) then
       confRow ["Result.Status"] = "Error_Other"
       return
    end

    if (chipsetRow["Chipset"] == "Lantiq") then
        cmd = "time /bin/sh /pfrm2.0/bin/nslookup_lantiq.sh " ..nslookDiagRow["HostName"] .. " " .. nslookDiagRow["DNSServer"] .. " " .. timeOut
    end

    while (cnt <= tonumber(tries)) do
        cnt = cnt + 1 
        stat = util.runShellCmd(cmd, "/var/nsLookUpDiag.out", "/var/nsRespTime.txt",  nil)

        -- Update the results to db
        sval,serrcode = pcall (loadfile ("/var/nsLookUp.out"))
        if (sval) then
            dofile ("/var/nsLookUp.out")
            local nslookTbl = util.getLuaVariable("nslook")

            outRow["NSLookupDiagnostics.DiagnosticsState"] = "Complete" 
            outRow["NSLookupDiagnostics.SuccessCount"] = nslook["SuccessCount"]

            if(nslook["AnswerType"] == nil) then
                iputilsTr.nsLookUpDiagnosticsErr()
                return
            end

            if (nslookTbl ~= nil) then
                if(nslook["AnswerType"] ~= nil and (nslook["IPAddresses"] ~= nil or nslook["IPv6Address"] ~= nil)) then
                    confRow ["Result.Status"] = "Success"
                elseif(nslook["IPAddresses"] == nil) then
                    confRow ["Result.Status"] = "Error_HostNameNotResolved"
                else
                    confRow ["Result.Status"] = "Error_Other"
                end
            else
                confRow ["Result.Status"] = "Error_Other"
            end
           
            local count_v4 = 0
            local count_v6 = 0
            local count = 0
            local ipv6Addrs = 0
            local ipaddr = {}
            local i = 1

            -- Get max 10 IPaddresses  
            if(nslook["IPAddresses"] ~= nil and nslook["IPAddresses"] ~= "")then
                _, count_v4 = string.gsub(nslook["IPAddresses"], ",", ",")
                count_v4 = count_v4 + 1
                if(count_v4 == 10) then
                    confRow ["Result.IPAddresses"] = nslook["IPAddresses"]
                else
                    confRow ["Result.IPAddresses"] = nslook["IPAddresses"]
                    if(nslook["IPv6Address"] ~= nil and nslook["IPv6Address"] ~= "")then
                        confRow ["Result.IPAddresses"] = nslook["IPAddresses"] .. "," ..nslook["IPv6Address"]
                         _, count = string.gsub(confRow ["Result.IPAddresses"], ",", ",")
                        count = count + 1
                        if(count > 10) then
                            ipaddr = util.split(confRow ["Result.IPAddresses"], ",")
                            for i = 1,10,1 do
                                if(i == 1) then
                                    confRow ["Result.IPAddresses"] = ipaddr[i]
                                else
                                    confRow ["Result.IPAddresses"] = confRow ["Result.IPAddresses"] .. "," .. ipaddr[i]
                                end
                            end
                        end
                    end
                end
            elseif(nslook["IPv6Address"] ~= nil and nslook["IPv6Address"] ~= "") then
                -- This block of code will be executed when nslookup resolves
                -- only v6 addresses without any v4 address present in it              
                _, count_v6 = string.gsub(nslook["IPv6Address"], ",", ",")
                if(count_v6 <= maxIP - 1) then 
                    tr69Glue.tf1Dbg(" Result.IPAddresses "..nslook["IPv6Address"])
                    confRow ["Result.IPAddresses"] = nslook["IPv6Address"]
                else
                    -- if number of IP's are greater than ten we
                    -- will parse each IP address and concatenate with
                    -- the confRow["Result.IPAddresses"] string upto first ten
                    -- addresses. As per amendment we have to allow only ten 
                    -- IP addresses for IPaddress field resolved by DNS
                    confRow ["Result.IPAddresses"] = nslook["IPv6Address"]
                    _, count = string.gsub(confRow ["Result.IPAddresses"], ",", ",")
                    count = count + 1
                    if(count > maxIP) then
                       ipaddr = util.split(confRow ["Result.IPAddresses"], ",")
                       for i = 1,10,1 do
                           if(i == 1) then
                              confRow ["Result.IPAddresses"] = ipaddr[i]
                           else
                              confRow ["Result.IPAddresses"] = confRow ["Result.IPAddresses"] .. "," .. ipaddr[i]
                           end
                       end
                    end
                end
            else
                confRow ["Result.IPAddresses"] = ""
            end

            confRow ["Result.AnswerType"] = nslook["AnswerType"] or ''
            confRow ["Result.HostNameReturned"] = nslook["HostNameReturned"] or ''
            confRow ["Result.DNSServerIP"] = nslook["DNSServerIP"] or ''
            
            if(confRow ["Result.Status"] == "Success") then
                local file = io.open("/var/nsRespTime.txt", "r") 
                if(file ~= nil) then
                    local line = file:read()
                    local resTime, tmp = string.sub(line, 6)
                    local time = util.split(resTime, " ")
                    local min = string.gsub(time[1],'m', '')
                    local sec = string.gsub(time[2],'s', '')
                    local responseTime = (min*60000) + (sec*1000)
                    confRow ["Result.ResponseTime"] = responseTime or "0"
                    file:close()
                else
                    confRow ["Result.ResponseTime"] = "0"
                end
            else
                confRow ["Result.ResponseTime"] = "0"
            end

            db.insert("Result",confRow)
        else
            confRow ["Result.Status"] = "Error_DNSServerNotAvailable"
            confRow ["Result.AnswerType"] = "None"
            confRow ["Result.HostNameReturned"] = ''
            confRow ["Result.IPAddresses"] = ''
            confRow ["Result.DNSServerIP"] = ''
            confRow ["Result.ResponseTime"] = "0"
            db.insert("Result",confRow)

            iputilsTr.nsLookUpDiagnosticsErr()
            return
        end 
    end
        
    db.update ("NSLookupDiagnostics", outRow, "1")
end

function iputilsTr.NSLookupDiagnosticsHandler(inTable)
    local inRow = inTable["NSLookupDiagnostics"]
    local rowId = ""
    local ifaceRow = {}
    local logicalIfName = ""
    local diagReqFlag = 0
    local status = "0"

    os.execute ("rm -rf /var/nsLookUp.out");
    os.execute ("rm -rf /var/nsRespTime.txt");
    -- delete all existing rows
    local query = "delete from Result where AnswerType='None' or AnswerType='Authoritative' or AnswerType='NonAuthoritative'"
    db.execute(query)

    --check diagnostics state
    if(inRow["NSLookupDiagnostics.DiagnosticsState"] ~= nil) then
        --When writing, the only allowed value is Requested.
       if(inRow["NSLookupDiagnostics.DiagnosticsState"] == "Requested") then
           --set diagReqFlag
           diagReqFlag = 1
       else
           --Unknown state, do no change in CPE, return 9007
           return error_code.INVALID_PARAM_VALUE;
       end
    end

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return 0;
    end

    --update db with new values
    if (inRow["NSLookupDiagnostics.InterfaceObject"] ~= nil) then
        if(inRow["NSLookupDiagnostics.DiagnosticsState"] ~= "Requested") then
            inRow["NSLookupDiagnostics.DiagnosticsState"] = "None"
        end

        if(string.len(inRow["NSLookupDiagnostics.InterfaceObject"]) == 0) then
            inRow["NSLookupDiagnostics.InterfaceObject"] = ""
        else 
            rowId = instanceMap[inRow["NSLookupDiagnostics.InterfaceObject"]]
            if (rowId == nil) then
                return error_code.INVALID_PARAM_VALUE;
            end

            logicalIfName = db.getAttribute ("NimfConf", "_ROWID_", rowId, "LogicalIfName")
            if (logicalIfName ~= nil) then
                inRow["NSLookupDiagnostics.Interface"] = logicalIfName
            end
        end
    end

    if(inRow["NSLookupDiagnostics.HostName"] ~= nil and inRow["NSLookupDiagnostics.DiagnosticsState"] ~= "Requested") then
        inRow["NSLookupDiagnostics.DiagnosticsState"] = "None"
    end

    if(inRow["NSLookupDiagnostics.DNSServer"] ~= nil) then
        if(inRow["NSLookupDiagnostics.DiagnosticsState"] ~= "Requested") then
            inRow["NSLookupDiagnostics.DiagnosticsState"] = "None"
        end
    end

    if(inRow["NSLookupDiagnostics.Timeout"] ~= nil and inRow["NSLookupDiagnostics.DiagnosticsState"] ~= "Requested") then
        inRow["NSLookupDiagnostics.DiagnosticsState"] = "None"
    end

    if(inRow["NSLookupDiagnostics.NumberOfRepetitions"] ~= nil and inRow["NSLookupDiagnostics.DiagnosticsState"] ~= "Requested") then
        inRow["NSLookupDiagnostics.DiagnosticsState"] = "None"
    end

    db.update ("NSLookupDiagnostics", inRow, "1")
    --Do NOT perform db.save here. NSLookupDiagnostics tbl is not meant to be
    --persistent across reboot

    --if state is "Requested", run diagnostics & update results to db
    if(diagReqFlag == 1) then
        iputilsTr.runNSLookupDiagnostics()
    end
end

function iputilsTr.TraceRouteDiagnosticsGet (input)
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local row = {}
    local query = nil
    local param = input["param"]
    
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from qosClassification 
    query = "_ROWID_=1"
    row = db.getRowWhere ("TraceRouteDiagnostics", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

     --find & return parameter values
    if(string.find(input["param"], "RouteHopsNumberOfEntries")) then
        -- RouteHopsNumberOfEntries
        local RouteHopsRows = db.getTable("RouteHops")
        value = #RouteHopsRows
    end

    tr69Glue.tf1Dbg ("Value = " .. value)
    return status, value
end
