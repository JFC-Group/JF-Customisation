-- clishCLI.lua
-- TeamF1
-- www.TeamF1.com

-- Modification History
-- 01d,06jun08,gnm added message to clishCfgObjExec() 
-- 01c,02may08,gnm Added clishCfgObjDel(). Modified clishCfgObjExec()
--                 to reload configuration after exec operation.
-- 01b,27jan08,gnm Modified clishCfgObjExec() to not print success message on config save 
-- 01a,28nov07,gnm written
--
-- Description
-- Core CLISH LUA set routine library. These routines will be used
-- from the CLISH XML files to set configuration parameters and apply
-- or roll back configuration changes to configuration objects (like
-- user info, 802.11 profile information, RADIUS server info etc.)
-- 

require "luasql.sqlite3"

-- global
__CLISH_CUR_OBJ_ID = nil
__CLISH_CUR_CFG_INIT_FN = nil
__CLISH_CUR_CFG_EXEC_FN = nil
__CLISH_CUR_CFG_IPVAL_FN = nil
__CLISH_CUR_CONFIG_ROW = {}
__CLISH_EDIT_CONFIG_ROW = {}

__CLISH_EDIT_SESSION_OBJECT = ""
__CLISH_SESSION_ARGS = nil

--
--
function clishPrintArgs (args)
    for k,v in pairs(args) do
	print (k, v)
    end
    return args
end

--
-- This routine gets an attribute value from the edit set. If it's not
-- present in the edit set the attribute value is fetched from the --
-- current config set.
function clishCfgAttrGet (objId, attrName)
    local attrVal = nil

    if (__CLISH_CUR_OBJ_ID ~= objId) then -- Check
        return attrVal
    end

    if (__CLISH_EDIT_CONFIG_ROW[attrName] ~= nil) then
        attrVal = __CLISH_EDIT_CONFIG_ROW[attrName]
    elseif (__CLISH_CUR_CONFIG_ROW[attrName] ~= nil) then
        attrVal = __CLISH_CUR_CONFIG_ROW[attrName]
    end
    return attrVal
end

--
-- This routine is used to execute component specific LUA code. It is
-- typically used in the ACTION tag of CLI show commands.
function clishCmdExec (cmdFn, ...)
    local targs = {...} -- Argument table
    local args = {}

    -- build arg table
    for _, v in pairs(targs) do 
	table.insert (args, v) 
    end
    -- Call the CLI function
    return cmdFn(args)
end

--
-- This routine clears the current configuration object and the
-- configuration routine callbacks
local function clishCfgClear()
    -- Configuration was save to db so reset global info
    __CLISH_CUR_CFG_INIT_FN = nil
    __CLISH_CUR_CFG_EXEC_FN = nil
    __CLISH_CUR_CFG_IPVAL_FN = nil
    __CLISH_SESSION_ARGS = args
    __CLISH_CUR_OBJ_ID = nil
    __CLISH_CUR_CONFIG_ROW = {} -- current config info is now discarded
    __CLISH_EDIT_CONFIG_ROW = {} -- current edit config info is discarded
end

--
-- This routine resets any configuration changes made till now
function clishCfgObjReset ()
    __CLISH_EDIT_CONFIG_ROW = {} -- current edit config info is discarded
end

--
-- This routine is used when the current configuration object
-- information is to be deleted from the database.
function clishCfgObjDel (objId)
    if (__CLISH_CUR_OBJ_ID ~= objId) then -- Check
        return "ERROR"
    end

    -- Save modified configuration
    local errorFlag, statusMessage = 
	  __CLISH_CUR_CFG_EXEC_FN (__CLISH_CUR_CONFIG_ROW, targs)
    if (errorFlag ~= "OK") then
        printCLIError (statusMessage..". Configuration not deleted.")
    end

    return "OK"
end

--
-- This routine saves the current configuration object to database.
-- Note that the configuration object identifier is not really
-- required to e passed to this function.
function clishCfgObjExec (objId, ...)
    local __CLISH_CFG_SAVE_TABLE = {}
    local targs = {...}
    local rowId = nil
    local fld = nil

    if (__CLISH_CUR_OBJ_ID ~= objId) then -- Check
        return "ERROR"
    end

    local rebootCheck = util.fileExists ("/tmp/bootComplete")
    if (not rebootCheck) then
        printCLIError ("Router initializing after reboot, please wait")
        return "ERROR"
    end

    -- Create the table to be saved. Values for fields that were not
    -- edited will be picked up from the values in the current config
    -- table.
    if (util.tableSize(__CLISH_EDIT_CONFIG_ROW) ~= 0) then
        for fld, _ in pairs(__CLISH_EDIT_CONFIG_ROW) do
	    __CLISH_CFG_SAVE_TABLE[fld] = __CLISH_EDIT_CONFIG_ROW[fld]
        end

        for fld, _ in pairs(__CLISH_CUR_CONFIG_ROW) do	
	    if (__CLISH_EDIT_CONFIG_ROW[fld] == nil) then
	        __CLISH_CFG_SAVE_TABLE[fld] = __CLISH_CUR_CONFIG_ROW[fld]
	    end
        end   
    else
	__CLISH_CFG_SAVE_TABLE = __CLISH_CUR_CONFIG_ROW
    end

    -- Check the built configuration before saving
    if (__CLISH_CUR_CFG_IPVAL_FN ~= nil) then
        local retVal, msg = __CLISH_CUR_CFG_IPVAL_FN (__CLISH_CFG_SAVE_TABLE)
	if (retVal == false) then
        if (msg ~=nil) then
	        printCLIError (msg)
        end
	    return "ERROR"
	end
    end

    -- Save modified configuration
    local errorFlag, statusMessage = 
	  __CLISH_CUR_CFG_EXEC_FN (__CLISH_CFG_SAVE_TABLE, targs)

	if (errorFlag ~= "OK") then
		if(statusMessage == "SaveWireless") then	
			statusMessage = ""
		else
		if (statusMessage == nil) then
		    statusMessage = ""
		end
        	printCLIError (statusMessage)
			printCLIError ("** Configuration could not be saved, Please try again. **")
		end
    else
        clishCfgObjReset () -- clear edited changes
    end

    -- Reload configuration using same arguments
    rowId, __CLISH_CUR_CONFIG_ROW = __CLISH_CUR_CFG_INIT_FN (__CLISH_SESSION_ARGS)    
    -- The init function needs to return a non nil value, even if the
    -- table really has no element.
    if  (__CLISH_CUR_CONFIG_ROW) == nil then
	clishCfgClear()
	printCLIError ("Error reading config after save.") 
	return "ERROR"
    end
   
    return "OK"
end

--
-- This routine adds a parameter to the current configuration object
function clishCfgObjAdd (objId, key, value)
    if (__CLISH_CUR_OBJ_ID ~= objId) then -- Check
        return "ERROR"
    end

    -- insert the key value pair in the configuration table
    __CLISH_EDIT_CONFIG_ROW[key] = value

    return "OK"
end

--
-- This routines creates a new configuration object based on the
-- object id provided. The configuration object remains active till
-- this routine is called next, which would mean that you are now
-- editing a new configuration object.
function clishCfgObjNew (objId, initFn, execFn, valFn, ...)
    local args = {}
    local rowId = nil    
    local targs = {...}

    for _, v in pairs(targs) do table.insert (args, v) end -- build argument table
    clishCfgClear()     -- Reset

    -- Set the init and save functions for configuration objects
    if (initFn == nil or execFn == nil or objId == nil) then
        print ("Cannot setup new configuration for edit.") 
        return "ERROR"
    end

    __CLISH_CUR_CFG_INIT_FN = initFn
    __CLISH_CUR_CFG_EXEC_FN = execFn
    __CLISH_CUR_CFG_IPVAL_FN = valFn
    __CLISH_CUR_OBJ_ID = objId
    __CLISH_SESSION_ARGS = args
    
    rowId, __CLISH_CUR_CONFIG_ROW = __CLISH_CUR_CFG_INIT_FN (args)

    -- The init function needs to return a non nil value, even if the
    -- table really has no element.
    if  (__CLISH_CUR_CONFIG_ROW) == nil then
	clishCfgClear()
	print ("Cannot setup new configuration to edit.") 
	return "ERROR"
    end
end
