--[[
#### Hussain Vali
#### TeamF1
#### www.TeamF1.com
#### Mar 28, 2008

#### File: dhcp.lua
#### Description: dhcp functions

#### Revisions:
01b,12feb10,pnm  Added db.insert in dhcp.config
01a,19Jul08,shv added DHCP Relay Gateway configuration function.
]]--


--************* Requires *************

--************* Initial Code *************
--package dhcp
dhcp = {}
dhcp.debug = 0
dhcp.mode = {
    IPV4_DHCP_NONE      =    0,
    IPV4_DHCP_SERVER    =    1,
    IPV4_DHCP_RELAY     =    2,
}
    
dhcp.dnsMode = {
    USE_DNS_PROXY       =   1,
    USE_DNS_FROM_ISP    =   2,
    USE_CUSTOM_DNS      =   3,
}

require "dhcpLib"
require "teamf1lualib/dhcpdreserv"
require "teamf1lualib/dhcpdoptions"

-------------------------------------------------------------------------
-- @name dhcp.poolConfGet
--
-- @description 
--
-- @return 
--

function dhcp.poolConfGet (LogicalIfName, default)
    local status = "ERROR"
    local errCode = "DHCP_ERR_CONFIG_GET"
    local query = {}

    if (LogicalIfName == nil) then
        return status, errCode
    end
            
    query = "LogicalIfName='" .. LogicalIfName .. "'"
    if ((default ~= nil) and (tonumber(default) > 0)) then
        query =  query .. " AND DefaultPool=1"
    end        

    -- Get the DHCP server configuration for provided logicalIfName 
    local conf = db.getRowWhere("DhcpServerPools", query, false)
    if (conf == nil) then
       return "ERROR", "DHCP_ERR_DB_QRY"
    end

    return "OK", "STATUS_OK", conf
end

-------------------------------------------------------------------------
-- @name dhcp.uniquePoolIDGet
--
-- @description 
--
-- @return 
--

function dhcp.uniquePoolIDGet()
    local poolTbl = {}
    local poolId = 0
    local found

    poolTbl = db.getTable("DhcpServerPools", false)
    for kk,vv in pairs(poolTbl) do
        found = 0
        poolId =  tonumber(vv["PoolID"]) + 1
        for k,v in pairs(poolTbl) do
            if (tonumber(v["PoolID"]) == poolId) then
                found  = 1
            end            
        end

        if (found == 0) then
            return poolId
        end            
    end

    return nil
end

-------------------------------------------------------------------------
-- @name dhcp.defPoolUpdate
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcp.defPoolUpdate (conf)
    local query = {}
    local confRow = {}
    local create = nil
    local valid
    local errstr
    local rowid

    -- check access permissions
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- Get the dhcp server configuration for given network
    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "' and DefaultPool=1"
    local confRow  = db.getRowWhere("DhcpServerPools", query, false)
    if (confRow == nil) then
        --
        -- Default Pool not found for this network.
        -- Add a new one.
        --
        -- Re initialising the table because the confRow became nil
        --
        confRow = {}
        confRow["LogicalIfName"] = conf["LogicalIfName"]
        confRow["PoolID"] = dhcp.uniquePoolIDGet()
        confRow["DefaultPool"] = 1
        confRow["MinAddress"] = ""
        confRow["MaxAddress"] = ""
        confRow["IPRouters"] = ""
        confRow["Enable"] ="0"
        create = 1
    end

    --
    -- if the network is UP and running, then check
    -- Is IPv4 address(min, max) are valid ?
    -- Is address range is valid ?
    -- Is address is in the same subnet as the LAN IP ?
    -- 

    if (conf["MinAddress"] ~= nil) then
        confRow["MinAddress"] = conf["MinAddress"]
    end
        
    if (conf["MaxAddress"] ~= nil) then        
        confRow["MaxAddress"] = conf["MaxAddress"]
    end
        
    if (conf["DomainName"] ~= nil) then
        confRow["DomainName"] = conf["DomainName"]
    end
        
    if (conf["DHCPLeaseTime"] ~= nil) then        
        confRow["DHCPLeaseTime"] = conf["DHCPLeaseTime"]
    end
    
    if (conf["DNSServers"] ~= nil) then    
        confRow["DNSServers"] = conf["DNSServers"]
    end

    if (conf["IPRouters"] ~= nil) then
        confRow["IPRouters"] = conf["IPRouters"]
    end

    if (conf ~= nil) then
        confRow["Enable"] = conf["Enable"]
    end    

    if (tonumber (conf["DNSServers"]) == dhcp.dnsMode.USE_CUSTOM_DNS) then
        confRow["DNSServer1"] = conf["DNSServer1"]
        confRow["DNSServer2"] = conf["DNSServer2"]
    end

    --
    -- Update the configuration
    -- 
    confRow = util.addPrefix(confRow, "DhcpServerPools.")
    if (create ~= nil) then
        valid, errstr, rowid = db.insert("DhcpServerPools", confRow)
    else
        valid, errstr = db.update ("DhcpServerPools", confRow, 
                                    confRow["DhcpServerPools._ROWID_"])
    end

    if (not valid) then
        return "ERROR", errstr, rowid        
    end
            
    -- Restart the DHCP server
--    require "teamf1lualib/service"
  --  service.restart("dhcpd", "1")

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name dhcp.poolIDGet
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcp.poolIDGet(LogicalIfName)
    local poolID = nil
    local query = nil

    if (LogicalIfName == nil) then
        return nil
    end
            
    query = "LogicalIfName='" .. LogicalIfName .. "' and DefaultPool=1"
    local confRow = db.getRowWhere("DhcpServerPools", query, false)
    if (confRow == nil) then
        return nil
    end
            
    if (confRow["PoolID"] ~= nil) then
        poolID = tonumber(confRow["PoolID"]) 
    end
    
    return poolID        
end

-------------------------------------------------------------------------
-- @name dhcp.poolMaxAddrGet
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcp.poolMaxAddrGet(LogicalIfName, MinAddress, numLeases)
    local connID = {}
    local MaxAddress = nil
    require "nimfLib"

    connID["LogicalIfName"] = LogicalIfName
    connID["AddressFamily"] = "2"
    connID["ConnectionKey"] = "0"

    local conn = nimfLib.connGet(connID)
    if (conn == nil) then
        return "ERROR","DHCPD_NET_ERR"
    end

	-- get the last address of the new pool
	MaxAddress = dhcpLib.dhcpdPoolMaxAddrGet(conn["Interface"], MinAddress, 
                                             numLeases)
	if (MaxAddress == nil) then
		return "ERROR","DHCPD_INVALID_NUM_DEVICES"
	end

    return "OK","STATUS_OK",  MaxAddress
end

-------------------------------------------------------------------------
-- @name dhcp.dprintf
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcp.dprintf (str)

    if (str == nil) then
        return
    end

    if (dhcp.debug == 0) then
        return
    end        

    print("DHCP: "  .. str)

    return 
end

-------------------------------------------------------------------------
-- @name dhcp.poolCfgInit
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcp.poolCfgInit (cfg, pool)

	cfg["Enable"] = pool["Enable"]

	if (pool["DHCPLeaseTime"] ~= nil) then
		cfg["DHCPLeaseTime"] = pool["DHCPLeaseTime"]
	end

	if (pool["DomainName"] ~= nil) then
		cfg["DomainName"] = pool["DomainName"]
	end

	if (pool["MinAddress"] ~= nil) then
		cfg["MinAddress"] = pool["MinAddress"]
	end

	if (pool["MaxAddress"] ~= nil) then
	    cfg["MaxAddress"] = pool["MaxAddress"]
	end

	if (pool["DNSServers"] ~= nil) then
		if (pool["DNSServers"] == "1") then
			cfg["DNSServers"] =  "1"
		else
			cfg["DNSServers"] =  "3"
		end
	end

	if (pool["DNSServer1"] ~= nil) then
	    cfg["DNSServer1"] = pool["DNSServer1"]
	end

	if (pool["DNSServer2"] ~= nil) then
	    cfg["DNSServer2"] = pool["DNSServer2"]
	end

	if (pool["DNSServer3"] ~= nil) then
	    cfg["DNSServer3"] = pool["DNSServer3"]
	end

	if (pool["IPRouters"] ~= nil) then
	    cfg["IPRouters"] = pool["IPRouters"]
	end

    if (pool["VendorClassID"] ~= nil) then
        cfg["VendorClassID"] = pool["VendorClassID"]
    end
            
    if (pool["VendorClassIDMode"] ~= nil) then
        cfg["VendorClassIDMode"] = pool["VendorClassIDMode"]
    end

    return cfg
end


--[[
************************** OLD FUNCTIONS *****************************
--]]

function dhcp.config (inputTable, cfgid, operation)

    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
            return "ACCESS_DENIED", "ADMIN_REQD"
    end
    local valid = false

    if (operation == "add") then
        valid = db.insert ("DhcpServerPools", inputTable)
    elseif (operation == "edit") then
        valid = dhcp.updateConfig(inputTable, rowid)
    elseif (operation == "delete") then
        return nil
    end

    -- return
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DHCP_CONFIG_FAILED"
    end
end


-- Updating Configurations
function dhcp.updateConfig (inputTable, rowid)

    local inTable = {}
	local query = "_ROWID_=" .. rowid

	inTable =  db.getRowWhere("DhcpServerPools", query)
	if (inTable == nil) then
		return false, "DHCPD_CONFIG_FAILED"
	end

	inTable["DhcpServerPools.Enable"] = inputTable["DhcpServerPools.Enable"]

	if (inputTable["DhcpServerPools.DHCPLeaseTime"] ~= nil) then
		inTable["DhcpServerPools.DHCPLeaseTime"] = 
			inputTable["DhcpServerPools.DHCPLeaseTime"]
	end

	if (inputTable["DhcpServerPools.DomainName"] ~= nil) then
		inTable["DhcpServerPools.DomainName"] = 
			inputTable["DhcpServerPools.DomainName"]
	end

	if (inputTable["DhcpServerPools.MinAddress"] ~= nil) then
		inTable["DhcpServerPools.MinAddress"] = 
			inputTable["DhcpServerPools.MinAddress"]
	end

	if (inputTable["DhcpServerPools.MaxAddress"] ~= nil) then
	    inTable["DhcpServerPools.MaxAddress"] = 
			inputTable["DhcpServerPools.MaxAddress"]
	end

	if (inputTable["DhcpServerPools.DNSServers"] ~= nil) then
		if (inputTable["DhcpServerPools.DNSServers"] == "1") then
			inTable["DhcpServerPools.DNSServers"] =  "1"
		else
			inTable["DhcpServerPools.DNSServers"] =  "3"
		end
	end

	if (inputTable["DhcpServerPools.DNSServer1"] ~= nil) then
	    inTable["DhcpServerPools.DNSServer1"] = 
			inputTable["DhcpServerPools.DNSServer1"]
	end

	if (inputTable["DhcpServerPools.DNSServer2"] ~= nil) then
	    inTable["DhcpServerPools.DNSServer2"] = 
			inputTable["DhcpServerPools.DNSServer2"]
	end

	if (inputTable["DhcpServerPools.DNSServer3"] ~= nil) then
	    inTable["DhcpServerPools.DNSServer3"] = 
			inputTable["DhcpServerPools.DNSServer3"]
	end

	if (inputTable["DhcpServerPools.IPRouters"] ~= nil) then
	    inTable["DhcpServerPools.IPRouters"] = 
			inputTable["DhcpServerPools.IPRouters"]
	end

	if (util.hasAnyFieldChanged("DhcpServerPools", inTable, 
							 inTable["DhcpServerPools._ROWID_"]) == 0) then
		return true, "STATUS_OK"
	end

    db.beginTransaction() --begin transaction
    valid, errStr = db.update("DhcpServerPools", inTable, rowid)
	if (not valid) then
        db.rollback()
        return false, "DHCPD_CONFIG_FAILED"
    end

	if (inputTable["DhcpServerPools.WinsServer"] ~= nil) then
		local dhcpOptionRow = {}
		local optionQry = "OptionCode=44 and PoolID=" .. inTable["DhcpServerPools.PoolID"]
		dhcpOptionRow = db.getRowWhere("DhcpOption", optionQry)
		if (dhcpOptionRow ~= nil) then
			dhcpOptionRow["DhcpOption.value1"] = inputTable["DhcpServerPools.WinsServer"]
		end

		valid, errStr = db.update("DhcpOption", dhcpOptionRow,
								   dhcpOptionRow["DhcpOption._ROWID_"])
		if (not valid) then
			db.rollback()
		    return false, "DHCPD_CONFIG_FAILED"
	    end
	end

    db.commitTransaction()

    -- Restart the DHCP server
    require "teamf1lualib/service"
    service.restart("dhcpd", "1")

	return	true
end


function dhcp.fixedIpConfig (inputTable, rowid, operation)
    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
            return "ACCESS_DENIED", "ADMIN_REQD"
    end
    db.beginTransaction() --begin transaction
    local valid = false

    if (operation == "add") then
        valid = db.insert("DhcpfixedIpAddress", inputTable)
    elseif (operation == "edit") then
        valid = db.update("DhcpfixedIpAddress", inputTable, rowid)
    elseif (operation == "delete") then
        valid = db.delete("DhcpfixedIpAddress", inputTable)
    end

    -- return
    if (valid) then
        db.commitTransaction()
        return "OK", "STATUS_OK"
    else
        db.rollback()
        return "ERROR", "DHCP_CONFIG_FAILED"
    end
end

function dhcp.dhcpConfigWrap (inputTable, logIfName)
    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    local dhcpRelayUpdate = false
    local valid = false
    local where = "LogicalIfName = '" .. logIfName .."'"
    local dhcpsConfig = db.getRowWhere ("DhcpServerPools", where)
    local dhcpRelayConfig = db.getRowWhere ("DhcpRelay",where)

    local dhcpRelayInTable = {}
    if (inputTable["DhcpServerPools.Enable"] == "3") then
        inputTable["DhcpServerPools.Enable"] = "0"
        dhcpRelayInTable["DhcpRelay.DhcpRelayStatus"] = "1"
    else
        dhcpRelayInTable["DhcpRelay.DhcpRelayStatus"] = "0"        
    end

    local rowid = nil
    if (dhcpsConfig ~= nil) then
        rowid = dhcpsConfig["DhcpServerPools._ROWID_"]
    end
    if (rowid ~= nil) then
        if (inputTable["DhcpServerPools.Enable"] == "1") then
            if (logIfName == "LAN") then
                local dhcpRelayConfig = db.getRowWhere ("DhcpRelay", "LogicalIfName = 'DMZ'")
                if (dhcpRelayConfig ~= nil and dhcpRelayConfig["DhcpRelay.DhcpRelayStatus"] == "1") then
                    dhcpRelayConfig["DhcpRelay.DhcpRelayStatus"] = "0"
                    valid = db.update("DhcpRelay", dhcpRelayConfig, dhcpRelayConfig["DhcpRelay._ROWID_"])
                else
                    valid = true
                end
            elseif (logIfName == "DMZ") then
                local dhcpRelayConfig = db.getRowWhere ("DhcpRelay", "LogicalIfName = 'LAN'")
                if (dhcpRelayConfig ~= nil and dhcpRelayConfig["DhcpRelay.DhcpRelayStatus"] == "1") then
                    dhcpRelayConfig["DhcpRelay.DhcpRelayStatus"] = "0"
                    valid = db.update("DhcpRelay", dhcpRelayConfig, dhcpRelayConfig["DhcpRelay._ROWID_"])
                else
                    valid = true
                end
            else
                valid = true
            end
        else
            valid = true
        end
        if (valid) then
            valid = dhcp.updateConfig (inputTable, rowid)
        end
    end

    db.beginTransaction() --begin transaction
    if (valid and dhcpRelayConfig ~= nil) then
        rowid = dhcpRelayConfig["DhcpRelay._ROWID_"]
        if (rowid ~= nil) then
            if (dhcpRelayInTable["DhcpRelay.DhcpRelayStatus"] == "1") then
                dhcpRelayInTable["DhcpRelay.RelayGateway"] = inputTable["DhcpRelay.RelayGateway"]
                if (logIfName == "LAN") then
                    local dhcpConfig = db.getRowWhere ("DhcpServerPools", "LogicalIfName = 'DMZ'")

                    if (dhcpConfig ~= nil and dhcpConfig["DhcpServerPools.Enable"] == "1") then
                        dhcpConfig["DhcpServerPools.Enable"] = "0"
                        valid = db.update("DhcpServerPools", dhcpConfig, dhcpConfig["DhcpServerPools._ROWID_"])
                    else
                        valid = true
                    end
                elseif (logIfName == "DMZ") then
                    local dhcpConfig = db.getRowWhere ("DhcpServerPools", "LogicalIfName = 'LAN'")

                    if (dhcpConfig ~= nil and dhcpConfig["DhcpServerPools.Enable"] == "1") then
                        dhcpConfig["DhcpServerPools.Enable"] = "0"
                        valid = db.update("DhcpServerPools", dhcpConfig, dhcpConfig["DhcpServerPools._ROWID_"])
                    else
                        valid = true
                    end
                else
                    valid = true
                end
            end
            if (valid) then
                valid = db.update("DhcpRelay", dhcpRelayInTable, rowid)
            end
        end
    end

    -- return
    if (valid) then
        db.commitTransaction()
        return "OK", "STATUS_OK"
    else
        db.rollback()
        return "ERROR", "DHCP_CONFIG_FAILED"
    end
end
