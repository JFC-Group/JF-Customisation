-- mldproxyCLI.lua
-- Samer Sayeed
-- TeamF1
-- www.TeamF1.com
--
-- Modification History
-- 07jan09,ss written 
--
-- Description
-- CLI interface set and get routines

require "teamf1lualib/nimfView"

function mldCfgInit (args)
    configRow = db.getRow("mldproxy", "_ROWID_", "1")
    if (configRow == nil) then
        configRow = db.getDefaults(true, "mldproxy")
    end
    return 1, configRow
end

function mldCfgSave (configRow)
    DBTable = "mldproxy"
    errorFlag, statusCode = nimfView.ipv6MldConfig(configRow, "1", "edit")
    -- save db if no error
    if (errorFlag == "OK") then db.save() end
    statusMessage = db.getAttribute("stringsMap", "stringId", statusCode, LANGUAGE)
    return errorFlag, statusMessage
end

function mldCfgInputVal (configRow)
    local ipMode = db.getAttribute ("networkInfo", "_ROWID_", "1", "netWorkMode")
    if (ipMode == "1") then
        printCLIError ("Please Set IP Mode to IPv4/IPv6 to configure IPV6 MLD.")
        return false
    end
    return true
end

function mldCfgGet (args)
    local row = db.getRow ("mldproxy", "_ROWID_", "1")
    printLabel ("MLD")
    print("MLD Configuration\n")
    if (mldCfgInputVal()) then
    if( row["mldproxy.isEnabled"]  == "1") then
    print("MLD is Enabled\n")
    elseif (row["mldproxy.isEnabled"] == "0") then
    print("MLD is Disabled\n")
    end
    print("Maximum query response time: " .. row["mldproxy.maxQueryResponseTime"] .. " Milli Seconds\n")
    print("Robustness Variable: " .. row["mldproxy.queryTimeout"] .. "\n")
    print("Query interval: " .. row["mldproxy.queryInterval"] .. " Seconds\n")
    end
end
