#!/pfrm2.0/bin/lua 

--[[
  #### File: config.lua
  #### Description: configuration library
-- Copyright (c) 2015-2016, TeamF1 Networks Pvt. Ltd.
-- (Subsidiary of D-Link India)
--
  #### Revisions:
  01f,14May15,adk  added while loop to successfully insert table sqliteLock.
  01e,23feb10,pnm  remove several os.execute commands from the export routine.
  01d,12oct09,pnm  moved commit to end of function in import routine.
  01c,19aug09,pnm  added support for old configuration import format and
                   modified the updateChecksum routine not to do export second
                   time.
  01b,16apr09,rks  added config.beginOperation,commitOperation,recOp
  01a,19Dec07,nsr  written
  ]]--

--************* Requires *************
require "teamf1lualib/util"

-- package config
config = {}

--locals
local defaultRunLevel = "2"
local currentRunLevel 

-- generate md5 sum for file
function config.getChecksum (fileName)

    local pfile = io.popen ("cat " .. fileName .. " | grep -v 'checksum' | md5sum  | cut -d' ' -f1")
    local checksum = pfile:read ("*a")
    pfile:close()

    -- remove new line character
    return string.gsub (checksum, "\n", "")
end

-- verify checksum on file 
function config.verifyChecksum (fileName)

    -- populate table entires from file
    if (pcall (loadfile (fileName))) then
        dofile (fileName)
    else
        return nil
    end

    -- get checksum from systemConfig tbl
    local checksum_file = config["checksum"]
 
    -- generate md5sum for file
    local checksum_md5sum = config.getChecksum (fileName)

    -- verify checksum is correct or 0
    if (checksum_file == checksum_md5sum or checksum_file == "0") then
        return "ok"
    else
        return nil
    end
end

-- update checksum in file
function config.updateChecksum (fileName)

    local checksum = config.getChecksum (fileName)

    local file = io.open(fileName .. "", "ab")
    db.saveTable(file, "config.checksum", checksum or 0, false, 1, 1)
    file:close()
end

function config.register (compName, importFunc, exportFunc, runLevel)
    if (config["components"] == nil) then
        config["components"] = {}
    end
    local comp = {}
    comp.compName = compName
    comp.import = importFunc
    comp.export = exportFunc

	if (runLevel == nil) then
		runLevel = "2"
	end

	comp.runLevel = tonumber(runLevel)
    
    table.insert (config.components, comp)
end

function config.comps_import (userConfig,  defaultConfig, removeconfig, runLevel)
    require "teamf1lualib/config_comps"
    local valid = false
    local cnt = 1
    local errstr = ""
    local rowid 
	local compRunLevel

	currentRunLevel = tonumber(runLevel)
  
    for i,v in ipairs (config["components"]) do

		compRunLevel = tonumber(v["runLevel"])

		if (compRunLevel == currentRunLevel) then
            --print ("Importing configuration for " .. v.compName)
			status, message = v["import"] (userConfig[v.compName], defaultConfig[v.compName], removeconfig[v.compName])
		    if (status ~= nil and status == -1) then
				print ("error during importing configuration for " .. v.compName)
				return status, message
		    end
		end
    end

	-- update the current runLevel
	db.setAttribute("runLevelStatus", "_ROWID_", "1", "runLevel", currentRunLevel);

	if (currentRunLevel == tonumber(defaultRunLevel)) then
        while (not (valid)) do
            local input = {}
            input["sqliteLock.lock"] = 0
            valid, errstr, rowid = db.insert("sqliteLock", input)
            if (not (valid)) then
                --print ("Error String :'" .. errstr .. "'")
                print ("Iterating for .. " .. cnt)
                cnt = cnt + 1
                os.execute ("sleep 1")
            end
        end
    end
end

function config.import (fileName, defaultConfigFile, removeconfigFile, runLevel)
    local oldConfig = config
    
    -- resetting the table
    config = {}
    
    -- load lua variables from default config.
    dofile (defaultConfigFile)
    
    -- copy the config table into the defaultconfig. 
    local defaultConfig =  config
    
    --restore config to original
    config = oldConfig

    -- load lua variables from removeconfigFile into lua space
    status,message = pcall (dofile ,removeconfigFile)
    if (status ~= true) then
        print ("failed to parse removeconfig file...")
    end

    local removeconfig = removeconfig 
   
    -----------------------------------------------------------------
    -- load lua variables from add configFile into lua space
    --[[
    status,message = pcall (dofile, addConfigFile)
    if (message ~= nil) then
        print (message)
    end    
    if (status ~= true) then
        print ("failed to parse add config file. using default...")
        addConfig = {}
    end
    
    local addconfig = addconfig 
    ]]--
    ------------------------------------------------------------------
    config = {} 
   -- load lua variables from fileName into lua space
    status,message = pcall (dofile ,fileName)
    if (status ~= true) then
        print ("failed to parse config file. using Backup file...")
        -- if config file is currupted, use backup config file.
        -- this file is copied after bootup if config file and backup file are different only
        if (util.fileExists("/flash/teamf1.cfg.ascii.bkp")) then
            os.execute ("cp -rf /flash/teamf1.cfg.ascii.bkp /flash/teamf1.cfg.ascii")
            status,message = pcall (dofile , fileName)
        end
        if (status ~= true) then
            print ("failed to parse backup config file. using default file...")
            config = oldConfig--if the user config file fails then need to reset the DUT therfore removing the user
		    config.reset()    --configuration file from flash.
            local userConfig = defaultConfig
        end
    end
    
    local userConfig = config

    --restore config to original
    --checks for version  
    if (userConfig.version == nil) then
        print("File is missing content. Copying backup file")
        if (util.fileExists("/flash/teamf1.cfg.ascii.bkp")) then
            os.execute ("cp -rf /flash/teamf1.cfg.ascii.bkp /flash/teamf1.cfg.ascii")
            config = {}
            status,message = pcall (dofile ,fileName)
        else
            print("Backup File is not present. Resetting device to default")
        end
    end
    
    userConfig = config

    --restore config to original
    config = oldConfig 

    if (userConfig.version == nil) then
        print ("ASCII file is corrupted. Backup File is not available. Using default...")
        print ("unknown configuration. using default...")
		config.reset()
        userConfig = defaultConfig
	end

	local version = db.getAttribute("configFileTbl", "_ROWID_", 1,  "Version");
	if (version  ~= nil) then
		local versionInfo = util.split(version,".")
		local majorVersion = versionInfo[1]
		local minorVersion = versionInfo[2]

		local usrCfgVerInfo = util.split(userConfig.version, ".")
		if (usrCfgVerInfo[1] ~=  majorVersion) then
        	print ("config major version number mismatch device:" .. usrCfgVerInfo[1] .. "  firmware:" .. majorVersion .. ". Using default...")
			config.reset();
    	    dofile (defaultConfigFile)
		end
	end

    -- First we will apply the configuration that is using old format. Given
    -- this, old configuration format cannot have dependency on the new
    -- format. If there a dependency, the configuration import will never
    -- work.
    db.beginTransaction()
    -- global transaction is used to commit all DB changes in 1 shot.
    globalTransaction = true
    status, message = pcall (db.import)
    if (status ~= true) then
        print (message)
        print ("fail to import configuration")
        globalTransaction = nil
        db.rollback ()
        return 2
    end
    --calling the import function.
    status, status2, message = pcall (config.comps_import ,userConfig, defaultConfig, removeconfig , runLevel)

    if (status ~= true or status2 == -1) then
        if (status ~= true) then
            message = status2
        end
        print (message)
        print ("failed to apply configuration.")
        globalTransaction = nil
        db.rollback ()
        return 2
    end
    globalTransaction = nil
    db.commitTransaction ()

    return 0
end

--[[
--*****************************************************************************
--- config.export - export the current configuration to a file
---
--- This function iterates through all the components that are registered
--- with the config database, retrieves the component's configuration
--- and writes it to the file provided as an argument of this function.
--- The file configuration written by this function can be used to
--- import to any other system using the config.import().
---
--- ARGUMENTS:
--- filename - absolute path of the file name to which the system
--  configuration has to the written.
---
--- RETURN: 
--- On Success: OK, STATUS_OK
---
--- ERROR VALUES: N/A
---
---]]

function config.export (file)
    require "teamf1lualib/config_comps"
	local version = db.getAttribute("configFileTbl", "_ROWID_", 1,  "Version");

    for i,v in ipairs (config["components"]) do
        local compConfig = config.getComponentCfg(v)
        db.saveTable(file, "config." .. v.compName, compConfig, false, 1, 1)
    end
    db.saveTable(file, "config.version", version, false, 1, 1)
end

local operations = nil

function config.beginOperation()
    if (operations == nil) then
        operations = {}
        operations.n = 1
    end
end

function config.recOp (func, ...)
    if (operations) then
        operations[operations.n] = {}
        -- copy table incase arg is modified later
        operations[operations.n].arg = util.tableCopy (arg, 1)
        operations[operations.n].func = func
        operations.n = operations.n + 1
    else
        arg.n = nil
        func (unpack(arg))
    end
end

function config.rollbackOperation ()
    operations = nil
end

function config.commitOperation ()
    operations.n = nil
    for i,v in ipairs (operations) do
        v.arg.n = nil
        v.func (unpack(v.arg))
    end
    operations = nil
end

--[[
*****************************************************************************
- config.getComponentCfg - export the configuration from the component 
-
- This function exports the configuration from the component. During 
- bootup, when the settings of some of the components have not been
- fully imported into the database, this function loads the configuration
- from the settings file.
- 
- RETURN: 
-]]--

function config.getComponentCfg (comp)
	local compConfig = {}
	local compRunLevel 

	-- get the current runLevel
	currentRunLevel = db.getAttribute("runLevelStatus", "_ROWID_", "1", "runLevel");
	currentRunLevel = tonumber(currentRunLevel)

	-- check the runLevel of the component
	compRunLevel = tonumber(comp.runLevel)

	-- 
	-- we can export the components from the db.
	--
	if (currentRunLevel >= compRunLevel) then
        compConfig = comp["export"] ()
	else
		local configFile = db.getAttribute("environment", "name", "TEAMF1_CFG_ASCII", "value")
		-- The component has not been initialized, so get the
		-- configuration from the config file	
		compConfig = config.loadCompCfgFromFile (comp["compName"], configFile)
	end

	return compConfig
end

--[[
--*****************************************************************************
--- config.restore - restore configuration to flash 
---
--- This function restore the provided system configuration into flash. The
--- configuration file must be in the same format as returned by the
--- config.export().
---
--- ARGUMENTS:
--- filename - absolute path of the file name
---
--- RETURN: 
--- On Success: OK, STATUS_OK
--- On Failure: ERROR, <ERROR CODE>
---
--- ERROR VALUES:
--- CONFIG_CHECKSUM_FAILURE - Checksum has failed for the configuration.
---
---]]

function config.restore (filename)

	if (config.verifyChecksum (filename) == "ok") then

        local cfgFile = db.getAttribute("environment", "name", "FLASH_CFG_ASCII", "value")
        if(cfgFile == nil or cfgFile == "") then
            cfgFile = "/flash/teamf1.cfg.ascii"
        end
		-- remove old configuration
		os.execute("rm -f " .. cfgFile)

	    -- copy file to /tmp/
		os.execute("mv" .. " " .. filename .. " " .. cfgFile)

		return "OK", "STATUS_OK"
	else
        -- os.execute("rm -rf " .. " " .. filename)

        return "ERROR", "CONFIG_CHECKSUM_FAILURE"
	end
end

--[[
*****************************************************************************
- config.loadCompCfgFromFile - load component configuration from settings
-
- This function loads the component's configuration from the settings file.
-
- RETURN: 
-]]--

function config.loadCompCfgFromFile(compName, file)
    local oldConfig = config

    -- load lua variables from default config
    config = {}
    dofile (file)

   local currCfg =  config

   --restore config to original
    config = oldConfig

	return currCfg[compName]
end

--[[
*****************************************************************************
- config.checkIfFileExists - check if the given file exists 
-
- This function checks if the given file exists
-
- RETURN: 
-]]--

function config.checkIfFileExists(fileName)
	local fileHandle = nil

	fileHandle = io.open(fileName, "r");
	if (fileHandle == nil) then
		return false
	end
	
	fileHandle:close()
	return true
end

--[[
*****************************************************************************
- config.reset- reset the configuration
-
-  This function resets the current configuration of the system.
-
- RETURN: 
-]]--

function config.reset()
   -- remove the flash configuration file
   local cfg = db.getAttribute("environment", "name", "FLASH_CFG_ASCII", "value")
   if (cfg ~= nil) then
       os.execute ("rm -f " .. cfg)
   end
end

--[[
*****************************************************************************
- config.update- update the configuration
-
-  This function updates the old configuration of the system.
-
- RETURN: 
-]]--

function config.update (configTable, defaultTable, removeconfig)
    
    -- check if the user config file is empty
    if (configTable == nil or #configTable == 0) then
        -- copy the values from the default configuration 
        -- file to the user configuratuion file.
        configTable = defaultTable
        return configTable
    end    
    
    -- if the configuration is not empty
    if (configTable ~= nil and defaultTable ~= nil and #configTable ~= 0)  then
        -- check if the number of rows for the new default 
        -- configuration file and the old configuration file
        -- are different
        if (tonumber(#configTable) ~= tonumber (#defaultTable)) then
            -- If the rows of User Configuration is less than the default
            -- configuration . 
            if (tonumber(#configTable) < tonumber(#defaultTable)) then
                -- if the number of rows of old configuration file is 
                -- less than the new configuration file then we will 
                -- update the new rows.
                for s,t in pairs (defaultTable) do
                    if (not configTable[s]) then
                        configTable[s] = t
                    end
                end        
            end
        end
        -- Remove the fields which has been removed from the new
        -- configuration file
        -- Taking the name of the fields in the table buffer
        local buffer = {}
        local count = 1
        for i,v in pairs (configTable[1]) do
            if ((defaultTable[1] ~= nil) and (not defaultTable[1][i]) and (i ~= "_ROWID_")) then
                buffer[count] = i
                count = count + 1
            end
        end
        -- Iterate for all the rows for each fields which has to be
        -- removed from the user configuration file
        if (#buffer ~= nil) then
            for p,q in pairs (buffer) do
                for i,v in pairs (configTable) do
                    for ii,vv in pairs (v) do
                        if (q == ii) then
                            configTable[i][ii] = nil
                        end
                    end
                end
            end
        end
        -- Comparing with the remove config files if any row has to be 
        -- deleted
        -- 
        if (removeconfig ~= nil) then              
            for p,q in pairs (removeconfig) do
                if (q ~= nil) then
                    for i,v in pairs (configTable) do
                        if (q._ROWID_ == v._ROWID_) then
                            table.remove (configTable, i)
                        end
                    end    
                end
            end
            -- Changing the Rowid to a sequence
            local loop = 1
            for i,v in pairs (configTable) do
                if (type (v) == "table") then
                    v["_ROWID_"] = loop
                    loop = loop + 1
                end
            end    
        end    
        
        
        -- Adding the rows of Add Config to the User configuration 
        --[[
        local rowid = 1
        if (addConfig ~= nil) then
        for r,s in pairs (addConfig) do
        rowid = s["_ROWID_"]
        for i,v in pairs (configTable) do
        if (tonumber (v["_ROWID_"]) >= tonumber (rowid)) then
        v["_ROWID_"] = v["_ROWID_"] + 1
        end   
        end
        for k,v in pairs(addConfig) do
        configTable[#configTable + 1] = v
        end
        end
        end ]]--
    end 
   
    --Check always if a new field has added
    for i,v in pairs (defaultTable) do
        if (type (v) == "table") then
            for ii,vv in pairs (v) do 
                if (not configTable[i][ii]) then
                    for q,t in pairs (configTable) do
--                        t[ii] = vv
			if (t[ii] == nil or t[ii] == "") then
                        	t[ii] = vv
                    	end
                    end
                end    
            end
        end
        if (type (i) == "string") then
            if(configTable[i] == nil) then
                configTable[i] = v
            end    
        end  
    end


    return configTable
end    
