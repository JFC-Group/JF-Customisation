--[[
#### Hussain Vali.
#### TeamF1
#### www.TeamF1.com
#### Aug 14, 2008
#### File: ripng.lua
#### Description: RIPNG configuration functions
#### Revisions:
]]--

--************* Requires *************

--************* Initial Code *************

--package RIP Configuration
ripng = {}

--************* Functions *************
-- RIPNG Configuration
function ripng.ripngConfig (inputTable, rowid, operation)
    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
    	return "ACCESS_DENIED", "ADMIN_REQD"
    end

    db.beginTransaction() --begin transaction
    local valid = false

    -- validate
    if (db.typeAndRangeValidate(inputTable)) then
        local Rowid = db.existsRow ("Ripng", "_ROWID_", rowid)
        if(Rowid) then
 	        valid = db.update("Ripng", inputTable, rowid)
        else
        	valid = db.insert("Ripng", inputTable)
        end
    end

    if(valid) then
 	    db.commitTransaction(true)
    	return "OK", "STATUS_OK"
    else
	    db.rollback()
    	return "ERROR", "RIPNG_CONFIG_FAILED"
    end
end


function ripng.ripngConfigGet ()

    --locals
	local ripngTbl = {}
	local localTable = {}

	query = "_ROWID_=1"
	ripngTbl = db.getRowWhere("Ripng", query ,false)
	if (ripngTbl == nil) then
		return localTable
	end

	--return
	return ripngTbl
end

function ripng.import (RipngTbl, defaultCfg, removeCfg)
    
    if (RipngTbl == nil) then
        RipngTbl = defaultCfg
    end

    local ripngTbl = {}

	if (RipngTbl ~= nil) then
        ripngTbl = config.update (RipngTbl, defaultCfg, removeCfg)
	    for k,v in pairs (ripngTbl) do
			if (v ~= nil) then
	    	    v = util.addPrefix (v, "Ripng.")
		        db.insert("Ripng", v)
			end
	    end
	end
end

function ripng.export ()
    local table = {}
    table =  db.getTable ("Ripng", false)
    return table
end

if (config.register) then
   config.register("Ripng", ripng.import, ripng.export, "2")
end
