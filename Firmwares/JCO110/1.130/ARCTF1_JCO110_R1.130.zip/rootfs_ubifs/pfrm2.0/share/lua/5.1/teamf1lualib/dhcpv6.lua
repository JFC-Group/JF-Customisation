-- Copyright (c) 2017, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd] 

-- Revisions:
-- 01c,25Oct17,sjr changes for Single AP.
-- 01b,08Sep17,swr Changes for SPR 62295
-- 01a,31Jul17,swr  Changes for SPR 60117


dhcpv6 = {}
dhcpv6.server= {}
dhcpv6.debug=1

dhcpv6.mode = {
    IPV6_DHCP_NONE      =    0,
    IPV6_DHCP_SERVER    =    1,
    IPV6_DHCP_RELAY     =    2,
}

dhcpv6.server.mode = {
    STATEFUL_MODE   = 0,
    STATELESS_MODE  = 1,
}

dhcpv6.server.dnsMode = {
    USE_DNS_PROXY       = 1,
    USE_DNS_FROM_ISP    = 2,
    USE_CUSTOM_DNS      = 3,
}

require "teamf1lualib/dhcpv6pool"
require "teamf1lualib/dhcpv6prefix"
require "teamf1lualib/dhcpv6TrExtn"

-------------------------------------------------------------------------
-- @name dhcpv6.config
--
-- @description 
--
-- @return 
--

function dhcpv6.config (tableName, inputTable, rowid, operation)
    -- validate
    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
            return db.insert(tableName, inputTable)
        elseif (operation == "edit") then
            return db.update(tableName, inputTable, rowid)
        elseif (operation == "delete") then
           for k,v in pairs(inputTable) do
                valid  = db.deleteRow(tableName, "_ROWID_", v)
                if (not valid) then  return false end
            end
        end
    end

    return false
end


-------------------------------------------------------------------------
-- @name dhcpv6.import
--
-- @description 
--
-- @return 
--

function dhcpv6.import (dhcpv6Config, defaultCfg, removeCfg)
    if (dhcpv6Config == nil) then
        dhcpv6Config = defaultCfg
    end

    local clientTmp = {}
    local serverTmp = {}
    local poolTmp = {}

    -- Array of Ethernet based WAN devices.
    local ethWANBoardIds = {"/pfrm2.0/HW_HG260ES", "/pfrm2.0/ETHERNET_ONLY", "/pfrm2.0/HW_JCE410"}
    local ethernetDevice = 0
	local  configMergeDone = "0"
    local singleApSupport = "0"
    singleApSupport = db.getAttribute ("environment", "name", "SINGLE_AP_SUPPORT" ,"value")

    
   if (dhcpv6Config["client"] ~= nil) then
        clientTmp = config.update (dhcpv6Config.client, defaultCfg.client, removeCfg.client)
        if (clientTmp ~= nil and #clientTmp ~= 0) then

            for key,value in pairs (ethWANBoardIds) do
                if (util.fileExists (value) ) then
                    ethernetDevice = 1
                end
            end

            for i,v in ipairs (clientTmp) do
                v = util.addPrefix (v, "dhcpv6c.");
		        -- By default Mode should be stateless, for Ethernet devices as per RJIL
                if(util.fileExists("/flash/configMerge/ipv6WanDefaults2") == false) then
                    if (tonumber(ethernetDevice) == 1) then
                        v["dhcpv6c.statelessMode"] = 1
                    else
                        v["dhcpv6c.statelessMode"] = 0
                    end
                    configMergeDone = "1"
                else
                    if (tonumber(ethernetDevice) == 0) then
                        v["dhcpv6c.statelessMode"] = 0
                        if (v["dhcpv6c.LogicalIfName"] == "IF1") then
                            v["dhcpv6c.prefixDelegation"] = 1 
                        end
                    end
                end
                -- By default PD should be disabled or Ethernet devices
                if (tonumber(ethernetDevice) == 1) then
                    if(util.fileExists("/flash/configMerge/pdChange") == false) then
                        v["dhcpv6c.prefixDelegation"] = 0
                    end
                end
                dhcpv6.config ("dhcpv6c", v, -1, "add")
            end
		if (configMergeDone == "1") then
			local ipv6WanDefaults2 = io.open("/flash/configMerge/ipv6WanDefaults2", "w")                                                          
            if(ipv6WanDefaults2 ~= nil) then                                                                       
            	ipv6WanDefaults2:close()                                                                           
            end
			-- touch saveDB flag to do a DB export to flash after import is complete
			local saveDBFile  = io.open("/tmp/callDbSave", "w")                                                          
            if(saveDBFile ~= nil) then                                                                       
            	saveDBFile:close()                                                                           
           	end	
		end
        end
    end
	
   if (dhcpv6Config["server"] ~= nil) then
        serverTmp = config.update (dhcpv6Config.server, defaultCfg.server, removeCfg.server)
        if (serverTmp ~= nil and #serverTmp ~=  0) then
            for i,v in ipairs (serverTmp) do
                v = util.addPrefix (v, "dhcpv6s.");
		-- By default DNS Server should be Use DNS Proxy as per RJIL
		v["dhcpv6s.useDNSServersFrom"] = "1"
                if (singleApSupport ~= nil and singleApSupport == "1") then
                    if (v["dhcpv6s.LogicalIfName"] ~= "IF4" and v["dhcpv6s.LogicalIfName"] ~= "IF5") then
                        dhcpv6.config ("dhcpv6s", v, -1, "add")
                    end
                else
                    if (v["dhcpv6s.LogicalIfName"] ~= "IF4" and v["dhcpv6s.LogicalIfName"] ~= "IF5" and v["dhcpv6s.LogicalIfName"] ~= "IF6" and v["dhcpv6s.LogicalIfName"] ~= "IF7") then
                        dhcpv6.config ("dhcpv6s", v, -1, "add")
                    end
                end
            end
        end
    end
	
   --[[ As per RJIL, Need to include Address information(IANA) for DHCPv6s Stateful
   only incase if prefix obtained from IAPD request on WAN side
   if (dhcpv6Config["pool"] ~= nil) then
       poolTmp = config.update (dhcpv6Config.pool, defaultCfg.pool, removeCfg.pool)
       if (poolTmp ~= nil and #poolTmp ~= 0) then
           for i,v in ipairs (poolTmp) do
               v = util.addPrefix (v, "dhcpv6sLANAddrPool.");
               dhcpv6.config ("dhcpv6sLANAddrPool", v, -1, "add")
           end
       end
   end]]--

   if (dhcpv6Config["prefix"] ~= nil) then
       prefixTmp = config.update (dhcpv6Config.prefix, defaultCfg.prefix, removeCfg.prefix)
       if (prefixTmp ~= nil and #prefixTmp ~= 0) then
           for i,v in ipairs (prefixTmp) do
               v = util.addPrefix (v, "dhcpv6sLANPrefixPool.");
               dhcpv6.config ("dhcpv6sLANPrefixPool", v, -1, "add")

                --update dhcpv6ServerPools table
                dhcpv6Tr.importDhcpv6ServerPools (v)

                -- insert row in ipv6PrefixTable
                dhcpv6Tr.importIPv6PrefixTable (v)
           end
       end
   end

end

-------------------------------------------------------------------------
-- @name dhcpv6.export
--
-- @description 
--
-- @return 
--

function dhcpv6.export ()
	local dhcpv6Tbl = {}

 	local ctable = db.getTable("dhcpv6c" , false)
	if (ctable ~= nil) then
	    dhcpv6Tbl["client"] = ctable
	end

    local stbl = db.getTable("dhcpv6s" , false)
	if (stbl ~= nil) then
	    dhcpv6Tbl["server"] = stbl
	end

	--[[local poolTbl = db.getTable("dhcpv6sLANAddrPool", false)
	if (poolTbl ~= nil) then
	    dhcpv6Tbl["pool"] =  poolTbl
	end]]--

    local prefixTbl = db.getTable("dhcpv6sLANPrefixPool", false)
	if (prefixTbl ~= nil) then
	    dhcpv6Tbl["prefix"] =  prefixTbl
	end

	return dhcpv6Tbl
end
 

if (config.register) then
   config.register("dhcpv6", dhcpv6.import, dhcpv6.export, "1")
end

-------------------------------------------------------------------------
-- @name dhcpv6.server.validate
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcpv6.server.validate (conf)
    require "nimfLib"

    util.appendDebugOut ("DHCP Table:" .. util.tableToStringRec(conf))

    local enable = tonumber(conf["isEnabled"])
    if ((enable ~= 0) and (enable ~= 1)) then
        return "ERROR", "DHCPV6_INVALID_MODE"
    end       

    if (enable == 0) then
        -- No further validation
        return "OK", "STATUS_OK"
    end

    local mode = tonumber(conf["statelessMode"])
    if ((mode ~= dhcpv6.server.mode.STATEFUL_MODE) and
        (mode ~= dhcpv6.server.mode.STATELESS_MODE)) then
        return "ERROR", "DHCPV6_INVALID_MODE"
    end

    local dnsMode = tonumber(conf["useDNSServersFrom"])
    if ((dnsMode ~= dhcpv6.server.dnsMode.USE_DNS_PROXY) and
        (dnsMode ~= dhcpv6.server.dnsMode.USE_DNS_FROM_ISP) and
        (dnsMode ~= dhcpv6.server.dnsMode.USE_CUSTOM_DNS)) then
        return "ERROR", "DHCPV6_INVALID_DNS_MODE"
    end        

    if (dnsMode == dhcpv6.server.dnsMode.USE_CUSTOM_DNS) then
        if ((conf["PrimaryDns"] ~= nil) and 
            (string.len(conf["PrimaryDns"]) > 0)) then
            if (nimfLib.ipv6AddrCheck(conf["PrimaryDns"]) == nil) then
                return "ERROR", "DHCPV6_INVALID_PRIMARY_DNS"
            end            
        end

        if ((conf["SecondaryDns"] ~= nil) and
            (string.len(conf["SecondaryDns"]) > 0))  then
            if (nimfLib.ipv6AddrCheck(conf["SecondaryDns"]) == nil) then
                return "ERROR", "DHCPV6_INVALID_SECONDARY_DNS"
            end            
        end        
    end    

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name dhcpv6.server.cfgInit
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcpv6.server.cfgInit (row, conf)

    if (conf["LogicalIfName"] ~= nil) then
        row["LogicalIfName"] = conf["LogicalIfName"]  
    end        
    
    if (conf["isEnabled"] ~= nil) then
        row["isEnabled"] = conf["isEnabled"]  
    end        

    if (conf["primaryDNSServer"] ~= nil) then
        row["primaryDNSServer"] = conf["primaryDNSServer"]  
    end

    if (conf["secondaryDNSServer"] ~= nil) then
        row["secondaryDNSServer"] =  conf["secondaryDNSServer"]
    end

    if (conf["statelessMode"] ~= nil) then
        row["statelessMode"] = conf["statelessMode"]
    end

    if (conf["useDNSServersFrom"] ~= nil) then
        row["useDNSServersFrom"] = conf["useDNSServersFrom"]  
    end

    if (conf["domainName"] ~= nil) then
        row["domainName"] = conf["domainName"] 
    end

    if (conf["sipServerType"] ~= nil) then
        row["sipServerType"] = conf["sipServerType"] 
    end

    if (conf["sipServer"] ~= nil) then
        row["sipServer"] = conf["sipServer"] 
    end

    if (conf["leaseTime"] ~= nil) then
        row["leaseTime"] = conf["leaseTime"]
    end

    if (conf["serverPreference"] ~= nil) then
        row["serverPreference"] = conf["serverPreference"]
    end

    if (conf["prefixDelegation"] ~= nil) then
        row["prefixDelegation"] = conf["prefixDelegation"]
    end

    return row
end

-------------------------------------------------------------------------
-- @name dhcpv6.server.defCfgGet
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcpv6.server.defCfgGet()
    local conf = {}
    conf["isEnabled"] ="0"
    conf["statelessMode"] = "0"
    conf["leaseTime"] = 86400
    conf["useDNSServersFrom"] = 1
    conf["serverPreference"] = 1

    return conf
end

-------------------------------------------------------------------------
-- @name dhcpv6.server.configure
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcpv6.server.configure (conf, dbFlag)
    require "teamf1lualib/service"
    local query

    if (conf["LogicalIfName"] == nil) then
        return "ERROR","DHCPV6D_INVALID_PARAMS"
    end        

    -- validate the configuration
    local status, errCode = dhcpv6.server.validate(conf)
    if (status ~= "OK") then
        return status, errCode            
    end
            
    -- Get the DHCPv6 server configuration for this network
    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "'"
    local row = db.getRowWhere("dhcpv6s", query, false)
    if (row ~= nil) then
        row = dhcpv6.server.cfgInit(row, conf)

        row = util.addPrefix(row, "dhcpv6s.")
        local valid, errstr = db.update("dhcpv6s", row, row["dhcpv6s._ROWID_"])
        if (not valid) then
            dhcpv6.dprintf("failed to update DHCPv6 server configuration")
            return "ERROR", "DHCPV6D_UPDATE_FAILED"
        end            
    else
        row = dhcpv6.server.defCfgGet()
        row = dhcpv6.server.cfgInit(row, conf)

        util.appendDebugOut ("conf.." .. util.tableToStringRec(row))

        row = util.addPrefix(row, "dhcpv6s.")
        local valid, errstr, rowid  = db.insert("dhcpv6s", row)
        if (not valid) then
            dhcpv6.dprintf("ipv6DhcpConfigure: failed to add DHCPv6 server configuration")
            return "ERROR", "DHCPV6D_ADD_FAILED"
        end            
    end        

    if(dbFlag == 1) then
        service.restart("dhcpv6s", "1")
    end

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name dhcpv6.server.get
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcpv6.server.get (query)
    local rows = {}
    local index = 1
    local cfgTbl = {}

    if (query ~= nil) then
        rows = db.getRowsWhere("dhcpv6s", query, false)
    else
        rows = db.getTable("dhcpv6s", false)
    end        
    
    if (rows ~= nil) then
        for k,v in pairs(rows) do
            cfgTbl[index] = {}                
            cfgTbl[index] = v
            index = index + 1
        end            
    end

    return "OK","STATUS_OK", cfgTbl
end

-------------------------------------------------------------------------
-- @name dhcpv6.dprintf
--
-- @descrription 
--
-- @return 
--

function dhcpv6.dprintf (str)

    if (str == nil) then
        return
    end

    if (dhcpv6.debug == 0) then
        return
    end        

    print("DHCPV6: "  .. str)

    return 
end

-------------------------------------------------------------------------
-- @name dhcpv6.server.delete
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcpv6.server.delete (IDList)
    require "teamf1lualib/service"

    if (IDList == nil) then
        dhcpv6.dprintf("dhcpv6.server.delete: invalid arguments")        
        return "ERROR", "DHCPV6D_INVALID_ARG"
    end
            
    local valid, errstr = db.delete ("dhcpv6s", IDList)
    if (not valid) then
        dhcpv6.dprintf("dhcpv6.server.delete: " ..
                       "failed to delete bindings from db. Err:" .. errstr)
        dhcpv6.dprintf("IDList: " .. util.tableToStringRec(IDList))
        return "ERROR","DHCPV6D_DB_ERR"
    end        

    service.restart("dhcpv6s", "1")

    return "OK", "STATUS_OK"
end
