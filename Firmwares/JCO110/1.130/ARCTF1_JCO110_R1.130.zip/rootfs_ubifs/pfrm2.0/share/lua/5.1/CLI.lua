-- CLI.lua
-- Gaurav Mathur
-- TeamF1
-- www.TeamF1.com

-- Modification History
-- 16may16,vkt Modified for removing the duplicate session settings command
-- from CLI
-- 15feb13,rkm Added CLI support for VLAN
-- 12oct12,rkm Added CLI support for L2TP VPN CLient
-- 10oct12,jd  Added CLI support for hotspot feature
-- 16apr12,vik Fixed Spr#23982 (CLI support for Smtp)
-- 03apr12 vik Fixed SPR#26707
-- 26aug11 nis added CLI support for PPTP VPN Client
-- 28jun11 avr addded CLI support for wlan 
-- 21dec10 bhj added CLI support for sslvpn
-- 23aug10 db  added security support
-- 08amr10 rac added lua library for pptpd and l2tpd servers
-- 27feb10 rac added lua library for dmz
-- 23jan09 ss  added lua libraries for vipsecure, rip, bwLimit, customServices, snmp, firewall6-rule,
--             nimf6CLI, ipMode, idsCLI, radius, trafficMeter, schedules, contentFiltering,
--             sourceMacFiltering, portTriggering, 6to4CLI, isatap, mldproxy, radvd
--             portManagement, langroupsCLI, lanMultihoming, dot11
-- 07nov08 nlm added lua libraries for vpn passthrough, security checks, basic
--             security settings, NAT, Access control and port forwarding rules and
--             DoS attacks 
-- 07oct08 ss  added dhcp lua library
-- 07oct08 ss  reverting changes for accessmgmt and langroups 
--             by removing inclusion of remoteCLI, langroupsCLI lua libraries.
-- 24sep08 rfi adding nimf,dhcpc,pppoe and ifStatic lua libraries
-- 19sep08 rfi adding upnp lua libraries
-- 28nov07 gnm written
--
-- Description
-- CLISH entry point
--

-- Reading security level
local securityLevel = io.open("/etc/security_level.conf", "r")

-- Check if file is there
if(securityLevel) then
    HIGH_SEC = securityLevel:read("*all") or "HIGH"
    if(string.find(HIGH_SEC, "HIGH")) then
        HIGH_SEC = "HIGH"
    else
        HIGH_SEC = "LOW"
    end
    securityLevel:close()
end
local modelIdFile = io.popen("/pfrm2.0/bin/printProductData /etc/mtdDevice ModelId")
if (modelIdFile) then
    MODEL_ID = modelIdFile:read("*line") or "DSR-1000N"
    modelIdFile:close()
end
UNIT_NAME = MODEL_ID
local hwVersionFile = io.popen("/pfrm2.0/bin/printProductData /etc/mtdDevice HwVer")
if (hwVersionFile) then
    HW_VERSION = hwVersionFile:read("*line") or "A1"
    hwVersionFile:close()
end
PRODUCT_ID = MODEL_ID .. "_" .. HW_VERSION
-- load requried libraries
require "teamf1lualib/vlanCLI"
require "teamf1lualib/clishCLI"
require "teamf1lualib/db"
require "teamf1lualib/util"
require "teamf1lualib/utilsCLI"
require "teamf1lualib/timeCLI"
require "teamf1lualib/userdbCLI"
require "teamf1lualib/ifDevCLI"
require "teamf1lualib/logConfigCLI"
require "teamf1lualib/loggingCLI"
require "teamf1lualib/utilitiesCLI"
require "teamf1lualib/systemCLI"
require "teamf1lualib/ddnsCLI"
require "teamf1lualib/upnpCLI"
require "teamf1lualib/nimfCLI"
require "teamf1lualib/iprouteCLI"
require "teamf1lualib/dhcpCLI"
require "teamf1lualib/vpnpassthroughCLI"
require "teamf1lualib/natCLI"
require "teamf1lualib/firewall-ruleCLI"
require "teamf1lualib/ripCLI"
require "teamf1lualib/ipAliasCLI"
require "teamf1lualib/customServicesCLI"
require "teamf1lualib/vipsecureCLI"
require "teamf1lualib/snmpCLI"
require "teamf1lualib/intelAmtCLI"
require "teamf1lualib/firewall6-ruleCLI"
require "teamf1lualib/nimf6CLI"
require "teamf1lualib/ipModeCLI"
require "teamf1lualib/remoteCLI"
require "teamf1lualib/idsCLI"
require "teamf1lualib/radiusCLI"
require "teamf1lualib/extAuthCLI"
require "teamf1lualib/trafficMeterCLI"
require "teamf1lualib/schedulesCLI"
--require "teamf1lualib/contentFilteringCLI"
require "teamf1lualib/smtpAlgCLI"
require "teamf1lualib/sourceMacFilteringCLI"
require "teamf1lualib/6to4CLI"
if (UNIT_NAME == "DSR-1000AC" or UNIT_NAME == "DSR-500AC" or PRODUCT_ID == "DSR-1000_B1" or PRODUCT_ID == "DSR-500_B1") then
require "teamf1lualib/teredoCLI"
end
require "teamf1lualib/isatapCLI"
--require "teamf1lualib/mldproxyCLI"
require "teamf1lualib/radvdCLI"
require "teamf1lualib/portManagementCLI"
--require "teamf1lualib/langroupsCLI"
--require "teamf1lualib/lanMultihomingCLI"
require "teamf1lualib/dmzCLI"
require "teamf1lualib/advancedCLI"
require "teamf1lualib/applicationrulesCLI"
require "teamf1lualib/websiteFilteringCLI"
require "teamf1lualib/usbCLI"
require "teamf1lualib/sharePortCLI"
require "teamf1lualib/pptpClientCLI"
require "teamf1lualib/l2tpClientCLI"
require "teamf1lualib/pptpdCLI"
require "teamf1lualib/l2tpdCLI"
if (HIGH_SEC == "HIGH") then
require "teamf1lualib/sslvpnCLI"
require "teamf1lualib/openvpnCLI"
end
require "teamf1lualib/ethernetCLI"
require "teamf1lualib/tahiCLI"
require "teamf1lualib/switchdriverCLI"
require "teamf1lualib/protocolBindingCLI"
require "teamf1lualib/dmzReservedIpCLI"
--require "teamf1lualib/tempCPCLI"
if (MODEL_ID ~= "DSR-250" and MODEL_ID ~= "DSR-250N" and MODEL_ID ~= "DSR-150" and MODEL_ID ~= "DSR-150N") then
require "teamf1lualib/ospfCLI"
end
if (MODEL_ID ~= "DWC-1000") then
require "teamf1lualib/bwLimitCLI"
require "teamf1lualib/dot11ConfigCLI"
require "teamf1lualib/dot11ShowCLI"
else
require "teamf1lualib/wlanCLI"
require "teamf1lualib/widssecurityCLI"
require "teamf1lualib/clientCLI"
require "wirelessCtrlLuaLib"
require "teamf1lualib/peercontrollerCLI"
require "teamf1lualib/apmanagementCLI"
require "teamf1lualib/approfileCLI"
require "teamf1lualib/globalCLI"
require "teamf1lualib/lmCLI"
require "teamf1lualib/qosCLI"
end
require "teamf1lualib/greCLI"
require "teamf1lualib/igmpCLI"
require "teamf1lualib/webAccessCLI"
--require "teamf1lualib/sessionSettingsCLI"
require "teamf1lualib/lmCLI"
require "teamf1lualib/dynamicwebFiltringCLI"
require "teamf1lualib/accountingCLI"
-- This is a hack for now. We'll attach the CLI to login.login later
ACCESS_LEVEL = 0

-- types
TRUE = 0
FALSE = -1

-- Set language global variable
LANGUAGE = "en_US"

-- Database location
DB_FILE_NAME="/tmp/system.db"

local langFile = io.open("/flash/tmp/lang.txt", "r")
langId = langFile:read("*line")
if (langId == nil or langId == "") then
    langId = "en_US"
end
langString = "/tmp/" .. langId .. ".db"

-- Connect to the system DB once when CLISH starts
db.connect(DB_FILE_NAME)
db.execute("ATTACH '" .. langString .. "' as langDB")
SETTINGS_FILE = db.getAttribute("environment", "name", "TEAMF1_CFG_ASCII", "value")




