--[[
#### Adarsh Uppula
#### TeamF1
#### www.TeamF1.com
#### June 29, 2007

#### File: web.lua
#### Description: Web functions.

#### Revisions:
None
]]--


--************* Requires *************

require "teamf1lualib/login"

--************* Initial Code *************

-- package web
web = {}

--************* Functions *************

-- Go to given page if logged in.
-- Assumes login validation already done.
function web.goToPage (page, htm, clearbutton)
	util.appendDebugOut("Wanting to go to page: " .. page .. "<br>")
	-- clear button press
	if clearbutton then ButtonType = nil end
	-- if htm
	if htm then page = page .. ".html" end
    page = web.pageListCheck(page)
	-- check if good page
	if (page == PLATFORM_PAGE) then
		cgilua.lp.include(HOME_PAGE)
	elseif (page ~= nil and util.fileExists(page)) then
		if (rebootFlag) then
			util.appendDebugOut("Going to reboot page: " .. REBOOT_PAGE .. "<br>")
			cgilua.lp.include(REBOOT_PAGE) --go to next page
		else
                        util.appendDebugOut("Going to the page: " .. page .. "<br>")
                        cgilua.lp.include(page) --go back to current page
		end
	else
		cgilua.lp.include(HOME_PAGE)
	end
end

function web.pageListCheck(pageToGoTo)
    local page_authorised = 0
    local PageList={
--    "6to4TunnelIpv6.html",
    "accessPoints.html",
    "accessPointsMacFilter.html",
    "accessPointsStatus.html",
    "accounting.html",
    "accountingStatus.html",
--    "alg.html",
    "approvedUrls.html",
    "backupRestore.html",
    "bandwidthProfiles.html",
    "blocked.html",
    "blockedKeywords.html",
    "bridgeMode.html",
--    "captivePortalDisabled.html",
--    "captivePortal.html",
    "cgi-action.html",
    "configurablePort.html",
    "connectionEntryFlush.html",
    "contentFiltering.html",
    "cosMapping.html",
    "customServices.html",
    "dashboard.html",
    "dateAndTime.html",
    "defaultPolicy.html",
    "deviceStatistics.html",
    "deviceStatus.html",
    "diagDisplay.html",
    "diagnostics.html",
    "diagnosticsPtrace.html",
    "disks.html",
--    "dmzConfig.html",
--    "dmzDhcpLeasedClients.html",
--    "dmzDhcpReservedIps.html",
    "dmzHost.html",
    "dmzV6Host.html",
    "dosDDoSPrevention.html",
    "dscpMapping.html",
--    "dynamicRouting.html",
    "errorPage.html",
    "eogre.html",
    "exportWebFilter.html",
    "firewallRules.html",
    "footer.html",
    "forcedLogin.html",
--    "ftpServer.html",
    "getFirmwareStatus.html",
    "getHelp.html",
    "groups.html",
    "header.html",
    "headerPlain.html",
    "igmpProxySetup.html",
    "imsDomains.html",
    "index.html",
    "ipMode.html",
    "ipv6Routing.html",
--    "isatapTunnels.html",
    "lanDhcpLeasedClients.html",
    "lanDhcpV6LeasedClients.html",
    "lanIPv4Config.html",
--    "lanIpv4DhcpSipServer.html",
    "lanIPv4DhcpVendorClass.html",
    "lanIPv4ReservedIPs.html",
    "lanIPv6Config.html",
--    "macFiltering.html",
    "maptAvailablePorts.html",
    "maptConfiguration.html",
    "maptPortStats.html",
    "metaInclude.html",
    "mldSetup.html",
    "networkSharing.html",
--    "p2pSessionLimitation.html",
    "portForwarding.html",
    "portVlan.html",
    "prefixList.html",
    "profiles.html",
    "progressBar.html",
    "radiusConfig.html",
    "rdvd.html",
--    "remoteManagement.html",
--    "remoteSysLogSetup.html",
--    "ripng.html",
    "routingMode.html",
    "schedules.html",
    "secureF1rstExtensions.html",
    "serialNum.html",
    "showHelp.html",
--    "sipAlg.html",
    "specificAttacks.html",
    "staticRouting.html",
    "statusPage.html",
    "switchFirmware.html",
--    "telnet.html",
    "tftpServername.html",
--    "tr-069ClientConfig.html",
    "trafficSelectors.html",
--    "tunnelStatusIpv6.html",
    "unauthorizedUsage.html",
    "upgradeViaNetwork.html",
    "upnpConfig.html",
--    "userAccessPortalSession.html",
--    "userAccessPortalSetup.html",
    "users.html",
    "vendorSpecificInformation.html",
--    "viewLogs.html",
    "vlanSettings.html",
    "vpnPassthrough.html",
    "wanIPv4Config.html",
    "wanIpv6Config.html",
    "wanPortType.html",
    "webManagement.html",
    "wirelessClients.html",
    "wirelessStatistics.html",
    "wmm.html",
    "wps.html",
--    "acsPasswordGeneration.html",
    "deviceList.html",
    "parentalGuidance.html",
    "serverSettings.html",
--    "mediaSharing.html",
    "backup.lua",
    "download.lua",
    "csvDownload.lua",
    "platform.lua",
    "dbglog.lua",
    "clientAccessControl.html",
    "freeMemCheck.html",
    "changePassword.html",
    "dscpToCosMapping.html",
    "firewallRulesIPv6.html",
    "dropInvalidConnections.html",
    "wanStatus.html",
    "lanStatus.html",
    "apGroupName.html",
    "wirelessStatus.html",
    "lanIPv6AddressPools.html",
    "lanIPv6PrefixLength.html"
    }

    -- Device specific whitelist pages
    local PageList_HG260ES = {}
    if (util.fileExists ("/pfrm2.0/HW_HG260ES")) then
        PageList_HG260ES={
        "vlanWan.html"
        }
    end

    local PageList_BRCM = {}
    if (util.fileExists ("/pfrm2.0/BRCMJCO300")) then
        PageList_BRCM={
        "getCurrentChannel.html",
        "getCurrentChannelRadio2.html",
        "radioadvancedConfig24GHz.html",
        "radioadvancedConfig5GHz.html",
        "radioBasicConfig24GHz.html",
        "radioBasicConfig5GHz.html",
--        "deviceAccess.html",
        "multiSubnet.html"
        }
    end
    local PageList_JCO4032
   if (util.fileExists ("/pfrm2.0/HW_JCO4032") or util.fileExists ("/pfrm2.0/HW_JCOW407") or util.fileExists ("/pfrm2.0/HW_JCOW402")) then
        PageList_JCO4032={
        "getCurrentChannel.html",
        "getCurrentChannelRadio2.html",
        "radioadvancedConfig24GHz.html",
        "radioadvancedConfig5GHz.html",
        "radioBasicConfig24GHz.html",
        "radioBasicConfig5GHz.html",
--        "deviceAccess.html",
        "multiSubnet.html",
--        "meshConfiguration.html",
        "meshTopology.html"
}
    end 

    local PageList_LNTQ = {}
    if (util.fileExists ("/pfrm2.0/INTEL_LNTQ")) then
        PageList_LNTQ={
        "osgiApplication.html",     
        "radioadvancedConfig.html",
        "radioBasicConfig.html",
        "vlanWan.html",
--        "ieee1905.html"
        }
    end
    
    local PageList_ARCAD = {}
    if (util.fileExists ("/pfrm2.0/ARCADYAN")) then
        PageList_ARCAD={
        "osgiApplication.html",      
        "radioadvancedConfig.html",
        "radioBasicConfig.html",
        "vlanWan.html"
        }
    end

    -- To remove any special characters to avoid sql injection
    pageToGoTo = db.escape(pageToGoTo)

    for count = 1, #PageList do
        if PageList[count] == pageToGoTo then
    	    page_authorised = 1
    	    break
        end
    end
    if (util.fileExists ("/pfrm2.0/HW_HG260ES")) then
        for count = 1, #PageList_HG260ES do
            if PageList_HG260ES[count] == pageToGoTo then
        	page_authorised = 1
        	break
            end
        end
    end

     if (util.fileExists ("/pfrm2.0/BRCMJCO300")) then
        for count = 1, #PageList_BRCM do
            if PageList_BRCM[count] == pageToGoTo then
        	 page_authorised = 1
        	 break
            end
        end
    end

     if (util.fileExists ("/pfrm2.0/HW_JCO4032") or util.fileExists ("/pfrm2.0/HW_JCOW407") or util.fileExists ("/pfrm2.0/HW_JCOW402")) then
        for count = 1, #PageList_JCO4032 do
            if PageList_JCO4032[count] == pageToGoTo then
        	 page_authorised = 1
        	 break
            end
        end
    end

    if (util.fileExists ("/pfrm2.0/INTEL_LNTQ")) then
        for count = 1, #PageList_LNTQ do
            if PageList_LNTQ[count] == pageToGoTo then
        	 page_authorised = 1
        	 break
            end
        end
    end

    if (util.fileExists ("/pfrm2.0/ARCADYAN")) then
        for count = 1, #PageList_ARCAD do
            if PageList_ARCAD[count] == pageToGoTo then
        	 page_authorised = 1
        	 break
            end
        end
    end

    if page_authorised == 0 then	
        pageToGoTo = ERROR_PAGE
    end
    return pageToGoTo
end

-- Run given page if logged in.
-- Assumes login validation already done.
function web.runPage (page)
	-- check if good page
	if (cgi.page == PLATFORM_PAGE) then
		cgilua.lp.include(HOME_PAGE)
	elseif (page ~= nil and util.fileExists(page)) then
		dofile(page)
	else
		cgilua.lp.include(HOME_PAGE)
	end
end

-- Put file as string.
function web.includeFile (filepath)
	cgilua.put(util.fileToString(filepath))
end

-- Put file as string after lua procesing.
function web.includeMenu (filepath)
	cgilua.lp.include(filepath)
end

-- Convert given cgi table (only fields) to a LUA table.
-- Returns nil on error.
function web.cgiToLuaTable (cgitable)
	local luaTable = {}
	local splitparts = {}
	local keyStr = ""
	for k,v in pairs(cgitable) do
		splitparts = util.split(k, ".")
		if (#splitparts == 2) then
			-- for checkbox fields
			if (type(v) == "table" and #v == 2) then
				luaTable[splitparts[1] .. "." .. splitparts[2]] = v[1]
			-- for file upload
			elseif (type(v) == "table" and #v == 4) then
				luaTable[splitparts[1] .. "." .. splitparts[2]] = v
			-- regular field
			else
				luaTable[splitparts[1] .. "." .. splitparts[2]] = v
			end
		elseif(#splitparts == 1) then
			-- for checkbox fields
			if (type(v) == "table" and #v == 2) then
				luaTable[splitparts[1]] = v[1]
			-- for file upload
			elseif (type(v) == "table" and #v == 4) then
				luaTable[splitparts[1]] = v
			-- regular field
			else
				luaTable[splitparts[1]] = v
			end
		end
	end

	-- return
	return luaTable
end

-- Search given cgi table for button and return its (fixed) name.
function web.cgiFindButton (cgi)
	local field, splitted, value = web.cgiSearch(cgi, "button")
	if (splitted ~= nil and (splitted[#splitted] == "x" or splitted[#splitted] == "y")) then
		table.remove(splitted, #splitted)
		field = splitted[1]
		for k,v in pairs(splitted) do
			if (k ~= 1) then
				field = field .. "." .. v
			end
		end
	end
	return field, splitted, value
end

-- Search given cgi table for token and return its (fixed) name.
function web.cgiFindToken (cgi)
	local field, splitted, value = web.cgiSearch(cgi, "token")
	if (splitted ~= nil and (splitted[#splitted] == "x" or splitted[#splitted] == "y")) then
		table.remove(splitted, #splitted)
		field = splitted[1]
		for k,v in pairs(splitted) do
			if (k ~= 1) then
				field = field .. "." .. v
			end
		end
	end
	return field, splitted, value
end


-- Search given cgi table and return value where key's
-- first part is given token. Returns table if value is not
-- a table with key "1".
-- Returns nil on error.
function web.cgiSearch (table, token)
	local splitted = {}
	local tab = {}
	for k,v in pairs(table) do
		splitted = util.split(k, ".")
		if (#splitted >= 1 and splitted[1] == token) then
			if (type(v) == "table") then
				return k, splitted, v
			else
				tab["1"] = v
				return k, splitted, tab
			end
		end
	end
	
	--none found
	return nil, nil, nil
end

-- If value true, return "checked", else "".
function web.checkboxSelected (value)
	--if equal
	if value then
		return "CHECKED"
	else
		return ""
	end
end

-- If value true, return "selected", else "".
function web.radioSelected (value)
	--if equal
	if value then
		return "CHECKED"
	else
		return ""
	end
end

-- If value true, return "selected", else "".
function web.dropdownSelected (value)
	--if equal
	if value then
		return "SELECTED"
	else
		return ""
	end
end

-- If value true, return "disabled", else "".
function web.inputDisabled (value)
	--if equal
	if value then
		return "DISABLED"
	else
		return ""
	end
end

-- Return argument corresponding to index (a string).
function web.getArgsFromIndex (index, arg0, arg1, arg2, arg3)
	if index == "0" then
		return arg0
	elseif index == "1" then
		return arg1
	elseif index == "2" then
		return arg2
	elseif index == "3" then
		return arg3
	end
end

-- Let user download given file as given name.
function web.download (filepath, filename)
	--set filedownload cookie
	cgilua.cookies.set("TeamF1Download","started")
	cgilua.header("Content-type", "application/octet-stream;")
	cgilua.header("Content-disposition", "attachment; filename=" .. filename)
	cgilua.put("\n" .. util.fileToString(filepath))
end

function web.sendXML (filepath, filename)
	cgilua.header("Content-type", "text/xml;")
--	cgilua.header("Content-disposition", "attachment; filename=" .. filename)
	cgilua.put("\n" .. util.fileToString(filepath))
end

function web.sendJSON (msg)
	cgilua.header("Content-type", "application/json;")
	cgilua.put("\n" .. msg)
end

-- If value true, return "SELECTED", else "".
function web.multiDropDownSelected (inputArray, value)
    for u,v in pairs(inputArray) do
		--if equal
		if v == value then
		   return "SELECTED"
        end
    end
    return ""
end

-- Routine to prevent resubmission of add/edit forms when page is refreshed
function web.checkRefresh (pageRedirect)
    -- Code to check if user clicked refresh or save button
    if ((cgilua.cookies.get("recordModified") ~= nil and cgilua.cookies.get("recordModified") == "0") or cgilua.cookies.get("recordModified") == nil) then
        -- set coookie
       cgilua.cookies.set("recordModified", 1)       
    else
        -- Redirect code if user clicked refresh         
        local redirectURLTbl = util.split(os.getenv("HTTP_REFERER"),"platform.cgi")
        if (redirectURLTbl[1] ~= nil) then 
            cgilua.redirect (redirectURLTbl[1].."platform.cgi?page="..pageRedirect..".html")
            os.exit(1)
        end
    end
end
