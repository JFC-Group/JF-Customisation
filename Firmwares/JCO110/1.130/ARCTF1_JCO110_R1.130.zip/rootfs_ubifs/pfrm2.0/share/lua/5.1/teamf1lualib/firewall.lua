--[[
#### File: firewall.lua
#### Description: IPv4 and IPv6 Firewall Rules' Configuration APIs
#### modification history:
     ----------------------
---- 01t,25Oct17,sjr changes for Single AP.
---- 01s,31Jul17,swr Changes for SPR 60117
---- 01r,16Apr17,sjr SPR #59793, modified import logic for dot11ProfileDef table
---- 01q,22Dec16,swr Changes for SPR 58655
---- 01p,10Sep16,swr Changes for SPR 57249(cas optimization)
---- 01o,29Feb16,swr Fix for SPR 55249
---- 01n,17Dec15,swr Fix for SPR 54404 and 54380
---- 01m,02Dec15,swr Fix for SPR 54403
---- 01l,25Nov15,swr Fix for SPR 54340
---- 01k,06Apr15,swr Fix for SPR 50469
---- 01j,31mar15,mmk Added one to one inbound firewall mapping support.
---- 01i,20dec14,mmk Added port based firewall
---- 01i,06dec14,mmk Added icsa related attack checks
---- 01h,06dec14,mmk Added routing, system and IPv6 logs support.
---- 01g,10sep13,drk changes for P2P session Limit support
---- 01h,29aug13,ash changes for SPR#39718
---- 01g,10aug13,ash changes for bandwidth monitoring
---- 01f,12feb13,lnv added mac filtering, content filtering support
---- 01e,16jul12,vik added attack checks support.
---- 01d,27jun12,nis changed custom service edit msg as per QA expectations (SPR 32837)
---- 01d,10apr12,nis added code to display open ports in UI
---- 01c,06apr12,nis added various checks for custom services
---- 01b,21mar12,nis added changes to support IPv6 rules
---- 01a,07mar12,nis written.
]]--

--************* Requires *************
require "teamf1lualib/ifDev"
require "teamf1lualib/validations"

--************* Initial Code *********

--************* Defines **************
IPv4DBTable = "FirewallRules"
IPv6DBTable = "FirewallRules6"
L2DBTable = "L2FirewallRules"
MACConfigTbl = "clientMacConfig"

--************* Packages *************
fw = {}
firewall = {}
firewallv4 = {}
firewallv6 = {}
firewallL2 = {}
firewallMAC = {}
--************* Functions *************
-------------------------------------------------------------------------------
-- @name : firewall.tf1Dbg - print dbg messages
-- 
-- @description : This function prints dbg messages to a file
--
function firewall.tf1Dbg(dbgMessage) 
   local dbgfile = ""
   dbgfile = io.open("/var/log/tf1FwDbg.log","a")
   if dbgfile~=nil then 
       dbgfile:write(dbgMessage .. "\n")
       io.close(dbgfile) 
   end
end

-------------------------------------------------------------------------------
-- @name : firewall.firewallRulesConfig()
--
-- @description : API to perform various conversions and validations before
-- setting values in DB during add/edit operation
--
-- @return : status, errorMsg
-- 
function firewall.firewallRulesConfig(inputTable, rowid, operation,trcall)
    local statusFlag = true
    --db.beginTransaction() --begin transactions

    if((inputTable["SourceAddressStart"] == inputTable["DestinationAddressStart"]) and (inputTable["SourceAddressType"] == "1") and (inputTable["DestinationAddressType"] == "1"))then
        return "ERROR", "source and destination should not be same"
    end

    if (inputTable ~= nil) then 
        inputTable.FromZoneType = "SECURE"
        inputTable.ToZoneType = "INSECURE"
        inputTable.RuleType = "SECURE_INSECURE"
    end

    inputTable = util.addPrefix(inputTable, "FirewallRules.")
  
    statusFlag = firewallv4.config(inputTable, rowid, operation)
    
    -- return
    if (statusFlag) then
        --db.commitTransaction(true)
    	return "OK", "STATUS_OK"
    else
	    --db.rollback()
    	return "ERROR", "FW_CONFIG_FAILED"
    end
end

-------------------------------------------------------------------------------
-- @name : firewall.portFwdRulesConfig()
--
-- @description : API to perform various conversions and validations before
-- setting values in DB during add/edit operation
--
-- @return : status, errorMsg
-- 
function firewall.portFwdRulesConfig(inputTable, rowid, operation)
    local statusFlag = true
    -- 1 is nat & 2 is classical
    local routeMode = db.getAttribute ("routingMode", "_ROWID_", "1", "natSetting") or ''
    --db.beginTransaction() --begin transactions

    if((inputTable["SourceAddressStart"] == inputTable["DNATAddress"]) and inputTable["SourceAddressType"] == "1")then
        return "ERROR" ,"source and destination should not be same"
    end

    if (inputTable ~= nil) then 
        inputTable.FromZoneType = "INSECURE"
        inputTable.ToZoneType = "SECURE" 
        inputTable.RuleType = "INSECURE_SECURE"
        --set 'DNATPortEnable' based on routing mode in the device
        if(routeMode == "1") then
            inputTable.DNATPortEnable = "1"
        else
            inputTable.DNATPortEnable = "0"
        end
    end

    if (UNIT_INFO ~= "ODU") then
    	if (inputTable.DestinationAddressType == "2") then
    		local portype = db.getAttribute ("Services", "ServiceName", inputTable.ServiceName, "PortType")
    		local isdefault = db.getAttribute ("Services", "ServiceName", inputTable.ServiceName, "IsDefault")
		if (portype == "2" or isdefault == "1") then
			return "ERROR", "INTERNAL_PORT_TYPE_AS_SINGLE"
		else
			local portstart = db.getAttribute ("Services", "ServiceName", inputTable.ServiceName, "DestinationPortStart")
    			local portend = db.getAttribute ("Services", "ServiceName", inputTable.ServiceName, "DestinationPortEnd")
			local diff = portend - portstart
			if (diff ~= tonumber(inputTable.DnatPortRangeLength)) then
				return "ERROR", "INTERNAL_PORT_LENGTH_AND_CUSTOM_PORT_RANGE_DIFF_SHOULD_SAME"
			end
            if (tonumber(inputTable.DnatPortRangeLength) > 10) then
                return "ERROR", "INTERNAL_PORT_LENGTH_SHOULD_LESS_THAN_TEN"
            end
		end
    	end
    	inputTable.DestinationAddressInvert = inputTable.DnatPortRangeLength 
    end
    inputTable = util.addPrefix(inputTable, "FirewallRules.")
    
    statusFlag = firewallv4.config(inputTable, rowid, operation)
    
    -- return
    if (statusFlag) then
        --db.commitTransaction(true)
    	return "OK", "STATUS_OK"
    else
	    --db.rollback()
    	return "ERROR", "FW_CONFIG_FAILED"
    end
end

-------------------------------------------------------------------------------
-- @name : firewall.firewallRules6Config()
--
-- @description : API to perform various conversions and validations before
-- setting values in DB during add/edit operation
--
-- @return : status, errorMsg
-- 
function firewall.firewallRules6Config(inputTable, rowid, operation)
    local statusFlag = true
    db.beginTransaction() --begin transactions

    if (inputTable["SourceAddressStart"] ~= nil) then
        --ipv6 address validation
        if (string.match(inputTable["SourceAddressStart"],'^fe80') or string.match(inputTable["SourceAddressStart"],'^FE80')) then
            -- check if the ipv6 is not a link-local address
            return "ERROR","Link-Local ip addresses are not allowed"
        elseif ((ifDevLib.isIpv6AddressReserved(inputTable["SourceAddressStart"])) > 0 ) then
            -- check if the ipv6 is a reserved
            return "ERROR","Reserved ip addresses are not allowed"
        elseif(ifDevLib.isIpv6AddressMulticast(inputTable["SourceAddressStart"]) > 0 ) then
            -- check if the ipv6 is multicast address
            return "ERROR","Multicast ip addresses are not allowed"
        elseif (validations.ipv6AddrValidate(inputTable["SourceAddressStart"],"", "") ~= 0 ) then
            return "ERROR","invalid ip address"
        end
    end
    
    if (inputTable["DestinationAddressStart"] ~= nil) then
        --ipv6 address validation
        if (string.match(inputTable["DestinationAddressStart"],'^fe80') or string.match(inputTable["DestinationAddressStart"],'^FE80')) then
            -- check if the ipv6 is not a link-local address
            return "ERROR","Link-Local ip addresses are not allowed"
        elseif ((ifDevLib.isIpv6AddressReserved(inputTable["DestinationAddressStart"])) > 0 ) then
            -- check if the ipv6 is a reserved
            return "ERROR","Reserved ip addresses are not allowed"
        elseif(ifDevLib.isIpv6AddressMulticast(inputTable["DestinationAddressStart"]) > 0 ) then
            -- check if the ipv6 is multicast address
            return "ERROR","Multicast ip addresses are not allowed"
        elseif (validations.ipv6AddrValidate(inputTable["DestinationAddressStart"],"", "") ~= 0 ) then
            return "ERROR","invalid ip address"
        end
    end

    if((inputTable["SourceAddressStart"] == inputTable["DestinationAddressStart"]) and (inputTable["SourceAddressType"] == "1") and (inputTable["DestinationAddressType"] == "1") ) then 
        return "ERROR", "source and destination should not be same"
    end

    if (inputTable ~= nil) then

        if (inputTable.Direction == "Inbound") then
            inputTable.FromZoneType = "INSECURE"
            inputTable.ToZoneType = "SECURE" 
        elseif (inputTable.Direction == "Outbound") then
            inputTable.FromZoneType = "SECURE"
            inputTable.ToZoneType = "INSECURE"
        end 

        -- Concatenate Zone Types to obtain Rule Type
        inputTable.RuleType = inputTable.FromZoneType .. "_" .. inputTable.ToZoneType
    end

    inputTable = util.addPrefix(inputTable, "FirewallRules6.")
    
    statusFlag = firewallv6.config(inputTable, rowid, operation)
    
    if (statusFlag) then
        db.commitTransaction(true)
    	return "OK", "STATUS_OK"
    else
	    db.rollback()
    	return "ERROR", "FW_CONFIG_FAILED"
    end
end

-------------------------------------------------------------------------------
-- @name : firewall.firewallRulesL2Config()
--
-- @description : API to perform various conversions and validations before
-- setting values in DB during add/edit operation
--
-- @return : status, errorMsg
-- 
function firewall.firewallRulesL2Config(inputTable, rowid, operation)
    local statusFlag = true
    db.beginTransaction() --begin transactions

    if (inputTable ~= nil) then

        if (inputTable.Direction == "Inbound") then
            inputTable.FromZoneType = "INSECURE"
            inputTable.ToZoneType = "SECURE" 
        elseif (inputTable.Direction == "Outbound") then
            inputTable.FromZoneType = "SECURE"
            inputTable.ToZoneType = "INSECURE"
        end 

        -- Concatenate Zone Types to obtain Rule Type
        inputTable.RuleType = inputTable.FromZoneType .. "_" .. inputTable.ToZoneType
    end

    inputTable = util.addPrefix(inputTable, "L2FirewallRules.")
    
    statusFlag = firewallL2.config(inputTable, rowid, operation)
    
    if (statusFlag) then
        db.commitTransaction(true)
    	return "OK", "STATUS_OK"
    else
	    db.rollback()
    	return "ERROR", "FW_CONFIG_FAILED"
    end
end

-------------------------------------------------------------------------------
-- @name : firewall.fwCustomSvcConfig()
--
-- @description : 
--
-- @return : 
-- 
function firewall.fwCustomSvcConfig(inputTable, rowid, operation)
    local statusFlag = true
    --db.beginTransaction() --begin transactions

    if (inputTable ~= nil) then 
        inputTable.TypeOfService = "0"
        inputTable.IsDefault = "0"
        if (inputTable.Protocol == "1") then
            inputTable.PortType = "1"
        end
    end

    inputTable = util.addPrefix(inputTable, "Services.")
  
    statusFlag = fw.config("Services", inputTable, rowid, operation)
    
    -- return
    if (statusFlag) then
        --db.commitTransaction(true)
    	return "OK", "STATUS_OK"
    else
	    --db.rollback()
    	return "ERROR", "CS_CONFIG_FAILED"
    end
end

-------------------------------------------------------------------------------
-- @name : firewall.portTriggerRulesConfig()
--
-- @description : API to perform various conversions and validations before
-- setting values in DB during add/edit operation
--
-- @return : status, errorMsg
-- 
function firewall.portTriggerRulesConfig(inputTable, rowid, operation)
    local statusFlag = true
    db.beginTransaction() --begin transactions

    inputTable = util.addPrefix(inputTable, "PortTriggering.")
    
    statusFlag = fw.config("PortTriggering", inputTable, rowid, operation)
    
    -- return
    if (statusFlag) then
        db.commitTransaction(true)
    	return "OK", "STATUS_OK"
    else
	    db.rollback()
    	return "ERROR", "FW_CONFIG_FAILED"
    end
end

-------------------------------------------------------------------------------
-- @name : firewall.fwRulesGet()
--
-- @description : This function returns all the outbound ipv4 firewall rules 
--
-- @return : lua table containing all the rules that need to be displayed
--
function firewall.fwRulesGet()
    return db.getRowsWhere ("FirewallRules", "RuleType = 'SECURE_INSECURE'", false)
end

-------------------------------------------------------------------------------
-- @name : firewall.portFwdRulesGet()
--
-- @description : This function returns all the port forward firewall rules 
--
-- @return : lua table containing all the rules that need to be displayed
--
function firewall.portFwdRulesGet()
    return db.getRowsWhere ("FirewallRules", "RuleType = 'INSECURE_SECURE'", false)
end

-------------------------------------------------------------------------------
-- @name : firewall.fwRules6Get()
--
-- @description : This function returns the entire FirewallRules6 table
--
-- @return : lua table containing all the rules that need to be displayed
--
function firewall.fwRules6Get()
    return db.getTable ("FirewallRules6", false)
end

-------------------------------------------------------------------------------
-- @name : firewall.fwRulesL2Get()
--
-- @description : This function returns the entire L2FirewallRules table
--
-- @return : lua table containing all the rules that need to be displayed
--
function firewall.fwRulesL2Get()
    return db.getTable ("L2FirewallRules", false)
end
-------------------------------------------------------------------------------
-- @name : firewall.portTriggerRulesGet()
--
-- @description : This function returns all the port triggering rules 
--
-- @return : lua table containing all the rules that need to be displayed
--
function firewall.portTriggerRulesGet()
    return db.getTable ("PortTriggering", false)
end

-------------------------------------------------------------------------------
-- @name : firewall.openPortsGet()
--
-- @description : This function returns all the open ports in the device
--
-- @return : lua table
-- 
function firewall.openPortsGet()
    --locals
    local portTrigTbl = {}
    local row = {}
    local ifStaticTbl = {}

    -- require
    require "fwPortTriggerLuaLib"

    portTrigTbl = fwPortTriggerLuaLib.portTriggerStatsGet()

    for k,v in pairs (portTrigTbl) do
        portTrigTbl[k] = {}
       
        -- iterate over all the entries        
        for kk, vv in pairs (v) do
            if (kk == "openPortStart") then
                startPort = vv                
            end

            if (kk == "openPortEnd") then
                endPort = vv                
            end

            if (kk == "ipAddr") then
                portTrigTbl[k].ipAddr = vv
            end

            if (kk == "timeRemaining") then
                portTrigTbl[k].timeRemaining = vv
            end
        end
        portTrigTbl[k].openPortsRange = startPort .. "-" .. endPort
       
        -- we have all the info at this stage except for network name
        -- which we will access from 'ifStatic' table
        
        local query = "AddressFamily = 2"
        local statusFlag = 0
        local ifStaticTbl = db.getRowsWhere ("ifStatic", query, false)
        
        if (ifStaticTbl ~= nil) then
            -- iterate over all the rows of 'ifStatic' table to check for each
            -- network
            for p,q in pairs (ifStaticTbl) do      
                local zone
                zone = db.getAttribute ("networkInterface", "LogicalIfName", q["LogicalIfName"], "zoneType")

                if (q["StaticIp"] ~= "0.0.0.0" and q["StaticIp"] ~= nil and zone ~= "insecure") then
                    -- check whether IP lies in given 'secure' network or not
                    statusFlag = fwPortTriggerLuaLib.getNetwork (q["StaticIp"], q["NetMask"], portTrigTbl[k].ipAddr)
                    if (statusFlag == 1) then
                        portTrigTbl[k].networkName = db.getAttribute ("networkInterface", "LogicalIfName", q["LogicalIfName"], "networkName")
                    end
                end
            end
        end
    end
    
    return portTrigTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.fwCustomSvcGet()
--
-- @description :  
--
-- @return : 
-- 
function firewall.fwCustomSvcGet()
    return db.getRowsWhere ("Services", "IsDefault = '0'", false)
end

-------------------------------------------------------------------------------
-- @name : firewall.fwServiceGet()
--
-- @description :  
--
-- @return : 
-- 
function firewall.fwServiceGet()
    return db.getTable ("Services", false)
end

-------------------------------------------------------------------------------
-- @name : firewall.fwRulesAddGet()
--
-- @description : This function returns the default values for ipv4 outbound
-- rules to be displayed (mainly for drop-downs)
--
-- @return : lua table containing the default values 
--
function firewall.fwRulesAddGet()
    fwIpv4DefTbl = {}
    fwIpv4DefTbl.Services = {}
    fwIpv4DefTbl.Services = db.getDistinctValues ("Services", "ServiceName")    
    fwIpv4DefTbl.lanNetworks = {}
    fwIpv4DefTbl.lanNetworks = db.getRowsWhere ("networkInterface", "zoneType = 'secure'", false)
    fwIpv4DefTbl.wanNetworks = {}
    fwIpv4DefTbl.wanNetworks = db.getRowsWhere ("networkInterface", "zoneType = 'insecure'", false)
    return fwIpv4DefTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.portFwdRulesAddGet()
--
-- @description : This function returns the default port forwarding values to be 
-- displayed (mainly for drop-downs)
--
-- @return : lua table containing the default values 
--
function firewall.portFwdRulesAddGet()
    portFwdDefTbl = {}
    portFwdDefTbl.Services = {}
    portFwdDefTbl.Services = db.getTable("Services")

    return portFwdDefTbl
end
-------------------------------------------------------------------------------
-- @name : firewall.fwRules6AddGet()
--
-- @description : This function returns the default values to be displayed
--
-- @return : lua table containing the default values 
--
function firewall.fwRules6AddGet()
    fwIpv6DefTbl = {}
    fwIpv6DefTbl.Services = {}
    fwIpv6DefTbl.Services = db.getDistinctValues ("Services", "ServiceName")    
    fwIpv6DefTbl.lanNetworks = {}
    fwIpv6DefTbl.lanNetworks = db.getRowsWhere ("networkInterface", "zoneType = 'secure'", false)
    fwIpv6DefTbl.wanNetworks = {}
    fwIpv6DefTbl.wanNetworks = db.getRowsWhere ("networkInterface", "zoneType = 'insecure'", false)
    return fwIpv6DefTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.fwRulesL2AddGet()
--
-- @description : This function returns the default values to be displayed
--
-- @return : lua table containing the default values 
--
function firewall.fwRulesL2AddGet()
    fwL2DefTbl = {}
    fwL2DefTbl.Services = {}
    fwL2DefTbl.Services = db.getDistinctValues ("Services", "ServiceName")    
    fwL2DefTbl.lanNetworks = {}
    fwL2DefTbl.lanNetworks = db.getRowsWhere ("networkInterface", "zoneType = 'secure'", false)
    fwL2DefTbl.wanNetworks = {}
    fwL2DefTbl.wanNetworks = db.getRowsWhere ("networkInterface", "zoneType = 'insecure'", false)
    return fwL2DefTbl
end
-------------------------------------------------------------------------------
-- @name : firewall.portTriggerRulesAddGet()
--
-- @description : This function returns the default port triggering values to be 
-- displayed (mainly for drop-downs)
--
-- @return : lua table containing the default values 
--
function firewall.portTriggerRulesAddGet()
    portTriggerDefTbl = {}
    portTriggerDefTbl.Networks = {}
    portTriggerDefTbl.Networks = db.getRowsWhere ("networkInterface", "zoneType = 'secure'", false)
    return portTriggerDefTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.fwRulesAddSet()
--
-- @description : This function is used to set the DB when an IPv4 rule is added
--
-- @return : status, errorMsg
--
function firewall.fwRulesAddSet(firewallAddTable)
    --locals
    local protocol

    protocol = db.getAttribute ("Services", "ServiceName", firewallAddTable.ServiceName, "Protocol")
    if (protocol == "58") then
        return "ERROR", "ICMPv6-type service is not supported for IPv4 Firewall Rules!"
    end

    return firewall.firewallRulesConfig(firewallAddTable, "-1", "add")  
end

-------------------------------------------------------------------------------
-- @name : firewall.portFwdRulesAddSet()
--
-- @description : This function is used to set the DB when a Port Fwd rule is added
--
-- @return : status, errorMsg
--
function firewall.portFwdRulesAddSet(firewallAddTable)
    --locals
    local protocol

    protocol = db.getAttribute ("Services", "ServiceName", firewallAddTable.ServiceName, "Protocol")

    

    if (protocol == "1") then
        return "ERROR", "ICMPv6-type service is not supported for Port Forwarding Rules!"
    end

    return firewall.portFwdRulesConfig(firewallAddTable, "-1", "add")  
end

-------------------------------------------------------------------------------
-- @name : firewall.fwRules6AddSet()
--
-- @description : This function is used to set the DB when an IPv6 rule is added
--
-- @return : status, errorMsg
--
function firewall.fwRules6AddSet(firewallAddTable)
    local protocol
    
    protocol = db.getAttribute ("Services", "ServiceName", firewallAddTable.ServiceName, "Protocol")
    if (protocol == "1") then
        return "ERROR", "ICMP (v4) type service is not supported for IPv6 Firewall Rules!"
    end

    return firewall.firewallRules6Config(firewallAddTable, "-1", "add")  
end

-------------------------------------------------------------------------------
-- @name : firewall.fwRulesL2AddSet()
--
-- @description : This function is used to set the DB when an L2 rule is added
--
-- @return : status, errorMsg
--
function firewall.fwRulesL2AddSet(firewallAddTable)

    return firewall.firewallRulesL2Config(firewallAddTable, "-1", "add")  
end

-------------------------------------------------------------------------------
-- @name : firewall.fwCustomSvcAddSet()
--
-- @description : 
--
-- @return : 
--
function firewall.fwCustomSvcAddSet(CustomSvcAddTbl)
    return firewall.fwCustomSvcConfig(CustomSvcAddTbl, "-1", "add")  
end

-------------------------------------------------------------------------------
-- @name : firewall.portTriggerRulesAddSet()
--
-- @description : This function is used to set the DB when a Port Triggering 
-- rule is added
--
-- @return : status, errorMsg
--
function firewall.portTriggerRulesAddSet(portTriggerAddTable)
    return firewall.portTriggerRulesConfig(portTriggerAddTable, "-1", "add")  
end

-------------------------------------------------------------------------------
-- @name : firewall.fwRulesEditGet()
--
-- @description : This function is used to get the values from DB when an IPv4
-- rule is to be edited
--
-- @return : lua table containing previous values
--
function firewall.fwRulesEditGet()
    fwIpv4DefTbl = {}
    fwIpv4DefTbl.Services = {}
    fwIpv4DefTbl.Services = db.getDistinctValues ("Services", "ServiceName")    
    fwIpv4DefTbl.lanNetworks = {}
    fwIpv4DefTbl.lanNetworks = db.getRowsWhere ("networkInterface", "zoneType = 'secure'", false)
    fwIpv4DefTbl.wanNetworks = {}
    fwIpv4DefTbl.wanNetworks = db.getRowsWhere ("networkInterface", "zoneType = 'insecure'", false)
    return fwIpv4DefTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.portFwdRulesEditGet()
--
-- @description : This function is used to get the values from DB when an IPv4
-- rule is to be edited
--
-- @return : lua table containing previous values
--
function firewall.portFwdRulesEditGet()
    portFwdDefTbl = {}
    portFwdDefTbl.Services = {}
    portFwdDefTbl.Services = db.getTable("Services")

    return portFwdDefTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.fwRules6EditGet()
--
-- @description : This function is used to get the values from DB when an IPv6 
-- rule is to be edited
--
-- @return : lua table containing previous values
--
function firewall.fwRules6EditGet(rowId)
    fwIpv6DefTbl = {}
    fwIpv6DefTbl.Services = {}
    fwIpv6DefTbl.Services = db.getDistinctValues ("Services", "ServiceName")    
    fwIpv6DefTbl.lanNetworks = {}
    fwIpv6DefTbl.lanNetworks = db.getRowsWhere ("networkInterface", "zoneType = 'secure'", false)
    fwIpv6DefTbl.wanNetworks = {}
    fwIpv6DefTbl.wanNetworks = db.getRowsWhere ("networkInterface", "zoneType = 'insecure'", false)
    return fwIpv6DefTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.fwRulesL2EditGet()
--
-- @description : This function is used to get the values from DB when an L2 
-- rule is to be edited
--
-- @return : lua table containing previous values
--
function firewall.fwRulesL2EditGet(rowId)
    fwL2DefTbl = {}
    fwL2DefTbl.Services = {}
    fwL2DefTbl.Services = db.getDistinctValues ("Services", "ServiceName")    
    fwL2DefTbl.lanNetworks = {}
    fwL2DefTbl.lanNetworks = db.getRowsWhere ("networkInterface", "zoneType = 'secure'", false)
    fwL2DefTbl.wanNetworks = {}
    fwL2DefTbl.wanNetworks = db.getRowsWhere ("networkInterface", "zoneType = 'insecure'", false)
    return fwL2DefTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.portTriggerRulesEditGet()
--
-- @description : This function is used to get the values from DB when a port
-- triggering rule is to be edited
--
-- @return : lua table containing previous values
--
function firewall.portTriggerRulesEditGet()
    portTriggerDefTbl = {}
    portTriggerDefTbl.Networks = {}
    portTriggerDefTbl.Networks = db.getRowsWhere ("networkInterface", "zoneType = 'secure'", false)
    return portTriggerDefTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.fwCustomSvcEditGet()
--
-- @description : 
--
-- @return : 
--
function firewall.fwCustomSvcEditGet(rowId)
    local configTbl = {}
    configTbl = db.getRow ("Services", "_ROWID_", rowId) 
    configTbl = util.removePrefix(configTbl, "Services.")
    return configTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.fwRulesEditSet()
--
-- @description : This function is used to set the values in DB when an IPv4
-- rule is to be edited
--
-- @return : status, errorMsg
--
function firewall.fwRulesEditSet(firewallEditTable)
    --locals
    local protocol

    protocol = db.getAttribute ("Services", "ServiceName", firewallEditTable.ServiceName, "Protocol")
    if (protocol == "58") then
        return "ERROR", "ICMPv6-type service is not supported for IPv4 Firewall Rules!"
    end

    return firewall.firewallRulesConfig(firewallEditTable, firewallEditTable._ROWID_, "edit")  
end

-------------------------------------------------------------------------------
-- @name : firewall.portFwdRulesEditSet()
--
-- @description : This function is used to set the values in DB when a Port
-- Forward rule is to be edited
--
-- @return : status, errorMsg
--
function firewall.portFwdRulesEditSet(firewallEditTable)
    --locals
    local protocol

    protocol = db.getAttribute ("Services", "ServiceName", firewallEditTable.ServiceName, "Protocol")
    if (protocol == "1") then
        return "ERROR", "ICMPv6-type service is not supported for Port Forwarding Rules!"
    end

    return firewall.portFwdRulesConfig(firewallEditTable, firewallEditTable._ROWID_, "edit")  
end

-------------------------------------------------------------------------------
-- @name : firewall.fwRules6EditSet()
--
-- @description : This function is used to set the values in DB when an IPv6 
-- rule is to be edited
--
-- @return : status, errorMsg
--
function firewall.fwRules6EditSet(firewallEditTable)
    local protocol
    
    protocol = db.getAttribute ("Services", "ServiceName", firewallEditTable.ServiceName, "Protocol")
    if (protocol == "1") then
        return "ERROR", "ICMP (v4) type service is not supported for IPv6 Firewall Rules!"
    end

    return firewall.firewallRules6Config(firewallEditTable, firewallEditTable._ROWID_, "edit")  
end

-------------------------------------------------------------------------------
-- @name : firewall.fwRulesL2EditSet()
--
-- @description : This function is used to set the values in DB when an L2 
-- rule is to be edited
--
-- @return : status, errorMsg
--
function firewall.fwRulesL2EditSet(firewallEditTable)
    
    return firewall.firewallRulesL2Config(firewallEditTable, firewallEditTable._ROWID_, "edit")  
end

-------------------------------------------------------------------------------
-- @name : firewall.fwCustomSvcEditSet()
--
-- @description : 
--
-- @return : 
--
function firewall.fwCustomSvcEditSet(fwCustomSvcEditTbl)
    --locals
    local svcName
    local isFwRuleExist, isFwRule6Exist
    local ruleInUse, ruleInUse6
    local svcFwRulesRows = {}
    local svcFwRulesRows6 = {}
    local query
    local isTrafficSelectorExist

    svcName = fwCustomSvcEditTbl.oldServiceName
    query = "ServiceName = '" .. svcName .."'"
     
    isTrafficSelectorExist = db.existsRowWhere("qosClassification", "Service = '" .. svcName .. "'")
    if (isTrafficSelectorExist) then
        db.rollback()
        return "ERROR", "Service " .. svcName .. " is in use. Delete associated Traffic selector first."
    end
    
    isFwRuleExist = db.existsRowWhere("FirewallRules", "ServiceName = '" .. svcName .. "'") 
    svcFwRulesRows = db.getRows("FirewallRules", "ServiceName", svcName)
    for k,v in pairs(svcFwRulesRows) do
        ruleInUse = 0;
        if (v["FirewallRules.Status"] == "1" or v["FirewallRules.Status"] == "0") then
            -- service can be edited if firewall rule is disabled
            ruleInUse = 1;
            break;       
        end         
    end       

    if (isFwRuleExist and ruleInUse == 1) then
    return "ERROR", "Service " .. svcName .. " cannot be edited as it is being used in IPv4 Port Forwarding/Firewall Rule(s)."
    end

    isFwRule6Exist = db.existsRowWhere("FirewallRules6", "ServiceName = '" .. svcName .. "'") 
    svcFwRulesRows6 = db.getRows("FirewallRules6", "ServiceName", svcName)
    for k,v in pairs(svcFwRulesRows6) do
        ruleInUse6 = 0;
        if (v["FirewallRules6.Status"] == "1") then
            ruleInUse6 = 1;
            break;       
        end         
    end         

    if (isFwRule6Exist and ruleInUse6 == 1) then
        return "ERROR", "Service " .. svcName .. " cannot be edited as it is being used in IPv6 Firewall Rule(s)!"
    end

    -- return
    return firewall.fwCustomSvcConfig(fwCustomSvcEditTbl, fwCustomSvcEditTbl._ROWID_, "edit")  
end

-------------------------------------------------------------------------------
-- @name : firewall.portTriggerRulesEditSet()
--
-- @description : This function is used to set the values in DB when a Port
-- Triggering rule is to be edited
--
-- @return : status, errorMsg
--
function firewall.portTriggerRulesEditSet(firewallEditTable)
    return firewall.portTriggerRulesConfig(firewallEditTable, firewallEditTable._ROWID_, "edit")  
end

-------------------------------------------------------------------------------
-- @name : firewall.fwRulesEnable()
--
-- @description : This function is used to enable an IPv4 Firewall
-- Rule
--
-- @return : status, errorMsg
--
function firewall.fwRulesEnable (rowId)
    local statusFlag = true

    -- set status as '1' for all the rules that need to be enabled
    statusFlag = db.setAttribute ("FirewallRules", "_ROWID_", rowId, "Status", "1")

    if(statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_RULES_ENABLED_FAILED"
    end

end

-------------------------------------------------------------------------------
-- @name : firewall.portFwdRulesEnable()
--
-- @description : This function is used to enable an IPv4 Port forwarding Rule
--
-- @return : status, errorMsg
--
function firewall.portFwdRulesEnable(rowId)
   local statusFlag = true

    -- set status as '1' for all the rules that need to be enabled
    statusFlag = db.setAttribute ("FirewallRules", "_ROWID_", rowId, "Status", "1")

    if(statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_PORTFORWARD_RULE_ENABLE_FAILED"
    end
end

-------------------------------------------------------------------------------
-- @name : firewall.fwRules6Enable()
--
-- @description : This function is used to enable an IPv6 Firewall
-- Rule
--
-- @return : status, errorMsg
--
function firewall.fwRules6Enable (rowId)
    local statusFlag = true

    -- set status as '1' for all the rules that need to be enabled
    statusFlag = db.setAttribute ("FirewallRules6", "_ROWID_", rowId, "Status", "1")

    if(statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_RULES_ENABLED_FAILED"
    end

end

-------------------------------------------------------------------------------
-- @name : firewall.fwRulesL2Enable()
--
-- @description : This function is used to enable an L2 Firewall
-- Rule
--
-- @return : status, errorMsg
--
function firewall.fwRulesL2Enable (rowId)
    local statusFlag = true

    -- set status as '1' for all the rules that need to be enabled
    statusFlag = db.setAttribute ("L2FirewallRules", "_ROWID_", rowId, "Status", "1")

    if(statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_RULES_ENABLED_FAILED"
    end

end

-------------------------------------------------------------------------------
-- @name : firewall.fwRulesDisable()
--
-- @description : This function is used to disable an IPv4 Firewall Rule
--
-- @return : status, errorMsg
--
function firewall.fwRulesDisable (rowId)
    local statusFlag = true

    -- set status as '0' for all the rules that need to be disabled
    statusFlag = db.setAttribute ("FirewallRules", "_ROWID_", rowId, "Status", "0")

    if(statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_RULES_DISABLED_FAILED"
    end

end

-------------------------------------------------------------------------------
-- @name : firewall.portFwdRulesDisable()
--
-- @description : This function is used to enable an IPv4 Port forwarding Rule
--
-- @return : status, errorMsg
--
function firewall.portFwdRulesDisable(rowId)
   local statusFlag = true

    -- set status as '0' for all the rules that need to be disabled
    statusFlag = db.setAttribute ("FirewallRules", "_ROWID_", rowId, "Status", "0")

    if(statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_PORTFORWARD_RULE_DISABLE_FAILED"
    end
end

-------------------------------------------------------------------------------
-- @name : firewall.fwRules6Disable()
--
-- @description : This function is used to disable an IPv6 Firewall Rule
--
-- @return : status, errorMsg
--
function firewall.fwRules6Disable (rowId)
    local statusFlag = true

    -- set status as '0' for all the rules that need to be disabled
    statusFlag = db.setAttribute ("FirewallRules6", "_ROWID_", rowId, "Status", "0")

    if(statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_RULES_DISABLED_FAILED"
    end

end

-------------------------------------------------------------------------------
-- @name : firewall.fwRulesL2Disable()
--
-- @description : This function is used to disable an L2 Firewall Rule
--
-- @return : status, errorMsg
--
function firewall.fwRulesL2Disable (rowId)
    local statusFlag = true

    -- set status as '0' for all the rules that need to be disabled
    statusFlag = db.setAttribute ("L2FirewallRules", "_ROWID_", rowId, "Status", "0")

    if(statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_RULES_DISABLED_FAILED"
    end

end
-------------------------------------------------------------------------------
-- @name : firewall.fwRulesDelete()
--
-- @description : This function is used to delete IPv4 Firewall Rule(s)
--
-- @return : status, errorMsg
--
function firewall.fwRulesDelete (inTable)
    local statusFlag = true

    statusFlag = firewallv4.config(inTable, rowId, "delete")

    if(statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_RULES_DELETE_FAILED"
    end

end

-------------------------------------------------------------------------------
-- @name : firewall.portFwdRulesDelete()
--
-- @description : This function is used to delete IPv4 Port forwarding Rule(s)
--
-- @return : status, errorMsg
--
function firewall.portFwdRulesDelete(inTable)
   local statusFlag = true

    statusFlag = firewallv4.config(inTable, rowId, "delete")

    if(statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_PORTFORWARD_RULES_DELETE_FAILED"
    end
end

-------------------------------------------------------------------------------
-- @name : firewall.fwRules6Delete()
--
-- @description : This function is used to delete IPv6 Firewall Rule(s)
--
-- @return : status, errorMsg
--
function firewall.fwRules6Delete (inTable)
    local statusFlag = true

    statusFlag = firewallv6.config(inTable, rowId, "delete")

    if(statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_RULES_DELETE_FAILED"
    end

end

-------------------------------------------------------------------------------
-- @name : firewall.fwRulesL2Delete()
--
-- @description : This function is used to delete L2 Firewall Rule(s)
--
-- @return : status, errorMsg
--
function firewall.fwRulesL2Delete (inTable)
    local statusFlag = true

    statusFlag = firewallL2.config(inTable, rowId, "delete")

    if(statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_RULES_DELETE_FAILED"
    end

end

-------------------------------------------------------------------------------
-- @name : firewall.fwCustomSvcDelete()
--
-- @description : 
--
-- @return : 
--
function firewall.fwCustomSvcDelete (inTable)
    local valid = false

    valid = fw.config("Services", inTable, rowId, "delete") 

    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "CUSTOM_SERVICE_DELETE_FAILED"
    end
end

-------------------------------------------------------------------------------
-- @name : firewall.fwPortTriggerDelete()
--
-- @description : This function is used to delete port triggering Rule(s)
--
-- @return : status, errorMsg
--
function firewall.fwPortTriggerDelete (inTable)
    return fw.config("PortTriggering", inTable, rowId, "delete")
end

--------------------------------------------------------------------------------
--@name : firewall.securityLevelSet ()
--
--@description : The function will set the security level for network after 
--coverting network name to logical interface name
--
--@return : status, errMsg
function firewall.securityLevelSet (networkName, mode)
	
	--locals
	local securityConfigTbl = {}
    local oldRow = {}
    local query 
    local valid = false

    -- 1-to-1 mapping between network name and logical interface name
    securityConfigTbl["LogicalIfName"] = db.getAttribute ("networkInterface", "networkName", 
                                        networkName, "LogicalIfName")

    query = "LogicalIfName='" .. securityConfigTbl["LogicalIfName"] .. "'"

    -- getting the security config table for corresponding secure network
    oldRow = db.getRowWhere("SecurityConfig", query, false)
    
    if (oldRow == nil) then
        -- no such row exists; add case
        operation = "add"
    else
        securityConfigTbl["_ROWID_"] = oldRow["_ROWID_"]       
        operation = "edit"
    end

    securityConfigTbl["securityLevel"] = mode
    securityConfigTbl = util.addPrefix(securityConfigTbl, "SecurityConfig.")

    if (operation == "edit") then
        valid = fw.config ("SecurityConfig", securityConfigTbl, securityConfigTbl["SecurityConfig._ROWID_"], operation)
    elseif (operation == "add") then
        valid = fw.config ("SecurityConfig", securityConfigTbl, "-1", operation)
    end

    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "SECURITY_CONFIG_FAILED"
    end
end

--------------------------------------------------------------------------------
--@name : firewall.securityLevelGet ()
--
--@description : The function will get the security level for network
--
--@return : security level attribute
function firewall.securityLevelGet (logicalIfName)
    return db.getAttribute("SecurityConfig", "LogicalIfName", logicalIfName, "securityLevel")
end

-------------------------------------------------------------------------------
-- @name : firewallv4.config()
--
-- @description : API to perform actual DB add/delete/edit operation on table
-- containing IPv4 firewall rules
--
-- @return : status
-- 
function firewallv4.config (inputTable, rowid, operation)
    if (operation == "add") then
        return db.insert(IPv4DBTable, inputTable)
    elseif (operation == "edit") then
        return db.update(IPv4DBTable, inputTable, rowid)
    elseif (operation == "delete") then
        return db.delete(IPv4DBTable, inputTable)
    end
    return false
end

-------------------------------------------------------------------------------
-- @name : firewallv6.config()
--
-- @description : API to perform actual DB add/delete/edit operation on table 
-- containing IPv6 firewall rules
--
-- @return : status
-- 
function firewallv6.config (inputTable, rowid, operation)
    if (operation == "add") then
        return db.insert(IPv6DBTable, inputTable)
    elseif (operation == "edit") then
        return db.update(IPv6DBTable, inputTable, rowid)
    elseif (operation == "delete") then
        return db.delete(IPv6DBTable, inputTable)
    end
    return false
end

-------------------------------------------------------------------------------
-- @name : firewallL2.config()
--
-- @description : API to perform actual DB add/delete/edit operation on table 
-- containing L2 firewall rules
--
-- @return : status
-- 
function firewallL2.config (inputTable, rowid, operation)
    if (operation == "add") then
        return db.insert(L2DBTable, inputTable)
    elseif (operation == "edit") then
        return db.update(L2DBTable, inputTable, rowid)
    elseif (operation == "delete") then
        return db.delete(L2DBTable, inputTable)
    end
    return false
end
-------------------------------------------------------------------------------
-- @name : fw.config()
--
-- @description : API to perform actual DB add/delete/edit operation on 
-- miscellaneous firewall tables
--
-- @return : status
-- 
function fw.config (name, inputTable, rowid, operation)
    -- validate
    if (operation == "add") then
        return db.insert(name, inputTable)
    elseif (operation == "edit") then
        return db.update(name, inputTable, rowid)
    elseif (operation == "delete") then
        return db.delete(name, inputTable)
    end
    return false
end

-------------------------------------------------------------------------------
-- @name : firewall.eogreGet()
--
-- @description : This function returns Eogre Table or Eogre Row based on  
-- query recieved
--
-- @return : lua table containing all table or row depend on query recieved
--
function firewall.eogreGet(query)
    if(query ~= nil) then
        return db.getRowWhere ("Eogre", query, false)
    else
        return db.getTable ("Eogre", false)
    end
end

--------------------------------------------------------------------------------
--@name : firewall.eogreSet ()
--
--@description : The function will update the Eogre Table 
--
--@return : status, errMsg
--
function firewall.eogreSet (eogreTmp)
    local status 

    -- add prefix
    local eogreTmp1 = util.addPrefix (eogreTmp, "Eogre.")

    status = db.update ("Eogre", eogreTmp1, eogreTmp1["Eogre._ROWID_"])

    if (status ~= nil) then
        db.save ();
    end
    return "OK", "STATUS_OK"

end

-------------------------------------------------------------------------------
-- @name : firewall.export()
--
-- @description : API to export tables related to firewall component
--
-- @return : lua table containing tables related to firewall component
-- 
function firewall.export ()
    local fwall = {}
    local table = {}
    table["service"] = {}
    table["securityconfig"] = {}

	-- export services
    table["service"] = db.getTable ("Services", false)
    if (table["service"] ~= nil) then
        fwall["service"] = table["service"]
    end

    -- export Schedules configuration
    table["Schedules"] = db.getTable ("Schedules", false)
    if (table["Schedules"] ~= nil) then
        fwall["Schedules"] = table["Schedules"]
    end

    -- port forwarding rules
    query = "RuleType='INSECURE_SECURE'"
    rules = db.getRowsWhere("FirewallRules",query, false)
    if (rules ~= nil) then
        fwall["port_forward"] = rules
    end

    -- filtering
    query = "RuleType='SECURE_INSECURE'"
    rules = db.getRowsWhere("FirewallRules",query, false)
    if (rules ~= nil) then
        fwall["filter"] = rules
    end

    -- ipv6 rules
    rules = db.getTable("FirewallRules6", false)
    if (rules ~= nil) then
        fwall["ipv6rule"] = rules
    end

    -- port triggering rules
    rules = db.getTable("PortTriggering", false)
    if (rules ~= nil) then
        fwall["port_trigger"] = rules
    end

    -- security level for each LAN network
    table["securityconfig"] = db.getTable ("SecurityConfig", false)
    if (table["securityconfig"] ~= nil) then
        fwall["securityconfig"] = table["securityconfig"]
    end   

    -- export FullConeNat
    table["FullConeNat"] = db.getTable ("FullConeNat", false)
    if (table["FullConeNat"] ~= nil) then
        fwall["FullConeNat"] = table["FullConeNat"]
    end

	-- export dmz configuration
    table["dmz"] = db.getTable ("dmz", false)
    if (table["dmz"] ~= nil) then
        fwall["dmz"] = table["dmz"]
    end
 
    -- export dmz6 configuration
    table["dmz6"] = db.getTable ("dmz6", false)
    if (table["dmz6"] ~= nil) then
        fwall["dmz6"] = table["dmz6"]
    end
    -- export firewallStatus configuration
    table["firewallStatus"] = db.getTable ("firewallStatus", false)
    if (table["firewallStatus"] ~= nil) then
        fwall["firewallStatus"] = table["firewallStatus"]
    end
    
    --export routingMode configuration
    table["routingMode"] = db.getTable ("routingMode", false)
    if (table["routingMode"] ~= nil) then
        fwall["routingMode"] = table["routingMode"]
    end

    --export AlgConf configuration
    table["AlgConf"] = db.getTable ("AlgConf", false)
    if (table["AlgConf"] ~= nil) then
        fwall["AlgConf"] = table["AlgConf"]
    end

    --export SpecificAttackChecks configuration
    table["SpecificAttackChecks"] = db.getTable ("SpecificAttackChecks", false)
    if (table["SpecificAttackChecks"] ~= nil) then
        fwall["SpecificAttackChecks"] = table["SpecificAttackChecks"]
    end

    --export DosAttackChecks configuration
    table["DosAttackChecks"] = db.getTable ("DosAttackChecks", false)
    if (table["DosAttackChecks"] ~= nil) then
        fwall["DosAttackChecks"] = table["DosAttackChecks"]
    end

    --export p2pSessionLimit configuration
    table["p2pSessionLimit"] = db.getTable ("p2pSessionLimit", false)
    if (table["p2pSessionLimit"] ~= nil) then
        fwall["p2pSessionLimit"] = table["p2pSessionLimit"]
    end

    -- export macFilterConfig configuration
    table["macFilterConfig"] = db.getTable ("macFilterConfig", false)
    if (table["macFilterConfig"] ~= nil) then
        fwall["macFilterConfig"] = table["macFilterConfig"]
    end

    -- export macFilterRules configuration
    table["macFilterRules"] = db.getTable ("macFilterRules", false)
    if (table["macFilterRules"] ~= nil) then
        fwall["macFilterRules"] = table["macFilterRules"]
    end

    -- export casNotification configuration
    table["casNotification"] = db.getTable ("casNotification", false)
    if (table["casNotification"] ~= nil) then
        fwall["casNotification"] = table["casNotification"]
    end

    -- export clientMacConfig configuration
    table["clientMacConfig"] = db.getTable ("clientMacConfig", false)
    if (table["clientMacConfig"] ~= nil) then
        fwall["clientMacConfig"] = table["clientMacConfig"]
    end

    -- export ContentFiltering configuration
    table["ContentFiltering"] = db.getTable ("ContentFiltering", false)
    if (table["ContentFiltering"] ~= nil) then
        fwall["ContentFiltering"] = table["ContentFiltering"]
    end

    -- export TrustedDomains configuration
    table["TrustedDomains"] = db.getTable ("TrustedDomains", false)
    if (table["TrustedDomains"] ~= nil) then
        fwall["TrustedDomains"] = table["TrustedDomains"]
    end

    -- export BlockSites configuration
    table["BlockSites"] = db.getTable ("BlockSites", false)
    if (table["BlockSites"] ~= nil) then
        fwall["BlockSites"] = table["BlockSites"]
    end

    -- export defaultPolicy configuration
    table["defaultPolicy"] = db.getTable ("defaultPolicy", false)
    if (table["defaultPolicy"] ~= nil) then
        fwall["defaultPolicy"] = table["defaultPolicy"]
    end

     -- export conntrackAction configuration
    table["conntrackAction"] = db.getTable ("conntrackAction", false)
    if (table["conntrackAction"] ~= nil) then
        fwall["conntrackAction"] = table["conntrackAction"]
    end

    -- export BwMon configuration
    table["BwMon"] = db.getTable ("BwMon", false)
    if (table["BwMon"] ~= nil) then
        fwall["BwMon"] = table["BwMon"]
    end

    -- export BwMonStat configuration
    table["BwMonStat"] = db.getTable ("BwMonStat", false)
    if (table["BwMonStat"] ~= nil) then
        fwall["BwMonStat"] = table["BwMonStat"]
    end

    -- export BwMonCustom configuration
    table["BwMonCustom"] = db.getTable ("BwMonCustom", false)
    if (table["BwMonCustom"] ~= nil) then
        fwall["BwMonCustom"] = table["BwMonCustom"]
    end

	-- export FirewallLogs configuration
    table["FirewallLogs"] = db.getTable ("FirewallLogs", false)
    if (table["FirewallLogs"] ~= nil) then
        fwall["FirewallLogs"] = table["FirewallLogs"]
    end

	-- export FirewallLogs6 configuration
    table["FirewallLogs6"] = db.getTable ("FirewallLogs6", false)
    if (table["FirewallLogs6"] ~= nil) then
        fwall["FirewallLogs6"] = table["FirewallLogs6"]
    end

	-- export IcsaSettings configuration
    table["IcsaSettings"] = db.getTable ("IcsaSettings", false)
    if (table["IcsaSettings"] ~= nil) then
        fwall["IcsaSettings"] = table["IcsaSettings"]
    end

    -- export WebAccessCtrl configuration
    table["WebAccessCtrl"] = db.getTable ("WebAccessCtrl", false)
    if (table["WebAccessCtrl"] ~= nil) then
        fwall["WebAccessCtrl"] = table["WebAccessCtrl"]
    end

    -- export InterfaceInfo configuration
    table["InterfaceInfo"] = db.getTable ("InterfaceInfo", false)
    if (table["InterfaceInfo"] ~= nil) then
        fwall["InterfaceInfo"] = table["InterfaceInfo"]
    end

    -- export PktCountEnable configuration
    table["PktCountEnable"] = db.getTable ("PktCountEnable", false)
    if (table["PktCountEnable"] ~= nil) then
        fwall["PktCountEnable"] = table["PktCountEnable"]
    end

     -- export Eogre configuration
    table["Eogre"] = db.getTable ("Eogre", false)
    if (table["Eogre"] ~= nil) then
        fwall["Eogre"] = table["Eogre"]
    end

     -- export dot11ProfileDef configuration
    table["dot11ProfileDef"] = db.getTable ("dot11ProfileDef", false)
    if (table["dot11ProfileDef"] ~= nil) then
        fwall["dot11ProfileDef"] = table["dot11ProfileDef"]
    end

    -- export L2FirewallDefaultPolicy configuration
    table["L2FirewallDefaultPolicy"] = db.getTable ("L2FirewallDefaultPolicy", false)
    if (table["L2FirewallDefaultPolicy"] ~= nil) then
        fwall["L2FirewallDefaultPolicy"] = table["L2FirewallDefaultPolicy"]
    end

    -- export L2FirewallRules configuration
    table["L2FirewallRules"] = db.getTable ("L2FirewallRules", false)
    if (table["L2FirewallRules"] ~= nil) then
        fwall["L2FirewallRules"] = table["L2FirewallRules"]
    end

	-- export ThirdParty configuration
	table["ThirdParty"] = db.getTable ("ThirdParty", false)
	if (table["ThirdParty"] ~= nil) then
		fwall["ThirdParty"] = table["ThirdParty"]
	end

	return fwall
end

-- Copy all the columns except _ROWID_
-- Import might cause a problem with firewall rules, if there
-- is a rule already present with _ROWID_ same as the rule which
-- is being imported. 
function firewall.rowIdStrip (row)
    local result = {}

    if (row == nil) then
        return result
    end

    for k,v in pairs(row) do
        if (k ~= "_ROWID_") then
            result[k] = v
        end
    end

    return result
end

-------------------------------------------------------------------------------
-- @name : firewall.import()
--
-- @description : API to import 'Services' table
--
-- @return : None
-- 
function firewall.import (inputTable, defaultCfg, remCfg)
	if (inputTable == nil) then
		inputTable = defaultCfg
	end

    firewall.tf1Dbg("Entering firewall.import function..")
    local serviceTmp = {}
    local securityconfigTmp = {}
    local portForwardingTmp = {}
    local filterTmp = {}
    local ipv6Tmp = {}
    local portTriggerTmp = {}
    local fullConeNatTmp = {}
    local dmzTmp = {}
    local firewallStatusTmp = {}
    local routingModeTmp = {}
    local macFilterConfigTmp = {}
    local macFilterRulesTmp = {}
    local casNotificationTmp = {}
    local clientMacConfigTmp = {}
    local contentFilteringTmp = {}
    local trustedDomainsTmp = {}
    local blockSitesTmp = {}
    local defaultPolicyTmp = {}
    local conntrackActionTmp = {}
    local algConfTmp = {}
    local specAttChkTmp = {}
    local dosAttChkTmp = {}
    local p2pSessionLimit = {}
    local schedulesTmp = {}
    local bwMonTmp = {}
    local bwMonStatTmp = {}
    local bwMonCustomTmp = {}
	local FirewallLogsTmp = {}
	local FirewallLogs6Tmp = {}
	local IcsaSettingsTmp = {}
    local p2pSessionLimit = {}
    local webAccessControl = {}
    local InterfaceInfoTmp = {}
    local PktCountEnableTmp = {}
    local EogreTmp = {}
    local dot11ProfileDefTmp = {}
    local L2FirewallRulesTmp = {}
    local L2FirewallDefaultPolicyTmp = {}
    local DeviceAccessTmp = {}
    local ThirdPartyTmp = {}
    local dmz6Tmp = {}

	-- import services
        serviceTmp = config.update (inputTable.service, defaultCfg.service, remCfg.service)
        if (serviceTmp ~= nil and #serviceTmp ~= 0) then
            for i,v in ipairs (serviceTmp) do
                v = util.addPrefix (v, "Services.");
                fw.config ("Services", v, "-1", "add")
            end
        end

    -- import Schedules configuration
        schedulesTmp = config.update (inputTable.Schedules, defaultCfg.Schedules, remCfg.Schedules)
        if (schedulesTmp ~= nil and #schedulesTmp ~= 0) then
            for i,v in ipairs (schedulesTmp) do
                v = util.addPrefix (v, "Schedules.");
                fw.config ("Schedules", v, "-1", "add")
            end
        end

    -- import security level for each LAN network
        securityconfigTmp = config.update (inputTable.securityconfig, defaultCfg.securityconfig, remCfg.securityconfig)
        if (securityconfigTmp ~= nil and #securityconfigTmp ~= 0) then
            for i,v in ipairs (securityconfigTmp) do
                v = util.addPrefix (v, "SecurityConfig.");
                fw.config ("SecurityConfig", v, "-1", "add")
            end
        end

    --import defaultPolicy configuration
        defaultPolicyTmp = config.update (inputTable.defaultPolicy, defaultCfg.defaultPolicy, remCfg.defaultPolicy)
        if (defaultPolicyTmp ~= nil and #defaultPolicyTmp ~= 0) then
            for i,v in ipairs (defaultPolicyTmp) do
                v = util.addPrefix (v, "defaultPolicy.");
                fw.config ("defaultPolicy", v, "-1", "add")
            end
        end

    --import conntrackAction configuration
        conntrackActionTmp = config.update (inputTable.conntrackAction, defaultCfg.conntrackAction, remCfg.conntrackAction)
        if (conntrackActionTmp ~= nil and #conntrackActionTmp ~= 0) then
            for i,v in ipairs (conntrackActionTmp) do
                v = util.addPrefix (v, "conntrackAction.");
                fw.config ("conntrackAction", v, "-1", "add")
            end
        end

      -- import port forwarding rules
        portForwardingTmp = config.update (inputTable.port_forward, defaultCfg.port_forward, remCfg.port_forward)
        if (portForwardingTmp ~= nil and #portForwardingTmp ~= 0) then
            for i,v in ipairs (portForwardingTmp) do
                v = firewall.rowIdStrip(v)
                v = util.addPrefix (v, "FirewallRules.");
                fw.config ("FirewallRules", v, -1, "add")
            end
        end

    -- import filtering rules
        filterTmp = config.update (inputTable.filter, defaultCfg.filter, remCfg.filter)
        if (filterTmp ~= nil and #filterTmp ~=  0) then
            for i,v in ipairs (filterTmp) do
                v = firewall.rowIdStrip(v)
                v = util.addPrefix (v, "FirewallRules.");
                fw.config ("FirewallRules", v, -1, "add")
            end
        end

    -- import ipv6 rules
        ipv6Tmp = config.update (inputTable.ipv6rule, defaultCfg.ipv6rule, remCfg.ipv6rule)
        if (ipv6Tmp ~= nil and #ipv6Tmp ~= 0) then
            for i,v in ipairs (ipv6Tmp) do
                v = firewall.rowIdStrip(v)
                v = util.addPrefix (v, "FirewallRules6.");
                fw.config ("FirewallRules6", v, -1, "add")
            end
        end

    -- import port triggering rules
        portTriggerTmp = config.update (inputTable.port_trigger, defaultCfg.port_trigger, remCfg.port_trigger)
        if (portTriggerTmp ~= nil and #portTriggerTmp ~= 0) then
            for i,v in ipairs (portTriggerTmp) do
                v = firewall.rowIdStrip(v)
                v = util.addPrefix (v, "PortTriggering.");
                fw.config ("PortTriggering", v, -1, "add")
            end
        end
    
        -- import FullConeNat
        fullConeNatTmp = config.update (inputTable.FullConeNat, defaultCfg.FullConeNat, remCfg.FullConeNat)
        if (fullConeNatTmp ~= nil and #fullConeNatTmp ~= 0) then
            for i,v in ipairs (fullConeNatTmp) do
                v = util.addPrefix (v, "FullConeNat.");
                fw.config ("FullConeNat", v, "-1", "add")
            end
        end

	-- import dmz configuration
        dmzTmp = config.update (inputTable.dmz, defaultCfg.dmz, remCfg.dmz)
        if (dmzTmp ~= nil and #dmzTmp ~= 0) then
            for i,v in ipairs (dmzTmp) do
                v = util.addPrefix (v, "dmz.");
                fw.config ("dmz", v, "-1", "add")
            end
        end
        
      	-- import firewallStatus configuration
        firewallStatusTmp = config.update (inputTable.firewallStatus, defaultCfg.firewallStatus, remCfg.firewallStatus)
        if (firewallStatusTmp ~= nil and #firewallStatusTmp ~= 0) then
            for i,v in ipairs (firewallStatusTmp) do
                v = util.addPrefix (v, "firewallStatus.");
                fw.config ("firewallStatus", v, "-1", "add")
            end
        end

    -- import routingMode configuration
        routingModeTmp = config.update (inputTable.routingMode, defaultCfg.routingMode, remCfg.routingMode)
        if (routingModeTmp ~= nil and #routingModeTmp ~= 0) then
            for i,v in ipairs (routingModeTmp) do
                v = util.addPrefix (v, "routingMode.");
                fw.config ("routingMode", v, "-1", "add")
            end
        end

    -- import AlgConf configuration
        algConfTmp = config.update (inputTable.AlgConf, defaultCfg.AlgConf, remCfg.AlgConf)
        if (algConfTmp ~= nil and #algConfTmp ~= 0) then
            for i,v in ipairs (algConfTmp) do
                v = util.addPrefix (v, "AlgConf.");
                fw.config ("AlgConf", v, "-1", "add")
            end
        end

    -- import SpecificAttackChecks configuration
        specAttChkTmp = config.update (inputTable.SpecificAttackChecks, defaultCfg.SpecificAttackChecks, remCfg.SpecificAttackChecks)
        if (specAttChkTmp ~= nil and #specAttChkTmp ~= 0) then
            for i,v in ipairs (specAttChkTmp) do
                v = util.addPrefix (v, "SpecificAttackChecks.");
                fw.config ("SpecificAttackChecks", v, "-1", "add")
            end
        end

    -- import DosAttackChecks configuration
        dosAttChkTmp = config.update (inputTable.DosAttackChecks, defaultCfg.DosAttackChecks, remCfg.DosAttackChecks)
        if (dosAttChkTmp ~= nil and #dosAttChkTmp ~= 0) then
            for i,v in ipairs (dosAttChkTmp) do
                v = util.addPrefix (v, "DosAttackChecks.");
                fw.config ("DosAttackChecks", v, "-1", "add")
            end
        end

     -- import p2pSessionLimit configuration
        p2pSessionLimit = config.update (inputTable.p2pSessionLimit, defaultCfg.p2pSessionLimit, remCfg.p2pSessionLimit)
        if (p2pSessionLimit ~= nil and #p2pSessionLimit ~= 0) then
            for i,v in ipairs (p2pSessionLimit) do
                v = util.addPrefix (v, "p2pSessionLimit.");
                fw.config ("p2pSessionLimit", v, "-1", "add")
            end
        end

    -- import macFilterConfig configuration
        macFilterConfigTmp = config.update (inputTable.macFilterConfig, defaultCfg.macFilterConfig, remCfg.macFilterConfig)
        if (macFilterConfigTmp ~= nil and #macFilterConfigTmp ~= 0) then
            for i,v in ipairs (macFilterConfigTmp) do
                v = util.addPrefix (v, "macFilterConfig.");
                fw.config ("macFilterConfig", v, "-1", "add")
            end
        end       

    -- import macFilterRules configuration
        macFilterRulesTmp = config.update (inputTable.macFilterRules, defaultCfg.macFilterRules, remCfg.macFilterRules)
        if (macFilterRulesTmp ~= nil and #macFilterRulesTmp ~= 0) then
            for i,v in ipairs (macFilterRulesTmp) do
                v = util.addPrefix (v, "macFilterRules.");
                fw.config ("macFilterRules", v, "-1", "add")
            end
        end

        -- import casNotification configuration
        casNotificationTmp = config.update (inputTable.casNotification, defaultCfg.casNotification, remCfg.casNotification)
        if (casNotificationTmp ~= nil and #casNotificationTmp ~= 0) then
            for i,v in ipairs (casNotificationTmp) do
                v = util.addPrefix (v, "casNotification.");
                fw.config ("casNotification", v, "-1", "add")
            end
        end

        -- import clientMacConfig configuration
        clientMacConfigTmp = config.update (inputTable.clientMacConfig, defaultCfg.clientMacConfig, remCfg.clientMacConfig)
        if (clientMacConfigTmp ~= nil and #clientMacConfigTmp ~= 0) then
            for i,v in ipairs (clientMacConfigTmp) do
                v = util.addPrefix (v, "clientMacConfig.");
                fw.config ("clientMacConfig", v, "-1", "add")
            end
        end

    -- import ContentFiltering configuration
        contentFilteringTmp = config.update (inputTable.ContentFiltering, defaultCfg.ContentFiltering, remCfg.ContentFiltering)
        if (contentFilteringTmp ~= nil and #contentFilteringTmp ~= 0) then
            for i,v in ipairs (contentFilteringTmp) do
                v = util.addPrefix (v, "ContentFiltering.");
                fw.config ("ContentFiltering", v, "-1", "add")
            end
        end

    -- import TrustedDomains configuration
        trustedDomainsTmp = config.update (inputTable.TrustedDomains, defaultCfg.TrustedDomains, remCfg.TrustedDomains)
        if (trustedDomainsTmp ~= nil and #trustedDomainsTmp ~= 0) then
            for i,v in ipairs (trustedDomainsTmp) do
                v = util.addPrefix (v, "TrustedDomains.");
                fw.config ("TrustedDomains", v, "-1", "add")
            end
        end

    -- import BlockSites configuration
        blockSitesTmp = config.update (inputTable.BlockSites, defaultCfg.BlockSites, remCfg.BlockSites)
        if (blockSitesTmp ~= nil and #blockSitesTmp ~= 0) then
            for i,v in ipairs (blockSitesTmp) do
                v = util.addPrefix (v, "BlockSites.");
                fw.config ("BlockSites", v, "-1", "add")
            end
        end

     --import BwMon configuration
        bwMonTmp = config.update (inputTable.BwMon, defaultCfg.BwMon, remCfg.BwMon)
        if (bwMonTmp ~= nil and #bwMonTmp ~= 0) then
            for i,v in ipairs (bwMonTmp) do
                v = util.addPrefix (v, "BwMon.");
                fw.config ("BwMon", v, "-1", "add")
            end
        end

    --import BwMonStat configuration
        bwMonStatTmp = config.update (inputTable.BwMonStat, defaultCfg.BwMonStat, remCfg.BwMonStat)
        if (bwMonStatTmp ~= nil and #bwMonStatTmp ~= 0) then
            for i,v in ipairs (bwMonStatTmp) do
                v["Counter"] = "0"
                v = util.addPrefix (v, "BwMonStat.");
                fw.config ("BwMonStat", v, "-1", "add")
            end
        end

      --import BwMonCustom configuration
      bwMonCustomTmp = config.update (inputTable.BwMonCustom, defaultCfg.BwMonCustom, remCfg.BwMonCustom)
        if (bwMonCustomTmp ~= nil and #bwMonCustomTmp ~= 0) then
            for i,v in ipairs (bwMonCustomTmp) do
                v = util.addPrefix (v, "BwMonCustom.");
                fw.config ("BwMonCustom", v, "-1", "add")
            end
        end

	  --import FirewallLogs configuration
      FirewallLogsTmp = config.update (inputTable.FirewallLogs, defaultCfg.FirewallLogs, remCfg.FirewallLogs)
        if (FirewallLogsTmp ~= nil and #FirewallLogsTmp ~= 0) then
            for i,v in ipairs (FirewallLogsTmp) do
                v = util.addPrefix (v, "FirewallLogs.");
                fw.config ("FirewallLogs", v, "-1", "add")
            end
        end

	  --import FirewallLogs6 configuration
      FirewallLogs6Tmp = config.update (inputTable.FirewallLogs6, defaultCfg.FirewallLogs6, remCfg.FirewallLogs6)
        if (FirewallLogs6Tmp ~= nil and #FirewallLogs6Tmp ~= 0) then
            for i,v in ipairs (FirewallLogs6Tmp) do
                v = util.addPrefix (v, "FirewallLogs6.");
                fw.config ("FirewallLogs6", v, "-1", "add")
            end
        end

		--import IcsaSettings configuration
      IcsaSettingsTmp = config.update (inputTable.IcsaSettings, defaultCfg.IcsaSettings, remCfg.IcsaSettings)
        if (IcsaSettingsTmp ~= nil and #IcsaSettingsTmp ~= 0) then
            for i,v in ipairs (IcsaSettingsTmp) do
                v = util.addPrefix (v, "IcsaSettings.");
                fw.config ("IcsaSettings", v, "-1", "add")
            end
        end

      --import WebAccessCtrl configuration
      webAccessControl = config.update (inputTable.WebAccessCtrl, defaultCfg.WebAccessCtrl, remCfg.WebAccessCtrl)
        if (webAccessControl ~= nil and #webAccessControl ~= 0) then
            for i,v in ipairs (webAccessControl) do
                v = util.addPrefix (v, "WebAccessCtrl.");
                fw.config ("WebAccessCtrl", v, "-1", "add")
            end
        end

        --import InterfaceInfo configuration
      InterfaceInfoTmp = config.update (inputTable.InterfaceInfo, defaultCfg.InterfaceInfo, remCfg.InterfaceInfo)
        if (InterfaceInfoTmp ~= nil and #InterfaceInfoTmp ~= 0) then
            for i,v in ipairs (InterfaceInfoTmp) do
				-- removing bridges from ODU
                if (util.fileExists ("/pfrm2.0/FXN_ODU")) then
                    if (v["interfaceName"] == "bdg1") then
                        v["interfaceName"] = "eth0"
                    end
                    if (v["interfaceName"] == "bdg2") then
                        v["interfaceName"] = "unm"
                    end
                end
                v = util.addPrefix (v, "InterfaceInfo.");
                fw.config ("InterfaceInfo", v, "-1", "add")
            end
        end

         --import PktCountEnable configuration
      PktCountEnableTmp = config.update (inputTable.PktCountEnable, defaultCfg.PktCountEnable, remCfg.PktCountEnable)
        if (PktCountEnableTmp ~= nil and #PktCountEnableTmp ~= 0) then
            for i,v in ipairs (PktCountEnableTmp) do
                v = util.addPrefix (v, "PktCountEnable.");
                fw.config ("PktCountEnable", v, "-1", "add")
            end
        end
        
        --import Eogre configuration
        EogreTmp = config.update (inputTable.Eogre, defaultCfg.Eogre, remCfg.Eogre)
        if (EogreTmp ~= nil and #EogreTmp ~= 0) then
            for i,v in ipairs (EogreTmp) do
                v = util.addPrefix (v, "Eogre.");
                fw.config ("Eogre", v, "-1", "add")
            end
        end

        --import  dot11ProfileDef configuration
        local singleApSupport = "0"
        local jioPrivateNetSupport = "0"
        singleApSupport = db.getAttribute ("environment", "name", "SINGLE_AP_SUPPORT" ,"value")
        jioPrivateNetSupport = db.getAttribute ("Eogre", "_ROWID_", 1, "jioPrivateNet")
        dot11ProfileDefTmp = config.update (inputTable.dot11ProfileDef, defaultCfg.dot11ProfileDef, remCfg.dot11ProfileDef)
        if (dot11ProfileDefTmp ~= nil and #dot11ProfileDefTmp ~= 0) then
            for i,v in ipairs (dot11ProfileDefTmp) do
                v = util.addPrefix (v, "dot11ProfileDef.");
                if (v["dot11ProfileDef.security"] == "WPA+WPA2")then
                    v["dot11ProfileDef.security"] = "WPA2"
                    v["dot11ProfileDef.pairwiseCiphers"] = "CCMP"
                end
                if (singleApSupport ~= nil and singleApSupport == "1") then
                    v["dot11ProfileDef.profileName"] = "Jio_1"
                    v["dot11ProfileDef.ssid"] = "Jio_1"
                end
                if (jioPrivateNetSupport ~= nil and jioPrivateNetSupport == "1") then
                    v["dot11ProfileDef.profileName"] = "Jio_3"
                    v["dot11ProfileDef.ssid"] = "Jio_3"
                end
                fw.config ("dot11ProfileDef", v, "-1", "add")
            end
        end

        --import  L2FirewallDefaultPolicy configuration
        L2FirewallDefaultPolicyTmp = config.update (inputTable.L2FirewallDefaultPolicy, defaultCfg.L2FirewallDefaultPolicy, remCfg.L2FirewallDefaultPolicy)
        if (L2FirewallDefaultPolicyTmp ~= nil and #L2FirewallDefaultPolicyTmp ~= 0) then
            for i,v in ipairs (L2FirewallDefaultPolicyTmp) do
                v = util.addPrefix (v, "L2FirewallDefaultPolicy.");
                fw.config ("L2FirewallDefaultPolicy", v, "-1", "add")
            end
        end

        --import  L2FirewallRules configuration
        L2FirewallRulesTmp = config.update (inputTable.L2FirewallRules, defaultCfg.L2FirewallRules, remCfg.L2FirewallRules)
        if (L2FirewallRulesTmp ~= nil and #L2FirewallRulesTmp ~= 0) then
            for i,v in ipairs (L2FirewallRulesTmp) do
                v = util.addPrefix (v, "L2FirewallRules.");
                fw.config ("L2FirewallRules", v, "-1", "add")
            end
        end

        --import  DeviceAccess configuration
        DeviceAccessTmp = config.update (inputTable.DeviceAccess, defaultCfg.DeviceAccess, remCfg.DeviceAccess)
        if (DeviceAccessTmp ~= nil and #DeviceAccessTmp ~= 0) then
            for i,v in ipairs (DeviceAccessTmp) do
                v = util.addPrefix (v, "DeviceAccess.");
                fw.config ("DeviceAccess", v, "-1", "add")
            end
        end

        --import ThirdParty configuration
        ThirdPartyTmp = config.update (inputTable.ThirdParty, defaultCfg.ThirdParty, remCfg.ThirdParty)
        if (ThirdPartyTmp ~= nil and #ThirdPartyTmp ~= 0) then
            for i,v in ipairs (ThirdPartyTmp) do
                v = util.addPrefix (v, "ThirdParty.");
                if(v["ThirdParty.Name"] == "JFV") then
                    v["ThirdParty.Name"] =  "Juice"
                    v["ThirdParty.Vendor"] =  "Jio"
                end
                fw.config ("ThirdParty", v, "-1", "add")
            end
        end

        -- import dmz6 configuration
        dmz6Tmp = config.update (inputTable.dmz6, defaultCfg.dmz6, remCfg.dmz6)
        if (dmz6Tmp ~= nil and #dmz6Tmp ~= 0) then
            for i,v in ipairs (dmz6Tmp) do
                v = util.addPrefix (v, "dmz6.");
                fw.config ("dmz6", v, "-1", "add")
            end
        end
end

-- Register 'firewall' with 'config' to facilitate import and export  
if (config.register) then
   config.register("firewall", firewall.import, firewall.export, "1")
end

-------------------------------------------------------------------------------
-- @name : firewall.dmzGet()
--
-- @description : API to return 'dmz' table
--
-- @return : Entire dmz table
-- 
function firewall.dmzGet ()
    --local 
    local dmzTbl = {}
    
    dmzTbl = db.getRow ("dmz", "_ROWID_", "1")   

    -- convert logical name to network name 
    dmzTbl["dmz.wanNetworkName"] = db.getAttribute ("networkInterface", "LogicalIfName", dmzTbl["dmz.LogicalIfName"], "networkName")
    --return
    return dmzTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.dmzSet()
--
-- @description : API to set values in 'dmz' table
--
-- @return : status, error code
-- 
function firewall.dmzSet (dmzTable)

    -- add table prefix
    dmzTable = util.addPrefix(dmzTable, "dmz.")

    statusFlag = fw.config ("dmz", dmzTable, "1", "edit")

    -- check status
    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "Dmz configuration failed"
    end    
end
-------------------------------------------------------------------------------
-- @name : firewall.getNetMask()
--
-- @description : API to get the netmask
--
-- @return : status, error, value

function firewall.getNetMask(logicalIfName, ipAddr)

    require "fwPortTriggerLuaLib"
    -- locals 
    local status = "ERROR"
    local errMsg = "SUBNET_MASK_NOT_FOUND"

    local netMask = ""
    local ifStaticTbl = {}
    local query = "LogicalIfName='" .. logicalIfName .. "'AND AddressFamily=2"

    -- getting the ifStatic table
    
    ifStaticTbl = db.getRowWhere("ifStatic", query, false)
    
    -- Querying the ifStatic if any match is found
    local statusFlag = fwPortTriggerLuaLib.getNetwork (ifStaticTbl["StaticIp"], ifStaticTbl["NetMask"], ipAddr)
    if (statusFlag == 1) then
        netMask = ifStaticTbl["NetMask"] or ""
    end
    if (statusFlag == 0) then
        return status, errMsg, netMask 
    else
        return "OK", "STATUS_OK", netMask
    end
end

--------------------------------------------------------------------------------
-- @name : firewall.protoNameToNum()
--
-- @description : This function returns protocol number for given protocol name 
--
-- @return : value
--
function firewall.protoNameToNum (protoName)
	local value

	if (protoName == "TCP") then
		value = "6"
	elseif (protoName == "UDP") then
		value = "17"
	else
		value = "1"
	end

	return value
end

-------------------------------------------------------------------------------
-- @name : firewall.protoNumToName()
--
-- @description : This function returns protocol name for given protocol number 
--
-- @return : value
--
function firewall.protoNumToName (protoNum)
	local value

	if (protoNum == "6") then
		value = "TCP"
	elseif (protoNum == "17") then
		value = "UDP"
	else
		value = "ICMP"
	end

	return value
end

-------------------------------------------------------------------------------
-- @name : firewall.addr4Validate()
--
-- @description : This function is used for ipv4 address validation
--
-- @return : OK, ERROR
--
function firewall.addr4Validate (addr)
	return "OK"
end

-------------------------------------------------------------------------------
-- @name : firewall.portRangeValidate()
--
-- @description : This function validates the port number
--
-- @return : OK, ERROR
--
function firewall.portRangeValidate (port)
	local portNum = tonumber(port)

	if (portNum >= 0 and portNum <= 65535) then
		return "OK"
	end	

	return "ERROR"
end

-------------------------------------------------------------------------------
-- @name : firewall.macFilterConfigGet()
--
-- @description : API to return 'macFilterConfig' table
--
-- @return : Entire macFilterConfig table
-- 
function firewall.macFilterConfigGet()
    --local 
    local macFilterConfigTbl = {}
    
    macFilterConfigTbl = db.getRow ("macFilterConfig", "_ROWID_", "1")   
    macFilterConfigTbl = util.removePrefix(macFilterConfigTbl, "macFilterConfig.")
    --return
    return macFilterConfigTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.macFilterConfigSet()
--
-- @description : API to set values in 'macFilterConfig' table
--
-- @return : status, error code
-- 
function firewall.macFilterConfigSet(macFilterConfigTable)

    -- add table prefix
    macFilterConfigTable = util.addPrefix(macFilterConfigTable, "macFilterConfig.")

    statusFlag = fw.config ("macFilterConfig", macFilterConfigTable, "1", "edit")

    -- check status
    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "MAC filter configuration failed"
    end    
end

-------------------------------------------------------------------------------
-- @name : firewall.macRulesGet()
--
-- @description : This function returns all the MAC filtering rules 
--
-- @return : lua table containing all the rules that need to be displayed
--
function firewall.macRulesGet()
    return db.getTable ("macFilterRules", false)
end

-------------------------------------------------------------------------------
-- @name : firewall.fwMacRulesConfig()
--
-- @description : API to perform actual DB add/delete/edit operation on  MAC
-- filtering tables
--
-- @return : status, errorMsg 
-- 
function firewall.fwMacRulesConfig(inputTable, rowid, operation)
    local statusFlag = true
    db.beginTransaction() --begin transactions

    inputTable = util.addPrefix(inputTable, "macFilterRules.")
  
    statusFlag = fw.config("macFilterRules", inputTable, rowid, operation)
    
    -- return
    if (statusFlag) then
        db.commitTransaction(true)
    	return "OK", "STATUS_OK"
    else
	    db.rollback()
    	return "ERROR", "FW_CONFIG_FAILED"
    end
end

-------------------------------------------------------------------------------
-- @name : firewall.tr69fwMacRulesConfig()
--
-- @description : API to perform actual DB add/delete/edit operation on  MAC
-- filtering tables
--
-- @return : status, errorMsg 
-- 
function firewall.tr69fwMacRulesConfig(inputTable, rowid, operation)
    local statusFlag = true

    inputTable = util.addPrefix(inputTable, "macFilterRules.")
  
    statusFlag = fw.config("macFilterRules", inputTable, rowid, operation)
    
    -- return
    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_CONFIG_FAILED"
    end
end

-------------------------------------------------------------------------------
-- @name : firewall.macRulesAddSet()
--
-- @description : This function is used to set the DB when a MAC rule is added
--
-- @return : status, errorMsg
--
function firewall.macRulesAddSet(macFilterRuleTbl)
    return firewall.fwMacRulesConfig(macFilterRuleTbl, "-1", "add")  
end

-------------------------------------------------------------------------------
-- @name : firewall.macRulesEditSet()
--
-- @description : This function is used to set the values in DB when a MAC
-- filtering rule is to be edited
--
-- @return : status, errorMsg
--
function firewall.macRulesEditSet(macFilterRuleTbl)
    return firewall.fwMacRulesConfig(macFilterRuleTbl, macFilterRuleTbl._ROWID_, "edit")
end

-------------------------------------------------------------------------------
-- @name : firewall.macRulesEditGet()
--
-- @description : API to return MAC filter rule being edited
--
-- @return : lua table containing previous values of the row
--
function firewall.macRulesEditGet(rowId)
    local configTbl = {}
    configTbl = db.getRow ("macFilterRules", "_ROWID_", rowId)
    configTbl = util.removePrefix(configTbl, "macFilterRules.")
    return configTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.macRulesDelete()
--
-- @description : This function is used to delete MAC filtering rules
--
-- @return : status, errorMsg
--
function firewall.macRulesDelete(inTable)
    return firewall.fwMacRulesConfig(inTable, inTable._ROWID_, "delete")
end

-------------------------------------------------------------------------------
-- @name : firewall.contentFilteringConfigGet()
--
-- @description : API to return 'ContentFiltering' table
--
-- @return : Entire ContentFiltering table
-- 
function firewall.contentFilteringConfigGet()
    --local 
    local contentFilteringTbl = {}
    
    contentFilteringTbl = db.getRow ("ContentFiltering", "_ROWID_", "1")   

    contentFilteringTbl = util.removePrefix(contentFilteringTbl, "ContentFiltering.")
    --return
    return contentFilteringTbl
end


-------------------------------------------------------------------------------
-- @name : firewall.contentFilteringConfigSet()
--
-- @description : API to set values in 'ContentFiltering' table
--
-- @return : status, error code
-- 
function firewall.contentFilteringConfigSet(contentFilteringTbl)

    -- add table prefix
    contentFilteringTbl = util.addPrefix(contentFilteringTbl, "ContentFiltering.")

    statusFlag = fw.config ("ContentFiltering", contentFilteringTbl, "1", "edit")

    -- check status
    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "Content filtering configuration failed"
    end    
end

-------------------------------------------------------------------------------
-- @name : firewall.contentFilterConfig()
--
-- @description : API to perform actual DB add/delete/edit operation on content
-- filtering tables
--
-- @return : status, errorMsg 
-- 
function firewall.contentFilterConfig(tableName, inputTable, rowid, operation)
    local statusFlag = true
    db.beginTransaction() --begin transactions

    local prefixVal = tableName .. "."
    inputTable = util.addPrefix(inputTable, prefixVal)
 
	if (tableName == "BlockSites") then
        util.appendDebugOut("BlockSites Table: " .. util.tableToStringRec(inputTable) .. "\n")
        if (operation == "add" or operation == "edit") then
            local keywrd = string.upper (inputTable["BlockSites.KeywordToBlock"])
            if (keywrd == "HTTP" or keywrd == "HTTPS") then
                return "ERROR", "HTTP_HTTPS_NOT_ALLOWED"
            end
        end
--Check for previous existing entry
        if (operation == "add") then
            if (db.existsRow(tableName, "KeywordToBlock", inputTable["BlockSites.KeywordToBlock"])) then
                return "ERROR", "KEYWORD_ALREADY_EXIST"
            end
        end
    end
--Check for previous existing entry
	if (tableName == "TrustedDomains") then
        if (operation == "add") then
            if (db.existsRow(tableName, "KeywordToAllow", inputTable["TrustedDomains.KeywordToAllow"])) then
                return "ERROR", "KEYWORD_ALREADY_EXIST"
            end
        end
    end

    statusFlag = fw.config(tableName, inputTable, rowid, operation)
    
    -- return
    if (statusFlag) then
        db.commitTransaction(true)
    	return "OK", "STATUS_OK"
    else
	    db.rollback()
    	return "ERROR", "CF_CONFIG_FAILED"
    end
end

-------------------------------------------------------------------------------
-- @name : firewall.trustedDomainsGet()
--
-- @description : This function returns all the trusted domains
--
-- @return : lua table containing all the trusted domains that need to be displayed
--
function firewall.trustedDomainsGet()
    return db.getTable ("TrustedDomains", false)
end

-------------------------------------------------------------------------------
-- @name : firewall.trustedDomainsAddSet()
--
-- @description : This function is used to set the DB when a trusted domain is added
--
-- @return : status, errorMsg
--
function firewall.trustedDomainsAddSet(trustedDomainsTbl)
    return firewall.contentFilterConfig("TrustedDomains", trustedDomainsTbl, "-1", "add")  
end

-------------------------------------------------------------------------------
-- @name : firewall.trustedDomainsEditSet()
--
-- @description : This function is used to set the values in DB when a trusted
-- domain is to be edited
--
-- @return : status, errorMsg
--
function firewall.trustedDomainsEditSet(trustedDomainsTbl)
    return firewall.contentFilterConfig("TrustedDomains", trustedDomainsTbl, trustedDomainsTbl._ROWID_, "edit")
end

-------------------------------------------------------------------------------
-- @name : firewall.trustedDomainsEditGet()
--
-- @description : API to return trusted domain being edited
--
-- @return : lua table containing previous values of the row
--
function firewall.trustedDomainsEditGet(rowId)
    local configTbl = {}
    configTbl = db.getRow("TrustedDomains", "_ROWID_", rowId) 
    configTbl = util.removePrefix(configTbl, "TrustedDomains.")
    return configTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.trustedDomainsDelete()
--
-- @description : This function is used to delete trusted domains
--
-- @return : status, errorMsg
--
function firewall.trustedDomainsDelete(inTable)
    return firewall.contentFilterConfig("TrustedDomains", inTable, inTable._ROWID_, "delete")
end

-------------------------------------------------------------------------------
-- @name : firewall.blockSitesGet()
--
-- @description : This function returns all the blocked sites
--
-- @return : lua table containing all the blocked sites that need to be displayed
--
function firewall.blockSitesGet()
    return db.getTable ("BlockSites", false)
end

-- check input file content for "'"
function firewall.verifyFileContent(filePath)
    local fileHandle = io.open(filePath)
    if(fileHandle) then
        local fileContent = fileHandle:read("*all") or ''
        fileHandle:close()
        if (db.sqlInjectionCheck(fileContent)) then
            return true
        else
            return false
        end
    end
end

-------------------------------------------------------------------------------
-- @name : firewall.importCSV
--
-- @description : This function imports blocked sites or approved urls from
--                a csv file
--
-- @return : status, errorMsg
--
function firewall.importCSV(tblName, filePath)
    local valid = false

    -- check if filePath exists
    if (filePath == nil) then
        firewall.tf1Dbg("filePath is nil")
        return "ERROR", "NULL_PARAMETER"
    end

    -- check for "'" in csv file content
    valid = firewall.verifyFileContent(filePath)
    if (valid) then
	   return "ERROR","SQL_INVALID_INPUT"
    end

    -- check if table name exists
    if (tblName == nil) then
        return "ERROR", "NULL_PARAMETER"
    end

    if (tblName == "BlockSites") then
         valid = os.execute ("/pfrm2.0/bin/importBlockedKeyword " .. filePath .. " "  .. tblName)
    elseif (tblName == "TrustedDomains") then
         valid = os.execute ("/pfrm2.0/bin/importApprovedUrls " .. filePath .. " " .. tblName)
    else
         return "ERROR", "TABLE_NOT_SUPPORTED"
    end

    os.execute("rm " .. filePath)

    if (valid == 0) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "IMPORT_FAILED"
    end
end

-------------------------------------------------------------------------------
-- @name : firewall.blockSitesAddSet()
--
-- @description : This function is used to set the DB when a blocked site is added
--
-- @return : status, errorMsg
--
function firewall.blockSitesAddSet(blockSitesTbl)
    blockSitesTbl["Status"] = 1
    return firewall.contentFilterConfig("BlockSites", blockSitesTbl, "-1", "add")  
end

-------------------------------------------------------------------------------
-- @name : firewall.blockSitesEditSet()
--
-- @description : This function is used to set the values in DB when a blocked
-- site is to be edited
--
-- @return : status, errorMsg
--
function firewall.blockSitesEditSet(blockSitesTbl)
    return firewall.contentFilterConfig("BlockSites", blockSitesTbl, blockSitesTbl._ROWID_, "edit")
end

-------------------------------------------------------------------------------
-- @name : firewall.blockSitesEditGet()
--
-- @description : API to return blocked site being edited
--
-- @return : lua table containing previous values of the row
--
function firewall.blockSitesEditGet(rowId)
    local configTbl = {}
    configTbl = db.getRow("BlockSites", "_ROWID_", rowId) 
    configTbl = util.removePrefix(configTbl, "BlockSites.")
    return configTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.blockSitesDelete()
--
-- @description : This function is used to delete blocked sites
--
-- @return : status, errorMsg
--
function firewall.blockSitesDelete(inTable)
    return firewall.contentFilterConfig("BlockSites", inTable, inTable._ROWID_, "delete")
end

-------------------------------------------------------------------------------
-- @name : firewall.blockSitesEnable()
--
-- @description : This function is used to enable a blocked site
-- Rule
--
-- @return : status, errorMsg
--
function firewall.blockSitesEnable(rowId)
    local statusFlag = true

    -- set status as '1' the blocked site that need to be enabled
    statusFlag = db.setAttribute ("BlockSites", "_ROWID_", rowId, "Status", "1")

    if(statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_CONFIG_FAILED"
    end
end

-------------------------------------------------------------------------------
-- @name : firewall.blockSitesDisable()
--
-- @description : This function is used to disable a blocked site
--
-- @return : status, errorMsg
--
function firewall.blockSitesDisable(rowId)
    local statusFlag = true

    -- set status as '0' for the blocked site that need to be disabled
    statusFlag = db.setAttribute ("BlockSites", "_ROWID_", rowId, "Status", "0")

    if(statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_CONFIG_FAILED"
    end
end



-------------------------------------------------------------------------------
-- @name : firewall.defaultPolicyConfigGet()
--
-- @description : API to return 'defaultPolicy' table
--
-- @return : Entire defaultPolicy table
-- 
function firewall.defaultPolicyConfigGet()
    --local 
    local defaultPolicyTbl = {}
    
    defaultPolicyTbl = db.getRow ("defaultPolicy", "_ROWID_", "1")   

    defaultPolicyTbl = util.removePrefix(defaultPolicyTbl, "defaultPolicy.")
    --return
    return defaultPolicyTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.defaultPolicyConfigSet()
--
-- @description : API to set values in 'defaultPolicy' table
--
-- @return : status, error code
-- 
function firewall.defaultPolicyConfigSet(defaultPolicyTbl)

    -- add table prefix
    defaultPolicyTbl = util.addPrefix(defaultPolicyTbl, "defaultPolicy.")

    statusFlag = fw.config ("defaultPolicy", defaultPolicyTbl, "1", "edit")

    -- check status
    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_CONFIG_FAILED"
    end    
end

-------------------------------------------------------------------------------
-- @name : firewall.defaultL2PolicyConfigGet()
--
-- @description : API to return 'L2FirewallDefaultPolicy' table
--
-- @return : Entire defaultPolicy table
-- 
function firewall.defaultL2PolicyConfigGet()
    --local 
    local defaultL2PolicyTbl = {}
    
    defaultL2PolicyTbl = db.getRow ("L2FirewallDefaultPolicy", "_ROWID_", "1")   

    defaultL2PolicyTbl = util.removePrefix(defaultL2PolicyTbl, "L2FirewallDefaultPolicy.")
    --return
    return defaultL2PolicyTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.defaultL2PolicyConfigSet()
--
-- @description : API to set values in 'L2FirewallDefaultPolicy' table
--
-- @return : status, error code
-- 
function firewall.defaultL2PolicyConfigSet(defaultL2PolicyTbl)

    -- add table prefix
    defaultL2PolicyTbl = util.addPrefix(defaultL2PolicyTbl, "L2FirewallDefaultPolicy.")

    statusFlag = fw.config ("L2FirewallDefaultPolicy", defaultL2PolicyTbl, "1", "edit")

    -- check status
    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_CONFIG_FAILED"
    end    
end

-------------------------------------------------------------------------------
-- @name : firewall.connectionEntryFlushConfigGet()
--
-- @description : API to return 'conntrackAction' table
--
-- @return : Entire conntrackAction table
-- 
function firewall.connectionEntryFlushConfigGet()
    --local 
    local conntrackActionTbl = {}
    
    conntrackActionTbl = db.getRow ("conntrackAction", "_ROWID_", "1")   

    conntrackActionTbl = util.removePrefix(conntrackActionTbl, "conntrackAction.")
    --return
    return conntrackActionTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.connectionEntryFlushConfigSet()
--
-- @description : API to set values in 'conntrackAction' table
--
-- @return : status, error code
-- 
function firewall.connectionEntryFlushConfigSet(conntrackActionTbl)

    -- add table prefix
    localConntracActionTbl = util.addPrefix(conntrackActionTbl, "conntrackAction.")

    statusFlag = fw.config ("conntrackAction", localConntracActionTbl, "1", "edit")

    -- check status
    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_CONFIG_FAILED"
    end    
end

-------------------------------------------------------------------------------
-- @name : firewall.routingModeConfigGet()
--
-- @description : API to return 'routingMode' table
--
-- @return : Entire routingMode table
-- 
function firewall.routingModeConfigGet()
    --local 
    local routingModeTbl = {}
    
    routingModeTbl = db.getRow ("routingMode", "_ROWID_", "1")   

    routingModeTbl = util.removePrefix(routingModeTbl, "routingMode.")

    --return
    return routingModeTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.routingModeConfigSet()
--
-- @description : API to set values in 'routingMode' table
--
-- @return : status, error code
-- 
function firewall.routingModeConfigSet(routingModeTbl)
    -- check if the configuration has changed in GUI
    local currentTbl = firewall.routingModeConfigGet()
    if (currentTbl["natSetting"] == routingModeTbl["natSetting"]) then
        return "OK", "STATUS_OK"
    end

    -- add table prefix
    routingModeTbl = util.addPrefix(routingModeTbl, "routingMode.")

    statusFlag = fw.config ("routingMode", routingModeTbl, "1", "edit")
    if (statusFlag) then
        --delete all port forwarding rules
        local pfwdRules = {}
        local inTable = {}
        local status = "OK"
        pfwdRules = db.getRowsWhere ("FirewallRules", "RuleType = 'INSECURE_SECURE'", false)
        for k,v in pairs(pfwdRules) do
            inTable["FirewallRules._ROWID_"] = v["_ROWID_"]
            status = firewall.portFwdRulesDelete (inTable)
        end
        if (status ~= "OK") then 
            statusFlag = false
        end
    end

    -- check status
    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_CONFIG_FAILED"
    end    
end

-------------------------------------------------------------------------------
-- @name : firewall.algConfigGet()
--
-- @description : API to return 'AlgConf' table
--
-- @return : lua table containing alg configuration
-- 
function firewall.algConfigGet()
    --local 
    local configTbl = {}
    
    configTbl = db.getRow ("AlgConf", "_ROWID_", "1")   

    configTbl = util.removePrefix(configTbl, "AlgConf.")

    --return
    return configTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.algConfigSet()
--
-- @description : API to set values in 'AlgConf' table
--
-- @return : status, error code
-- 
function firewall.algConfigSet(algConfTbl)
    --locals
    local statusFlag = true

    -- add table prefix
    algConfTbl = util.addPrefix(algConfTbl, "AlgConf.")

    statusFlag = fw.config ("AlgConf", algConfTbl, "1", "edit")

    -- check status
    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_CONFIG_FAILED"
    end    
end

-------------------------------------------------------------------------------
-- @name : firewall.routingLogsConfigGet()
--
-- @description : API to return 'FirewallLogs' table
--
-- @return : lua table containing routingLogs configuration
-- 
function firewall.routingLogsConfigGet()
    --local 
    local configTbl = {}
    
    configTbl = db.getRow ("FirewallLogs", "_ROWID_", "1")   

    configTbl = util.removePrefix(configTbl, "FirewallLogs.")

    --return
    return configTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.routingLogsConfigSet()
--
-- @description : API to set values in 'FirewallLogs' table
--
-- @return : status, error code
-- 
function firewall.routingLogsConfigSet(routingLogsConfTbl)
    --locals
    local statusFlag = true

    -- add table prefix
    routingLogsConfTbl = util.addPrefix(routingLogsConfTbl, "FirewallLogs.")

    statusFlag = fw.config ("FirewallLogs", routingLogsConfTbl, "1", "edit")

    -- check status
    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_CONFIG_FAILED"
    end    
end

-------------------------------------------------------------------------------
-- @name : firewall.ipv6LogsConfigGet()
--
-- @description : API to return 'FirewallLogs6' table
--
-- @return : lua table containing ipv6Logs configuration
-- 
function firewall.ipv6LogsConfigGet()
    --local 
    local configTbl = {}
    
    configTbl = db.getRow ("FirewallLogs6", "_ROWID_", "1")   

    configTbl = util.removePrefix(configTbl, "FirewallLogs6.")

    --return
    return configTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.ipv6LogsConfigSet()
--
-- @description : API to set values in 'FirewallLogs6' table
--
-- @return : status, error code
-- 
function firewall.ipv6LogsConfigSet(ipv6LogsConfTbl)
    --locals
    local statusFlag = true

    -- add table prefix
    ipv6LogsConfTbl = util.addPrefix(ipv6LogsConfTbl, "FirewallLogs6.")

    statusFlag = fw.config ("FirewallLogs6", ipv6LogsConfTbl, "1", "edit")

    -- check status
    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_CONFIG_FAILED"
    end    
end

-------------------------------------------------------------------------------
-- @name : firewall.systemLogsConfigGet()
--
-- @description : API to return 'FirewallLogs' table
--
-- @return : lua table containing systemLogs configuration
-- 
function firewall.systemLogsConfigGet()
    --local 
    local configTbl = {}
    
    configTbl = db.getRow ("FirewallLogs", "_ROWID_", "1")   

    configTbl = util.removePrefix(configTbl, "FirewallLogs.")

    --return
    return configTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.systemLogsConfigSet()
--
-- @description : API to set values in 'FirewallLogs' table
--
-- @return : status, error code
-- 
function firewall.systemLogsConfigSet(routingLogsConfTbl)
    --locals
    local statusFlag = true

    -- add table prefix
    routingLogsConfTbl = util.addPrefix(routingLogsConfTbl, "FirewallLogs.")

    statusFlag = fw.config ("FirewallLogs", routingLogsConfTbl, "1", "edit")

    -- check status
    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_CONFIG_FAILED"
    end    
end

-------------------------------------------------------------------------------
-- @name : firewall.specAttChkConfigGet()
--
-- @description : API to return 'SpecificAttackChecks' table
--
-- @return : lua table containing specific attack checks configuration
-- 
function firewall.specAttChkConfigGet()
    --locals
    local configTbl = {}
    
    configTbl = db.getRow ("SpecificAttackChecks", "_ROWID_", "1")   

    configTbl = util.removePrefix(configTbl, "SpecificAttackChecks.")

    --return
    return configTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.specAttChkConfigSet()
--
-- @description : API to set values in 'SpecificAttackChecks' table
--
-- @return : status, error code
-- 
function firewall.specAttChkConfigSet(cfgTbl)
    --locals
    local statusFlag = true

    -- add table prefix
    cfgTbl = util.addPrefix(cfgTbl, "SpecificAttackChecks.")

    statusFlag = fw.config ("SpecificAttackChecks", cfgTbl, "1", "edit")

    -- check status
    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_CONFIG_FAILED"
    end    
end

--------------------------------------------------------------------------
-- @name : firewall.status()
--
-- @description : API to return 'status' table
--
-- @return : Entire firewall status table
-- 
function firewall.Statusget ()
    local FirewallStatusTbl = {}
   FirewallStatusTbl = db.getRow ("firewallStatus", "_ROWID_", "1")     
    return FirewallStatusTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.statusSet()
--
-- @description : API to set values in 'status' table
--
-- @return : None
-- 
function firewall.StatusSet (FirewallStatusTable)
    statusFlag = fw.config ("firewallStatus", FirewallStatusTable, "1", "edit")
    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "Firewall configuration failed"
    end  
end

-------------------------------------------------------------------------------
-- @name : firewall.dosAttChkConfigGet()
--
-- @description : API to return 'DosAttackChecks' table
--
-- @return : lua table containing dos/ddos attack checks configuration
-- 
function firewall.dosAttChkConfigGet()
    --locals
    local configTbl = {}
    
    configTbl = db.getRow ("DosAttackChecks", "_ROWID_", "1")   

    configTbl = util.removePrefix(configTbl, "DosAttackChecks.")

    --return
    return configTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.dosAttChkConfigSet()
--
-- @description : API to set values in 'DosAttackChecks' table
--
-- @return : status, error code
-- 
function firewall.dosAttChkConfigSet(cfgTbl)
    --locals
    local statusFlag = true

    debug.Debugger("Entering firewall.dosAttChkConfigSet fn..")
    for k,v in pairs(cfgTbl) do
        debug.Debugger("k:" .. k .. "    v:" .. v)
    end

    debug.Debugger("Entering dosAttChkConfigSet..")
    -- add table prefix
    cfgTbl = util.addPrefix(cfgTbl, "DosAttackChecks.")

    statusFlag = fw.config ("DosAttackChecks", cfgTbl, "1", "edit")

    -- check status
    if (statusFlag) then
        debug.Debugger("Leaving dosAttChkConfigSet OK..")
    	return "OK", "STATUS_OK"
    else
        debug.Debugger("Leaving dosAttChkConfigSet ERROR..")
    	return "ERROR", "FW_CONFIG_FAILED"
    end    
end

-------------------------------------------------------------------------------
-- @name : firewall.iscaSettingConfigGet()
--
-- @description : API to return 'IcsaSettings' table
--
-- @return : lua table containing IcsaSettings configuration
-- 
function firewall.iscaSettingConfigGet()
    --locals
    local configTbl = {}
    
    configTbl = db.getRow ("IcsaSettings", "_ROWID_", "1")   

    configTbl = util.removePrefix(configTbl, "IcsaSettings.")

    --return
    return configTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.iscaSettingConfigSet()
--
-- @description : API to set values in 'IcsaSettings' table
--
-- @return : status, error code
-- 
function firewall.iscaSettingConfigSet(cfgTbl)
    --locals
    local statusFlag = true

    debug.Debugger("Entering firewall.iscaSettingConfigSet fn..")
    for k,v in pairs(cfgTbl) do
        debug.Debugger("k:" .. k .. "    v:" .. v)
    end

    debug.Debugger("Entering iscaSettingConfigSet..")
    -- add table prefix
    cfgTbl = util.addPrefix(cfgTbl, "IcsaSettings.")

    statusFlag = fw.config ("IcsaSettings", cfgTbl, "1", "edit")

    -- check status
    if (statusFlag) then
        debug.Debugger("Leaving iscaSettingConfigSet OK..")
    	return "OK", "STATUS_OK"
    else
        debug.Debugger("Leaving iscaSettingConfigSet ERROR..")
    	return "ERROR", "FW_CONFIG_FAILED"
    end    
end

-------------------------------------------------------------------------------
-- @name : firewall.p2pSessionLimitConfigGet()
--
-- @description : API to return 'p2pSessionLimit' table
--
-- @return : lua table containing P2P Sesion limit configuration
-- 
function firewall.p2pSessionLimitConfigGet()
    --locals
    local configTbl = {}
   util.appendDebugOut ("\n\nHere to get table values \n\n") 
    configTbl = db.getRow ("p2pSessionLimit", "_ROWID_", "1")   

util.appendDebugOut ("\nP2PSessionLimit Table: \n\n" .. util.tableToString (configTbl))
    --configTbl = util.removePrefix(configTbl, "p2pSessionLimit.")

    --return
    return configTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.p2pSessionLimitConfigSet()
--
-- @description : API to set values in p2pSessionLimit table
--
-- @return : status, error code
-- 
function firewall.p2pSessionLimitConfigSet(cfgTbl)
    --locals
    local statusFlag = true

    util.appendDebugOut("Entering firewall.p2pSessionLimitConfigSet fn..")
    for k,v in pairs(cfgTbl) do
        util.appendDebugOut("\nk:" .. k .. "    v:\n" .. v)
    end

    util.appendDebugOut("Entering p2pSessionLimitConfigSet..")
    -- add table prefix
    cfgTbl = util.addPrefix(cfgTbl, "p2pSessionLimit.")

    statusFlag = fw.config ("p2pSessionLimit", cfgTbl, "1", "edit")

    -- check status
    if (statusFlag) then
        util.appendDebugOut("Leaving p2pSessionLimitConfigSet OK..")
    	return "OK", "STATUS_OK"
    else
        util.appendDebugOut("Leaving p2pSessionLimitConfigSet ERROR..")
    	return "ERROR", "FW_CONFIG_FAILED"
    end    
end

-------------------------------------------------------------------------------
-- @name : firewall.scheduleConfig()
--
-- @description : API to perform actual DB operation on schedule table(s)
--
-- @return : status, errorMsg 
-- 
function firewall.scheduleConfig(tableName, inputTable, rowid, operation)
    local statusFlag = true
    db.beginTransaction() --begin transactions

    local prefixVal = tableName .. "."
    inputTable = util.addPrefix(inputTable, prefixVal)
  
    statusFlag = fw.config(tableName, inputTable, rowid, operation)
    
    -- return
    if (statusFlag) then
        db.commitTransaction(true)
    	return "OK", "STATUS_OK"
    else
	    db.rollback()
    	return "ERROR", "SCHEDULE_CONFIG_FAILED"
    end
end

-------------------------------------------------------------------------------
-- @name : firewall.fwSchedGet()
--
-- @description : This function returns all the schedules
--
-- @return : lua table containing all the schedules
-- 
function firewall.fwSchedGet()
    return db.getTable ("Schedules", false)
end

-------------------------------------------------------------------------------
-- @name : firewall.fwSchedAddSet()
--
-- @description : updates the DB when a schedule is added
--
-- @return : status, errorMsg
--
function firewall.fwSchedAddSet(schedTbl)
    return firewall.scheduleConfig("Schedules", schedTbl, "-1", "add")  
end

-------------------------------------------------------------------------------
-- @name : firewall.fwSchedEditGet()
--
-- @description : API to return schedule being edited
--
-- @return : lua table containing previous values of the row
--
function firewall.fwSchedEditGet(rowId)
    local configTbl = {}
    configTbl = db.getRow("Schedules", "_ROWID_", rowId) 
    configTbl = util.removePrefix(configTbl, "Schedules.")
    return configTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.fwSchedEditSet()
--
-- @description : Updates the DB when a schedule is edited
--
-- @return : status, errorMsg
--
function firewall.fwSchedEditSet(scheduleTbl)
    local schName = ""
    local isDepApproved, isDepBlocked
    local query = ""

    schName = scheduleTbl["ScheduleName"]
    query = "ScheduleName = '" .. schName .."'"

    isDepApproved = db.existsRowWhere("TrustedDomains", query)
    isDepBlocked = db.existsRowWhere("BlockSites", query)

    if (isDepApproved or isDepBlocked) then
        return "ERROR", "SCHEDULE_IN_USE"
    end
    
    return firewall.scheduleConfig("Schedules", scheduleTbl, scheduleTbl._ROWID_, "edit")
end

-------------------------------------------------------------------------------
-- @name : firewall.fwSchedDelete()
--
-- @description : This function is used to delete schedules
--
-- @return : status, errorMsg
--
function firewall.fwSchedDelete(inTable)
    local valid = false

    valid = fw.config("Schedules", inTable, inTable._ROWID_, "delete") 

    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "SCHEDULE_DELETE_FAILED"
    end
end

-------------------------------------------------------------------------------
-- @name : firewall.bwMonGet()
--
-- @description : API to return 'BwMon' table
--
-- @return : Entire bwMon table
-- 
function firewall.bwMonGet()
    --local 
    local bwMonTbl = {}
    
    bwMonTbl = db.getRow ("BwMon", "_ROWID_", "1")   

    bwMonTbl = util.removePrefix(bwMonTbl, "BwMon.")

    --return
    return bwMonTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.pktCountGet()
--
-- @description : API to return 'PktCountEnable' table
--
-- @return : Entire PktCountEnable table
-- 
function firewall.pktCountGet()
    --local 
    local PktCountEnableTbl = {}
    
    PktCountEnableTbl = db.getRow ("PktCountEnable", "_ROWID_", "1")   

    PktCountEnableTbl = util.removePrefix(PktCountEnableTbl, "PktCountEnable.")

    --return
    return PktCountEnableTbl
end
-------------------------------------------------------------------------------
-- @name : firewall.bwMonSet()
--
-- @description : API to set values in 'BwMon' table
--
-- @return : status, error code
-- 
function firewall.bwMonSet(bwMonTbl)
    -- check if the configuration has changed in GUI
    local currentTbl = firewall.bwMonGet()
    if (currentTbl["enable"] == bwMonTbl["enable"]) then
        return "OK", "STATUS_OK"
    end

    -- add table prefix
    bwMonTbl = util.addPrefix(bwMonTbl, "BwMon.")

    statusFlag = fw.config ("BwMon", bwMonTbl, "1", "edit")
    if (statusFlag) then
        -- set all counters to 0 in BwMonStat table
        local bwMonStatTbl = db.getTable ("BwMonStat") 
        if (bwMonStatTbl ~= nil) then
            for k,v in pairs(bwMonStatTbl) do
                v["BwMonStat.Counter"] = "0"
                statusFlag = fw.config ("BwMonStat", v, v["BwMonStat._ROWID_"], "edit")
            end
        else
            statusFlag = false
        end
    end

    -- check status
    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_CONFIG_FAILED"
    end    
end
-------------------------------------------------------------------------------
-- @name : firewall.pktCountSet()
--
-- @description : API to set values in 'PktCountEnable' table
--
-- @return : status, error code
-- 
function firewall.pktCountSet(PktCountEnableTbl)
    -- check if the configuration has changed in GUI
    local currentTbl = firewall.pktCountGet()
    if (currentTbl["enable"] == PktCountEnableTbl["status"]) then
        return "OK", "STATUS_OK"
    end

      local tmpPktCountTbl = {}
      tmpPktCountTbl["enable"] = PktCountEnableTbl["status"]
    -- add table prefix
    PktCountEnableTbl = util.addPrefix(tmpPktCountTbl, "PktCountEnable.")

    statusFlag = fw.config ("PktCountEnable", PktCountEnableTbl, "1", "edit")
    -- check status
    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_CONFIG_FAILED"
    end    
end
-------------------------------------------------------------------------------
-- @name : firewall.bwMonCustomGet()
--
-- @description : This function returns all the custom bandwidth monfitoring
-- configuration 
--
-- @return : lua table containing all the rules that need to be displayed
--
function firewall.bwMonCustomGet()
    return db.getTable ("BwMonCustom", false)
end

-------------------------------------------------------------------------------
-- @name : firewall.bwMonCustomConfig()
--
-- @description : API to perform actual DB add/delete/edit operation on bwMonCustom
--  tables
--
-- @return : status, errorMsg 
-- 
function firewall.bwMonCustomConfig(inputTable, rowid, operation)
    local statusFlag = true

    inputTable = util.addPrefix(inputTable, "BwMonCustom.")
  
    statusFlag = fw.config("BwMonCustom", inputTable, rowid, operation)
    
    -- return
    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_CONFIG_FAILED"
    end
end

-------------------------------------------------------------------------------
-- @name : firewall.bwMonCustomAddSet()
--
-- @description : This function is used to set the DB when a custom bandwidth
-- montitoring is added
--
-- @return : status, errorMsg
--
function firewall.bwMonCustomAddSet(bwMonCustomConf)
    local status = false
    local query = nil
    local accNameIdx = 0
    local maxIdx = 1
    local Idx = 0
    local bwMonStatRow = {}

    -- Check if same account is already present
    if (bwMonCustomConf["accType"] == "1") then
        query = "ipAddr='" .. bwMonCustomConf["ipAddr"] .. "'"
    else
        query = "macAddr='" .. bwMonCustomConf["macAddr"] .. "'"
    end
    
    if (db.existsRowWhere ("bwMonCustom", query)) then
        return "ERROR", "CUSTOM_ACCOUNT_ALREADY_EXIST"
    end
    
    local bwMonCustomTbl = db.getTable("BwMonCustom", false)
    if (bwMonCustomTbl ~= nil and #bwMonCustomTbl > 0) then
        for kk, vv in pairs (bwMonCustomTbl) do
            Idx = tonumber (string.sub (vv["AccName"], 5))
            if (maxIdx < Idx) then
                maxIdx = Idx
            end
        end
        accNameIdx = maxIdx + 1
    else
        accNameIdx = 1
    end

    local accName = "HOST" .. accNameIdx
    bwMonCustomConf["AccName"] = accName

    local appNames = db.getDistinctValues("BwMonStat", "AppName")
    for k,v in pairs (appNames) do
        bwMonStatRow = {}
        bwMonStatRow["BwMonStat.LogicalIfName"] = bwMonCustomConf["LogicalIfName"]
        bwMonStatRow["BwMonStat.AccName"] = accName
        bwMonStatRow["BwMonStat.Counter"] = "0"
        bwMonStatRow["BwMonStat.AppName"] = v["BwMonStat.AppName"]
        status = fw.config("BwMonStat", bwMonStatRow, "-1", "add")
        if (not status) then
            return "ERROR", "FW_CONFIG_FAILED"
        end
    end

    status = firewall.bwMonCustomConfig(bwMonCustomConf, "-1", "add")
    if (status == "OK") then
        return "OK", "STATUS_OK" 
    else
        return "ERROR", "FW_CONFIG_FAILED"
    end
    
end

-------------------------------------------------------------------------------
-- @name : firewall.bwMonCustomEditSet()
--
-- @description : This function is used to set the values in DB when a custom
-- bandwidth monitoring is to be edited
--
-- @return : status, errorMsg
--
function firewall.bwMonCustomEditSet(bwMonCustomTbl)
    local query = nil

    if (bwMonCustomTbl["accType"] == "1") then
        bwMonCustomTbl["macAddr"] = ""
        query = "ipAddr='" .. bwMonCustomTbl["ipAddr"] .. "'"
    else
        bwMonCustomTbl["ipAddr"] = ""
        query = "macAddr='" .. bwMonCustomTbl["macAddr"] .. "'"
    end

    if (db.existsRowWhere ("bwMonCustom", query)) then
        return "ERROR", "CUSTOM_ACCOUNT_ALREADY_EXIST"
    end

    return firewall.bwMonCustomConfig(bwMonCustomTbl, bwMonCustomTbl._ROWID_, "edit")
end

-------------------------------------------------------------------------------
-- @name : firewall.bwMonCustomEditGet()
--
-- @description : API to return custom banwidth being edited
--
-- @return : lua table containing previous values of the row
--
function firewall.bwMonCustomEditGet(rowId)
    local configTbl = {}
    configTbl = db.getRow ("BwMonCustom", "_ROWID_", rowId)
    configTbl = util.removePrefix(configTbl, "BwMonCustom.")
    return configTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.bwMonCustomDelete()
--
-- @description : This function is used to delete custom bandwidth rules
--
-- @return : status, errorMsg
--
function firewall.bwMonCustomDelete(inTable)
    local status = false
    local bwMonCustomRow = db.getRowWhere ("BwMonCustom", "_ROWID_ = '" .. inTable["_ROWID_"] .. "'", false)
    if (bwMonCustomRow ~= nil) then
        status = db.deleteRow ("BwMonStat", "AccName", bwMonCustomRow["AccName"])
        if(not status) then
            return "ERROR", "FW_CONFIG_FAILED"
        end
    end
    status = firewall.bwMonCustomConfig(inTable, inTable._ROWID_, "delete")
    if(status) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "FW_CONFIG_FAILED"
    end
end

-------------------------------------------------------------------------------
-- @name : firewall.webAccessConfGet()
--
-- @description : API to return 'WebAccessCtrl' table
--
-- @return : Entire WebAccessCtrl table
-- 
function firewall.webAccessConfGet()
    --local 
    local webAccessCtrlTbl = {}
   
    webAccessCtrlTbl = db.getRow ("WebAccessCtrl", "_ROWID_", "1")   

    webAccessCtrlTbl = util.removePrefix(webAccessCtrlTbl, "WebAccessCtrl.")

    --return
    return "OK", "STATUS_OK" , webAccessCtrlTbl
end

-------------------------------------------------------------------------------
-- @name : firewall.webAccessConfSet()
--
-- @description : API to set 'WebAccessCtrl' configuration
--
-- @return : OK or ERROR
-- 
function firewall.webAccessConfSet(webAccessCtrlTbl)
-- check if the configuration has changed in GUI
    local status, errMsg, currentTbl = firewall.webAccessConfGet()
    if (currentTbl["enable"] == webAccessCtrlTbl["enable"]) then
        return "OK", "STATUS_OK"
    end

    currentTbl["enable"] = webAccessCtrlTbl["enable"]
    -- add table prefix
    currentTbl = util.addPrefix(currentTbl, "WebAccessCtrl.")

    statusFlag = fw.config ("WebAccessCtrl", currentTbl, "1", "edit")
    -- check status
    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "WEBACCESS_CONFIG_FAILED"
    end
end
-------------------------------------------------------------------------------
-- @name : firewall.clientMacConfigGet()
--
-- @description : API to return 'clientMacConfig' table
--
-- @return : Entire macFilterConfig table
-- 
function firewall.clientMacConfigGet()
    return db.getTable ("clientMacConfig", false)
end

-------------------------------------------------------------------------------
-- @name : firewall.clientMacConfigEditGet()
--
-- @description : API to return 'clientMacConfig' table
--
-- @return : Entire macFilterConfig table
-- 
function firewall.clientMacConfigEditGet(rowId)
    return db.getRowWhere ("clientMacConfig", "_ROWID_ = '" .. rowId .. "'", false)
end

-------------------------------------------------------------------------------
-- @name : firewall.clientMacConfigSet()
--
-- @description : API to set values in 'clientMacConfig' table
--
-- @return : status, error code
-- 
function firewall.clientMacConfigSet(clientMacConfigTable, action)

    if(util.fileExists("/tmp/connSuccess")) then
        if (action == "enable") then enStr = "1" else enStr = "0" end
  
        for i, v in pairs(clientMacConfigTable) do
            statusFlag = db.setAttribute("clientMacConfig", "_ROWID_", v, "MACFilteringPolicy", enStr)
        end

        if (statusFlag) then
             return "OK", "STATUS_OK"
        else
            return "ERROR", "MAC filter configuration failed"
        end
    else
    	return "ERROR", "MAC filter configuration failed"
    end
       
end

-------------------------------------------------------------------------------
-- @name : firewall.clientMacConfigEditSet()
--
-- @description : API to edit values in 'clientMacConfig' table
--
-- @return : status, error code
-- 
function firewall.clientMacConfigEditSet(clientMacConfigTable, rowId)

    local inputTable = {}

    inputTable["alias"] = clientMacConfigTable["alias"]
    inputTable["decription"] = clientMacConfigTable["descr"]

    inputTable = util.addPrefix(inputTable, "clientMacConfig.")

    util.appendDebugOut ("Values to be edited: " .. util.tableToStringRec(inputTable) .. "\n")

    if(util.fileExists("/tmp/connSuccess")) then
        statusFlag = fw.config ("clientMacConfig", inputTable, rowId, "edit")
    else
        return "ERROR", "CPE is not connected to ACS"
    end

    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "MAC filter configuration failed"
    end    
end
-------------------------------------------------------------------------------
-- @name : firewall.clientMacConfigDelete()
--
-- @description : This function is used to delete MAC Rule(s)
--
-- @return : status, errorMsg
--
function firewall.clientMacConfigDelete (inTable)
    local statusFlag = true
    local retVal = ""
    local clientMacCfgRow = {}

    if(util.fileExists("/tmp/connSuccess")) then
        if(#inTable > 1) then
            retVal = db.execute ("update clientMacConfig set Deleted=1")
            if(retVal == false) then
                return "ERROR", "MAC_ALL_ROWS_DELETE_FAILED"
            end

            -- wait until all the mac clients are notified to the ACS server
            while(util.fileExists ("/tmp/success") ~= true) do
                os.execute ("usleep 5000")  
            end                         
            os.remove ("/tmp/success")

            -- delete all clientMacConfig rows 
            retVal = db.execute ("delete from clientMacConfig where Deleted=1")
            if(retVal) then
                -- delete all rows from casNotification
                retVal = db.execute ("delete from casNotification")
                if(retVal) then
                    return "OK", "STATUS_OK"
                else
                    return "ERROR", "MAC_ALL_ROWS_DELETE_FAILED"
                end
            else
                return "ERROR", "MAC_ALL_ROWS_DELETE_FAILED"
            end
        elseif(#inTable == 1) then
            clientMacCfgRow = db.getRowWhere ("clientMacConfig", "_ROWID_="..inTable[1], false)
            if (clientMacCfgRow == nil) then        
                return "ERROR", "MAC_ROWS_DELETE_FAILED"
            end
            
            statusFlag = db.setAttribute ("clientMacConfig", "sourceMacAddr", clientMacCfgRow["sourceMacAddr"], "Deleted", "1")
            if(not statusFlag) then
                return "ERROR", "MAC_ROWS_DELETE_FAILED"
            end 
            
            -- wait until the mac client is notified to the ACS server
            while(util.fileExists ("/tmp/success") ~= true) do
                os.execute ("usleep 5000")
            end   
            os.remove ("/tmp/success") 
            
            statusFlag = firewallMAC.config(inTable, nil, "delete")
            
            if(statusFlag) then
                -- delete all rows from casNotification
                retVal = db.execute ("delete from casNotification where sourceMacAddr='"..clientMacCfgRow["sourceMacAddr"].."'")
                if(retVal) then
                    return "OK", "STATUS_OK"
                else
                    return "ERROR", "MAC_ROWS_DELETE_FAILED"
                end
            else
                return "ERROR", "MAC_ROWS_DELETE_FAILED"
            end
        end
    else
        return "ERROR", "MAC_ROWS_DELETE_FAILED"
    end
end

-------------------------------------------------------------------------------
-- @name : firewallv4.config()
--
-- @description : API to perform actual DB add/delete/edit operation on table
-- containing IPv4 firewall rules
--
-- @return : status
-- 
function firewallMAC.config (inputTable, rowid, operation)
    if (operation == "add") then
        return db.insert(MACConfigTbl, inputTable)
    elseif (operation == "edit") then
        return db.update(MACConfigTbl, inputTable, rowid)
    elseif (operation == "delete") then
        return db.delete(MACConfigTbl, inputTable)
    end
    return false
end

-------------------------------------------------------------------------------
-- @name : firewall.fwRulesEnable()
--
-- @description : This function is used to enable an IPv4 Firewall
-- Rule
--
-- @return : status, errorMsg
--
function firewall.clientMacConfigSave (inputTable)
    local statusFlag = true

    -- set status as '1' for all the rules that need to be enabled
    statusFlag = db.setAttribute ("macFilterConfig", "_ROWID_", "1", "MACFilteringStatus", 
                                        inputTable["ClientAccessControlStatus"])

    if(statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_RULES_ENABLED_FAILED"
    end

end

-------------------------------------------------------------------------------
-- @name : firewall.deviceAccessAddGet()
--
-- @description : This function is used get device access details
-- Rule
--
-- @return : status, errorMsg

function firewall.deviceAccessAddGet ()
    local DeviceAccessInfo = {}

    DeviceAccessInfo["Status"] = db.getAttribute("DeviceAccess", "_ROWID_", 1, "Status")
    DeviceAccessInfo["MACAddress"] = db.getAttribute("DeviceAccess", "_ROWID_", 1, "MACAddress")

   return DeviceAccessInfo
end

-------------------------------------------------------------------------------
-- @name : firewall.deviceAccessAddSet()
--
-- @description : This function is used to enable an debugging
-- Rule
--
-- @return : status, errorMsg
--
function firewall.deviceAccessAddSet (inputTable)
    local statusFlag1 = true
    local statusFlag2 = true
    local cmd = ""
    local iptableCmd = "/pfrm2.0/bin/iptables"
    local MacAddress
    local telnelCmd = "/usr/sbin/telnetd"
    local telnelKillCmd = "killall telnetd"


    statusFlag1 = db.setAttribute ("DeviceAccess", "_ROWID_", "1", "Status",inputTable["Status"])
    if (tonumber(inputTable["Status"]) == 1) then
        statusFlag2 = db.setAttribute ("DeviceAccess", "_ROWID_", "1", "MACAddress",inputTable["MACAddress"])
        cmd = iptableCmd .. " -I fwInBypass -m ifgroup --ifgroup-in 0x1/0x1 -m mac --mac-source " .. inputTable["MACAddress"] .. " -j ACCEPT"
        util.runShellCmd(cmd, nil, nil, nil);
        util.runShellCmd(telnelCmd, nil, nil, nil);
    else 
        MacAddress = db.getAttribute("DeviceAccess", "_ROWID_", 1, "MACAddress")
        cmd = iptableCmd .. " -D fwInBypass -m ifgroup --ifgroup-in 0x1/0x1 -m mac --mac-source " .. MacAddress .. " -j ACCEPT"
        util.runShellCmd(cmd, nil, nil, nil);
        util.runShellCmd(telnelKillCmd, nil, nil, nil);
        statusFlag2 = true
    end

    if(statusFlag1 and statusFlag2) then
    	return "OK", "STATUS_OK"
    else
        if (statusFlag1) then
    	    return "ERROR",statusFlag2
        else
            return "ERROR",statusFlag1
        end
    end
end
