/*
 * File: eogre.js
 * Created on 4th Jan 2013 - Bala krishna G
 * Modified on 8th Jan 2013 - Lakshmi
 * Copyright (c) 2012 TeamF1, Inc.
 * All rights reserved.
 */
 deviceSpecificVal =  document.getElementById('tf1_hidden_deviceSpecificCheck').value;
/**
 * This function calls Page loads
 * Onload validation
 * @method onloadCall
 */
jQuery(function(){
  onloadCall (enableEogre, {imageId:'', disableIndividual:'', disableGrp:'', enableIndividual:'', enableGrp:'', hideClass:'hide', showClass:'configRow', breakDivs:'', breakClass:'break', imagesInfo:{disableImages:'', enableImages:'', disableClass:'', enableClass:''}});
  enableTextFieldByImageClick('tf1_enableEogre','tf1_ipv4Address tf1_tunnelKey tf1_modeOfOperation tf1_remoteIp tf1_vlan tf1_dataRate tf1_enableOffloadFallback tf1_secRemoteIp tf1_txtIpv6Address tf1_txtsecIpv6Address','break_ipv4Address break_tunnelKey break_modeOfOperation break_remoteIp break_vlan break_dataRate break_enableOffloadFallback break_secRemoteIp break_txtIpv6Address break_txtsecIpv6Address');
checkModeOfOperation();
if(deviceSpecificVal == "BR"){
modeChange();
}
});

/**
 * Wrapper function called onload
 * @method changeDhcpStatus
 * @param obj
 */
function enableEogre(toggleObj, thisObj){
    onImageToggle(toggleObj);
    var imgId=thisObj.id;   
    switch(imgId){
    	case 'tf1_enableOffloadFallback':  

	     enableTextFieldByImageClick('tf1_enableOffloadFallback','tf1_secRemoteIp','break_secRemoteIp');
if(deviceSpecificVal == "BR"){
showhideOffloadfallback();
}

    	break;
      case 'tf1_enableEogre':  
	     enableTextFieldByImageClick('tf1_enableEogre','tf1_ipv4Address tf1_tunnelKey tf1_modeOfOperation tf1_remoteIp tf1_txtIpv6Address tf1_vlan tf1_dataRate tf1_enableOffloadFallback tf1_secRemoteIp tf1_txtsecIpv6Address','break_ipv4Address break_tunnelKey break_modeOfOperation break_remoteIp break_txtIpv6Address break_vlan break_dataRate break_enableOffloadFallback break_secRemoteIp break_txtsecIpv6Address');
      if(deviceSpecificVal == "BR"){
	modeChange();
      }
    	break;
    }
   
}
function showhideOffloadfallback(){
var addressTypeValue = radioCheckedValueGet('tf1_ipv4Address');
  var modeOperationValue = comboSelectedValueGet('tf1_modeOfOperation');
 var imgSrc = $("#tf1_enableEogre").attr("src");
 var imgSrc1 = $("#tf1_enableOffloadFallback").attr("src");
     if (imgSrc.indexOf("_on") != -1 && imgSrc1.indexOf("_on") != -1) {
	if(addressTypeValue == "0" && modeOperationValue =="1"){
 		fieldStateChangeWr("tf1_txtsecIpv6Address", "", "tf1_secRemoteIp", "");
		vidualDisplay('tf1_txtsecIpv6Address break_txtsecIpv6Address','hide');
		vidualDisplay('tf1_secRemoteIp', 'configRow');
		vidualDisplay('break_secRemoteIp ', 'break');

	}
	else if(addressTypeValue == "1"  && modeOperationValue =="1"){
		fieldStateChangeWr("tf1_secRemoteIp", "", "tf1_txtsecIpv6Address", "");
		vidualDisplay('tf1_secRemoteIp break_secRemoteIp','hide');
		vidualDisplay('tf1_txtsecIpv6Address', 'configRow');
		vidualDisplay('break_txtsecIpv6Address', 'break');
	}
   }
 else{
      if (imgSrc.indexOf("_on") != -1 && imgSrc1.indexOf("_off") != -1) {
	if(addressTypeValue == "0" && modeOperationValue =="1"){
          fieldStateChangeWr("tf1_txtIpv6Address tf1_txtsecIpv6Address", "", "", "");
          vidualDisplay('tf1_txtIpv6Address tf1_txtsecIpv6Address break_txtIpv6Address break_txtsecIpv6Address', 'hide');
	}
	else if(addressTypeValue == "1"  && modeOperationValue =="1"){
 	  fieldStateChangeWr("tf1_txtsecIpv6Address", "", "tf1_txtIpv6Address", "");
          vidualDisplay('tf1_txtIpv6Address', 'configRow');
          vidualDisplay('break_txtIpv6Address', 'break');
 	  vidualDisplay('tf1_txtsecIpv6Address break_txtsecIpv6Address', 'hide');
	}
      }
      else{
          fieldStateChangeWr("tf1_secRemoteIp tf1_txtsecIpv6Address", "", "", "");
          vidualDisplay('tf1_txtIpv6Address tf1_secRemoteIp tf1_txtsecIpv6Address break_secRemoteIp break_txtsecIpv6Address break_txtIpv6Address', 'hide');
     }
 }  
}
/**
 * This function for enable or disable fields while clicking on on off image
 * Onclick event
 * @method enableTextFieldByImageClick
 * @param imgId - image Id
 * @param fieldIds - space separated field names
 * @param brk - space separated break names
 */
function enableTextFieldByImageClick(imgId,fieldIds,brk){	
	var imgObjVal = document.getElementById(imgId).src;    
    var imageName = imgObjVal.substring (imgObjVal.lastIndexOf ('/') + 1);
   	if (imageName == ON_IMAGE) {    	           
   		fieldStateChangeWr ('', '', fieldIds, '');
       	vidualDisplay(fieldIds,'configRow');	   
       	vidualDisplay (brk,'break');
	}else if (imageName == OFF_IMAGE) {   
   		fieldStateChangeWr (fieldIds, '', '', '');
   	    vidualDisplay(fieldIds,'hide');
   	    vidualDisplay (brk,'hide');
    }
}
/* Reset function for form

*/

function eogreOnReset(frmId) {

	resetImgOnOff(frmId);
  enableTextFieldByImageClick('tf1_enableEogre','tf1_ipv4Address tf1_tunnelKey tf1_modeOfOperation tf1_remoteIp tf1_vlan tf1_dataRate tf1_enableOffloadFallback tf1_secRemoteIp tf1_txtIpv6Address tf1_txtsecIpv6Address','break_ipv4Address break_tunnelKey break_modeOfOperation break_remoteIp break_txtIpv6Address break_vlan break_dataRate break_enableOffloadFallback break_secRemoteIp break_txtIpv6Address break_txtsecIpv6Address');
checkModeOfOperation();
  if(deviceSpecificVal == "BR"){
  modeChange();

  }
}
/**
* @method: checkModeOfOperation
* @description: This function is called for changing mode of operation
*/
function checkModeOfOperation(){
  var selValue = comboSelectedValueGet('tf1_modeOfOperation');
  if (!selValue) return;    
  switch (parseInt(selValue, 10)) {
      case 1:
          var imgSrc = $("#tf1_enableEogre").attr("src");
            if (imgSrc.indexOf("_on") != -1) 
            {     	
              enableTextFieldByImageClick('tf1_enableOffloadFallback','tf1_secRemoteIp','break_secRemoteIp');
              vidualDisplay('tf1_enableOffloadFallback', 'configRow');
              vidualDisplay('break_enableOffloadFallback', 'break');
              var imgSrc1 = $("#tf1_enableOffloadFallback").attr("src");
                if (imgSrc1.indexOf("_on") != -1) 
                {
                  fieldStateChangeWr("", "", "tf1_secRemoteIp", "");
                  vidualDisplay('tf1_secRemoteIp', 'configRow');
                  vidualDisplay('break_secRemoteIp', 'break');
                }
            }
      break;
      case 2:
          fieldStateChangeWr("tf1_secRemoteIp tf1_txtsecIpv6Address", "", "", "");
          vidualDisplay('tf1_enableOffloadFallback tf1_secRemoteIp tf1_txtsecIpv6Address', 'hide');
          vidualDisplay('break_enableOffloadFallback break_secRemoteIp break_txtsecIpv6Address', 'hide');
      break;
    }
}
/****
 * validate the form
 * OnClick validation
 * @method remoteMgmtValidation
 */
function eogreValidation(frmId){    
	var txtValidArray = new Array();
    //txtValidArray[0] = "tf1_tunnelKey, Please enter a valid Tunnel Key";
    txtValidArray[txtValidArray.length] = "tf1_remoteIp, Please enter a valid IP Address";
    txtValidArray[txtValidArray.length] = "tf1_txtIpv6Address,Please enter a valid IPv6 Address.";
    txtValidArray[txtValidArray.length] = "tf1_secRemoteIp, Please enter a valid Secondary Remote IP Address";
    txtValidArray[txtValidArray.length] = "tf1_txtsecIpv6Address,Please enter a valid Secondary Remote IPv6 Address.";
    if (txtFieldArrayCheck(txtValidArray) == false) 
        return false;

  if (ipv4Validate('tf1_remoteIp', 'IP', false, true, "Invalid Remote IP address.", "for octet ", true) == false) 
        return false;
  if (ipv4Validate('tf1_secRemoteIp', 'IP', false, true, "Invalid Secondary Remote IP address.", "for octet ", true) == false) 
        return false;
 if(deviceSpecificVal == "BR"){
  if (ipv6Validate('tf1_txtIpv6Address', true, true, '') == false) 
        return false;

  if (ipv6Validate('tf1_txtsecIpv6Address', true, true, '') == false) 
        return false;
}


  var vlanObj = document.getElementById("tf1_vlan");
  if (!vlanObj.disabled && $("#tf1_vlan").val() != ''){
	if (numericValueRangeCheck(vlanObj, "", "", 2, 4094, true, "", "") == false)
	{
	   return false;	
	}
  }
    
   var dataRateObj = document.getElementById("tf1_dataRate");
  if (!dataRateObj.disabled && $("#tf1_dataRate").val() != ''){
	if (numericValueRangeCheck(dataRateObj, "", "", 1, 30720, true, "", "") == false)
	{
	   return false;	
	}
  }

    setHiddenChks (frmId);
   displayProgressBar ();
   return true;
}

/**
 * State Mode Change
 * @method modeChange
 */
function modeChange(){
    var selValue = radioCheckedValueGet('tf1_ipv4Address');
    if (!selValue) 
        return;
    switch (parseInt(selValue, 10)) {
        case 0: /* Stateful */
            fieldStateChangeWr("tf1_txtIpv6Address tf1_txtsecIpv6Address", "", "tf1_remoteIp tf1_secRemoteIp", "");
            vidualDisplay("tf1_txtIpv6Address tf1_txtsecIpv6Address", 'hide');
            vidualDisplay("break_txtIpv6Address break_txtsecIpv6Address", 'hide');
	    vidualDisplay("tf1_remoteIp tf1_secRemoteIp", 'configRow');
            vidualDisplay("break_remoteIp break_secRemoteIp", 'break');

            break;
            
        case 1: /* Stateless */
            fieldStateChangeWr("tf1_remoteIp tf1_secRemoteIp", "", "tf1_txtIpv6Address tf1_txtsecIpv6Address", "");
            vidualDisplay("tf1_txtIpv6Address tf1_txtsecIpv6Address", 'configRow');
            vidualDisplay("break_txtIpv6Address break_txtsecIpv6Address", 'break');
	    vidualDisplay("tf1_remoteIp tf1_secRemoteIp", 'hide');
            vidualDisplay("break_remoteIp break_secRemoteIp", 'hide');
            break;
    }
    checkModeOfOperation();
    if(deviceSpecificVal == "BR"){
	showhideOffloadfallback();
     }

}
