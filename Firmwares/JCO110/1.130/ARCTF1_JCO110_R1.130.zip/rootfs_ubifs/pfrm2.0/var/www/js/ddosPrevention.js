/*
 * File: ddosPrevention.js
 * Created on 12th June 2013 - Bala krishna G
 * Copyright (c) 2012 TeamF1, Inc.
 * All rights reserved.
 */
/****
 * validate the form
 * OnClick validation
 * @method pageValidate
 */
function pageValidate(frmId){
    var txtFieldIdArr = new Array();  
    
    txtFieldIdArr[0] = "tf1_tcpSYNPackets, Please enter valid TCP SYN Packets";
    txtFieldIdArr[1] = "tf1_udpConnectionLimits, Please enter valid UDP Connection Limits";
    txtFieldIdArr[2] = "tf1_cimpPing, Please enter valid Confirm ICMP Ping Requests";
    txtFieldIdArr[3] = "tf1_icmpControl, Please enter valid ICMP Control / Notification Packets";
       
    if (txtFieldArrayCheck(txtFieldIdArr) == false) 
        return false;    
   
    if (isProblemCharArrayCheck(txtFieldIdArr, "'\" ", NOT_SUPPORTED) == false) 
        return false; 
    
     var portObj = document.getElementById("tf1_tcpSYNPackets");
    if (!portObj.disabled) {
        if (numericValueRangeCheck(portObj, "", "", 0, 256, true, "", "") == false) 
            return false;
    }
	
	 var portObj = document.getElementById("tf1_udpConnectionLimits");
    if (!portObj.disabled) {
        if (numericValueRangeCheck(portObj, "", "", 0, 128, true, "", "") == false) 
            return false;
    }
	
	 var portObj = document.getElementById("tf1_cimpPing");
    if (!portObj.disabled) {
        if (numericValueRangeCheck(portObj, "", "", 0, 50, true, "", "") == false) 
            return false;
    }
	
	 var portObj = document.getElementById("tf1_icmpControl");
    if (!portObj.disabled) {
        if (numericValueRangeCheck(portObj, "", "", 0, 50, true, "", "") == false) 
            return false;
    }

    setHiddenChks(frmId); 
    displayProgressBar ();
   return true;
}

/*Added chnages for ---- */

$(document).ready(function(){
	onloadCall (enableDisableFieldsByImageClick, {imageId:'', disableIndividual:'', disableGrp:'', enableIndividual:'', enableGrp:'', hideClass:'hide', showClass:'configRow', breakDivs:'', breakClass:'break', imagesInfo:{disableImages:'', enableImages:'', disableClass:'', enableClass:''}});

enableTextFieldByImageClick('tf1_tcpSYNPacketsEnable','tf1_tcpSYNPackets','');
enableTextFieldByImageClick('tf1_icmpControlEnable','tf1_icmpControl','');	
enableTextFieldByImageClick('tf1_udpConnectionLimitsEnable','tf1_udpConnectionLimits','');
enableTextFieldByImageClick('tf1_cimpPingEnable','tf1_cimpPing','');
});

function dosDDoSOnreset() {
  enableTextFieldByImageClick('tf1_tcpSYNPacketsEnable','tf1_tcpSYNPackets','');
  enableTextFieldByImageClick('tf1_icmpControlEnable','tf1_icmpControl','');	
  enableTextFieldByImageClick('tf1_udpConnectionLimitsEnable','tf1_udpConnectionLimits','');
  enableTextFieldByImageClick('tf1_cimpPingEnable','tf1_cimpPing','');
}

function enableDisableFieldsByImageClick(data, thisObj) { 
    onImageToggle(data);  
	var imgId=thisObj.id;   
    switch(imgId){
    case 'tf1_tcpSYNPacketsEnable':  
			enableTextFieldByImageClick('tf1_tcpSYNPacketsEnable','tf1_tcpSYNPackets','');	
    break;
		case 'tf1_udpConnectionLimitsEnable':  
			enableTextFieldByImageClick('tf1_udpConnectionLimitsEnable','tf1_udpConnectionLimits','');	
    break;  
    case 'tf1_cimpPingEnable':  
      enableTextFieldByImageClick('tf1_cimpPingEnable','tf1_cimpPing','');	
    break;    
    case 'tf1_icmpControlEnable':  
      enableTextFieldByImageClick('tf1_icmpControlEnable','tf1_icmpControl','');
    break;  	
    }
}


/**
 * This function for enable or disable fields while clicking on on off image
 * Onclick event
 * @method enableTextFieldByImageClick
 * @param imgId - image Id
 * @param fieldIds - space separated field names
 * @param brk - space separated break names
 */
function enableTextFieldByImageClick(imgId,fieldIds,brk){	
	
	var imgObjVal = document.getElementById(imgId).src;    
    var imageName = imgObjVal.substring (imgObjVal.lastIndexOf ('/') + 1);
   	if (imageName == ON_IMAGE) {    	           
   		fieldStateChangeWr ('', '', fieldIds, '');
       	vidualDisplay(fieldIds,'configRow');	   
       	vidualDisplay (brk,'break');
	}else if (imageName == OFF_IMAGE) {   
   		fieldStateChangeWr (fieldIds, '', '', '');
   	    vidualDisplay(fieldIds,'hide');
   	    vidualDisplay (brk,'hide');
    }
}
 
