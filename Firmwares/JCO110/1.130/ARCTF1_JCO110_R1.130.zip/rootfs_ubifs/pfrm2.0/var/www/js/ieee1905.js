/*
 * File: eogre.js
 * Created on 4th Jan 2013 - Bala krishna G
 * Modified on 8th Jan 2013 - Lakshmi
 * Copyright (c) 2012 TeamF1, Inc.
 * All rights reserved.
 */

/* Reset function for form

*/

function ieee1905OnReset(frmId) {

	resetImgOnOff(frmId);
	enableTextFieldByImageClick('tf1_enableIEEE1905','tf1_btnStartWps','break_btnStartWps');

}

function enableDisableFieldsByImageClick(data, thisObj) { 
    onImageToggle(data);  
	var imgId=thisObj.id;   
    switch(imgId){
	
    	case 'tf1_enableIEEE1905':  
	      
		 var imgSrc = $("#tf1_enableIEEE1905").attr("src");
			if (imgSrc.indexOf("_on") != -1) 
			{     	

		alert("WPS Enabled AP interface will act as IEEE1905 registrar.");
			}
	enableTextFieldByImageClick('tf1_enableIEEE1905','tf1_btnStartWps','break_btnStartWps');
	wpsStatusGet();

    	break;
    }
} 
 
/**
 * This function for enable or disable fields while clicking on on off image
 * Onclick event
 * @method enableTextFieldByImageClick
 * @param imgId - image Id
 * @param fieldIds - space separated field names
 * @param brk - space separated break names
 */
function enableTextFieldByImageClick(imgId,fieldIds,brk){	
	
	var imgObjVal = document.getElementById(imgId).src;    
    var imageName = imgObjVal.substring (imgObjVal.lastIndexOf ('/') + 1);
   	if (imageName == ON_IMAGE) {    	           
   		fieldStateChangeWr ('', '', fieldIds, '');
       	vidualDisplay(fieldIds,'configRow');	   
       	vidualDisplay (brk,'break');
	}else if (imageName == OFF_IMAGE) {   
   		fieldStateChangeWr (fieldIds, '', '', '');
   	    vidualDisplay(fieldIds,'hide');
   	    vidualDisplay (brk,'hide');
    }
}
function wpsStatusGet() {
  var statusWps = document.getElementById('tf1_hidden_enableWPSStatus').value;
   if(statusWps == 0 ) {
        $("#tf1_btnStartWps").attr("disabled", true);
      } 
}
