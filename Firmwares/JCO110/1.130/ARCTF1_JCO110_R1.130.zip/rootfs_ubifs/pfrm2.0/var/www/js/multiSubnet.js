/*
 * File: ipMode.js
 * Created on 30th July 2014 - Bala krishna G
 * Copyright (c) 2014 TeamF1, Inc.
 * All rights reserved.
 */
/**
 * Form Validation
 * @method wanSetupValidate
 */
function multiSubnetValidation(frmId){
	var multi_subnet_confirm = confirm('An Multi Subnet change will cause the device to reboot, Click OK to continue or Cancel to abort');  
    if(multi_subnet_confirm == false){
        resetImgOnOff(frmId);
		return false;
	 }
    
    displayProgressBar ();
    setHiddenChks(frmId);
   return true;
}


  
