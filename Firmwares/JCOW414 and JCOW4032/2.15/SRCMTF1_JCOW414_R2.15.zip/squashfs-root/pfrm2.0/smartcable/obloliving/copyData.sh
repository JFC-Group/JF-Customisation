#!/bin/sh

OBLO_DIR="/flash/obloliving"
SC_OBLO_DIR="/flash/smartcable/obloliving"
SC_DIR="/flash/smartcable"

if [ $(dirname $0) = '.' ]; then CURRENT_SPATH=$(pwd); else CURRENT_SPATH=$(dirname $0); fi
echo "in copyData"
echo "${CURRENT_SPATH}"


sameFirmware=0
search=$(grep -cw "app.firmware_version" /flash/obloliving/cfg/ohm/ohm.properties)
if [ $search -eq 1 ]; then
 flash_firmware=$(awk '/app.firmware_version/ {print $3}' "${OBLO_DIR}/cfg/ohm/ohm.properties" )
 echo "flashfirmware is ${flash_firmware}"
 pfrm_firmware=$(awk '/app.firmware_version/ {print $3}' "${CURRENT_SPATH}/cfg/ohm/ohm.properties" )
 echo "pfrm_firmware is ${pfrm_firmware}"
 if [ "$flash_firmware" = "$pfrm_firmware" ]; then
  sameFirmware=1
 fi
fi

samecloud=0
search=$(grep -cw "bridge.cloud.addr:" /flash/obloliving/cfg/omb/oblomb.properties)
if [ $search -eq 1 ]; then
 flash_cloud=$(awk '/bridge.cloud.addr:/ {print $2}' "${OBLO_DIR}/cfg/omb/oblomb.properties" )
 echo "flash cloud is ${flash_cloud}"
 pfrm_cloud=$(awk '/bridge.cloud.addr:/ {print $2}' "${CURRENT_SPATH}/cfg/omb/oblomb.properties" )
 echo "pfrm_cloud is ${pfrm_cloud}"
 if [ "$flash_cloud" = "$pfrm_cloud" ]; then
  samecloud=1 
 fi
fi

	
if [ ! -d "$SC_DIR" ]; then
 echo "${SC_DIR} doesnt exist"
 mkdir "$SC_DIR"
else
 echo "${SC_DIR} exist"
fi

if [ ! -d "$SC_OBLO_DIR" ]; then
 echo "${SC_OBLO_DIR} doesnt exist"
 mkdir "$SC_OBLO_DIR"
else
 echo "${SC_OBLO_DIR} exist"
fi
   

if [ -d "$OBLO_DIR" ]; then
 echo "${OBLO_DIR} exist"
 if [ -L "$OBLO_DIR" ]; then
  echo "${OBLO_DIR} is symlink"
 else
  echo "${OBLO_DIR} is a directory"
  exit 1
 fi    
else
 echo "${OBLO_DIR} doesnt exist"
 ln -s "$SC_OBLO_DIR" "$OBLO_DIR"
fi

if [ ! -d "${SC_OBLO_DIR}/tmp" ]; then
 echo "${SC_OBLO_DIR}/tmp doesnt exist"
 mkdir "${SC_OBLO_DIR}/tmp"
else
 echo "${SC_OBLO_DIR}/tmp exist"
fi


if [ ! -d "${SC_OBLO_DIR}/cfg" ]; then
 echo "${SC_OBLO_DIR}/cfg doesnt exist"
 mkdir "${SC_OBLO_DIR}/cfg"
 cp -a "${CURRENT_SPATH}/cfg/." "${SC_OBLO_DIR}/cfg"
else
 echo "${SC_OBLO_DIR}/cfg exist"
 if [ $sameFirmware -eq 0 ]; then
  echo "Overwriting config files"
  rm -rf ${SC_OBLO_DIR}/cfg
  cp -a "${CURRENT_SPATH}/cfg/." "${SC_OBLO_DIR}/cfg"
 fi
# if [ $samecloud -eq 0 ]; then
#  echo "Overwriting config files"
#  rm -rf ${SC_OBLO_DIR}/cfg
#  cp -a "${CURRENT_SPATH}/cfg/." "${SC_OBLO_DIR}/cfg"
# fi
fi
chmod -R 766 ${SC_OBLO_DIR}/cfg

if [ ! -d "${SC_OBLO_DIR}/log" ]; then
 echo "${SC_OBLO_DIR}/log doesnt exist"
 mkdir "${SC_OBLO_DIR}/log"
 cp -a "${CURRENT_SPATH}/log/." "${SC_OBLO_DIR}/log"
else
 echo "${SC_OBLO_DIR}/log exist"
fi
   
   
if [ ! -d "${SC_OBLO_DIR}/data" ]; then
 echo "${SC_OBLO_DIR}/data doesnt exist"
 mkdir "${SC_OBLO_DIR}/data"
 cp -a "${CURRENT_SPATH}/data/." "${SC_OBLO_DIR}/data"
else
 echo "${SC_OBLO_DIR}/data exist"
fi

if [ ! -d "${SC_OBLO_DIR}/ota" ]; then
 echo "${SC_OBLO_DIR}/ota doesnt exist"
 mkdir "${SC_OBLO_DIR}/ota"
else
   echo "${SC_OBLO_DIR}/ota exist"
fi

#if [ ! -d "${SC_OBLO_DIR}/bin" ]; then
# echo "${SC_OBLO_DIR}/bin doesnt exist"
# mkdir "${SC_OBLO_DIR}/bin"
# ln -s "${CURRENT_SPATH}/bin/update_cfg.sh" "${SC_OBLO_DIR}/bin/update_cfg.sh"
#else
# echo "${SC_OBLO_DIR}/bin exist"
#fi
   
      
   
#cp -a cfg/. "${SC_OBLO_DIR}/cfg"
#cp -a log/. "${SC_OBLO_DIR}/log"
#cp -a data/. "${SC_OBLO_DIR}/data"

#if [ -d "${OBLO_DIR}/OBLO_LIBS" ]; then
# echo "${OBLO_DIR}/OBLO_LIBS exist"
# if [ -L "${OBLO_DIR}/OBLO_LIBS" ]; then
#  echo "${OBLO_DIR}/OBLO_LIBS is symlink"
# else
#  echo "${OBLO_DIR}/OBLO_LIBS is a directory"
# fi
#else
# ln -s "${CURRENT_SPATH}/OBLO_LIBS" "${SC_OBLO_DIR}/OBLO_LIBS"
#fi
        
if [ -L "${SC_OBLO_DIR}/boardid" ]; then
 echo "${SC_OBLO_DIR}/boardid is symlink"
else
 ln -s "${CURRENT_SPATH}/boardid" ${SC_OBLO_DIR}/boardid
fi
