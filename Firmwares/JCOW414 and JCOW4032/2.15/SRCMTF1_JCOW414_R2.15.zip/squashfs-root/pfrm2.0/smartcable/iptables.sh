#!/bin/sh

iptables -A INPUT -m state --state NEW -p tcp --dport 1883 -j ACCEPT ; iptables -A INPUT -m state --state NEW -p tcp --dport 8002 -j ACCEPT ; 
iptables -A INPUT -m state --state NEW -p tcp --dport 8003 -j ACCEPT ; iptables -A INPUT -m state --state NEW -p tcp --dport 8883 -j ACCEPT ; 
iptables -A INPUT -m state --state NEW -p tcp --dport 8884 -j ACCEPT ; iptables -A INPUT -m state --state NEW -p udp --dport 1900 -j ACCEPT ;
iptables -A INPUT -m state --state NEW -p udp --dport 3702 -j ACCEPT ; iptables -A INPUT -m state --state NEW -p udp --dport 32768:61000 -j ACCEPT ; iptables -A INPUT -m state --state NEW -p tcp --dport 31100:31300 -j ACCEPT;
