-- nasNAS.lua -  NAS related routines

-- Copyright (c) 2010, TeamF1, Inc.

-- modification history
-- --------------------
-- 01a,31mar10,pnm  written.

-- ********************** Requires ********************
require "teamf1lualib/nas"

--*****************************************************************************
--nas.exportProtoInfo - exports the nas share protocol related info.
--
--This routine exports the protocol related info, given the nasShare info.
--
--RETURNS: table with info info
function nas.exportProtoInfo (nasShareTbl)
    -- local declarations
    local where = nil

    -- iterate through the table and create where string
    for i,v in ipairs (nasShareTbl) do
        if (where == nil) then
            where = "shareId='"..v["name"].."'"
        else
            where = where.."OR shareId='"..v["name"].."'"
        end
    end

    -- execute the query and return results
    if (where ~= nil) then
        return db.getRowsWhere ("nasShareProtocol", where, false)
    else
        return nil
    end
end

--*****************************************************************************
--nas.exportProcessCompsTable - processes the components table list
--
--This routine iterates through the process components list and export each of
--the register table info.
--
--RETURNS: true or false
function nas.exportProcessCompsTable (nasShareTbl, file)
    -- import required libraries
    require "teamf1lualib/config_NAScomps"

    -- Iterate through the component table
    print (util.tableToStringRec (partitionMgmt["components"], 1))
    for i,v in ipairs (partitionMgmt["components"]) do
        if (v["export"] ~= nil) then
            compConfig = v["export"] (nasShareTbl)
            if (compConfig ~= nil) then
                db.saveTable(file, "config." .. v.compName, compConfig, false,
                1, 1)
            end
        end
    end
end

--*****************************************************************************
--nas.shareConfigExport - exports nas share related info.
--
--This routine will check the number of components register with it. It then
--pulls information from all of those components and return a big table to the
--calling function.
--
--RETURN: table with share related info
function nas.shareConfigExport (partId, file)
    -- Get list of shares that are part of the given partition ID
    local where = "partitionId='" .. partId .. "'"
    local nasShareTbl = {}
    nasShareTbl["shares"] = db.getRowsWhere ("nasShare", where, false)
    
    -- Check if there any shares to export
    if (nasShareTbl["shares"] ~= nil) then

        -- Export the comp list shares
        nas.exportProcessCompsTable (nasShareTbl["shares"], file)

        -- Get the share and protocol mapping table
        nasShareTbl["shareProtocol"] = nas.exportProtoInfo (nasShareTbl["shares"])
    end
    db.saveTable(file, "config.nas", nasShareTbl, false, 1, 1)

    return true
end

--*****************************************************************************
--nas.shareImport - imports nas shares
--
--This routine imports nas shares
--
--RETURNS: nothing
function  nas.shareImport (configTable, partId)
    local valid
    DBTable = "nasShare"
    for i,v in ipairs (configTable["shares"]) do
        -- Need to replace the partition ID
        v["partitionId"] = partId
        
        -- Covert from form <comp name><column name> to <["tableName.column"]
        v = util.addPrefix (v, "nasShare.");
        util.appendDebugOut (util.tableToString (v))

        -- Add Data into the DB
        valid, message = nas.config (v, "-1", "add")
        if (not valid) then
            return valid, message
        end
    end
    if (configTable["shareProtocol"] ~= nil) then
        DBTable = "nasShareProtocol"
        for i,v in ipairs (configTable["shareProtocol"]) do
            -- Covert from form <comp name><column name> to
            -- <["tableName.column"]
            v = util.addPrefix (v, "nasShareProtocol.");
            util.appendDebugOut (util.tableToString (v))

            -- Add the data into the DB
            valid, message = nas.config (v, "-1", "add")
            if (not valid) then
                return valid, message
            end
        end
    end
end

--*****************************************************************************
--nas.deleteProcessCompsTable - processes the components table list
--
--This routine iterates through the process components list and export each of
--the register table info.
--
--RETURNS: true or false
function nas.deleteProcessCompsTable (nasShareTbl)
    -- import required libraries
    require "teamf1lualib/config_NAScomps"

    -- Iterate through the component table
    for i,v in ipairs (partitionMgmt["components"]) do
        if (v["delete"] ~= nil) then
            v["delete"] (nasShareTbl)
        end
    end
end
--*****************************************************************************
--nas.deleteProtoInfo - deletes the nas share protocol related info.
--
--This routine deletes the protocol related info, given the nasShare info.
--
--RETURNS: table with info info
function nas.deleteProtoInfo (nasShareTbl)
    -- local declarations
    local where = nil

    -- iterate through the table and create where string
    for i,v in ipairs (nasShareTbl) do
        if (where == nil) then
            where = "shareId='"..v["name"].."'"
        else
            where = where.."OR shareId='"..v["name"].."'"
        end
    end

    -- execute the query and return results
    if (where ~= nil) then
        local tbl = db.getRowsWhere ("nasShareProtocol", where, false)
        if (tbl ~= nil) then
            for i,v in ipairs (tbl) do
                where = "shareId='" .. v["shareId"] .. "'AND protocol='" ..
                v["protocol"] .. "'"
                db.deleteRowWhere ("nasShareProtocol", where)
            end
        end
    else
        return nil
    end
end

--*****************************************************************************
--nas.shareConfigDelete - deletes nas share related info.
--
--This routine will check the number of components register with it. It then
--deletes all the information from each of the components and deletes matching
--data.
--
--RETURN: table with share related info
function nas.shareConfigDelete (partId)
    -- Get list of shares that are part of the given partition ID
    local where = "partitionId='" .. partId .. "'"
    local nasShareTbl = db.getRowsWhere ("nasShare", where, false)
    
    -- Check if there any shares to be deleted
    if (nasShareTbl ~= nil) then

        -- Delete the shares from each of the component
        nas.deleteProcessCompsTable (nasShareTbl)

        -- Get the share and protocol mapping table
        nas.deleteProtoInfo (nasShareTbl)
    end

    -- Iterate through the share list and delete one share at a time.
    for i,v in ipairs (nasShareTbl) do
        db.deleteRow ("nasShare", "_ROWID_", v["_ROWID_"])
    end

    return true
end


if (partitionMgmt.shareConfigRegister) then
    partitionMgmt.shareConfigRegister ("nas", nas.shareImport, nil, nil)
end

