--[[ easyMeshLogin.lua - Handler for Easy Mesh Login Request Method.
--
-- Copyright (c) 2008-2014, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: easyMeshLogin.lua
-- Description: Handler for Easy Mesh Login Request Method.
-- 
-- modification history
-- --------------------
-- 01a, 03Dec19, ar written.
--
--]]

require "easyMeshLib"
require "teamf1lualib/db"
require "timeLib"

local COOKIE_LENGTH         = 10

-- LoginRequest Object as defined by Customer Specification.
local LoginRequestObj = {
    ["Login"]          = "Login",
}

-- List of LoginResponse Tags as defined by Customer Specification.
local LoginResObj = {
    "DeviceState",
    "uid",
    "Result",
    "Response_Code"
}

-- Initialise the LoginRespose_t Lua Table which will be coverted as JSON Object
local LoginRespose_t = {
    ["DeviceState"] = "N/A",
    ["uid"] = "N/A",
    ["Result"] = "ERROR",
    ["Response_Code"] = "401",
    ["Error_Message"] = "Login Failed"
}

-- Supported Return Codes for "LoginResponse"
local LoginResponse_ReturnCodes = {
    ["OK"] = "OK",
    ["ERROR"] = "ERROR",
    ["SUCCESS"] = "Success",
    ["FAILED"]  = "Failed",
}

-- path for cookie and referer Ip Address
local REFERER_PATH = "/tmp/referer/"
local REMOVE = os.remove
----------------------------------------------------------
--@name delete Existing UserSession 


function CheckExistingUserSession (loginUserNameStr)

    local userType = db.getAttribute("users", "username",loginUserNameStr , "groupname") or ''
	for k,v in pairs(db.getTable("loginSession")) do
		if ((v["loginSession.username"] == loginUserNameStr) and (v["loginSession.loginState"] == "LOGGED_IN") and (userType == "admin")) then
            local userInfo = db.getRow ("users", "username", v["loginSession.username"])
            if(userInfo == nil) then
                userInfo["users.loginTimeout"] = 30            
            end
            local status,upTime = timeLib.uptime()
		    if(tonumber(v["loginSession.lastAccessTime"]) < (upTime - tonumber(userInfo["users.loginTimeout"]) * 60)) then
                local wherePart = "username = '" .. loginUserNameStr .. "' AND cookie = '" .. v["loginSession.cookie"] .. "'"
                -- delete session
                local errMsg, status = db.deleteRowWhere("loginSession", wherePart)
                -- if the cookieVal is found in db then only delete the mapping
                if (errMsg == 1) then
                    -- remove the mapping
                    REMOVE(REFERER_PATH .. v["loginSession.cookie"])
                    return OK
                end
            end
    
            return "ERROR"
        end
    end
    
    return OK

     -- check user's existing Web Session, if any.
    --[[local query = "username='" .. loginUserNameStr .. "'"
    local usrSessionRow =  db.getRowWhere ("loginSession", query, true)
    if (usrSessionRow ~= nil) then
        return "ERROR"
    else
        return "OK"
    end]]--

end

----------------------------------------------------------------------------------
-- @name easyMeshUserInfoGet
--
-- @description This function gets userinformation from system database for the
-- given username.
--
-- @return OK, userinfo (on Success)
--         ERROR, nil (on Failure)
--
function easyMeshUserInfoGet(easyMeshUsername)

    local query = "username='" .. easyMeshUsername .. "'"
    local usrRow =  db.getRowWhere ("users", query, true)
    if (usrRow == nil) then
        mesh.dprintf("User does not Exists")
        return "ERROR", usrRow
    end
    
   return "OK", usrRow 
end


----------------------------------------------------------------------------------
-- @name loginHandler
--
-- @description This function Handles EasyMesh Login Request Methods.
--
-- @return JSON responses to EasyMesh Login requests
--
function loginHandler(methodObj, meshRequestMethod)

    local uniqueVal = nil
    local loginUserNameStr    = methodObj["Admin_Name"]
    local loginPasswordStr    = methodObj["Admin_Password"]
    local loginUserName = nil
    local loginPassword = nil
   
    if ((loginUserNameStr == nil) or (loginPasswordStr == nil)) then
        LoginRespose_t["DeviceState"]   = nil
        LoginRespose_t["uid"]           = nil
        LoginRespose_t["Result"]        = LoginResponse_ReturnCodes["FAILED"]
        LoginRespose_t["Response_Code"] = "400"
        LoginRespose_t["Error_Message"] = "Bad Request"
        --mesh.sendResponse (LoginRespose_t) 
        return "ERROR", "INVALID_METHOD", LoginRespose_t
    end

    mesh.dprintf("loginUserNameStr: " .. loginUserNameStr)
    mesh.dprintf("loginPasswordStr: " .. loginPasswordStr)

    loginUserName = db.escape(loginUserNameStr)
    loginPassword = loginPasswordStr

    -- Validate EASY MESH User with System user database.
    -- EasyMesh user should be a system user also.
    status, userInfo = easyMeshUserInfoGet(loginUserName)
    if (status ~= "OK") then
        LoginRespose_t["DeviceState"]   = nil
        LoginRespose_t["uid"]           = nil
        LoginRespose_t["Result"]        = LoginResponse_ReturnCodes["FAILED"]
        LoginRespose_t["Response_Code"] = "401"
        LoginRespose_t["Error_Message"] = "Unauthorized"
        mesh.dprintf("Invalid User")
        --mesh.sendResponse (LoginRespose_t) 
        return "ERROR", "INVALID_LOGIN_CREDENTIALS", LoginRespose_t
    end

    if (loginPassword ~= userInfo["users.password"]) then
        LoginRespose_t["DeviceState"]   = nil
        LoginRespose_t["uid"]           = nil
        LoginRespose_t["Result"]        = LoginResponse_ReturnCodes["FAILED"]
        LoginRespose_t["Response_Code"] = "401"
        LoginRespose_t["Error_Message"] = "Unauthorized"
        mesh.dprintf("Password Not Matched")
        --mesh.sendResponse (LoginRespose_t) 
        return "ERROR", "INVALID_LOGIN_CREDENTIALS", LoginRespose_t
    end

    if (CheckExistingUserSession(loginUserName) == "ERROR") then
        LoginRespose_t["DeviceState"]   = nil
        LoginRespose_t["uid"]           = nil
        LoginRespose_t["Result"]        = "Conflict"
        LoginRespose_t["Response_Code"] = "409"
        LoginRespose_t["Error_Message"] = "An Active Session already exists for the User"
        --mesh.sendResponse (LoginRespose_t) 
        return "ERROR", "ACTIVE_SESSION_EXISTS_FOR_USER", LoginRespose_t
    end



    local loginGroupName = userInfo["users.groupname"] 

    -- generate cookie
    uniqueVal = easyMeshLib.getRandom(COOKIE_LENGTH)
    mesh.dprintf("Unique Cookie: " .. uniqueVal)
    
    LoginRespose_t["uid"] = uniqueVal

    -- Send Login Request details for easyMesh store.
    status=easyMeshLib.SessionExists( 
                            loginUserName, 
                            loginGroupName
                          )
    if(status == 2) then
        LoginRespose_t["DeviceState"]   = nil
        LoginRespose_t["uid"]           = nil
        LoginRespose_t["Result"]        = "Conflict"
        LoginRespose_t["Response_Code"] = "409"
        LoginRespose_t["Error_Message"] = "An Active Session already exists for the User"
        --mesh.sendResponse (LoginRespose_t) 
        return "ERROR", "ACTIVE_SESSION_EXISTS_FOR_USER", LoginRespose_t
    end
    easyMeshLib.LoginReqUpdate( 
                            loginUserName, 
                            LoginRespose_t["uid"],
                            loginPassword, 
                            loginGroupName
                          )

    if (util.fileExists ("/flash/FcDef")) then
        LoginRespose_t["DeviceState"] = "1"
    else
        LoginRespose_t["DeviceState"] = "0"
    end
    
    LoginRespose_t["Result"] = LoginResponse_ReturnCodes["OK"]
    LoginRespose_t["Response_Code"] = "200"
    LoginRespose_t["Error_Message"] = nil

    --mesh.sendResponse (LoginRespose_t) 
    
    return "OK", "SUCCESS", LoginRespose_t
end

meshRequestMethodsList["Login"]["methodHandler"] = loginHandler
