--[[
#### Abhinendra Babu. T
#### TeamF1
#### www.TeamF1.com
#### June 18, 2008
#### File: radvd.lua
#### Description: RADVD Functions
### Revisions:
]]--

-- Copyright (c) 2017, TeamF1 Networks Pvt. Ltd. 
-- [Subsidiary of D-Link (India) Ltd] 

radvd = {}
radvd.debug = 0

require "teamf1lualib/radvdPrefix"

-------------------------------------------------------------------------
-- @name radvd.restart
--
-- @description 
--
-- @return 
--

function radvd.restart()
    require "teamf1lualib/service"
    local instanceId = "1"

    service.restart("radvd", instanceId)
end

-------------------------------------------------------------------------
-- @name radvd.config
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function radvd.config (inputTable, rowid, operation)
    -- validate
    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
            return db.insert("radvd", inputTable)
        elseif (operation == "edit") then
            return db.update("radvd", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("radvd", inputTable)
        end
    end
    return false
end

-------------------------------------------------------------------------
-- @name radvd.profileConfig
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function radvd.profileConfig (inputTable, rowid, operation)
    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    db.beginTransaction() --begin transaction
    local valid = false
    
    valid = radvd.config(inputTable, rowid, operation)
       	
    -- return
    if (valid) then
    	db.commitTransaction(true)
    	return "OK", "STATUS_OK"
    else
    	db.rollback()
	return "ERROR", "RADVD_CONFIG_FAILED"    	
    end
end

-------------------------------------------------------------------------
-- @name radvd.import
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function radvd.import(radvdConfig, defaultCfg, removeCfg)
    
    if (radvdConfig == nil) then
        return
    end
            
    if (radvdConfig == nil) then
        radvdConfig = defaultCfg 
    end
    
    local confTbl = {}
    confTbl = config.update (radvdConfig.conf, defaultCfg.conf, removeCfg.conf)

    local pfxTbl = {}
    pfxTbl = config.update (radvdConfig.pfxTbl, defaultCfg.pfxTbl, removeCfg.pfxTbl)

	local   configMergeDone = "0"
    local singleApSupport = "0"
    singleApSupport = db.getAttribute ("environment", "name", "SINGLE_AP_SUPPORT" ,"value")

    

    if (confTbl ~= nil and #confTbl ~= 0) then
        for i,v in ipairs (confTbl) do
            v = util.addPrefix (v, "radvd.");
            -- RJIL doesnt needs radvd enabled by default anymore
            --v["radvd.isEnabled"] = "1"
			if(util.fileExists("/flash/configMerge/radvdEnabled2") == false) then
				v["radvd.isEnabled"] = "1"
				configMergeDone = "1"
			end 
            if (singleApSupport ~= nil and singleApSupport == "1") then
                if (v["radvd.LogicalIfName"] ~= "IF4" and v["radvd.LogicalIfName"] ~= "IF5") then
                    radvd.profileConfig (v, -1, "add")
                end
            else
                if (v["radvd.LogicalIfName"] ~= "IF4" and v["radvd.LogicalIfName"] ~= "IF5" and v["radvd.LogicalIfName"] ~= "IF6" and v["radvd.LogicalIfName"] ~= "IF7" ) then
                    radvd.profileConfig (v, -1, "add")
                end
            end
        end
		if (configMergeDone == "1") then
			local radvdEnabled = io.open("/flash/configMerge/radvdEnabled2", "w")                                                          
            if(radvdEnabled ~= nil) then                                                                       
            	radvdEnabled:close()                                                                           
            end
			-- touch saveDB flag to do a DB export to flash after import is complete
			local saveDBFile  = io.open("/tmp/callDbSave", "w")                                                          
            if(saveDBFile ~= nil) then                                                                       
            	saveDBFile:close()                                                                           
           	end	
		end
    end

    -- As per RJIL requirement RADVD should not advertise default prefix fd00::
    if (pfxTbl ~= nil and #pfxTbl ~= 0) then
        for i,v in ipairs (pfxTbl) do
            v = util.addPrefix (v, "radvdLANPrefixPool.");
            if (v["radvdLANPrefixPool.radvdAdvPrefix"] ~= "fd00::" and (tonumber (v["radvdLANPrefixPool.radvdAdvPrefixLifetime"]) ~= 0 )) then
                radvdPrefix.profileConfig (v, -1, "add")
	    end
        end
    end
end

-------------------------------------------------------------------------
-- @name radvd.export
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function radvd.export(radvdConfig)
	local radvdTbl = {}

	radvdTbl["conf"] = db.getTable("radvd" , false)
	radvdTbl["pfxTbl"] = db.getTable("radvdLANPrefixPool" , false)

	return radvdTbl
end

-------------------------------------------------------------------------
-- @name radvd.delete
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function radvd.delete (IDList)

    if (IDList == nil) then
        radvd.dprintf("radvd.delete: invalid arguments")        
        return "ERROR", "RADVD_INVALID_ARG"
    end
            
    local valid, errstr = db.delete ("radvd", IDList)
    if (not valid) then
        radvd.dprintf("radvd.delete: " ..
                      "failed to delete bindings from db. Err:" .. errstr)
        radvd.dprintf("IDList: " .. util.tableToStringRec(IDList))
        return "ERROR","RADVD_DB_ERR"
    end        

    -- restart radvd
    radvd.restart()

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name radvd.validate
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function radvd.validate(conf)
    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------
-- @name radvd.cfgInit
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function radvd.cfgInit(row, conf)

    if (conf["isEnabled"] ~= nil) then
        row["isEnabled"] = conf["isEnabled"]
    end

    if (conf["UnicastOnly"] ~= nil) then
        row["UnicastOnly"] = conf["UnicastOnly"]
    end
                    
    if (conf["useDHCP6sPrefixes"] ~= nil) then
        row["useDHCP6sPrefixes"] = conf["useDHCP6sPrefixes"]
    end
                                
    if (conf["MaxRtrAdvInterval"] ~= nil) then
        row["MaxRtrAdvInterval"] = conf["MaxRtrAdvInterval"]
    end
                                            
    if (conf["MinRtrAdvInterval"] ~= nil) then
        row["MinRtrAdvInterval"] = conf["MinRtrAdvInterval"]
    end

    if (conf["AdvReachableTime"] ~= nil) then
        row["AdvReachableTime"] = conf["AdvReachableTime"]
    end

    if (conf["AdvRetransTimer"] ~= nil) then
        row["AdvRetransTimer"] = conf["AdvRetransTimer"]
    end

    if (conf["AdvCurHopLimit"] ~= nil) then
        row["AdvCurHopLimit"] = conf["AdvCurHopLimit"]
    end

    if (conf["AdvMobileAgentFlag"] ~= nil) then
        row["AdvMobileAgentFlag"] = conf["AdvMobileAgentFlag"]
    end

    if (conf["AdvLinkMTU"] ~= nil) then
        row["AdvLinkMTU"] = conf["AdvLinkMTU"]
    end
                                                        
    if (conf["AdvManagedFlag"] ~= nil) then                                                        
        row["AdvManagedFlag"] = conf["AdvManagedFlag"]
    end
        
    if (conf["AdvOtherConfigFlag"] ~= nil) then        
        row["AdvOtherConfigFlag"] = conf["AdvOtherConfigFlag"]
    end    

    if (conf["AdvDefaultLifetime"] ~= nil) then
        row["AdvDefaultLifetime"] = conf["AdvDefaultLifetime"]
    end
            
    if (conf["AdvDefaultPreference"] ~= nil) then
        row["AdvDefaultPreference"] = conf["AdvDefaultPreference"]
    end                        

    if (conf["LogicalIfName"] ~= nil) then
        row["LogicalIfName"] = conf["LogicalIfName"]
    end

    return row
end

-------------------------------------------------------------------------
-- @name radvd.defCfgGet
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function radvd.defCfgGet()
    local row = {}

    row["isEnabled"] = "0"
    row["UnicastOnly"] = "0"
    row["useDHCP6sPrefixes"] = "0"
    row["MaxRtrAdvInterval"] = "30"
    row["MinRtrAdvInterval"] = "10"
    row["AdvReachableTime"] = "0"
    row["AdvRetransTimer"] = "0"
    row["AdvCurHopLimit"] = "64"
    row["AdvMobileAgentFlag"] = "0"
    row["AdvLinkMTU"] = "1500"
    row["AdvManagedFlag"] = "0"
    row["AdvOtherConfigFlag"] = "1"
    row["AdvDefaultLifetime"] = "3600"
    row["AdvDefaultPreference"] = "1"
    row["LogicalIfName"] = ""

    return row
end

-------------------------------------------------------------------------
-- @name radvd.configure
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function radvd.configure(conf)

    --locals
    local radvdTbl = {}

    if (conf == nil) then
        return "ERROR", "RADVD_INVALID_PARAM"        
    end
                    
    if (conf["LogicalIfName"] == nil) then
        return "ERROR", "RADVD_INVALID_PARAM"        
    end        

    -- configure radvd
    local radvdTbl = db.getTable ("radvd", false)
    if (radvdTbl ~= nil and #radvdTbl > 0) then
        for k, v in pairs (radvdTbl) do
            -- GUI Configrations needs to be apply for default LAN (IF2) only.
            if (v["LogicalIfName"] == conf["LogicalIfName"])then
                v = radvd.cfgInit(v, conf)
                if (v["AdvLinkMTU"] == "0") then
                return "ERROR","MTU: Please enter a value between 1280 - 1500"
                end
                if (v["AdvDefaultLifetime"] == "0") then                        
                return "ERROR","Router Lifetime: Please enter a value between 30 - 9000"    
                end
            else
                -- rest of interfaces (otherthan default LAN) only radvd enable/disable is required.
                v["isEnabled"] = conf["isEnabled"]
            end
            v = util.addPrefix(v, "radvd.")
            local valid, errstr = db.update("radvd", v, v["radvd._ROWID_"])
            if (not valid) then
                radvd.dprintf("radvd.configure: failed to update RADVD configuration")
                return "ERROR", "RADVD_UPDATE_FAILED"
            end            
        end
    else        
        row = radvd.defCfgGet()
        row = radvd.cfgInit(row, conf)

        row = util.addPrefix(row, "radvd.")
        local valid, errstr, rowid  = db.insert("radvd", row)
        if (not valid) then
            radvd.dprintf("radvd.configure: failed to add RADVD configuration")
            return "ERROR", "RADVD_ADD_FAILED"
        end            
    end        

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name radvd.dprintf
--
-- @descrription 
--
-- @return 
--

function radvd.dprintf (str)

    if (str == nil) then
        return
    end

    if (radvd.debug == 0) then
        return
    end        

    print("radvd: "  .. str)

    return 
end

-------------------------------------------------------------------------
-- @name radvd.get
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function radvd.get (query)
    local rows = {}
    local index = 1
    local cfgTbl = {}

    if (query ~= nil) then
        rows = db.getRowsWhere("radvd", query, false)
    else
        rows = db.getTable("radvd", false)
    end        
    
    if (rows ~= nil) then
        for k,v in pairs(rows) do
            cfgTbl[index] = {}                
            cfgTbl[index] = v
            index = index + 1
        end            
    end

    return "OK","STATUS_OK", cfgTbl
end

if (config.register) then
   config.register("radvd", radvd.import, radvd.export, "1")
end
