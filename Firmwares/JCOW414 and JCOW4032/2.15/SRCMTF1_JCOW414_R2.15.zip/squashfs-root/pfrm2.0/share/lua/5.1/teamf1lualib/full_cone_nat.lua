--************* Requires *************

--************* Initial Code *********

--************* Defines **************

--************* Packages *************
full_cone_nat = {}

--************* Functions *************

function full_cone_nat.config (inputTable, rowId, operation)
    if (operation == "add") then
            return db.insert("FullConeNat", inputTable)
        elseif (operation == "edit") then
            return db.update("FullConeNat", inputTable, rowId)
        elseif (operation == "delete") then
            return db.delete("FullConeNat", inputTable)
        end
    return false
end

-- check whether the ipaddress provided is within the network range or not
function validateIpAddress (inputTable)

    -- require
    require "fwPortTriggerLuaLib"

    if (inputTable ["FullConeNat.localNetworkName"] ~= nil) then
        local logicalIfName = db.getAttribute ("networkInterface", "networkName", inputTable ["FullConeNat.localNetworkName"], "LogicalIfName")
        if (logicalIfName ~= nil) then
            local whereClause = "LogicalIfName = '" .. logicalIfName .. "' AND AddressFamily = '2'"
			local rows = db.getRowsWhere("ifStatic", whereClause)
			if (rows and #rows == 1) then
                for l,m in pairs(rows) do
                    staticIp = m["ifStatic.StaticIp"]
                    netMask  = m["ifStatic.NetMask"]
                    statusFlag = fwPortTriggerLuaLib.getNetwork (staticIp, netMask, inputTable ["FullConeNat.LanServerIp"])
                    if (statusFlag == 1) then
                        return "OK"
                    end
                end
            end    
        end            
    end

    return "ERROR"
end    
        

function full_cone_nat.delete (inputTable)
    return full_cone_nat.config(inputTable, inputTable ["FullConeNat._ROWID_"], "delete")
end

function full_cone_nat.add (inputTable)
    db.beginTransaction() --begin transaction
    
    -- check whether the ipaddress provided is within the network range or not
    if (inputTable ["FullConeNat.addressType"] == "1") then
        status = validateIpAddress (inputTable)
        if (status == "ERROR") then
            db.rollback ()
            return "ERROR", "FULL_CONE_IP_NOT_IN_CONFIGURED_RANGE"
        end
    end    


    status = full_cone_nat.config (inputTable, "-1", "add")

    if (status) then
       db.commitTransaction ()
       return "OK", "STATUS_OK"
   else
       db.rollback ()
       return "ERROR", "FULL_CONE_NAT_ADD_FAILED"
   end
end

function full_cone_nat.editGet (rowid)

    local DBRow = {}
    local page = {}

    util.appendDebugOut ("ROWID = " .. rowid)
    DBrow = db.getRow ("FullConeNat", "_ROWID_", rowid)

    local page = {}
    local networks1 = {}
    local nwTable = db.getTable("networkInterface", false)
    if (page == nil) then
        return page
    end
    for k, v in pairs (nwTable) do
        if (v.zoneType == "secure") then
            networks1[k] = {}
            networks1[k]["networkname"] = v.networkName
        end
    end
    
    page.networks = networks1 
    page.lanNetworkName = DBrow ["FullConeNat.localNetworkName"]
    page.addressType = DBrow ["FullConeNat.addressType"]
    page.LanServerIp = DBrow ["FullConeNat.LanServerIp"]
    page.LanServerMac = DBrow ["FullConeNat.LanServerMac"]
    return page
end

function full_cone_nat.editSet (page, rowid)

    local inputTable = {}
    local status
    db.beginTransaction() --begin transaction
   -- page = util.addPrefix(page, "FullConeNat.")
   util.appendDebugOut("editSet: " .. util.tableToStringRec(page) .. " rowId = ".. rowid) 
  -- return "OK", ""
  inputTable ["localNetworkName"] = page.lanNetworkName
  inputTable ["addressType"] = page.addressType
  inputTable ["LanServerIp"] = page.LanServerIp
  
  if (page["LanServerMac"] ~= nil) then 
     require "ifDevLib"
     if (ifDevLib.isMulticastEtherAddr(page["LanServerMac"]) or
         ifDevLib.isBroadcastEtherAddr(page["LanServerMac"])) then
         return "ERROR","INVALID_ACL_MAC"
     else
         inputTable["LanServerMac"] = page["LanServerMac"]
     end
  end

   util.appendDebugOut("editSet2: " .. util.tableToStringRec(inputTable) .. " rowId = ".. rowid) 
  inputTable = util.addPrefix (inputTable, "FullConeNat.")
  -- status = db.update("FullConeNat", inputTable, "1")
  
  -- check whether the ipaddress provided is within the network range or not
  if (inputTable ["FullConeNat.addressType"] == "1") then
      status = validateIpAddress (inputTable)
      if (status == "ERROR") then
          db.rollback ()
          return "ERROR", "FULL_CONE_IP_NOT_IN_CONFIGURED_RANGE"
      end
  end  

   status = full_cone_nat.config (inputTable, rowid , "edit") 

   if (status) then
       db.commitTransaction ()
       return "OK", "STATUS_OK"
   else
       db.rollback ()
       return "ERROR", "FULL_CONE_NAT_EDIT_FAILED"
   end
end
