--[[
#### Copyright (c) 2017, TeamF1 Networks Pvt. Ltd. 
#### (Subsidiary of D-Link India)

#### 
#### File: tr181_dhcpv6TrExtn.lua
#### Description: 
#### TR-181 functions for Device.DHCPv6.Server.Pool.{i}. and 
#### Device.IP.Interface.{i}.IPv6Prefix.{i}. profiles
####

#### Revisions:
1a,10Aug17,swr  written, Changes for SPR 60117
]]--

dhcpv6Tr = {}

--[[
--*****************************************************************************
-- dhcpv6Tr.importDhcp6ServerPools- import dhcpv6ServerPools table
-- 
]]--
function dhcpv6Tr.importDhcpv6ServerPools (input)
    local dhcpv6ServerPoolstbl = {}

    --update dhcpv6ServerPools table
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.addrPoolAddress"] = ""
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.IANAManualPrefixes"] = ""
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.IANAPrefixes"] = ""
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.DUID"] = input["dhcpv6sLANPrefixPool.hostDuid"]
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.prefixPoolAddress"] = input["dhcpv6sLANPrefixPool.delegationPrefix"]
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.IAPDManualPrefixes"] = ""
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.IAPDPrefixes"] = ""
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.IAPDAddLength"] = input["dhcpv6sLANPrefixPool.delegationPrefixLen"]
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.prefix"] = input["dhcpv6sLANPrefixPool.delegationPrefix"].."/"..input["dhcpv6sLANPrefixPool.delegationPrefixLen"]
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.LogicalIfName"] = "IF2"
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.serverPoolType"] = "IAPD"

    db.insert("dhcpv6ServerPools", dhcpv6ServerPoolstbl)
end

--[[
--*****************************************************************************
-- dhcpv6Tr.importIPv6PrefixTable- import ipv6PrefixTable table
-- 
]]--
function dhcpv6Tr.importIPv6PrefixTable (input)
    local ipv6PrefixTbl = {}
    -- insert row in ipv6PrefixTable
    ipv6PrefixTbl["ipv6PrefixTable.LogicalIfName"] = "IF2"
    ipv6PrefixTbl["ipv6PrefixTable.prefixType"] = "IAPD"
    ipv6PrefixTbl["ipv6PrefixTable.addressFamily"] = "10"
    ipv6PrefixTbl["ipv6PrefixTable.ConnectionKey"] = "0"
    ipv6PrefixTbl["ipv6PrefixTable.isStatic"] = "0"
    ipv6PrefixTbl["ipv6PrefixTable.ipAddress"] = ""
    ipv6PrefixTbl["ipv6PrefixTable.ipDstAddres"] = ""
    ipv6PrefixTbl["ipv6PrefixTable.ipv6PrefixLen"] = "0"
    ipv6PrefixTbl["ipv6PrefixTable.subnetMask"] = ""
    ipv6PrefixTbl["ipv6PrefixTable.hostDuid"] = input["dhcpv6sLANPrefixPool.hostDuid"]
    ipv6PrefixTbl["ipv6PrefixTable.delegationPrefix"] = input["dhcpv6sLANPrefixPool.delegationPrefix"]
    ipv6PrefixTbl["ipv6PrefixTable.delegationPrefixLen"] = input["dhcpv6sLANPrefixPool.delegationPrefixLen"]
    ipv6PrefixTbl["ipv6PrefixTable.startAddress"] = ""
    ipv6PrefixTbl["ipv6PrefixTable.endAddress"] = ""
    ipv6PrefixTbl["ipv6PrefixTable.prefixLength"] = "0"

    db.insert("ipv6PrefixTable", ipv6PrefixTbl) 
end

--[[
--*****************************************************************************
-- dhcpv6Tr.deleteDhcpv6ServerPools- delete dhcpv6ServerPools row(s)
-- 
-- Returns: 1 on error, 0 on success
]]--
function dhcpv6Tr.deleteDhcpv6ServerPools (tableName, input)
    local addr = ""
    local prefix = ""
    local status

    -- delete dhcpv6ServerPools row
    for k,v in pairs (input) do
        if(tableName == "dhcpv6sLANAddrPool") then
            addr = db.getAttribute(tableName, "_ROWID_", v, "startAddress")
            status = db.deleteRow ("dhcpv6ServerPools", "addrPoolAddress", addr)
        elseif(tableName == "dhcpv6sLANPrefixPool") then
            prefix = db.getAttribute(tableName, "_ROWID_", v, "delegationPrefix")
            status = db.deleteRow ("dhcpv6ServerPools", "prefixPoolAddress", prefix)
        end
        if(status == nil) then
            return 1
        end
    end 

    return 0
end

--[[
--*****************************************************************************
-- dhcpv6Tr.deleteIPv6Prefix- delete ipv6PrefixTable row(s)
-- 
-- Returns: 1 on error, 0 on success
]]--
function dhcpv6Tr.deleteIPv6Prefix (tableName, input)
    local addr = ""
    local prefix = ""
    local status

    -- delete ipv6PrefixTable row
    for k,v in pairs (input) do
        if(tableName == "dhcpv6sLANAddrPool") then
            addr = db.getAttribute(tableName, "_ROWID_", v, "startAddress")
            status = db.deleteRow ("ipv6PrefixTable", "startAddress", addr)
        elseif(tableName == "dhcpv6sLANPrefixPool") then
            prefix = db.getAttribute(tableName, "_ROWID_", v, "delegationPrefix")
            status = db.deleteRow ("ipv6PrefixTable", "delegationPrefix", prefix)
        end
        if(status == nil) then
            return 1
        end
    end

    return 0
end

--[[
--*****************************************************************************
-- dhcpv6Tr.updateDhcpv6ServerPools- edit dhcpv6ServerPools table
-- 
-- Returns: 1 on error, 0 on success
]]--
function dhcpv6Tr.updateDhcpv6ServerPools (conf, input)
    local dhcpv6sLANPrefixPoolRow = {}
    local dhcpv6ServerPoolRow = {}

    -- update input in dhcpv6ServerPools
    dhcpv6sLANPrefixPoolRow = db.getRow("dhcpv6sLANPrefixPool","_ROWID_", conf["_ROWID_"])
    query = "prefixPoolAddress='" .. dhcpv6sLANPrefixPoolRow["dhcpv6sLANPrefixPool.delegationPrefix"] .. "'"
    
    dhcpv6ServerPoolRow = db.getRowWhere("dhcpv6ServerPools", query, false)
    dhcpv6ServerPoolRow["DUID"] = input["hostDuid"]
    dhcpv6ServerPoolRow["IAPDAddLength"] = input["delegationPrefixLen"]
    dhcpv6ServerPoolRow["prefixPoolAddress"] = input["delegationPrefix"]
    dhcpv6ServerPoolRow["prefix"] = input["delegationPrefix"].."/"..input["delegationPrefixLen"]
    
    dhcpv6ServerPoolRow = util.addPrefix(dhcpv6ServerPoolRow, "dhcpv6ServerPools.")
    local valid, errstr = db.update("dhcpv6ServerPools", dhcpv6ServerPoolRow, dhcpv6ServerPoolRow["dhcpv6ServerPools._ROWID_"])
    if (not valid) then
        return 1
    end

    return 0
end

--[[
--*****************************************************************************
-- dhcpv6Tr.updateIPv6PrefixTable- import ipv6PrefixTable table
-- 
-- Returns: 1 on error, 0 on success
]]--
function dhcpv6Tr.updateIPv6PrefixTable (conf, input)
    local dhcpv6sLANPrefixPoolRow = {}
    local ipv6PrefixTbl = {}

    -- update input in ipv6PrefixTable
    dhcpv6sLANPrefixPoolRow = db.getRow("dhcpv6sLANPrefixPool","_ROWID_", conf["_ROWID_"])
    query = "delegationPrefix='" .. dhcpv6sLANPrefixPoolRow["dhcpv6sLANPrefixPool.delegationPrefix"] .. "'"
        
    ipv6PrefixTbl = db.getRowWhere("ipv6PrefixTable", query, false)
    ipv6PrefixTbl["hostDuid"] = input["hostDuid"]
    ipv6PrefixTbl["delegationPrefixLen"] = input["delegationPrefixLen"]
    ipv6PrefixTbl["delegationPrefix"] = input["delegationPrefix"]
    
    ipv6PrefixTbl = util.addPrefix(ipv6PrefixTbl, "ipv6PrefixTable.")
    local valid, errstr = db.update("ipv6PrefixTable", ipv6PrefixTbl, ipv6PrefixTbl["ipv6PrefixTable._ROWID_"])
    if (not valid) then
        return 1
    end 

    return 0
end

--[[
--*****************************************************************************
-- dhcpv6Tr.insertDhcpv6ServerPools- add dhcpv6ServerPools row
-- 
-- Returns: 1 on error, 0 on success
]]--
function dhcpv6Tr.insertDhcpv6ServerPools (input)
    local dhcpv6ServerPoolstbl = {}

    dhcpv6ServerPoolstbl["dhcpv6ServerPools.addrPoolAddress"] = ""
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.IANAManualPrefixes"] = ""
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.IANAPrefixes"] = ""
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.DUID"] = input["clientIdentifier"]
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.prefixPoolAddress"] = input["delegationPrefix"]
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.IAPDManualPrefixes"] = ""
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.IAPDPrefixes"] = ""
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.IAPDAddLength"] = input["delegationPrefixLen"]
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.prefix"] = input["delegationPrefix"].."/"..input["delegationPrefixLen"]
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.LogicalIfName"] = "IF2" 
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.serverPoolType"] = "IAPD"
    
    local valid, errstr, rowid = db.insert("dhcpv6ServerPools", dhcpv6ServerPoolstbl) 
    if (not valid) then
        return 1
    end

    return 0
end

--[[
--*****************************************************************************
-- dhcpv6Tr.insertIPv6PrefixTable- add ipv6PrefixTable row
-- 
-- Returns: 1 on error, 0 on success
]]--
function dhcpv6Tr.insertIPv6PrefixTable (input)
    local ipv6PrefixTbl = {}

    ipv6PrefixTbl["ipv6PrefixTable.LogicalIfName"] = "IF2"
    ipv6PrefixTbl["ipv6PrefixTable.prefixType"] = "IAPD"
    ipv6PrefixTbl["ipv6PrefixTable.addressFamily"] = "10"
    ipv6PrefixTbl["ipv6PrefixTable.ConnectionKey"] = "0"
    ipv6PrefixTbl["ipv6PrefixTable.isStatic"] = "0"
    ipv6PrefixTbl["ipv6PrefixTable.ipAddress"] = ""
    ipv6PrefixTbl["ipv6PrefixTable.ipDstAddres"] = ""
    ipv6PrefixTbl["ipv6PrefixTable.ipv6PrefixLen"] = "0"
    ipv6PrefixTbl["ipv6PrefixTable.subnetMask"] = ""
    ipv6PrefixTbl["ipv6PrefixTable.hostDuid"] = input["clientIdentifier"]
    ipv6PrefixTbl["ipv6PrefixTable.delegationPrefix"] = input["delegationPrefix"]
    ipv6PrefixTbl["ipv6PrefixTable.delegationPrefixLen"] = input["delegationPrefixLen"]
    ipv6PrefixTbl["ipv6PrefixTable.startAddress"] = ""
    ipv6PrefixTbl["ipv6PrefixTable.endAddress"] = ""
    ipv6PrefixTbl["ipv6PrefixTable.prefixLength"] = "0"
    
    local valid, errstr, rowid = db.insert("ipv6PrefixTable", ipv6PrefixTbl) 
    if (not valid) then
        return 1
    end 

    return 0
end
