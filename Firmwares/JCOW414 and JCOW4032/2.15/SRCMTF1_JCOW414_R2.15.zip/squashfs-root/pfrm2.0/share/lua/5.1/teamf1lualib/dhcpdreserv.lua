-- Copyright (c) 2017, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]

--[[
#### modification history
--------------------
01a,08Sep17,swr  Changes for SPR 62295
]]--

dhcp.reserv = {}

-------------------------------------------------------------------------
-- @name dhcp.reserv.add
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcp.reserv.add (binding, dbFlag)
	require "teamf1lualib/service"
	local query = nil

    if ((binding == nil) or (binding["LogicalIfName"] == nil)) then
        dhcp.dprintf("dhcp.reserv.add: invalid arguments")        
        return "ERROR", "DHCPD_INVALID_ARG"
    end        

    local LogicalIfName = binding["LogicalIfName"]

    -- validate the binding
    local  status, errCode = dhcp.reserv.validate(binding)
    if (status ~= "OK") then
        dhcp.dprintf("dhcp.reserv.edit: Invalid dhcp binding")
		return status, errCode
    end        

	local query = nil
	-- check if the mac address  already exists
    query = "MacAddr='" .. binding["MacAddr"] .. "' or IpAddr='" .. binding["IpAddr"] .. "' or Cname='" .. binding["Cname"] .. "'"
	row = db.getRowWhere("DhcpfixedIpAddress", query, false)
	if (row ~= nil) then
        dhcp.dprintf("dhcp.reserv.validate: DHCP Reservation already exists")
		return "ERROR","DHCPD_RESERVATION_EXISTS"
	end

    -- Get the pool ID for this network
    poolID = dhcp.poolIDGet(LogicalIfName)
    if (poolID == nil) then
        dhcp.dprintf("dhcp.reserv.add: network " 
                    .. LogicalIfName .. "not found in dhcpd configuration")
		return "ERROR","DHCPD_INVALID_NETWORK"
    end

	binding["PoolID"] = poolID

	-- add the binding to the database  
	dhcp.dprintf ("Adding DHCP binding: " .. util.tableToStringRec(binding))
	binding = util.addPrefix(binding, "DhcpfixedIpAddress.")
	local valid, errstr = db.insert("DhcpfixedIpAddress", binding)
    if (not valid) then
        dhcp.dprintf("dhcp.reserv.add: failed to add binding to db. Err:" .. errstr)
        dhcp.dprintf("Binding: " .. util.tableToStringRec(binding))
        return "ERROR","DHCPD_DB_ERR"
    end

    if(dbFlag == 1) then
        -- re-write configuration and restart the DHCP server.
        service.restart("dhcpd", "1")
    end
	
	return "OK","STATUS_OK"
end

-------------------------------------------------------------------------
-- @name dhcp.reserv.delete
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcp.reserv.delete(IDList)
	require "teamf1lualib/service"

    if (IDList == nil) then
        dhcp.dprintf("dhcp.reserv.add: invalid arguments")        
        return "ERROR", "DHCPD_INVALID_ARG"
    end
            
    local valid, errstr = db.delete ("DhcpfixedIpAddress", IDList)
    if (not valid) then
        dhcp.dprintf("dhcp.reserv.delete: failed to delete bindings from db. Err:" .. errstr)
        dhcp.dprintf("IDList: " .. util.tableToStringRec(IDList))
        return "ERROR","DHCPD_DB_ERR"
    end        

	-- re-write configuration and restart the DHCP server.
    service.restart("dhcpd", "1")

	return "OK","STATUS_OK"
end

-------------------------------------------------------------------------
-- @name dhcp.reserv.edit
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcp.reserv.edit(ID, binding, dbFlag)
	require "teamf1lualib/service"
	require "dhcpLib"
	require "ifDevLib"
	local query = nil

    -- validate the binding
    local  status, errCode = dhcp.reserv.validate(binding)
    if (status ~= "OK") then
        dhcp.dprintf("dhcp.reserv.edit: Invalid dhcp binding")
		return status, errCode
    end        

    -- check if the mac address  already exists
    query = "_ROWID_!='" .. ID .. "'"
	fixedIPRows = db.getRowsWhere("DhcpfixedIpAddress", query, false)
    for k,v in pairs (fixedIPRows) do
        if(v["IpAddr"] == binding["IpAddr"] or v["MacAddr"] == binding["MacAddr"] or v["Cname"] == binding["Cname"]) then
            return "ERROR","DHCPD_RESERVATION_EXISTS"
        end
    end

	-- check if the address reservation already exists
	query = "_ROWID_='" .. ID .. "'"
	local row = db.getRowWhere("DhcpfixedIpAddress", query, false)
	if (row == nil) then
        dhcp.dprintf("dhcp.reserv.edit: failed to get binding from configuration")
		return "ERROR","DHCPD_RESERVATION_NOT_FOUND"
	end
	
    row["IpAddr"] = binding["IpAddr"]
    row["MacAddr"] = binding["MacAddr"]
    row["Cname"] = binding["Cname"]
        
    -- update configuration in the database
	row = util.addPrefix(row, "DhcpfixedIpAddress.")
	local valid, errstr = db.update ("DhcpfixedIpAddress", row,
                                     row["DhcpfixedIpAddress._ROWID_"])
    if (not valid) then
        dhcp.dprintf("dhcp.reserv.edit: failed to edit binding to db. Err:" .. errstr)
        dhcp.dprintf("Binding: " .. util.tableToStringRec(binding))
        return "ERROR","DHCPD_DB_ERR"
    end

    if(dbFlag == 1) then
        -- re-write configuration and restart the DHCP server.
        service.restart("dhcpd", "1")
    end

	return "OK","STATUS_OK"
end

-------------------------------------------------------------------------
-- @name dhcp.reserv.get
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcp.reserv.get(ID)
    local binding = {}
    local query = nil

    if (ID ~= nil) then
    	query = "PoolID=" .. ID
	binding = db.getRowsWhere("DhcpfixedIpAddress", query, false)
    	if (binding == nil) then
	    	return "ERROR","DHCPD_RESERVATION_NOT_FOUND"
    	end
    --[[else
	binding = db.getTable("DhcpfixedIpAddress", false)
    	if (binding == nil) then
	    	return "ERROR","DHCPD_RESERVATION_NOT_FOUND"
    	end]]--
    end        

	return "OK","STATUS_OK", binding
end

-------------------------------------------------------------------------
-- @name dhcp.reserv.validate
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcp.reserv.validate (binding)
	require "ifDevLib"
    require "teamf1lualib/nimf"

    local net = ifDevLib.netIfInfoGet (binding["LogicalIfName"]);

    if ((binding == nil) or (binding["MacAddr"] == nil) or
        (binding["IpAddr"] == nil) or (net == nil)) then
		return "ERROR","DHCPD_INVALID_ARG"
    end        

	-- check if the mac address is a multicast or a broadcast
	if (ifDevLib.isMulticastEtherAddr(binding["MacAddr"]) or
		ifDevLib.isBroadcastEtherAddr(binding["MacAddr"])) then
        dhcp.dprintf("dhcp.reserv.validate: invalid mac address")
		return "ERROR","DHCPD_INVALID_MAC_ADDRESS"
	end 

    if (nimfLib.isAddrInNetwork(net["interfaceName"], binding["IpAddr"]) ~= 1) then
        dhcp.dprintf("dhcp.reserv.validate: IP address does not belong to network's subnet")
		return "ERROR","DHCPD_ADDRESS_NOT_IN_LAN_SUBNET"
    end        

    return "OK", "STATUS_OK"
end
