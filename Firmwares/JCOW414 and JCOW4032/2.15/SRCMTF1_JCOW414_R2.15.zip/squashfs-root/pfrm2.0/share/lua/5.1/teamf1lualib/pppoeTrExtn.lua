--[[
#### 
#### File: pppoeTrExtn.lua
#### Description: 
#### TR-98 handlers for  WANPPPConnection Object
#### 
####

#### Revisions:
01a,10nov10,sam  written
]]--

pppoeTr = {}
require "teamf1lualib/pppoe"


--[[
--*****************************************************************************
--  pppoeTr.PPPoEProfileInit - initialize a pppoe profile
--
--  This function creates and initializes a pppoe profile.
--
-- RETURN: profile object
]]--

function pppoeTr.PPPoEProfileInit (LogicalIfName, ProfileName)
	local profile = {}

	if (ProfileName == nil) then
		ProfileName = "cwmp_" .. LogicalIfName
	end

	profile["PppoeProfile.LogicalIfName"] = LogicalIfName
	profile["PppoeProfile.ProfileName"] = ProfileName
	profile["PppoeProfile.Status"] = 1
    profile["PppoeProfile.AuthOpt"] = '0'
	profile["PppoeProfile.UserName"] = 'teamf1'
    profile["PppoeProfile.Password"] = 'teamf1'
    profile["PppoeProfile.Service"] = 0
    profile["PppoeProfile.IdleTimeOutFlag"] = 1
    profile["PppoeProfile.IdleTimeOutValue"] = 600
    profile["PppoeProfile.GetIpFromIsp"] = 1
    profile["PppoeProfile.GetDnsFromIsp"] = 1
    profile["PppoeProfile.StaticIp"] = ''
    profile["PppoeProfile.NetMask"] = ''
    profile["PppoeProfile.PrimaryDns"] = ''
    profile["PppoeProfile.SecondaryDns"] = ''

	return profile
end

--[[
--*****************************************************************************
--  pppoeTr.PPPoEProfileCreate - create a pppoe profile
--
-- This function creates a pppoe profile and commits it into the 
-- database.
--
-- RETURN:
-- status :  0 for success and  > 0 for error
-- rowid  : rowid of the pppoe profile in the database
]]--

function pppoeTr.PPPoEProfileCreate (LogicalIfName, ProfileName)
	local profile = {}
	local valid = false
	local errstr = nil
	local rowid
	local query = nil
	local create

	-- validate parameters
	if ((LogicalIfName == nil) and (ProfileName == nil)) then
		print ("Invalid arguments to PPPoEProfileCreate")
		return 1
	end

	-- NOTE: 
	-- There is no proper way for getting the profile name during
	-- object creation.
	--
	-- One way to use the "Name" parameter in the
	-- WANPPPConnection object, but that is not provided
	-- during object creation.
	-- 
	-- we will generate a profile name
	--
	if (ProfileName ~= nil and (string.len(ProfileName) > 0)) then
		create = 0
	else
		create = 1
	end

	if (create == 1) then
		local count = 0

		count = tr69Glue.maxRowIdGet ("PppoeProfile")
		count = count + 1
		ProfileName = "cwmp_" .. tostring(count)
	end

	-- check if the profile is already present 
	-- in the database.
	query = "LogicalIfName='" .. LogicalIfName .. "' " ..
			"AND ProfileName = '" .. ProfileName .. "'"
	profile = db.getRowWhere("PppoeProfile", query) 
	if (profile ~= nil) then	
		rowid = profile["PppoeProfile._ROWID_"]
	else
		print ("Creating PPPoE Profile: " .. ProfileName)

		-- initialize a new profile object
		profile = pppoeTr.PPPoEProfileInit(LogicalIfName, ProfileName)
		if (profile == nil) then
			print ("failed to initialize PPPoE Profile: " .. ProfileName)
			return 1
		end
	
		-- commit object into the database
		valid, errstr, rowid = db.insert("PppoeProfile", profile)
		if (not valid) then
			print ("failed to commit PPP Profile object into database." ..
				   "reason: " .. errstr)		
			return 1
		end
	end
	
	return  0, rowid
end

--[[
--*****************************************************************************
--  pppoeTr.PPPoEProfileDestroy - destroy a pppoe profile
--
--  This function deletes a pppoe profile from the database
--
-- RETURN: 0 for success and  > 0 for error
]]--

function pppoeTr.PPPoEProfileDestroy (LogicalIfName, ProfileName, rowid)
	local query = nil
	local valid = nil

	-- validate parameters
	if ((LogicalIfName == nil) or (ProfileName == nil)) then
		return 1
	end

	-- generate query string
	if (rowid ~= nil) then
		query = "_ROWID_=" .. rowid
	else
		query = "LogicalIfName='" .. LogicalIfName .. "'"
		if (ProfileName ~= nil) then
			query = query .. " AND ProfileName= '" .. ProfileName .. "'"
		end
	end

	valid = db.deleteRowWhere("PppoeProfile", query)
	if (not valid) then
		return 1 
	end

	return 0
end

--[[
--*****************************************************************************
-- pppoeTr.PPPoEProfileConfig - configure WAN PPPoE Profile 
-- 
--  This function configures a pppoe profile
-- 
-- RETURN: 0 for success and > 0 for failure
]]--

function pppoeTr.PPPoEProfileConfig (query, inputTbl)
	require "ifDevLib"
	local profile = {}
	local tmpVal = nil

	if (query == nil) then
		return 1
	end
	
	profile = db.getRowWhere("PppoeProfile", query, true)
	if (profile == nil) then
		return 1
	end

	tmpVal = inputTbl["PppoeProfile.UserName"]
	if (tmpVal ~= nil) then
		profile["PppoeProfile.UserName"] = tmpVal
	end

	tmpVal = inputTbl["PppoeProfile.Password"]
	if (tmpVal ~= nil) then
		profile["PppoeProfile.Password"] = tmpVal
	end

	tmpVal = inputTbl["PppoeProfile.Service"]
	if (tmpVal ~= nil) then
		profile["PppoeProfile.Service"] = tmpVal
	end

	tmpVal = inputTbl["PppoeProfile.AuthOpt"]
	if (tmpVal ~= nil) then
		local auth  = nil
		if (tmpVal == "PAP") then
			auth = "2"
		elseif (tmpVal == "CHAP") then
			auth = "3"
		elseif (tmpVal == "MS-CHAP") then
			auth = "4"
		end
		if (auth ~= nil) then
			profile["PppoeProfile.AuthOpt"] = auth
		end
	end
		
	tmpVal = inputTbl["PppoeProfile.IdleTimeOutFlag"]
	if (tmpVal ~= nil) then
		if (tmpVal == "AlawysOn") then
			profile["PppoeProfile.IdleTimeOutFlag"] = "0"
		elseif (tmpVal == "OnDemand") then
			profile["PppoeProfile.IdleTimeOutFlag"] = "1"
		end
	end
			
	tmpVal = inputTbl["PppoeProfile.IdleTimeOutValue"]
	if (tmpVal ~= nil) then
		profile["PppoeProfile.IdleTimeOutValue"] = tmpVal
	end

	tmpVal = inputTbl["PppoeProfile.PrimaryDns"]
	if (tmpVal ~= nil) then
		if (ifDevLib.ipv4AddrCheck(tmpVal) ~= nil) then		
			profile["PppoeProfile.PrimaryDns"] = tmpVal
            profile["PppoeProfile.GetDnsFromIsp"] = "0"
		else
			profile["PppoeProfile.PrimaryDns"] = ""
            profile["PppoeProfile.GetDnsFromIsp"] = "1"
		end
	end

	tmpVal = inputTbl["PppoeProfile.SecondaryDns"]
	if (tmpVal ~= nil) then
		if (ifDevLib.ipv4AddrCheck(tmpVal) ~= nil) then		
			profile["PppoeProfile.SecondaryDns"] = tmpVal
            profile["PppoeProfile.GetDnsFromIsp"] = "0"
		else
			profile["PppoeProfile.SecondaryDns"] = ""
            profile["PppoeProfile.GetDnsFromIsp"] = "1"
		end
	end

	tmpVal = inputTbl["PppoeProfile.StaticIp"]
	if (tmpVal ~= nil) then
		if (ifDevLib.ipv4AddrCheck(tmpVal) ~= nil) then		
			profile["PppoeProfile.StaticIp"] = tmpVal
            profile["PppoeProfile.GetIpFromIsp"] = "0"
		else
			profile["PppoeProfile.StaticIp"] = ""
            profile["PppoeProfile.GetIpFromIsp"] = "1"
		end
	end

	tmpVal = inputTbl["PppoeProfile.NetMask"]
	if (tmpVal ~= nil) then
		if (ifDevLib.ipv4AddrCheck(tmpVal) ~= nil) then		
			profile["PppoeProfile.NetMask"] = tmpVal
            profile["PppoeProfile.GetIpFromIsp"] = "0"
		else
			profile["PppoeProfile.NetMask"] = ""
            profile["PppoeProfile.GetIpFromIsp"] = "1"
		end
	end

	status = pppoe.profileConfig(profile, profile["PppoeProfile._ROWID_"], 
								 "edit", 1)
	if (status == nil or false) then
		return 1
	end

	return 0
end

--[[
--*****************************************************************************
--  pppoeTr.PPPoEProfileParamGet - get profile configuration parameter 
--
--  This function gets the profile configuration parameter
--
-- RETURN: 
-- status : 0 for success and 1 for failure
-- value  : parameter value or error code
]]--

function pppoeTr.PPPoEProfileParamGet (query, field)
	local profile = nil
	local status = "0"

	if ((query == nil) or (field == nil)) then
		return "1","TR069_INVALID_INPUT"
	end
	
	profile = db.getRowWhere("Pppoe", query, false)
	if (profile == nil) then
		return "1","TR069_OBJECT_NOT_FOUND"
	end

	if (field == "PPPAuthenticationProtocol") then
		local auth = profile["AuthOpt"] 
		if (auth == "2") then
			value = "PAP"
		elseif (auth == "3") then
			value = "CHAP"
		elseif (auth == "4") then
			value = "MS-CHAP"
		end
	elseif (field == "ConnectionTrigger") then
		if ((profile["IdleTimeOutValue"] ~= 0) and
		    (profile["IdleTimeOutFlag"]	~= 0)) then
			value = "OnDemand"
		else
			value = "AlwaysOn"
		end
	end

	return status, value
end

--[[
--*****************************************************************************
--  pppoeTr.PPPoEInit - initialize pppoe  device
--
--  This function creates and initializes pppoe device
--
-- RETURN: pppoe device
]]--

function  pppoeTr.PPPoEInit (LogicalIfName)
	local pppoedev = {}

	pppoedev["Pppoe.LogicalIfName"] = LogicalIfName
    pppoedev["Pppoe.UserName"] = 'teamf1'
    pppoedev["Pppoe.Password"] = 'teamf1'
    pppoedev["Pppoe.IspName"] = 0
    pppoedev["Pppoe.AccountName"] = ''
    pppoedev["Pppoe.DomainName"] = ''
    pppoedev["Pppoe.GetIpFromIsp"] = 1
    pppoedev["Pppoe.GetDnsFromIsp"] = 1
    pppoedev["Pppoe.StaticIp"] = ''
    pppoedev["Pppoe.NetMask"] = ''
    pppoedev["Pppoe.PrimaryDns"] = ''
    pppoedev["Pppoe.SecondaryDns"] = ''
    pppoedev["Pppoe.IdleTimeOutFlag"] = 1
    pppoedev["Pppoe.IdleTimeOutValue"] = 600
    --- PPPoE Profiles not supported.
    --- pppoedev["Pppoe.ProfileName"] = "" .. LogicalIfName .. "_Profile"
    pppoedev["Pppoe.AuthOpt"] = '0'

	return pppoedev
end

--[[
--*****************************************************************************
--  pppoeTr.PPPoECreate - create pppoe  device
--
--  This function creates a pppoe device and commits it into the database.
--  A PPPoE profile is created for the device if it does not already exist.
--
-- RETURN: 
-- status - 0 for success and > 0 for failure
-- rowid  - rowid of the object in the database
]]--

function  pppoeTr.PPPoECreate (LogicalIfName)
	local pppoedev = nil
	local valid = false
	local errstr = nil
	local rowid
	local query 
	local ProfileName

	-- validate parameters
	if (LogicalIfName == nil) then
		return 1
	end

	query = "LogicalIfName='" .. LogicalIfName .. "'"

	-- check if the PPPoE  device is already present
	-- in the database
	pppoedev = db.getRowWhere("Pppoe", query, true)
	if (pppoedev ~= nil) then
	
		-- force an update on the PPPoE table so that the parameters get
        -- added to the instance map.
		pppoeTr.PPPoEConfig(query, pppoedev)

		rowid = pppoedev["Pppoe._ROWID_"]
	else
		print ("Creating Pppoe Device for " .. LogicalIfName)
		-- initialize the object
		pppoedev = pppoeTr.PPPoEInit(LogicalIfName)
		if (pppoedev == nil) then
			return 1
		end
	
		-- commit object into the database
		valid, errstr, rowid = db.insert("Pppoe", pppoedev)
		if (not valid) then
			print ("failed to commit PPPoE object into database." ..
				   "reason: " .. errstr)		
			return 1
		end
	end	
	
	ProfileName = pppoedev["Pppoe.ProfileName"]

	--
	-- Create PPPoE profile if it is not
	-- already created.
	-- if pppoe profiles are not supported then
	-- Pppoe.ProfileName must be set to nil
	--
	if ((ProfileName ~= nil) and (string.len(ProfileName) > 0)) then
		status = pppoeTr.PPPoEProfileCreate(LogicalIfName, ProfileName)
		if (status ~= 0) then
			--
			-- Profile creation would fail only if the
			-- PppoeProfile table is not present in the database
			--
			pppoedev["ProfileName"] = nil
		end
	end
	
	return  0, rowid
end

--[[
--*****************************************************************************
--  pppoeTr.PPPoEDestroy - destory  pppoe  device
--
--  This function destorys a pppoe device and deletes it from the database.
--
-- RETURN: 
]]--

function  pppoeTr.PPPoEDestroy (LogicalIfName)
	local query = nil
	local valid = nil

	-- validate parameters
	if (LogicalIfName == nil) then
		return 1
	end

	-- generate query string
	query = "LogicalIfName='" .. LogicalIfName .. "'"
	valid = db.deleteRowWhere("Pppoe", query)
	if (not valid) then
		return 1 
	end

	return 0
end

--[[
--*****************************************************************************
--  pppoeTr.PPPoEConfig - configure a pppoe device 
--
-- This function configures the pppoe device. If the profilename
-- is specified in the pppoe device, then the profile is
-- configured, else the pppoe device is configured.
--
-- RETURN: 0 for success  or  > 0 for error
]]--

function  pppoeTr.PPPoEConfig (query, inputTbl)
	require "ifDevLib"

	local tmpVal

	if (query == nil) then
		return 1
	end
	
	pppoedev = db.getRowWhere("Pppoe", query, true)
	if (pppoedev == nil) then
		return 1
	end

	--
	-- Check if any profile is associated with the PPP device. 
	--
	local ProfileName = pppoedev["Pppoe.ProfileName"]
	if ((ProfileName ~= nil) and (string.len(ProfileName) > 0)) then
		--
		-- Call the profile configuration function.
		--
		query = "" .. query  .. " AND  ProfileName='" .. ProfileName .. "'"
		return  pppoeTr.PPPoEProfileConfig (query, inputTbl)
	end

	tmpVal = inputTbl["Pppoe.UserName"]
    if (tmpVal ~= nil) then
        pppoedev["Pppoe.UserName"] = tmpVal
    end

    tmpVal = inputTbl["Pppoe.Password"]
    if (tmpVal ~= nil) then
        pppoedev["Pppoe.Password"] = tmpVal
    end

    tmpVal = inputTbl["Pppoe.AuthOpt"]
    if (tmpVal ~= nil) then
        local auth  = ""
        if (tmpVal == "PAP") then
            auth = "2"
        elseif (tmpVal == "CHAP") then
            auth = "3"
        elseif (tmpVal == "MS-CHAP") then
            auth = "4"
        end
        if (auth ~= nil) then
            pppoedev["Pppoe.AuthOpt"] = auth
        end
    end

    tmpVal = inputTbl["Pppoe.IdleTimeOutFlag"]
    if (tmpVal ~= nil) then
        if (tmpVal == "AlawysOn") then
            pppoedev["Pppoe.IdleTimeOutFlag"] = "0"
        elseif (tmpVal == "OnDemand") then
            pppoedev["Pppoe.IdleTimeOutFlag"] = "1"
        end
    end

	tmpVal = inputTbl["Pppoe.IdleTimeOutValue"]
    if (tmpVal ~= nil) then
        pppoedev["Pppoe.IdleTimeOutValue"] = tmpVal
    end

    tmpVal = inputTbl["Pppoe.PrimaryDns"]
    if (tmpVal ~= nil) then
        if (ifDevLib.ipv4AddrCheck(tmpVal) ~= nil) then
            pppoedev["Pppoe.PrimaryDns"] = tmpVal
            pppoedev["Pppoe.GetDnsFromIsp"] = "0"
		else
            pppoedev["Pppoe.PrimaryDns"] = ""
            pppoedev["Pppoe.GetDnsFromIsp"] = "1"
        end
    end

    tmpVal = inputTbl["Pppoe.SecondaryDns"]
    if (tmpVal ~= nil) then
        if (ifDevLib.ipv4AddrCheck(tmpVal) ~= nil) then
            pppoedev["Pppoe.SecondaryDns"] = tmpVal
            pppoedev["Pppoe.GetDnsFromIsp"] = "0"
		else
            pppoedev["Pppoe.SecondaryDns"] = ""
            pppoedev["Pppoe.GetDnsFromIsp"] = "1"
        end
    end

    tmpVal = inputTbl["Pppoe.StaticIp"]
    if (tmpVal ~= nil) then
        if (ifDevLib.ipv4AddrCheck(tmpVal) ~= nil) then
            pppoedev["Pppoe.StaticIp"] = tmpVal
            pppoedev["Pppoe.GetIpFromIsp"] = "0"
		else
            pppoedev["Pppoe.StaticIp"] = ""
            pppoedev["Pppoe.GetIpFromIsp"] = "1"
        end
    end

    tmpVal = inputTbl["Pppoe.NetMask"]
    if (tmpVal ~= nil) then
        if (ifDevLib.ipv4AddrCheck(tmpVal) ~= nil) then
            pppoedev["Pppoe.NetMask"] = tmpVal
            pppoedev["Pppoe.GetIpFromIsp"] = "0"
		else
            pppoedev["Pppoe.NetMask"] = ""
            pppoedev["Pppoe.GetIpFromIsp"] = "1"
        end
    end

	status = pppoe.config (pppoedev, pppoedev["Pppoe._ROWID_"], "edit")
	if (status == nil or false) then
		return 1
	end

	return 0
end

--[[
--*****************************************************************************
--  pppoeTr.PPPoEParamGet - get pppoe configuration parameter 
--
--  This function gets the pppoe configuration parameter
--
-- RETURN: 
-- status : 0 for success and 1 for failure
-- value  : parameter value or error code
]]--

function  pppoeTr.PPPoEParamGet (rowid, field)
	local pppoedev = nil
	local query = nil
	local status = "0"

	if ((rowid == nil) or (field == nil)) then
		return "1","TR069_INVALID_INPUT"
	end
	
	query = "_ROWID_=" .. rowid
	pppoedev = db.getRowWhere("Pppoe", query, false)
	if (pppoedev == nil) then
		return "1","TR069_OBJECT_NOT_FOUND"
	end

	--
	-- Check if any profile is associated with the PPP device. 
	--
	local ProfileName = pppoedev["ProfileName"]
	if ((ProfileName ~= nil) and (string.len(ProfileName) > 0)) then
		--
		-- Call the profile configuration function.
		--
		query = "LogicalIfName='" .. pppoedev["LogicalIfName"] .. "'  " ..
				"AND  ProfileName='" .. pppoedev["ProfileName"]  .. "'"
		return  pppoeTr.PPPoEProfileParamGet (query, field)
	end

	if (field == "PPPAuthenticationProtocol") then
		local auth = pppoedev["AuthOpt"] 
		if (auth == "2") then
			value = "PAP"
		elseif (auth == "3") then
			value = "CHAP"
		elseif (auth == "4") then
			value = "MS-CHAP"
		else
			value = "PAP,CHAP,MS-CHAP"
		end
	elseif (field == "ConnectionTrigger") then
		if ((pppoedev["IdleTimeOutValue"] ~= 0) and
		    (pppoedev["IdleTimeOutFlag"]	~= 0)) then
			value = "OnDemand"
		else
			value = "AlwaysOn"
		end
	end

	return status, value
end
