-------------------------------------------------------------------------------
-- Sends logging information to loggingd
--
-- @copyright Copyright (c) 2012, TeamF1, Inc. 
-------------------------------------------------------------------------------

require"lualogging/logging"

local LOG_LEVEL = {
	["DEBUG"] = 1,
	["INFO"]  = 2,
	["WARN"]  = 3,
	["ERROR"] = 4,
	["FATAL"] = 5,
}

function logging.adplog(loggerId)
    local logger = logging.new(function(self, level, message)
		                       level = LOG_LEVEL[level]
                               loggingLib.log(self.moduleId, level, message)
                               return true
                               end)
    logger:setModuleId(loggerId)

    return logger
end
