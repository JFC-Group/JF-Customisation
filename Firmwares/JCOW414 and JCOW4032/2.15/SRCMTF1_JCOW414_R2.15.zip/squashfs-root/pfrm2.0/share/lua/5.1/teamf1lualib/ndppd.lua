-- Copyright (c) 2017, TeamF1 Networks Pvt. Ltd. 
-- [Subsidiary of D-Link (India) Ltd] 


ndppd = {}
-------------------------------------------------------------------------
-- @name ndppd.config
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function ndppd.config (inputTable, rowid, operation)
    -- validate
    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
            return db.insert("ndppd", inputTable)
        elseif (operation == "edit") then
            return db.update("ndppd", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("ndppd", inputTable)
        end
    end
    return false
end

-------------------------------------------------------------------------
-- @name ndppd.profileConfig
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function ndppd.profileConfig (inputTable, rowid, operation)
    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    db.beginTransaction() --begin transaction
    local valid = false
    
    valid = ndppd.config(inputTable, rowid, operation)
       	
    -- return
    if (valid) then
    	db.commitTransaction(true)
    	return "OK", "STATUS_OK"
    else
    	db.rollback()
	return "ERROR", "NDPPD_CONFIG_FAILED"    	
    end
end


-------------------------------------------------------------------------
-- @name ndppd.import
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function ndppd.import(ndppdConfig, defaultCfg, removeCfg)
    
    if (ndppdConfig == nil) then
        ndppdConfig = defaultCfg 
    end
    
    local confTbl = {}
    confTbl = config.update (ndppdConfig.conf, defaultCfg.conf, removeCfg.conf)

    if (confTbl ~= nil and #confTbl ~= 0) then
        for i,v in ipairs (confTbl) do
            v = util.addPrefix (v, "ndppd.");
            ndppd.profileConfig (v, -1, "add")
        end
    end

end

-------------------------------------------------------------------------
-- @name ndppd.export
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function ndppd.export(ndppdConfig)
	local ndppdTbl = {}

	ndppdTbl["conf"] = db.getTable("ndppd" , false)

	return ndppdTbl
end

if (config.register) then
   config.register("ndppd", ndppd.import, ndppd.export, "1")
end

