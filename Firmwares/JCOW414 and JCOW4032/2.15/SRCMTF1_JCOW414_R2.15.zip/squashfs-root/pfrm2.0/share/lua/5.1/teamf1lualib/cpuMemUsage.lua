--[[
#### Aditya kapoor
#### TeamF1
#### www.TeamF1.com
#### Dec 15, 2011

#### File: cpuMemUsage.lua
#### Description: cpuMemUsage functions

]]--
--------------------------------
--package
cpuMemUsage = {}






--*****************************************************************************
	--Functions specific to the particular component 
--*****************************************************************************
--@name cpuMemUsage.cpuUtilInfoGet()
--
--@description The function will update the table by executing the command and 
--return the cpu information from the table
--
--@return

function cpuMemUsage.cpuUtilInfoGet()

    -- require
    require "cpuMemUsageLib"
    
	--declaration
	local cpuUsageTbl = {}		--local table containg details of the table SystemStatics
	local usageTbl = {}
	local cpuTempTbl = {}

	usageTbl = cpuMemUsageLib.cpuStatsGet()
	if (usageTbl == nil) then
		return cpuUsageTbl
	end

    cpuTempTbl = cpuMemUsageLib.cpuTempGet()
    if (cpuTempTbl == nil) then
		return cpuUsageTbl
	end

    local tbl1 = util.split(cpuTempTbl["CpuTemp"], ".")
    local tbl2 = util.split( cpuTempTbl["EnclosureTemp"], ".")
    
    --table with detail of cpu info
	cpuUsageTbl["CpuUsedByUser"] = usageTbl["CpuUsedByUser"]
	cpuUsageTbl["CpuUsedByKernel"] = usageTbl["CpuUsedByKernel"]
	cpuUsageTbl["CpuWaitingForIO"] = usageTbl["CpuWaitingForIO"]
	cpuUsageTbl["CpuIdle"] = usageTbl["CpuIdle"]
	cpuUsageTbl["CpuTemp"] = tbl1[1] or string.gsub(cpuTempTbl["CpuTemp"],"C","")
	cpuUsageTbl["EnclosureTemp"] = tbl2[1] or cpuTempTbl["EnclosureTemp"]	

	--return	
	return cpuUsageTbl
end

--****************************************************************************
--@name cpuMemUsage.cpuMemInfoGet()
--
--@description The function will execute the command which will update the table
--and returns the values of memory info
--
--@return

function cpuMemUsage.cpuMemInfoGet() 

    -- require
	require "cpuMemUsageLib"

	--declaration
	local usageTable = {}
	local memUsageTbl = {}		--local table containg details of the table SystemStatics
	
	usageTable = cpuMemUsageLib.memStatsGet()
	if (usageTable == nil) then
		return memUsageTbl
	end
	
    local i=1

	--table with detail of memory info 
	memUsageTbl["MemoryTotal"] = usageTable["MemoryTotal"]
	memUsageTbl["MemoryUsed"] = usageTable["MemoryUsed"]
	memUsageTbl["MemoryFree"] = usageTable["MemoryFree"]
	memUsageTbl["MemoryCached"] = usageTable["MemoryCached"]
	memUsageTbl["MemoryBuffers"] = usageTable["MemoryBuffers"]	
	--return
	return memUsageTbl
end

--****************************************************************************
--@name cpuMemUsage.configInfoGet()
--
--@description The function will execute the command which will update the table
--and returns the values of memory info of Config
--
--@return

function cpuMemUsage.configInfoGet() 

    -- require
	require "cpuMemUsageLib"

	--declaration
	local usageTable = {}
	local configUsageTbl = {}		--local table containg details of the table SystemStatics
	
	usageTable = cpuMemUsageLib.configGet()
	if (usageTable == nil) then
		return configUsageTbl
	end
	
	--table with detail of memory info 
	configUsageTbl["MemoryTotal"] = usageTable["MemoryTotal"]
	configUsageTbl["MemoryUsed"] = usageTable["MemoryUsed"]
    configUsageTbl["MemoryAvaliable"] =usageTable["Avaliable"]
	configUsageTbl["MemoryUsed%"] = usageTable["UsedPercent"]
	
    --return
	return configUsageTbl
end

--****************************************************************************
