-- @copyright Copyright (c) 2012, TeamF1, Inc. 

require "teamf1lualib/evtDsptch"
require "ripLib"
require "appExtn/AppExtn"

RipExtn = OoUtil.inheritsFrom(AppExtn)
RipExtn.name    = "RIP"
RipExtn.className   = "RipExtn"
RipExtn.classId = "rip"
RipExtn.dbTable = "Rip"
RipExtn.logger  = nil

local SUPER = require("appExtn.AppExtn")

local netEvents  = {}
netEvents[evtDsptch.event.IFDEV_EVENT_IP4_NET_UP] =  0
netEvents[evtDsptch.event.IFDEV_EVENT_IP4_NET_DOWN] =  0

local cfgEvents = {}
cfgEvents[db.event.SQLITE_INSERT] = 1
cfgEvents[db.event.SQLITE_UPDATE] = 1
cfgEvents[db.event.SQLITE_DELETE] = 1

-------------------------------------------------------------------------------
-- @name RipExtn:new
--
-- @description This function creates a new instance object for rip, loads
-- the configuration and event subcriptions
--
-- @return  0 for success and -1 for error
--

function RipExtn:new(instanceId, props)

    assert(instanceId, "Instance ID must be specified")

    -- create a new instance
    self = RipExtn.create()

    SUPER.new(self, RipExtn.classId, instanceId, props)

    self.name  = RipExtn.name
    self.dbTable = RipExtn.dbTable
    self.dbconn = RipExtn.dbconn
    self.logger = RipExtn.logger

    -- initialize events for this instance
    self.netEvents = netEvents              
    self.cfgEvents = cfgEvents

    -- register with appd
    appd.appExtnRegister(self)                    

    -- load the instance          
    local status, errCode, self = self:load()
    if (status == nil) then
        LOG:error("failed to load " .. classId .. 
                  "(" .. instanceId .. ")")
        return nil
    end        

    return self
end

-------------------------------------------------------------------------------
-- @name RipExtn:load
--
-- @description This function loads the configuration for the application
--
-- @return  
--

function RipExtn:load() 
    require "teamf1lualib/nimf"

    local status, errCode, self = SUPER.load(self)
    if (status == nil) then
        LOG:error(self.name .. "failed to load rip configuration")        
        return -1
    end        

    local props = self:getProps()
    if (ripLib.cfgLoad(props) < 0) then
        LOG:error(self.name .. "failed to initialise rip configuration")        
        return -1
    end        
        
    return 0
end        

-------------------------------------------------------------------------------
-- @name RipExtn:delete
--
-- @description This function destroys an instance of this extension
--
-- @return  
--

function RipExtn:delete() 
    appd.appExtnUnregister(self)
    return 
end        

-------------------------------------------------------------------------------
-- @name RipExtn:stop
--
-- @description This function stops rip
--
-- @return  0 for success and -1 for error
--

function RipExtn:stop ()

    LOG:info("Stopping " .. self.name ..  "(" ..  self.instanceId .. ")")

    ripLib.stop()

    return 0
end

-------------------------------------------------------------------------------
-- @name RipExtn:start
--
-- @description This function starts rip
--
-- @return  0 for success and -1 for error
--

function RipExtn:start ()

    if (self:isEnabled()) then

        LOG:info("Starting " .. self.name ..  "(" ..  self.instanceId .. ")")

        local status = ripLib.start()
        if (status < 0) then
            LOG:error(self.name .. " start failed")
            return status
        end        
    end

    return 0
end

-------------------------------------------------------------------------------
-- @name RipExtn:restart
--
-- @description This function restarts rip
--
-- @return  0 for success and -1 for error
--

function RipExtn:restart ()

    LOG:info("Re-starting " .. self.name ..  "(" ..  self.instanceId .. ")")

    self:stop()

    local status = self:start()
    if (status < 0) then
        return status
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name RipExtn:isEnabled
--
-- @description This function checks the configuration if rip is enabled
--
-- @return  
--

function RipExtn:isEnabled()
    local props = self:getProps()

    if (tonumber(props.Version) > 0) then
        return true
    end        

    return false
end

-------------------------------------------------------------------------------
-- @name RipExtn:getAppName
--
-- @description This function gets the name of this extension
--
-- @return  
--

function RipExtn:getAppName()
   return self.name
end

-------------------------------------------------------------------------------
-- @name RipExtn:getDbTableName
--
-- @description This function gets the database table name which contains
-- configuration records for all instances of this application.
--
-- @return  
--

function RipExtn:getDbTableName()
   return self.dbTable
end

-------------------------------------------------------------------------------
-- @name RipExtn:onNetEvent
--
-- @description This function handles network events for rip
--
-- @param  netevent event info
--
-- @return  0 for success and -1 for error
--

function RipExtn:onNetEvent(netevent)

    if (self:isEventSubscribed(netevent) == false) then
        LOG:ddebug(self.classId .. " not subscribed to event: " ..
                  netevent.event .. " on " .. netevent.ifname)
        return 0
    end        

    -- re-load configuration and interface list
    self:load()

    -- restart
    self:restart()

    return 0
end

-------------------------------------------------------------------------------
-- @name RipExtn:isEventSubscribed
--
-- @description This function checks if this instance is subcribed to
-- the event pass as input
--
-- @param event event info
--
-- @return  0 for success and -1 for error
--

function RipExtn:isEventSubscribed(event)

    if (event.type == appd.eventType.APPD_EV_NET) then
        
        local evstate = self.netEvents[event.event]
        if (evstate == nil) then
            return false
        end            
                    
        if (evstate > 0) then
            return true
        end        

    elseif (event.type == appd.eventType.APPD_EV_CFG) then

        -- are we subscribed to this event                        
        local evstate = self.cfgEvents[event.event]
        if (evstate == nil) then
            return false
        end            

        if (evstate > 0) then
            return true
        end        
    end

    return false
end

-------------------------------------------------------------------------------
-- @name RipExtn:onCfgEvent
--
-- @description This function is called by appd to handle configuration events
-- 
-- @param  cfgevent event information
--
-- @return  
--

function RipExtn:onCfgEvent(cfgevent)

    if (self:isEventSubscribed(cfgevent) == false) then
        LOG:ddebug(self.classId .. " not subscribed to event: " ..
                   cfgevent.event .. " on " .. cfgevent.dbTable)
        return
    end        

    if (cfgevent.event == db.event.SQLITE_INSERT) then
        -- start rip
        self:start()
    elseif (cfgevent.event == db.event.SQLITE_UPDATE) then
        -- re-load configuration and interface list
        self:load()

        -- restart rip
        self:restart()
    elseif (cfgevent.event == db.event.SQLITE_DELETE) then
        self:stop()
    end                

    return
end

-------------------------------------------------------------------------------
-- @name RipExtn:print
--
-- @description This function is called by appd to bootstrap all instances of 
-- this application. 
--
-- @param  
--
-- @return  
--

function RipExtn:print()
    require "util/strlib"

    LOG:info("Class     : " .. self.classId)
    LOG:info("Instance  : " .. self.instanceId)
    LOG:info("App Name  : " .. self:getAppName())
    LOG:info("Conf      : " .. strlib.serializeTbl(self:getProps()))
    return
end

-------------------------------------------------------------------------------
-- @name RipExtn.cfgEventCallback
--
-- @description 
--
-- @param  
--
-- @return  
--

function RipExtn.cfgEventCallback(obj, info)

    LOG:ddebug(RipExtn.classId .. " configuration callback called  " .. 
               "for event: " ..  info.event .. " on rowId " .. info.rowId)

    if (info.event == db.event.SQLITE_INSERT) then
        if (obj == nil) then 
            -- create instance 
            obj = RipExtn:new(info.rowId)
        end        

        if (obj) then 
            obj:onCfgEvent(info) 
        end

    elseif (info.event == db.event.SQLITE_UPDATE) then
        -- process event
        if (obj) then 
            obj:onCfgEvent(info) 
        end
    elseif (info.event == db.event.SQLITE_DELETE) then
        -- process event and destroy instance
        if (obj) then
            obj:onCfgEvent(info)
            self:delete()
        end
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name RipExtn.bootstrap
--
-- @description This function is called by appd on startup to bootstrap all 
-- instances of this application. 
--
-- @param  
--
-- @return  
--

function RipExtn.bootstrap()
    local instanceId=nil
    local callbackTable= {}

    ripLib.killAll()

    local callback = {}
    callback.type = appd.eventType.APPD_EV_CFG
    callback.dbTable = RipExtn.dbTable
    callback.routine = RipExtn.cfgEventCallback
    table.insert(callbackTable, callback)
    appd.callbackRegister (RipExtn.classId, callbackTable)

    local cfg = db.getTable(RipExtn.dbTable, false)
    if (cfg == nil) then
        return 0
    end        

    for index, record in pairs(cfg) do
        instanceId = record["_ROWID_"]

        -- create an instance and restart it
        local obj = RipExtn:new(instanceId)
        if (obj and obj:isEnabled()) then
            obj:start()
        end                        
    end

    return 0
end

return RipExtn
