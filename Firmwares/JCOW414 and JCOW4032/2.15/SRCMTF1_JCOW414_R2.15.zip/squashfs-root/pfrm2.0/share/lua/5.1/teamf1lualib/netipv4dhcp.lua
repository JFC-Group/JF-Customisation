--[[
#### @copyright Copyright (c) 2013, TeamF1, Inc.

#### Copyright (c) 2014, TeamF1Networks Pvt. Ltd. 
#### (Subsidiary of D-Link India)

#### modification history
--------------------
01c,23Nov17,swr  changes for spr 62635(XSS vulnerability) and 61441
01b,08Sep17,swr  Changes for SPR 62295
01a,19aug14,brk  Added DHCP Options configuration funtions
  
--]]
gui.networking.reservedDhcpClient = {}
gui.networking.reservedDhcpClient.add = {}
gui.networking.reservedDhcpClient.edit = {}

gui.networking.dhcpVendor={}
gui.networking.dhcpVendor.add = {}
gui.networking.dhcpVendor.edit = {}

gui.networking.dhcpVendorSpecificInfo={}
gui.networking.dhcpVendorSpecificInfo.add = {}
gui.networking.dhcpVendorSpecificInfo.edit = {}

gui.networking.tftpservername={}
gui.networking.sipserveraddress={}

gui.networking.hostTbl = {}
gui.networking.hostTbl.add = {}
gui.networking.hostTbl.edit = {}

VENDOR_SPECIFIC_DHCP_OPCODE      =    43
TFTP_SERVER_NAME_DHCP_OPCODE     =    66
SIP_SERVER_ADDRESS_DHCP_OPCODE   =   120
DHCPD_OPT_SCOPE_INTERFACE        =   0x2
DHCPD_POOLID                     =    1
DHCP_OPTION_ENABLE               =    1

-------------------------------------------------------------------------
-- @name gui.networking.ipv4DhcpConfGet
--
-- @description
--
-- @param conf
--
-- @return
--

function gui.networking.ipv4DhcpConfGet (conf)
    require "teamf1lualib/dhcp"
    local status = "ERROR"
    local errCode = ""
    local default = 1
    local dhcpmode = tostring(dhcp.mode.IPV4_DHCP_RELAY)
    conf["dhcpMode"] = tostring(dhcp.mode.IPV4_DHCP_NONE)

    -- Get DHCP server info
    status, errCode, dhcpdConf = dhcp.poolConfGet (conf["LogicalIfName"], default)
    if (dhcpdConf ~= nil) then
        if (tonumber(dhcpdConf["Enable"]) > 0) then
            conf["dhcpMode"] = tostring(dhcp.mode.IPV4_DHCP_SERVER)
        end
        conf["DomainName"] = dhcpdConf["DomainName"];
        conf["dhcpStartIP"] = dhcpdConf["MinAddress"];
        conf["dhcpStopIP"] = dhcpdConf["MaxAddress"];
        conf["dhcpLeaseTime"] = tonumber(dhcpdConf["DHCPLeaseTime"]);
        conf["DNSServers"] = dhcpdConf["DNSServers"];
        if (tonumber (dhcpdConf["DNSServers"]) == dhcp.dnsMode.USE_CUSTOM_DNS) then
            conf["PrimaryDns"] = dhcpdConf["DNSServer1"] or "0.0.0.0";
            conf["SecondaryDns"] = dhcpdConf["DNSServer2"] or "0.0.0.0";
        end
    else
         conf["dhcpLeaseTime"] = "1" -- assigning default value for lease time to diaplay in GUI
    end

    -- include the dhcpRelay table
    require "teamf1lualib/dhcpRelay"
    status, errCode, relayConf = dhcpRelay.confGet(conf["LogicalIfName"])
    -- if relay table is present for this logicalifname
    if(relayConf ~= nil) then
        if (tonumber(relayConf["dhcpRelayStatus"]) > 0) then
            conf["dhcpMode"] = dhcpmode
            conf["relayGw"] = relayConf["relayGw"]
            conf["option82"] = relayConf["option82"]
            conf["circuitID"] = relayConf["circuitID"]
            conf["remoteID"] = relayConf["remoteID"]
        end
    end

    return "OK", "STATUS_OK", conf
end

-------------------------------------------------------------------------
-- @name gui.networking.ipv4DhcpConfigure
--
-- @description
--
-- @param conf
--
-- @return
--

function gui.networking.ipv4DhcpConfigure(conf)
    require "teamf1lualib/dhcp"
    local status = "ERROR"
    local errCode = ""

    -- Made changes for Default subnet modification to 43.x as per RJIL
        if(util.fileExists("/pfrm2.0/ETHERNET_ONLY") or util.fileExists("/pfrm2.0/HW_HG260ES") or
            util.fileExists("/pfrm2.0/HW_JCE410")) then
            if(util.fileExists("/flash/configMerge/ipChange") == false) then
                ipChange = io.open("/flash/configMerge/ipChange", "w")                                                          
                if(ipChange ~= nil) then                                                                       
                    ipChange:close()                                                                           
                end  
            end
        end

    if (tonumber(conf["dhcpMode"]) == dhcp.mode.IPV4_DHCP_SERVER) then
        
        if (tonumber(conf["DNSServers"]) == dhcp.dnsMode.USE_CUSTOM_DNS) then
            conf["DNSServer1"] = conf["PrimaryDns"]
            conf["DNSServer2"] = conf["SecondaryDns"]
        end

        conf["MinAddress"] = conf["dhcpStartIP"]
        conf["MaxAddress"] = conf["dhcpStopIP"]
        conf["DHCPLeaseTime"] = conf["dhcpLeaseTime"]
        conf["IPRouters"] = conf["StaticIp"]
        conf["Enable"] = 1

        gui.dprintf("Updating Default DHCP server pool for:" .. conf["LogicalIfName"])

        -- Add/Update the default DHCP pool
        status, errCode = dhcp.defPoolUpdate (conf)
        if (status ~= "OK") then
            return status, errCode
        end
    else
        local default = 1;

        -- Disable DHCP server for this network
        status, errCode, poolConf = dhcp.poolConfGet (conf["LogicalIfName"], default)
        if (status == "OK") then
            poolConf["Enable"] = 0

            gui.dprintf("Disabling DHCP Server on:" .. conf["LogicalIfName"]);

            -- Add/Update the default DHCP pool
            status, errCode = dhcp.defPoolUpdate (poolConf)
            if (status ~= "OK") then
                return status, errCode
            end
        end
    end

    if (tonumber(conf["dhcpMode"]) == 2) then
        conf["dhcpRelayStatus"] = "1"
    else
        conf["dhcpRelayStatus"] = "0"
    end

    require "teamf1lualib/dhcpRelay"
    status, errCode = dhcpRelay.confEdit(conf)
    if (status ~= "OK") then
        return status, errCode
    end

    return "OK", "STATUS_OK"
end

--[[
-------------------------------------------------------------------------------
-- gui.networking.reservedDhcpClient - get the list of reserved IPs
--
-- This function gets the list of reserved IP addresses.
--
-- RETURN:
]]--

function gui.networking.reservedDhcpClient.get(NetworkName)
    require "teamf1lualib/dhcp"
    require "teamf1lualib/network"

    local poolID
    local page = {}
    local reservedIpTbl = {}
    local bindings = {}

    page.reserv = {}

    status, errCode, conf = network.ifConfGet(NetworkName)
    if (status ~= "OK") then
        return status, errCode
    end

    poolID = dhcp.poolIDGet(conf["LogicalIfName"])
    -- get the list of all reserved Ips in the db
    local status, errCode, reservedIpTbl = dhcp.reserv.get(poolID)
    if (status ~= "OK") then
        return status, errCode, page
    end

    for i,v in ipairs(reservedIpTbl) do
        bindings[i] = {}
        bindings[i]["macAddr"] = util.filterXSSChars(reservedIpTbl[i]["MacAddr"])
        bindings[i]["startAddr"] = util.filterXSSChars(reservedIpTbl[i]["IpAddr"])
        bindings[i]["Cname"] = util.filterXSSChars(reservedIpTbl[i]["Cname"])
        if (UNIT_INFO == "ODU") then   
            bindings[i]["Enable"] = reservedIpTbl[i]["Enable"]
        end
        bindings[i]["_ROWID_"] = reservedIpTbl[i]["_ROWID_"]
    end

    page.reserv = bindings;

    return status, errCode, page.reserv
end

-------------------------------------------------------------------------------
-- gui.networking.reservedDhcpClient.add.set - Reserve a DHCP address
--
-- This function configures the DHCP server to reserve an IP address
--
-- RETURN:

function gui.networking.reservedDhcpClient.add.set(page, dbFlag)
 require "teamf1lualib/dhcp"
    require "teamf1lualib/network"

    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if(dbFlag == nil) then
        dbFlag = 1
    end

    page["NetworkName"] = "Local"
 local binding = {}

    if (page["LogicalIfName"] == nil) then

        status, errCode, conf = network.ifConfGet(page["NetworkName"])
        if (status ~= "OK") then
            return status, errCode
        end

        page["LogicalIfName"] = conf["LogicalIfName"]
        binding["LogicalIfName"] = conf["LogicalIfName"]
    else
        binding["LogicalIfName"] = page["LogicalIfName"]
    end

    status, errCode = gui.networking.ipAddressSubnetValidation (page["LogicalIfName"], page["startAddr"])
    if (status == "ERROR") then
        errCode = "IPADDRESS_NOT_IN_NETWORK_SUBNET"
        return status, errCode
    end

    status, errCode = gui.networking.reserveIpValidation(page)
    if (status == "ERROR") then
        gui.dprintf("reservedDhcpClient.add.set: failed to add a reserved address")
        return status, errCode
    end


    binding["MacAddr"] = page["macAddr"]
    binding["IpAddr"] = page["startAddr"]
    binding["Cname"] = page["Cname"]
    if (UNIT_INFO == "ODU") then
        binding["Enable"] = page["Enable"]
    end

    local status, errCode = dhcp.reserv.add(binding, dbFlag)
    if (status ~= "OK") then
        gui.dprintf("reservedDhcpClient.add.set: failed to add a reserved address")
        return status, errCode
    end

    db.save2()

 return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- gui.networking.reservedDhcpClient.add.get - edit a DHCP address reservation info
--
-- This function gets information to be displayed in the edit DHCP reservation.
-- page.
--
-- RETURN:

function gui.networking.reservedDhcpClient.add.get (page)
    local conf = {}
    return "OK", "STATUS_OK", conf
end

-------------------------------------------------------------------------------
-- gui.networking.reservedDhcpClient.edit.get - edit a DHCP address reservation info
--
-- This function gets information to be displayed in the edit DHCP reservation.
-- page.
--
-- RETURN:

function gui.networking.reservedDhcpClient.edit.get(rowid)
 require "teamf1lualib/dhcp"
 local binding = {}
 local page = {}
        local query = nil

 if (rowid ~= nil) then

  --Construct query
      query = "_ROWID_=" .. rowid

  -- check if the address reservation already exists
  binding = db.getRowWhere("DhcpfixedIpAddress", query, false)
  if (binding == nil) then
          gui.dprintf("reservedDhcpClient.edit.get: failed to get binding")
   return "ERROR","DHCPD_RESERVATION_NOT_FOUND"
  end

  page["startAddr"] = util.filterXSSChars(binding["IpAddr"])
  page["macAddr"] = util.filterXSSChars(binding["MacAddr"])
  page["Cname"] = util.filterXSSChars(binding["Cname"])
  if (UNIT_INFO == "ODU") then
      page["Enable"] = binding["Enable"]
  end
  page["_ROWID_"] = binding ["_ROWID_"]
 end

 return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- gui.networking.reservedDhcpClient.edit.set - edit a DHCP address reservation
--
-- This function edits a DHCP reservation.
--
-- RETURN:

function gui.networking.reservedDhcpClient.edit.set(page, dbFlag)
 require "teamf1lualib/dhcp"
    require "teamf1lualib/network"

    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if(dbFlag == nil) then
        dbFlag = 1
    end

    page["NetworkName"] = "Local"
    gui.dprintf("reservedDhcpClient.edit.set: INPUT:" .. util.tableToStringRec(page))
    if (page["LogicalIfName"] == nil) then
        status, errCode, conf = network.ifConfGet(page["NetworkName"])
        if (status ~= "OK") then
            return status, errCode
        end
        page["LogicalIfName"] = conf["LogicalIfName"]
    end

    status, errCode = gui.networking.ipAddressSubnetValidation (page["LogicalIfName"], page["startAddr"])
    if (status == "ERROR") then
        errCode = "IPADDRESS_NOT_IN_NETWORK_SUBNET"
        return status, errCode
    end

    status, errCode = gui.networking.reserveIpValidation(page)
    if (status == "ERROR") then
        gui.dprintf("reservedDhcpClient.edit.set: failed to add a reserved address")
        return status, errCode
    end

 local binding = {}
    binding["LogicalIfName"] = page["LogicalIfName"]
    binding["MacAddr"] = page["macAddr"]
    binding["IpAddr"] = page["startAddr"]
    binding["Cname"] = page["Cname"]
    if (UNIT_INFO == "ODU") then
        binding["Enable"] = page["Enable"]
    end
    binding["_ROWID_"] = page["_ROWID_"]

    local status, errCode = dhcp.reserv.edit(binding["_ROWID_"], binding, dbFlag)
    if (status ~= "OK") then
        gui.dprintf("reservedDhcpClient.edit.set: failed to edit reserved address")
        return status, errCode
    end

    db.save2()

 return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- gui.networking.reservedDhcpClient.delete - delete a address reservation
--
-- This function deletes an address reservation.
--
-- RETURN:

function gui.networking.reservedDhcpClient.delete (rowids)
 require "teamf1lualib/dhcp"

    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    local status, errCode = dhcp.reserv.delete(rowids)
    if (status ~= "OK") then
        gui.dprintf("reservedDhcpClient.delete: failed to delete dhcp reservations")
        return status, errCode
    end

    db.save2()

 return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- gui.networking.dhcpVendor.get - get all the configured dhcp options
--
-- This function gets all the DHCP options configured.
--
-- RETURN:

function gui.networking.dhcpVendor.get(NetworkName)
 require "teamf1lualib/dhcp"
 require "teamf1lualib/network"
 local dhcpOptionsTbl = {}
    local LogicalIfName
    local poolsTbl = {}
 local page = {}

    if (NetworkName == nil) then
        NetworkName = 'Local'
    end

    status, errCode, conf = network.ifConfGet(NetworkName)
    if (status ~= "OK") then
        return status, errCode
    end

    LogicalIfName = conf["LogicalIfName"]

 -- get DHCP option pool for this network
    local status, errCode, poolsTbl = dhcp.optpool.get(LogicalIfName)
    if (status ~= "OK") then
        return status, errCode
    end

    util.appendDebugOut ("Pool Table " .. util.tableToStringRec (poolsTbl))

    -- fill in the DHCP Options table
 for i,v in ipairs(poolsTbl) do
        dhcpOptionsTbl[i] = {}
  dhcpOptionsTbl[i]["classid"] = util.filterXSSChars(poolsTbl[i]["VendorClassID"])
  dhcpOptionsTbl[i]["startAddr"] = util.filterXSSChars(poolsTbl[i]["MinAddress"])
  dhcpOptionsTbl[i]["leasenumber"] =
  util.filterXSSChars(dhcpLib.dhcpdPoolSizeGet(poolsTbl[i]["MinAddress"],
           poolsTbl[i]["MaxAddress"]))
  dhcpOptionsTbl[i]["_ROWID_"] = poolsTbl[i]["_ROWID_"]
 end

 page = dhcpOptionsTbl

 return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- gui.networking.dhcpVendor.add.get - get add page info
--
-- This function gets information required to display the Add/Edit
-- DHCP options page
--
-- RETURN:

function gui.networking.dhcpVendor.add.get (page)
    local conf = {}
 return "OK", "STATUS_OK", conf
end

-------------------------------------------------------------------------------
-- gui.networking.dhcpVendor.add.set - add a DHCP option
--
-- This function adds a DHCP option.
--
-- RETURN:

function gui.networking.dhcpVendor.add.set (page)
 require "teamf1lualib/dhcp"
 require "teamf1lualib/network"
 local pool = {}
 local MaxAddress = nil
    local LogicalIfName = nil
 local query = nil

    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

     if (page["NetworkName"] == nil) then
        NetworkName = 'Local'
    end

    status, errCode, conf = network.ifConfGet(page["NetworkName"])
    if (status ~= "OK") then
        return status, errCode
    end

    LogicalIfName = conf["LogicalIfName"]

	local defLeaseTime = "1.0"
	--get lease time from default server pool
	local defPool = db.getRow("DhcpServerPools", "DefaultPool", "1")
	if (defPool ~= nil) then
		defLeaseTime = defPool["DhcpServerPools.DHCPLeaseTime"]
	end

    -- Initialise the pool
 pool["PoolID"] = dhcp.poolIDGet()
 pool["DefaultPool"] = "0"
 pool["Enable"] = "1"
 pool["MinAddress"] = page["startAddr"]
    pool["LogicalIfName"] = LogicalIfName
	pool["DHCPLeaseTime"] = defLeaseTime

    -- Get the Max address of the pool based on the
    -- number of leases
    local status, errCode, MaxAddress = dhcp.poolMaxAddrGet(LogicalIfName,
                                                            page["startAddr"],
                                                            page["leasenumber"])
    if (status ~= "OK") then
        return status, errCode
    end

 pool["MaxAddress"] = MaxAddress
 pool["VendorClassID"] = page["classid"]
 pool["VendorClassIDMode"] = "Exact"

 -- check if a pool already exists with the same client id
 local query = "VendorClassID='" .. page["classid"] .. "'"
    status, errCode, row = dhcp.optpool.get(LogicalIfName, query)
    if ((row ~= nil) and (util.tableSize(row) > 0)) then
     gui.dprintf ("Pool Already exists with the same name")
  return "ERROR","DHCPD_OPTION_EXISTS"
 end

    -- add the pool to the dhcp configuraton
    status, errCode = dhcp.optpool.add (pool)
    if (status ~= "OK") then
        dhcp.dprintf("failed to add vendor pool:" .. page["classid"])
        return status, errCode
    end


    db.save2()

 return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- gui.networking.dhcpVendor.edit.get - get edit page info
--
-- This function gets the edit page info for DHCP options
--
-- RETURN:

function gui.networking.dhcpVendor.edit.get (rowid)
 require "teamf1lualib/dhcp"
 local pool = {}
 local dhcp_opt = {}
 local query = {}

 query = "_ROWID_=" .. rowid
    local status, errCode, poolTbl = dhcp.optpool.get(nil, query)
    if (status ~= "OK") then
     gui.dprintf("dhcpVendor.edit.get: failed to get vendor options")
        return status, errCode
    end

    pool = poolTbl[1]
 dhcp_opt["classid"] = util.filterXSSChars(pool["VendorClassID"])
 dhcp_opt["startAddr"] = util.filterXSSChars(pool ["MinAddress"])
 dhcp_opt["leasenumber"] =
             util.filterXSSChars(dhcpLib.dhcpdPoolSizeGet(pool["MinAddress"], pool["MaxAddress"]))
 dhcp_opt["_ROWID_"] = pool ["_ROWID_"]

 gui.dprintf("dhcpVendor.edit.get:" .. util.tableToStringRec(dhcp_opt))

 return "OK", "STATUS_OK", dhcp_opt
end

-------------------------------------------------------------------------------
-- gui.networking.dhcpVendor.edit.set - edit DHCP option
--
-- This function edits a DHCP option
--
-- RETURN:

function gui.networking.dhcpVendor.edit.set (page)
 require "teamf1lualib/dhcp"
 local pool = {}
 local query = {}
 local MaxAddress = nil

    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

 query = "_ROWID_=" .. page["_ROWID_"]
    local status, errCode, poolTbl = dhcp.optpool.get(nil, query)
    if (status ~= "OK") then
     gui.dprintf("dhcpVendor.edit.get: failed to get vendor options")
        return status, errCode
    end

    pool = poolTbl[1]
    pool["MinAddress"] = page["startAddr"]
    pool["VendorClassID"] = page["classid"]

    -- Get the Max address of the pool based on the
    -- number of leases
    local status, errCode, MaxAddress = dhcp.poolMaxAddrGet(pool["LogicalIfName"],
                                                            pool["MinAddress"],
                                                            page["leasenumber"])
    if (status ~= "OK") then
        gui.dprintf("dhcpVendor.edit.set: failed to get MaxAddress for pool")
        return status, errCode
    end

    pool["MaxAddress"] = MaxAddress

 -- check if a row already exists with the same client id
 query = "VendorClassID='" .. pool["VendorClassID"] .. "'" ..
   "AND _ROWID_!=" .. pool["_ROWID_"]

    local status, errCode, row = dhcp.optpool.get(nil, query)
    if ((status == "OK") and (util.tableSize(row) > 0)) then
        gui.dprintf("dhcpVendor.edit.set: Pool with vendor ID:"
                     .. pool["VendorClassID"] .. " exists")
        return status, errCode
    end

    -- Edit the dhcp configuration
    status, errCode = dhcp.optpool.edit(pool["_ROWID_"], pool)
    if (status ~= "OK") then
        gui.dprintf("dhcpVendor.edit.set: failed to edit vendor pool configuration")
        return status, errCode
    end

    db.save2()

 return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- gui.networking.dhcpVendor.delete - delete DHCP options
--
-- This function deletes the given DHCP options.
--
-- RETURN:

function gui.networking.dhcpVendor.delete (rowids)
 require "teamf1lualib/dhcp"

    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

 gui.dprintf("Vendor pool rowids:" .. util.tableToStringRec(rowids))

    local status, errCode = dhcp.optpool.delete(rowids)
    if (status ~= "OK") then
        gui.dprintf("dhcpVendor.delete: failed to delete dhcp vendor pool")
        return status, errCode
    end

    db.save2()

 return "OK","STATUS_OK"
end


-------------------------------------------------------------------------------------
-- @Funtion     : gui.networking.dhcpVendorSpecificInfo.add.set()
--
-- @description : This function add a DHCP vendor specific information option.                   
--                  
-- @return      : "OK", "STATUS_OK"       on Success 
--                valid, statusMsg        on Failure
--
-- @Author      : brk
--

function gui.networking.dhcpVendorSpecificInfo.add.set (conf)
    require "teamf1lualib/dhcp"
    require "teamf1lualib/network"
    local statusMsg
    local valid

    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    conf["OptionCode"] = VENDOR_SPECIFIC_DHCP_OPCODE   
    query = "OptionCode='" .. conf["OptionCode"] .. "'"

    local confRow  = db.getRowsWhere("DhcpOption", query, false)
    for i,v in ipairs(confRow) do
        if (confRow[i]["SubOptionCode"] == conf["vendorcode"] ) then
           gui.dprintf ("VendorCode Already exists with the same name") 
           return "ERROR","VENDOR_CODE_EXISTS"
        end
    end

    conf["Enable"] = DHCP_OPTION_ENABLE
    conf["OptionScope"] = DHCPD_OPT_SCOPE_INTERFACE
    conf["PoolID"] = DHCPD_POOLID
    conf["value2"] = ""     
    conf["value3"] = ""                                                 
    conf["SubOptionCode"] = conf["vendorcode"]    
    conf["value1"] = conf["vendorinfo"]

    valid, statusMsg = dhcp.OptionsUpdate(conf)
    if (valid ~= "OK") then
        gui.dprintf("dhcpVendorSpecificInfo.add.set: failed to add dhcp vendor specific information")
        return valid, statusMsg
    end

    db.save2()

    return "OK","STATUS_OK"

end

-------------------------------------------------------------------------------------
-- @Funtion     : gui.networking.dhcpVendorSpecificInfo.edit.set()
--
-- @description : This function edit a DHCP vendor specific information option.                   
--                  
-- @return      : "OK", "STATUS_OK"       on Success 
--                valid, statusMsg        on Failure
--
-- @Author      : brk
--

function gui.networking.dhcpVendorSpecificInfo.edit.set (conf)
    require "teamf1lualib/dhcp"
    local statusMsg
    local valid

    if (ACCESS_LEVEL ~= 0) then
      return "ACCESS_DENIED", "ADMIN_REQD"
    end

    conf["Enable"] = DHCP_OPTION_ENABLE
    conf["OptionCode"] = VENDOR_SPECIFIC_DHCP_OPCODE
    conf["OptionScope"] = DHCPD_OPT_SCOPE_INTERFACE
    conf["PoolID"] = DHCPD_POOLID
    conf["value2"] = ""
    conf["value3"] = ""
    conf["SubOptionCode"] = conf["vendorcode"]  
    conf["value1"] = conf["vendorinfo"]

    valid, statusMsg = dhcp.OptionsUpdate(conf)
    if (valid ~= "OK") then
        gui.dprintf("dhcpVendorSpecificInfo.edit.set: failed to edit dhcp vendor specific information")
        return valid, statusMsg
    end

    db.save2()

    return "OK","STATUS_OK"

end

-------------------------------------------------------------------------------------
-- @Funtion     : gui.networking.dhcpVendorSpecificInfo.delete()
--
-- @description : This function delete a DHCP vendor specific information option.                   
--                  
-- @return      : "OK", "STATUS_OK"       on Success 
--                 status, errCode        on Failure
--
-- @Author      : brk
--

function gui.networking.dhcpVendorSpecificInfo.delete (rowids)
    require "teamf1lualib/dhcp"
    local status
    local errCode

    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    gui.dprintf("Vendor specific informtion rowids:" .. util.tableToStringRec(rowids))

    local status, errCode = dhcp.optiondelete(rowids)
    if (status ~= "OK") then
        gui.dprintf("dhcpVendorSpecificInfo.delete: failed to delete dhcp vendor specific infotmation")
        return status, errCode
    end

    db.save2()

    return "OK","STATUS_OK"

end

------------------------------------------------------------------------------
-- @Funtion     : gui.networking.dhcpVendorSpecificInfo.add.get()
--
-- @description : This function get add page information.                   
--                  
-- @return      : "OK", "STATUS_OK",conf       on Success 
--
-- @Author      : brk
--

function gui.networking.dhcpVendorSpecificInfo.add.get (page)
    local conf = {}
    return "OK", "STATUS_OK", conf

end

------------------------------------------------------------------------------
-- @Funtion     : gui.networking.dhcpVendorSpecificInfo.edit.get()
--
-- @description : This function gets the edit page information from dhcp options.                   
--                  
-- @return      : "OK", "STATUS_OK",conf       on Success 
--                 valid, statusMsg            on Failure
--
-- @Author      : brk
--

function gui.networking.dhcpVendorSpecificInfo.edit.get (rowid)
    require "teamf1lualib/dhcp"
    local poolsTbl = {}
    local conf = {}
    local query = {}

    query = "_ROWID_=" .. rowid

    conf["OptionCode"] = VENDOR_SPECIFIC_DHCP_OPCODE
    conf["_ROWID_="]   = rowid

    local valid, statusMsg, poolsTbl = dhcp.Optionget(conf)
    if (valid ~= "OK") then
        gui.dprintf("dhcpVendorSpecificInfo.edit.get: failed to get vendor specific information")
        return valid, statusMsg
    end

    conf["vendorcode"] = poolsTbl["SubOptionCode"]
    conf["vendorinfo"] = poolsTbl["value1"]
    conf["_ROWID_"] = poolsTbl["_ROWID_"]

    return "OK", "STATUS_OK", conf

end

------------------------------------------------------------------------------
-- @Funtion     : gui.networking.dhcpVendorSpecificInfo.get()
--
-- @description : This function gets all vendor specific information from dhcp options configured.                   
--                  
-- @return      : "OK", "STATUS_OK",page       on Success 
--                 valid, statusMsg            on Failure
--
-- @Author      : brk
--

function gui.networking.dhcpVendorSpecificInfo.get()
    require "teamf1lualib/dhcp"
    require "teamf1lualib/network"
    local dhcpOptionsTbl = {}
    local poolsTbl = {}
    local page = {}
    local conf ={}

    conf["OptionCode"] = VENDOR_SPECIFIC_DHCP_OPCODE

    local valid, statusMsg, poolsTbl = dhcp.Optiongets(conf)
    if (valid ~= "OK") then
        gui.dprintf("dhcpVendorSpecificInfo.get: failed to get vendor specific information")
        return valid, statusMsg
    end
 
    -- fill in the DHCP vendor specific info Options table
    for i,v in ipairs(poolsTbl) do
        dhcpOptionsTbl[i] = {}
        dhcpOptionsTbl[i]["vendorcode"] = poolsTbl[i]["SubOptionCode"]
        dhcpOptionsTbl[i]["vendorinfo"] = poolsTbl[i]["value1"]
        dhcpOptionsTbl[i]["_ROWID_"] = poolsTbl[i]["_ROWID_"]
    end

    page = dhcpOptionsTbl

    return "OK", "STATUS_OK", page

end

------------------------------------------------------------------------------
-- @Funtion     : gui.networking.tftpservername.set()
--
-- @description : This function set the dhcp tftp server name.                   
--                  
-- @return      : "OK", "STATUS_OK"       on Success 
--                 valid, statusMsg       on Failure
--
-- @Author      : brk
--

function gui.networking.tftpservername.set(conf)
   
    require "teamf1lualib/dhcp"

    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    conf["Enable"] = DHCP_OPTION_ENABLE
    conf["OptionCode"] = TFTP_SERVER_NAME_DHCP_OPCODE
    conf["value1"] = conf["tftpservername"]
    conf["OptionScope"] = DHCPD_OPT_SCOPE_INTERFACE
    conf["PoolID"] = DHCPD_POOLID
    conf["value2"] =""
    conf["value3"]= conf["tftpServerType"]

    local valid, statusMsg = dhcp.OptionsUpdate(conf)
    if (valid ~= "OK") then
        gui.dprintf("tftpservername.set: failed to set tftp server name")
        return valid, statusMsg
    end

    db.save2()

    return "OK", "STATUS_OK"

end

------------------------------------------------------------------------------
-- @Funtion     : gui.networking.tftpservername.get()
--
-- @description : This function get the dhcp tftp server name.                   
--                  
-- @return      : "OK", "STATUS_OK",conf       on Success 
--                 valid, statusMsg            on Failure
--
-- @Author      : brk
--

function gui.networking.tftpservername.get()

    require "teamf1lualib/dhcp"
    local poolsTbl = {}
    local conf = {}

    conf["OptionCode"] = TFTP_SERVER_NAME_DHCP_OPCODE

    local valid, statusMsg, poolsTbl = dhcp.Optionget(conf)
    if (valid ~= "OK") then
        gui.dprintf("tftpservername.get: failed to get dhcp tftp server name")
        return valid, statusMsg, conf
    end

    conf["tftpServerType"] = poolsTbl["value3"]
    conf["tftpservername"] = poolsTbl["value1"]
    conf["_ROWID_"] = poolsTbl["_ROWID_"]  

    return "OK","STATUS_OK", conf

end


------------------------------------------------------------------------------
-- @Funtion     : gui.networking.sipserveraddress.set()
--
-- @description : This function set the dhcp sip server address.                   
--                  
-- @return      : "OK", "STATUS_OK"       on Success 
--                 valid, statusMsg       on Failure
--
-- @Author      : brk
--

function gui.networking.sipserveraddress.set(conf)

    require "teamf1lualib/dhcp"

    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    conf["Enable"] = DHCP_OPTION_ENABLE
    conf["OptionCode"] = SIP_SERVER_ADDRESS_DHCP_OPCODE
    conf["value1"] = conf["sipserveraddress"]
    conf["OptionScope"] = DHCPD_OPT_SCOPE_INTERFACE
    conf["PoolID"] = DHCPD_POOLID
    conf["value2"] =""
    conf["value3"]= conf["sipServerType"]

    local valid, statusMsg = dhcp.OptionsUpdate(conf)
    if (valid ~= "OK") then
        gui.dprintf("sipserveraddress.set: failed to set dhcp sip server address")
        return valid, statusMsg
    end

    db.save2()

    return "OK", "STATUS_OK"

end

------------------------------------------------------------------------------
-- @Funtion     : gui.networking.sipserveraddress.get()
--
-- @description : This function get the dhcp sip server address.                   
--                  
-- @return      : "OK", "STATUS_OK",conf       on Success 
--                 valid, statusMsg            on Failure
--
-- @Author      : brk
--

function gui.networking.sipserveraddress.get()

    require "teamf1lualib/dhcp"
    local poolsTbl = {}
    local conf = {}

    conf["OptionCode"] = SIP_SERVER_ADDRESS_DHCP_OPCODE

    local valid, statusMsg, poolsTbl = dhcp.Optionget(conf)
    if (valid ~= "OK") then
        gui.dprintf("sipserveraddress.get: failed to get dhcp sip server address")
        return valid, statusMsg, conf
    end

    conf["sipServerType"] = poolsTbl["value3"]
    conf["sipserveraddress"] = poolsTbl["value1"]
    conf["_ROWID_"] = poolsTbl["_ROWID_"]

    return "OK","STATUS_OK", conf

end

-------------------------------------------------------------------------------
-- @name gui.networking.hostTbl.delete
--
-- @description This function deletes hostTbl entries from system
--
-- @param rowid(s) for which host name has to be deleted.
--
-- @return
--
function gui.networking.hostTbl.delete (rowids)
    --include
    require "teamf1lualib/hostTbl"

     -- Sanity for privilages
     if (ACCESS_LEVEL ~= 0) then
         return "ACCESS_DENIED", "ADMIN_REQD"
     end

     --locals
     local status = nil
     local errMsg = nil

     --delete each entry
     for k,v in pairs(rowids) do
         local inTable = {}
         inTable["_ROWID_"] = v
         status, errMsg = hostTbl.hostsDelete (inTable)
         if (status ~= "OK") then
             break
         end
     end

     db.save2()
     --return
     return status, errMsg
end

-------------------------------------------------------------------------------
-- @name gui.networking.hostTbl.edit.set
--
-- @description This function updates hostTbl entries  in system.
--
-- @param lua table containing hosts confiuration
--
-- @return
--
function gui.networking.hostTbl.edit.set (Conf)
    --include
    require "teamf1lualib/hostTbl"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status = nil
    local errMsg = nil

    --setting the new configuration in the hostTbl table
    status, errMsg = hostTbl.hostsEditSet(Conf)

    db.save2()

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name gui.networking.hostTbl.edit.get
--
-- @description This function gets configuration for an existing host entries in
-- system.
--
-- @param rowid for which hostname configuration has to be modified.
--
-- @return
--
function gui.networking.hostTbl.edit.get (rowid)
    --include
    require "teamf1lualib/hostTbl"

    --locals
    local confTbl = {}
    local errMsg = nil
    local status = nil

    --getting the configuration for the selected row
    confTbl = hostTbl.hostsEditGet(rowid)
    if (confTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    errMsg = "STATUS_OK"
    status = "OK"

    
    confTbl["IpAddr"] = util.filterXSSChars(confTbl["IpAddr"])
    confTbl["Cname"] = util.filterXSSChars(confTbl["Cname"])

    --return
    return status, errMsg, confTbl
end

-------------------------------------------------------------------------------
-- @name gui.networking.hostTbl.add.get
--
-- @description This function gets default configuration for adding a hosts in
-- system.
--
-- @return
--
function gui.networking.hostTbl.add.get ()
    --include
    require "teamf1lualib/hostTbl"

    --locals
    local confTbl = {}
    local errMsg = nil
    local statusMsg = nil

    errMsg = "STATUS_OK"
    status = "OK"

    --return
    return status, errMsg, confTbl
end

-------------------------------------------------------------------------------
-- @name gui.networking.hostTbl.add.set
--
-- @description This function adds hostName in system.
--
-- @param lua table containing userdb confiuration
--
-- @return
--
function gui.networking.hostTbl.add.set (Conf)
    --include
    require "teamf1lualib/hostTbl"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status = nil
    local errMsg = nil

    --setting the new configuration in the users table
    status, errMsg = hostTbl.hostsAddSet(Conf)

    db.save2()

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name gui.networking.hostTbl.get
--
-- @description This function get hostName table.
--
-- @param lua table containing hostName confiuration
--
-- @return
--
function gui.networking.hostTbl.get ()
    -- Require
    require "teamf1lualib/hostTbl"

    -- locals
    local hostsInfo = {} --local table containing the users Info
    local page = {} --local table containing the users Info
    local errMsg = nil
    local statusMsg = nil
    page.hostTbl = {}

    -- get the system information from platform
    hostsInfo = hostTbl.hostsGet()
    if (hostsInfo == nil) then
        return "OK", "DB_ERROR_TRY_AGAIN", page
    end

    for i,v in ipairs (hostsInfo)
    do
        page.hostTbl[i] = {}
        page.hostTbl[i].Cname = util.filterXSSChars(v["Cname"])
        page.hostTbl[i].IpAddr = util.filterXSSChars(v["IpAddr"])
        page.hostTbl[i]._ROWID_ = v["_ROWID_"]
    end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

    --return
    return errMsg, statusMsg, page
end


