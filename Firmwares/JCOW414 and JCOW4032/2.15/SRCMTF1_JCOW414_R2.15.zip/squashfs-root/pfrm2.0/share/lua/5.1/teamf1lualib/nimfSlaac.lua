-- @copyright Copyright (c) 2012, TeamF1, Inc. 

require "teamf1lualib/slaac"

--[[
*******************************************************************************
-- @name nimfConn.ipv6AutoConfValidate
--
-- @description 
--
-- @param conf 
--
-- @return  OK or ERROR
-- @errCode error string.
--]]

function nimfConn.ipv6AutoConfValidate(conf)
    local ipAddr

    -- check if primary DNS is valid
    ipAddr = conf["PrimaryDns"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv6AddrCheck(ipAddr) == nil)) then
        return "ERROR", "NIMF_ERR_INVALID_PRIMARY_DNS"
    end        

    -- check if secondary DNS is valid
    ipAddr = conf["SecondaryDns"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv6AddrCheck(ipAddr) == nil)) then
        return "ERROR", "NIMF_ERR_INVALID_SECONDARY_DNS"
    end        

    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- @name nimfConn.ipv6AutoCfgInit
--
-- @description The function initialises the ipv6 auto configuration.
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv6AutoCfgInit(cur, conf)
    local cfg = {}
    local ConnectionKey = conf["ConnectionKey"]

    if (ConnectionKey == nil) then
        ConnectionKey = "0"
    end        

    if (cur ==  nil) then
        cfg["LogicalIfName"] = conf["LogicalIfName"]
        cfg["ConnectionKey"] = ConnectionKey
        cfg["GetIpFromIsp"] = conf["GetIpFromIsp"]
        cfg["GetDnsFromIsp"]  = conf["GetDnsFromIsp"]
        cfg["nameserver1"]   = conf["PrimaryDns"]
        cfg["nameserver2"]   = conf["SecondaryDns"]
        cfg["GetRouteFromIsp"] = "1"
        cfg["ConfigureDNS"] = "1"
        cfg["isEnabled"] = "1"
    else
        cfg = cur
        cfg["GetIpFromIsp"]  = conf["GetIpFromIsp"]
        cfg["GetDnsFromIsp"] = conf["GetDnsFromIsp"]
        cfg["nameserver1"]   = conf["PrimaryDns"]
        cfg["nameserver2"]   = conf["SecondaryDns"]
        if (tonumber(conf["GetDnsFromIsp"]) > 0) then
            cfg["ConfigureDNS"] = "1"
        end            

        if (conf["ConfigureDNS"] ~= nil) then
            cfg["ConfigureDNS"] =  conf["ConfigureDNS"]
        end
    end                

    return cfg
end

--[[
*******************************************************************************
-- @name nimfConn.ipv6AutoConfigure
--
-- @description 
--
-- @param conf 
--
-- @return  OK or ERROR
-- @errCode error string.
--]]

function nimfConn.ipv6AutoConfigure(conf)
    local query = nil
    local record = {}
    local cfg = {}
    local errstr = ""
    local valid
    local rowid

    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "'"
    if (conf["ConnectionKey"] ~= nil) then
        query = query .. " AND ConnectionKey=" .. conf["ConnectionKey"]
    end

    nimf.dprintf ("Configuring ipv6 auto connection for " ..  
                  conf["LogicalIfName"])

    record = db.getRowWhere("slaac", query, false)
    if (record == nil) then
        -- initialize configuration
        cfg = nimfConn.ipv6AutoCfgInit(record, conf)
            
        -- add configuration
        cfg = util.addPrefix(cfg, "slaac.")

        nimf.dprintf ("ipv6 slaac connection " ..  util.tableToStringRec(cfg))

        valid, errstr, rowid = slaac.config (cfg, nil, "add")
    else        
        -- initialize configuration
        cfg = nimfConn.ipv6AutoCfgInit(record, conf)

        local changed = nimf.hasTableChanged("slaac", cfg, cfg["_ROWID_"])
        if (not changed) then
            return "OK","STATUS_OK", false
        end            

        --
        -- Set this to true to indicate configuration has changed
        --
        rowid = true

        -- update configuration
        cfg = util.addPrefix(cfg, "slaac.")
        valid, errstr = slaac.config (cfg, cfg["slaac._ROWID_"], "edit")
    end        

    if (not valid) then
        nimf.dprintf("nimfConn.ipv6AutoConfigure: " ..
                     "Auto Connection configuration failed")
        return "ERROR", errstr or ""
    end
            
    return "OK", "STATUS_OK", rowid
end

--[[
*******************************************************************************
-- @name nimfConn.ipv6AutoDeconfigure
--
-- @description 
--
-- @param conf 
--
-- @return  OK or ERROR
-- @errCode error string.
--]]

function nimfConn.ipv6AutoDeconfigure(conf)
    local query = nil
    local errstr = ""
    local valid

    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "'"
    if (conf["ConnectionKey"] ~= nil) then
        query = query .. " AND ConnectionKey=" .. conf["ConnectionKey"]
    end

    nimf.dprintf ("Deleting auto connection for " ..  conf["LogicalIfName"])
    valid, errstr = db.deleteRowWhere("slaac", query)
    if (not valid) then
        return "ERROR", errstr
    end
            
    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- @name nimfConn.ipv6AutoDefConfGet
--
-- @description 
--
-- @param conf 
--
-- @return  OK or ERROR
-- @errCode error string.
--]]

function nimfConn.ipv6AutoDefConfGet(connID)
    local cfg = {}

    cfg["LogicalIfName"] = connID["LogicalIfName"]
    cfg["AddressFamily"] = connID["AddressFamily"]
    cfg["ConnectionKey"] = connID["ConnectionKey"] or "0"
    cfg["GetIpFromIsp"] =  "1"
    cfg["GetDnsFromIsp"] = "1"
    cfg["PrimaryDns"] = ''
    cfg["SecondaryDns"] = ''

    return cfg
end

--[[
*******************************************************************************
-- @name nimfConn.ipv6AutoConfGet
--
-- @description 
--
-- @param conf 
--
-- @return  OK or ERROR
-- @errCode error string.
--]]

function nimfConn.ipv6AutoConfGet(conf)
    local query = nil
    local record = {}
    local cfg = {}

    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "'"
    record = db.getRowWhere("slaac", query, false)
    if (record ~= nil) then
        cfg["LogicalIfName"] = record["LogicalIfName"]
        cfg["AddressFamily"] = nimf.proto.NIMF_PROTO_TYPE_IPV6
        cfg["ConnectionKey"] = record["ConnectionKey"]
        cfg["GetIpFromIsp"] = record["GetIpFromIsp"]
        cfg["GetDnsFromIsp"] = record["GetDnsFromIsp"]
        cfg["PrimaryDns"] = record["nameserver1"]
        cfg["SecondaryDns"] = record["nameserver2"]
    end        

    return "OK", "STATUS_OK", cfg
end
