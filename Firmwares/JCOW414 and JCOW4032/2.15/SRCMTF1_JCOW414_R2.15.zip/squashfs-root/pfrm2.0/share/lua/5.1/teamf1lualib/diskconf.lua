-- diskconf.lua - lua wrapper calls for disk configuration and Management

-- Copyright (c) 2013-2017, TeamF1 Networks Pvt. Ltd.
-- (Subsidiary of D-Link India)

-- modification history
-- --------------------
-- 01c, 23Nov17, swr changes for spr 62635(XSS vulnerability) and 61441
-- 01b, 20Apr17, MSV Made changes for DMS support in LANTIQ SPR#60512.
-- 01a, 16Feb17, ar Corrected DMS settings configuration check before disk
--                  'format' action
--

gui.administration.disks = {}
gui.administration.disks.partitions = {}
gui.administration.disks.parentalGuidance = {}
gui.administration.disks.mediaShare = {}

--*****************************************************************************
-- gui.administration.disks.get - gets all the disk info.
--
-- This routine gets disk related info.
--
-- RETURNS: table with disk info.

function gui.administration.disks.get ()

    -- import required library
    require "teamf1lualib/diskMgmt"
    require "teamf1lualib/smb"

    -- Local declarations
    local status
    local statusStr
    local disks = {}
	local fileName="/tmp/diskstats"
	local index = 1
    local shared = ""

	-- the table gets filled here
    if (pcall (loadfile (fileName))) then
        dofile (fileName)
	end

    -- check if sharing is enabled or not
    local status, errCode, conf = smb.confGet()
    if (status == "OK") then
        if (conf ~= nil and tonumber(conf.serverEnable) > 0 ) then
            shared = "yes"
        else            
            shared = "no"
        end            
    end    

    disks = {}
    if (diskstats ~= nil) then
    	for k,v in pairs(diskstats) do
	    	disks[index] = {}
    		disks[index].name = v["diskId"]
	    	disks[index].diskId = v["deviceId"]
    		disks[index].uuid = v["uuid"]
	        disks[index].size = v["size"]
	        disks[index].deviceType = v["diskType"]
    	    disks[index].shared = shared
	    	disks[index].allocSpace = v["allocatedSpace"]
		    disks[index].unallocSpace = v["unallocatedSpace"]
    		index = index + 1
	    end
    end

    return "OK", "STATUS_OK", disks
end

--*****************************************************************************
-- gui.administration.disks.safely_remove - removes the given list of disk
--
-- This routine removes the given list of disks
--
-- RETURNS: status and statusStr

function gui.administration.disks.safely_remove (diskIdTbl)
    -- import required library
    require "teamf1lualib/diskMgmt"
	local statsUpdateProgram = "/pfrm2.0/bin/diskMgmtStatsGet.lua "
    local lua = "/pfrm2.0/bin/lua"
    local deleteNas = "/pfrm2.0/bin/deleteNASConfig.lua"
    local db_filename = "/tmp/system.db"

    -- Local Declarations
    local status
    local statusStr

    local diskData = {}
    for i,v in pairs (diskIdTbl) do
        diskData[i] = {}
        diskData[i]["diskId"] = v
    end
 
     for k,v in pairs (diskData) do
        local status = db.getAttribute ("diskMgmtPartition", "diskId", v["diskId"], "status")
		if(status == nil or tonumber(status) == 0) then
            return "ERROR", "DISK_NOT_READY_YET"
        end
    end

    -- Call the routine to update the smb configuration
    for k,v in pairs (diskData) do
        local partId = db.getAttribute ("diskMgmtPartition", "diskId", v["diskId"], "partId")
		if(partId ~= nil) then
        	local deleteNasProgram = lua .." ".. deleteNas .." " .. db_filename .. " " .. partId
        	os.execute (deleteNasProgram)
		else
			status = "ERROR"
			statusStr = "DISK_ALREADY_REMOVED"
			return status, statusStr
		 end 
    end 
    
    -- Call the routine to remove the disks
    status, statusStr = diskMgmt.removeDisks (diskData)

    os.execute(statsUpdateProgram)

    return status, statusStr
end

--*****************************************************************************
-- gui.administration.disks.partitions.get - gets partitions info for given disk ID
--
-- This routine gets partition info for given disk ID.
--
-- RETURNS: table with partition info

function gui.administration.disks.partitions.get (diskId)
    -- import required library
    require "teamf1lualib/diskMgmt"
    require "teamf1lualib/smb"
    local shared = ""

	--[[
    -- Local declarations
    local status
    local statusStr
	]]--
	local fileName = "/tmp/diskstats"

    local page = {}

	-- the table gets filled here
    if (pcall (loadfile (fileName))) then
        dofile (fileName)
	end

    -- check if sharing is enabled or not
    local status, errCode, conf = smb.confGet()
    if (status == "OK") then
        if (tonumber(conf.serverEnable) > 0 ) then
            shared = "yes"
        else            
            shared = "no"
        end            
    end    

	partitions = {}
	for k,v in pairs(diskstats) do
		if (v["deviceId"] == diskId) then
			partitions.name = v["diskId"]
	        partitions.size = v["size"]
	        partitions.deviceType = v["diskType"]
	        partitions.shared = "yes"
		    partitions.diskAllocSpace = v["allocatedSpace"]
			partitions.diskUnallocSpace = v["unallocatedSpace"]
	        partitions.diskId = v["deviceId"]
			for i,vv in ipairs (v.partitions) do
				partitions[i] = {}
	            partitions[i].name = vv["name"]
		        partitions[i].partId = vv["partId"]
			    partitions[i].hidden = vv["hidden"]
			    partitions[i].perm = vv["perm"]
			    partitions[i].type = diskMgmt.fsStrGet(vv["fsType"])
			    partitions[i].size = vv["size"]
				partitions[i].usage = tonumber(vv["partUsage"])
	            partitions[i].usedSpace = vv["usedSpace"]
		        partitions[i].freeSpace = vv["freeSpace"]
			end
		end
	end

    return "OK","STATUS_OK", partitions
end

--[[
--**************************************************************************
-- gui.administration.localNetTblGet() 
--
-- 
-- RETURNS: page
]]--

function gui.administration.localNetTblGet()
    require "teamf1lualib/ifDev"
    local netList = {}
    local net = {}        
    local ifTbl = {}

    -- get a list of LAN,Routed networks
    local status, errCode, ifTbl = ifDev.netListGet()
    if (status ~= "OK") then
        return netList
    end        

    for k,v in pairs(ifTbl) do
        net = {}
        if (ifDev.isRouted(v["connectionType"])) then
            net["interfaceName"] = v["interfaceName"]
            net["networkName"] = v["networkName"]
            table.insert(netList, net)
        end            
    end        

    return netList
end

--*****************************************************************************
-- gui.administration.fileShareGet - 
--
--
-- RETURNS: 

function gui.administration.fileShareGet()
    require "teamf1lualib/mediaServerMgmt"
    require "teamf1lualib/smb"
    require "teamf1lualib/network"

    local configRow =  {}
    configRow.networks = {}
    configRow.shareSettings = "1"
    configRow.lanNetworkName = "Local"

    configRow.networks = gui.administration.localNetTblGet()
    if (configRow.networks == nil) then
        return "OK", "STATUS_OK", configRow
    end
            
    status, errCode, conf = mediaServerMgmt.confGet()
    if (status == "OK") then
        if (conf ~= nil) then
            configRow.lanNetworkName = network.nameGet(conf.LogicalIfName)
            configRow.shareSettings = conf.serverEnable
            configRow.friendlyName = conf.friendlyName
        end
    end    

    return "OK", "STATUS_OK", configRow
end

--*****************************************************************************
-- gui.administration.fileShareSet - 
--
--
-- RETURNS:

function gui.administration.fileShareSet(conf,dbFlag)
    require "teamf1lualib/mediaServerMgmt"
    require "teamf1lualib/smb"
    require "teamf1lualib/network"
    require "teamf1lualib/diskMgmt"
    local serverconf =  {}
    local status = "ERROR"
    local errCode
    if (dbFlag == nil) then
        dbFlag = 1
    end

    -- get the logicalIfname
    local LogicalIfName = network.logicalIfNameGet(conf.lanNetworkName)

    -- configure media server
    status, errCode, serverconf = mediaServerMgmt.confGet()
    if (status == "OK") then
        if (serverconf ~= nil) then
            serverconf["LogicalIfName"] = LogicalIfName
            serverconf["serverEnable"] =  conf.shareSettings
            serverconf["friendlyName"] =  conf.friendlyName
            status, errCode = mediaServerMgmt.confSet(serverconf,dbFlag)
        end
    end    

    -- configure file server
    status, errCode, serverconf = smb.confGet()
    if (status == "OK") then
        if (serverconf ~= nil) then
            serverconf["LogicalIfName"] = LogicalIfName
            serverconf["serverEnable"] =  conf.shareSettings
            status, errCode = smb.confSet(serverconf,dbFlag)
        end
    end    
    
    -- configure diskMgmt
    if (serverconf ~= nil) then
        serverconf["serverEnable"] =  conf.shareSettings
        status, errCode = diskMgmt.diskSet(serverconf,dbFlag)
    end

    if (status == "OK") then db.save2() end

    return status, errCode
end

--*****************************************************************************
-- gui.administration.disks.partitions.format - format the disk partition
--
-- This routine format's the disk partition
--
-- RETURNS: status and statusStr

function gui.administration.disks.partitions.format (partName, fsType)
    
    -- import required library
    require "teamf1lualib/partitionMgmt"
    require "teamf1lualib/nasNAS"

    -- Local Declarations
    local status = "OK"
    local statusStr = "STATUS_OK"
    local errMsg
    if (partName == nil) then
        return "ERROR", "STORAGE_DEVICE_NOT_AVAILABLE"
    end

    -- added check to check if dms/ftp is enabled is enabled
    local query = "_ROWID_=1"
    local dmsEnable = "0"
    local ftpEnable = "0"
    local serviceStr = ""
    local dmsTbl = {}

	if (util.fileExists ("/pfrm2.0/BRCMJCO300") or util.fileExists ("/pfrm2.0/HW_JCO410") or util.fileExists ("/pfrm2.0/HW_JCE410") or util.fileExists("/pfrm2.0/HW_JCO4032") or util.fileExists("/pfrm2.0/HW_JCOW407") or util.fileExists("/pfrm2.0/HW_JCOW402")) then
        status, errMsg, dmsTbl = gui.administration.disks.getDMSSetting ()
        if (dmsTbl ~= nil) then
            dmsEnable = dmsTbl["dmsEnable"]
        end
    else
        dmsTbl = db.getRowWhere ("dmsServerSettings", query, false);
        if (dmsTbl ~= nil) then
            dmsEnable = dmsTbl["serverEnable"]
        end
    end

    local ftpTbl = db.getRowWhere ("ftpd", query, false);
    if (ftpTbl ~= nil) then
        ftpEnable = ftpTbl["enable"]
    end
    
    if (ftpEnable == "1" or dmsEnable == "1") then
        serviceStr = (ftpEnable == "1" and dmsEnable == "1") and "FTP and DMS" or (ftpEnable == "1") and "FTP" or (dmsEnable == "1") and "DMS"
        return "ERROR", "Please disable " .. serviceStr .. " server to format the drive."
    end

    local status = db.getAttribute ("diskMgmtPartition", "name", partName, "status")
    if (status == nil or tonumber(status) == 0) then
        return "ERROR", "DISK_NOT_READY_YET"
    end
    
    local partId = db.getAttribute ("diskMgmtPartition", "name", partName, "partId")
     
    if (partId == nil)  then
        return "ERROR", "PARTITION_MGMT_FAILED_TO_GET_DISK_ID"
	end
    -- Call the routine to remove nas share 
    nas.shareConfigDelete (partId)          

    -- format partition
    status, statusStr = partitionMgmt.formatPartition (partId, fsType)

    -- export partition
    if (status == "OK") then
        --status, statusStr = partitionMgmt.exportPartition (partId)
        
        if (not status) then
            status = "OK"
            statusStr = "STATUS_OK"
        end
    end

    return status, statusStr
end

--*****************************************************************************
-- gui.administration.disks.partitions.infoGet - gets partitions info for given disk ID
--
-- This routine gets partition info for given disk ID.
--
-- RETURNS: table with partition info

function gui.administration.disks.partitions.infoGet (diskId)
    -- import required library
    require "teamf1lualib/diskMgmt"
    require "teamf1lualib/smb"
    local shared = ""

    local page = {}

    -- check if sharing is enabled or not
    local status, errCode, conf = smb.confGet()
    if (status == "OK") then
        if (tonumber(conf.serverEnable) > 0 ) then
            shared = "yes"
        else            
            shared = "no"
        end            
    end    
    
    status, errCode, conf = diskMgmt.getDiskPartitionInfo (diskId)
    if (status == "OK") then
        diskstats       = conf.diskStat
        diskPartition   = conf.diskPartition
    end    

	partitions = {}
	partitionTbl = {}
   	if (diskstats == nil) then 
	    return "ERROR","STORAGE_DEVICE_NOT_AVAILABLE", partitions
   	end
   	
	if (diskPartition  == nil) then
	    return "ERROR","STORAGE_DEVICE_NOT_AVAILABLE", partitions
   	end
 
    partitions.name = diskstats["diskId"]
    partitions.size = diskstats["size"]
    partitions.deviceType = diskstats["diskType"]
    partitions.shared = shared
    partitions.diskAllocSpace = diskstats["allocatedSpace"]
    partitions.diskUnallocSpace = diskstats["unallocatedSpace"]
    partitions.diskId = diskstats["deviceId"]

	 for i,v in ipairs (diskPartition) do
         for ii,vv in pairs (v) do 
             partitions[i] = {}
             partitions[i].name = v["name"]
             partitions[i].partId = v["partId"]
             partitions[i].type = db.getAttribute ("diskMgmtPartition", "partId", partitions[i].partId, "partFSFormat")
             partitions[i].size = v["size"]
             partitions[i].usage = tonumber(v["partUsage"])
             partitions[i].usedSpace = v["usedSpace"]
             partitions[i].freeSpace = v["freeSpace"]
         end
     end


     for i,v in ipairs (diskPartition) do
         for ii,vv in pairs (v) do 
             partitionTbl[i] = {}
             partitionTbl[i].name = v["name"]
             partitionTbl[i].partId = v["partId"]
             partitionTbl[i].type = db.getAttribute ("diskMgmtPartition", "partId", partitions[i].partId, "partFSFormat")
             partitionTbl[i].size = v["size"]
             partitionTbl[i].usage = tonumber(v["partUsage"])
             partitionTbl[i].usedSpace = v["usedSpace"]
             partitionTbl[i].freeSpace = v["freeSpace"]
         end
     end

    return "OK","STATUS_OK", partitions , partitionTbl
end

--*****************************************************************************
-- gui.administration.disks.trGet () - gets info for given partitionID
--
-- This routine gets details for the disk attached for TR-140.
--
-- RETURNS: table with info table.

function gui.administration.disks.trGet (partId)
    
    -- local variables
    local index = 1
    local returnDisk = {}
    local tmp = "/tmp/"
    local vendor = ""
    local model = ""
    
    -- udev command to query attached disks.
    local query="udevadm info --query=all --name="
    
    local part = string.gsub (partId, "/dev/","")
    local file = tmp..part
    os.execute (query .. partId..">"..file)
    for line in io.lines(file) do
        if (string.find(line, "ID_VENDOR")) then
            returnDisk["vendor"] = string.gsub (line, "E: ID_VENDOR=", "")
        end
        if (string.find(line, "ID_MODEL")) then
            returnDisk["model"] = string.gsub (line, "E: ID_MODEL=", "")
        end
        if (string.find(line, "ID_SERIAL_SHORT")) then
            returnDisk["serialNumber"] = string.gsub (line, "E: ID_SERIAL_SHORT=", "")
        end
        if (string.find(line, "ID_BUS")) then
            returnDisk["connectionType"] = string.gsub (line, "E: ID_BUS=", "")
        end
    end
    
    return "OK","STATUS_OK",returnDisk
end

--*****************************************************************************
-- gui.administration.disks.dmsSettingGet () - gets info for given partitionID
--
-- This routine gets details for the disk attached for TR-140.
--
-- RETURNS: table with info table.

function gui.administration.disks.getDMSSetting ()
	if (util.fileExists ("/pfrm2.0/BRCMJCO300") or util.fileExists ("/pfrm2.0/HW_JCO410") or util.fileExists ("/pfrm2.0/HW_JCE410") or util.fileExists("/pfrm2.0/HW_JCO4032") or util.fileExists("/pfrm2.0/HW_JCOW407") or util.fileExists("/pfrm2.0/HW_JCOW402")) then
    local status
    local dmsTbl = {}
    local nilTbl = {}
    local cfgTbl = {}
    local confTbl = {}
    local rcvTbl = {}
    local dmsSettingTbl = {}
    local query = "_ROWID_=1"
    local index = 1

    confTbl[index] = {}
    confTbl[index]["ParamName"] = "Device.X_RJIL_DMS_MediaShare.DMS.FriendlyName"
    confTbl[index]["PartyName"] = "DMS"
    index = index + 1

    confTbl[index] = {}
    confTbl[index]["ParamName"] = "Device.X_RJIL_DMS_MediaShare.DMS.DMS_Enabled"
    confTbl[index]["PartyName"] = "DMS"
    index = index + 1
    
    confTbl[index] = {}
    confTbl[index]["ParamName"] = "Device.X_RJIL_DMS_MediaShare.DMS.ContentAggregation_Enabled"
    confTbl[index]["PartyName"] = "DMS"
    index = index + 1
   
    -- do not call gui.administration.tr069ThirdPartyConfiguration.get API until
    -- dimclient has initialised threads for third party APPs
    if(util.fileExists("/tmp/trThirdPartyInitDone.txt")) then
    status, rcvTbl = gui.administration.tr069ThirdPartyConfiguration.get (confTbl) 
    for i, v in pairs (rcvTbl) do
        if (v.Status ~= "ERROR") then
            if (string.find (v.ParamName, "FriendlyName")) then
                cfgTbl["friendlyName"] = v.ParamValue
            end
            if (string.find (v.ParamName, "DMS_Enabled")) then
                cfgTbl["dmsEnable"] = v.ParamValue
            end
            if (string.find (v.ParamName, "ContentAggregation_Enabled")) then
                cfgTbl["contentAggregation"] = v.ParamValue
            end
        else
            if (string.find (v.ParamName, "FriendlyName")) then
                cfgTbl["friendlyName"] = ""
            end
            if (string.find (v.ParamName, "DMS_Enabled")) then
                cfgTbl["dmsEnable"] = "0"
            end
            if (string.find (v.ParamName, "ContentAggregation_Enabled")) then
                cfgTbl["contentAggregation"] = "0"
            end
	end
    end
    end

    return "OK", "STATUS_OK", cfgTbl

	else

    local dmsTbl = {}
    local nilTbl = {}
    local cfgTbl = {}
    local dmsSettingTbl = {}
    local query = "_ROWID_=1"

    dmsTbl = db.getRowWhere ("dmsServerSettings", query, false)
    if (dmsTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN", nilTbl 
    end

    cfgTbl["dmsEnable"] = dmsTbl["serverEnable"]
   
    dmsSettingTbl = db.getRowWhere ("dmsServerConfig", query, false)
    if (dmsSettingTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN", nilTbl 
    end
    -- get content aggregation path
    errorFlag, statusCode, diskTable = gui.administration.disks.get ()
    if (diskTable == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN", nilTbl 
    end

    query = "mntDir='" .. dmsSettingTbl["CAPath"] .. "'"                            
    local diskPartTbl = db.getRowWhere ("diskMgmtPartition", query, false)
    for i,v in pairs (diskTable) do
        if (diskPartTbl ~= nil) then
            if (diskPartTbl.diskId == v.diskId) then
                contentAggrPath = v.name                                     
            end
        else
            contentAggrPath = "No USB Attached"
        end
    end

    cfgTbl["contentAggregation"] = dmsSettingTbl["CAEnable"]
    cfgTbl["contentaggregationPath"] = contentAggrPath
    cfgTbl["friendlyName"] = util.filterXSSChars (dmsSettingTbl["friendlyName"])
    if (dmsSettingTbl["indexMode"] == "1") then
        cfgTbl["contentTreeMode"] = "auto"
    else
        cfgTbl["contentTreeMode"] = "Refresh"
    end
    cfgTbl["shareMode"] = dmsSettingTbl["shared"]
    cfgTbl["deviceParentalLevel"] = dmsSettingTbl["pgDefDeviceLevel"]
    cfgTbl["contentParentalLevel"] = dmsSettingTbl["pgDefContentLevel"]


    return "OK", "STATUS_OK", cfgTbl
	end


end

--*****************************************************************************
-- gui.administration.disks.dmsSettingGet () - gets info for given partitionID
--
-- This routine gets details for the disk attached for TR-140.
--
-- RETURNS: table with info table.

function gui.administration.disks.getDMSSettingStatus ()
	if (util.fileExists ("/pfrm2.0/BRCMJCO300") or util.fileExists ("/pfrm2.0/HW_JCO410") or util.fileExists ("/pfrm2.0/HW_JCE410") or util.fileExists("/pfrm2.0/HW_JCO4032") or util.fileExists("/pfrm2.0/HW_JCOW407") or util.fileExists("/pfrm2.0/HW_JCOW402")) then
    local status
    local dmsTbl = {}
    local nilTbl = {}
    local cfgTbl = {}
    local confTbl = {}
    local rcvTbl = {}
    local dmsSettingTbl = {}
    local query = "_ROWID_=1"
    local index = 1

    --confTbl[index] = {}
    --confTbl[index]["ParamName"] = "Device.X_RJIL_DMS_MediaShare.DMS.DMS_Enabled"
    --confTbl[index]["PartyName"] = "DMS"
    --index = index + 1
    
    -- do not call gui.administration.tr069ThirdPartyConfiguration.get API until
    -- dimclient has initialised threads for third party APPs
    --if(util.fileExists("/tmp/trThirdPartyInitDone.txt")) then
    --status, rcvTbl = gui.administration.tr069ThirdPartyConfiguration.get (confTbl) 
    --for i, v in pairs (rcvTbl) do
    --    if (v.Status ~= "ERROR") then
    --        if (string.find (v.ParamName, "DMS_Enabled")) then
     --           cfgTbl["dmsEnable"] = v.ParamValue
     --       end
     --   else
     --       if (string.find (v.ParamName, "DMS_Enabled")) then
      --          cfgTbl["dmsEnable"] = "0"
      --      end
	--end
    --end
   -- end
    os.execute ("cat /flash/dms_xml/access_conf.xml  | grep -i enabled |  cut -f2 -d'>' | cut -f1 -d'<' > /tmp/dmsStatusDashboard" )
    local dmsStatusVal = ""        
    dmsF = io.open("/tmp/dmsStatusDashboard","r")
    if(dmsF ~= nil) then
         dmsStatusVal = dmsF:read("*line")
         dmsF:close()
    end
    cfgTbl["dmsEnable"] = dmsStatusVal

    return "OK", "STATUS_OK", cfgTbl

	else

    local dmsTbl = {}
    local nilTbl = {}
    local cfgTbl = {}
    local dmsSettingTbl = {}
    local query = "_ROWID_=1"

    dmsTbl = db.getRowWhere ("dmsServerSettings", query, false)
    if (dmsTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN", nilTbl 
    end

    cfgTbl["dmsEnable"] = dmsTbl["serverEnable"]
   
    dmsSettingTbl = db.getRowWhere ("dmsServerConfig", query, false)
    if (dmsSettingTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN", nilTbl 
    end

    return "OK", "STATUS_OK", cfgTbl
	end


end
--*****************************************************************************
-- gui.administration.disks.dmsSettingSet () - gets info for given partitionID
--
-- This routine gets details for the disk attached for TR-140.
--
-- RETURNS: table with info table.

function gui.administration.disks.setDMSSetting (inputTable)
	if (util.fileExists ("/pfrm2.0/BRCMJCO300") or util.fileExists ("/pfrm2.0/HW_JCO410") or util.fileExists ("/pfrm2.0/HW_JCE410") or util.fileExists("/pfrm2.0/HW_JCO4032") or util.fileExists("/pfrm2.0/HW_JCOW407") or util.fileExists("/pfrm2.0/HW_JCOW402")) then
    local dmsTbl = {}
    local nilTbl = {}
    local cfgTbl = {}
    local status
    local errMsg
    local dmsSettingTbl = {}
    local changed = 0
    local dmsFriendlyName = 0
    local index = 1
    local query = "_ROWID_=1"

    status, errMsg, dmsTbl = gui.administration.disks.getDMSSetting ()

    if (inputTable["dmsEnable"] ~= nil) then
        if (inputTable["dmsEnable"] ~= dmsTbl["dmsEnable"]) then
            cfgTbl[index] = {}
            cfgTbl[index]["ParamName"] = "Device.X_RJIL_DMS_MediaShare.DMS.DMS_Enabled"
            cfgTbl[index]["PartyName"] = "DMS"
	    cfgTbl[index]["ParamValue"] = inputTable["dmsEnable"]
            index = index + 1
            changed = 1
        end
    end

    if (inputTable["friendlyName"] ~= nil) then
        if (inputTable["friendlyName"] ~= dmsTbl["friendlyName"]) then
	    cfgTbl[index] = {}
	    cfgTbl[index]["ParamName"] = "Device.X_RJIL_DMS_MediaShare.DMS.FriendlyName"
	    cfgTbl[index]["PartyName"] = "DMS"
	    cfgTbl[index]["ParamValue"] = inputTable["friendlyName"]
	    index = index + 1
            changed = 1
        end
    end
   
    if (inputTable["contentAggregation"] ~= nil) then
        if (inputTable["contentAggregation"] ~= dmsTbl["contentAggregation"]) then
	    cfgTbl[index] = {}
	    cfgTbl[index]["ParamName"] = "Device.X_RJIL_DMS_MediaShare.DMS.ContentAggregation_Enabled"
	    cfgTbl[index]["PartyName"] = "DMS"
	    cfgTbl[index]["ParamValue"] = inputTable["contentAggregation"]
	    index = index + 1
            changed = 1
        end
    end
   
    if(changed == 1) then 
		status, cfgTbl = gui.administration.tr069ThirdPartyConfiguration.set (cfgTbl)
		for i, v in pairs (cfgTbl) do
			if (v.Status == "ERROR") then
				if (string.find (v.ParamName, "FriendlyName")) then
					return "ERROR", "DMS failed to apply configuration for 'FriendlyName'"
				end
			end
		end
    end

    return "OK", "STATUS_OK"

	else

    local dmsTbl = {}
    local nilTbl = {}
    local cfgTbl = {}
    local dmsSettingTbl = {}
    local dmsChanged = 0
    local dmsCfgChanged = 0
    local diskID
    local query = "_ROWID_=1"

    dmsTbl = db.getRowWhere ("dmsServerSettings", query, false)
    if (dmsTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN" 
    end

    dmsSettingTbl = db.getRowWhere ("dmsServerConfig", query, false)
    if (dmsSettingTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    if (inputTable["contentaggregationPath"] ~= nil) then
        if (inputTable["contentaggregationPath"] ~= dmsSettingTbl ["CAPath"]) then
            local errorFlag, statusCode, diskTable = gui.administration.disks.get ()
            if (diskTable ~= nil) then
                local name = inputTable["contentaggregationPath"]
                for i,v in pairs (diskTable) do
                    if (name == v.name) then
                        diskID = v.diskId
                    end
                end
                local query = "diskId='"..diskID .. "'"                                            
                local diskPartTbl = db.getRowWhere ("diskMgmtPartition", query, false)
		if (diskPartTbl ~= nil) then
                    dmsSettingTbl ["CAPath"] = diskPartTbl.mntDir
		else
		    dmsSettingTbl ["CAPath"] = ""
		end
                dmsCfgChanged = 1
            end
        end
    end

    if (inputTable["dmsEnable"] ~= nil) then
        if (inputTable["dmsEnable"] ~= dmsTbl["serverEnable"]) then
            dmsTbl["serverEnable"] = inputTable["dmsEnable"]
            dmsChanged = 1
        end
    end
    
    if (inputTable["contentAggregation"] ~= nil) then
        if (inputTable["contentAggregation"] ~= dmsSettingTbl["CAEnable"]) then
            dmsSettingTbl["CAEnable"] = inputTable["contentAggregation"]
            dmsCfgChanged = 1
        end
    end

    if (inputTable["friendlyName"] ~= nil) then
        if (inputTable["friendlyName"] ~= dmsSettingTbl["friendlyName"]) then
            dmsSettingTbl["friendlyName"] = inputTable["friendlyName"]
            dmsCfgChanged = 1
        end
    end
    if (inputTable["contentTreeMode"] ~= nil) then
        if (inputTable["contentTreeMode"] == "auto") then
            dmsSettingTbl["indexMode"] = "1"
        else
            dmsSettingTbl["indexMode"] = "1"
        end
        dmsCfgChanged = 1
    end
    if (inputTable["shareMode"] ~= nil) then
        if (inputTable["shareMode"] ~= dmsSettingTbl["shared"]) then        
            dmsSettingTbl["shared"] = inputTable["shareMode"]
            dmsCfgChanged = 1
        end
    end
    if (inputTable["deviceParentalLevel"] ~= nil) then
        if (inputTable["deviceParentalLevel"] ~= dmsSettingTbl["pgDefDeviceLevel"]) then        
            dmsSettingTbl["pgDefDeviceLevel"] = inputTable["deviceParentalLevel"]
            if (tonumber(inputTable["deviceParentalLevel"]) > tonumber(dmsSettingTbl["pgDefContentLevel"])) then
                dmsSettingTbl["pgDefContentLevel"] = inputTable["deviceParentalLevel"]
            end
            dmsCfgChanged = 1
        end
    end
    if (inputTable["contentParentalLevel"] ~= nil) then
        if (inputTable["contentParentalLevel"] ~= dmsSettingTbl["pgDefContentLevel"]) then        
            dmsSettingTbl["pgDefContentLevel"] = inputTable["contentParentalLevel"]
            dmsCfgChanged = 1
        end
    end
    
    if (dmsChanged == 1 or dmsCfgChanged == 1) then
        db.beginTransaction() -- begin transcation
    end

    if (dmsChanged == 1) then
        dmsTbl = util.addPrefix (dmsTbl, "dmsServerSettings.")
        valid = db.update("dmsServerSettings", dmsTbl, 1)
        
        if (valid) then
            db.commitTransaction()
            db.save2()
            return "OK", "STATUS_OK"
        else
            db.rollback()
            return "ERROR", "DMS Failed to save Configuration. Please retry again."
        end
    end

    if (dmsCfgChanged == 1) then
        dmsSettingTbl = util.addPrefix (dmsSettingTbl, "dmsServerConfig.")
        valid = db.update("dmsServerConfig", dmsSettingTbl, 1)
        
        if (valid) then
            db.commitTransaction()
            db.save2()
            return "OK", "STATUS_OK"
        else
            db.rollback()
            return "ERROR", "DMS Failed to save Configuration. Please retry again."
        end
    end

    return "OK", "STATUS_OK"
	end
end

--*****************************************************************************
-- gui.administration.disks.clientsEditSet () - gets info for given partitionID
--
-- This routine gets details for the disk attached for TR-140.
--
-- RETURNS: table with info table.

function gui.administration.disks.clientsEditSet (inputTable, operation)
    
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end 
   
    inputTable["devDelete"] = 0 
    -- setting configuration of DMC
    if (inputTable ~= nil) then
        if (inputTable["ClientMac"] ~= nil and inputTable["PCLevel"] ~= nil and inputTable["devDelete"] ~= nil) then
            os.execute ("/pfrm2.0/bin/mediaClientConfig " .. inputTable["ClientMac"] .." ".. inputTable["PCLevel"] .." ".. inputTable["devDelete"])
        end
    end

    return "OK", "STATUS_OK"
end

--*****************************************************************************
-- gui.administration.disks.clientsDelete () - gets info for given partitionID
--
-- This routine gets details for the disk attached for TR-140.
--
-- RETURNS: table with info table.

function gui.administration.disks.clientsDelete (rows, operation)

    require "teamf1lualib/util"
    require("teamf1lualib/LuaXml")

     -- check for privileges
     if (ACCESS_LEVEL ~= 0) then
         return "ACCESS_DENIED", "ADMIN_REQD"
     end

    local config = {}
    local returnTbl={}
    local xfile = xml.load("/var/twine/xml/pg_device_list.xml")
    if (xfile == nil) then
        return "ERROR", "Unable to load xml file"
    end

    for i,v in pairs (xfile) do
        config[i]= {}
        for p=1,7 do
            if (v[p] ~= nil and v[p][0] ~= nil and v[p][1] ~= nil) then
                config[i][v[p][0]]= v[p][1]
            end
        end
    end
    
    for i,v in pairs (config) do
        for p,q in pairs (rows) do    
            if (tonumber(i) == tonumber(p))then
                returnTbl["ClientMac"]   = v["mac_address"]
                returnTbl["PCLevel"]     = v["level"]
                returnTbl["devDelete"]   = 1
                -- deleting DMC from DMS Server configuration 
                os.execute ("/pfrm2.0/bin/mediaClientConfig " .. returnTbl["ClientMac"] .." ".. returnTbl["PCLevel"] .." ".. returnTbl["devDelete"])
            end
        end
    end 
     
   return "OK", "STATUS_OK"

end

--*****************************************************************************
-- gui.administration.disks.clientsEditGet () - gets info for given partitionID
--
-- This routine gets details for the disk attached for TR-140.
--
-- RETURNS: table with info table.

function gui.administration.disks.clientsEditGet (rowId)
    
    -- require
    require "teamf1lualib/util"
    require("teamf1lualib/LuaXml")

    local config = {}
    local returnTbl={}
    local xfile = xml.load("/var/twine/xml/pg_device_list.xml")
    if (xfile == nil) then
        return "ERROR", "Unable to load xml file"
    end

    for i,v in pairs (xfile) do
        config[i]= {}
        for p=1,7 do
            if (v[p] ~= nil and v[p][0] ~= nil and v[p][1] ~= nil) then
                config[i][v[p][0]]= v[p][1]
            end
        end
    end
    
    for i,v in pairs (config) do
        if (tonumber(i) == tonumber(rowId))then
            returnTbl["_ROWID_"]     = rowId
            returnTbl["Device"]      = rowId
            returnTbl["ClientMac"]   = v["mac_address"]
            returnTbl["Description"] = v["friendly_name"]
            returnTbl["PCLevel"]     = v["level"]
        end
    end

    return "OK", "STATUS_OK", returnTbl

end

--*****************************************************************************
-- gui.administration.disks.clientsGet () - gets info for given partitionID
--
-- This routine gets details for the disk attached for TR-140.
--
-- RETURNS: table with info table.

function gui.administration.disks.clientsGet ()

    -- require
    require "teamf1lualib/util"
    require("teamf1lualib/LuaXml")

    local config = {}
    local returnTbl={}
    local xfile = xml.load("/var/twine/xml/pg_device_list.xml")
    if (xfile == nil) then
        return "ERROR", "Unable to load xml file"
    end

    for i,v in pairs (xfile) do
        config[i]= {}
        for p=1,7 do
            if (v[p] ~= nil and v[p][0] ~= nil and v[p][1] ~= nil) then
                config[i][v[p][0]]= v[p][1]
            end
        end
    end
    
    for p,q in pairs (config) do
        if (p ~= 0) then
            returnTbl[p]            = {}
            returnTbl[p]["_ROWID_"]    = p
            returnTbl[p]["Device"]     = p
            returnTbl[p]["ClientMac"]  = q["mac_address"]
            returnTbl[p]["Description"]= q["friendly_name"]
            returnTbl[p]["PGLevel"]    = q["level"]
	    if (tonumber(returnTbl[p]["PGLevel"]) == 0)then
                returnTbl[p]["PCLevel"] =  "Disable"
            elseif(tonumber(returnTbl[p]["PGLevel"]) == 1)then
                returnTbl[p]["PCLevel"] =  "G"
            elseif(tonumber(returnTbl[p]["PGLevel"]) == 2)then
                returnTbl[p]["PCLevel"] =  "PG"
            elseif(tonumber(returnTbl[p]["PGLevel"]) == 3)then
                returnTbl[p]["PCLevel"] =  "PG-13"
            elseif(tonumber(returnTbl[p]["PGLevel"]) == 4)then
                returnTbl[p]["PCLevel"] =  "R"
            else
                returnTbl[p]["PCLevel"] =  "NC-17"
            end
        end
    end

    return "OK", "STATUS_OK", returnTbl 
    
end

--*****************************************************************************
-- gui.administration.disks.parentalGuidance.get () - gets info for given partitionID
--
-- This routine gets details for the disk attached for TR-140.
--
-- RETURNS: table with info table.

function gui.administration.disks.parentalGuidance.get ()
   require "teamf1lualib/mediaServerMgmt" 
    local returnDisk = {}
    
    os.execute ("/pfrm2.0/bin/mediaClientPGLevelRescan ")
    returnDisk = mediaServerMgmt.parentalGuidanceGet()

    return "OK", "STATUS_OK", returnDisk
end

--*****************************************************************************
-- gui.administration.disks.parentalGuidance.folderEditGet () - gets info for given partitionID
--
-- This routine gets details for the disk attached for TR-140.
--
-- RETURNS: table with info table.

function gui.administration.disks.parentalGuidance.folderEditGet (inputTable)
   require "teamf1lualib/mediaServerMgmt" 
    local returnDisk = {}
    local diskInfo = {}
    local parentName
    local objID
    local pcLevel
	local pageContent = 0
	local index = 0
    
    diskInfo = mediaServerMgmt.parentalGuidanceGet()

    if (diskInfo ~= nil) then
        for i,v in pairs (diskInfo) do
            if (v.objID == inputTable.folderName) then
                parentName = v.parentName
                objID = v.objID
                pcLevel = v.PCLevel
                shared = v.shared
            end
            if (v.child ~= nil) then
                for p,q in pairs (v.child) do
                    if (q.objID == inputTable.folderName) then
                        parentName = q.name
                        objID = q.objID
                        pcLevel = q.PCLevel
                        shared = q.shared 
                    end
                end
            end
        end
    end
    
    if (inputTable.minIndex ~= nil) then
        index = inputTable.minIndex
        pageContent = 1
    elseif (inputTable.maxIndex ~= nil) then
        index = inputTable.maxIndex
        pageContent = 2
    end
    
    if (parentName ~= nil and objID ~= nil and pcLevel ~= nil and shared ~= nil ) then
	    os.execute ("/pfrm2.0/bin/mediaDMSSubPgLevelConfig '" .. parentName .. "' '" .. objID .. "' '" .. pcLevel .. "' '" .. shared .. "' '" .. index .. "' '" .. pageContent .. "'")
    end

    returnDisk = mediaServerMgmt.parentalGuidanceGet()

    return "OK", "STATUS_OK", returnDisk
end

--*****************************************************************************
-- gui.administration.disks.parentalGuidance.set () - gets info for given partitionID
--
-- This routine gets details for the disk attached for TR-140.
--
-- RETURNS: table with info table.

function gui.administration.disks.parentalGuidance.set (inputTbl)

   require "teamf1lualib/mediaServerMgmt" 
     local status = "ERROR"
     local errCode

    if (ACCESS_LEVEL ~=0) then 
      return "ACCESS_DENIED", "ADMIN_REQD"
    end
    
   status, errCode = mediaServerMgmt.parentalGuidanceSet(inputTbl)

    return "OK", "STATUS_OK"

end

--*****************************************************************************
-- gui.administration.disks.mediaShare.get () - gets info for given partitionID
--
-- This routine gets details for the disk attached for TR-140.
--
-- RETURNS: table with info table.

function gui.administration.disks.mediaShare.get ()
   require "teamf1lualib/mediaServerMgmt" 
    local returnDisk = {}
    
    os.execute ("/pfrm2.0/bin/mediaDMSShareClientsRescan")
    returnDisk = mediaServerMgmt.mediaShareGet()
    
    return "OK", "STATUS_OK", returnDisk
end

--*****************************************************************************
-- gui.administration.disks.mediaShare.set () - gets info for given partitionID
--
-- This routine gets details for the disk attached for TR-140.
--
-- RETURNS: table with info table.

function gui.administration.disks.mediaShare.set (inputTbl)

   require "teamf1lualib/mediaServerMgmt" 
     local status = "ERROR"
     local errCode

    if (ACCESS_LEVEL ~=0) then 
      return "ACCESS_DENIED", "ADMIN_REQD"
    end
    
    status, errCode = mediaServerMgmt.mediaShareSet(inputTbl)
    
    return "OK", "STATUS_OK"

end

--*****************************************************************************
-- gui.administration.disks.parentalGuidance.folderEditGet () - gets info for given partitionID
--
-- This routine gets details for the disk attached for TR-140.
--
-- RETURNS: table with info table.

function gui.administration.disks.mediaShare.folderEditGet (inputTable)
   require "teamf1lualib/mediaServerMgmt" 
    local returnDisk = {}
    local diskInfo = {}
    local parentName
    local objID
    local pcLevel
    local shared
    local pageContent = 0
	local index = 0

    diskInfo = mediaServerMgmt.mediaShareGet()

    if (diskInfo ~= nil) then
        for i,v in pairs (diskInfo) do
            if (v.objID == inputTable.folderName) then
                parentName = v.parentName
                objID = v.objID
                pcLevel = v.PCLevel
                shared = v.shared
            end
            if (v.child ~= nil) then
                for p,q in pairs (v.child) do
                    if (q.objID == inputTable.folderName) then
                        parentName = q.name
                        objID = q.objID
                        pcLevel = q.PCLevel
                        shared = q.shared 
                    end
                end
            end
        end
    end
   
    if (inputTable.minIndex ~= nil) then
        index = inputTable.minIndex
        pageContent = 1
    elseif (inputTable.maxIndex ~= nil) then
        index = inputTable.maxIndex
        pageContent = 2
    end

    if (parentName ~= nil and objID ~= nil  and pcLevel ~= nil and shared ~= nil) then  
       os.execute ("/pfrm2.0/bin/mediaDMSShareClientsConfig '" .. parentName .. "' '" .. objID .. "' '" .. pcLevel .. "' '" .. shared .. "' '" .. index .. "' '" .. pageContent .. "'")
    end
    returnDisk = mediaServerMgmt.mediaShareGet()

    return "OK", "STATUS_OK", returnDisk
end
