--[[ easyMeshClientInfo.lua - Handler for Easy Mesh ClientInfo Method.
--
-- Copyright (c) 2008-2019, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: easyMeshClientInfo.lua
-- Description: Handler for Easy Mesh ClientInfo Method.
-- 
-- modification history
-- --------------------
-- 01a, 10Jan2020, ar written.
--
--]]
require "teamf1lualib/ifDev"
require "teamf1lualib/easyMeshTopologyLib"
require "teamf1lualib/easyMeshClientInfoLib"

-- Client Request Object as defined by Customer Specification.
local ClientRequestObj = {
    ["Device_Type"]      = "Device_Type",
    ["Device_MAC"]  = "Device_MAC"
}

-- List of Client Tags as defined by Customer Specification.
local ClientResObj = {
    ["Result"] = "Result"
}

-- Initialise the ClientResponse_t Lua Table which will be coverted as JSON Object
local ClientResponse_t = {
    ["Result"] = "ERROR",
    ["Response_Code"] = "400",
    ["Error_Message"] = "Failed to get Client Info"
}

-- Supported Return Codes for "Client Response"
local ClientResponse_ReturnCodes = {
    ["OK"] = "OK",
    ["ERROR"] = "ERROR",
    ["SUCCESS"] = "Success",
    ["FAILED"]  = "Failed"
}

function getClientBaseMacType(mac)

    local baseMacType = nil
    local cmd1 = "ifconfig |grep HWa"
    os.execute(cmd1 .. " > /tmp/meshDevMacs")

    local cmd = "cat /tmp/meshDevMacs"
    local pipe = io.popen(cmd .. " 2>&1") -- redirect stderr to stdout
	local cmdOutput = pipe:read("*a")
	pipe:close()
    --print(cmdOutput)
	    
    output=string.gsub(cmdOutput, "\n$", "")
    intfData = util.split(output,"\n" )
    if(intfData ~= false) then
        for i,v in pairs(intfData) do
            intfInfo = util.split(v, "HWaddr")
            if (intfInfo ~= false) then
                currMac = string.gsub(intfInfo[2], " ", "")
                --mesh.dprintf(currMac)
                if((string.lower(currMac)) == (string.lower(mac))) then
                    intfName = util.split(intfInfo[1], " ")
                    if(intfName ~= false) then
                        --mesh.dprintf(intfName[1])
                        if((intfName[1]=="ra0") or (intfName[1]=="ra1") or (intfName[1]=="ra2") or (intfName[1]=="ra3")) then
                            baseMacType = "radio_24"
                        elseif ((intfName[1]=="rai0") or (intfName[1]=="rai1") or (intfName[1]=="rai2") or (intfName[1]=="rai3")) then
                            baseMacType = "radio_5"
                        else
                            baseMacType = ""
                        end
                    end
                    
                    break
                end
            end
        end
    end
    
    return baseMacType
end

function getClientAppInfo(client_info, clientNode)

    local clientInfo_t = {}
    clientInfo_t["MAC"]=""

    if (client_info["MAC"] == nil) then
        if(clientNode[MESH_OBJ_MAC] ~= nil) then
            clientInfo_t["MAC"] = clientNode[MESH_OBJ_MAC]
        end
    else
        clientInfo_t["MAC"] = client_info["MAC"]
    end

    if (clientInfo_t["MAC"] ~= nil) then
        local deviceIpAddr = db.getAttribute("LanHosts" ,"MACAddress",string.lower(clientInfo_t["MAC"]),"IPAddress")
        local deviceIpv6Addr = db.getAttribute("LanHosts" ,"MACAddress",string.lower(clientInfo_t["MAC"]),"IPv6Address")
        clientInfo_t["IPv4Address"] = deviceIpAddr or ""
        clientInfo_t["IPv6Address"] = deviceIpv6Addr or ""
    end

    if (client_info["ul_rate"] ~= nil) then
        clientInfo_t["LinkRateTx"] = client_info["ul_rate"]
    else
        clientInfo_t["LinkRateTx"] = "0"
    end

    if (client_info["dl_rate"] ~= nil) then
        clientInfo_t["LinkRateRx"] = client_info["dl_rate"]
    else
        clientInfo_t["LinkRateRx"] = "0"
    end

    if (clientNode[MESH_OBJ_LABEL] ~= nil) then
        labelInfo = util.split(clientNode[MESH_OBJ_LABEL],"\n")
        if (labelInfo ~= false) then
            if(labelInfo[1] == "") then
                local hostName = ""
                if(clientInfo_t["MAC"] ~= nil)then
                    hostName = db.getAttribute("LanHosts" ,"MACAddress",string.lower(clientInfo_t["MAC"]),"HostName") 
                end

                if(hostName == "") then
                    clientInfo_t["Device_NickName"] = clientInfo_t["MAC"] or ""
                else
                    clientInfo_t["Device_NickName"] = hostName or ""
                end
            else
                clientInfo_t["Device_NickName"] = labelInfo[1]
            end
        end
    end

    if (client_info["RRM"] ~= nil and client_info["BTM"] ~= nil) then
        if (client_info["RRM"] == "YES" and client_info["BTM"] == "YES") then
            clientInfo_t["client_type"] = "KV"
        else
            clientInfo_t["client_type"] = "NKV"
        end
    end
    --[[
    if(client_info["Currentchan"] ~= nil) then
        if (client_info["channelList"] ~= nil )then
            for i,chanInfo in pairs(client_info["channelList"]) do
                if(chanInfo["Channel"] == client_info["Currentchan"])then
                    local rssiInfo = util.split(chanInfo["RSSI"],"(")
                    if(rssiInfo ~= false) then
                        clientInfo_t["SignalStrength"] = rssiInfo[1]
                    end
                end
            end
        end
    end
    ]]--

    if (clientNode[MESH_OBJ_SIGNALSTRENGTH] ~= nil) then
        clientInfo_t["SignalStrength"] = clientNode[MESH_OBJ_SIGNALSTRENGTH]
    end


    clientInfo_t["Connection Type"] = "wireless"
    clientInfo_t["Port"] = ""

	if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then
		-- TODO: remove later . Adding for now for filling dummy Common:radios blocks for ont-dc
        clientInfo_t["Common"] = {}
        clientInfo_t["Common"]["radios"] = {}		
	end
    
    if ((clientNode[MESH_OBJ_BSSID] ~= nil) and 
        (clientNode[MESH_OBJ_MEDIUM] ~= nil)) then

        clientInfo_t["Common"] = {}
        clientInfo_t["Common"]["radios"] = {}

        local tmp = {}
        if (clientNode[MESH_OBJ_MEDIUM] == "2.4G") then
            tmp["radio_type"] = "radio_24"
            tmp["base_mac"] = clientNode[MESH_OBJ_BSSID]
        elseif(clientNode[MESH_OBJ_MEDIUM] == "5G") then
            tmp["radio_type"] = "radio_5"
            tmp["base_mac"] = clientNode[MESH_OBJ_BSSID]
        elseif(clientNode[MESH_OBJ_MEDIUM] == "Ethernet") then
            tmp["radio_type"] = ""
            tmp["base_mac"] = ""
            clientInfo_t["Connection Type"] = "Ethernet"
            clientInfo_t["client_type"] = ""
        end
        --mesh.dprintf(baseMacType)
        table.insert(clientInfo_t["Common"]["radios"],tmp)
    end

    return clientInfo_t
end

function getEasyMeshClientsInfoHandler(methodObj, meshRequestMethod)
    
    local deviceType    = methodObj["Device_Type"]
    local deviceMac     = methodObj["Device_MAC"]
    local clientInfo    = {}

    if ((deviceType == nil) or (deviceMac == nil) or 
	    ((deviceType ~= "CAP") and (deviceType ~= "RE")) or 
	    (ifDev.macValidate(deviceMac) ~= "OK") ) then
        ClientResponse_t["Result"] = ClientResponse_ReturnCodes["FAILED"]
        ClientResponse_t["Response_Code"] = "400"
        ClientResponse_t["Error_Message"] = "Bad Request"
        --mesh.sendResponse (ClientResponse_t) 
        return "ERROR", "INVALID_METHOD", ClientResponse_t
    end

    mesh.dprintf("Client Device Type: " .. deviceType)
    mesh.dprintf("Client Device MAC: " .. deviceMac)

    local meshTopology_t = {}
    local status , errorCode

    status, errorCode, meshTopology_t = easyMeshTopologyLib.getEasyMeshTopologyNodesAndEdges()
    if(status == "ERROR") then
        return status, errorCode, nil
    end

    local nodes_t = meshTopology_t["nodes"]
    local edges_t = meshTopology_t["edges"]
    local node_id = nil

    for i,node in pairs(nodes_t) do
       if ((node[MESH_OBJ_GROUP] == CAP_GROUP) or (node[MESH_OBJ_GROUP] == AGENT_GROUP)) then
           if (string.lower(node["mac"]) == string.lower(deviceMac)) then
               node_id = node[MESH_OBJ_ID]
               break
           end
       end
    end

    if (node_id == nil) then
        ClientResponse_t["Result"] = ClientResponse_ReturnCodes["FAILED"]
        ClientResponse_t["Response_Code"] = "400"
        ClientResponse_t["Error_Message"] = "Unable to get Clients Info"
        --mesh.sendResponse (ClientResponse_t) 
        return "ERROR", "INVALID_METHOD", ClientResponse_t
    end

    ClientResponse_t["Clients"] = {}
    local staCount = 0

    for i,edge in pairs(edges_t) do
        if (tonumber(edge[PARENT_EDGE]) == tonumber(node_id)) then
            for i,node in pairs(nodes_t) do
                if (node[MESH_OBJ_GROUP] == STA_GROUP) then
                    if (edge[CHILD_EDGE] == node[MESH_OBJ_ID]) then
                        local client_info = getClientInfo(node[MESH_OBJ_MAC])
                        if (client_info ~= nil) then
                            local staAppInfo = getClientAppInfo(client_info, node)
                            if (staAppInfo ~= nil) then
                                table.insert(ClientResponse_t["Clients"],staAppInfo)
                                staCount = staCount+1
                            end
                        end
                    end
                end
            end
        end
    end

    ClientResponse_t["Result"] = ClientResponse_ReturnCodes["OK"]
    ClientResponse_t["Device_MAC"] = deviceMac
    ClientResponse_t["Client_Numbers"] = tostring(staCount)
    ClientResponse_t["Response_Code"] = "200"
    ClientResponse_t["Error_Message"] = nil

    --mesh.sendResponse (ClientResponse_t) 
    return "OK", "SUCCESS", ClientResponse_t
end

meshRequestMethodsList["Client"]["methodHandler"] = getEasyMeshClientsInfoHandler
