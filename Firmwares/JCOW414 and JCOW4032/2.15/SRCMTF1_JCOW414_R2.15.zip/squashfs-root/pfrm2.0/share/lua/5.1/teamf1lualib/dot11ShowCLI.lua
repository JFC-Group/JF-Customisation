-- dot11ShowCLI.lua
-- Gaurav Mathur
-- TeamF1
-- www.TeamF1.com

-- Copyright (c) 2017, TeamF1 Networks Pvt. Ltd. 
-- (Subsidiary of D-Link India)

-- Modification History
-- 17Apr18,swr Changes for SPR 63646(csv result format)
-- 08Aug17,swr Changes for SPR 60819(health monitoring)
-- 24dec07,gnm Added dot11RadioCountryGet(); Modified
--	       dot11RadioAllGet() and dot11RadioSingleGet() to display
--	       current channel from the configuredChannel field;
--	       Modified dot11RadioGet() -- added call to dot11RadioCountryGet()
-- 23dec07,gnm Modified dot11ProfileQoSConfigGet and dot11ProfileDSCPMapGet to add
--	       checks for non-existant profiles; Modified dot11IAPPGet
--	       to read IAPP secret from the correct table; Modified
--             dot11StatsGet() to update system stats after command is
--             executed.
-- 06nov07 gnm written
--
-- Description
-- CLI DOT11 get and set routines

--require "teamf1lualib/dot11View"

--
--
function dot11RAPDetAllGet ()
    local resultTab = {}
    local rapTab = db.getRowsWhere("dot11RogueAP", "rogueAP=1")
    
    for k,v in pairs(rapTab) do
        resTab.insertField (resultTab, "BSSID", v["dot11RogueAP.macAddress"])
	resTab.insertField (resultTab, "SSID", v["dot11RogueAP.SSID"])
	resTab.insertField (resultTab, "Security", v["dot11RogueAP.security"])
	resTab.insertField (resultTab, "Encryption", 
			   v["dot11RogueAP.pairwiseCiphers"])
	resTab.insertField (resultTab, "Authentication", 
			   v["dot11RogueAP.authMethods"])
    end
    return resultTab
end

--
--
function dot11RAPAllGet ()
    local resultTab = {}
    local rapTab = db.getRowsWhere("dot11RogueAP", "rogueAP=0")
    
    for k,v in pairs(rapTab) do
        resTab.insertField (resultTab, "BSSID", v["dot11RogueAP.macAddress"])
	resTab.insertField (resultTab, "SSID", v["dot11RogueAP.SSID"])
	resTab.insertField (resultTab, "Security", v["dot11RogueAP.security"])
	resTab.insertField (resultTab, "Encryption", 
			   v["dot11RogueAP.pairwiseCiphers"])
	resTab.insertField (resultTab, "Authentication", 
			   v["dot11RogueAP.authMethods"])
    end
    return resultTab
end
			         
--
--
function dot11APDetailedStatsGet (apName, radio)
    local resultTab = {}
    local statsTab = db.getTableWithJoin({"dot11VAP:dot11Interface:vapName"})
    local found = 0
    					  
    --find correct interface (VAP, radio pair) in the table
    for k,v in pairs(statsTab) do
	if v["dot11VAP.vapName"] == apName and
	   v["dot11Interface.radioNo"] == radio then
   	   found = 1
	   row = db.getRow("dot11VAPStats", "dot11VAPStats.interfaceName", 
		 v["dot11Interface.interfaceName"])
	   resTab.insertField (resultTab, "AP", v["dot11VAP.vapName"])
	   resTab.insertField (resultTab, "Radio", v["dot11Interface.radioNo"])
	   resTab.insertField (resultTab, "Interface", v["dot11Interface.interfaceName"])
	   if (row == nil) then break end
	   resTab.insertField (resultTab, "XXX", row["dot11VAPStats.is_rx_badversion"])
	   --todo: add other fields from dot11VAPStats here
	   break
	end
    end
    if (found ~= 1) then
        resTab.insertField (resultTab, "", "No interface corresponding to AP and Radio");
        return resultTab
    end
    return resultTab
end

--
--
function dot11APStatsGet (apName)
    local resultTab = {}
    local statsTab = db.getTableWithJoin({"dot11VAP:dot11Interface:vapName"})

    for k,v in pairs(statsTab) do
	local row = db.getRow("interfaceStats", "interfaceStats.interfaceName", 
		    v["dot11Interface.interfaceName"])		
	resTab.insertField (resultTab, "AP", v["dot11VAP.vapName"])
	resTab.insertField (resultTab, "Radio", v["dot11Interface.radioNo"])
	resTab.insertField (resultTab, "PktRx", row["interfaceStats.rx_packets"])
	resTab.insertField (resultTab, "PktTx", row["interfaceStats.tx_packets"])
	resTab.insertField (resultTab, "ByteRx", row["interfaceStats.rx_bytes"])
	resTab.insertField (resultTab, "ByteTx", row["interfaceStats.tx_bytes"])
	resTab.insertField (resultTab, "ErrRx", row["interfaceStats.rx_errors"])
	resTab.insertField (resultTab, "ErrTx", row["interfaceStats.tx_errors"])
	resTab.insertField (resultTab, "DropRx", row["interfaceStats.rx_dropped"])
	resTab.insertField (resultTab, "DropTx", row["interfaceStats.tx_dropped"])
	resTab.insertField (resultTab, "Mcast", row["interfaceStats.multicast"])
	resTab.insertField (resultTab, "Coll", row["interfaceStats.collisions"])
    end
    return resultTab
end

--
--
function dot11RadioCountryGet ()
    local resultTab = {}

    local countryDefcode = db.getAttribute ("dot11GlobalConfig",
			 "rowid", 1, "country");
    local country = db.getAttribute ("dot11Countries",
			 "countrycode", countryDefcode, "country");
    resTab.insertField (resultTab, "Country", country)
    return resultTab
end

--
--
function dot11RadioStatsGet (radioNum)
    local table = db.getTable("dot11Radio")
    local resultTab = {}

    for k,v in pairs(table) do
	local row = db.getRow("interfaceStats", "interfaceStats.interfaceName", 
	      v["dot11Radio.interfaceName"])
	row["dot11Radio.radioNo"] = v["dot11Radio.radioNo"]

	resTab.insertField (resultTab, "Radio", v["dot11Radio.radioNo"])
	resTab.insertField (resultTab, "PktRx", row["interfaceStats.rx_packets"])
	resTab.insertField (resultTab, "PktTx", row["interfaceStats.tx_packets"])
	resTab.insertField (resultTab, "ByteRx", row["interfaceStats.rx_bytes"])
	resTab.insertField (resultTab, "ByteTx", row["interfaceStats.tx_bytes"])
	resTab.insertField (resultTab, "ErrRx", row["interfaceStats.rx_errors"])
	resTab.insertField (resultTab, "ErrTx", row["interfaceStats.tx_errors"])
	resTab.insertField (resultTab, "DropRx", row["interfaceStats.rx_dropped"])
	resTab.insertField (resultTab, "DropTx", row["interfaceStats.tx_dropped"])
	resTab.insertField (resultTab, "Mcast", row["interfaceStats.multicast"])
	resTab.insertField (resultTab, "#Coll", row["interfaceStats.collisions"])
    end
    return resultTab
end

-- get the field values from the dbase tables
function dot11CardSingleGet (cardName)
    local resultTab = {}

    row = db.getRow ("dot11Card", "dot11Card.cardName", cardName)
    if (row == nil) then --sanity check
       resTab.insertField (resultTab, "", "No such card")
       return resultTab
    end

    resTab.insertField (resultTab, "Card", row["dot11Card.cardName"])
    resTab.insertField (resultTab, "Band", row["dot11Card.band"])
    
    resTab.insertYNField (resultTab, row["dot11Card.txEnabled"] == "1", "Tx Enable")
    resTab.insertYNField (resultTab, row["dot11Card.rxEnabled"] == "1", "Rx Enable")
    resTab.insertYNField (resultTab, row["dot11Card.agcEnabled"] == "1",
			  "AGC Enable")
    resTab.insertYNField (resultTab, row["dot11Card.txCancellation"] == "1",
			  "Tx Cancellation")
    resTab.insertField (resultTab, "Rx Max Gain", row["dot11Card.rxMaxGain"])
    resTab.insertField (resultTab, "Transmit LO", row["dot11Card.txLO"])
    resTab.insertField (resultTab, "Receive LO", row["dot11Card.rxLO"])

    return resultTab
end

-- get the field values from the dbase tables
function dot11CardAllGet ()
    local resultTab = {}
    local cardTab = db.getTable("dot11Card")

    for k,v in pairs(cardTab) do
        resTab.insertField (resultTab, "Card", v["dot11Card.cardName"])
	resTab.insertField (resultTab, "Band", v["dot11Card.band"])
    end
    return resultTab
end

-- get IP TOS/DiffServ mapping for a profile
function dot11ProfileDSCPMapGet (profileName)
    local resultTab = {}
    local fieldNamePrefix = "dscpCosMap" 
    local fieldNameSuffix = 0 
    local fieldNameSuffixMax = 63
    local fieldName = "" 
    local val = ""

    row = db.getRow ("dot11Profile", "dot11Profile.profileName", profileName)
    if (row == nil) then --sanity check
       resTab.insertField (resultTab, "", "No such profile")
       return resultTab
    end
    
    while (fieldNameSuffix <= fieldNameSuffixMax) do
	fieldName = fieldNamePrefix .. fieldNameSuffix
	val = row["dot11Profile." .. fieldName]
	if (string.lower(val) ~= "default") then
	   resTab.insertField (resultTab, "IP DSCP/TOS", fieldNameSuffix)
	   resTab.insertField (resultTab, "Class Of Service", val)	   
        end
	fieldNameSuffix = fieldNameSuffix + 1
    end
    return resultTab
end

--get QoS configuration details for a profile
function dot11ProfileQoSConfigGet (profileName)
    local resultTab = {}    

    row = db.getRow("dot11Profile", "dot11Profile.profileName", profileName)
    if (row == nil) then --sanity check
       resTab.insertField (resultTab, "", "No such profile")
       return resultTab
    end

    resTab.insertYNField (resultTab, row["dot11Profile.qosEnable"] == "1", 
			 "QoS Enable")
    resTab.insertField (resultTab, "Default Class Of Service", 
		       row["dot11Profile.defaultCos"])
    return resultTab
end
      
-- get the field values from the dbase tables
function dot11ProfileSingleGet (profileName, displayQoS)
    local resultTab = {}

    if displayQoS ~= "Y" and displayQoS ~= "N" then --sanity check
       displayQoS = "N"
    end   
    row = db.getRow ("dot11Profile", "dot11Profile.profileName",
		     profileName)
    if (row == nil) then --sanity check
       resTab.insertField (resultTab, "", "No such profile")
       return resultTab
    end
		     
    resTab.insertField (resultTab, "Profile Name", row["dot11Profile.profileName"])
    resTab.insertField (resultTab, "SSID", row["dot11Profile.ssid"])
    if (row["dot11Profile.broadcastSSID"] == "1") then
       resTab.insertField (resultTab, "Broadcast SSID", "Enabled")
    else
        resTab.insertField (resultTab, "Broadcast SSID", "Disabled")
    end
    security = row["dot11Profile.security"]
    resTab.insertField (resultTab, "Security", security)
    if (security == "WEP") then 
	resTab.insertField (resultTab, "Authentication", 
			   row["dot11Profile.wepAuth"])
        resTab.insertField (resultTab, "Encryption",
			   row["dot11Profile.groupCipher"])
        local idx = row["dot11Profile.defWepkeyIdx"]
	resTab.insertField (resultTab, "WEP Key " .. (idx+1),
			       row["dot11Profile.wepkey" .. idx])
    elseif (security == "WPA") or (security == "WPA2") or 
	   (security == "WPA+WPA2") then
	resTab.insertField (resultTab, "Authentication", 
			   row["dot11Profile.authMethods"])
        resTab.insertField (resultTab, "Encryption",
			   row["dot11Profile.pairwiseCiphers"])
	resTab.insertField (resultTab, "WPA Password", 
			   row["dot11Profile.pskPassAscii"])
    end
              

    resTab.insertField (resultTab, 
		       "Association Timeout Interval (in Seconds)", 
		       row["dot11Profile.assocTimeout"])
    resTab.insertField (resultTab, 
		       "Authentication Timeout Interval (in Seconds)", 
		       row["dot11Profile.authTimeout"])
    resTab.insertField (resultTab, 
		       "Group Key Refresh Interval (in Seconds)", 
		       row["dot11Profile.groupKeyUpdateInterval"])
    resTab.insertField (resultTab, 
		       "Group Key Refresh Interval (in Seconds)", 
		       row["dot11Profile.groupKeyUpdateInterval"])
    resTab.insertField (resultTab, "PMKSA LifeTime (in Seconds)", 		       
		       row["dot11Profile.pmksaLifetime"])
    resTab.insertField (resultTab, 
		       "802.1X Re-authentication Interval (in Seconds)",
		       row["dot11Profile.dot1xReauthInterval"])
    return resultTab
     
end

-- get the field values from the dbase tables
function dot11ProfileAllGet ()
    local i = 0
    local resultTab = {}
    local profileTab = db.getTable("dot11Profile")

    for k,v in pairs(profileTab) do
	i = i + 1
	local row = profileTab[i]

	resTab.insertField (resultTab, "Profile Name", row["dot11Profile.profileName"])
	resTab.insertField (resultTab, "SSID", row["dot11Profile.ssid"])
	resTab.insertField (resultTab, "Security", row["dot11Profile.security"])

	local encryption = row["dot11Profile.pairwiseCiphers"] or ""
	local authentication = row["dot11Profile.authMethods"] or ""

	if (row["dot11Profile.security"] == "OPEN")  then 
	    encryption = "NONE"
	    authentication = "NONE"
	elseif (row["dot11Profile.security"] == "WEP") then
	       encryption = row["dot11Profile.groupCipher"] or ""
	       authentication = row["dot11Profile.wepAuth"] or ""
	end
	resTab.insertField (resultTab, "Encryption", encryption)
	resTab.insertField (resultTab, "Authentication", authentication)
    end
    return resultTab
end

-- get the field values from the dbase tables
function dot11RadioAllGet ()
    local i = 0
    local resultTab = {}
    local radioTable = db.getTableWithJoin({"dot11Radio:dot11Card:cardNo"})   

    for k,v in pairs(radioTable) do
	i = i + 1
	local row = radioTable[i]

	resTab.insertField (resultTab, "Radio", row["dot11Radio.radioNo"])
	resTab.insertField (resultTab, "Card Name", row["dot11Card.cardName"])
	resTab.insertField (resultTab, "Path", row["dot11Radio.path"])
	if (row["dot11Radio.rogueAPEnabled"] == "0") then
	    resTab.insertField (resultTab, "Rogue AP Enabled", "No")
	else
	    resTab.insertField (resultTab, "Rogue AP Enabled", "Yes")
	end
	-- ToDo: This will be changed to the field 'currentChannel' once
	-- the backend implementation is fixed to update that field in
	-- the database with the value of the current channel.
        resTab.insertField (resultTab, "Channel", row["dot11Radio.configuredChannel"])
   end
   return (resultTab)
end

-- get the access points associated with a radio
function dot11RadioAPGet (radioNum)
    local resultTab = {}

    local ifaceTab = db.getRowsWhere("dot11Interface", 
		   "radioNo = '".. radioNum .. "' AND vapName <> 'unused'")
    for k, v in pairs(ifaceTab) do
	local row = db.getRowWithJoin({"dot11VAP:dot11Profile:profileName"}, 
	    "dot11VAP.vapName", v["dot11Interface.vapName"])

	resTab.insertField (resultTab, "AP Name", row["dot11VAP.vapName"])
	resTab.insertField (resultTab, "BSSID", v["dot11Interface.macAddress"])
	resTab.insertField (resultTab, "SSID", row["dot11Profile.ssid"])

	local profileProps = ""
	if (row["dot11Profile.security"] == "OPEN" or 
	   row["dot11Profile.security"] == "WEP") then
		profileProps = row["dot11Profile.security"]
	else
		profileProps = row["dot11Profile.security"] .. " / " .. 
		   row["dot11Profile.pairwiseCiphers"] .. " / " .. 
		   row["dot11Profile.authMethods"]
	end
	local tmpStr = row["dot11VAP.profileName"] .. "(" .. 
		     profileProps .. ")"
	resTab.insertField (resultTab, "Profile", tmpStr)
	resTab.insertField (resultTab, "VLAN ID", row["dot11VAP.vlanId"])
    end
    return resultTab
end

-- get the field values from the dbase tables
function dot11RadioSingleGet (radioNum)
    local i = 0
    local resultTab = {}

    --fetch radio information from the database
    local radioTable = db.getRowWithJoin ({"dot11Radio:dot11Card:cardNo"}, 
    		       "dot11Radio.radioNo", radioNum)
    if (radioTable == nil) then  --sanity check
	resTab.insertField (resultTab, "", "No such radio")
	return resultTab
    end 
	
    resTab.insertField (resultTab, "Radio", radioTable["dot11Radio.radioNo"])
    resTab.insertField (resultTab, "Card Name", radioTable["dot11Card.cardName"])
    resTab.insertField (resultTab, "Path", radioTable["dot11Radio.path"])

    if (radioTable["dot11Radio.rogueAPEnabled"] == "0") then
        resTab.insertField (resultTab, "Rogue AP Enabled", "No")
    else
	resTab.insertField (resultTab, "Rogue AP Enabled", "Yes")
    end
    if (radioTable["dot11Radio.configuredChannel"] == "0") then
        resTab.insertField (resultTab, "Channel", "Auto")
    else
        resTab.insertField (resultTab, "Channel", 
			   radioTable["dot11Radio.configuredChannel"])
    end
    -- ToDo: This will be changed to the field 'currentChannel' once
    -- the backend implementation is fixed to update that field in
    -- the database with the value of the current channel.
    resTab.insertField (resultTab, "Current Channel", 
			   radioTable["dot11Radio.configuredChannel"])
    resTab.insertField (resultTab, "TX Power", radioTable["dot11Radio.txPower"])
    resTab.insertField (resultTab, "RX Diversity", 
		       radioTable["dot11Radio.rxDiversity"])

   return (resultTab)
end

-- get the details for all access points configued
function dot11APAllGet ()
    local i = 0
    local resultTab = {}
    
    local apTable = db.getTableWithJoin({"dot11VAP:dot11Profile:profileName"})
    if (apTable == nil) then --sanity check
       resTab.insertField (resultTab, "", "No APs Configured")
       return resultTab
    end
    for k,v in pairs(apTable) do
	local tempTable = db.getRows("dot11Interface", "dot11Interface.vapName", v["dot11VAP.vapName"])
	local radios = ""
	for kk,vv in pairs(tempTable) do
	    radios = radios .. vv["dot11Interface.radioNo"] .. ", "
	end
	radios = radios:sub(1, radios:len()-2) --shave last comma
	i = i + 1
	local row = apTable[i]

	resTab.insertField (resultTab, "APName", row["dot11VAP.vapName"])
	if (row["dot11VAP.vapEnabled"] == "0") then
	   resTab.insertField (resultTab, "Enabled", "N")
	else
	   resTab.insertField (resultTab, "Enabled", "Y")
	end
	resTab.insertField (resultTab, "SSID", row["dot11Profile.ssid"])
	if (row["dot11Profile.broadcastSSID"] == "0") then
	   resTab.insertField (resultTab, "Broadcast", "N")
	else
	   resTab.insertField (resultTab, "Broadcast", "Y")
	end

	local profileProps = ""
	if (row["dot11Profile.security"] == "OPEN" or 
	   row["dot11Profile.security"] == "WEP") then
	   profileProps = row["dot11Profile.security"]
	else
	   profileProps = row["dot11Profile.security"] .. " / "
			  .. row["dot11Profile.pairwiseCiphers"] .. " / "
			  .. row["dot11Profile.authMethods"]
	end
	tmpStr = row["dot11VAP.profileName"] .. "(" .. profileProps .. ")"
	resTab.insertField (resultTab, "Profile", tmpStr)
	resTab.insertField (resultTab, "Radios", radios)
	resTab.insertField (resultTab, "VLAN_ID",
			   row["dot11VAP.vlanId"])

    end
    return resultTab
end

-- get ACL policy details for an AP
local function dot11APACLget (apName)
    local idx = 1
    local resultTab = {} --table to store ACL info in

    local vapTab = db.getRow ("dot11VAP", "dot11VAP.vapName", apName)
    local aclTab = db.getRows ("dot11ACL", "dot11ACL.vapName", apName)

    if (vapTab ~= nil) then		    
    resTab.insertField (resultTab, "ACL Policy Status", vapTab["dot11VAP.defACLPolicy"])
    end

    for k,v in pairs(aclTab) do
	resTab.insertField (resultTab, "Host"..idx, v["dot11ACL.macAddress"])
	idx = idx + 1
    end
    return resultTab
end

-- get for the access point specified by the argument
local function dot11APSingleGet (apName)
    local i = 0
    local resultTab = {} --table to store AP info in
    local radios = ""

    local apTable = db.getRowWithJoin ({"dot11VAP:dot11Profile:profileName"}, 
		  "dot11VAP.vapName", apName)
    if (apTable == nil) then --sanity check
       resTab.insertField (resultTab, "", "No such AP")
       return resultTab
    end
    		  
    resTab.insertField (resultTab, "APName", apTable["dot11VAP.vapName"])
    if (apTable["dot11VAP.vapEnabled"] == "0") then
        resTab.insertField (resultTab, "Enabled", "N")
    else
        resTab.insertField (resultTab, "Enabled", "Y")
    end
    resTab.insertField (resultTab, "Role", apTable["dot11VAP.dot11Mode"])
    resTab.insertField (resultTab, "Profile", apTable["dot11VAP.profileName"])
    
    local tempTable = db.getRows("dot11Interface", "dot11Interface.vapName",
		      apTable["dot11VAP.vapName"])
    local radios = ""	
    for kk,vv in pairs(tempTable) do
	radios = radios .. vv["dot11Interface.radioNo"] .. ", "
    end
    radios = radios:sub(1, radios:len()-2) --shave last comma
    resTab.insertField (resultTab, "Radios", radios)
    resTab.insertField (resultTab, "Mode", apTable["dot11VAP.opMode"])
    resTab.insertField (resultTab, "VLAN Enabled", apTable["dot11VAP.vlanEnabled"])
    resTab.insertField (resultTab, "VLAN ID", db.getDefStr("vlan", "vlanId"))
    resTab.insertField (resultTab, "SSID", apTable["dot11Profile.ssid"])
    resTab.insertField (resultTab, "Max Clients", apTable["dot11VAP.maxClients"])
    resTab.insertField (resultTab, "Beacon Interval", apTable["dot11VAP.beaconInterval"])
    resTab.insertField (resultTab, "DTIM Interval", apTable["dot11VAP.dtimInterval"])
    resTab.insertField (resultTab, "RTS Threshold", apTable["dot11VAP.rtsThreshold"])
    resTab.insertField (resultTab, "Frag Threshold", apTable["dot11VAP.fragThreshold"])
    resTab.insertField (resultTab, "Preamble Mode", apTable["dot11VAP.preambleMode"])

    if (apTable["dot11VAP.rtsCtsProtect"] == "0") then
        resTab.insertField (resultTab, "RTS/CTS Protection", "Y")
    else
        resTab.insertField (resultTab, "RTS/CTS Protection", "N")
    end

    resTab.insertField (resultTab, "TX Power", apTable["dot11VAP.txPower"])
    resTab.insertField (resultTab, "Short Retry", apTable["dot11VAP.shortRetry"])
    resTab.insertField (resultTab, "Long Retry", apTable["dot11VAP.longRetry"])

    local rateStr = ""
	if (apTable["dot11VAP.rate1Mbps"] == "1") then
	   rateStr = rateStr .. " " .. "1"
    end
	if (apTable["dot11VAP.rate2Mbps"] == "1") then
	   rateStr = rateStr .. ", " .. "2"
    end
	if (apTable["dot11VAP.rate5_5Mbps"] == "1") then
	   rateStr = rateStr .. ", " .. "5.5"
    end
	if (apTable["dot11VAP.rate6Mbps"] == "1") then
	   rateStr = rateStr .. ", " .. "6"
    end
	if (apTable["dot11VAP.rate9Mbps"] == "1") then
	   rateStr = rateStr .. ", " .. "9"
    end
	if (apTable["dot11VAP.rate11Mbps"] == "1") then
	   rateStr = rateStr .. ", " .. "11"
    end
	if (apTable["dot11VAP.rate12Mbps"] == "1") then
	   rateStr = rateStr .. ", " .. "12"
    end
	if (apTable["dot11VAP.rate18Mbps"] == "1") then
	   rateStr = rateStr .. ", " .. "18"
    end
	if (apTable["dot11VAP.rate24Mbps"] == "1") then
	   rateStr = rateStr .. ", " .. "24"
    end
	if (apTable["dot11VAP.rate36Mbps"] == "1") then
	   rateStr = rateStr .. ", " .. "36"
    end
	if (apTable["dot11VAP.rate48Mbps"] == "1") then
	   rateStr = rateStr .. ", " .. "48"
    end
	if (apTable["dot11VAP.rate54Mbps"] == "1") then
	   rateStr = rateStr .. ", " .. "54"
    end
    resTab.insertField (resultTab, "Supported Rate", rateStr)
    return resultTab
end

--

-- This routine gets the statistics for a VAP defined by an Access
-- point identifier and the radio number. If both the access point
-- identifier and the radio number are not specified, this routine
-- will display statistics for all the VAPs

function dot11StatsGet (args)
    local apName = args[1]
    local radio = args[2]
    
    if (apName ~= "all" and radio ~= "-1") then
        resultTab = dot11APDetailedStatsGet (apName, radio)
	printLabel ("AP Detailed Statistics")
	resTab.print (resultTab, 0)
    else
        printLabel ("Radio Statistics")
	resultTab = dot11RadioStatsGet ()
        resTab.print (resultTab, 0)
	printLabel ("AP Statistics")
	resultTab = dot11APStatsGet ()
	resTab.print (resultTab, 0)
    end
    -- run program to read the stats and update DB
    local prog = db.getAttribute("environment", "name", "IFDEVSTATS_PROGRAM", "value")
    os.execute(prog .. " " .. DB_FILE_NAME)
end  

--
-- main function for wlan stats get
-- 
function dot11WlanStatsGet (args)
    require "teamf1lualib/gui"
    require "teamf1lualib/wireless"

   -- printLabel ("WLAN statistics")
    local resultTab = {}
    local wifiTotal = {}
    errorFlag, statusCode, wifiTable = gui.status.statistics.wifi.get ()
    wifiTotal = wifiTable.total
    
    local i = 0 
    local wifiStatsTable = wifiTable.statsTbl
    for k,v in pairs (wifiStatsTable) do
        i = i+1
        local wifiRow = wifiTable.statsTbl[i]
        if (wifiRow ~= nil) then
            resTab.insertField (resultTab, "AP Name", wifiRow["interface"])
            resTab.insertField (resultTab, "PktRx", wifiRow["rx_packets"])
            resTab.insertField (resultTab, "PktTx", wifiRow["tx_packets"])
            resTab.insertField (resultTab, "ByteRx", wifiRow["rx_bytes"])
            resTab.insertField (resultTab, "ByteTx", wifiRow["tx_bytes"])
            resTab.insertField (resultTab, "ErrRx", wifiRow["rx_errors"])
            resTab.insertField (resultTab, "ErrTx", wifiRow["tx_errors"])
            resTab.insertField (resultTab, "DropRx", wifiRow["rx_dropped"])
            resTab.insertField (resultTab, "DropTx", wifiRow["tx_dropped"])
            resTab.insertField (resultTab, "Mcast", wifiRow["multicast"])
        end
    end

    resTab.print (resultTab, 0)
end   

--
-- main function for dot11 clients get
-- 
function dot11ClientsGet (args)
    require "teamf1lualib/gui"
    require "teamf1lualib/wireless"

    printLabel ("WLAN clients")
    local resultTab = {}
    errorFlag, statusCode, dot11STATab = gui.wireless.clients.get()

    for k,v in pairs(dot11STATab) do
        resTab.insertField (resultTab, "AP Name", v["vapName"])
        resTab.insertField (resultTab, "MACAddress", v["macAddress"])
        resTab.insertField (resultTab, "Security", v["security"])
        resTab.insertField (resultTab, "Encryption", v["cipher"])
        resTab.insertField (resultTab, "Authentication", v["authentication"])
        resTab.insertField (resultTab, "Time Connected", v["timeConnected"])
    end

    resTab.print (resultTab, 0)
end   


--
-- main function for dot11 rogueap get
-- 
function dot11RogueAPGet (args)
    printLabel ("Authorized AP Mac Addresses")
    resultTab = dot11RAPAllGet ()
    resTab.print (resultTab, 0)
    printLabel ("Detected RogueAPs")
    resultTab = dot11RAPDetAllGet ()	
    resTab.print (resultTab, 0)
end   

--
-- main function for dot11 get
--
function dot11APGet (args)
   local apName = args[1]

   -- We build different types of tables depending on whether
   -- the AP name is given or not
   if (apName ~= "all") then
	printLabel ("AP Configuration")
	resultTab = dot11APSingleGet (apName)
	resTab.print (resultTab, 8)
	printLabel ("ACL Policy and MAC Addresses")
	resultTab = dot11APACLget (apName)
	resTab.print (resultTab, 8)
   else
	resultTab = dot11APAllGet ()
	resTab.print (resultTab, 8)
   end
   -- Now print the result table   
end

--
-- main function for dot11 radio get
-- 
function dot11RadioGet (args)
    local radioNum = args[1]
   
    -- We build different types of tables depending on whether
    -- the Radio number is given or not
    if (radioNum ~= "-1") then
        printLabel ("Radio Settings")
   	resultTab = dot11RadioSingleGet (radioNum)
	resTab.print (resultTab, 0)
	printLabel ("List of Access Points for Radio")
	resultTab = dot11RadioAPGet (radioNum)
	resTab.print (resultTab, 0)
    else
	printLabel ("Country Selection")
	resultTab = dot11RadioCountryGet ()
	resTab.print (resultTab, 0)
	printLabel ("Available Radios")
	resultTab = dot11RadioAllGet ()
	resTab.print (resultTab, 0)
    end
end   

--
-- main function for dot11 profile get
-- 
function dot11ProfileGet (args)
    local profileName = args[1]
    local displayQoS = args[2]   
    
    if (profileName ~= "all") then
   	resultTab = dot11ProfileSingleGet (profileName, displayQoS)
	printLabel ("Profile Configuration")
	resTab.print (resultTab, 0)
	if (displayQoS == "Y") then
	   printLabel ("Profile QoS Configuration")
	   resultTab = dot11ProfileQoSConfigGet (profileName)
	   resTab.print (resultTab, 0)
	   resultTab = dot11ProfileDSCPMapGet (profileName)
	   printLabel ("IP TOS/DiffServ Mapping (non default values)")
	   resTab.print (resultTab, 0)
        end
    else
	resultTab = dot11ProfileAllGet ()
        resTab.print (resultTab, 0)
    end
end   

--
-- main function for dot11 card get
-- 
function dot11CardGet (args)
    local cardId = args[1]

    if (cardId ~= "all") then
   	resultTab = dot11CardSingleGet (cardId)
	printLabel ("WLAN Card Settings")
	resTab.print (resultTab, 0)
    else
        printLabel ("WLAN Card Table")
	resultTab = dot11CardAllGet ()
        resTab.print (resultTab, 0)
    end
end   

--
--
function dot11IAPPGet(args)
    local resultTab = {}
    local bssidSecret = db.getAttribute("dot11GlobalConfig", "_ROWID_", "1",
	   "iappBssidSecret")

    resTab.insertField (resultTab, "BSSID Secret", bssidSecret)
    resTab.print (resultTab, 0)

    resultTab = {}   	 
    local table = db.getTableWithJoin({"dot11VAP:dot11Profile:profileName"})

    for _, row in pairs(table) do
	resTab.insertField (resultTab, "AP Name", row["dot11VAP.vapName"])
	resTab.insertField (resultTab, "VLAN", row["dot11VAP.vlanId"])
	resTab.insertYNField (resultTab, row["dot11VAP.iappEnabled"] == "1",
			     "IAPP Enabled")
    end

    printLabel ("Local AP Configuration")
    resTab.print (resultTab, 0)
    
    resultTab = {}   
    table = db.getTable("dot11IAPPRemoteAP")

    for _, row in pairs(table) do
    resTab.insertField (resultTab, "BSSID", row["dot11IAPPRemoteAP.bssid"])
    resTab.insertField (resultTab, "IP Address", row["dot11IAPPRemoteAP.ipAddr"])
    resTab.insertField (resultTab, "BSSID Secret", row["dot11IAPPRemoteAP.bssidSecret"])
    resTab.insertField (resultTab, "VLAN", row["dot11IAPPRemoteAP.vlanId"])
    resTab.insertYNField (resultTab, row["dot11IAPPRemoteAP.neighbor"] == "1", 
			 "Neighbor")
    end			 
    printLabel ("Remote AP Configuration")
    resTab.print (resultTab, 0)    			 
end

--
--
function dot11RogueAPGet(args)
    local resultTab = {}   
    local table = db.getTable("dot11AuthorizedAP")

    for _, row in pairs(table) do
    resTab.insertField (resultTab, "BSSID", row["dot11AuthorizedAP.macAddress"])
    resTab.insertField (resultTab, "SSID", row["dot11AuthorizedAP.SSID"])
    resTab.insertField (resultTab, "Security", row["dot11AuthorizedAP.security"])
    resTab.insertField (resultTab, "Encryption", row["dot11AuthorizedAP.pairwiseCiphers"] or "")
    resTab.insertField (resultTab, "Authentication", row["dot11AuthorizedAP.authMethods"] or "")
    end

    printLabel ("Authorized AP Mac Addresses")
    resTab.print (resultTab, 0)

    resultTab = {}   
    table = db.getTable("dot11RogueAP")

    for _, row in pairs(table) do
    resTab.insertField (resultTab, "BSSID", row["dot11RogueAP.macAddress"])
    resTab.insertField (resultTab, "SSID", row["dot11RogueAP.SSID"])
    resTab.insertField (resultTab, "Security", row["dot11RogueAP.security"])
    resTab.insertField (resultTab, "Encryption", row["dot11RogueAP.pairwiseCiphers"])
    resTab.insertField (resultTab, "Authentication", row["dot11RogueAP.authMethods"])
    resTab.insertField (resultTab, "Time Last", row["dot11RogueAP.timeLastSeen"])
    end

    printLabel ("RogueAP Detected")
    resTab.print (resultTab, 0)

end

--
-- 
function dot11ACLGet (args)
    local apName = args[1]
    local label = "" 
    local resultTab = {}   
    local where = "vapName = '" .. apName .. "'"

    printLabel ("Default ACL Policy")    
    local defPol = db.getAttribute("dot11VAP", "dot11VAP.vapName", apName, 
	  "defACLPolicy")
    resTab.insertField (resultTab, "ACL Policy Status", defPol)    	  
    resTab.print (resultTab, defPol)
    
    resultTab = {}
    local table = db.getRowsWhere("dot11ACL", where)
    for _, row in pairs(table) do
        resTab.insertField (resultTab, "", row["dot11ACL.macAddress"])
    end

    printLabel ("List of MAC Address")    
    resTab.print (resultTab, 0)
end
