-- iprouteCLI.lua
-- Bhanu R
-- TeamF1
-- www.TeamF1.com

-- Modification History
-- 04oct11,rkm added CLI changes for DWC
-- 05jan10,db  added support for DMZ and WAN2
-- 02dec08,ss  added ipv6 routing cli support
-- 03oct08,rbh written
--
-- Description
-- CLI interface set and get routines

require "teamf1lualib/iproute"
require "teamf1lualib/validations"


--
-- This routine saves the modified/newly added static routes.
function routeCfgSave(configRow)	 
    local errorFlag = "ERROR"
    local statusCode = ""
    local statusMessage = ""

    if (configRow ["route._ROWID_"] == nil) then
        errorFlag , statusMessage = iproute.config(configRow, "-1", "add")
    else
        errorFlag , statusMessage = iproute.config(configRow, configRow ["route._ROWID_"],"edit")
    end

    if (errorFlag == "OK") then 
        db.save()
    end

    return errorFlag, statusMessage           	 
end

--
-- This routine saves the modified/newly added static routes.
function routeV6CfgSave(configRow)	 
    local errorFlag = "ERROR"
    local statusCode = ""
    local statusMessage = ""
    configRow["route6.active"] = "1"
    if (configRow ["route6._ROWID_"] == nil) then
        errorFlag , statusMessage = iproute.ipv6Config(configRow, "-1", "add")
    else
        errorFlag , statusMessage = iproute.ipv6Config(configRow, configRow ["route6._ROWID_"],"edit")
    end

    if (errorFlag == "OK") then
        db.save()
    end
    return errorFlag, statusMessage           	 
end

--
-- This routine deletes the specified static route.
function routeCfgDel(configRow)	 
    local errorFlag = "ERROR"
    local statusCode = ""
    local statusMessage = ""
    local rowId = {}

    if (db.existsRow ("route", "routeName" ,configRow ["route.routeName"])) then
        rowId["route._ROWID_"] = configRow ["route._ROWID_"]
        errorFlag , statusMessage = iproute.deleteRoute (rowId)
    else
        return "ERROR", "No such route with the specified name"
    end

    if (errorFlag == "OK") then 
        db.save()
    end

    return errorFlag, statusMessage           	 
end

--
-- This routine deletes the specified static route.
function routeV6CfgDel(configRow)	 
    local errorFlag = "ERROR"
    local statusCode = ""
    local statusMessage = ""
    local rowId = {}

    if (db.existsRow ("route6", "routeName" ,configRow ["route6.routeName"])) then
        rowId["route6._ROWID_"] = configRow ["route6._ROWID_"]
        errorFlag , statusMessage = iproute.deleteIpv6Route (rowId)
    else
        return "ERROR", "No such route with the specified name"
    end

    if (errorFlag == "OK") then 
        db.save()
    end

    return errorFlag, statusMessage           	 
end

--
-- This routine deletes all the configured routes.
function routeDelAll()	 
    local errorFlag = "ERROR"
    local statusCode = ""
    local statusMessage = ""
    local rowIds = {}
    local routeTable = {}

    routeTable = db.getTable ("route")
    if (routeTable == nil) then
        return "ERROR" , "No exisitng routes to delete"
    end

    for _,v in pairs(routeTable) do
        rowIds[ v["route._ROWID_"] ]= v["route._ROWID_"]
    end
   
    errorFlag , statusMessage = iproute.deleteRoute (rowIds)

    if (errorFlag == "OK") then 
        db.save()
    end

    return errorFlag, statusMessage           	 
end

--
-- This routine deletes all the configured routes.
function routeV6DelAll()	 
    local errorFlag = "ERROR"
    local statusCode = ""
    local statusMessage = ""
    local rowIds = {}
    local routeTable = {}

    routeTable = db.getTable ("route6")
    if (routeTable == nil) then
        return "ERROR" , "No exisitng routes to delete"
    end

    for _,v in pairs(routeTable) do
        rowIds[v["route6._ROWID_"]] = v["route6._ROWID_"]
    end
   
    errorFlag , statusMessage = iproute.deleteIpv6Route (rowIds)

    if (errorFlag == "OK") then 
        db.save()
    end

    return errorFlag, statusMessage           	 
end

--
-- This routine reads in a current static route configuration information
-- into a configuration object. Or, it justs initialises the defaults in case
-- a new route is getting added.
function routeCfgInit(args)
    local routeName = args[1]
    local rowId = -1

    local configRow = db.getRow("route","routeName",routeName)
    if (configRow == nil) then
        configRow = {}
        configRow["route.routeName"] = routeName
        configRow["route.interface"] = "LAN"
        configRow["route.private"] = 0
        configRow["route.prefix"] = "default"
        configRow["route.active"] = 1
    else
        rowId = configRow["route._ROWID_"]
    end
    return rowId, configRow
end

--
-- This routine reads in a current static route configuration information
-- into a configuration object. Or, it justs initialises the defaults in case
-- a new route is getting added.
function routeV6CfgInit(args)
    local routeName = args[1]
    local rowId = -1

    local configRow = db.getRow("route6","routeName",routeName)
    if (configRow == nil) then
        configRow = {}
        configRow["route6.routeName"] = routeName
    else
        rowId = configRow["route6._ROWID_"]
    end
    return rowId, configRow
end

--
-- This routine validates the static route configuration information.
function routeCfgInputVal(configRow)
    if (configRow["route.dstIpAddr"] == nil) then
        printCLIError ("Invalid destination IP address")
        return false
    end
    if (configRow["route.ipSNetMask"] == nil) then
        printCLIError ("Invalid IP subnetmask for the route.")
        return false
    end
    if (configRow["route.gwIpAddr"] == nil) then
        printCLIError ("Invalid gateway IP Address.")
        return false
    end
    if ((configRow["route.metric"] == nil) or (tonumber(configRow["route.metric"]) < 2) 
        or (tonumber(configRow["route.metric"]) > 15 ))then
        printCLIError ("Invalid Metric. Please enter a value between 2 and 15.")
        return false
    end
    if ((configRow["route.interfaceName"] == nil) or (configRow["route.interfaceName"] ~= "LAN" and configRow["route.interfaceName"] ~= "WAN1" and configRow["route.interfaceName"] ~= "WAN2" and configRow["route.interfaceName"] ~= "DMZ") ) then 
        printCLIError ("Invalid interfaceName. please give LAN or OPTION1 or OPTION2 or DMZ")
        return false
    end
    return true
end

--
-- This routine validates the static route configuration information.
function routeCfgV6InputVal(configRow)
    local ipmode = db.getRow("networkInfo", "_ROWID_", "1")
    if(ipmode["networkInfo.netWorkMode"] == "1")then
    printCLIError("Please Set IP Mode to IPv4/IPv6 to configure IPv6 Static Routes.")
    return false
    end
    if (configRow["route6.dstIpAddr"] == nil) then
        printCLIError ("Invalid destination IP address")
        return false
    end
    if (configRow["route6.prefix"] == nil) then
        printCLIError ("Invalid prefix length for the route.")
        return false
    end
    if (configRow["route6.gwIpAddr"] == nil) then
        printCLIError ("Invalid gateway IP Address.")
        return false
    end
    if ((configRow["route6.metric"] == nil) or (tonumber(configRow["route6.metric"]) < 2) 
        or (tonumber(configRow["route6.metric"]) > 15 ))then
        printCLIError ("Invalid Metric. Please enter a value between 2 and 15.")
        return false
    end
    if ((configRow["route6.interfaceName"] == nil) or (configRow["route6.interfaceName"] == "Dedicated-WAN") or (configRow["route6.interfaceName"] == "LAN") or (configRow["route6.interfaceName"] == "Sit0-WAN1")) then 
        printCLIError ("Invalid interfaceName. please give LAN or OPTION or sito-Tunnel")
        return false
    end
    a,b,c = validations.ipv6AddrValidate(configRow["route6.gwIpAddr"], "", "")
    if ( b~= "OK") then 
        print(b)
        return false
   end

    a,b,c = validations.ipv6AddrValidate(configRow["route6.dstIpAddr"], "", "")
    if ( b~= "OK") then 
        print( b)
        return false
   end
   return true
end

--
-- This routine implements the CLI command to show the route config
-- configuration
function routingV6Get (args)
    local routeTable = {}
    routeTable = db.getTable ("route6")

    if(db.getAttribute ("networkInfo", "_ROWID_", "1", "netWorkMode") == "1")then
        print("Please Set IP Mode to IPv4/IPv6 to configure IPv6 Static Routes.")
    else
    if (routeTable == nil ) then
        print ("Currently no static  routes are configured\n")
    end
    
    print ("Name" .. "\t" .. "Destination" .. "\t".. "Gateway" .."\t" .. "\t" .. "Interface" .. "\t" .. "Metric" .. "\t" .. "Active\n")
    print ("----" .. "\t" .. "-----------" .. "\t".. "-------" .. "\t" .. "\t"  .. "---------" .. "\t" .. "------" .. "\t" .. "-------\n")
    for _,v in pairs(routeTable) do
	if ( v["route6.interfaceName"] == "WAN1PPPOE2" ) then
		v["route6.interfaceName"] = "OPTION1PPPOE2"
	else
		v["route6.interfaceName"] = "OPTION2PPPOE2" 
	end     

	 print (v["route6.routeName"] .. "\t" .. v["route6.dstIpAddr"] .. "\t" ..v["route6.gwIpAddr"] .. "\t " .. v["route6.interfaceName"] .. "\t" .. "\t" ..v["route6.metric"] ..  "\t" ..v["route6.active"] .."\n")
    end
    end
end  

--
-- This routine implements the CLI command to show the route config
-- configuration
function routingGet (args)
    local routeTable = {}
    routeTable = db.getTable ("route")

    if (routeTable == nil ) then
        print ("Currently no static  routes are configured\n")
    end
    
    print ("Name" .. "\t" .. "Destination" .. "\t".. "Gateway" .."\t" .. "\t" .. "Interface" .. "\t" .. "Metric" .. "\t" .. "Active" .. "\t" .. "Private\n")
    print ("----" .. "\t" .. "-----------" .. "\t".. "-------" .. "\t" .. "\t"  .. "---------" .. "\t" .. "------" .. "\t" .. "-------" .. "\t" .. "-------\n")
    for _,v in pairs(routeTable) do
	if (v["route.interfaceName"] == "WAN1PPPOE2") then
		v["route.interfaceName"] = "OPTION1PPPOE2"
	else
		v["route.interfaceName"] = "OPTION2PPPOE2"
	end
        print (v["route.routeName"] .. "\t" .. v["route.dstIpAddr"] .. "\t" ..v["route.gwIpAddr"] .. "\t " .. v["route.interfaceName"] .. "\t" .. "\t" ..v["route.metric"] ..  "\t" ..v["route.active"] .."\t" ..v["route.private"] .."\n")
    end
end  

