
require"ifDevLib"

LAN_MAC_FILE = "/tmp/lanMAC1"
LAN_PHY_INTF_NAME = "eth0"

easyMeshMgmt = {}

function tcapiEasyMeshSetExecute(dbstring, variable, value)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/tcapi set Mesh"
    local cmdStr = TCAPI_SET_CMD_BINARY..dbstring.." "..variable.." \""..value.."\""
    os.execute("echo "..cmdStr.. " > /dev/console")
    os.execute(cmdStr)

end


function tcapiSetEasyMeshSSIDExecute(dbstring, variable, value)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/tcapi set WLan"
    local cmdStr = TCAPI_SET_CMD_BINARY..dbstring.." "..variable.." \""..value.."\""
    os.execute("echo "..cmdStr.. " > /dev/console")
    os.execute(cmdStr)

end


function tcapiWLanEasyMeshCommitCmdExecute(dbstring)

    local TCAPI_COMMIT_CMD_BINARY = "/userfs/bin/tcapi commit WLan"
    local cmdStr = TCAPI_COMMIT_CMD_BINARY..dbstring
    os.execute("echo "..cmdStr.. " > /dev/console")
    os.execute(cmdStr)

end


function tcapiEasyMeshSetCmdExecute(dbstring, variable, value)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/tcapi set Mesh"
    local cmdStr = TCAPI_SET_CMD_BINARY..dbstring.." "..variable.." "..value
    os.execute("echo "..cmdStr.. " > /dev/console")
    os.execute(cmdStr)

end


function tcapiEasyMeshCommitCmdExecute(dbString)

    local TCAPI_COMMIT_CMD_BINARY = "/userfs/bin/tcapi commit Mesh"
    local cmdStr = TCAPI_COMMIT_CMD_BINARY..dbString
    os.execute("echo "..cmdStr.. " > /dev/console")
    os.execute(cmdStr)

end

function tcapiSaveCmdExecute()

    local TCAPI_SAVE_CMD_BINARY = "/userfs/bin/tcapi save"
    os.execute("echo "..TCAPI_SAVE_CMD_BINARY.. " > /dev/console")
    os.execute(TCAPI_SAVE_CMD_BINARY)

end

------------------------------------------------------------------------------
-- @name : easyMeshMgmt.easyMeshGet()
--
-- @description : API to return 'easyMesh' table
--
-- @return : Entire easyMesh table
-- 
function easyMeshMgmt.easyMeshGet ()
    --local 
    local meshTbl = {}
    
    meshTbl = db.getRow ("easyMesh","_ROWID_","1") 

    meshTbl = util.removePrefix(meshTbl, "easyMesh.")
    
    return meshTbl
end

function easyMeshMgmt.easyMeshSet(meshConfTbl)
    --locals
    local statusFlag = true
    local radioDbString = ""
    local MeshinterfaceAL_Mac = ""
    local meshTmp = db.getTable ("easyMesh",false)

    -- add table prefix
    meshConfTbl = util.addPrefix(meshConfTbl, "easyMesh.")

    statusFlag = easyMeshMgmt.config ("easyMesh", meshConfTbl, "1", "edit")

    -- check status
    if (statusFlag) then
	    if(meshConfTbl["easyMesh.meshEnable"] == "1") then
            os.execute("touch /flash/MESH_ENABLED")
            os.execute("echo '1' > /tmp/MESH_ENABLED")
          

            --Checking the Radius Authentication Enabled
            --Setting to WPA2PSK
            local authMode = db.getAttribute("dot11Profile","profileName","Jio_1","authMethods")

            if(authMode == "RADIUS") then
                valid = db.setAttribute("dot11Profile", "profileName","Jio_1", "authMethods", "PSK") 
            end

            authMode = db.getAttribute("dot11Profile","profileName","Jio_4","authMethods")

            if(authMode == "RADIUS") then
                valid = db.setAttribute("dot11Profile", "profileName","Jio_4", "authMethods", "PSK") 
            end

            --Enabling the FH VAP's
            local vapEnable = db.getAttribute("dot11VAP","vapName","ap1","vapEnabled")
            if(vapEnable == "0") then
                local cmd ="/sbin/ifconfig ra0 up" 
                os.execute(cmd)
                cmd = "/usr/bin/brctl addif bdg2 ra0"
                os.execute(cmd)
               radioDbString = "_Entry0" 
               tcapiSetEasyMeshSSIDExecute(radioDbString,"HideSSID","1")
               tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID","1")
               tcapiWLanEasyMeshCommitCmdExecute(radioDbString)
            end

            vapEnable = db.getAttribute("dot11VAP","vapName","ap4","vapEnabled")
            if(vapEnable == "0") then
                cmd ="/sbin/ifconfig rai0 up" 
                os.execute(cmd)
                cmd = "/usr/bin/brctl addif bdg2 rai0"
                os.execute(cmd)
                radioDbString = "11ac_Entry0" 
                tcapiSetEasyMeshSSIDExecute(radioDbString,"HideSSID","1")
                tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID","1")
                tcapiWLanEasyMeshCommitCmdExecute(radioDbString)
            end

            local radioDbString = ""
            --Back Haul Vap's Name same as Primary AP's
    
            local vapName = util.fileToString ("/tmp/ssidRandom")
    
            vapName = vapName.. "-BH"
            radioDbString = "_Entry1" 
            tcapiSetEasyMeshSSIDExecute(radioDbString,"SSID",vapName)
            tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID","1")
            tcapiSetEasyMeshSSIDExecute(radioDbString,"AuthMode","WPA2PSK")
            tcapiSetEasyMeshSSIDExecute(radioDbString,"EncrypType","AES")
            local bhPwd = generateBHPasswd("a")
            if(bhPwd == nil) then
                bhPwd = util.fileToString ("/tmp/randPasswordWifi")
            end
            tcapiSetEasyMeshSSIDExecute(radioDbString,"WPAPSK",bhPwd)
            tcapiSetEasyMeshSSIDExecute(radioDbString,"HideSSID","1")
            radioDbString = "_radio2gbssinfo_entry1" 
            tcapiEasyMeshSetCmdExecute(radioDbString,"BackHaul",1)
            tcapiEasyMeshSetCmdExecute(radioDbString,"FrontHaul",0)
            --tcapiEasyMeshCommitCmdExecute(radioDbString)

            radioDbString = "11ac_Entry1" 
            tcapiSetEasyMeshSSIDExecute(radioDbString,"SSID",vapName)
            tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID","1")
            tcapiSetEasyMeshSSIDExecute(radioDbString,"AuthMode","WPA2PSK")
            tcapiSetEasyMeshSSIDExecute(radioDbString,"EncrypType","AES")
            --[[
	        bhPwd = generateBHPasswd("a")
            if(bhPwd == nil) then
                bhPwd = util.fileToString ("/tmp/randPasswordWifi")
            end
		    ]]--
            tcapiSetEasyMeshSSIDExecute(radioDbString,"WPAPSK",bhPwd)
            tcapiSetEasyMeshSSIDExecute(radioDbString,"HideSSID","1")
            radioDbString = "_radio5glbssinfo_entry1" 
            tcapiEasyMeshSetCmdExecute(radioDbString,"BackHaul",1)
            tcapiEasyMeshSetCmdExecute(radioDbString,"FrontHaul",0)
            --tcapiEasyMeshCommitCmdExecute(radioDbString)
    
            radioDbString = ""
		    radioDbString="_dat"
	        tcapiEasyMeshSetCmdExecute(radioDbString,"MapEnable",1)
	        tcapiEasyMeshSetCmdExecute(radioDbString,"MAP_Turnkey",1)
		    --tcapiSetCmdWrite("MapEnable","1")
	   	    --tcapiSetCmdWrite("MAP_Turnkey","1")
           	radioDbString="__mapcfg"
	   	    tcapiEasyMeshSetCmdExecute(radioDbString,"br_inf",meshTmp[1]["meshInterfacename"])
	   	    MeshinterfaceAL_Mac = ifDevLib.getMac(meshTmp[1]["meshInterfacename"])
	   	    tcapiEasyMeshSetCmdExecute(radioDbString,"AL-MAC",MeshinterfaceAL_Mac)
            radioDbString ="_dat"
	   	    tcapiEasyMeshCommitCmdExecute(radioDbString)
           	tcapiSaveCmdExecute() 
        else
            os.execute("rm -rf /flash/MESH_ENABLED")
       	    os.execute("echo '0' > /tmp/MESH_ENABLED")
            

            local vapEnable = db.getAttribute("dot11VAP","vapName","ap1","vapEnabled")
            if(vapEnable == "0") then
                cmd ="/sbin/ifconfig ra0 down" 
                os.execute(cmd)
                cmd = "/usr/bin/brctl delif bdg2 ra0"
                os.execute(cmd)
               radioDbString = "_Entry0" 
               --tcapiSetEasyMeshSSIDExecute(radioDbString,"HideSSID","0")
               tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID","0")
               tcapiWLanEasyMeshCommitCmdExecute(radioDbString)
            end

            vapEnable = db.getAttribute("dot11VAP","vapName","ap4","vapEnabled")
            if(vapEnable == "0") then
                cmd ="/sbin/ifconfig rai0 down" 
                os.execute(cmd)
                cmd = "/usr/bin/brctl delif bdg2 rai0"
                os.execute(cmd)
                radioDbString = "11ac_Entry0" 
                --tcapiSetEasyMeshSSIDExecute(radioDbString,"HideSSID","0")
                tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID","0")
                tcapiWLanEasyMeshCommitCmdExecute(radioDbString)
            end

            radioDbString="_dat"
	        tcapiEasyMeshSetCmdExecute(radioDbString,"MapEnable",0)
	        tcapiEasyMeshSetCmdExecute(radioDbString,"MAP_Turnkey",0)
	   	    --tcapiSetCmdWrite("MapEnable","0")
	   	    --tcapiSetCmdWrite("MAP_Turnkey","0")
	   	    tcapiEasyMeshCommitCmdExecute(radioDbString)
           	tcapiSaveCmdExecute()
        end
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_CONFIG_FAILED"
    end    
end


function easyMeshMgmt.config (name,inputTable,rowid,operation)

    if (operation == "add") then
        return db.insert(name, inputTable)
    elseif (operation == "edit") then
        return db.update(name, inputTable, rowid)
    elseif (operation == "delete") then
        return db.delete(name, inputTable)
    end

    return false

end

function easyMeshMgmt.import(easyMeshConfig,defaultConfig,removeConfig)

    --local BaseMac = util.fileToString(LAN_MAC_FILE)
    --os.execute("/sbin/ifconfig "..LAN_PHY_INTF_NAME.." hw ether "..BaseMac.." ;/sbin/ifconfig "..LAN_PHY_INTF_NAME.." up")
    local cmdpid = "/bin/ps | grep -v grep | grep '/userfs/bin/mapd' |awk '{print($1)}' > /tmp/mapdpidold"
    os.execute(cmdpid)

    if (easyMeshConfig == nil) then 
        easyMeshConfig = defaultConfig
    end

    local easyMeshDevicesTmp = {}  
    easyMeshDevicesTmp = config.update(easyMeshConfig.easyMeshDevices,defaultConfig.easyMeshDevices,removeConfig.easyMeshDevices)
    if (easyMeshDevicesTmp ~= nil and #easyMeshDevicesTmp ~= 0) then
        for i,v in ipairs (easyMeshDevicesTmp) do
            v = util.addPrefix (v, "easyMeshDevices.")
            easyMeshMgmt.config("easyMeshDevices",v,"-1","add")
        end
    end
   
    if (not(util.fileExists("/pfrm2.0/DEVICE_REPEATER"))) then
	--adding the BH Interfaces to bdg2
    local cmd ="/sbin/ifconfig ra1 up" 
    os.execute(cmd)
    cmd = "/usr/bin/brctl addif bdg2 ra1"
    os.execute(cmd)
    cmd ="/sbin/ifconfig rai1 up" 
    os.execute(cmd)
    cmd = "/usr/bin/brctl addif bdg2 rai1"
    os.execute(cmd)
    
    radioDbString = "_radio2gbssinfo_entry0" 
    tcapiEasyMeshSetCmdExecute(radioDbString,"BackHaul",0)
    tcapiEasyMeshSetCmdExecute(radioDbString,"FrontHaul",1)
    --tcapiEasyMeshCommitCmdExecute(radioDbString)
    --tcapiSaveCmdExecute()
    
    radioDbString = "_radio2gbssinfo_entry2" 
    tcapiEasyMeshSetCmdExecute(radioDbString,"BackHaul",0)
    tcapiEasyMeshSetCmdExecute(radioDbString,"FrontHaul",1)
    --tcapiEasyMeshCommitCmdExecute(radioDbString)
    --tcapiSaveCmdExecute()
   
    radioDbString = "_radio2gbssinfo_entry3" 
    tcapiEasyMeshSetCmdExecute(radioDbString,"BackHaul",0)
    tcapiEasyMeshSetCmdExecute(radioDbString,"FrontHaul",1)
    --tcapiEasyMeshCommitCmdExecute(radioDbString)
    --tcapiSaveCmdExecute()
 
    radioDbString = "_radio5glbssinfo_entry0" 
    tcapiEasyMeshSetCmdExecute(radioDbString,"BackHaul",0)
    tcapiEasyMeshSetCmdExecute(radioDbString,"FrontHaul",1)
    --tcapiEasyMeshCommitCmdExecute(radioDbString)
    --tcapiSaveCmdExecute()
  
    radioDbString = "_radio5glbssinfo_entry2" 
    tcapiEasyMeshSetCmdExecute(radioDbString,"BackHaul",0)
    tcapiEasyMeshSetCmdExecute(radioDbString,"FrontHaul",1)
    --tcapiEasyMeshCommitCmdExecute(radioDbString)
    --tcapiSaveCmdExecute()
  
    radioDbString = "_radio5glbssinfo_entry3" 
    tcapiEasyMeshSetCmdExecute(radioDbString,"BackHaul",0)
    tcapiEasyMeshSetCmdExecute(radioDbString,"FrontHaul",1)
    --tcapiEasyMeshCommitCmdExecute(radioDbString)
    --tcapiSaveCmdExecute()


    local radioDbString = ""
    --Back Haul Vap's Name same as Primary AP's
    
    local vapName = util.fileToString ("/tmp/ssidRandom")
    
    vapName = vapName.. "-BH"
    radioDbString = "_Entry1" 
    tcapiSetEasyMeshSSIDExecute(radioDbString,"WNMEnable","1")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"MaxStaNum","10")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"AccessPolicy","0")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"IEEE8021X","0")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"WPSConfMode","4")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"SSID",vapName)
    tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID","1")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"AuthMode","WPA2PSK")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"EncrypType","AES")
    local bhPwd = generateBHPasswd("a")
    if(bhPwd == nil) then
        bhPwd = util.fileToString ("/tmp/randPasswordWifi")
    end
    tcapiSetEasyMeshSSIDExecute(radioDbString,"WPAPSK",bhPwd)
    tcapiSetEasyMeshSSIDExecute(radioDbString,"HideSSID","1")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"VapInfc","ra1")
    radioDbString = "_radio2gbssinfo_entry1" 
    tcapiEasyMeshSetCmdExecute(radioDbString,"BackHaul",1)
    tcapiEasyMeshSetCmdExecute(radioDbString,"FrontHaul",0)
    --tcapiEasyMeshCommitCmdExecute(radioDbString)
    --tcapiSaveCmdExecute()

    radioDbString = "11ac_Entry1" 
    tcapiSetEasyMeshSSIDExecute(radioDbString,"WNMEnable","1")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"MaxStaNum","10")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"AccessPolicy","0")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"IEEE8021X","0")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"WPSConfMode","4")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"SSID",vapName)
    tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID","1")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"AuthMode","WPA2PSK")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"EncrypType","AES")
    --[[bhPwd = generateBHPasswd("a")
    if(bhPwd == nil) then
        bhPwd = util.fileToString ("/tmp/randPasswordWifi")
    end]]--
    tcapiSetEasyMeshSSIDExecute(radioDbString,"WPAPSK",bhPwd)
    tcapiSetEasyMeshSSIDExecute(radioDbString,"HideSSID","1")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"VapInfc","rai1")
    radioDbString = "_radio5glbssinfo_entry1" 
    tcapiEasyMeshSetCmdExecute(radioDbString,"BackHaul",1)
    tcapiEasyMeshSetCmdExecute(radioDbString,"FrontHaul",0)
    --tcapiEasyMeshCommitCmdExecute(radioDbString)
    --tcapiSaveCmdExecute()
    --radioDbString = "" 
    
    radioDbString="_Common"
    tcapiEasyMeshSetExecute(radioDbString,"DeviceRole","1")
    tcapiEasyMeshSetExecute(radioDbString,"NonMapIface","ra2;ra3;rai2;rai3")
    --tcapiSaveCmdExecute() 
    --tcapiEasyMeshCommitCmdExecute(radioDbString)
    --radioDbString="_mapcfg"
	--tcapiEasyMeshSetCmdExecute(radioDbString,"Agent_apply_M2_BSS_num","2")
    --radioDbString="_dat"
    --tcapiEasyMeshCommitCmdExecute(radioDbString)
    --tcapiSaveCmdExecute() 
    radioDbString="_SteerCfg"
	tcapiEasyMeshSetCmdExecute(radioDbString,"LowRSSIAPSteerEdge_RE","25")
	tcapiEasyMeshSetCmdExecute(radioDbString,"force_roam_rssi_th","-70")
	tcapiEasyMeshSetCmdExecute(radioDbString,"APsteer_thresh_tolerance","15")
	tcapiEasyMeshSetCmdExecute(radioDbString,"MinRssiIncTh_RE","5")
	tcapiEasyMeshSetCmdExecute(radioDbString,"MinRssiIncTh_Peer","5")
	tcapiEasyMeshSetCmdExecute(radioDbString,"CUOverloadTh_2G","70")
	tcapiEasyMeshSetCmdExecute(radioDbString,"CUOverloadTh_5G_L","80")
	tcapiEasyMeshSetCmdExecute(radioDbString,"CUOverloadTh_5G_H","80")
    --radioDbString="_dat"
    --tcapiEasyMeshCommitCmdExecute(radioDbString)
    --tcapiSaveCmdExecute() 
   
    local easyMeshTmp = {}  

    easyMeshTmp = config.update(easyMeshConfig.easyMesh,defaultConfig.easyMesh,removeConfig.easyMesh)
  
    local Status = "ERROR"
    local message = "" 
    local MeshAL_MAC = ""
    if (easyMeshTmp ~= nil and #easyMeshTmp ~= 0) then
        for i,v in ipairs (easyMeshTmp) do
            v = util.addPrefix (v, "easyMesh.")
            easyMeshMgmt.config("easyMesh",v,"-1","add")
        end
    end
   
    local meshConfTbl = db.getTable ("easyMesh",false)

    if(meshConfTbl ~= nil) then
	if(meshConfTbl[1]["meshEnable"] == "1") then
       os.execute("touch /flash/MESH_ENABLED")
       os.execute("echo '1' > /tmp/MESH_ENABLED")
       radioDbString="_dat"
	   tcapiEasyMeshSetCmdExecute(radioDbString,"MapEnable",1)
	   tcapiEasyMeshSetCmdExecute(radioDbString,"MAP_Turnkey",1)
	   --tcapiSetCmdWrite("MapEnable",1)
	   --tcapiSetCmdWrite("MAP_Turnkey",1)
	   --tcapiEasyMeshCommitCmdExecute(radioDbString)
       --tcapiSaveCmdExecute() 
       radioDbString="_mapcfg"
	   tcapiEasyMeshSetCmdExecute(radioDbString,"br_inf",meshConfTbl[1]["meshInterfacename"])
	   tcapiEasyMeshSetExecute(radioDbString,"bss_config_priority","ra1;ra0;rai1;rai0")
	   tcapiEasyMeshSetExecute(radioDbString,"lan","eth0.1,eth0.2,eth0.3,eth0.4")
	   MeshAL_MAC = ifDevLib.getMac(meshConfTbl[1]["meshInterfacename"])
	   tcapiEasyMeshSetCmdExecute(radioDbString,"AL-MAC",MeshAL_MAC)
	   radioDbString="_DefSetting"
	   tcapiEasyMeshSetCmdExecute(radioDbString,"DhcpCtl","0")
       radioDbString="_dat"
       tcapiEasyMeshCommitCmdExecute(radioDbString)
       tcapiSaveCmdExecute() 
     else
         os.execute("rm -rf /flash/MESH_ENABLED")
         os.execute("echo '0' > /tmp/MESH_ENABLED")
	   radioDbString="_dat"
	   tcapiEasyMeshSetCmdExecute(radioDbString,"MapEnable",0)
	   tcapiEasyMeshSetCmdExecute(radioDbString,"MAP_Turnkey",0)
	   --tcapiSetCmdWrite("MapEnable",0)
	   --tcapiSetCmdWrite("MAP_Turnkey",0)
	   tcapiEasyMeshCommitCmdExecute(radioDbString)
       tcapiSaveCmdExecute()
 	end
    end       
 end
  
end

function easyMeshMgmt.export()

    local easyMeshConfig= {}
  
    easyMeshConfig["easyMesh"] = db.getTable ("easyMesh", false)
    easyMeshConfig["easyMeshDevices"] = db.getTable ("easyMeshDevices", false)
  
    return easyMeshConfig
        
end

require "teamf1lualib/config"
if (config.register) then
   config.register("easyMeshMgmt", easyMeshMgmt.import, easyMeshMgmt.export, "2")
end

--
--PassWord Generate For BackHaul Based on the MAC Address 
--

function generateBHPasswd(band)
    local bspasswd = nil
    local FILE = "/tmp/lanMAC2"
    if(band == "a") then
        FILE = "/tmp/lanMAC3"
    end

    local macAddr = util.fileToString(FILE)  
    --print("MAC: " .. macAddr)
    
    if(ifDevLib.macAddrCheck(macAddr)== nil) then
        return nil
    end

    local cmd= "/pfrm2.0/bin/pwgen 16 1 -H "..FILE .." "
    local pipe = io.popen(cmd .. " 2>&1") -- redirect stderr to stdout
    local cmdOutput = pipe:read("*a")
    pipe:close()
    --print("rand password: " .. cmdOutput)
    bspasswd = string.gsub(cmdOutput, "\n", "")
    --print("rand password: " .. cmdOutput)
    --print("rand password len: " .. string.len(bspasswd))
    if(bspasswd == nil or string.len(bspasswd) ~= 16) then	
       return nil
    end
      return bspasswd
end 
