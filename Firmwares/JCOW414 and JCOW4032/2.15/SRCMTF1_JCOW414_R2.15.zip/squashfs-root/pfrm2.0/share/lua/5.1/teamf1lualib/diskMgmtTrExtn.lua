--[[
#### File: tr140_diskMgmtTrExtn.lua
#### Description: common functions for TR-181
#### Copyright (c) 2017, TeamF1 Networks Pvt. Ltd.
#### (Subsidiary of D-Link India) 

#### Modification history:
01d,22May17,swr Changes for SPR 60383
01c,28Sep15,swr Changes for SPR 53208
01b,12May14,vik added tr_140 parameters support
01a,04Oct13,adk written
]]--

diskTr = {}

-- includes 
require "teamf1lualib/gui"

--[[
--*****************************************************************************
-- diskTr.nasConfigGet- get nasShare status
-- 
-- This function is called to get the following parameter
-- Device.StorageService.0.
-- Enable
--
-- Returns: status, value
]]--

function diskTr.nasConfigGet (input)
    tr69Glue.tf1Dbg("Entering nasConfigGet..")
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local row = {}
    local query = nil
    local statusMsg, errMsg
    local param = input["param"]

    -- Device.StorageService.0.Enable
    -- get corresponding db entry from 'smbGlobalConfig'

    statusMsg, errMsg, row = gui.administration.fileShareGet ()
    
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    
   --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = row ["shareSettings"]
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end 

    return status, value 
end

--[[
--*****************************************************************************
-- diskTr.diskPhyGet- get disk physical info.
-- 
-- This function is called to get the following parameters
-- Device.StorageService.0.PhysicalMedium.
-- Name
-- Vendor
-- Model
-- SerialNumber
-- ConnectionType
--
-- Returns: status, value
]]--

function diskTr.diskPhyGet (input)
    tr69Glue.tf1Dbg("Entering diskPhyGet..")
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local statusMsg, errMsg
    local row = {}
    local diskTbl = {}
    local query = nil
    local param = input["param"]
    
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "PhysicalMedium.")
    parentObjInstance = string.sub(param, 1, endIdx+2)

    --read the rowId mapping to packages
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    -- Device.StorageService.0.PhysicalMedium.0.Name
    -- Device.StorageService.0.PhysicalMedium.0.Vendor
    -- Device.StorageService.0.PhysicalMedium.0.Model
    -- Device.StorageService.0.PhysicalMedium.0.SerialNumber
    -- Device.StorageService.0.PhysicalMedium.0.ConnectionType
    
    -- get corresponding db entry from diskMgmtPartition
    query = "_ROWID_=" .. rowId

    row = db.getRowWhere ("diskMgmtPartition", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    local partId = row ["partId"]
    local diskId = row ["diskId"]
    statusMsg, errMsg, diskTbl = gui.administration.disks.partitions.infoGet (diskId)
    statusMsg, errMsg, diskTrTbl = gui.administration.disks.trGet (partId)
   
    --find & return parameter values
    if(string.find(input["param"], "Name")) then
        -- Name
        value = diskTbl ["name"]
    elseif(string.find(input["param"], "Vendor")) then
        -- Vendor
       value = diskTrTbl ["vendor"] or "" 
    elseif(string.find(input["param"], "Model")) then
        -- Model
        value = diskTrTbl ["model"] or ""
    elseif(string.find(input["param"], "SerialNumber")) then
        -- SerialNumber
        value = diskTrTbl ["serialNumber"] or ""
    elseif(string.find(input["param"], "ConnectionType")) then
        -- ConnectionType
        value = diskTbl ["deviceType"]
    elseif(string.find(input["param"], "Removable")) then
        if (diskTbl ["deviceType"] == "scsi") then
            value = 0
        else
            value = 1
        end
    elseif(string.find(input["param"], "FirmwareVersion")) then
        -- FirmwareVersion
        local hdparmCmd = "/pfrm2.0/bin/hdparm -I " .. partId .. " |/bin/grep Firmware | cut -d ' ' -f 4"
        local pipe = io.popen(hdparmCmd) 
        local firmwareVer = nil
        firmwareVer = pipe:read("*line")
        pipe:close()
        if (firmwareVer == '' or firmwareVer == nil) then
            value = ''
        else
            value = firmwareVer
        end
    elseif(string.find(input["param"], "SMARTCapable")) then
        -- SMARTCapable
        local hdparmCmd = "/pfrm2.0/bin/hdparm -I " .. partId .. " |/bin/grep 'SMART feature set'"
        local pipe = io.popen(hdparmCmd) 
        local smartCapable = ''
        smartCapable = pipe:read("*line")
        pipe:close()
        if (smartCapable == '' or smartCapable == nil) then
            value = 0
        else
            value = 1
        end
    elseif(string.find(input["param"], "HotSwappable")) then
        -- HotSwappable
        if (diskTbl ["deviceType"] == "scsi") then
            value = 0
        else
            value = 1
        end
	    elseif(string.find(input["param"], "Capacity")) then
        if (string.find (diskTbl["size"],"MB") ~= nil ) then
            size = (string.gsub (diskTbl["size"],"MB",""))
			sizeMB = tonumber(size)
            value = math.floor(sizeMB)
        elseif (string.find (diskTbl["size"],"M") ~= nil ) then
            size = (string.gsub (diskTbl["size"],"M",""))
			sizeMB = tonumber(size)
            value = math.floor(sizeMB)
        elseif (string.find (diskTbl["size"],"GB") ~= nil ) then
            size = (string.gsub (diskTbl["size"],"GB",""))
			sizeGB = tonumber(size)
            value = math.floor(sizeGB * 1024)
        elseif (string.find (diskTbl["size"],"G") ~= nil ) then
            size = (string.gsub (diskTbl["size"],"G",""))
			sizeGB = tonumber(size)
            value = math.floor(sizeGB * 1024)
        end
    elseif(string.find(input["param"], "Status")) then
        value = "Online"
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end 

    return status, value 
end

--[[
--*****************************************************************************
-- diskTr.diskVolGet- get volume info of the disk attached
-- 
-- This function is called to get the following parameters
-- Device.StorageService.0.PhysicalMedium.
-- Name
-- FileSystem
-- Capacity
-- UsedSpace
--
-- Returns: status, value
]]--

function diskTr.diskVolGet (input)
    tr69Glue.tf1Dbg("Entering diskVolGet..")
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local statusMsg, errMsg
    local row = {}
    local diskTbl = {}
    local query = nil
    local param = input["param"]
    local index = 0
    local chipsetRow = nil
    
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "LogicalVolume.")
    parentObjInstance = string.sub(param, 1, endIdx+2)

    --read the rowId mapping to packages
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    -- Device.StorageService.0.LogicalVolume.0.Name
    -- Device.StorageService.0.LogicalVolume.0.FileSystem
    -- Device.StorageService.0.LogicalVolume.0.Capacity
    -- Device.StorageService.0.LogicalVolume.0.UsedSpace

    -- get corresponding db entry from diskMgmtPartition

    errMsg, statusMsg, diskTbl, result = diskTr.getDiskInformation()
    if (errMsg ~= "OK") then
        return "1", statusMsg
    end
   
    index = tonumber(rowId)

    --find & return parameter values
    if(string.find(input["param"], "Name")) then
        -- Name
        value = result[index]["name"]
    elseif(string.find(input["param"], "FileSystem")) then
        -- Vendor
       value = result [index]["type"] 
    elseif(string.find(input["param"], "Capacity")) then
        chipsetRow = db.getRowWhere("chipsetInfo", "_ROWID_=1", false)
        if (chipsetRow == nil or chipsetRow == "") then
            return "1", "DB_ERROR_TRY_AGAIN"
        end
        -- In Lantiq device we are receiving the size in KB without units 
        -- mentioned in string(Eg: 120KB we are getting as 120)
        -- Hence adding KB string at the end to get the value in MB.
        if(chipsetRow["Chipset"] == "Lantiq") then
            tr69Glue.tf1Dbg("Chipset is Lantiq");
            value = diskTr.convertSizeToMB(result[index]["size"].."KB");
        else 
        -- Model
        -- convert the size into MB as per amendment
            value = diskTr.convertSizeToMB(result[index]["size"]);
        end
    elseif(string.find(input["param"], "UsedSpace")) then
        chipsetRow = db.getRowWhere("chipsetInfo", "_ROWID_=1", false)
        if (chipsetRow == nil or chipsetRow == "") then
            return "1", "DB_ERROR_TRY_AGAIN"
        end

        if(chipsetRow["Chipset"] == "Lantiq") then
            tr69Glue.tf1Dbg("Chipset is Lantiq");
            value = diskTr.convertSizeToMB(result[index]["usedSpace"].."KB");
        else
        -- SerialNumber
        -- convert the size into MB as per amendment
            value = diskTr.convertSizeToMB(result[index]["usedSpace"]);
        end
    elseif(string.find(input["param"], "Status")) then
        value = "Online"
    elseif(string.find(input["param"], "Enable")) then
        value = 1
    elseif(string.find(input["param"], "PhysicalReference")) then
        value = "PhysicalMedium." .. rowId 
    elseif(string.find(input["param"], "Encrypted")) then
        -- Encrypted
        value = 0
    elseif(string.find(input["param"], "FolderNumberOfEntries")) then
        -- FolderNumberOfEntries
        query = "_ROWID_=" .. rowId
        row = db.getRowWhere ("diskMgmtPartition", query, false)
        if(row == nil) then
           return "1", "DB_ERROR_TRY_AGAIN"
        end
        local folderCountCmd = "ls -l " .. row["mntDir"] .. " | grep ^d | wc -l"
        local pipe = io.popen(folderCountCmd) 
        local dirCount = 0
        dirCount = pipe:read("*line")
        pipe:close()
        value = tonumber(dirCount)
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end  

    return status, value 
end

--[[ 
--diskTr.convertSizeToMB: This function converts the input into mega bytes.
--
--This function is called by diskTr.diskVolGet function to convert the capacity
--and usedspace parameters into MB.
--
--Returns : value in megabytes
--]]--
function diskTr.convertSizeToMB (input)
    local size = 0
    local sizeMB = 0

    if (string.find (input,"MB") ~= nil ) then
       size = (string.gsub (input,"MB",""))
       sizeMB = tonumber(size)
    elseif (string.find (input,"M") ~= nil ) then
       size = (string.gsub (input,"M",""))
       sizeMB = tonumber(size)
    elseif (string.find (input,"GB") ~= nil ) then
       size = (string.gsub (input,"GB",""))
       sizeMB = (tonumber(size) * 1024)
    elseif (string.find (input,"G") ~= nil ) then
       size = (string.gsub (input,"G",""))
       sizeMB = (tonumber(size) * 1024)
    elseif (string.find (input,"KB") ~= nil ) then
       size = (string.gsub (input,"KB",""))
       sizeMB = (tonumber(size) / 1024)
    elseif (string.find (input,"K") ~= nil ) then
       size = (string.gsub (input,"K",""))
       sizeMB = (tonumber(size) / 1024)
    else
       -- convert bytes to MB
       size = tonumber(input);
       sizeMB = size / 1024000
    end

    return math.floor(sizeMB)
end
--[[
--*****************************************************************************
-- diskTr.nasConfigSet- sets a sharing set-up 
-- 
-- This function is called to set the Sharing setup.
-- Device.StorageService.0.
-- Enable
--
-- Status
--
-- Returns: status
]]--
function diskTr.nasConfigSet (input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering diskTr.nasConfigSet..")
    
    local status = "0"
    local row = {}
    local rowId
    local query = nil
    local status = ""
    local errMsg = ""
    local conf = {}

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = "1"
        return "1";
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(tr69Param, "StorageService.")
    parentObjInstance = string.sub(tr69Param, 1, endIdx+2)

    --read the rowId mapping to pkgInstalledSystemDB
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        status = "1"
        return "1";
    end

   -- get the current state of the sharing setup
    statusMsg, errMsg, row = gui.administration.fileShareGet ()
    if (input["diskMgmtPartition"]["diskMgmtPartition.status"] ~= nil) then
        if (row ["shareSettings"] == input["diskMgmtPartition"]["diskMgmtPartition.status"]) then
            return 0;
        else 
            conf["shareSettings"] = input["diskMgmtPartition"]["diskMgmtPartition.status"]
            status, errMsg = diskTr.serverAccessSet(conf)
            if (status ~= "OK") then
                return 1;
            end
        end
    end

    return 0
end


--[[
--*****************************************************************************
-- diskTr.diskPhySet- just a check function 
-- 
-- This function is called to set the Sharing setup.
-- Device.StorageService.0.PhysicalMedium.0.
-- Name
--
-- Status
--
-- Returns: status
]]--
function diskTr.diskPhySet (input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering  diskTr.diskPhySet ..")
    local status = "0"
    local row = {}
    local rowId
    local query = nil
     
    -- if func has been called for setting Device.StorageService.0.PhysicalMedium.0.Name
    -- then it should return without setting anything.
    if (input["diskMgmtPartition"]["diskMgmtPartition.name"] ~= nil) then
        return 0;
    end

    return 0;
end

--[[
--*****************************************************************************
-- diskTr.diskVolSet- just a check function 
-- 
-- This function is called to set the Sharing setup.
-- Device.StorageService.0.LogicalVolume.0.
-- Name
-- Capacity
--
--
-- Returns: status
]]--
function diskTr.diskVolSet (input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering  diskTr.diskVolSet ..")
    local status = "0"
    local row = {}
    local rowId
    local query = nil
    
    -- if func has been called for setting Device.StorageService.0.PhysicalMedium.0.Name
    -- or Device.StorageService.0.PhysicalMedium.0.Capacity then it should return without 
    -- setting anything.

    if ((input["diskMgmtPartition"]["diskMgmtPartition.name"] ~= nil) or (input["diskMgmtPartition"]["diskMgmtPartition.size"])) then
        return 0;
    end

    return 0;
end

--[[
--*****************************************************************************
-- diskTr.serverAccessSet- Enable or Disable the server access 
-- 
-- This function is called to set the Sharing setup.
--
--
-- Returns: status
]]--
function diskTr.serverAccessSet (conf)
    tr69Glue.tf1Dbg("Entering diskTr.serverAccessSet..")
    -- include
    require "teamf1lualib/mediaServerMgmt"
    require "teamf1lualib/smb"
    require "teamf1lualib/diskMgmt"

    local status = "ERROR"
    local errCode = ""
    local row = {}
    local query = "_ROWID_=1"
    local serverconf =  {} 
    local mediaconf =  {} 
    local smbconf =  {} 
    local diskconf =  {} 
    
    -- get the current status of media sharing
    status, errCode, mediaconf = mediaServerMgmt.confGet()
    if (status ~= "OK") then
        return "ERROR", "MEDIA_SERVER_ERR_DB_QUERY_FAILED"
    end    

    -- compare the current value with the configured value and update if
    -- 'changed'
    if (mediaconf.serverEnable ~= conf.shareSettings) then

        mediaconf.serverEnable = conf.shareSettings
        -- adding prefix
        mediaconf = util.addPrefix(mediaconf, "mediaServerGlobalCfg.")
        --update table mediaServerGlobalCfg.
        DBTable = "mediaServerGlobalCfg"
        valid, statusStr = diskTr.config(mediaconf, mediaconf["mediaServerGlobalCfg._ROWID_"], "edit")
        -- Return from function
        if (valid == false) then
            tr69Glue.tf1Dbg (statusStr)
            db.rollback ()
            return "ERROR", "MEDIA_SERVER_CONFIG_ERROR"
        end
    end
    
    -- get the current status of smb sharing
    status, errCode, smbconf = smb.confGet()
    if (status ~= "OK") then
        return "ERROR", "MEDIA_SERVER_ERR_DB_QUERY_FAILED"
    end   
    
    -- compare the current value with the configured value and update if
    -- 'changed'
    if (smbconf.serverEnable ~= conf.shareSettings) then
        smbconf.serverEnable = conf.shareSettings
        -- adding prefix
        smbconf = util.addPrefix(smbconf, "smbGlobalConfig.")
        --update table smbGlobalConfig.
        DBTable = "smbGlobalConfig"
        valid, statusStr = diskTr.config(smbconf, smbconf["smbGlobalConfig._ROWID_"], "edit")
        -- Return from function
        if (valid == false) then
            tr69Glue.tf1Dbg (statusStr)
            db.rollback ()
            return "ERROR", "NAS_SMB_CONFIG_FAILED"
        end
    end
    
    -- get the current status of smb sharing
    status, errCode, diskconf = diskMgmt.diskMgmtGet ()
    if (status ~= "OK") then
        return "ERROR", "DISKMGMT_ERR_DB_QUERY_FAILED"
    end   

    -- compare the current value with the configured value and update if
    -- 'changed'
    for k,v in pairs (diskconf) do
        if (v.status ~= conf.shareSettings) then
            v.status = conf.shareSettings
            -- adding prefix
            v = util.addPrefix(v, "diskMgmtPartition.")
            --update table diskMgmtPartition.
            DBTable = "diskMgmtPartition"
             
            valid, statusStr = diskTr.config(v, v["diskMgmtPartition._ROWID_"], "edit")
            -- Return from function
            if (valid == false) then
                tr69Glue.tf1Dbg (statusStr)
                db.rollback ()
                return "ERROR", "DISK_CONFIG_FAILED"
            end
        end
    end

    --db.commitTransaction ()
    db.save() 
    return "OK", "STATUS_OK"
end

--[[
--*****************************************************************************
-- diskTr.config- Performs operations
-- 
-- This function is called to set the Sharing setup.
--
--
-- Returns: status
]]--
function diskTr.config (inputTable, rowid, operation)
    if (operation == "add") then
        return db.insert(DBTable,inputTable)
    elseif (operation == "edit") then
        return db.update(DBTable,inputTable,rowid)
    elseif (operation == "delete") then
        return db.delete(DBTable,inputTable)
    end
end

--[[
--*****************************************************************************
-- diskTr.diskVolFolderGet- get volume Folder info of the disk attached
-- 
-- This function is called to get the following parameters
-- Device.StorageService.0.LogicalVolume.0.Folder.0.
-- 
-- Name
-- Enable
-- UserAccountAccess
--
-- Returns: status, value
]]--

function diskTr.diskVolFolderGet (input)
    tr69Glue.tf1Dbg("Entering diskVolFolderGet..")
    local status = "0"
    local value = "0"
    local rowId
    local statusMsg, errMsg
    local row = {}
    local diskTbl = {}
    local paramTbl = {}
    local query = nil
    local diskQuery = nil
    local param = input["param"]
    
        
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --read the rowId mapping to packages
    rowId = instanceMap[param]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    -- Device.StorageService.0.LogicalVolume.0.Folder.0.Name
    -- Device.StorageService.0.LogicalVolume.0.Folder.0.Enable
    -- Device.StorageService.0.LogicalVolume.0.Folder.0.UserAccountAccess

    -- get corresponding db entry from diskMgmtPartition
    query = "_ROWID_=" .. rowId
    diskTbl = db.getRowWhere ("diskMgmtFolderInfo", query, false)
    if(diskTbl == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    
    --find & return parameter values
    if(string.find(input["param"], "Name")) then
        -- Name
        value = diskTbl ["folderPath"]
    elseif(string.find(input["param"], "Enable")) then
        value = 1
    elseif(string.find(input["param"], "UserAccountAccess")) then
        value = diskTbl ["UserAccess"]
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end  

    return status, value 
end

--[[
--*****************************************************************************
-- diskTr.diskVolFolderSet- set volume Folder info of the disk attached
-- 
-- This function is called to set the following parameters
-- Device.StorageService.0.LogicalVolume.0.Folder.0.
-- 
-- Name
-- Enable
-- UserAccountAccess
--
-- Returns: status
]]--
function diskTr.diskVolFolderSet (input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering diskTr.diskVolSet..")
    
    local status = "0"
    local row = {}
    local paramTbl = {}
    local rowId
    local query = nil
    local status = ""
    local errMsg = ""
    local conf = {}

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = "1"
        return "1";
    end

    --read the rowId mapping to pkgInstalledSystemDB
    rowId = instanceMap[tr69Param]
    if (rowId == nil) then
        status = "1"
        return "1";
    end

    if (input["diskMgmtFolderInfo"]["diskMgmtFolderInfo.folderPath"] ~= nil) then
        -- Name
        -- get corresponding db entry from diskMgmtFolderInfo
        query = "_ROWID_= " .. rowId
        row = db.getRowWhere ("diskMgmtFolderInfo", query, false)
        if(row == nil) then
           return "1", "DB_ERROR_TRY_AGAIN"
        end

       -- check for folder path
       local dbFolderPath = {}
       local confFolderPath = {}
       local found = 0
       
       dbFolderPath = util.split(row["folderPath"],"/")
       confFolderPath = util.split(input["diskMgmtFolderInfo"]["diskMgmtFolderInfo.folderPath"],"/")

       for k,v in pairs (dbFolderPath) do
           -- last part
           if (dbFolderPath[k+1] == nil) then
               if (confFolderPath[k] ~= nil and confFolderPath[k] ~= '' ) then
                   found = 1
               else
                    return 1
               end
           -- check all the part till the last one
           elseif (dbFolderPath[k] == confFolderPath[k]) then
           else
                return 1
           end
        end

          if (found == 1) then
              db.setAttribute ("diskMgmtFolderInfo", "_ROWID_", rowId, "folderPath", input["diskMgmtFolderInfo"]["diskMgmtFolderInfo.folderPath"])
              local cmd = "/bin/mv " .. row["folderPath"] .. " " .. input["diskMgmtFolderInfo"]["diskMgmtFolderInfo.folderPath"] 
          os.execute(cmd)
          end
    end

    
    if (input["diskMgmtFolderInfo"]["diskMgmtFolderInfo.folderEnable"] ~= nil or input["diskMgmtFolderInfo"]["diskMgmtFolderInfo.UserAccess"] ~= nil) then
        -- Enable or UserAccountAccess
        return 0
    end

return 0

end

--[[
--*****************************************************************************
-- diskTr.capConfigGet- get capability
-- 
-- This function is called to get the following parameter
-- Device.StorageService.0.
-- Enable
--
-- Returns: status, value
]]--

function diskTr.capConfigGet (input)
    tr69Glue.tf1Dbg("Entering capConfigGet..")
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local row = {}
    local query = nil
    local statusMsg, errMsg
    local param = input["param"]

    -- Device.StorageService.0.Capabilities
   
    statusMsg, errMsg, row = gui.administration.ftp.get ()
    
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    
   --find & return parameter values
    if (string.find(input["param"], "SFTPCapable")) then
        value = 0
    elseif(string.find(input["param"], "FTPCapable")) then
        -- Enable
        value = row ["enable"]
    elseif (string.find(input["param"], "HTTPCapable")) then
        value = 0
    elseif (string.find(input["param"], "HTTPSCapable")) then
        value = 0
    elseif (string.find(input["param"], "HTTPWritable")) then
        value = 0
    elseif (string.find(input["param"], "SupportedNetworkProtocols")) then
        value = "SMB"
    elseif (string.find(input["param"], "SupportedFileSystemTypes")) then
        value = "ext2,ext3"
    elseif (string.find(input["param"], "VolumeEncryptionCapable")) then
        value = 0
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end 

    return status, value 
end

function diskTr.getDiskInformation()
    local index = 0    
    local allDisks = {}
    local diskTbl = {}
    local partTbl = {}
    local disklen = 1
    local result = {}
    local errMsg, statusMsg
                                                
    allDisks = db.getTable ("diskMgmtVolume", false)
    if (allDisks == nil or allDisks == "") then
       return "ERROR","DISKMGMT_NO_DEVICE_FOUND"
    end
                 
    for k,v in pairs(allDisks) do                                                           
        errMsg, statusMsg, diskTbl, partTbl = gui.administration.disks.partitions.infoGet (v["deviceId"])
        if (errMsg ~= "OK") then
            return errMsg, statusMsg
        end
        if (partTbl ~= nil or partTbl ~= "") then
            for k, v in pairs (partTbl) do
                table.insert(result, v)
            end
        end
    end                                                    
    return "OK", "STATUS_OK", diskTbl, result
end

