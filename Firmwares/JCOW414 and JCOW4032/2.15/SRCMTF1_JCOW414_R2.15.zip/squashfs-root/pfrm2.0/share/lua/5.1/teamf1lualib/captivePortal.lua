--[[
#### Ashutosh Gautam
#### TeamF1
#### www.TeamF1.com
#### jul 16, 2013

#### File: captivePortal.lua
#### Description: Login functions.

#### Revisions:
01b 16oct13, ash changes for logging portal events
01a 16jul13, ash written 
]]--


--************* Requires *************
--require "captivePortalLib"
require "teamf1lualib/db"
require "captivePortalLib"
require "loginLib"

captivePortal = {}

CAPTIVE_PORTAL_DEFAULT_PROFILE_FOOTER = "Copyright 2016 TeamF1, Inc."

function captivePortal.Config (tableName, inputTable, rowid, operation)
    -- validate
    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
            return db.insert(tableName, inputTable)
        elseif (operation == "edit") then
            return db.update(tableName, inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete(tableName,inputTable)
        end
    end
    return false
end

-------------------------------------------------------------------------------
-- @name : captivePortal.confGet()
--
-- @description : API to get captivePortal configurations
--
-- @return : status, statusCode, captivePortalConf 
--
function captivePortal.confGet ()
    local statusQuery
    local confQuery
    local statRow = {}
    local confRow = {}

    -- Get captivePortal configuration
    statusQuery = "_ROWID_='1'"
    statRow = db.getRowWhere("captivePortal", statusQuery, false)
    if (statRow == nil) then
        return "ERROR", "CAPTIVE_PORTAL_CONF_ERROR"
    end

    -- Get interface configurations only when captive portal is enabled
    if (statRow["enable"] == "1") then
        confQuery = "ifName='bdg2'"
        confRow = db.getRowWhere("captivePortalVlan", confQuery, false)
        if (confRow == nil) then
            return "ERROR", "CAPTIVE_PORTAL_IF_CONF_ERROR"
        end
    end
    confRow["enable"] = statRow["enable"]

    return "OK", "STATUS_OK", confRow
end

-------------------------------------------------------------------------------
-- @name : captivePortal.configure()
--
-- @description : configure captive portal 
-- 
-- @return : status
--
function captivePortal.configure(conf)
    local stat = "ERROR"
    local errMsg =  "CAPTIVE_PORTAL_CONF_FAILED"
    local query = nil
    local portalRow = {}
    local portalVlanRow = {}
    local operation = nil
    local rowId = nil
    local valid = false

    if (conf == nil) then
        return "ERROR", "INVALID_CONF"
    end

    query = "_ROWID_='1'"
    portalRow = db.getRowWhere ("CaptivePortal", query, false)
    if (portalRow == nil) then
        return "ERROR", "CAPTIVE_PORTAL_CONF_ERROR"
    end

    portalRow["enable"] = conf["enable"]
    if (conf["enable"] == "1") then
        portalVlanRow["vlanId"] = conf["vlanId"]
        portalVlanRow["ifName"] = "bdg2" -- in future will construct base on vlanId
        portalVlanRow["accessType"] = conf["accessType"]
        portalVlanRow["authServerId"] = conf["authServerId"]
        portalVlanRow["profileId"] = conf["profileId"]
        portalVlanRow["redirectType"] = conf["redirectType"]
        if (db.existsRow("CaptivePortalVlan", "ifName", "bdg2")) then
            rowId = "1"
            operation = "edit"
        else
            operation = "add"
            rowId = "-1"
        end
    else
        query = "ifName = 'bdg2'"
        portalVlanRow = db.getRowWhere ("CaptivePortalVlan", query, false)
        if (portalVlanRow == nil) then
            return "ERROR", "CAPTIVE_PORTAL_VLAN_CONF_ERROR"
        end
        operation = "delete"
        rowId = portalVlanRow["_ROWID_"]
    end
    
    db.beginTransaction() --begin transaction

    portalRow = util.addPrefix (portalRow, "CaptivePortal.");
    valid = captivePortal.Config("CaptivePortal", portalRow, "1", "edit")

    if (valid) then
        portalVlanRow = util.addPrefix (portalVlanRow, "CaptivePortalVlan.");
        valid = captivePortal.Config ("CaptivePortalVlan", portalVlanRow, rowId, operation)
        if (valid) then
            db.commitTransaction(true)
        else
            db.rollback()
            return "ERROR", "CAPTIVE_PORTAL_CONF_FAILED"
        end
    else
        return "ERROR", "CAPTIVE_PORTAL_CONF_FAILED"
    end
    
    return "OK", "STATUS_OK"
end
-------------------------------------------------------------------------------
-- @name : captivePortal.getLoginStatus()
--
-- @description : API to get captivePortal login status
--
-- @return : status
--
function captivePortal.getLoginStatus ()
    local status
    local ipAddr = SAPI.Request.servervariable ("REMOTE_ADDR")
    ipAddr = string.gsub (ipAddr, "(%a*:)", "")
    local macAddr = captivePortalLib.macAddrGet (ipAddr)
    local query = "ipAddr = '" .. ipAddr.."'" .. " and macAddr = '" .. macAddr.."'" 
    
    -- Check row in captivePortalSession
    local row = db.getRowWhere ("CaptivePortalSession", query, false)
    if (row ~= nil) then
        status = "1"
    else
        status = "0"  
    end 

    return status
end

-------------------------------------------------------------------------------
-- @name : captivePortal.extAuthRadius()
--
-- @description : perform external radius Authentication
--
-- @return : status
--
function captivePortal.extAuthRadius(username, password, authType, errorStatus)
    local status
    local idletimeout
    local query
    local result, timeOut, sessionTimeOut = captivePortalLib.authenticate (username, password, authType)
    query = "UserName = '" .. username .. "'"
    local row = db.getRowWhere ("CaptivePortalSession", query, false)
    if (result == 0) then
        if (row ~= nil) then
            result = 1
            status = "SESSION_IN_PROGRESS"
        else
            result = 0
            status = "LOGGED_IN_SUCCESS"
        end
    else
        result = 2
        status = errorStatus
    end

    return result, status, timeOut
end

-------------------------------------------------------------------------------
-- @name : captivePortal.runTimeAuthenticate()
--
-- @description : perform runTime Authentication
--
-- @return : status
--
function captivePortal.runTimeAuthenticate (inputTable, vlanId, profileId)

    local result
    local status
    local idletimeout
    local query
    local row = {}

    local username = inputTable ["UserName"]
    local password = inputTable ["Password"]
    local userAgent = inputTable ["userAgent"]
    
    --Escape user input strings to avoid Sql Injections effect
    username = db.escape(username) 
    password = db.escape(password) 

    local query = "vlanId =" .. vlanId

    local row = db.getRowWhere("CaptivePortalVlan", query, false)
	
    local ipAddr = SAPI.Request.servervariable("REMOTE_ADDR")
    ipAddr = string.gsub (ipAddr, "(%a*:)", "")
    local macAddr = captivePortalLib.macAddrGet(ipAddr)
   
    -- Permanent CP Users
    if (row["accessType"] == "2") then
        --[[
	    --External Authentication
	    if(row["authServerId"] ~= "0") then
            local authMode = tonumber(row["authServerId"])
            local errorStatus = db.getAttribute ("CaptivePortalPageDetails", "profileId", profileId , "errorMessage")
		    local authType = authMode % 10
		    authMode = authMode-authType
	        if (authMode==10 ) then
        	    return captivePortal.extAuthRadius (username, password, authType, errorStatus) -- 1-PAP,2-CHAP,3-MS-CHAP,4-MS-CHAPv2
	        else
                return "ERROR", "AUTH_METHOD_NOT_SUPPORTED", idletimeout
	        end
	    else
		    row = nil
		    query = "username = '" .. username.."'" .. " and password = '" .. password.."'"
		    row = db.getRowWhere ("users", query, false)
	        --- check for rows
		    if (row ~= nil and captivePortal.isCaptivePortalUser(username)) then
                result, status=	captivePortal.CPSessionCheck(username)
                idletimeout = row["loginTimeout"]
				if(result == 1) then
					return result, status, idletimeout
				end
                result = 0
                status = "Succesfully logged in!"
                return result, status, idletimeout
		    end
   		    result = 2
		    status = db.getAttribute ("CaptivePortalPageDetails", "profileId", profileId, "errorMessage")    
		    return result, status, idletimeout
	    end
        ]]--
        usrRow = db.existsRow ("users", "username", username)
        if (usrRow) then
            -- Local authentication
			if (loginLib.userExists(username,password) == "1") then
            	query = "username = '" .. username.."'" .. " and password = '" .. password.."'"
		    	row = db.getRowWhere ("users", query, false)
	        	--- check for rows
		    	if (row ~= nil and captivePortal.isCaptivePortalUser(username)) then
                	result, status=	captivePortal.CPSessionCheck(username)
                	idletimeout = row["loginTimeout"]
					if(result == 1) then
						return result, status, idletimeout
					end
                	result = 0
                	status = "Succesfully logged in!"
                	return result, status, idletimeout
		    	end
			end
            	result = 2
		    	status = db.getAttribute ("CaptivePortalPageDetails", "profileId", profileId, "errorMessage")
                if (macAddr ~= "0") then
                    captivePortal.Log (macAddr, "login failed")
                end
		    	return result, status, idletimeout
        else
            local authType = db.getAttribute ("radiusClient", "_ROWID_", "1", "authType")
            if (authType ~= nil) then
                local errorStatus = db.getAttribute ("CaptivePortalPageDetails", "profileId", profileId , "errorMessage")
                result, status, idletimeout = captivePortal.extAuthRadius (username, password, authType, errorStatus)
                if (macAddr ~= "0" and result == 2) then
                    captivePortal.Log (macAddr, "login failed")
                end
                return result,status,idletimeout
            end
        end
    else
        return "ERROR", "USER_ACESS_NOT_SPPORTED", idletimeout
    end
end

-------------------------------------------------------------------------------
-- @name : captivePortal.runTimelogin()
--
-- @description : Add runTime session
--
-- @return : status
--
function captivePortal.runTimelogin (inputTable,profileId,vlanId,idletimeout)
    local valid = false
    local table = {}
    local tblName     = "CaptivePortalSession"
    local ipAddr      = SAPI.Request.servervariable("REMOTE_ADDR")
    ipAddr            = string.gsub (ipAddr, "(%a*:)", "")
    local username    = inputTable["UserName"]
    inputTable["idleTimeout"] = idletimeout
    inputTable["ipAddr"]      = ipAddr
    inputTable["macAddr"]     = captivePortalLib.macAddrGet(ipAddr)
    inputTable["ifName"]      = "bdg2"  
  
    --If macAddrGet fails
    if (inputTable["macAddr"] == "0") then
        return "ERROR", "MAC address not found, please ensure you are on the LAN subnet"
    end
    

    local rowid = db.getAttribute("CaptivePortalSession", "ipAddr", ipAddr, "_ROWID_")
    if (rowid ~= nil) then        
        db.deleteRow(tblName, "ipAddr", ipAddr)        
    end
    
    inputTable = util.addPrefix (inputTable, "CaptivePortalSession.");
    valid = captivePortal.Config ("CaptivePortalSession", inputTable, "-1", "add")
    
    if (valid) then
        captivePortal.Log (inputTable["CaptivePortalSession.macAddr"], "logged in")
    end

    local errMessage = db.getAttribute ("CaptivePortalPageDetails", "profileId", profileId, "errorMessage")
    --End of transaction 
    if (valid) then
        return "OK", "Succesfully logged in!"
    else
        return "ERROR", errMessage
    end        

end

-------------------------------------------------------------------------------
-- @name : captivePortal.runTimeLogout()
--
-- @description : Add runTime session
--
-- @return : status
--
function captivePortal.runTimeLogout ()

    local tblName = "CaptivePortalSession"
    local ipAddr  = SAPI.Request.servervariable("REMOTE_ADDR")
    ipAddr            = string.gsub (ipAddr, "(%a*:)", "")

    db.beginTransaction() --begin transaction
    local macAddr = captivePortalLib.macAddrGet(ipAddr)
    
    if (macAddr ~= "0") then
        captivePortal.Log (macAddr, "logged out")
    end

    local valid = db.deleteRow(tblName, "ipAddr", ipAddr)

     --End of transaction
    if (valid) then
        db.commitTransaction(true)
        return "OK", "Status OK"
    else
        db.rollback()
        return "ERROR", "Status not OK"
    end

end

function captivePortal.isEnabled ()
    
    local Status = db.getAttribute("CaptivePortal", "_ROWID_", "1", "enable")
    local profileId = 0
    local vlanId = 0
    if (Status == "1") then
        local host = SAPI.Request.servervariable ("HTTP_HOST")
        local vlans = db.getTable ("CaptivePortalVlan", false)
    	local i = 0
	    local j = 0
        for k, v in pairs (vlans) do
    	    i = i + 1
	        local vlan = vlans [i]
	        vlanId = vlan ["vlanId"]
	        profileId = vlan ["profileId"]
            if (vlan ["vlanId"] == "1") then 
            	vlan ["vlanId"] = "" 
            end
            if (Status == "1") then
                return Status, profileId, vlanId
            end    
        end             
    end
    return Status, profileId, vlanId
end  

-------------------------------------------------------------------------------
-- @name : captivePortal.changePassword()
--
-- @description : changes password
--
-- @return : status
--
function captivePortal.changePassword(inputTable)
    local tablename = "users"

    local ipAddr    = SAPI.Request.servervariable("REMOTE_ADDR")
    ipAddr            = string.gsub (ipAddr, "(%a*:)", "")
    local username   = db.getAttribute("CaptivePortalSession", "ipAddr", ipAddr, "UserName")
    local valid     = false
    local passwd    = inputTable["nPassword"]

--Escape user input strings to avoid Sql Injections effect
if (username ~= nil) then
	username = db.escape(username) 
	passwd = db.escape(passwd) 

    local query = "username = '" .. username .."'"
    local userrow = db.getRowWhere ("users", query, false)
    local macAddr = captivePortalLib.macAddrGet(ipAddr)
    
    if (captivePortal.isCaptivePortalUser(username)) then
        valid = db.setAttribute("users", "username", username, "password", passwd)
    else
        return "ERROR", "User is not local portal user"
    end

    if (valid) then
        valid = captivePortal.runTimeLogout () 
    end

    if (valid) then
        if (macAddr ~= "0") then
            local logStr = "changed password for " .. username
            captivePortal.Log (macAddr, logStr)
        end
    end
    if (valid) then
        return "OK", "Password has been changed"
    else
        return "ERROR", "Password could not be changed"
    end
else 
	return "ERROR", "The session has been disconnected. The Password change operation could not be performed"    
	end
end    

-------------------------------------------------------------------------------
-- @name : captivePortal.forcedLogin()
--
-- @description : changes password
--
-- @return : status
--
function captivePortal.forcedLogin(inputTable,profileId,vlanId)
    local tableName = "CaptivePortalSession"
    local username  = inputTable["UserName"]
    --Escape user input strings to avoid Sql Injections effect
    username = db.escape(username) 
    local idletimeout = db.getAttribute ("CaptivePortalSession", "UserName", username, "idleTimeout")
    local StatusMsg = "Could not login"
    local ipAddr    = SAPI.Request.servervariable("REMOTE_ADDR")
    ipAddr            = string.gsub (ipAddr, "(%a*:)", "")
    local macAddr   = captivePortalLib.macAddrGet(ipAddr)
    local stat = nil
    
    --If macAddrGet fails
    if (macAddr == "0") then
        return "ERROR", "MAC address not found, please ensure you are on the DSR's LAN subnet"
    end

    local valid = db.deleteRow(tableName, "UserName", username)
    local StatusMsg = "Could not delete"
    if (valid) then
        local temptable = {}
        temptable["UserName"] = username
        stat, StatusMsg = captivePortal.runTimelogin (temptable, profileId,vlanId, idleTimeout)
    end

    if (valid) then
        return "OK", StatusMsg
    else
        return "ERROR", StatusMsg
    end
end 


-------------------------------------------------------------------------------
-- @name : captivePortal.usersDisconnect()
--
-- @description : Disconnect users 
-- 
-- @return : status
--
function captivePortal.usersDisconnect(rows)
  
    db.beginTransaction() --begin transaction
    local valid
    if (rows ~= nil) then
        for k,v in pairs (rows) do
            valid = db.deleteRow ("CaptivePortalSession", "_ROWID_", v)
            if(not valid) then break
            end
        end   
    end    

    if (valid) then
        db.commitTransaction(true)
        return "OK", "STATUS_OK"
    else
        db.rollback()
        return "ERROR", "Operation Failed"
    end

end

-------------------------------------------------------------------------------
-- @name : captivePortal.CPSessionCheck()
--
-- @description : Check session 
-- 
-- @return : status
--
function captivePortal.CPSessionCheck(username)

	local query = "UserName = '" .. username .."'" 
	local row = db.getRowWhere ("CaptivePortalSession", query, false)
	if (row ~= nil) then
            local result = 1
       	    return result, "User Already Logged In !! "
	end
end


-------------------------------------------------------------------------------
-- @name : captivePortal.uploadHeaderImg()
--
-- @description :  
-- 
-- @return : status
--
function captivePortal.uploadHeaderImg(inputTable)
    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    local RowID = inputTable["imageIndex"]

    local fileName = cgilua.cookies.get("TeamF1Login")
    local extension = captivePortalLib.extensionGet (inputTable["file.upload"]["filename"])

    local name = "image" .. RowID .. "." .. extension

    -- Checking the size of the uploaded image.
    local fileSize = inputTable["file.upload"]["filesize"]

    if (tonumber(fileSize) > 100000) then
        return "ERROR", "File Size exceeded. Limit is 100kb", name
    end

    -- Remove the previous file
    local tmpName = db.getAttribute("ImageDetails", "_ROWID_", RowID, "name")
    os.execute("rm -rf" .. " " .. "/flash/tmp/capPort/" .. tmpName)

    local valid

    db.beginTransaction() --begin transaction

    -- Add the current file
    os.execute("mv" .. " " .. "/tmp/" .. fileName .. " /flash/tmp/capPort/" .. name)
    
    --Save it in Database
    local tempTable = {}
    tempTable["ImageDetails.name"] = name
    tempTable["ImageDetails.value"] = "1"

    valid = db.update ("ImageDetails", tempTable, RowID)

    --End of transaction 
    if (valid) then
        db.commitTransaction(true)
        return "OK", "STATUS_OK", name
    else
        db.rollback()
        return "ERROR", "Operation Failed", name
    end
end

-------------------------------------------------------------------------
-- @name captivePortal.profilesAddSet
--
-- @description 
--
-- @return 
--
function captivePortal.profilesAddSet(inputTable)
    local status
    local errCode
    
    if (inputTable == nil) then
        return "ERROR", "INVALID_CONF"
    end

    query = "configurationName = '" .. inputTable.configurationName .. "'"
	local row = db.getRowWhere("CaptivePortalPageDetails", query, false)
	if (row ~= nil) then
		return "ERROR","CAPTIVE_PROFILE_WITH_SAME_NAME_EXIST"
	end

    inputTable = util.addPrefix (inputTable, "CaptivePortalPageDetails."); 
    valid = captivePortal.Config("CaptivePortalPageDetails", inputTable, "-1", "add")
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "CAPTIVE_PROFILE_ADD_FAILED"
    end
end

-------------------------------------------------------------------------
-- @name captivePortal.profilesEditSet
--
-- @description 
--
-- @return 
--
function captivePortal.profilesEditSet(inputTable)
    local status
    local errCode
    
    if (inputTable == nil) then
        return "ERROR", "INVALID_CONF"
    end

    inputTable = util.addPrefix (inputTable, "CaptivePortalPageDetails.")
    
    local profileName = db.getAttribute ("CaptivePortalPageDetails", "_ROWID_", inputTable["CaptivePortalPageDetails._ROWID_"], "configurationName")

    if (profileName ~= nil and profileName == "default") then
        return "ERROR", "DEFAULT_CAPTIVE_PORTAL_PROFILE_CAN_NOT_EDIT"
    end

    valid = captivePortal.Config("CaptivePortalPageDetails", inputTable, inputTable["CaptivePortalPageDetails._ROWID_"], "edit")
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "CAPTIVE_PROFILE_EDIT_FAILED"
    end
end

-------------------------------------------------------------------------
-- @name captivePortal.profilesEditGet
--
-- @description 
--
-- @return 
--
function captivePortal.profilesEditGet(rowId)
    local status
    local errCode
    local query = nil
    local confRow = {}

    query = "_ROWID_= '" .. rowId .. "'"

    confRow = db.getRowWhere ("CaptivePortalPageDetails", query, false)
    if (confRow == nil) then
        return "ERROR", "CONF_NOT_EXIST", nil
    end

	confRow["title"] = util.filterXSSChars (confRow["title"])
	confRow["headerCaption"] = util.filterXSSChars (confRow["headerCaption"])

	if (confRow["LoginBoxTitle"] ~= nil) then
		confRow["LoginBoxTitle"] = util.filterXSSChars (confRow["LoginBoxTitle"])
	end

	if (confRow["welcomeMessage"] ~= nil ) then
		confRow["welcomeMessage"] = util.filterXSSChars (confRow["welcomeMessage"])
	end

	if (confRow["errorMessage"] ~= nil ) then
		confRow["errorMessage"] = util.filterXSSChars (confRow["errorMessage"])
	end

	if ( confRow["AdContent"] ~= nil) then
		confRow["AdContent"] = util.filterXSSChars (confRow["AdContent"])
	end

	if (confRow["FooterContent"] ~= nil) then
		confRow["FooterContent"] = util.filterXSSChars (confRow["FooterContent"])
	end

    return confRow
    
end

-------------------------------------------------------------------------------
-- @name : captivePortal.profilesDelete()
--
-- @description : delete profiles
-- 
-- @return : status
--
function captivePortal.profilesDelete(inputTable)
    local valid = false
    local vlanId = nil
    
    if (inputTable == nil) then
        return "ERROR", "CAPTIVE_PORTAL_PROFILE_DEL_FAILED"
    end
   
    local profileName = db.getAttribute ("CaptivePortalPageDetails", "_ROWID_", inputTable["CaptivePortalPageDetails._ROWID_"], "configurationName")

    if (profileName ~= nil and profileName == "default") then
        return "ERROR", "DEFAULT_CAPTIVE_PORTAL_PROFILE_CAN_NOT_DELETE"
    end

    local profileId = db.getAttribute ("CaptivePortalPageDetails", "_ROWID_", inputTable["CaptivePortalPageDetails._ROWID_"], "profileId")

	if (profileId == nil) then
		return "ERROR", "CAPTIVE_PORTAL_PROFILE_DEL_FAILED"
	end

    debug.Debugger("profileId")
    debug.Debugger(profileId)

    if (profileId ~= nil) then
        vlanId= db.getAttribute("CaptivePortalVlan", "profileId", profileId, "vlanId")
        if (vlanId ~= nil) then
            return "ERROR", "CAPTIVE_PORTAL_PROFILE_IN_USE"
        end
    end

    valid =  captivePortal.Config("CaptivePortalPageDetails", inputTable, inputTable["__ROWID__"], "delete")
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "CAPTIVE_PORTAL_PROFILE_DEL_FAILED"
    end
end

-------------------------------------------------------------------------
-- @name captivePortal.profilesGet
--
-- @description 
--
-- @return 
--
function captivePortal.profilesGet()
    return db.getTable("CaptivePortalPageDetails",false)
end

-------------------------------------------------------------------------
-- @name captivePortal.imagesGet
--
-- @description 
--
-- @return 
--
function captivePortal.imagesGet()
    return db.getTable("ImageDetails",false)
end

-------------------------------------------------------------------------
-- @name captivePortal.sessionGet
--
-- @description 
--
-- @return 
--
function captivePortal.sessionGet()
    return db.getTable("captivePortalSession",false)
end
-------------------------------------------------------------------------------
-- @name : captivePortal.isCaptivePortalUser()
--
-- @description : configure captivePortal 
-- 
-- @return : status
--
function captivePortal.isCaptivePortalUser(userName)
    local groupname = db.getAttribute ("users","userName", userName, "groupname")
    if(groupname ~= nil) then
        local row = db.getRow("groups", "name", groupname)
        if(row ~= nil) then
            local table = util.split (row["groups.capabilities"],",")
            for k,v in pairs (table) do
                if (v == "10") then
                    -- User is a captive portal user
                    return true
                end
            end
        end
    else
        return false
    end
end

-------------------------------------------------------------------------------
-- @name : captivePortal.Log()
--
-- @description : Log the lan client events
-- 
-- @return : status
--
function captivePortal.Log(mac, message)
    require "teamf1lualib/login"

    local status = "ERROR"
    local ssid = nil
    local logStr = nil

    if (mac == nil) then
        return "ERROR", "INVALID_MAC"
    end
    
    logStr = "Lan client with mac = ".. mac ..""
    --get ssid for wireless client
    status, ssid = login.ssidGet(mac)
    if (status == "OK") then
        logStr = logStr .. " connected to ssid = " .. ssid .. ""
    end

    logStr = logStr .. " " .. message
    stat = captivePortalLib.log (logStr)
    return stat
end
-------------------------------------------------------------------------------
-- @name : captivePortal.export()
--
-- @description : API to export tables related to captivePortal component
--
-- @return : lua table containing tables related to captivePortal component
-- 
function captivePortal.export ()
    local cPortalTbl = {}
    local table = {}
    table["CaptivePortal"] = {}
    table["CaptivePortalSession"] = {}
    table["CaptivePortalPageDetails"] = {}
    table["CaptivePortalVlan"] = {}
    table["ImageDetails"] = {}
    table["pageBackgroundImage"] = {}

	-- export CaptivePortal configurations
    table["CaptivePortal"] = db.getTable ("CaptivePortal", false)
    if (table["CaptivePortal"] ~= nil) then
        cPortalTbl["CaptivePortal"] = table["CaptivePortal"]
    end

    -- export CaptivePortalVlan configurations
    table["CaptivePortalVlan"] = db.getTable ("CaptivePortalVlan", false)
    if (table["CaptivePortalVlan"] ~= nil) then
        cPortalTbl["CaptivePortalVlan"] = table["CaptivePortalVlan"]
    end
   
    -- export CaptivePortalPageDetails configurations
    table["CaptivePortalPageDetails"] = db.getTable("CaptivePortalPageDetails", false)
    if (table["CaptivePortalPageDetails"] ~= nil) then
        cPortalTbl["CaptivePortalPageDetails"] = table["CaptivePortalPageDetails"]
    end
    
    -- export ImageDetails configurations
    table["ImageDetails"] = db.getTable ("ImageDetails", false)
    if (table["ImageDetails"] ~= nil) then
        cPortalTbl["ImageDetails"] = table["ImageDetails"]
    end

    -- export pageBackgroundImage configurations
    table["pageBackgroundImage"] = db.getTable ("pageBackgroundImage", false)
    if (table["pageBackgroundImage"] ~= nil) then
        cPortalTbl["pageBackgroundImage"] = table["pageBackgroundImage"]
    end

    --[[
     -- export CaptivePortalSession configurations
    table["CaptivePortalSession"] = db.getTable("CaptivePortalSession", false)
    if (table["CaptivePortalSession"] ~= nil) then
        cPortalTbl["CaptivePortalSession"] = table["CaptivePortalSession"]
    end
     ]]--

	return cPortalTbl
end

-------------------------------------------------------------------------------
-- @name : captivePortal.import()
--
-- @description : API to import 'captivePortal' tables
--
-- @return : None
-- 
function captivePortal.import (inputTable, defaultCfg, remCfg)
	if (inputTable == nil) then
		inputTable = defaultCfg
	end

    local valid = false
    local CaptivePortalTmp = {}
    local CaptivePortalSessionTmp = {}
    local CaptivePortalPageDetailsTmp = {}
    local CaptivePortalVlanTmp = {}
    local ImageDetailsTmp = {}
    local pageBackgroundImageTmp = {}


	-- import CaptivePortal
        CaptivePortalTmp = config.update (inputTable.CaptivePortal, defaultCfg.CaptivePortal, remCfg.CaptivePortal)
        if (CaptivePortalTmp ~= nil and #CaptivePortalTmp ~= 0) then
            for i,v in ipairs (CaptivePortalTmp) do
                v = util.addPrefix (v, "CaptivePortal.");
                captivePortal.Config ("CaptivePortal", v, "-1", "add")
            end
        end
    
        -- import CaptivePortalVlan
        CaptivePortalVlanTmp = config.update (inputTable.CaptivePortalVlan, defaultCfg.CaptivePortalVlan, remCfg.CaptivePortalVlan)
        if (CaptivePortalVlanTmp ~= nil and #CaptivePortalVlanTmp ~=  0) then
            for i,v in ipairs (CaptivePortalVlanTmp) do
                v = util.addPrefix (v, "CaptivePortalVlan.");
                captivePortal.Config ("CaptivePortalVlan", v, -1, "add")
            end
        end

      -- import CaptivePortalPageDetails
        CaptivePortalPageDetailsTmp = config.update (inputTable.CaptivePortalPageDetails, defaultCfg.CaptivePortalPageDetails, remCfg.CaptivePortalPageDetails)
        if (CaptivePortalPageDetailsTmp ~= nil and #CaptivePortalPageDetailsTmp ~= 0) then
            for i,v in ipairs (CaptivePortalPageDetailsTmp) do
				if (v.configurationName == "default" ) then
					v.FooterFontColor = "4"
					-- for default there is no edit option in GUI, so copyright year can be enforced SPR:56974
					v.FooterContent = CAPTIVE_PORTAL_DEFAULT_PROFILE_FOOTER
				end
                v = util.addPrefix (v, "CaptivePortalPageDetails.");
                captivePortal.Config ("CaptivePortalPageDetails", v, -1, "add")
            end
        end

    
        -- import ImageDetails
        ImageDetailsTmp = config.update (inputTable.ImageDetails, defaultCfg.ImageDetails, remCfg.ImageDetails)
        if (ImageDetailsTmp ~= nil and #ImageDetailsTmp ~=  0) then
            for i,v in ipairs (ImageDetailsTmp) do
                v = util.addPrefix (v, "ImageDetails.");
                captivePortal.Config ("ImageDetails", v, -1, "add")
            end
        end

        -- import pageBackgroundImage
        pageBackgroundImageTmp = config.update (inputTable.pageBackgroundImage, defaultCfg.pageBackgroundImage, remCfg.pageBackgroundImage)
        if (pageBackgroundImageTmp ~= nil and #pageBackgroundImageTmp ~=  0) then
            for i,v in ipairs (pageBackgroundImageTmp) do
                v = util.addPrefix (v, "pageBackgroundImage.");
                captivePortal.Config ("pageBackgroundImage", v, -1, "add")
            end
        end

        --[[
        -- import CaptivePortalSession
        CaptivePortalSessionTmp = config.update (inputTable.CaptivePortalSession, defaultCfg.CaptivePortalSession, remCfg.CaptivePortalSession)
        if (CaptivePortalSessionTmp ~= nil and #CaptivePortalSessionTmp ~= 0) then
            for i,v in ipairs (CaptivePortalSessionTmp) do
                v = util.addPrefix (v, "CaptivePortalSession.");
                captivePortal.Config ("CaptivePortalSession", v, "-1", "add")
            end
        end
        ]]--
end

-- Register 'captivePortal' with 'config' to facilitate import and export  
if (config.register) then
   config.register("captivePortal", captivePortal.import, captivePortal.export, "1")
end

