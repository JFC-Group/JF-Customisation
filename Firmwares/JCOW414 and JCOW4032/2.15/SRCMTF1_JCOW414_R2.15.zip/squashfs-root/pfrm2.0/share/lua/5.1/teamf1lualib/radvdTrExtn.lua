--[[
#### Copyright (c) 2014, TeamF1 Networks Pvt. Ltd. 
#### (Subsidiary of D-Link India)
#### 
#### File: tr181_radvdTrExtn.lua
#### Description: 
#### TR-181 handlers for radvd. This file is included from tr181_tr69funcs.lua
####

#### Revisions:
01b,31Oct17,swr  Changes for SPR 59254(radvd prefixes)
01a,12Jan17,swr  Changes for SPR 58467.
]]--

radvdTr = {}

require "teamf1lualib/radvd"
require "teamf1lualib/radvdPrefix"

local dbFlag = 0
--[[
--*****************************************************************************
-- radvdTr.getRadvdPrefixes - get IPv6Prefix instance name
-- 
-- Returns: IPv6Prefix instance name or nil
]]--
function radvdTr.getRadvdPrefixes(prefixType)
    local ipv6TableRow = {}
    local query = nil
    local mainVal = ""
    local staticIP = ""
    local prefixObj = ""
    local value = ""
    local breakFlag = 0

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return value
    end

    prefixObj = "Device.IP.Interface.2.IPv6Prefix."

    query = "prefixType='AUTO' and LogicalIfName='IF2' and addressFamily=10"
    ipv6TableRow = db.getRowsWhere ("ipv6PrefixTable", query, false)
    if(ipv6TableRow == nil) then
        return value 
    end

    if(prefixType == "All") then
        query = "LogicalIfName='IF2'"
        stat, errMsg, prefixRow = radvdPrefix.get(query)
    else
        query = "LogicalIfName='IF2' and radvdPrefixType=2"
        stat, errMsg, prefixRow = radvdPrefix.get(query)
    end

    if (prefixRow ~= nil) then
        for k,v in pairs (prefixRow) do
            if (value == "") then
                for name,val in pairs (instanceMap) do
                    if(string.find(name, prefixObj) and string.find(name, "Enable")) then
                        for k1, v1 in pairs(ipv6TableRow) do
                            prefixIpv6Addr = nimfLib.prefixGet(v1["ipAddress"], v1["ipv6PrefixLen"])
                            prefixRadvd = nimfLib.prefixGet(v["radvdAdvPrefix"], v["radvdAdvPrefixLength"])
                            if(prefixIpv6Addr == prefixRadvd) then
                                if(tonumber(val) == tonumber(v1["_ROWID_"])) then
                                    len = string.len(name)
                                    mainVal = string.sub(name, 1, len-6)
                                    breakFlag = 1
                                    break; 
                                end
                            end
                        end
                        if(breakFlag == 1) then
                            break;
                        end
                    end
                end
                value = mainVal
            else
                breakFlag = 0
                for name,val in pairs (instanceMap) do
                    if(string.find(name, prefixObj) and string.find(name, "Enable")) then
                        for k1, v1 in pairs(ipv6TableRow) do
                            prefixIpv6Addr = nimfLib.prefixGet(v1["ipAddress"], v1["ipv6PrefixLen"])
                            prefixRadvd = nimfLib.prefixGet(v["radvdAdvPrefix"], v["radvdAdvPrefixLength"])
                            if(prefixIpv6Addr == prefixRadvd) then
                                if(tonumber(val) == tonumber(v1["_ROWID_"])) then
                                    len = string.len(name)
                                    mainVal = string.sub(name, 1, len-6)
                                    breakFlag = 1
                                    break; 
                                end
                            end
                        end
                        if(breakFlag == 1) then
                            break;
                        end
                    end
                end
                value = value .. ',' .. mainVal
            end
        end
    end
    
    return value
end

--[[
--*****************************************************************************
-- radvdTr.configGet - get radvd configuration
-- 
-- TR69 Parameter: Device.RouterAdvertisement.
--
]]--

function radvdTr.configGet (input)
    local status = "0"
    local value = "0"
    local rowId
    local row = {}
    local query = nil
    local stat
    local errMsg
    local prefixRow = {}

    --get corresponding db entry from 'radvd'
    query = "_ROWID_=1"
    row = db.getRowWhere ("radvd", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = row["isEnabled"]
    elseif(string.find(input["param"], "Status")) then
        -- DefaultPolicy
        if(row["isEnabled"] == "0") then
            value = "Disabled"
        elseif(row["isEnabled"] == "1") then
            value = "Enabled"
        else
            return "1", "DB_ERROR_TRY_AGAIN"
        end
    elseif(string.find(input["param"], "Alias")) then
        value = "default" .. row["_ROWID_"]
    elseif(string.find(input["param"], "MaxRtrAdvInterval")) then
        value = row["MaxRtrAdvInterval"]
    elseif(string.find(input["param"], "AdvDefaultLifetime")) then
        value = row["AdvDefaultLifetime"]
    elseif(string.find(input["param"], "AdvManagedFlag")) then
        value = row["AdvManagedFlag"]
    elseif(string.find(input["param"], "AdvOtherConfigFlag")) then
        value = row["AdvOtherConfigFlag"]
    elseif(string.find(input["param"], "MinRtrAdvInterval")) then
        value = row["MinRtrAdvInterval"]
    elseif(string.find(input["param"], "AdvMobileAgentFlag")) then
        value = row["AdvMobileAgentFlag"]
    elseif(string.find(input["param"], "AdvCurHopLimit")) then
        value = row["AdvCurHopLimit"]
    elseif(string.find(input["param"], "AdvReachableTime")) then
        value = row["AdvReachableTime"]
    elseif(string.find(input["param"], "AdvRetransTimer")) then
        value = row["AdvRetransTimer"]
    elseif(string.sub(input["param"], 47, -1) == "ManualPrefixes") then
        value = radvdTr.getRadvdPrefixes("Manual")
    elseif(string.find(input["param"], "AdvPreferredRouterFlag")) then
        if (row["AdvDefaultPreference"] == "1") then
            value = "Low"
        elseif (row["AdvDefaultPreference"] == "2") then
            value = "Medium"
        elseif (row["AdvDefaultPreference"] == "3") then
            value = "High"
        end
    elseif(string.find(input["param"], "AdvLinkMTU")) then
        value = row["AdvLinkMTU"]
    elseif (string.sub(input["param"], 47, -1) == "Prefixes") then
        value = radvdTr.getRadvdPrefixes("All")
    elseif(string.find(input["param"], "Interface")) then
        -- Interface
        -- find the corresponding interface entry from instanceMap using LogicalIfName
        local logicalIfName = "IF2"
        local lanIfaceObj = ""
        lanIfaceObj = nimfTr.getIfaceObjFromIfname(logicalIfName)
        value = lanIfaceObj
        if(value == nil or value == "") then
            return "1", "DB_ERROR_TRY_AGAIN"
        end
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- radvdTr.configSet - set radvd configuration
-- 
-- TR69 Parameter: Device.RouterAdvertisement.
--
]]--

function radvdTr.configSet (input, rowids, actionType, tr69Param)

    local status = "0"
    local row = {}
    local rowId
    local query = nil
    local radvdRow = {}
    local faultTbl = {}
    local index = 0
    local multiSubnetCfgSave = 0

    --get corresponding db entry from 'radvd'
    query = "_ROWID_=1"
    row = db.getRowWhere ("radvd", query, false)
    if(row == nil) then
        tr69Glue.tf1Dbg("Couldn't fetch corresponding radvd row..")
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    radvdRow = row

    if (input["radvd"]["radvd.Enable"] ~= nil) then
        radvdRow["isEnabled"] = input["radvd"]["radvd.Enable"]
        multiSubnetCfgSave = 1
    end

    if (input["radvd"]["radvd.MaxRtrAdvInterval"] ~= nil) then
        if((tonumber(input["radvd"]["radvd.MaxRtrAdvInterval"]) >= 10) and (tonumber(input["radvd"]["radvd.MaxRtrAdvInterval"]) <= 1800)) then
            radvdRow["MaxRtrAdvInterval"] = input["radvd"]["radvd.MaxRtrAdvInterval"]
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."MaxRtrAdvInterval", error_code.INVALID_PARAM_VALUE)
        end
    end

    if (input["radvd"]["radvd.AdvDefaultLifetime"] ~= nil) then
        if((tonumber(input["radvd"]["radvd.AdvDefaultLifetime"]) >= 30) and (tonumber(input["radvd"]["radvd.AdvDefaultLifetime"]) <= 9000)) then
            radvdRow["AdvDefaultLifetime"] = input["radvd"]["radvd.AdvDefaultLifetime"]
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."AdvDefaultLifetime", error_code.INVALID_PARAM_VALUE)
        end
    end

    if (input["radvd"]["radvd.AdvManagedFlag"] ~= nil) then
        radvdRow["AdvManagedFlag"] = input["radvd"]["radvd.AdvManagedFlag"]
    end
    
    if (input["radvd"]["radvd.AdvOtherConfigFlag"] ~= nil) then
        radvdRow["AdvOtherConfigFlag"] = input["radvd"]["radvd.AdvOtherConfigFlag"]
    end

    if (input["radvd"]["radvd.MinRtrAdvInterval"] ~= nil) then
        if((tonumber(input["radvd"]["radvd.MinRtrAdvInterval"]) >= 3) and (tonumber(input["radvd"]["radvd.MinRtrAdvInterval"]) <= 1350)) then
            radvdRow["MinRtrAdvInterval"] = input["radvd"]["radvd.MinRtrAdvInterval"]
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."MinRtrAdvInterval", error_code.INVALID_PARAM_VALUE)
        end
    end

    if (input["radvd"]["radvd.AdvReachableTime"] ~= nil) then
        if((tonumber(input["radvd"]["radvd.AdvReachableTime"]) >= 0) and (tonumber(input["radvd"]["radvd.AdvReachableTime"]) <= 3600000)) then
            radvdRow["AdvReachableTime"] = input["radvd"]["radvd.AdvReachableTime"]
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."AdvReachableTime", error_code.INVALID_PARAM_VALUE)
        end
    end

    if (input["radvd"]["radvd.AdvRetransTimer"] ~= nil) then
        radvdRow["AdvRetransTimer"] = input["radvd"]["radvd.AdvRetransTimer"]
    end

    if (input["radvd"]["radvd.AdvCurHopLimit"] ~= nil) then
        if((tonumber(input["radvd"]["radvd.AdvCurHopLimit"]) >= 0) and (tonumber(input["radvd"]["radvd.AdvCurHopLimit"]) <= 255)) then
            radvdRow["AdvCurHopLimit"] = input["radvd"]["radvd.AdvCurHopLimit"]
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."AdvCurHopLimit", error_code.INVALID_PARAM_VALUE)
        end
    end

    if (input["radvd"]["radvd.AdvMobileAgentFlag"] ~= nil) then
        radvdRow["AdvMobileAgentFlag"] = input["radvd"]["radvd.AdvMobileAgentFlag"]
    end

    if (input["radvd"]["radvd.AdvPreferredRouterFlag"] ~= nil) then
        if (input["radvd"]["radvd.AdvPreferredRouterFlag"] == "Low") then
            radvdRow["AdvDefaultPreference"] = 1
        elseif (input["radvd"]["radvd.AdvPreferredRouterFlag"] == "Medium") then
            radvdRow["AdvDefaultPreference"] = 2
        elseif (input["radvd"]["radvd.AdvPreferredRouterFlag"] == "High") then
            radvdRow["AdvDefaultPreference"] = 3
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."AdvPreferredRouterFlag", error_code.INVALID_PARAM_VALUE)
        end
    end

    if (input["radvd"]["radvd.AdvLinkMTU"] ~= nil) then
        if((tonumber(input["radvd"]["radvd.AdvLinkMTU"]) >= 1280) and (tonumber(input["radvd"]["radvd.AdvLinkMTU"]) <= 1500)) then
            radvdRow["AdvLinkMTU"] = input["radvd"]["radvd.AdvLinkMTU"]
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."AdvLinkMTU", error_code.INVALID_PARAM_VALUE)
        end
    end

    if (status == ERROR) then
        return status, faultTbl
    end

    tr69Glue.tf1Dbg("Calling radvd Configure ")

    radvdRow = util.addPrefix(radvdRow, "radvd.")
    local valid, errstr = db.update("radvd", radvdRow, radvdRow["radvd._ROWID_"])
    if (not valid) then        
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    local radvdTbl = db.getTable ("radvd", false)
    if (radvdTbl ~= nil and #radvdTbl > 0) then
        for k,v in pairs(radvdTbl) do
            if(multiSubnetCfgSave == 1 and v["LogicalIfName"] ~= "IF2") then
                tr69Glue.tf1Dbg("rowid .. " .. v["_ROWID_"])
                db.setAttribute("radvd", "_ROWID_", v["_ROWID_"], "isEnabled", radvdRow["radvd.isEnabled"])
            end
        end
    end
        
    db.save()

    tr69Glue.tf1Dbg("Leaving radvdConfigSet..")
    return status, faultTbl;
end

--[[
--*****************************************************************************
-- radvdTr.optionConfigSet - set radvd options configuration
-- 
-- TR69 Parameter: Device.RouterAdvertisement.InterfaceSetting.0.Option.
--
]]--

function radvdTr.optionConfigSet (input, rowids, actionType, tr69Param)

    local status = "0"
    local row = {}
    local rowId
    local query = nil
    local radvdOptionRow = {}
   
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --read the rowId mapping to radvdLANPrefixPool
    rowId = instanceMap[tr69Param]
    if (rowId == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get corresponding db entry from radvdLANPrefixPool
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("radvdLANPrefixPool", query, false)
    if(row == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    radvdOptionRow = row
    
    --Enable
    if(input["radvdLANPrefixPool"]["radvdLANPrefixPool.Enable"] ~= nil) then
        radvdOptionRow["Enable"] = tonumber (input["radvdLANPrefixPool"]["radvdLANPrefixPool.Enable"])
    end

    if(input["radvdLANPrefixPool"]["radvdLANPrefixPool.Value"] ~= nil) then
        radvdOptionRow["radvdAdvPrefix"] = input["radvdLANPrefixPool"]["radvdLANPrefixPool.Value"] .. "::"
    end

    radvdOptionRow = util.addPrefix(radvdOptionRow, "radvdLANPrefixPool.")
    local valid, errstr = db.update("radvdLANPrefixPool", radvdOptionRow,
                                    radvdOptionRow["radvdLANPrefixPool._ROWID_"])
    if (not valid) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end           
    
    db.save()

    tr69Glue.tf1Dbg("Leaving radvdOptionConfigSet..")
    return 0;
end

--[[
--*****************************************************************************
-- radvdTr.optionConfigGet - get radvd option Configuration
-- 
-- TR69 Parameter: Device.RouterAdvertisement.InterfaceSetting.0.Option
--
]]--

function radvdTr.optionConfigGet (input)
    local status = "0"
    local value = "0"
    local rowId
    local row = {}
    local query = nil
    local stat
    local errMsg
    local prefixRow = {}

    
  
    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --read the rowId mapping to radvdLANPrefixPool
    rowId = instanceMap[param]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from radvdLANPrefixPool
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("radvdLANPrefixPool", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        value = row["Enable"]
    elseif(string.find(input["param"], "Tag")) then
        value = 3
    end

    return status, value
end

--[[
--*****************************************************************************
-- fwTr.radvdOptionAdd - Add port radvd prefix pool
-- 
-- This function is called to add the following profile
--
-- Device.RouterAdvertisement.InterfaceSetting.0.Option.
--
-- Returns: status
]]--
function radvdTr.radvdOptionAdd(input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering radvdOptionAdd..")

    local status = OK
    local errorFlag
    local row = {}
    local query = nil

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR
        return status
    end

    -- Filling the parameters of radvdLANPrefixPool when Add Object for Option is called
    rows = db.getTable ("radvdLANPrefixPool", false)
    tr69Glue.tf1Dbg("Number of Rows Present .." ..#rows)
    input["LogicalIfName"] = "IF2" 
    input["Enable"] = "1" 
    input["radvdPrefixType"] = "2"
    input["Base6to4Interface"] = ""
    input["SLAIdentifier"] = ""
    input["radvdAdvPrefix"] = "fd01::"
    input["radvdAdvPrefixLength"] = "64"
    input["radvdAdvPrefixLifetime"] = "3600"
    
    require "teamf1lualib/gui"
    require "teamf1lualib/netipv6dhcp"
    statusCode, errorString = gui.networking.radvdPrefix.add.set (input, dbFlag)

    if (statusCode ~= "OK") then
        tr69Glue.tf1Dbg("errorString : " .. errorString)
        return error_code.REQUEST_DENIED;
    end

    tr69Glue.tf1Dbg("Leaving radvdOptionAdd..")
    return status;
end
