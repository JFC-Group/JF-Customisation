--[[ dot11_ul.lua - dot11 checks .
--
-- Copyright (c) 2008-2017, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: dot11_ul.lua
-- Description: .
-- 
-- modification history
-- --------------------
-- 01a, 20Jul17, sjr written.
--
--]]
--
--
--requires
require "teamf1lualib/dot11"

--table packages
ul_dot11 = {}

-- Profiles Setup
ul_dot11.ProfileInfo = {}

-- AP setup
ul_dot11.apProfileInfo = {}
ul_dot11.apProfileInfo.edit = {}

-- wps setup
ul_dot11.wps = {}

-- ieee1905 setup
ul_dot11.ieee1905 = {}

-- radio setup
ul_dot11.radio = {}

-- acl setup
ul_dot11.acl = {}
ul_dot11.acl.add = {}

-- wmm setup
ul_dot11.wmm = {}

------------------------------------------------------------------------
--@name securityCheck
--
--@description this functions checks securityCheck
--
--@return status, errCode
------------------------------------------------------------------------

function securityCheck (inputTable, radio1Table, radio2Table)
    
    -- locals
    local profileName = nil
    local radioNo1query = "radioNo=1"
    local radioNo2query = "radioNo=2"
    local radio1interfacetable = {}
    local radio2interfacetable = {}

    --check for the security as TKIP/WEP of the radio1 active profile when
    --802.11n mode in active
    radio1interfacetable = db.getRowsWhere ("dot11Interface", radioNo1query, false)
    for i,j in pairs(radio1interfacetable)do
        profileName = db.getAttribute ("dot11VAP","vapName",j["vapName"],"profileName")
        if(profileName == inputTable ["dot11Profile.profileName"] )then
            if((inputTable ["dot11Profile.security"] == "WPA" or inputTable ["dot11Profile.security"] == "WEP") and ((radio1Table["band"] == "a" and (radio1Table["opMode"] == "2" or radio1Table["opMode"] == "3" or string.find(radio1Table["opMode"], "na"))) or (radio1Table["band"] == "b" and (radio1Table["opMode"] == "4" or radio1Table["opMode"] == "5" or string.find(radio1Table["opMode"], "ng")))))then
                return "ERROR", "WEP and WPA only security not allowed when radio is configured in 802.11n mode"
            end
        end
    end
    
    --checking for the security as TKIP/WEP of the radio2 active profile
    --when 802.11n mode in active
    radio2interfacetable = db.getRowsWhere ("dot11Interface", radioNo2query, false)
    for i,j in pairs(radio2interfacetable)do
        profileName = db.getAttribute ("dot11VAP","vapName",j["vapName"],"profileName")
        if(profileName == inputTable ["dot11Profile.profileName"] )then
            if((inputTable ["dot11Profile.security"] == "WPA" or inputTable ["dot11Profile.security"] == "WEP") and ((radio2Table["band"] == "a" and (radio2Table["opMode"] == "2" or radio2Table["opMode"] == "3" or radio2Table["opMode"] == "na")) or (radio2Table["band"] == "b" and (radio2Table["opMode"] == "4" or radio2Table["opMode"] == "5" or string.find(radio2Table["opMode"], "ng")))))then
                return "ERROR", "WEP and WPA only security not allowed when radio is configured in 802.11n mode"
            end
        end
    end

    return "OK", "STATUS_OK"

end

-------------------------------------------------------------------------------
-- @name securityGet - get security configuration
--
-- @description This function gets the security configuration for a given type
-- 
-- @return nil on error
-------------------------------------------------------------------------------

function securityGet(security,pairwiseCiphers,wepAuth,groupCipher)
    
    --require
    require "teamf1lualib/wifiSecMap"

    for i,v in ipairs(securityStrs) do
        if ((security == v[2]) and (security == "OPEN")) then
            return v
        elseif((security == v[2]) and ((security == "WPA") or (security == "WPA2") or (security == "WPA+WPA2")) and (pairwiseCiphers == v[3])) then
            return v
        elseif ((security == v[2]) and (security == "WEP") and (wepAuth == v[5]) and (groupCipher == v[6])) then
            return v
        end
    end

    --return
    return nil

end

-------------------------------------------------------------------------------
-- @name wpsCheck
--
-- @description this function doesn't allow Radius security when WPS is enabled
--              on Profile
--             
-- @return status, errorCode
-------------------------------------------------------------------------------
function wpsCheck (inputTable)

    local vapName
    local interfaceName
    local matchingRow

    if ((inputTable["dot11Profile.security"] =="WEP") or (inputTable["dot11Profile.security"] =="OPEN") or (inputTable["dot11Profile.security"] =="WPA") or (inputTable["dot11Profile.authMethods"] == "RADIUS")) then
        vapName = db.getAttribute("dot11VAP", "profileName",inputTable["dot11Profile.profileName"], "vapName")
        if (vapName ~= nil) then
            -- This profile is being used by one of the AP.So need to check WPS dependency.
            interfaceName = db.getAttribute("dot11Interface", "vapName",vapName, "interfaceName")
            matchingRow = db.existsRowWhere("dot11WPS", "vapName = '" .. vapName .. "'")
            if (matchingRow) then
                return "ERROR", "WPS is enabled on AP using this profile, Cannot set security/auth methods to OPEN/RADIUS"
            end
        end
    end

    return "OK", "STATUS_OK"

end

------------------------------------------------------------------------------
-- @name duplicateSSIDcheck
--
-- @description this function checks duplicate SSID's on each Radio
--
-- @return status, errCode
------------------------------------------------------------------------------
function duplicateSSIDcheck (inputTable)

    local profile_2_4_end = 3
    local dot11Profiles = nil

    -- ssid: extra heading and trailing spaces	
    if (string.sub(inputTable["dot11Profile.ssid"], 1, 1) == ' ' or string.sub(inputTable["dot11Profile.ssid"], -1, -1) == ' ') then
        return "ERROR", "Spaces are not allowed before or after SSID"
    end
 
    dot11Profiles = db.getRowsWhere ("dot11Profile", "ssid='"..inputTable ["dot11Profile.ssid"].."' and _ROWID_!='"..inputTable["_ROWID_"].."'", false)
    if (dot11Profiles ~= nil ) then
        for k,v in pairs (dot11Profiles) do
            if (tonumber(v["_ROWID_"]) <= profile_2_4_end and tonumber(inputTable["_ROWID_"]) <= profile_2_4_end) then
                return "ERROR", "SSID is already present in "..v["profileName"].." profile"
            end
            if (tonumber(v["_ROWID_"]) > profile_2_4_end and  tonumber(inputTable["_ROWID_"]) > profile_2_4_end) then
                return "ERROR", "SSID is already present in "..v["profileName"].." profile"
            end 	
        end
    end

    return "OK","STATUS_OK"

end
-------------------------------------------------------------------------------
--@name radioSecuritCheck
--
--@description function checks security WEP/WPA while configuting 802.11n
--
--@return status, errCode
-------------------------------------------------------------------------------
function radioSecurityCheck (inputTable, apInterfacetable)

    --locals
    local profileName
    local profileRow = {}

    for i,j in pairs(apInterfacetable)do
       profileName = db.getAttribute ("dot11VAP","vapName",j["vapName"],"profileName")
       profileRow = db.getRow ("dot11Profile","profileName",profileName)
       --for 2.4Ghz radios 
       if inputTable["band"] == "b" then
           if((profileRow["dot11Profile.security"] == "WPA" or profileRow["dot11Profile.security"] == "WEP") and (inputTable["opMode"] == "4" or inputTable["opMode"] == "5" or string.find(radioTable["opMode"], "ng")))then
               return "ERROR", "802.11n mode not allowed if any wireless profile is configured in WEP or WPA only mode"
           end
       end
       --for 5Ghz radios 
       if inputTable["band"] == "a" then
           if((profileRow["dot11Profile.security"] == "WPA" or profileRow["dot11Profile.security"] == "WEP") and (inputTable["opMode"] == "2" or inputTable["opMode"] == "3" or string.find(radioTable["opMode"], "na")))then
               return "ERROR", "802.11n mode not allowed if any wireless profile is configured in WEP or WPA only mode"
           end
       end
    end

    return "OK","STATUS_OK"

end

---------------------------------------------------------------------------------
--@name vapWPScheck
--
--@description this function prevents to disable AP when WPS is enabled on it.
--
--@return status, errCode
---------------------------------------------------------------------------------
function vapWPScheck (vapRows)

    --locals
    local vapName = nil
    local vapInterfaceName = nil
    local wpsStatus = nil
    local wpsTable = {}

    for k,v in pairs (vapRows) do
        --DB query to get the VAP name from dot11VAP sqlite3 table
        vapName = db.getAttribute("dot11VAP", "dot11VAP._ROWID_", v,"vapName")
        if(vapName ~= nil and vapName ~= '' and vapName ~= " ") then
            --DB query to get the interface name from dot11Interface sqlite3 table based on the vapName.
            vapInterfaceName = db.getAttribute("dot11Interface", "vapName", vapName,"interfaceName")
            if(vapInterfaceName ~= nil and vapInterfaceName ~= '' and vapInterfaceName ~= " ") then
                --DB query to check WPS is enabled on Interface or not. 
                wpsStatus = db.getAttribute("dot11wps","vapName",vapInterfaceName,"wpsEnabled")
                if(wpsStatus ~= nil and wpsStatus ~='' and wpsStatus ~= " ") then
                    if( tonumber(wpsStatus) == tonumber(1) and operation == "disable")then
                        wpsTable["dot11WPS.vapName"] = vapInterfaceName
                        wpsTable["dot11WPS.wpsEnabled"] = "0"
                        errMsg,status = dot11.WPS_config(wpsTable, "1", "edit")
                    end
                end
            end -- vapInterfaceName check
        end --vapName    
    end --vapRows

    -- returns 
    return "OK", "STATUS_OK"

end
---------------------------------------------------------------------------------
--@name eogreAccessPointCheck
--
--@description this function checks EoGRE is enabled on AP or not.
--
--@return status, errCode
--
function eogreAccessPointCheck(inputTbl)

    --locals
    local accesspoint 
    local accesspoint5
    local vapNamequery
    local dot11vapRow
    local eogreRow

    local jioPrivateNetSupport = "0"
    jioPrivateNetSupport = db.getAttribute ("Eogre", "_ROWID_", 1, "jioPrivateNet")
    --jioPrivateNetSupport = db.getAttribute ("environment", "name", "JIO_PRIVATE_NET" ,"value")
    if (jioPrivateNetSupport == "1") then
        accesspoint = "ap3"
        accesspoint5 = "ap6"
    else
        accesspoint = "ap2"
        accesspoint5 = "ap5"
    end

    if(inputTbl["dot11VAP.vapName"] == accesspoint or inputTbl["dot11VAP.vapName"] == accesspoint5)then
      eogreRow = db.getRowWhere ("Eogre","_ROWID_=1", false)
      if (eogreRow == nil) then
          return "ERROR", "DB_ERROR_TRY_AGAIN"
      end

      if ((tonumber(eogreRow["Enable"]) == 1) and (tonumber(eogreRow["ModeOfOperation"])== 1 ))then
          vapNamequery = "vapName= '" .. inputTbl["dot11VAP.vapName"] .. "'"          
          dot11vapRow = db.getRowWhere ("dot11VAP",vapNamequery, false)
          if (dot11vapRow == nil) then
              return "ERROR", "DB_ERROR_TRY_AGAIN"
          end
          if ((inputTbl["dot11VAP.profileName"] ~= dot11vapRow["profileName"]) or (inputTbl["dot11VAP.eogreCall"]== nil and inputTbl["dot11VAP.apIsolation"] ~= dot11vapRow["apIsolation"]))then
              return "ERROR", "PLEASE_TURN_OFF_EoGRE"
          end
      end
    end

    return "OK","STATUS_OK"
    
end
---------------------------------------------------------------------------------
--@name apProfileCheck
--
--@description this function checks the profile info on VAP
--
--@return status, errCode
---------------------------------------------------------------------------------
function apProfileCheck (inputTbl, radioNo)

    -- check if this profile is being used already
    local rowid
    local profileNamequery
    local dot11VapEntryRow


    rowid = inputTbl["_ROWID_"]
    profileNamequery = " profileName='" .. inputTbl["dot11VAP.profileName"] .. "' and  _ROWID_!='" .. rowid .. "'"
    dot11VapEntryRow = db.getRowWhere("dot11VAP", profileNamequery, false)
    -- check if this profile is being used already
    if (dot11VapEntryRow) then
        return "ERROR", "Profile is already being used by another AP"
    end
    local vapRows = db.getRows ("dot11VAP", "radioList", radioNo)
    if (not(vapRows)) then
        return "ERROR", "DOT11_AP_CONFIG_FAILED"
    end

    return "OK", "STATUS_OK"
end
---------------------------------------------------------------------------------
--@name maxClientsRadioValidate
--
--@description this function checks the max clients per radio 
--
--@return status, errCode
---------------------------------------------------------------------------------
function maxClientsRadioValidate (inputTbl, radioNo)

    local vapRows
    local totalClients
    local maxClientsPerRadio
    local rowid = inputTbl["_ROWID_"]
    
    vapRows = db.getRows ("dot11VAP", "radioList", radioNo)
    if (#vapRows==0) then
        return "ERROR", "DOT11_AP_CONFIG_FAILED"
    end

	--max client per radio validation
    totalClients = 0
    if (tonumber(inputTbl["dot11VAP.maxClients"]) < 1) then
            return "ERROR", "MaxAssociatedDevices can't be set to 0"
    end 
    --calculation to get total clients on all the VAP's based on given input.
    for _, row in pairs (vapRows) do
        if (row["dot11VAP._ROWID_"] == rowid) then
            totalClients = totalClients + tonumber(inputTbl["dot11VAP.maxClients"])
        else
            totalClients = totalClients + tonumber(row["dot11VAP.maxClients"])
        end
    end
    -- DB query to get max clients per radio.
    maxClientsPerRadio = db.getAttribute ("environment", "name", "MAX_CLIENTS_PER_RADIO", "value")
	if (not (maxClientsPerRadio)) then
        return "ERROR", "DOT11_AP_CONFIG_FAILED"
    end
    if (maxClientsPerRadio and (totalClients > tonumber(maxClientsPerRadio))) then
        return "ERROR" , "Maximum of "..maxClientsPerRadio.." clients are supported for radio-"..radioNo
    end

    return "OK","STATUS_OK"
end
---------------------------------------------------------------------------------
--@name LengthCheck
--
--@description this function checks length
--
--@return status, errCode
---------------------------------------------------------------------------------
function LengthCheck (minLength, maxLength, fieldValue, fieldName)

    --locals
    minLength = tonumber(minLength)
    maxLength = tonumber(maxLength)

    if (fieldValue == nil) then
        return "ERROR", fieldName.."length should not be empty"
    end

    if ((string.len(fieldValue) >= minLength) and (string.len(fieldValue) <= maxLength)) then
        return "OK", "STATUS_OK"
    end

    return "ERROR", fieldName.." Length should be "..minLength.."-"..maxLength.." Charcters"
end
-------------------------------------------------------------------------------
-- @name ul_dot11.ProfileInfo.set
--
-- @description This function validates the user input.
-- 
--
-- @return status, errCode
-------------------------------------------------------------------------------
function ul_dot11.ProfileInfo.set (inputTable, operation)

    --locals
    local status = nil
    local errMsg = nil
    local defRow = {}
    local profileRow = {}
    local radio1Table = {}
    local radio2Table = {}
    local aptable = {}
    local ap1table = {}
    local security = {}
    local wpsRow= {}
    local rowidquery = "_ROWID_='"
    local rowid1query = "_ROWID_=1"
    local rowid2query = "_ROWID_=2"
    local vapName = "ap1"
    local vapInterface1
    local ssidMinLength = "1"
    local ssidMaxLength = "32"
    local minpskAscii   = "8"
    local maxpskAscii   = "63"

    -- SSID length check
    if (inputTable ["dot11Profile.ssid"] ~= nil and inputTable ["dot11Profile.ssid"] ~= "") then
        status, errMsg = LengthCheck (ssidMinLength, ssidMaxLength, inputTable ["dot11Profile.ssid"], "SSID")
        if (status=="ERROR")then
            return status, errMsg
        end
    end

    -- password length check
    if (inputTable ["dot11Profile.pskPassAscii"] ~= nil and inputTable ["dot11Profile.pskPassAscii"] ~= "") then
        status, errMsg = LengthCheck (minpskAscii, maxpskAscii, inputTable ["dot11Profile.pskPassAscii"], "Password")
        if (status=="ERROR") then
            return status, errMsg
        end
        --password Valid character check
     	local status, errMsg = util.validPasswordCheck(inputTable ["dot11Profile.pskPassAscii"])
     	if (status == "ERROR") then
            return status, errMsg
        end	
    end
	
    -- Duplicate SSID checking on Radio (wlx)
    status, errMsg = duplicateSSIDcheck (inputTable)
    if (status=="ERROR") then
        return status, errMsg
    end

    wpsRow = db.getRowWhere ("dot11WPS", rowid1query, false)
    if (wpsRow == nil) then
        --why return from here we can insert a row if there is not row in DB
        vapInterface1 = db.getAttribute ("dot11Interface", "vapName", vapName, "interfaceName")
        db.execute("INSERT into dot11WPS values("..vapInterface1..",'0')")
        wpsRow = db.getRowWhere ("dot11WPS", rowid1query, false)
    end

    radio1Table = db.getRowWhere ("dot11Radio", rowid1query, false)
    if (radio1Table == nil) then
        return "ERROR","DB_ERROR_TRY_AGAIN"
    end

    --TODO make this logic generic for dual radio devices instead cheecking with file names
    if((not(util.fileExists("/pfrm2.0/HW_JCO110"))) and (not(util.fileExists("/pfrm2.0/HW_HG260ES"))) and (not(util.fileExists("/pfrm2.0/HW_ALU"))) and (not(util.fileExists("/pfrm2.0/HW_JCO410"))) and (not(util.fileExists("/pfrm2.0/HW_JCE410"))))then
        radio2Table = db.getRowWhere ("dot11Radio", rowid2query, false)
        if (radio2Table == nil) then
            return "ERROR","DB_ERROR_TRY_AGAIN"
        end
    end

    if (operation == "edit") then
        --check for the security as TKIP/WEP of the 2.4 GHz active profile when
        --802.11n mode in active
        status, errMsg = securityCheck (inputTable, radio1Table, radio2Table)
        if (status=="ERROR")then
            return status, errMsg
        end
        rowid = inputTable["_ROWID_"]
    else
        -- Add case
        rowid = nil
        defRow = db.getDefaults(true, "dot11Profile")
    end

    local security = {}
    security =  securityGet(inputTable["dot11Profile.security"],inputTable["dot11Profile.pairwiseCiphers"],inputTable["dot11Profile.wepAuth"],inputTable["dot11Profile.groupCipher"])
    if (not(security)) then
        util.appendDebugOut("Configured security not supported!!")
        return "ERROR", "DOT11_SECURITY_NOTSUPP"
    end
     
    -- WPS checks
    if (wpsRow["wpsEnabled"] == "1" and operation == "edit") then
        status, errMsg = wpsCheck (inputTable)
        if (status=="ERROR")then
            return status, errMsg
        end
    end
    
    inputTable["dot11Profile.security"] = security[2]
    if ((inputTable["dot11Profile.security"] == "WEP" or inputTable["dot11Profile.security"] == "OPEN")) then
        inputTable["dot11Profile.authMethods"] = security[4]
    end
    inputTable["dot11Profile.groupCipher"] = security[6]
    inputTable["dot11Profile.pairwiseCiphers"] = security[3]
    inputTable["dot11Profile.wepAuth"] = security[5]

    -- save password into paskPassAscii only if security is wpa(2)
    if ((inputTable["dot11Profile.security"] =="WPA" ) or (inputTable["dot11Profile.security"] =="WPA2" ) or (inputTable["dot11Profile.security"] =="WPA+WPA2")) then
        if ((operation == "edit") and (inputTable ["dot11Profile.pskPassAscii"] ~= nil) and (util.isAllMasked (inputTable ["dot11Profile.pskPassAscii"]))) then
            rowidquery = rowidquery .. rowid .. "'"
            profileRow = db.getRowWhere("dot11Profile", rowidquery, false)
            if (profileRow ~= nil) then
                inputTable ["dot11Profile.pskPassAscii"] = profileRow["pskPassAscii"]
            end
        end
    else
        inputTable ["dot11Profile.pskPassAscii"] = ""
    end

    if (operation == "add") then
        defRow["dot11Profile.profileName"] = inputTable ["dot11Profile.profileName"]
        defRow["dot11Profile.ssid"] = inputTable ["dot11Profile.ssid"]
        defRow["dot11Profile.broadcastSSID"] = inputTable ["dot11Profile.broadcastSSID"]
        defRow["dot11Profile.security"] = inputTable ["dot11Profile.security"]
        defRow["dot11Profile.pairwiseCiphers"] = inputTable ["dot11Profile.pairwiseCiphers"]
        defRow["dot11Profile.authMethods"] = inputTable ["dot11Profile.authMethods"]
        defRow["dot11Profile.pskPassAscii"] = inputTable ["dot11Profile.pskPassAscii"]
        defRow["dot11Profile.wepAuth"] = inputTable ["dot11Profile.wepAuth"]
        defRow["dot11Profile.pskPassHex"] = inputTable ["dot11Profile.pskPassHex"]
        defRow["dot11Profile.groupCipher"] = inputTable ["dot11Profile.groupCipher"]
        defRow["dot11Profile.defWepkeyIdx"] = inputTable ["dot11Profile.defWepkeyIdx"]
        defRow["dot11Profile.wepkeyPassphrase"] = inputTable ["dot11Profile.wepkeyPassphrase"]
        defRow["dot11Profile.wepkey0"] = inputTable ["dot11Profile.wepkey0"]
        defRow["dot11Profile.wepkey1"] = inputTable ["dot11Profile.wepkey1"]
        defRow["dot11Profile.wepkey2"] = inputTable ["dot11Profile.wepkey2"]
        defRow["dot11Profile.wepkey3"] = inputTable ["dot11Profile.wepkey3"]
        inputTable = defRow
    end

    -- db configuration.
    errMsg, status = dot11.profile_config (inputTable, rowid, operation)

   return errMsg, status
end

-------------------------------------------------------------------------------
-- @name dot11_ul.apProfileInfo.status
--
-- @description This function will enable/disable AP on the system.
--
-- @return status, errCode
--
function ul_dot11.apProfileInfo.status (rows, operation)
    --include
    require "teamf1lualib/dot11"

    --locals
    local status = "DOT11_VAP_ENABLE/DISABLE_FAILED"
    local errMsg = "OK"
    local valid = false
    local vapInterfaceName = nil
    local vapName = nil

    -- WPS check, 
    --[[errMsg, status = vapWPScheck (rows)
    if (errMsg=="ERROR")then
        return errMsg, status
    end]]--

    if (errMsg == "OK") then
        for k,v in pairs(rows) do
            vapName = db.getAttribute("dot11VAP", "dot11VAP._ROWID_", v,"vapName")
            if(vapName ~= nil and vapName ~= '' and vapName ~= " ") then
                vapInterfaceName = db.getAttribute("dot11Interface", "vapName", vapName,"interfaceName")
                if(vapInterfaceName ~= nil and vapInterfaceName ~= '' and vapInterfaceName ~= " ") then 
                    valid = dot11.AP_config(v, vapInterfaceName, operation)
                end
            end
        end
    end

    if (valid) then
        return "OK", "STATUS_OK"
    else
        return errMsg, status
    end

end

----------------------------------------------------------------------------------
-- @name   dot11_ul.apProfileInfo.edit.set
--
-- @description This function will set the information for a particular
--
-- access point which is being edited
--
-- @return status, errCode
--
 function ul_dot11.apProfileInfo.edit.set (cfgTbl, operation)

    --require    
    require "teamf1lualib/wifiSecMap"
    require "teamf1lualib/dot11"

    local rowid = cfgTbl["_ROWID_"]
    local security = {}
    local rowIdQuery =" _ROWID_='" .. rowid .. "'"
    local radioNoQuery = "radioNo="
    local vapEnabled
    local vapInterfaceName
    local profileRow = {}
    local radioRow = {}
    local valid = true
    local radioInterfaceName
    local errorCode, statusMsg
    local interfaceBridgeName = nil
    local logicalInterfaceName = nil
    
    --get vap details from rowid
    local dot11VapEntry = db.getRowWhere("dot11VAP", rowIdQuery, false)
    if(not(dot11VapEntry)) then
        util.appendDebugOut("unable to get dot11VAP Row from rowid - " .. rowid)
        return "ERROR", "DOT11_AP_CONFIG_FAILED"
    end

    if(cfgTbl["dot11VAP.vapEnabled"] == nil)then
        cfgTbl["dot11VAP.vapEnabled"] = dot11VapEntry["vapEnabled"]
    end

    if(cfgTbl["dot11VAP.radioNo"] == nil)then
        cfgTbl["dot11VAP.radioNo"] = dot11VapEntry["radioNo"]
    end

    local radioNo = db.getAttribute ("dot11Interface", "vapName", dot11VapEntry["vapName"], "radioNo")
    local radioInterfaceName = db.getAttribute("dot11Radio", "radioNo", radioNo, "interfaceName")
    radioNoQuery = radioNoQuery .. radioNo
    radioRow = db.getRowWhere ("dot11Radio", radioNoQuery, false)
    if (radioRow == nil) then
        return "ERROR","DB_ERROR_TRY_AGAIN"
    end

    profileRow = db.getRow ("dot11Profile","profileName",cfgTbl["dot11VAP.profileName"])
    --check for the profile associated to AP when 802.11n mode is active
    if((profileRow["dot11Profile.pairwiseCiphers"] == "TKIP" or profileRow["dot11Profile.security"] == "WEP") and ((radioRow["band"] == "a" and (radioRow["opMode"] == "2" or radioRow["opMode"] == "3" or string.find(radioRow["opMode"], "na"))) or (radioRow["band"] == "b" and (radioRow["opMode"] == "4" or radioRow["opMode"] == "5" or string.find(radioRow["opMode"], "ng")))))then
            return "ERROR", "HT modes are not allowed for WEP or WPA only mode"
    end
    

    -- check if this profile is being used already
    errorCode, statusMsg = apProfileCheck (cfgTbl, radioNo)
    if (errorCode == "ERROR")then
        return errorCode, statusMsg
    end

    --max client per radio validation
    errorCode, statusMsg = maxClientsRadioValidate (cfgTbl, radioNo)
    if (errorCode == "ERROR")then
        return errorCode, statusMsg
    end

    if(dot11VapEntry["profileName"] == cfgTbl["dot11VAP.profileName"]) then
        errorCode, statusMsg = dot11.VAP_config(cfgTbl, rowid, "edit")
    end

    return errorCode, statusMsg

end

-------------------------------------------------------------------------------
--@name ul_dot11.wps.set
--
--@description this function will set the values for WIFI protection setup
--
--@return status, errCode
-------------------------------------------------------------------------------

function ul_dot11.wps.set(inputTable)

    --require
    require "teamf1lualib/dot11"

    --locals
    local row = {}
    local query = "_ROWID_=1"
    local rowid = "1"
    local security
    local valid = false
    local errorFlag = "ERROR"
    local statusCode = "WPS_CONFIG_FAILED"

    row = db.getRowWhere("dot11WPS", query, false)
    if (row == nil) then
         return "ERROR","DB_ERROR_TRY_AGAIN"
    end
    row["wpsEnabled"] = inputTable["enableDisableWPS"]

    if (inputTable["tf1_dot11WPS_vaps"] == nil or inputTable["tf1_dot11WPS_vaps"] == "None") then
        return "ERROR","NO_VAP_SELECTED_TO_ENABLE_WPS"
    end

    local interfaceName = db.getAttribute("dot11Interface", "vapName", inputTable["tf1_dot11WPS_vaps"], "interfaceName")
    row["interfaceName"] = interfaceName
    row["vapName"] = inputTable["tf1_dot11WPS_vaps"]
     
    --get security from profile table
    local profileName = db.getAttribute("dot11VAP", "vapName", inputTable["tf1_dot11WPS_vaps"], "profileName")
    if(profileName == nil or profileName == '' or profileName == " ") then
        security = db.getAttribute("dot11Profile", "_ROWID_",rowid, "security")
    else
        security = db.getAttribute("dot11Profile", "profileName",profileName, "security")
    end
    -- check if the profile is configured with wpa/wpa2 etc.... else Error
    if((inputTable["enableDisableWPS"] == "1") and (security ~= "WPA") and (security ~= "WPA2") and (security ~="WPA+WPA2")) then
        return "ERROR", "NO_WPA_VAP_ERROR"
    end

    row = util.addPrefix(row, "dot11WPS.")
    errorFlag,statusCode = dot11.WPS_config(row, "1", "edit")

    -- return
    return errorFlag,statusCode
end

-------------------------------------------------------------------------------
--@name ul_dot11.wpsPbcConfig
--
--@description this function does WPS PBC action
--
--@return status, errCode
-------------------------------------------------------------------------------
function ul_dot11.wpsPbcConfig (inputTable)

    require "teamf1lualib/dot11"

    --locals
    local errorCode,statusMsg

    local interfaceName = db.getAttribute("dot11WPS", "_ROWID_", 1, "interfaceName")
    local vapName = db.getAttribute("dot11Interface", "interfaceName", interfaceName, "vapName")
    local vapEnabled = db.getAttribute("dot11VAP", "vapName", vapName, "vapEnabled")

    -- AP is Configured with WPS or not ?
    if (inputTable["tf1_dot11WPS_vaps"] ~= vapName) then
        return "ERROR", "WPS is not Enabled on AP"
    end

    -- If WPS Configured AP is disabled.
    if(vapEnabled == "0")then
        return "ERROR", "Selected AP is disabled"
    end

    errorCode,statusMsg = dot11.WpsConfigPbc()

    return errorCode, statusMsg

end

-------------------------------------------------------------------------------
--@name ul_dot11.wpsPinConfig
--
--@description  this function does WPS PIN action
--
--@return status, errCode
-------------------------------------------------------------------------------
function ul_dot11.wpsPinConfig (inputTable)

    -- requires
    require "teamf1lualib/dot11"
    require "teamf1lualib/wps"

    --locals
    local errorCode = "OK"
    local statusMsg = "STATUS_OK"
    local interfaceName = db.getAttribute("dot11WPS", "_ROWID_", 1, "interfaceName")
    local vapName = db.getAttribute("dot11Interface", "interfaceName", interfaceName, "vapName")
    local vapEnabled = db.getAttribute("dot11VAP", "vapName", vapName, "vapEnabled")

    -- AP is Configured with WPS or not 
    if (inputTable["tf1_dot11WPS_vaps"] ~= vapName) then
        return "ERROR", "WPS is not Enabled on AP"
    end

    -- If WPS Configured AP is disabled.
    if(vapEnabled == "0")then
        return "ERROR", "Selected AP is disabled"
    end

    --validating WPS pin
    errorCode,statusMsg = wps.validatePin(inputTable["tf1_txtPINNum"])

    if (errorCode == "OK") then
        errorCode,statusMsg = dot11.WpsConfigPin(inputTable["tf1_txtPINNum"])
        if(errorCode == "OK") then
            return "OK","STATUS_OK"
        else
            return "ERROR",statusMsg
        end
    end
    --return
    return errorCode,statusMsg
end

-------------------------------------------------------------------------------
--@name ul_dot11.ieee1905.set
--
--@description this function will set the values for ieee1905 setup
--
--@return status, errCode
-------------------------------------------------------------------------------

function ul_dot11.ieee1905.set(inputTable)

    --require
    require "teamf1lualib/ieee1905"

    --locals
    local row = {}
    local wpsTable = {}
    local query = "_ROWID_=1"
    local rowid = "1"
    local security
    local valid = false
    local errorFlag = "ERROR"
    local statusCode = "WPS_CONFIG_FAILED"

    row = db.getRowWhere("ieee1905", query, false)
    if (row == nil) then
         return "ERROR","DB_ERROR_TRY_AGAIN"
    end
    row["ieee1905Enabled"] = inputTable["ieee1905Enabled"]

    wpsTable = db.getRowWhere("dot11WPS", query, false)
    if (row == nil) then
         return "ERROR","DB_ERROR_TRY_AGAIN"
    end
    if(inputTable["vapName"] == nil)then
        row["registrarName"] = wpsTable["vapName"]
    else
        row["registrarName"] = inputTable["vapName"]
    end

    row = util.addPrefix(row, "ieee1905.")
    errorFlag,statusCode = ieee1905.ieee1905_config(row, "1", "edit")

    -- return
    return errorFlag,statusCode

end

-------------------------------------------------------------------------------
--@name ul_dot11.wpsPbcConfig
--
--@description this function does WPS PBC action
--
--@return status, errCode
-------------------------------------------------------------------------------
function ul_dot11.ieee1905PbcConfig (inputTable)

    require "teamf1lualib/dot11"

    --locals
    local errorCode,statusMsg

    local interfaceName = db.getAttribute("dot11WPS", "_ROWID_", 1, "vapName")
    local vapName = db.getAttribute("dot11Interface", "interfaceName", interfaceName, "vapName")
    local vapEnabled = db.getAttribute("dot11VAP", "vapName", vapName, "vapEnabled")

    -- AP is Configured with WPS or not ?
    if (inputTable["vap"] ~= interfaceName) then
        return "ERROR", "WPS is not Enabled on AP"
    end

    -- If WPS Configured AP is disabled.
    if(vapEnabled == "0")then
        return "ERROR", "Selected AP is disabled"
    end

    errorCode,statusMsg = dot11.ieee1905ConfigPbc()

    return errorCode, statusMsg

end

-------------------------------------------------------------------------------
--@name ul_dot11.radio.set
--
--@description this function eill set the values for radio
--
--@return status, errorCode
-------------------------------------------------------------------------------

function ul_dot11.radio.set(dot11Table)

    --require
    require "teamf1lualib/dot11"

    --locals
    local radioRow = {}
    local errorCode = "OK",statusMsg
    local bandquery = "band='"..dot11Table["band"].."'"
    local radioNoquery = "radioNo='"
    local interfaceRows = {}

    radioRow = db.getRowWhere ("dot11Radio", bandquery, false)
    if(radioRow == nil) then
        return "ERROR", "No radio table for band "..dot11Table["band"]
    end
    radioNoquery = radioNoquery..radioRow["radioNo"].."'"

    interfaceRows = db.getRowsWhere ("dot11Interface", radioNoquery, false)

    if( dot11Table["band"] ~= nil and dot11Table["opMode"] ~= nil) then
        os.execute ("echo SET band: " .. dot11Table["band"] .. " Operation Mode: " .. dot11Table["opMode"] .. " > /dev/console")
        dot11Table["opMode"]  = convertModes_econet(dot11Table["band"],dot11Table["opMode"],"1") --pass 1 for set
    end

    errorCode, statusMsg = radioSecurityCheck (dot11Table, interfaceRows)
    if (errorCode == "ERROR") then
        return errorCode, statusMsg
    end

    radioRow["currentChannel"] = dot11Table["currentChannel"]
    radioRow["opMode"] = dot11Table["opMode"]
    radioRow["chanWidth"] = dot11Table["chanWidth"]
    radioRow["configuredChannel"] = dot11Table["configuredChannel"]
    radioRow["txRate"] = dot11Table["txRate"]
    radioRow["txPower"] = dot11Table["txPower"]
    radioRow["radioCountryRev"] = dot11Table["radioCountryRev"] or radioRow["radioCountryRev"]

    -- control side band is opposite of subchannel band
    if dot11Table["contSideBand"] == "Upper" then
        radioRow["sideBand"] = "0"
    elseif dot11Table["contSideBand"] == "Lower" then
        radioRow["sideBand"] = "1"
    end
		
        os.execute ("echo SET band: " .. dot11Table["band"] .. " Operation Mode: " .. radioRow["opMode"] .. " > /dev/console")
    -- apply radio settings only if vap set has succeeded above
    radioRow = util.addPrefix(radioRow, "dot11Radio.")
    errorCode,statusMsg = dot11.radio_config(radioRow, radioRow["dot11Radio._ROWID_"] , "edit")

    return errorCode,statusMsg
end

-------------------------------------------------------------------------------
--@name ul_dot11.radio.advancedSet
--
--@description this function eill set the values for radio
--
--@return status, errorCode
-------------------------------------------------------------------------------
function ul_dot11.radio.advancedSet (dot11Table)

    --require
    require "teamf1lualib/dot11"

    --locals
    local errorCode = "OK",statusMsg
    local bandquery = "band='"..dot11Table["band"].."'"
    local radioRow = {}
    
    radioRow = db.getRowWhere ("dot11Radio", bandquery, false)
    radioRow["puren"] = "0"

    if (radioRow == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    radioRow["beaconInterval"] = dot11Table["beaconInterval"] or radioRow["beaconInterval"]
    radioRow["dtimInterval"] = dot11Table["dtimInterval"] or radioRow["dtimInterval"]
    radioRow["rtsThreshold"] = dot11Table["rtsThreshold"] or radioRow["rtsThreshold"]
    radioRow["fragThreshold"] = dot11Table["fragThreshold"] or radioRow["fragThreshold"]
    radioRow["preambleMode"] = dot11Table["preambleMode"] or radioRow["preambleMode"]
    radioRow["rtsCtsProtect"] = dot11Table["rtsCtsProtect"] or radioRow["rtsCtsProtect"]
    radioRow["radioCountryRev"] = dot11Table["radioCountryRev"] or radioRow["radioCountryRev"]
    radioRow = util.addPrefix(radioRow, "dot11Radio.")
    errorCode,statusMsg = dot11.radio_config(radioRow, radioRow["dot11Radio._ROWID_"] , "edit")

    -- return
    return errorCode,statusMsg
end

-------------------------------------------------------------------------------
--@name ul_dot11.acl.set - get the acl policy
--
--@description This function set the acl policy
--
--@return status, errorCode
--

function ul_dot11.acl.set(policy)

    --require
    require "teamf1lualib/dot11"

    --locals
    local dot11VAP = {}
    local rowIdQuery =  "_ROWID_="..policy["dot11VAP._ROWID_"] -- using ACL configuration only for admin
    local status = nil
    local valid = false
    local radioInterfaceName = nil
    local vapInterfaceName

    dot11VAP = db.getRowWhere("dot11VAP", rowIdQuery, true)
    if(dot11VAP == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    vapInterfaceName = db.getAttribute("dot11Interface","vapName",dot11VAP["dot11VAP.vapName"],"interfaceName")
    if(vapInterfaceName == nil) then
        return "ERROR", "No Interface For "..dot11VAP["dot11VAP.vapName"]
    end

    if (dot11VAP["dot11VAP.defACLPolicy"] == policy["dot11VAP.defACLPolicy"]) then
        return"OK", "STATUS_OK" 
    end

    -- config dot11VAP (default acl policy)
    local vapName = dot11VAP["dot11VAP.vapName"]
    valid = db.setAttribute("dot11VAP", "vapName", vapName, "defACLPolicy", policy["dot11VAP.defACLPolicy"])
     if (valid) then
         -- Setting configurations into nvram & driver.
         dot11VAP["dot11VAP.defACLPolicy"] = policy["dot11VAP.defACLPolicy"]
         valid = dot11.vap_acl_config_apply (dot11VAP, policy)
         if (valid) then
             return "OK","STATUS_OK"
         else
             return "ERROR", "ERROR_CONFIGURING_ACL_POLICY"
         end
     else
         return "ERROR", "ERROR_CONFIGURING_ACL_POLICY"
     end

end

-------------------------------------------------------------------------------
--@name dot11_ul.acl.add.set
--
--@description This function will allow user to add mac addresses for access
--
--control rule
--
--@return status, errorCode
--
function ul_dot11.acl.add.set(inputTable)

    --require
    require "teamf1lualib/dot11"
    require "ifDevLib"

    --locals
    local acl = {}
    local dot11VAP = {}
    local dot11ACL = {}
    local vapRowQuery = "_ROWID_="..inputTable["dot11ACL.vaprowId"]
    local valid = false 
    local radioInterfaceName = nil

    if (inputTable["macAddress"] ~= nil) then
        if (ifDevLib.isMulticastEtherAddr(inputTable["macAddress"]) or
            ifDevLib.isBroadcastEtherAddr(inputTable["macAddress"])) then
            return "ERROR","INVALID_ACL_MAC"
        end
    end

    dot11VAP = db.getRowWhere("dot11VAP", vapRowQuery, true)
    if(dot11VAP == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    --Before doing DB operation we need to have total number of rows
    --in dot11ACL table
    local vapNameQuery = "vapName='"..dot11VAP["dot11VAP.vapName"].."'"
    dot11ACL = db.getRowsWhere("dot11ACL", vapNameQuery, true)
    if(dot11ACL == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    acl["dot11ACL.macAddress"] = inputTable["dot11ACL.macAddress"]
    acl["dot11ACL.vapName"] = dot11VAP["dot11VAP.vapName"]

    -- add a ACL rule in db
    valid = dot11.ACL_config(acl, -1, "add")

    if(valid)then
        -- Saving config into driver.
        dot11.acl_mac_config_apply (dot11VAP, #dot11ACL)
        return "OK","STATUS_OK"
    else
        return "ERROR","ERROR_ADDING_RULE"
    end

end

-------------------------------------------------------------------------------
--@name ul_dot11.acl.delete
--
--@description This function will deletes an ACL rule
--
--@return status, errorCode
-------------------------------------------------------------------------------
function ul_dot11.acl.delete (rowmacs)

    --require
    require "teamf1lualib/dot11"

    --locals
    local valid = false
    local radioInterfaceName = nil
    local dot11VAP = {}
    local vapNameQuery
    local vapName

    for k,v in pairs (rowmacs) do
        vaprow = db.getRow ("dot11ACL", "_ROWID_", v)
        local vapName = vaprow["dot11ACL.vapName"]
        if(vapName == nil) then
            return "ERROR", "DB_ERROR_TRY_AGAIN"
        end

        local vapNameQuery="vapName='"..vapName.."'"
        dot11VAP = db.getRowWhere("dot11VAP", vapNameQuery, true)
        if(dot11VAP == nil) then
            return "ERROR", "DB_ERROR_TRY_AGAIN"
        end
    
        --Before doing DB operation we need to have total number of rows
        --in dot11ACL table
        local dot11ACL = db.getRowsWhere("dot11ACL", vapNameQuery, true)
        if(dot11ACL == nil) then
            return "ERROR", "DB_ERROR_TRY_AGAIN"
        end

        valid = db.deleteRow ("dot11ACL", "_ROWID_", v)
        if(valid)then
            -- deletes the rules in driver
            dot11.acl_mac_config_apply (dot11VAP, #dot11ACL)
        else
            return "ERROR","CANNOT_DELETE_TRY_AGAIN"
        end --end for rowmacs
    end

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name ul_dot11.wmm.set
--
-- @description This function will give configure the given wmm profile in the 
-- system.
--
-- @return status,errorCode
------------------------------------------------------------------------------
function ul_dot11.wmm.set (inputTable, operation)
    
    --include
    require "teamf1lualib/dot11_ul"

    --locals
    local status = "ERROR"
    local errMsg = "ERROR"

    local rowid = db.getAttribute ("dot11Profile", "profileName", inputTable["dot11Profile.profileName"], "_ROWID_")
    errMsg, status = dot11.profile_config (inputTable, rowid, operation)
    return errorMsg, status
end
