-- @copyright Copyright (c) 2013, TeamF1, Inc. 

require "teamf1lualib/l2tp"

--[[
*******************************************************************************
-- @name nimfConn.ipv4L2TPCfgInit
--
-- @description The function initialises the L2TP configuration.
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv4L2TPCfgInit(cur, conf)
    local cfg = {}

    if (cur ==  nil) then
        cfg["LogicalIfName"] = conf["LogicalIfName"]
    else
        cfg = cur        
    end                

    cfg["UserName"] = conf["UserName"]
    cfg["Password"] = conf["Password"]
    cfg["IspName"]  = conf["IspName"]
    cfg["GetIpFromIsp"] = conf["GetIpFromIsp"]
    cfg["GetDnsFromIsp"] = conf["GetDnsFromIsp"]
    cfg["PrimaryDns"] = conf["PrimaryDns"]
    cfg["SecondaryDns"] = conf["SecondaryDns"]
    cfg["Mtu"] = conf["Mtu"]
    cfg["IdleTimeOutFlag"] = conf["IdleDisconnect"]
    cfg["IdleTimeOutValue"] = "0"
    if (conf["IdleDisconnectTime"] ~= nil and 
        tonumber(conf["IdleDisconnectTime"]) > 0) then
        cfg["IdleTimeOutValue"] = conf["IdleDisconnectTime"]
    end
    
    -- L2TP Transport
    cfg["MyIp"] = conf["MyIPAddress"]
    cfg["StaticIp"] = conf["StaticIp"]
    cfg["NetMask"] = conf["NetMask"]
    cfg["Gateway"] = conf["Gateway"]
    cfg["ServerIp"] = conf["ServerIp"]

    -- L2TP Options
    cfg["Secret"] = conf["Secret"] or ""
    cfg["SplitTunnel"] = conf["SplitTunnel"] or "0"
    cfg["DualAccess"] = conf["DualAccess"] or "0"

    return cfg
end

--[[
*******************************************************************************
-- @name nimfConn.ipv4L2TPConfigure
--
-- @description This function conigures the L2TP Connection
--
-- @param conf configuration table with the following fields
-- <ul>
-- <li><i> LogicalIfName</i>        Logical name of the network.
-- <li><i> AddressFamily</i>        network protocol of the connection
-- <li><i> Enable</i>               enable/disable connection
-- <li><i> StaticIp</i>             Static IP Address
-- <li><i> NetMask</i>              Subnetmask of the above IP address.
-- <li><i> Gateway</i>              Gateway IP Address
-- <li><i> PrimaryDns</i>           Primary DNS server IP address of this network
-- <li><i> SecondaryDns</i>         Secondary DNS server IP address of this network
-- <li><i> IdleDisconnectTime</i>   Idle Timeout in case of PPP connections   
-- <li><i> Username</i>             username for PPP authentication
-- <li><i> Password</i>             password for PPP authentication
-- <li><i> GetIpFromIsp</i>         1 if this network gets IP parameters from ISP
-- <li><i> GetDnsFromIsp</i>        1 if this network gets DNS from ISP
-- <li><i> IspName</i>              ISP Name
-- <li><i> MyIPAddress</i>          L2TP Transport IP
-- <li><i> ServerIP</i>             L2TP Server IP Address
-- <li><i> Secret</i>               Secret
-- </ul>
--
-- @return  OK or ERROR
-- @errCode error string.
--]]

function nimfConn.ipv4L2TPConfigure(conf)
    local query = nil
    local record = {}
    local cfg = {}
    local errstr = ""
    local valid
    local rowid
    local status = "ERROR"
    local errCode  ="NET_ERR_L2TP_CONF"

    query = "LogicalIfName='" .. conf["LogicalIfName"].."'"

    nimf.dprintf ("Configuring L2TP connection for " ..  conf["LogicalIfName"])
    record = db.getRowWhere("L2tp", query, false)
    if (record == nil) then
        -- initialize configuration
        cfg = nimfConn.ipv4L2TPCfgInit(record, conf)
    if (cfg["Password"] ~= nil) then
        if (util.isAllMasked (cfg["Password"])) then
            cfg["Password"] = db.getAttribute ("L2tp","_ROWID_",cfg["_ROWID_"],"Password")
        end
    end

        -- Configure L2TP transport
        status, errCode =  nimfConn.ipv4L2TPTransportConfigure (cfg)
        if (status ~= "OK") then
            return status, errCode
        end

        -- add configuration
        cfg = util.addPrefix(cfg, "L2tp.")

        nimf.dprintf ("Adding L2TP connection " ..  util.tableToStringRec(cfg))
        valid, errstr, rowid = l2tp.config (cfg, nil, "add")
    else
        -- initialize configuration
        cfg = nimfConn.ipv4L2TPCfgInit(record, conf)
        if (cfg["Password"] ~= nil) then
            if (util.isAllMasked (cfg["Password"])) then
                cfg["Password"] = db.getAttribute ("L2tp","_ROWID_",cfg["_ROWID_"],"Password")
            end
        end

        local changed = nimf.hasTableChanged("L2tp", cfg, cfg["_ROWID_"])
        if (not changed) then
            return "OK","STATUS_OK", false
        end            

        -- Configure L2TP transport
        status, errCode =  nimfConn.ipv4L2TPTransportConfigure (cfg)
        if (status ~= "OK") then
            return status, errCode
        end
                        
        --
        -- Set this to true to indicate configuration has changed
        --
        rowid = true

        -- update configuration
        cfg = util.addPrefix(cfg, "L2tp.")
        valid, errstr = l2tp.config (cfg, cfg["L2tp._ROWID_"], "edit")
    end                

    if (not valid) then
        nimf.dprintf("ipv4L2TPConfigure: " ..
                     "IPv4 L2TP Connection configuration failed")
        return "ERROR", errstr
    end
            
    return "OK", "STATUS_OK", rowid
end

--[[
*******************************************************************************
-- @name  nimfConn.ipv4L2TPDeconfigure
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv4L2TPDeconfigure(conf)
    local query = nil
    local errstr = ""
    local valid
    local status = "ERROR"
    local errCode = "NET_ERR_L2TP_DECONF"

    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "'"

    nimf.dprintf ("Deleting IPv4 L2TP connection for " ..  conf["LogicalIfName"])
    valid, errstr = db.deleteRowWhere("L2tp", query)
    if (not valid) then
        nimf.dprintf("ipv4L2TPDeconfigure: failed to deconfigure L2TP on " .. 
                     conf["LogicalIfName"] .. " Err: " .. errstr or "Uknown")
        return status, errCode
    end
            
    nimf.dprintf ("Deleting IPv4 L2TP transport for " ..  conf["LogicalIfName"])
    status, errCode = nimfConn.ipv4L2TPTransportDeconfigure(conf)
    if (status ~= "OK") then
        nimf.dprintf("ipv4L2TPDeconfigure:failed to deconfigure L2TP transport on " .. 
                     conf["LogicalIfName"])
        return status, errCode
    end
                        
    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- nimfConn.ipv4L2TPConfValidate
--
-- @description This function validates parameters for IPv4 L2TP configuration
--
-- @param conf configuration table with the following fields
-- <ul>
-- <li><i> LogicalIfName</i>        Logical name of the network.
-- <li><i> AddressFamily</i>        network protocol of the connection
-- <li><i> Enable</i>               enable/disable connection
-- <li><i> StaticIp</i>             Static IP Address
-- <li><i> NetMask</i>              Subnetmask of the above IP address.
-- <li><i> Gateway</i>              Gateway IP Address
-- <li><i> PrimaryDns</i>           Primary DNS server IP address of this network
-- <li><i> SecondaryDns</i>         Secondary DNS server IP address of this network
-- <li><i> IdleDisconnectTime</i>   Idle Timeout in case of PPP connections   
-- <li><i> Username</i>             username for PPP authentication
-- <li><i> Password</i>             password for PPP authentication
-- <li><i> GetIpFromIsp</i>         1 if this network gets IP parameters from ISP
-- <li><i> GetDnsFromIsp</i>        1 if this network gets DNS from ISP
-- <li><i> IspName</i>              ISP Name
-- <li><i> MyIPAddress</i>          L2TP Transport IP
-- <li><i> ServerIP</i>             L2TP Server IP Address
-- <li><i> Secret</i>               Secret
-- </ul>
--
-- @return  OK or ERROR
-- @errCode error string.
--]]

function nimfConn.ipv4L2TPConfValidate(conf)
    local ipAddr=nil

    if ((conf["UserName"] == nil) or (conf["Password"] == nil))  then
        nimf.dprintf("ipv4L2TPConfValidate: Invalid conn credentials")
        return "ERROR", "NIMF_ERR_INVALID_PPP_CRED"
    end        

    -- check if StaticIp is valid
    ipAddr = conf["StaticIp"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv4AddrCheck(ipAddr) == nil)) then
        nimf.dprintf("ipv4L2TPConfValidate: Invalid preferred IP address")
        return "ERROR", "NIMF_ERR_INVALID_STATIC_IP"
    end        

    -- check if primary DNS is valid
    ipAddr = conf["PrimaryDns"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv4AddrCheck(ipAddr) == nil)) then
        nimf.dprintf("ipv4L2TPConfValidate: Invalid primary DNS")
        return "ERROR", "NIMF_ERR_INVALID_PRIMARY_DNS"
    end        

    -- check if secondary DNS is valid
    ipAddr = conf["SecondaryDns"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv4AddrCheck(ipAddr) == nil)) then
        nimf.dprintf("ipv4L2TPConfValidate: Invalid secondary DNS")
        return "ERROR", "NIMF_ERR_INVALID_SECONDARY_DNS"
    end        

    -- check if L2TP Transport IP is valid
    ipAddr = conf["MyIPAddress"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv4AddrCheck(ipAddr) == nil)) then
        nimf.dprintf("ipv4L2TPConfValidate: Invalid L2TP transport IP")
        return "ERROR", "NIMF_ERR_INVALID_MYIP"
    end        

    -- 
    -- Check if L2TP Server Ip is ok
    -- TODO: nimf need to support getaddinfo style
    -- address checking to check for domain names
    --

    -- check if L2TP Server Gateway IP is valid
    ipAddr = conf["Gateway"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv4AddrCheck(ipAddr) == nil)) then
        nimf.dprintf("ipv4L2TPConfValidate: Invalid L2TP transport gateway")
        return "ERROR", "NIMF_ERR_INVALID_SERVERIP"
    end        

    -- check idle timeout
    local idleTimeout = conf["IdleDisconnectTime"]
    if ((idleTimeout ~= nil) and (tonumber(idleTimeout) < 0)) then
        nimf.dprintf("ipv4L2TPConfValidate: Invalid idle disconnect time")
        return "ERROR", "NIMF_ERR_INVALID_IDLE_TIMEOUT"
    end        

    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- @name nimfConn.l2tpConfGet
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.l2tpConfGet(conf)
    local query = nil
    local record = {}
    local cfg = {}

    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "'"
    record = db.getRowWhere("L2tp", query, false)
    if (record ~= nil) then
        cfg["LogicalIfName"] = record["LogicalIfName"]
        cfg["AddressFamily"] = "2"
        cfg["IspName"] = record["IspName"]
        cfg["UserName"] = record["UserName"]
		cfg["Password"] = util.mask (record["Password"])
        cfg["IdleDisconnect"] = record["IdleTimeOutFlag"]
        cfg["IdleDisconnectTime"] = record["IdleTimeOutValue"]

        -- IP negotiation
        cfg["GetIpFromIsp"] = record["GetIpFromIsp"]
        cfg["StaticIp"] = record["StaticIp"]
        cfg["NetMask"] = record["NetMask"]
        cfg["GetDnsFromIsp"] = record["GetDnsFromIsp"]
        cfg["PrimaryDns"] = record["PrimaryDns"]
        cfg["SecondaryDns"] = record["SecondaryDns"]

        -- L2TP Transport
        cfg["MyIPAddress"] = record["MyIp"]
        cfg["Gateway"] = record["Gateway"]
        cfg["ServerIp"] = record["ServerIp"]

        -- L2TP Options
        cfg["Secret"] = record["Secret"]
        cfg["SplitTunnel"] = record["SplitTunnel"]
        cfg["DualAccess"] = record["DualAccess"]
        cfg["Mtu"] = record["Mtu"]
    end        

    return "OK", "STATUS_OK", cfg
end

--[[
*******************************************************************************
-- @name nimfConn.ipv4L2TPConfGet
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv4L2TPConfGet(conf)
    return nimfConn.l2tpConfGet(conf)
end

--[[
*******************************************************************************
-- @name nimfConn.ipv4L2TPTransportConfigure
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv4L2TPTransportConfigure (conf)
    local status = "ERROR"
    local errCode = "NET_ERR_L2TP_TRANSPORT_CONF"
    local conn = {}

    conn["LogicalIfName"] = conf["LogicalIfName"]
    conn["AddressFamily"] = "2"
    conn["ConnectionKey"] = "1"
    conn["StaticIp"] = conf["MyIp"]
    if ((conf["NetMask"] ~= nil) and (string.len(conf["NetMask"]) > 0)) then
        conn["NetMask"] = conf["NetMask"] 
    else
        conn["NetMask"] = "255.255.255.0"
    end                

    conn["Gateway"] = conf["Gateway"] or ""
    conn["DefaultConnection"] = "0"
    conn["ConfigureRoute"] = "0"
    conn["ConfigureDNS"] = "0"
    conn["Enable"] = "1"
    conn["PrimaryDns"] = ""
    conn["SecondaryDns"] = ""

    if ((conf["MyIp"] ~= nil) and 
        (string.len(conf["MyIp"]) > 0)) then
        conn["ConnectionType"] = "ifStatic"
    else
        conn["ConnectionType"] = "dhcpc"
    end                

    -- update configuration
    nimf.dprintf("Configuring L2TP Transport: " .. util.tableToStringRec(conn))
    status, errCode = nimfConn.configure(conn)
    if (status ~= "OK") then
        nimf.dprintf("nimfConn.ipv4L2TPTransportConfigure: failed to create " .. 
                     "transport connection ")
        return status, errCode
    end        

    return "OK","STATUS_OK"
end

--[[
*******************************************************************************
-- @name nimfConn.ipv4L2TPTransportDeconfigure
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv4L2TPTransportDeconfigure (conf)
    local connID = {}
    local status = "ERROR"
    local errCode = "NET_ERR_L2TP_TRANSPORT_DECONF"

    connID["LogicalIfName"] = conf["LogicalIfName"]
    connID["AddressFamily"] = conf["AddressFamily"] or "2"
    connID["ConnectionKey"] = "1"

    status, errCode = nimfConn.deconfigure(connID)
    if (status ~= "OK") then
        nimf.dprintf("nimfConn.ipv4L2TPTransportDeconfigure: failed to deconfigure " ..
                     "L2TP transport")
        return status, errCode        
    end
            
    return "OK", "STATUS_OK"            
end

--[[
*******************************************************************************
-- @name nimfConn.ipv4L2TPTransportEnable 
--
-- @description This function Enable l2tp transport connection.
--
-- @param connID    Connection ID
-- @field LogicalIfName NET ID
-- @field AddressFamily Protocol 
-- @field ConnectionKey unique connection number
--
-- @return  status, errCode
--
--]]

function nimfConn.ipv4L2TPTransportEnable (conf)
    local valid
    local errstr=""
    local status = "ERROR"
    local errCode = "NET_ERR_L2TP_TRANSPORT_ENABLE"
    local conn = {}

    conn["LogicalIfName"] = conf["LogicalIfName"]
    conn["AddressFamily"] = "2"
    conn["ConnectionKey"] = "1"
    
    query = "LogicalIfName='" .. conn["LogicalIfName"].."' and AddressFamily='" .. conn["AddressFamily"]
            .."' and ConnectionKey='" .. conn["ConnectionKey"].."'"

    record = db.getRowWhere("nimfConf", query, false)
    if (record == nil) then
        nimf.dprintf ("L2TP transport Enable failed")
        return "ERROR", "L2TP_TRANSPORT_CONF_ERR"
    end

    -- set connection as enable
    record["Enable"] = "1"
    
    -- update the configuration
    record = util.addPrefix(record, "NimfConf.")
    if (record == nil) then
        return "ERROR", nimf.err.NIMF_ERR_INVALID_ARG   
    end        

    -- commit 
    valid, errstr = nimf.config(record, record["NimfConf._ROWID_"], "edit")
    if (not valid) then
        if (errstr) then 
            nimf.dprintf("nimfConn..ipv4L2TPTransportEnable: update failed. reason:" .. errstr) 
        end
        nimf.dprintf("nimfConn..ipv4L2TPTransportEnable: failed to update connection configuration")
        return "ERROR", nimf.err.NIMF_ERR_DB_UPDATE
    end
    
    return "OK","STATUS_OK"
end

--[[
*******************************************************************************
-- @name nimfConn.ipv4L2TPTransportDisable 
--
-- @description This function Disable l2tp transport connection.
--
-- @param connID    Connection ID
-- @field LogicalIfName NET ID
-- @field AddressFamily Protocol 
-- @field ConnectionKey unique connection number
--
-- @return  status, errCode
--
--]]

function nimfConn.ipv4L2TPTransportDisable (conf)
    local valid
    local errstr=""
    local status = "ERROR"
    local errCode = "NET_ERR_L2TP_TRANSPORT_DISABLE"
    local conn = {}

    conn["LogicalIfName"] = conf["LogicalIfName"]
    conn["AddressFamily"] = "2"
    conn["ConnectionKey"] = "1"
    
    query = "LogicalIfName='" .. conn["LogicalIfName"].."' and AddressFamily='" .. conn["AddressFamily"]
            .."' and ConnectionKey='" .. conn["ConnectionKey"].."'"

    record = db.getRowWhere("nimfConf", query, false)
    if (record == nil) then
        nimf.dprintf ("L2TP transport disable failed")
        return "ERROR", "L2TP_TRANSPORT_CONF_ERR"
    end
    -- set connection as disable
    record["Enable"] = "0"
    
    -- update the configuration
    record = util.addPrefix(record, "NimfConf.")
    if (record == nil) then
        return "ERROR", nimf.err.NIMF_ERR_INVALID_ARG   
    end        

    -- commit 
    valid, errstr = nimf.config(record, record["NimfConf._ROWID_"], "edit")
    if (not valid) then
        if (errstr) then 
            nimf.dprintf("nimfConn..ipv4L2TPTransportDisable: update failed. reason:" .. errstr) 
        end
        nimf.dprintf("nimfConn..ipv4L2TPTransportDisable: failed to update connection configuration")
        return "ERROR", nimf.err.NIMF_ERR_DB_UPDATE
    end
    
    return "OK","STATUS_OK"
end
