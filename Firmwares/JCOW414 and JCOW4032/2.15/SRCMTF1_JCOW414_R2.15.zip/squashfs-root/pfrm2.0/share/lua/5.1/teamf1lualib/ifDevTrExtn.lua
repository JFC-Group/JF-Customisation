--[[
#### Copyright (c) 2015, TeamF1 Networks Pvt. Ltd. 
#### (Subsidiary of D-Link India)
#### 
#### File: ifDevTrExtn.lua
#### Description: 
#### TR-181 handlers for ifDev. This file is included from tr69funcs.lua.
####
#### Revisions:
01c,27Aug15,swr  Fix for SPR 53057
01b,07mar15,swr  Added changes in nwStatsGet for LowerLayers
01a,06mar15,swr  Changes for SPR 49978
]]--

ifDevTr = {}

--[[
--*****************************************************************************
-- ifDevTr.nwStatsGet - get network statistics 
-- 
-- This function is called to get the following parameters in,
-- Device.Ethernet.Interface.0.Stats.
-- Device.IP.Interface.0.Stats.
--
-- BytesSent
-- BytesReceived
-- PacketsSent
-- PacketsReceived
--
-- Returns: status, value
]]--
function ifDevTr.nwStatsGet(input)
    local status = "0"
    local value = ""
    local row = {}
    local rowId
    local query = nil
    local param = input["param"]
    local parentObjInstance = ""
    local logicalIfName
    local netStatsTbl = {}
    local IPTABLE_CMD = "/pfrm2.0/bin/iptables -w -t mangle -L "

    --load instanceMap
    local instanceMap =  tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", value
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "Interface.")
    parentObjInstance = string.sub(param, 1, endIdx+2)

    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", value
    end

    --get corresponding db entry from bridgeTable 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("bridgeTable", query, false)
    
    if(row == "nil") then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --if wan ip interface, then check connection type
    local nwRow = {} 
    local nimfRow = {}
    if(string.find(param, "Ethernet.Interface.") == nil) then 
        --get corresponding db entry from networkInterface
        query = "interfaceName='" .. row["interfaceName"] .. "'"
        nwRow = db.getRowWhere ("networkInterface", query, false)
        if (nwRow == nil) then
            return "1", "DB_ERROR_TRY_AGAIN"
        end

        if(nwRow["zoneType"] == "insecure" and nwRow["LogicalIfName"] == "IF1") then
            --get corresponding db entry from NimfConf
            query = "LogicalIfName='" .. nwRow["LogicalIfName"] .. "'"
            query = query .. " and " .. "AddressFamily='2'"
            nimfRow = db.getRowWhere ("NimfConf", query, false)
            if(nimfRow == nil) then
                return "1", "DB_ERROR_TRY_AGAIN"
            end

            --possible connection types: dhcpc,ifStatic,pppoe,pptp,l2tp
            if(string.find(param, "IP.Interface.")) then 
                if(nimfRow["ConnectionType"] ~= "dhcpc" and nimfRow["ConnectionType"] ~= "ifStatic") then
                    value = "0"
                    return status, value
                end
            end
            if(string.find(param, "PPP.Interface.")) then 
                if(nimfRow["ConnectionType"] ~= "pppoe") then
                    value = "0"
                    return status, value
                end
            end
        end
    end

    logicalIfName = row["LogicalIfName"]
    require "ifDevLib"
    netStatsTbl = ifDevLib.netIfInfoGet(logicalIfName)
    
    if (string.find (input["param"], "BytesSent")) then
        value = tostring(netStatsTbl["tx_bytes"])
    elseif (string.find (input["param"], "BytesReceived")) then
        value = tostring(netStatsTbl["rx_bytes"])
    elseif (string.find (input["param"], "DiscardPacketsSent")) then
        value = tostring(netStatsTbl["tx_dropped"])
    elseif (string.find (input["param"], "DiscardPacketsReceived")) then
        value = tostring(netStatsTbl["rx_dropped"])
    elseif (string.find (input["param"], "ErrorsSent")) then
        value = tostring(netStatsTbl["tx_errors"])
    elseif (string.find (input["param"], "ErrorsReceived")) then
        value = tostring(netStatsTbl["rx_errors"])
    elseif (string.find (input["param"], "UnknownProtoPacketsReceived")) then
        value = tostring(netStatsTbl["rx_dropped"])
    elseif (string.find (input["param"], "UnicastPacketsSent")) then
        local iptCmd = IPTABLE_CMD .. "fwOutUnicastCount" .. " -nxv | grep " .. row["interfaceName"] .. " | awk {'print $1'}" 
        local pipe = assert(io.popen(iptCmd), 'r') 
        local txUnicast = pipe:read("*line")
        pipe:close()
        value = txUnicast
    elseif (string.find (input["param"], "UnicastPacketsReceived")) then
        local iptCmd = IPTABLE_CMD .. "fwInUnicastCount" .. " -nxv | grep " .. row["interfaceName"] .. " | awk {'print $1'}" 
        local pipe = assert(io.popen(iptCmd), 'r') 
        local rxUnicast = pipe:read("*line")
        pipe:close()
        value = rxUnicast
    elseif (string.find (input["param"], "MulticastPacketsReceived")) then
        value = tostring(netStatsTbl["multicast"])
    elseif (string.find (input["param"], "MulticastPacketsSent")) then
        local iptCmd = IPTABLE_CMD .. "fwOutMulticastCount" .. " -nxv | grep " .. row["interfaceName"] .. " | awk {'print $1'}" 
        local pipe = assert(io.popen(iptCmd), 'r') 
        local txMulticast = pipe:read("*line")
        pipe:close()
        value = txMulticast
    elseif (string.find (input["param"], "BroadcastPacketsSent")) then
        local iptCmd = IPTABLE_CMD .. "fwOutBroadcastCount" .. " -nxv | grep " .. row["interfaceName"] .. " | awk {'print $1'}" 
        local pipe = assert(io.popen(iptCmd), 'r') 
        local txBroadcast = pipe:read("*line")
        pipe:close()
        value = txBroadcast
    elseif (string.find (input["param"], "BroadcastPacketsReceived")) then
        local iptCmd = IPTABLE_CMD .. "fwInBroadcastCount" .. " -nxv | grep " .. row["interfaceName"] .. " | awk {'print $1'}" 
        local pipe = assert(io.popen(iptCmd), 'r') 
        local rxBroadcast = pipe:read("*line")
        pipe:close()
        value = rxBroadcast
    elseif (string.find (input["param"], "PacketsSent")) then
        value = tostring(netStatsTbl["tx_packets"])
    elseif (string.find (input["param"], "PacketsReceived")) then
        value = tostring(netStatsTbl["rx_packets"])
    elseif (string.find (input["param"], "LowerLayers")) then
        if (logicalIfName == "IF1") then
            value = ""
        else
            value = ""
        end
    end

    -- Last Change parameter
    require "nimfLib"
    local connID = {}
    connID["LogicalIfName"] = logicalIfName
    connID["AddressFamily"] = "2"
    connID["ConnectionKey"] = "0"

    if (string.find (input["param"], "LastChange")) then
        local lastChange = ""
        local conn = nimfLib.connGet (connID)
        if (conn ~= nil) then
            lastChange = ifDevTr.timeInSecs(conn["Uptime"])
        end
        value = tostring(lastChange)
    end

    return status, value
end

--[[
--*****************************************************************************
-- ifDevTr.nwEthStatsGet - get network statistics 
-- 
-- This function is called to get the following parameters in,
-- Device.Ethernet.Interface.0.Stats.
-- Device.IP.Interface.0.Stats.
--
-- BytesSent
-- BytesReceived
-- PacketsSent
-- PacketsReceived
--
-- Returns: status, value
]]--
function ifDevTr.nwEthStatsGet(input)
    local status = "0"
    local value = ""
    local row = {}
    local ethRow = {}
    local rowId
    local query = nil
    local param = input["param"]
    local parentObjInstance = ""
    local logicalIfName
    local netStatsTbl = {}
    local IPTABLE_CMD = "/pfrm2.0/bin/iptables -w -t mangle -L "

    --load instanceMap
    local instanceMap =  tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", value
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "Interface.")
    parentObjInstance = string.sub(param, 1, endIdx+2)

    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", value
    end
    
    --get corresponding db entry from ethernet
    query = "_ROWID_=" .. rowId
    ethRow = db.getRowWhere ("ethernet", query, false)
    if (ethRow == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    
    --get corresponding db entry from bridgeTable 
    query = "LogicalIfName='" .. ethRow["LogicalIfName"] .. "'"
    row = db.getRowWhere ("bridgeTable", query, false)
    if(row == "nil") then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --if wan ip interface, then check connection type
    local nwRow = {} 
    local nimfRow = {}
    if(string.find(param, "Ethernet.Interface.") == nil) then 
        --get corresponding db entry from networkInterface
        query = "interfaceName='" .. row["interfaceName"] .. "'"
        nwRow = db.getRowWhere ("networkInterface", query, false)
        if (nwRow == nil) then
            return "1", "DB_ERROR_TRY_AGAIN"
        end

        if(nwRow["zoneType"] == "insecure" and nwRow["LogicalIfName"] == "IF1") then
            --get corresponding db entry from NimfConf
            query = "LogicalIfName='" .. nwRow["LogicalIfName"] .. "'"
            query = query .. " and " .. "AddressFamily='2'"
            nimfRow = db.getRowWhere ("NimfConf", query, false)
            if(nimfRow == nil) then
                return "1", "DB_ERROR_TRY_AGAIN"
            end

            --possible connection types: dhcpc,ifStatic,pppoe,pptp,l2tp
            if(string.find(param, "IP.Interface.")) then 
                if(nimfRow["ConnectionType"] ~= "dhcpc" and nimfRow["ConnectionType"] ~= "ifStatic") then
                    value = "0"
                    return status, value
                end
            end
            if(string.find(param, "PPP.Interface.")) then 
                if(nimfRow["ConnectionType"] ~= "pppoe") then
                    value = "0"
                    return status, value
                end
            end
        end
    end
    if ((ethRow["interfaceName"] == "eth1") and (ethRow["LogicalIfName"] == "IF2")) then 
        logicalIfName = row["LogicalIfName"]
        require "ifDevLib"
        netStatsTbl = ifDevLib.netEthernetInfoGet(ethRow["interfaceName"])
    else
        logicalIfName = row["LogicalIfName"]
        require "ifDevLib"
        netStatsTbl = ifDevLib.netIfInfoGet(logicalIfName)
    end
    
    if (string.find (input["param"], "BytesSent")) then
        value = tostring(netStatsTbl["tx_bytes"])
    elseif (string.find (input["param"], "BytesReceived")) then
        value = tostring(netStatsTbl["rx_bytes"])
    elseif (string.find (input["param"], "DiscardPacketsSent")) then
        value = tostring(netStatsTbl["tx_dropped"])
    elseif (string.find (input["param"], "DiscardPacketsReceived")) then
        value = tostring(netStatsTbl["rx_dropped"])
    elseif (string.find (input["param"], "ErrorsSent")) then
        value = tostring(netStatsTbl["tx_errors"])
    elseif (string.find (input["param"], "ErrorsReceived")) then
        value = tostring(netStatsTbl["rx_errors"])
    elseif (string.find (input["param"], "UnknownProtoPacketsReceived")) then
        value = tostring(netStatsTbl["rx_dropped"])
    elseif (string.find (input["param"], "UnicastPacketsSent")) then
        local iptCmd = IPTABLE_CMD .. "fwOutUnicastCount" .. " -nxv | grep " .. row["interfaceName"] .. " | awk {'print $1'}" 
        local pipe = assert(io.popen(iptCmd), 'r') 
        local txUnicast = pipe:read("*line")
        pipe:close()
        value = txUnicast
    elseif (string.find (input["param"], "UnicastPacketsReceived")) then
        local iptCmd = IPTABLE_CMD .. "fwInUnicastCount" .. " -nxv | grep " .. row["interfaceName"] .. " | awk {'print $1'}" 
        local pipe = assert(io.popen(iptCmd), 'r') 
        local rxUnicast = pipe:read("*line")
        pipe:close()
        value = rxUnicast
    elseif (string.find (input["param"], "MulticastPacketsReceived")) then
        value = tostring(netStatsTbl["multicast"])
    elseif (string.find (input["param"], "MulticastPacketsSent")) then
        local iptCmd = IPTABLE_CMD .. "fwOutMulticastCount" .. " -nxv | grep " .. row["interfaceName"] .. " | awk {'print $1'}" 
        local pipe = assert(io.popen(iptCmd), 'r') 
        local txMulticast = pipe:read("*line")
        pipe:close()
        value = txMulticast
    elseif (string.find (input["param"], "BroadcastPacketsSent")) then
        local iptCmd = IPTABLE_CMD .. "fwOutBroadcastCount" .. " -nxv | grep " .. row["interfaceName"] .. " | awk {'print $1'}" 
        local pipe = assert(io.popen(iptCmd), 'r') 
        local txBroadcast = pipe:read("*line")
        pipe:close()
        value = txBroadcast
    elseif (string.find (input["param"], "BroadcastPacketsReceived")) then
        local iptCmd = IPTABLE_CMD .. "fwInBroadcastCount" .. " -nxv | grep " .. row["interfaceName"] .. " | awk {'print $1'}" 
        local pipe = assert(io.popen(iptCmd), 'r') 
        local rxBroadcast = pipe:read("*line")
        pipe:close()
        value = rxBroadcast
    elseif (string.find (input["param"], "PacketsSent")) then
        value = tostring(netStatsTbl["tx_packets"])
    elseif (string.find (input["param"], "PacketsReceived")) then
        value = tostring(netStatsTbl["rx_packets"])
    elseif (string.find (input["param"], "LowerLayers")) then
        --[[
        if (logicalIfName == "IF1") then
            value = "WAN"
        elseif ((ethRow["interfaceName"] == "eth1") and (ethRow["LogicalIfName"] == "IF2")) then
            value = "LAN4"
        else 
            value = "LAN"
        end
        ]]--
        value = ""
    end

    -- Last Change parameter
    require "nimfLib"
    local connID = {}
    connID["LogicalIfName"] = logicalIfName
    connID["AddressFamily"] = "2"
    connID["ConnectionKey"] = "0"

    if (string.find (input["param"], "LastChange")) then
        local lastChange = ""
        local conn = nimfLib.connGet (connID)
        if (conn ~= nil and (string.find(conn["Uptime"], "N/A") == nil)) then
            lastChange = ifDevTr.timeInSecs(conn["Uptime"])
        end
        value = tostring(lastChange)
    end

    return status, value
end

--[[
--*****************************************************************************
-- ifDevTr.statsGet - get interface statistics 
-- 
-- This function is called to get the following parameters in,
-- Device.Ethernet.VLANTermination.0.Stats.
-- Device.IP.VLANTermination.0.Stats.
--
-- BytesSent
-- BytesReceived
-- PacketsSent
-- PacketsReceived
--
-- Returns: status, value
]]--
function ifDevTr.statsGet(input)
    local status = "0"
    local value = ""
    local row = {}
    local rowId
    local query = nil
    local param = input["param"]
    local parentObjInstance = ""
    local logicalIfName
    local netStatsTbl = {}

    --load instanceMap
    local instanceMap =  tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", value
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "VLANTermination.")
    parentObjInstance = string.sub(param, 1, endIdx+2)

    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", value
    end

    --get corresponding db entry from vlanEncapIf 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("vlanEncapIf", query, false)
    
    if(row == "nil") then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    ifName = row["interfaceName"] .. "." .. row["vlanId"]
    require "ifDevLib"
    netStatsTbl = ifDevLib.interfaceStatsGet(ifName)
   
    if (string.find (input["param"], "BytesSent")) then
        value = tostring(netStatsTbl["tx_bytes"])
    elseif (string.find (input["param"], "BytesReceived")) then
        value = tostring(netStatsTbl["rx_bytes"])
    elseif (string.find (input["param"], "DiscardPacketsSent")) then
        value = tostring(netStatsTbl["tx_dropped"])
    elseif (string.find (input["param"], "DiscardPacketsReceived")) then
        value = tostring(netStatsTbl["rx_dropped"])
    elseif (string.find (input["param"], "ErrorsSent")) then
        value = tostring(netStatsTbl["tx_errors"])
    elseif (string.find (input["param"], "ErrorsReceived")) then
        value = tostring(netStatsTbl["rx_errors"])
    elseif (string.find (input["param"], "UnknownProtoPacketsReceived")) then
        value = tostring(netStatsTbl["rx_dropped"])
    elseif (string.find (input["param"], "MulticastPacketsReceived")) then
        value = tostring(netStatsTbl["multicast"])
    elseif (string.find (input["param"], "BroadcastPacketsReceived")) then
        value = tostring(netStatsTbl["multicast"])
    elseif (string.find (input["param"], "UnicastPacketsReceived")) then
        value = tostring(netStatsTbl["rx_packets"] - netStatsTbl["multicast"])
    elseif (string.find (input["param"], "MulticastPacketsSent")) then
        value = "0"
    elseif (string.find (input["param"], "BroadcastPacketsSent")) then
        value = "0"
    elseif (string.find (input["param"], "UnicastPacketsSent")) then
        value = tostring(netStatsTbl["tx_packets"])
    elseif (string.find (input["param"], "PacketsSent")) then
        value = tostring(netStatsTbl["tx_packets"])
    elseif (string.find (input["param"], "PacketsReceived")) then
        value = tostring(netStatsTbl["rx_packets"])
    end

    return status, value
end

--[[
--*****************************************************************************
-- ifDevTr.bridgePortStatsGet - get bridge port interface statistics 
-- 
-- This function is called to get the following parameters in,
-- Device.Bridging.Bridge.0.Port.0.Stats.
--
-- BytesSent
-- BytesReceived
-- PacketsSent
-- PacketsReceived
-- ErrorsSent
-- ErrorsReceived
-- UnicastPacketsSent
-- UnicastPacketsReceived
-- DiscardPacketsSent
-- DiscardPacketsReceived
-- MulticastPacketsSent
-- MulticastPacketsReceived
-- BroadcastPacketsSent
-- BroadcastPacketsReceived
-- UnknownProtoPacketsReceived
-- 
-- Returns: status, value
]]--
function ifDevTr.bridgePortStatsGet(input)
    local status = "0"
    local value = ""
    local param = input["param"]
    local parentObjInstance = ""
    local row = {}
    local rowId
    local query = nil
    local netStatsTbl = {}

    --load instanceMap
    local instanceMap =  tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", value
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "Port.")
    parentObjInstance = string.sub(param, 1, endIdx+2)

    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", value
    end

    --get corresponding db entry from bridgeModePorts 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("bridgeModePorts", query, false)
    
    if(row == "nil") then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    ifName = row["InterfaceName"]
    require "ifDevLib"
    netStatsTbl = ifDevLib.interfaceStatsGet(ifName)
  
    if (string.find (input["param"], "BytesSent")) then
        value = tostring(netStatsTbl["tx_bytes"])
    elseif (string.find (input["param"], "BytesReceived")) then
        value = tostring(netStatsTbl["rx_bytes"])
    elseif (string.find (input["param"], "PacketsSent")) then
        value = tostring(netStatsTbl["tx_packets"])
    elseif (string.find (input["param"], "PacketsReceived")) then
        value = tostring(netStatsTbl["rx_packets"])
    elseif (string.find (input["param"], "ErrorsSent")) then
        value = tostring(netStatsTbl["tx_errors"])
    elseif (string.find (input["param"], "ErrorsReceived")) then
        value = tostring(netStatsTbl["rx_errors"])
    elseif (string.find (input["param"], "UnicastPacketsSent")) then
        value = tostring(netStatsTbl["tx_packets"])
    elseif (string.find (input["param"], "UnicastPacketsReceived")) then
        value = tostring(netStatsTbl["rx_packets"] - netStatsTbl["multicast"])
    elseif (string.find (input["param"], "DiscardPacketsSent")) then
        value = tostring(netStatsTbl["tx_dropped"])
    elseif (string.find (input["param"], "DiscardPacketsReceived")) then
        value = tostring(netStatsTbl["rx_dropped"])
    elseif (string.find (input["param"], "MulticastPacketsSent")) then
        value = "0"
    elseif (string.find (input["param"], "MulticastPacketsReceived")) then
        value = tostring(netStatsTbl["multicast"])
    elseif (string.find (input["param"], "BroadcastPacketsSent")) then
        value = "0"
    elseif (string.find (input["param"], "BroadcastPacketsReceived")) then
        value = tostring(netStatsTbl["multicast"])
    elseif (string.find (input["param"], "UnknownProtoPacketsReceived")) then
        value = tostring(netStatsTbl["rx_dropped"])
    end

    return status, value
end

--[[
--*****************************************************************************
-- ifDevTr.timeInSecs - time in secs 
-- 
-- This function is convert time in secs.
--
-- Returns: time in secs
]]--

function ifDevTr.timeInSecs (time)

    local secs = 0

    if (time == nil) then
        return 0
    end

    local days = util.split (time, " ")
    if (days ~= nil) then
        mins = util.split (days[3], ":")
        if (mins ~= nil) then
            local daySecs = tonumber(days[1] * 24 * 60 * 60)
            local hrSecs = tonumber(mins[1] * 60 * 60)
            local minSecs = tonumber(mins[2] * 60)
            local secs = tonumber(mins[3])
            secs = daySecs + hrSecs + minSecs + secs
            return secs
         end
    end

    return secs
end

--[[
--*****************************************************************************
-- ifDevTr.opticalStatsGet - get optical statistics 
-- 
-- This function is called to get the following parameters in,
-- Device.Optical.Interface.0.Stats.
--
-- BytesSent
-- BytesReceived
-- PacketsSent
-- PacketsReceived
-- ErrorsSent
-- ErrorsReceived
-- DiscardPacketsSent
-- DiscardPacketsReceived
-- 
-- Returns: status, value
]]--
function ifDevTr.opticalStatsGet(input)

    local status = "0"
    local value = ""
    local row = {}
    local rowId
    local query = nil
    local param = input["param"]
    local parentObjInstance = ""
    local logicalIfName
    local netStatsTbl = {}

    --load instanceMap
    local instanceMap =  tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", value
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "Interface.")
    parentObjInstance = string.sub(param, 1, endIdx+2)

    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", value
    end
    
    local bridgeModeRow = db.getRow ("bridgeMode", "_ROWID_", "1")
    local gponRow = db.getRow ("gpon", "_ROWID_", "1")
    if(gponRow["gpon.status"] == "1") then
       ifName = bridgeModeRow["bridgeMode.wanIface"]
    elseif(gponRow["gpon.status"] == "0") then
       value = "0"
       return status, value
    end

    require "ifDevLib"
    netStatsTbl = ifDevLib.interfaceStatsGet(ifName)
   
    if (string.find (input["param"], "BytesSent")) then
        value = tostring(netStatsTbl["tx_bytes"])
    elseif (string.find (input["param"], "BytesReceived")) then
        value = tostring(netStatsTbl["rx_bytes"])
    elseif (string.find (input["param"], "DiscardPacketsSent")) then
        value = tostring(netStatsTbl["tx_dropped"])
    elseif (string.find (input["param"], "DiscardPacketsReceived")) then
        value = tostring(netStatsTbl["rx_dropped"])
    elseif (string.find (input["param"], "ErrorsSent")) then
        value = tostring(netStatsTbl["tx_errors"])
    elseif (string.find (input["param"], "ErrorsReceived")) then
        value = tostring(netStatsTbl["rx_errors"])
    elseif (string.find (input["param"], "UnknownProtoPacketsReceived")) then
        value = tostring(netStatsTbl["rx_dropped"])
    elseif (string.find (input["param"], "MulticastPacketsReceived")) then
        value = tostring(netStatsTbl["multicast"])
    elseif (string.find (input["param"], "BroadcastPacketsReceived")) then
        value = tostring(netStatsTbl["multicast"])
    elseif (string.find (input["param"], "UnicastPacketsReceived")) then
        value = tostring(netStatsTbl["rx_packets"] - netStatsTbl["multicast"])
    elseif (string.find (input["param"], "MulticastPacketsSent")) then
        value = "0"
    elseif (string.find (input["param"], "BroadcastPacketsSent")) then
        value = "0"
    elseif (string.find (input["param"], "UnicastPacketsSent")) then
        value = tostring(netStatsTbl["tx_packets"])
    elseif (string.find (input["param"], "PacketsSent")) then
        value = tostring(netStatsTbl["tx_packets"])
    elseif (string.find (input["param"], "PacketsReceived")) then
        value = tostring(netStatsTbl["rx_packets"])
    end

    return status, value
end
