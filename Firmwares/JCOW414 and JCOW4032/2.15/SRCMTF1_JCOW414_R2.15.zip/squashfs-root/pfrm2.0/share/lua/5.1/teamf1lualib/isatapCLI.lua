-- isatapCLI.lua
-- Samer Sayeed
-- TeamF1
-- www.TeamF1.com
--
-- Modification History
-- 22jan09,ss written 
--
-- Description
-- CLI interface set and get routines

require "teamf1lualib/nimfView"

function isatapTunnelCfgDel (configRow)
    DBTable = "isatapTunnel"
    rows = {}
    rows["rowid"] = configRow["isatapTunnel._ROWID_"]
    -- if any rows to delete
    if (rows) then
        errorFlag, statusCode = nimfView.isatapTunnelDelete(rows)
    end
    -- save db if no error
    if (errorFlag == "OK") then db.save() end
    statusMessage = db.getAttribute("stringsMap", "stringId", statusCode, LANGUAGE)
    return errorFlag, statusMessage
end

function isatapTunnelCfgSave (configRow)
    DBTable = "isatapTunnel"
    if (configRow["isatapTunnel._ROWID_"] == "-1") then
        errorFlag, statusCode = nimfView.isatapTunnelConfig(configRow, "-1", "add")
    else
        errorFlag, statusCode = nimfView.isatapTunnelConfig(configRow, configRow["isatapTunnel._ROWID_"], "edit")
    end
    -- save db if no error
    if (errorFlag == "OK") then db.save() end
    statusMessage = db.getAttribute("stringsMap", "stringId", statusCode, LANGUAGE)
    return errorFlag, statusMessage
end

function isatapTunnelCfgInit (args)
    -- for Add
    local totalSize = db.tableSize("isatapTunnel")
    totalSize = "isatap" .. totalSize+1 
    if (args[1] == nil) then
        configRow = {}
        configRow["isatapTunnel._ROWID_"] = "-1"
        configRow["isatapTunnel.interfaceName"] = totalSize
        configRow["isatapTunnel.transportIfName"] = "LAN"
        configRow["isatapTunnel.isatapTunnelStatus"] = "1"
        configRow["isatapTunnel.useLanAddress"] = "1"
    -- for edit
    else
        configRow = db.getRow("isatapTunnel", "_ROWID_", args[1])
    end
    if(configRow == nil)then
        print("Row Deleted")
        return -1, {}
    end
    return configRow["isatapTunnel._ROWID_"], configRow
end

function isatapTunnelCfgInputVal(configRow)
    local ipMode = db.getAttribute ("networkInfo", "_ROWID_", "1", "netWorkMode")
    if (ipMode == "1") then
        printCLIError ("Please Set IP Mode to IPv4/IPv6 to configure IPv6 Tunnels.")
        return false
    end
    if (configRow["isatapTunnel.isatapPrefix"] == nil or configRow["isatapTunnel.isatapPrefix"] == "") then
        printCLIError ("Enter valid ISATAP Subnet Prefix")
        return false
    end
    if (configRow["isatapTunnel.useLanAddress"] == "0") then
        if( configRow["isatapTunnel.localIPv4Address"] == "" or configRow["isatapTunnel.localIPv4Address"] == nil) then
        printCLIError ("Enter valid IPv4 Address")
        return false
        end
    end
    return true
end
