-- @copyright Copyright (c) 2013, TeamF1, Inc.
--
-- modification history
-- --------------------
-- 01a, 10aug13, ash added support for l2tp
--
--
--[[ Wizards ]]--
gui.networking.wizard = {}

-------------------------------------------------------------------------------
-- @name gui.networking.wizard.get 
--
-- @description This function gets info to display wizard pages
--
-- @return 
--
function gui.networking.wizard.get ()

    --include
    require ("teamf1lualib/nimf")
    require ("teamf1lualib/nimfConn")
    require ("teamf1lualib/network")
    require "fwPortTriggerLuaLib"
    
    --locals
    local wizardTbl = {}
    local localTbl = {}
    local wifiCfgTbl = {}
    local err, statusMsg 

    -- get default connection type.
    require "teamf1lualib/nimf"
    local wiredConnTbl = nimf.getDefConnCfg ();
    if (wiredConnTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN", localTbl
    end

    -- get default wireless settings
    require "teamf1lualib/dot11"
    wifiCfgTbl = dot11.getDefWifiCfg ();
    if (wifiCfgTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN", localTbl
    end

    -- get default security mode
    require "teamf1lualib/firewall"
    local mode = db.getAttribute("SecurityConfig","LogicalIfName", "IF2", "securityLevel")

    -- get default system configuration settings
    local systemTbl = {}
    require "teamf1lualib/platform"
    systemTbl = platform.getDefSysCfg ()     -- fill in lua table as htm expects
    if (systemTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN", localTbl
    end
 
    -- Getting the connection type of the default WAN network
    local conf = {}
    local networkConf = {}
    local confTmp = {}
    local connID = {}
    local name = db.getAttribute("networkInterface", "LogicalIfName", "IF1", "networkName") 
    err, statusMsg, networkConf = network.ifConfGet(name)
    if (err ~= "OK") then
        gui.dprintf("ipv4.get: failed to get interface configuration")
        return err, status        
    end 

    -- Filling in the required details for the function
    conf["networkName"]	    = networkConf["networkName"]
    conf["LogicalIfName"]   = networkConf["LogicalIfName"]
    conf["networkType"]	    = gui.networking.zoneTypeToNetworkType (networkConf["zoneType"])
    conf["vlanId"]			= networkConf["networkId"]
    conf["AddressFamily"]   = "ipv4"

    connID["LogicalIfName"] = networkConf["LogicalIfName"]
    connID["AddressFamily"] = nimf.proto.NIMF_PROTO_TYPE_IPV4
    err, statusMsg, confTmp = gui.networking.connConfGet(connID, conf)
    if (err ~= "OK") then
        gui.dprintf("ipv4.get: failed to get connection configuration")
        -- Do not return because just after creating the network. You may not
        -- have the connection params.
    else
        conf = confTmp
    end        

    util.appendDebugOut("Connection type = " .. conf["ConnectionType"])
    
    wizardTbl ["hdConnType"] = conf["ConnectionType"]
    if (conf["ConnectionType"] == "dhcpc") then
        wizardTbl ["connection_type"] = "0"

    elseif (conf["ConnectionType"] == "pppoe") then
        wizardTbl ["connection_type"] = "1"
		wizardTbl["pppoe_UserName"] =  wiredConnTbl["pppoe_UserName"]
		wizardTbl["pppoe_Password"] = util.mask (wiredConnTbl["pppoe_Password"])
		wizardTbl["pppoe_DomainName"] = wiredConnTbl["pppoe_DomainName"]
		wizardTbl["pppoe_IdleTimeOutFlag"] = wiredConnTbl["pppoe_IdleTimeOutFlag"]
	elseif (conf["ConnectionType"] == "pptp") then
		wizardTbl["connection_type"] = "2"
		wizardTbl["pptp_UserName"] = wiredConnTbl["pptp_UserName"]
		wizardTbl["pptp_Password"] =util.mask (wiredConnTbl["pptp_Password"])
		wizardTbl["pptp_MyIp"] = wiredConnTbl["pptp_MyIp"]
		wizardTbl["pptp_ServerIp"] = wiredConnTbl["pptp_ServerIp"]
		wizardTbl["pptp_IdleTimeOutFlag"] = wiredConnTbl["pptp_IdleTimeOutFlag"]
    elseif (conf["ConnectionType"] == "l2tp") then
		wizardTbl["connection_type"] = "4"
		wizardTbl["l2tp_UserName"] = wiredConnTbl["l2tp_UserName"]
		wizardTbl["l2tp_Password"] =util.mask (wiredConnTbl["l2tp_Password"])
		wizardTbl["l2tp_MyIp"] = wiredConnTbl["l2tp_MyIp"]
		wizardTbl["l2tp_ServerIp"] = wiredConnTbl["l2tp_ServerIp"]
		wizardTbl["l2tp_IdleTimeOutFlag"] = wiredConnTbl["l2tp_IdleTimeOutFlag"]
    elseif (conf["ConnectionType"] == "ifStatic") then
        wizardTbl["connection_type"] = "3"
		wizardTbl["ipAddress"] = wiredConnTbl["ipAddress"]
		wizardTbl["subnetMask"] = wiredConnTbl["subnetMask"] 
		wizardTbl["gateway"] = wiredConnTbl["Gateway"] 
		wizardTbl["dns1"]  = wiredConnTbl["nameserver1"]
		wizardTbl["dns2"]  = wiredConnTbl["nameserver2"]
     end

    -- getting the values for the hidden fields

    local cfgTbl = {}
    local query = "networkInterface:ipAddressTable:LogicalIfName"
    cfgTbl = db.getTableWithJoin ({query})
    local lanTbl = {}
    local wanTbl = {}
    
    for i,v in pairs (cfgTbl) do
        if ((v["networkInterface.zoneType"] == "secure") and (v["ipAddressTable.addressFamily"] == "2")) then
            lanTbl[i] = {}
            lanTbl[i]["hdLanIp"] = v["ipAddressTable.ipAddress"]
            lanTbl[i]["hdLanSnet"] = v["ipAddressTable.subnetMask"]
            lanTbl[i]["hdLanIfName"] = v["networkInterface.networkName"]
        end
        if ((v["networkInterface.zoneType"] == "insecure") and (v["ipAddressTable.addressFamily"] == "2")) then
            wanTbl[i] = {}
            wanTbl[i]["hdWanIp"] = v["ipAddressTable.ipAddress"]
            wanTbl[i]["hdWanSnet"] = v["ipAddressTable.subnetMask"]
            wanTbl[i]["hdWanIfName"] = v["networkInterface.networkName"]
        end
    end

    local dmzTable = {}
    local dmzTbl = {}
    dmzTable = db.getTable("dmz", false)
    if (dmzTable ~= nil) then
        if (dmzTable.ipAddr ~= nil) then
            dmzTbl["hdDmzIp"] = dmzTable.ipAddr or ""
            local ifStaticTbl = {}
            ifStaticTbl = db.getTable("ifStatic", false)
            for i,v in pairs (ifStaticTbl) do
                local statusFlag = fwPortTriggerLuaLib.getNetwork (v["StaticIp"], v["NetMask"], dmzTable.ipAddr)
                if (statusFlag == 1) then
                    dmzTbl["hdDmzSnet"] = v["NetMask"] or ""
                end
            end
         end
    else
        return "ERROR", "DB_ERROR_TRY_AGAIN", localTbl
    end


    local pppoeTable = {}
    pppoeTable["hdPppoeIp"] = wiredConnTbl ["pppoe_StaticIp"]
    pppoeTable["hdPppoeSnet"] = wiredConnTbl ["pppoe_NetMask"]

    local pptpTable = {}
    pptpTable["hdPptpIp"] = wiredConnTbl ["pptp_MyIp"]
    pptpTable["hdPptpSnet"] = wiredConnTbl ["pptp_NetMask"]
    pptpTable["hdPptpServerIp"] = wiredConnTbl ["pptp_ServerIp"]

    local l2tpTable = {}
    l2tpTable["hdL2tpIp"] = wiredConnTbl ["l2tp_MyIp"]
    l2tpTable["hdL2tpSnet"] = wiredConnTbl ["l2tp_NetMask"]
    l2tpTable["hdL2tpServerIp"] = wiredConnTbl ["l2tp_ServerIp"]

    wizardTbl.dmzTbl = dmzTbl
    wizardTbl.lanTbl = lanTbl
    wizardTbl.wanTbl = wanTbl
    wizardTbl.pppoeTable = pppoeTable
    wizardTbl.pptpTable = pptpTable
    wizardTbl.l2tpTable = l2tpTable

    --getting the wireless info
	wizardTbl["wstatus"] = wifiCfgTbl["wstatus"]
	wizardTbl["wname"] = wifiCfgTbl["wname"]
    if (wifiCfgTbl["wpassword"] ~= nil) then
	    wizardTbl["wpassword"] = util.mask(wifiCfgTbl["wpassword"])
    else
        wizardTbl["wpassword"] = ""
    end

	--getting the security info    
    wizardTbl["mode"] = mode

	--getting the system info
    wizardTbl["system_name"] = systemTbl["name"]
    wizardTbl["admin_password"] = systemTbl["admin_password"]
    wizardTbl["timezone"] = systemTbl["time_zone"]
    wizardTbl["daylight_savings_flag"] = systemTbl["daylight_savings_flag"]

    err = "OK"
    statusMsg = ""
    --return
    return err, statusMsg, wizardTbl
end

-------------------------------------------------------------------------------
-- @name gui.networking.wizard.set 
--
-- @description This function apply wizard settings to the system
-- 
-- @param lua table.
--
-- @return 
--
function gui.networking.wizard.set (wizardCfg)

      -- require 
    require "teamf1lualib/time"
    require "teamf1lualib/userdb"
    require "teamf1lualib/firewall"
    require "teamf1lualib/platform"
    require "teamf1lualib/nimf"
    require "teamf1lualib/network"
    require "teamf1lualib/nimfConn"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- configure time
    local ntpTbl = {}
    local errMsg, status
    local query = "_ROWID_=1"
    ntpTbl = db.getRowWhere("ntp", query, false)
    ntpTbl["autoDaylight"] = wizardCfg["daylight_savings_flag"]
    ntpTbl["timezone"] = wizardCfg["timezone"]
    ntpTbl = util.addPrefix (ntpTbl, "ntp.");
    ntp.config (ntpTbl, 1, "edit");

    -- TODO: configure system settings
    local sysconfTbl = {}
    sysconfTbl["system_name"] = wizardCfg["system_name"];
    platform.sysInfoSet (sysconfTbl);

    -- configure the pppoe setings
    local pppoeTbl = {}
    local pptpTbl = {}
    local l2tpTbl = {}
    local ifstaticTbl = {}
    if (wizardCfg["connection_type"] == "0") then
        local dhcpTbl = {}
		dhcpTbl["ConnectionType"] = "dhcp"
        dhcpTbl["GetDnsFromIsp"] = "1"
        dhcpTbl["GetIpFromIsp"] = "1"
        dhcpTbl["mppe"] = "1"
        dhcpTbl["ConnectionType"] = "dhcpc"
        dhcpTbl["AddressFamily"] = "ipv4" 
        dhcpTbl["Enable"] = "1"
        dhcpTbl["LogicalIfName"] = "IF1"
        status, errMsg = network.configure ("Internet", dhcpTbl)
        if(status == "OK") then
            db.save()
        end
    elseif (wizardCfg["connection_type"] == "1") then
        local configPPPoeTbl = {}
        local query = "_ROWID_=1"
        local configPPPoeTbl = db.getRowWhere("Pppoe", query, false)
        if (configPPPoeTbl == nil) then
            return "ERROR", "DB_ERROR_TRY_AGAIN"
        end
        pppoeTbl["UserName"] = wizardCfg["pppoe_UserName"]
        if (util.isAllMasked (wizardCfg["pppoe_Password"])) then
            pppoeTbl["Password"] = db.getAttribute ("Pppoe","UserName",wizardCfg["pppoe_UserName"],"Password")
        else
            pppoeTbl["Password"] = wizardCfg["pppoe_Password"]
        end
		pppoeTbl["IdleDisconnect"] = wizardCfg["pppoe_IdleTimeOutFlag"]
		pppoeTbl["LogicalIfName"] = configPPPoeTbl["LogicalIfName"]
		pppoeTbl["Enable"] = "1"
		pppoeTbl["ConnectionType"] = "pppoe"
		pppoeTbl["AddressFamily"] = "ipv4"
		pppoeTbl["Mtu"] = "0"        
		pppoeTbl["IspName"] = configPPPoeTbl["IspName"]
		pppoeTbl["AccountName"] = configPPPoeTbl["AccountName"]
		pppoeTbl["DomainName"] = configPPPoeTbl["DomainName"]
		pppoeTbl["GetIpFromIsp"] = configPPPoeTbl["GetIpFromIsp"]
		pppoeTbl["GetDnsFromIsp"] = configPPPoeTbl["GetDnsFromIsp"]
		pppoeTbl["StaticIp"] = configPPPoeTbl["StaticIp"]
		pppoeTbl["NetMask"] = configPPPoeTbl["NetMask"]
		pppoeTbl["IdleDisconnectTime"] = configPPPoeTbl["IdleDisconnectTime"]
		pppoeTbl["ProfileName"] = configPPPoeTbl["ProfileName"]
		pppoeTbl["AuthOpt"] = configPPPoeTbl["AuthOpt"]
		pppoeTbl["PrimaryDns"] = configPPPoeTbl["PrimaryDns"]
		pppoeTbl["SecondaryDns"] = configPPPoeTbl["SecondaryDns"]
        status, errMsg = network.configure ("Internet", pppoeTbl)
        if(status == "OK") then
            db.save()
        end
    elseif (wizardCfg["connection_type"] == "2") then
        local configPPtpTbl = {}
        local query = "_ROWID_=1"
        local row = db.existsRow ("Pptp", "LogicalIfName", "IF1")
        if (row ~= false) then
            configPPtpTbl = db.getRowWhere("Pptp", query, false)
            if (configPPtpTbl == nil) then
                return "ERROR", "DB_ERROR_TRY_AGAIN"
            end
            pptpTbl["LogicalIfName"] = configPPtpTbl["LogicalIfName"]
            pptpTbl["IdleDisconnectTime"] = configPPtpTbl["IdleDisconnectTime"]
            pptpTbl["IspName"] = configPPtpTbl["IspName"]
            pptpTbl["GetIpFromIsp"] = configPPtpTbl["GetIpFromIsp"]
            pptpTbl["StaticIp"] = configPPtpTbl["StaticIp"]
            pptpTbl["NetMask"] = configPPtpTbl["NetMask"]
            pptpTbl["GetDnsFromIsp"] = configPPtpTbl["GetDnsFromIsp"]
            pptpTbl["PrimaryDns"] = configPPtpTbl["PrimaryDns"]
            pptpTbl["SecondaryDns"] = configPPtpTbl["SecondaryDns"]
            pptpTbl["MppeEncryptSupport"] = configPPtpTbl["MppeEncryptSupport"]
            pptpTbl["SplitTunnel"] = configPPtpTbl["SplitTunnel"]
            pptpTbl["DualAccess"] = configPPtpTbl["DualAccess"]
        else
            pptpTbl["LogicalIfName"] = "IF1"
            pptpTbl["IdleDisconnectTime"] = "0"
            pptpTbl["IspName"] = "Comcast"
            pptpTbl["GetIpFromIsp"] = "1"
            pptpTbl["StaticIp"] = ""
            pptpTbl["NetMask"] = ""
            pptpTbl["GetDnsFromIsp"] = "1"
            pptpTbl["PrimaryDns"] = ""
            pptpTbl["SecondaryDns"] = ""
            pptpTbl["MppeEncryptSupport"] = "0"
            pptpTbl["SplitTunnel"] = "0"
            pptpTbl["DualAccess"] = "0"    
        end
            pptpTbl["UserName"] = wizardCfg["pptp_UserName"]
            if (util.isAllMasked (wizardCfg["pptp_Password"])) then
                pptpTbl["Password"] = db.getAttribute ("Pptp","UserName",wizardCfg["pptp_UserName"],"Password")
            else
                pptpTbl["Password"] = wizardCfg["pptp_Password"]
            end
            pptpTbl["MyIPAddress"] = wizardCfg["pptp_MyIp"]
            pptpTbl["ServerIp"] = wizardCfg["pptp_ServerIp"]
            pptpTbl["IdleDisconnect"] = wizardCfg["pptp_IdleTimeOutFlag"]
            pptpTbl["Enable"] = "1"
            pptpTbl["AddressFamily"] = "2"
		    pptpTbl["ConnectionType"] = "pptp"
            status, errMsg = network.configure ("Internet", pptpTbl)
            if(status == "OK") then
                db.save()
            end
    elseif (wizardCfg["connection_type"] == "4") then
        local configL2tpTbl = {}
        local query = "_ROWID_=1"
        local row = db.existsRow ("L2tp", "LogicalIfName", "IF1")
        if (row ~= false) then
            configL2tpTbl = db.getRowWhere("L2tp", query, false)
            if (configL2tpTbl == nil) then
                return "ERROR", "DB_ERROR_TRY_AGAIN"
            end
            l2tpTbl["LogicalIfName"] = configL2tpTbl["LogicalIfName"]
            l2tpTbl["IdleDisconnectTime"] = configL2tpTbl["IdleDisconnectTime"]
            l2tpTbl["IspName"] = configL2tpTbl["IspName"]
            l2tpTbl["GetIpFromIsp"] = configL2tpTbl["GetIpFromIsp"]
            l2tpTbl["StaticIp"] = configL2tpTbl["StaticIp"]
            l2tpTbl["NetMask"] = configL2tpTbl["NetMask"]
            l2tpTbl["GetDnsFromIsp"] = configL2tpTbl["GetDnsFromIsp"]
            l2tpTbl["PrimaryDns"] = configL2tpTbl["PrimaryDns"]
            l2tpTbl["SecondaryDns"] = configL2tpTbl["SecondaryDns"]
            l2tpTbl["Secret"] = configL2tpTbl["Secret"]
            l2tpTbl["SplitTunnel"] = configL2tpTbl["SplitTunnel"]
            l2tpTbl["DualAccess"] = configL2tpTbl["DualAccess"]
        else
            l2tpTbl["LogicalIfName"] = "IF1"
            l2tpTbl["IdleDisconnectTime"] = "0"
            l2tpTbl["IspName"] = "Comcast"
            l2tpTbl["GetIpFromIsp"] = "1"
            l2tpTbl["StaticIp"] = ""
            l2tpTbl["NetMask"] = ""
            l2tpTbl["GetDnsFromIsp"] = "1"
            l2tpTbl["PrimaryDns"] = ""
            l2tpTbl["SecondaryDns"] = ""
            l2tpTbl["Secret"] = ""
            l2tpTbl["SplitTunnel"] = "0"
            l2tpTbl["DualAccess"] = "0"    
        end
            l2tpTbl["UserName"] = wizardCfg["l2tp_UserName"]
            if (util.isAllMasked (wizardCfg["l2tp_Password"])) then
                l2tpTbl["Password"] = db.getAttribute ("L2tp","UserName",wizardCfg["l2tp_UserName"],"Password")
            else
                l2tpTbl["Password"] = wizardCfg["l2tp_Password"]
            end
            l2tpTbl["MyIPAddress"] = wizardCfg["l2tp_MyIp"]
            l2tpTbl["ServerIp"] = wizardCfg["l2tp_ServerIp"]
            l2tpTbl["IdleDisconnect"] = wizardCfg["l2tp_IdleTimeOutFlag"]
            l2tpTbl["Enable"] = "1"
            l2tpTbl["AddressFamily"] = "2"
		    l2tpTbl["ConnectionType"] = "l2tp"
            status, errMsg = network.configure ("Internet", l2tpTbl)
            if(status == "OK") then
                db.save()
            end
    elseif (wizardCfg["connection_type"] == "3") then
        ifstaticTbl["LogicalIfName"] = "IF1"
        ifstaticTbl["AddressFamily"] = "2"
        local configifStaticTbl = {}
        configifStaticTbl = db.getRowWhere("ifStatic", query, false)
        if (configifStaticTbl == nil) then
            return "ERROR", "DB_ERROR_TRY_AGAIN"
        end
        ifstaticTbl["ConnectionKey"] = configifStaticTbl["ConnectionKey"]
        ifstaticTbl["StaticIp"] = wizardCfg["ipAddress"]
        ifstaticTbl["NetMask"] = wizardCfg["subnetMask"] 
        ifstaticTbl["Gateway"] = wizardCfg["gateway"] 
        ifstaticTbl["PrimaryDns"]  = wizardCfg["dns1"]
        ifstaticTbl["SecondaryDns"]  = wizardCfg["dns2"]
        ifstaticTbl["Enable"]  = "1"
		ifstaticTbl["ConnectionType"] = "ifStatic"
        status, errMsg = network.configure ("Internet", ifstaticTbl)
        if(status == "OK") then
            db.save()
        end
    end
    
    -- configure password for admin user
    local userTbl = {}
    if (util.isAllMasked (wizardCfg["admin_password"])) then
        userTbl["password"] = db.getAttribute ("users","username","admin","password")
    else
        userTbl["password"] = wizardCfg["admin_password"]
    end

    --userTbl["password"] = wizardCfg["admin_password"];
    userdb.setPasswd (userTbl);
    
    --[[
    --Removing following logic as we removed the security mode config page from
    --quick wizard.
    --
    local ifname = db.getAttribute("networkInterface", "LogicalIfName", "IF2", "networkName")
    -- configure security mode
    status, errMsg = firewall.securityLevelSet(ifname, wizardCfg["mode"])
    if (status ~= "OK") then
        return status, errMsg
    end
    ]]--
    
    -- configure admin access point
    local wirelessTbl = {}
    local queryWireless = "profileName='radio1'"
    
    -- getting the dot11Profile table 
    wirelessTbl = db.getRowWhere("dot11Profile",queryWireless, false)
    if (wizardCfg["wname"] ~= nil) then
        wirelessTbl["ssid"] = wizardCfg["wname"];
        if (wizardCfg["wpassword"] ~= nil) then
            if (util.isAllMasked (wizardCfg["wpassword"])) then
                wirelessTbl["pskPassAscii"] = db.getAttribute ("dot11Profile","profileName","radio1","pskPassAscii")
            else
                wirelessTbl["pskPassAscii"] = wizardCfg["wpassword"];
            end    
        end    
    end
    
    wirelessTbl["vapEnabled"] = wizardCfg["wstatus"]
    
    status, errMsg = gui.wireless.apProfileInfo.edit.set (wirelessTbl)
    if (status == "OK") then
        db.save()
    end
    return status, errMsg

end    

