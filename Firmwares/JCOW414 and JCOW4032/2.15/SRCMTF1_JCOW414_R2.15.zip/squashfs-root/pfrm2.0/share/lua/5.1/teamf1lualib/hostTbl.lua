-- hostTbl.lua : 

-- Copyright (c) 2011, TeamF1, Inc

require "ifStaticLib"

hostTbl = {}
hosts = {}

function hostTbl.config (inputTable, rowid, operation)
    -- validate
    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
            return db.insert("hostTbl", inputTable)
        elseif (operation == "edit") then
            return db.update("hostTbl", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("hostTbl",inputTable)
        end
    end
    return false
end

function hosts.config ()
    --require
    require "teamf1lualib/ifDev"
    local valid = false
    local ret
    local errCode
    local file = ""
    local zoneType = ifDev.ifZone.IFDEV_ZONE_TYPE_UNKNOWN
    
    local ifStaticConf = db.getTable("ifStatic", false)

    local hostName =  ifStaticLib.systemNameGet()
    if (hostName == nil) then
        return "ERROR", "HOSTNAME_GET_FAILED"
    end
    
    local hostTblConf = db.getTable("hostTbl",false)

    file = io.open("/var/hosts","w")
    if (file ~= nil) then
        if (ifStaticConf ~= nil) then
            for k,v in ipairs (ifStaticConf) do
                zoneType = ifDev.zoneGet(v["LogicalIfName"])
                if ((zoneType == ifDev.ifZone.IFDEV_ZONE_TYPE_SECURE) or
                    (zoneType == ifDev.ifZone.IFDEV_ZONE_TYPE_PUBLIC)) then
                    file:write(v["StaticIp"] .. " " ..  hostName .. "\n")
                end
            end
        end
        if (hostTblConf ~= nil) then
            for kk,vv in ipairs (hostTblConf) do
                file:write(vv["IpAddr"] .. " " ..  vv["Cname"] .. "\n")
            end
        end
        io.close(file)
    end

    ret, errCode = ifStaticLib.dnsMaskSighupSend()
    if (ret < 0) then
        return "ERROR", "HOSTS_NAME_CONFIG_FAILED"
    end

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name hostTbl.hostsDelete
--
-- @description 
--
-- @return 
--
function hostTbl.hostsDelete (inputTable)
    local query = nil
    local valid = false
    local ret
    local errCode
    local stat
    local errMsg

    if (inputTable == nil) then
        return "ERROR", "INVALID_CONF"
    end

    db.beginTransaction() --begin transaction

    inputTable = util.addPrefix(inputTable, "hostTbl.")
    valid = hostTbl.config(inputTable, inputTable._ROWID_, "delete")
    
    if (valid) then
        stat, errMsg = hosts.config()
        if (stat == "OK") then
            db.commitTransaction(true)
            return "OK", "STATUS_OK"
        end
    end
    
    db.rollback()
    return "ERROR", "HOST_DELETE_FAILED"

end

-------------------------------------------------------------------------
-- @name hostTbl.hostsGet
--
-- @description 
--
-- @return 
--
function hostTbl.hostsGet()
    return db.getTable("hostTbl",false)
end

-------------------------------------------------------------------------
-- @name hostTbl.hostsAddSet
--
-- @description 
--
-- @return 
--
function hostTbl.hostsAddSet(inputTable)
    require "teamf1lualib/ifDev"

    local query = nil
    local valid = false
    local ret
    local errCode
    local stat
    local errMsg

    if (inputTable == nil) then
        return "ERROR", "INVALID_CONF"
    end

    -- check ipaddr in lan subnet 
    if (ifDev.validateAddrInNetwork(inputTable["IpAddr"], "IF2") ~= 1) then
        errMsg = "ERROR"
        statusMsg = "IPADDR_NOT_IN_LAN_SUBNET"
        return errMsg, statusMsg
	end

    -- check host name 
    if (string.find(inputTable["Cname"], '[^%w.-]')) then
        errMsg = "ERROR"
        statusMsg = "INVALID_HOSTNAME"
        return errMsg, statusMsg
    end

    query = "IpAddr = '" .. inputTable.IpAddr .. "'"
	local row = db.getRowWhere("hostTbl", query, false)
	if (row ~= nil) then
		return "ERROR","HOST_WITH_SAME_IP_ALREADY_EXIST"
	end

    db.beginTransaction() --begin transaction

    inputTable = util.addPrefix(inputTable, "hostTbl.")
    valid = hostTbl.config(inputTable, "-1", "add")
    
    if (valid) then
        stat, errMsg = hosts.config()
        if (stat == "OK") then
            db.commitTransaction(true)
            return "OK", "STATUS_OK"
        end
    end
    
    db.rollback()
    return "ERROR", "HOST_ADD_FAILED"
end

-------------------------------------------------------------------------
-- @name hostTbl.hostsEditSet
--
-- @description 
--
-- @return 
--
function hostTbl.hostsEditSet(inputTable)
    require "teamf1lualib/ifDev"

    local query = nil
    local query1 = nil
    local valid = false
    local ipAddrChanged = false
    local row = {}
    local row1 = {}
    local ret
    local errCode
    local stat
    local errMsg

    if (inputTable == nil) then
        return "ERROR", "INVALID_CONF"
    end

    -- check ipaddr in lan subnet 
    if (ifDev.validateAddrInNetwork(inputTable["IpAddr"], "IF2") ~= 1) then
        errMsg = "ERROR"
        statusMsg = "IPADDR_NOT_IN_LAN_SUBNET"
        return errMsg, statusMsg
	end

    -- check host name 
    if (string.find(inputTable["Cname"], '[^%w.-]')) then
        errMsg = "ERROR"
        statusMsg = "INVALID_HOSTNAME"
        return errMsg, statusMsg
    end

    local rowid = inputTable._ROWID_

    query = "_ROWID_= '" .. rowid .. "'"
    row = db.getRowWhere("hostTbl", query, false)
	if (row ~= nil) then
        if (row["IpAddr"] ~= inputTable["IpAddr"]) then
            ipAddrChanged = true
        end
    end

    if (ipAddrChanged) then
        query1 = "IpAddr = '" .. inputTable.IpAddr .. "'"
        row1 = db.getRowWhere("hostTbl", query1, false)
        if (row1 ~= nil) then
            return "ERROR","HOST_WITH_SAME_IP_ALREADY_EXIST"
        end
	end

    db.beginTransaction() --begin transaction

    inputTable = util.addPrefix(inputTable, "hostTbl.")
    valid = hostTbl.config(inputTable, rowid, "edit")
    
    if (valid) then
        stat, errMsg = hosts.config()
        if (stat == "OK") then
            db.commitTransaction(true)
            return "OK", "STATUS_OK"
        end
    end
    
    db.rollback()
    return "ERROR", "HOST_EDIT_FAILED"
end

-------------------------------------------------------------------------
-- @name hostTbl.hostsEditGet
--
-- @description 
--
-- @return 
--
function hostTbl.hostsEditGet(rowId)
    local configTbl = {}
    configTbl = db.getRow ("hostTbl", "_ROWID_", rowId)
    return configTbl
end

function hostTbl.import (configTable)
    if (configTable ~= nil) then
        for i,v in ipairs (configTable) do
            v = util.addPrefix (v, "hostTbl.");
            hostTbl.config (v, -1, "add")
        end
    end
end

function hostTbl.export ()
    return db.getTable ("hostTbl", false)
end

if (config.register) then
   config.register("hostTbl", hostTbl.import, hostTbl.export, "1")
end
