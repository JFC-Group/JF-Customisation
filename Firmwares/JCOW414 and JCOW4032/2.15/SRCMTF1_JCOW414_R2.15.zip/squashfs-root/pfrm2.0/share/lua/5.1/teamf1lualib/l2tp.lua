--[[
#### Ashutosh Gautam.
#### TeamF1
#### www.TeamF1.com
#### Mar 13, 2013
#### File: l2tp.lua
#### Description: L2TP Setup functions
#### Revisions:
01a, 08oct13, ash changes for password encryption/descryption
]]--

--************* Requires *************
require "passwdSecureLib"

--************* Initial Code *************

l2tp = {}

-- PPTP config
function l2tp.config (inputTable, rowid, operation)
    -- validate
    if (operation == "add") then
        return db.insert("L2tp", inputTable)
    elseif (operation == "edit") then
        return db.update("L2tp", inputTable, rowid)
    elseif (operation == "delete") then
        return db.delete("L2tp", inputTable)
    end
end

function l2tp.import (inputTable, defaultCfg, remCfg)
   local status

   if (inputTable == nil) then
        inputTable = defaultCfg
    end
    
    --initializing a temp table
    local configTable = {}

    configTable = config.update (inputTable, defaultCfg, remCfg)
    if (configTable ~= nil and #configTable ~= 0)then
        for i,v in ipairs (configTable) do
            if (v["Password"] ~= nil and v["Password"] ~= "") then
                status, v["Password"] = passwdSecureLib.decryptData (v["Password"], "")
            end
            v = util.addPrefix (v, "L2tp.")
            db.insert ("L2tp", v)
        end
    end
end

function l2tp.export ()
    local status
    local l2tpconf = db.getTable ("L2tp", false)
    for i, v in ipairs (l2tpconf) do
        if (v["Password"] ~= nil and v["Password"] ~= "") then
            status, l2tpconf[i].Password = passwdSecureLib.encryptData (v["Password"], "")
        end
        if (v["Secret"] ~= nil and v["Secret"] ~= "") then
            status, l2tpconf[i].Secret = passwdSecureLib.encryptData (v["Secret"], "")
        end
    end
    return l2tpconf
end

if (config.register) then
   config.register("l2tp", l2tp.import, l2tp.export, "1")
end
