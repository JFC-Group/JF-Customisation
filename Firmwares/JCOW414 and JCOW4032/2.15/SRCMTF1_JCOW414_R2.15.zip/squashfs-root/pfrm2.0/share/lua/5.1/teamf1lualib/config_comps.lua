--
-- System components
--
require "teamf1lualib/logging"
require "teamf1lualib/evtDsptch"
require "teamf1lualib/platform"
require "teamf1lualib/tr69Mgmt"
require "teamf1lualib/userdb"

require "teamf1lualib/swMgr"
--
-- Components that create L2 interfaces
--
require "teamf1lualib/ethernet"
require "teamf1lualib/bridgeLib"
--require "teamf1lualib/dot11"
require "teamf1lualib/ifDev"
require "teamf1lualib/ipConf"

--
-- Components that create L3 connections
--
require "teamf1lualib/ifStatic"
require "teamf1lualib/dhcpc"
require "teamf1lualib/dhcpv6"
require "teamf1lualib/pppoe"
require "teamf1lualib/gpon"
require "teamf1lualib/nimf"
require "teamf1lualib/firewall"
require "teamf1lualib/iproute"

require "teamf1lualib/radvd"
require "teamf1lualib/ndppd"

--
-- Applications
--
require "teamf1lualib/time"
--require "teamf1lualib/firmware"
require "teamf1lualib/upnp"
--require "teamf1lualib/sshd"
require "teamf1lualib/rip"
require "teamf1lualib/ripng"
--require "teamf1lualib/ddns"
require "teamf1lualib/httpsMgmt"
require "teamf1lualib/sip"
--require "teamf1lualib/net-snmp"
require "teamf1lualib/igmp"
--require "teamf1lualib/pptp"
require "teamf1lualib/dhcpRelay"
require "teamf1lualib/dhcpv6Relay"
--require "teamf1lualib/bonjour"
--require "teamf1lualib/voip"
require "teamf1lualib/qos"

require "teamf1lualib/radius"
--require "teamf1lualib/smb"
--require "teamf1lualib/mediaServerMgmt"
require "teamf1lualib/6to4"
require "teamf1lualib/isatap"
require "teamf1lualib/hostTbl"
require "teamf1lualib/tcpdump"
--require "teamf1lualib/osgi"
require "teamf1lualib/smb"
require "teamf1lualib/mediaServerMgmt"
require "teamf1lualib/mldproxy"
require "teamf1lualib/maptConfig"
require "teamf1lualib/captivePortal"
--require "teamf1lualib/crontab"
require "teamf1lualib/vsftpd"
--require "teamf1lualib/pkgMgmt"
--require "teamf1lualib/ieee1905"
require "teamf1lualib/easyMeshMgmt"
