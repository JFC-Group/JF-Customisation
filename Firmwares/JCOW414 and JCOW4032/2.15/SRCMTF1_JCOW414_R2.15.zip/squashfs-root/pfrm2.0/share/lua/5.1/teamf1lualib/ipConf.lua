-- ipConf.lua : 

-- Copyright (c) 2013, TeamF1, Inc

ipConf = {}

function ipConf.config (inputTable, rowid, operation)
    -- validate
    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
            return db.insert("ipConf", inputTable)
        elseif (operation == "edit") then
            return db.update("ipConf", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("ipConf",inputTable)
        end
    end
    return false
end

-------------------------------------------------------------------------------
-- @name : ipConf.get()
--
-- @description : API to return ipConf table
--
-- @return : Entire ipConf table
-- 
function ipConf.get()
    --local 
    local ipConfTbl = {}
    
    ipConfTbl = db.getRow ("ipConf", "_ROWID_", "1")   

    ipConfTbl = util.removePrefix(ipConfTbl, "ipConf.")
    --return
    return ipConfTbl
end

-------------------------------------------------------------------------------
-- @name : ipConf.set()
--
-- @description : API to set values in ipConf table
--
-- @return : status, error code
-- 
function ipConf.set(ipConfTbl)

    -- add table prefix
    ipConfTbl = util.addPrefix(ipConfTbl, "ipConf.")

    statusFlag = ipConf.config (ipConfTbl, "1", "edit")

    -- check status
    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "IPCONF_FAILED"
    end    
end

function ipConf.import (configTable)
    if (configTable ~= nil) then
        for i,v in ipairs (configTable) do
            v = util.addPrefix (v, "ipConf.");
            ipConf.config (v, -1, "add")
        end
    end
end

function ipConf.export ()
    return db.getTable ("ipConf", false)
end

if (config.register) then
   config.register("ipConf", ipConf.import, ipConf.export, "1")
end

