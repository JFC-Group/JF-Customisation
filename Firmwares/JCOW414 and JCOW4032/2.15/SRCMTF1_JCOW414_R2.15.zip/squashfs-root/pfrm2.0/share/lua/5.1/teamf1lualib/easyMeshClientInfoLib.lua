--[[ easyMeshClientInfoLib.lua - Gets easyMesh topology clients information.
--
-- Copyright (c) 2008-2019, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: easyMeshClientInfoLib.lua
-- Description: Gets easyMesh topology clients information.
-- 
-- modification history
-- --------------------
-- 01a, 10Jan2020, ar written.
--
--]]

require "teamf1lualib/util"
require "teamf1lualib/easyMeshDebug"
require "teamf1lualib/easyMeshResponses"

--[[
--------------------------------------------------------------------------------------------------------------------------------------
-- Sample Client Information from easyMesh framework.
--------------------------------------------------------------------------------------------------------------------------------------
#> mapd_cli /tmp/mapd_ctrl mib sta 0
count =5 1=mapd_cli 2=/tmp/mapd_ctrl
Succesfully opened connection to mapd
STA ENTRY IN DB:
Client_id=0     MAC=9c:6b:72:19:32:f9   BSSID=f2:ac:d7:72:67:8b
Steer State=1   Steer method =11
num_11k=0       num_11k_succ=0
Local Steer Stats
        MANDATE                  : BTM(Attempts/Succ/Fail) = 0/0/0 Foced(Attempts/Succ/fail) = 0/0/0
        ACTIVE_STANDALONE_DG     : BTM(Attempts/Succ/Fail) = 0/0/0 Foced(Attempts/Succ/fail) = 0/0/0
        IDLE_STANDALONE_DG       : BTM(Attempts/Succ/Fail) = 0/0/0 Foced(Attempts/Succ/fail) = 0/0/0
        NOL_MULTIAP              : BTM(Attempts/Succ/Fail) = 0/0/0 Foced(Attempts/Succ/fail) = 0/0/0
        OL_MULTIAP               : BTM(Attempts/Succ/Fail) = 0/0/0 Foced(Attempts/Succ/fail) = 0/0/0
        ACTIVE_STANDALONE_UG     : BTM(Attempts/Succ/Fail) = 0/0/0 Foced(Attempts/Succ/fail) = 0/0/0
        IDLE_STANDALONE_UG       : BTM(Attempts/Succ/Fail) = 0/0/0 Foced(Attempts/Succ/fail) = 0/0/0
        ACTIVE_5GL_TO_5GH        : BTM(Attempts/Succ/Fail) = 0/0/0 Foced(Attempts/Succ/fail) = 0/0/0
        ACTIVE_5GH_TO_5GL        : BTM(Attempts/Succ/Fail) = 0/0/0 Foced(Attempts/Succ/fail) = 0/0/0
        IDLE_5GL_TO_5GH          : BTM(Attempts/Succ/Fail) = 0/0/0 Foced(Attempts/Succ/fail) = 0/0/0
        IDLE_5GH_TO_5GL          : BTM(Attempts/Succ/Fail) = 0/0/0 Foced(Attempts/Succ/fail) = 0/0/0
        NONE                     : BTM(Attempts/Succ/Fail) = 0/0/0 Foced(Attempts/Succ/fail) = 0/0/0
Remote Steer Stats BTM(Succ/Fail) = 0/0 Foced(Succ/fail) = 0/0
PHY CAPS: sp=1 2G:PhyMode/BW=VHT/20Mhz 5G:PhyMode/BW=VHT/80Mhz
Known channels list
Channel=6 RSSI=-64(non-serving)
Channel=36 RSSI=-72(current)
Current chan = 36       Activity state = IDLE   RRM/BTM/MBO = YES/YES/NO
dl_rate=0       ul_rate=0       tx_count=0      rx_count=0      auth_rej_count=0        auth_rej_max=5  CurrAirTime(calculated)=0
PhyRate=87

--------------------------------------------------------------------------------------------------------------------------------------
-- Corresponding parsed Smaple Lua Table
--------------------------------------------------------------------------------------------------------------------------------------
{
  tx_count= "0",
  rx_count= "0",
  num_11k_succ= "0",
  RRM= "YES",
  auth_rej_count= "0",
  Remote_Steer_Stats=     {
      ForcedSteeringStats=         {
          Success= "0",
          Failures= "0",
        },
      BTMSteeringStats=         {
          Success= "0",
          Failures= "0",
        },
    },
  Activitystate= "IDLE",
  clientPhyRate= "780",
  phyCapabilities=     {
      spatialStreams= "2",
      24g_phyMode_BW= "VHT/20Mhz",
      5g_phyMode_BW= "VHT/160Mhz",
    },
  Steer_State= "1",
  Currentchan= "44",
  channelList=     {
      [1] =         {
          RSSI= "-50(non-serving)",
          Channel= "12",
        },
      [2] =         {
          RSSI= "-58(current)",
          Channel= "44",
        },
    },
  dl_rate= "0",
  ul_rate= "0",
  MAC= "20:a6:0c:36:39:c5",
  BTM= "YES",
  MBO= "NO",
  auth_rej_max= "5",
  num_11k= "0",
  Local_Steer_Stats=     {
        ACTIVE_STANDALONE_UG=         {
          ForcedSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
          BTMSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
        },
        ACTIVE_5GL_TO_5GH=         {
          ForcedSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
          BTMSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
        },
        MANDATE=         {
          ForcedSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
          BTMSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
        },
        IDLE_STANDALONE_DG=         {
          ForcedSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
          BTMSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
        },
        ACTIVE_STANDALONE_DG=         {
          ForcedSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
          BTMSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
        },
        IDLE_5GL_TO_5GH=         {
          ForcedSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
          BTMSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
        },
        NONE=         {
          ForcedSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
          BTMSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
        },
        IDLE_STANDALONE_UG=         {
          ForcedSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
          BTMSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
        },
        IDLE_5GH_TO_5GL=         {
          ForcedSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
          BTMSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
        },
        ACTIVE_5GH_TO_5GL=         {
          ForcedSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
          BTMSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
        },
        NOL_MULTIAP=         {
          ForcedSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
          BTMSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
        },
        OL_MULTIAP=         {
          ForcedSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
          BTMSteeringStats=             {
              Failures= "0",
              Success= "0",
              Attempts= "0",
            },
        },
    },
  BSSID= "a8:3f:a1:59:6a:45",
  CurrAirTime(calculated)= "0",
  Steer_method_= "11",
  Client_id= "0 ",
}

--------------------------------------------------------------------------------------------------------------------------------------
]]--

CLIENT_LIST_CMD = "/userfs/bin/mapd_cli /tmp/mapd_ctrl mib sta_seen_list"
MAPD_MIB_CMD="/userfs/bin/mapd_cli /tmp/mapd_ctrl mib"
MAPD_STA_CMD="/userfs/bin/mapd_cli /tmp/mapd_ctrl mib sta "
MAC_STR_TOKEN="MAC"
MIB_OUTPUT_FILE="/tmp/mapd_mib_output.txt"
STA_OUTPUT_FILE="/tmp/mapd_sta_output.txt"

CLIENT_ID_TOKEN="Client_id"
CLIENT_MAC_TOKEN="MAC"
PARENT_MAC_TOKEN="BSSID"
STA_STEER_STATE_TOKEN="Steer State"
STA_STATE_TOKEN="State"
STA_STEER_METHOD_TOKEN="Steer method"
STA_METHOD_TOKEN="="
STA_STEERING_COUNT="num_11k"
STA_STEERING_SUCCESS_COUNT="num_11k_succ"
REMOTE_STEER_STATS_STR="Remote Steer Stats"
STA_CURRENT_CHANNEL="Current chan"
STA_ACTIVITY_STR="Activity state"
STA_CAPABILITIES_STR="RRM/BTM/MBO"
MISC_INFO_STR="dl_rate"
STA_PHYRATE_STR="PhyRate"
STA_PHYCAPS_STR="PHY CAPS"


function getClientBasicInfo(filename)

    local basicInfo = {}
    local cmd= "grep " .. "'" .. CLIENT_ID_TOKEN .. "' " .. filename
    local pipe = io.popen(cmd .. " 2>&1") -- redirect stderr to stdout
    local cmdOutput = pipe:read("*a")
    pipe:close()
    if(cmdOutput == nil) then
        return basicInfo
    end

    output=string.gsub(cmdOutput, "\n", "")
    if(output == nil) then
        return basicInfo
    end
    --mesh.dprintf("output: " .. output)
    basicData = util.split(output,"\t" )
    if (basicData ~= false) then
	    for i,v in pairs (basicData) do
		    -- print(i,v)
		    basicparam = util.split(v,"=")
		    if (basicparam ~= false) then
                if ( basicparam[1] ~= nil ) then
			        basicInfo[basicparam[1]] = basicparam[2] or ""
                end
		    end
	    end
    end

    return basicInfo
end

function getClientSteerInfo(filename)

    local staSteerInfo = {}
    local cmd= "grep " .. "'" .. STA_STEER_STATE_TOKEN .. "'" .. " " .. filename
    local pipe = io.popen(cmd .. " 2>&1") -- redirect stderr to stdout
    local cmdOutput = pipe:read("*a")
    pipe:close()
    if(cmdOutput == nil) then
        return staSteerInfo
    end
    --print("Steer Info: " .. cmdOutput)
    output=string.gsub(cmdOutput, "\n", "")
    if(output == nil) then
        return staSteerInfo
    end
    steerData = util.split(output,"\t" )
    if (steerData ~= false) then
	    for i,v in pairs(steerData) do
		    --print(i,v)
		    steerparam = util.split(v,"=")
		    if (steerparam ~= false) then
                if (steerparam[1] ~= nil) then 
			        local field=string.gsub(steerparam[1], " ", "_")
			        staSteerInfo[field] = steerparam[2] or ""
                end
		    end
	    end
    end

    return staSteerInfo
end

function getClientSteerCountInfo(filename)

    local staSteerCount = {}
    local cmd= "grep " .. "'" .. STA_STEERING_COUNT .. "' " .. filename
    local pipe = io.popen(cmd .. " 2>&1") -- redirect stderr to stdout
    local cmdOutput = pipe:read("*a")
    pipe:close()
    if(cmdOutput == nil) then
        return staSteerCount
    end
    --print("SteerCount Info: " .. cmdOutput)
    output=string.gsub(cmdOutput, "\n", "")
    if(output == nil) then
        return staSteerCount
    end
    steerData = util.split(output,"\t" )
    if (steerData ~= false) then
	    for i,v in pairs(steerData) do
		    --print(i,v)
		    steerparam = util.split(v,"=")
		    if (steerparam ~= false) then
                if (steerparam[1] ~= nil) then 
			        staSteerCount[steerparam[1]] = steerparam[2] or ""
		        end
		    end
	    end
    end

    return staSteerCount
end


function getClientLocalSteerStats(filename)

	local Local_Steer_Stats = {}
	local cmd
	    cmd= "grep " .. "Attempts " .. filename
	    local pipe = io.popen(cmd .. " 2>&1") -- redirect stderr to stdout
	    local cmdOutput = pipe:read("*a")
	    pipe:close()
        if(cmdOutput == nil) then
            return Local_Steer_Stats
        end
    	    --print(cmdOutput)

	    output=string.gsub(cmdOutput, "\n$", "")
        if(output == nil) then
            return Local_Steer_Stats 
        end
	    steerData = util.split(output,"\n" )
	    if (steerData ~= false) then
		    for i,v in pairs (steerData) do
			    --print(i, v)
	                steerStats = util.split(v,":")
	    		if (steerStats ~= false) then
					--print(steerStats[1],steerStats[2])
                    if((steerStats[1] ~= nil) and (steerType ~= nil) and (steerStats[2] ~= nil)) then                        
				        steerType = string.gsub(steerStats[1]," ", "")         -- remove extra spaces in the string
				        steerType = string.gsub(steerType,"\t", "")         -- remove extra spaces in the string
				        statsString = string.gsub(steerStats[2],"^%s*", "")    -- remove leading space from the string
					
                        --print(steerType,statsString)
				        Local_Steer_Stats[steerType] = {}
    					--print(tprint(Local_Steer_Stats))
	                    statsToken = util.split(statsString," ")
	        			if (statsToken ~= false) then
			        	        --print(i, v)
                            if((statsToken[3] ~= nil) and (statsToken[6] ~= nil)) then
				                BTMStatsStr = string.gsub(statsToken[3], " ", "")
				                ForcedStatsStr = string.gsub(statsToken[6], " ", "")
	    			    	    
                                --print(BTMstats, ForcedStats)
                                if (BTMStatsStr ~= nil) then
		    			            BTMstats = util.split(BTMStatsStr, "/")
    			    		        if (BTMStats ~= false) then
                                        Local_Steer_Stats[steerType]["BTMSteeringStats"] = {}
                                        local BTMSteeringStats = Local_Steer_Stats[steerType]["BTMSteeringStats"]
                                        BTMSteeringStats["Attempts"] = BTMstats[1] or ""
                                        BTMSteeringStats["Success"] = BTMstats[2] or ""
                                        BTMSteeringStats["Failures"] = BTMstats[3] or ""
				                    end
                                end

                                if (ForcedStatsStr ~= nil) then
        					        Forcedstats = util.split(ForcedStatsStr, "/")
	        				        if (Forcedstats ~= false) then
                                        local ForcedSteeringStats = {}
			        		            Local_Steer_Stats[steerType]["ForcedSteeringStats"] = {}
                                        ForcedSteeringStats = Local_Steer_Stats[steerType]["ForcedSteeringStats"]
                                        ForcedSteeringStats["Attempts"] = Forcedstats[1] or ""
                                        ForcedSteeringStats["Success"] = Forcedstats[2] or ""
                                        ForcedSteeringStats["Failures"] = Forcedstats[3] or ""
    	    			            end
                                end
                            end
                        end
                    end
                end
		    end
	    end

	return Local_Steer_Stats
end

function getClientRemoteSteerStats(filename)

    local Remote_Steer_Stats = {}
    local cmd
    cmd= "grep " .. "'" .. REMOTE_STEER_STATS_STR .. "' " .. filename
    local pipe = io.popen(cmd .. " 2>&1") -- redirect stderr to stdout
    local cmdOutput = pipe:read("*a")
    pipe:close()
    if(cmdOutput == nil) then
        return Remote_Steer_Stats
    end
    --print("remote Steer Stats String: " .. cmdOutput)
    output=string.gsub(cmdOutput, "\n", "")
    if(output == nil) then
        return Remote_Steer_Stats
    end
    rmtSteerStr = util.split(output," " )
    if (rmtSteerStr ~= false) then
        if (rmtSteerStr[6] ~= nil) then
	        rmtBTMStats = util.split(rmtSteerStr[6], "/")
            if (rmtBTMStats ~= false) then
	            local BTMStats = {}
                BTMStats["Success"] = rmtBTMStats[1] or ""
                BTMStats["Failures"] = rmtBTMStats[2] or ""
                Remote_Steer_Stats["BTMSteeringStats"] = BTMStats
	        end
        end
	    
        if (rmtSteerStr[9] ~= nil) then
	        rmtForcedStats = util.split(rmtSteerStr[9], "/")
            if (rmtForcedStats ~= false) then
	            local ForcedStats = {}
                ForcedStats["Success"] = rmtForcedStats[1] or ""
                ForcedStats["Failures"] = rmtForcedStats[2] or ""
                Remote_Steer_Stats["ForcedSteeringStats"] = ForcedStats
	        end
	    end
    end

    return Remote_Steer_Stats
end

function getClientBasicInfo2(filename)
    local miscData = nil
    local retTable = {}
    local cmd= "grep " .. "'" .. STA_CURRENT_CHANNEL .. "' " .. filename
    local pipe = io.popen(cmd .. " 2>&1") -- redirect stderr to stdout
    local cmdOutput = pipe:read("*a")
    pipe:close()
    if(cmdOutput == nil) then
        return retTable
    end
    --print("current channel string: " .. cmdOutput)
    output=string.gsub(cmdOutput, "\n", "")
    if(output == nil) then
        return retTable
    end
    miscData = util.split(output,"\t")
	if (miscData ~= false) then
		for i,v in pairs(miscData) do
            v =string.gsub(v, " ", "")
			--print(i,v)
    		miscInfo = util.split(v,"=")
			if (miscInfo ~= false) then
				--print(miscInfo[1],miscInfo[2])
				if(((miscInfo[1] ~= nil) and (miscInfo[2] ~= nil)) and (miscInfo[1] == "RRM/BTM/MBO")) then
					local field = util.split(miscInfo[1],"/")
					local value = util.split(miscInfo[2],"/")
					if(field ~= false and value ~=false) then
						retTable[field[1]] = value[1] or ""
						retTable[field[2]] = value[2] or ""
						retTable[field[3]] = value[3] or ""
					end
				else
					retTable[miscInfo[1]] = miscInfo[2] or ""
				end
			end
		end
	end
	return retTable
end

function getClientMiscInfo(filename)
	
    local miscData = nil
    local retVal = {}
    local cmd= "grep " .. "'" .. MISC_INFO_STR .. "' " .. filename
    local pipe = io.popen(cmd .. " 2>&1") -- redirect stderr to stdout
    local cmdOutput = pipe:read("*a")
    pipe:close()
    if(cmdOutput == nil) then
        return retVal
    end
    --print("Misc Info string: " .. cmdOutput)
    output=string.gsub(cmdOutput, "\n", "")
    if(output == nil) then
        return retVal
    end
    miscData = util.split(output,"\t")
    if (miscData ~= false) then
	    for i,v in pairs(miscData) do
	        local miscInfo = util.split(v,"=")
		    if (miscInfo ~= false) then
                if (miscInfo[1] ~= nil) then
			        retVal[miscInfo[1]] = miscInfo[2] or ""
                end
		    end
	    end
    end
    return retVal
end

function getClientPhyRate(filename)

    local PhyRate = ""
    local cmd= "grep " .. "'" .. STA_PHYRATE_STR .. "' " .. filename
    local pipe = io.popen(cmd .. " 2>&1") -- redirect stderr to stdout
    local cmdOutput = pipe:read("*a")
    pipe:close()
    if(cmdOutput == nil) then
        return PhyRate
    end
    --print("PhyRate string: " .. cmdOutput)
    output=string.gsub(cmdOutput, "\n", "")
    if(output == nil) then
        return PhyRate
    end
    PhyRateStr = util.split(output,"=")
    if (PhyRateStr ~= false) then
	    PhyRate = PhyRateStr[2] or ""
    end
    return PhyRate
end

function getClientChannelList(filename)

	local ChannleList = {}
	local cmd
	    cmd= "grep " .. "Channel " .. filename
	    local pipe = io.popen(cmd .. " 2>&1") -- redirect stderr to stdout
	    local cmdOutput = pipe:read("*a")
	    pipe:close()
        if(cmdOutput == nil) then
            return ChannleList
        end
    	    --print(cmdOutput)

	    output=string.gsub(cmdOutput, "\n$", "")
        if(output == nil) then
            return ChannleList
        end
	    ChannelData = util.split(output,"\n" )
	    if (ChannelData ~= false) then
		    for i,v in pairs (ChannelData) do
			    --print(i, v)
	            ChanInfo = util.split(v," ")
	    		if (ChanInfo ~= false) then
				    local chanTbl = {}
					-- print(ChanInfo[1],ChanInfo[2])
                    if (ChanInfo[1] ~= nil) then
				        chanVal = util.split(ChanInfo[1],"=")
				        if (chanVal ~= false) then
						    -- print(chanVal[1],chanVal[2])
				            chanTbl["Channel"] = chanVal[2] or ""
			            end
                    else
				        chanTbl["Channel"] = ""
                    end
                    
                    if (ChanInfo[2] ~= nil) then
				        rssiVal = util.split(ChanInfo[2],"=")
				        if (rssiVal ~= false) then
				            chanTbl["RSSI"] = rssiVal[2] or ""
				        end
                    else
				        chanTbl["RSSI"] = ""
				    end
                    table.insert(ChannleList, chanTbl)
                end
		    end
	    end
	return ChannleList
end

function getClientPhyCapabilities(filename)

	local phyCapabilities = {}
	local cmd
	    cmd= "grep " .. "'" .. STA_PHYCAPS_STR .. "' ".. filename
	    local pipe = io.popen(cmd .. " 2>&1") -- redirect stderr to stdout
	    local cmdOutput = pipe:read("*a")
	    pipe:close()
        if(cmdOutput == nil) then
            return phyCapabilities
        end
    	    --print(cmdOutput)
	    
	    output=string.gsub(cmdOutput, "\n$", "")
        if(output == nil) then
            return phyCapabilities
        end
	    phyData = util.split(output," ")
	    if (phyData ~= false) then
		    if(phyData[3] ~=nil) then
			    -- print(phyData[3])
			    spatialData = util.split(phyData[3],"=")
		    	if(spatialData ~= false) then
				    phyCapabilities["spatialStreams"] = spatialData[2] or ""
			    end
            else
                phyCapabilities["spatialStreams"] = ""
		    end
		    if(phyData[4] ~=nil) then
			    --print(phyData[4])
			    PhyData24g = util.split(phyData[4],"=")
		    	if(PhyData24g ~= false) then
				    phyCapabilities["24g_phyMode_BW"] = PhyData24g[2] or ""
			    end
            else
                phyCapabilities["24g_phyMode_BW"] = ""
		    end
		    if(phyData[5] ~=nil) then
			    --print(phyData[5])
			    PhyData5g = util.split(phyData[5],"=")
		    	if(PhyData5g ~= false) then
				    phyCapabilities["5g_phyMode_BW"] = PhyData5g[2] or ""
			    end
            else
                phyCapabilities["5g_phyMode_BW"] = ""
		    end
        else
            phyCapabilities["spatialStreams"] = ""
            phyCapabilities["24g_phyMode_BW"] = ""
            phyCapabilities["5g_phyMode_BW"] = ""
	    end

	    return phyCapabilities
end

function getClientIdFromTopology(macAddr, command)

    local clientID = nil
    local cmd = command .. " |grep '" .. string.lower(macAddr) .. "' |awk '{print($4)}'"

	local pipe = io.popen(cmd .. " 2>&1") -- redirect stderr to stdout
	local cmdOutput = pipe:read("*a")
	pipe:close()
    if(cmdOutput == nil) then
        return clientID
    end
	--mesh.dprintf("Client ID: " .. cmdOutput)

	clientID=tonumber(cmdOutput)
	if (type(clientID) ~= "number") then
		--mesh.dprintf("returning")
		return nil
	end

    return clientID
end

function getClientInfo (macAddr)

	require "teamf1lualib/ifDev"

    local client_info = {}
    local clientID = nil
    local MAPD_STA_CMD="/userfs/bin/mapd_cli /tmp/mapd_ctrl mib sta "

	if ((macAddr == nil) or (ifDev.macValidate(macAddr) ~= "OK")) then
		return "ERROR"
	end

	if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then
		client_info ["MAC"] =  macAddr
		return client_info
	end		

    clientID = getClientIdFromTopology(macAddr, MAPD_MIB_CMD)
    if (clientID == nil) then
		clientID = getClientIdFromTopology(macAddr, CLIENT_LIST_CMD)
        if (clientID == nil) then
            return "ERROR"
        end
    end

	util.runShellCmd ((MAPD_STA_CMD .. clientID),STA_OUTPUT_FILE)

	clientBasicInfo = getClientBasicInfo(STA_OUTPUT_FILE)
	if (clientBasicInfo ~= nil) then
		for i,v in pairs (clientBasicInfo) do
			client_info[i] = v
		end
	end
--[[	
    clientSteerInfo = getClientSteerInfo(STA_OUTPUT_FILE)
	if (clientSteerInfo ~= nil) then
		for i,v in pairs (clientSteerInfo) do
			client_info[i] = v
		end
	end
	clientSteerCountInfo = getClientSteerCountInfo(STA_OUTPUT_FILE)
	if (clientSteerCountInfo ~= nil) then
		for i,v in pairs (clientSteerCountInfo) do
			client_info[i] = v
		end
	end
    client_info["Local_Steer_Stats"] = {}
	client_info["Local_Steer_Stats"] = getClientLocalSteerStats(STA_OUTPUT_FILE)
	client_info["Remote_Steer_Stats"] = {}
	client_info["Remote_Steer_Stats"] = getClientRemoteSteerStats(STA_OUTPUT_FILE)

]]--
	clientBasicInfo2 = getClientBasicInfo2(STA_OUTPUT_FILE)
	if (clientBasicInfo2 ~= nil) then
		for i,v in pairs (clientBasicInfo2) do
			client_info[i] = v
		end
	end
	miscInfoTbl = getClientMiscInfo(STA_OUTPUT_FILE)
	for i,v in pairs(miscInfoTbl) do
		client_info[i] = v
	end
    --[[
	client_info["clientPhyRate"] = getClientPhyRate(STA_OUTPUT_FILE)
	client_info["channelList"] = getClientChannelList(STA_OUTPUT_FILE)
	client_info["phyCapabilities"] = getClientPhyCapabilities(STA_OUTPUT_FILE)
    ]]--

	--mesh.dprintf(tprint(client_info))
    return client_info

end
