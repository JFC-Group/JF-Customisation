--[[
#### Hussain Vali.
#### TeamF1
#### www.TeamF1.com
#### Mar 14, 2008
#### File: dhcpc.lua
#### Description: DHCP Client Settings functions
#### Revisions:
01d,25Oct17,sjr changes for Single AP.
01c,11Nov16,MSV  removed import, export support for dhcpv6sLANAddrPool table.
01b,12feb10,pnm  added dhcp server routines
01a,02feb10,pnm  added import/export routines
]]--

--************* Requires *************

--************* Initial Code *************

require "teamf1lualib/dhcp"
require "teamf1lualib/util"
--package DHCP Client Configurations
dhcpc = {}

local USE_DNS_PROXY = "1"

--************* Functions *************
-- dhcp client config
function dhcpc.config (tableName, inputTable, rowid, operation)
    -- validate
    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
            return db.insert(tableName, inputTable)
        elseif (operation == "edit") then
            return db.update(tableName, inputTable, rowid)
        elseif (operation == "delete") then
            return nil
        end
    end
end

function dhcpc.import (inputTable, defaultCfg, remCfg)
    if (inputTable == nil) then
        inputTable = defaultCfg
    end
  
    -- initializing the temp tables
    local clientTmp = {}
    local serverTmp = {}
    local fixedIpAddressTmp = {}
    local leasedClientsTmp = {}
    local optionsTmp = {}
    local clientOptionsTmp = {}
    local poolTmp = {}
    local singleApSupport = "0"
    singleApSupport = db.getAttribute ("environment", "name", "SINGLE_AP_SUPPORT" ,"value")


    -- calling the config.update function for merging the two files
    if (inputTable["client"] ~= nil) then
        clientTmp = config.update (inputTable.client, defaultCfg.client,
                                   remCfg.client)
        if (clientTmp ~= nil and #clientTmp ~= 0) then
            for i,v in ipairs (clientTmp) do           
                v = util.addPrefix (v, "Dhcpc.");
                dhcpc.config ("Dhcpc", v, -1, "add")
            end
        end
    end

    if (inputTable["server"] ~= nil) then

        -- Made changes for Default subnet modification to 43.x as per RJIL
        if(util.fileExists("/pfrm2.0/ETHERNET_ONLY") or util.fileExists("/pfrm2.0/HW_HG260ES") or
            util.fileExists("/pfrm2.0/HW_JCE410")) then
            if(util.fileExists("/flash/configMerge/ipChange") == false) then
                inputTable.server = nil
            end
        end

        serverTmp = config.update (inputTable.server, defaultCfg.server, 
                                   remCfg.server)
        if (serverTmp ~= nil and #serverTmp ~= 0) then
            for i,v in ipairs (serverTmp) do
                v = util.addPrefix (v, "DhcpServerPools.");
				if (v["DhcpServerPools.DefaultPool"] == "1") then
 					if (v["DhcpServerPools.IPRouters"] == "" or v["DhcpServerPools.IPRouters"] == nil) then
 						local query = "LogicalIfName='" .. "IF2" .. "' AND " .."AddressFamily='" .. "2" .. "'"
						local record = db.getRowWhere("ifStatic", query, false)
						if (record ~= nil) then
							v["DhcpServerPools.IPRouters"] = record["StaticIp"]
						end
 					end
					if (util.fileExists ("/pfrm2.0/BRCMJCO300")) then
						-- For all BRCM ONTs set to DNS proxy which is required for JHV
						v["DhcpServerPools.DNSServers"] = USE_DNS_PROXY
					end
 				end
                if (singleApSupport ~= nil and singleApSupport == "1") then
                    if (v["DhcpServerPools.LogicalIfName"] ~= "IF4" and v["DhcpServerPools.LogicalIfName"] ~= "IF5")then
                        status = dhcp.config (v, -1, "add")
                    end
                else
                    if (v["DhcpServerPools.LogicalIfName"] ~= "IF4" and v["DhcpServerPools.LogicalIfName"] ~= "IF5" and v["DhcpServerPools.LogicalIfName"] ~= "IF6" and v["DhcpServerPools.LogicalIfName"] ~= "IF7")then
                        status = dhcp.config (v, -1, "add")
                    end
                end
            end
        end
    end

    if (inputTable["fixedIpAddress"] ~= nil) then
        fixedIpAddressTmp = config.update (inputTable.fixedIpAddress, 
                                           defaultCfg.fixedIpAddress, 
                                           remCfg.fixedIpAddress)
        if (fixedIpAddressTmp ~= nil and #fixedIpAddressTmp ~= 0) then
            for i,v in ipairs (fixedIpAddressTmp) do
                v = util.addPrefix (v, "DhcpfixedIpAddress.");
                dhcp.fixedIpConfig (v, -1, "add")
            end
        end
    end

    if (inputTable["leasedClients"] ~= nil) then
        leasedClientsTmp = config.update (inputTable.leasedClients, 
                                          defaultCfg.leasedClients, 
                                          remCfg.leasedClients)
        if (leasedClientsTmp ~= nil and #leasedClientsTmp ~= 0) then
            for i,v in ipairs (leasedClientsTmp) do
                v = util.addPrefix (v, "DhcpLeasedClients.");
                dhcp.config (v, -1, "add")
            end
        end
    end

    if (inputTable["options"] ~= nil) then
        optionsTmp = config.update (inputTable.options, defaultCfg.options, 
                                    remCfg.options)
        if (optionsTmp ~= nil and #optionsTmp ~= 0) then 
            for i,v in ipairs (optionsTmp) do
                v = util.addPrefix (v, "DhcpOption.");
                dhcp.config (v, -1, "add")
            end
        end
    end

    if (inputTable["clientOptions"] ~= nil) then
        clientOptionsTmp = config.update (inputTable.clientOptions, 
                                          defaultCfg.clientOptions, 
                                          remCfg.clientOptions)
        if ((clientOptionsTmp ~= nil) and (#clientOptionsTmp ~= 0)) then
            for i,v in ipairs (clientOptionsTmp) do
                v = util.addPrefix (v, "DhcpcOptions.");
                dhcpc.config ("DhcpcOptions", v, -1, "add")
            end
        end
    end

    --[[ As per RJIL, Need to include Address information for DHCPv6s Stateful
    only incase if prefix obtained from IAPD request on WAN side
    if (inputTable["pool"] ~= nil) then
        poolTmp = config.update (inputTable.pool, defaultCfg.pool, remCfg.pool)
        if (poolTmp ~= nil and #poolTmp ~= 0)  then
            for i,v in ipairs (poolTmp) do
                v = util.addPrefix (v, "dhcpv6sLANAddrPool.");
                local valid = dhcpc.config ("dhcpv6sLANAddrPool", v, -1, "add")
            end
        end
    end]]--
end

function dhcpc.export ()
    local dhcp = {}
    dhcp ["client"] = db.getTable ("Dhcpc", false)
    
    local table = db.getTable ("DhcpServerPools", false)
    if (table ~= nil) then
        dhcp["server"] = table
    end
    
    local table = db.getTable ("DhcpfixedIpAddress", false)
    if (table ~= nil) then
        dhcp["fixedIpAddress"] = table
    end

    local table = db.getTable ("DhcpLeasedClients", false)
    if (table ~= nil) then
        dhcp["leasedClients"] = table
    end
    
    local table = db.getTable ("DhcpOption", false)
    if (table ~= nil) then
        dhcp["options"] = table
    end

    local table = db.getTable ("DhcpcOptions", false)
    if (table ~= nil) then
        dhcp["clientOptions"] = table
    end

    --[[local table = db.getTable ("dhcpv6sLANAddrPool", false)
    if (table ~= nil) then
        dhcp["pool"] = table
    end]]--

    return dhcp
end

if (config.register) then
   config.register("dhcp", dhcpc.import, dhcpc.export ,"1")
end
