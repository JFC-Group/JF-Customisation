multiboot = {}

local currFirmConf = "/cfg/currentfirmware.conf"
local flashBootConf = "/cfg/multiboot.conf"
local sdcardBootConf = "/mnt/sdcard/boot/multiboot.conf"
local kernel_image_prefix = "/mnt/sdcard/boot/kernel."
local fs_image_prefix = "/mnt/sdcard/boot/fs."
local cfg_prefix = "/mnt/sdcard/data/configs"
local kernel_flash_partition = "/dev/mtd4"
local flashUtil = "/bin/flashWrite "
multiboot.debug = 1
multiboot.console = 0
multiboot.firmdCompId = 101

-- check if we are on older  econa ref board
--[[
TODO: read the board u-boot env variable to determine board type
local f=io.open("/dev/mtd7")
if (f) then
	os.execute("mount -t jffs2 -onoatime,nodiratime /dev/mtdblock7 /flash_multiboot")
	local flashBootConf = "/flash_multiboot/multiboot.conf"
	io.close (f)
end
]]--

----------------------------------------------------------------------------------
-- @name multiboot.firmwareEntGet - 
--
-- @description This function gets the boot entry for the given title from
-- the boot table.
-- 
-- @return 
--
--

function multiboot.firmwareEntGet(title)

    if (title == nil) then
        title = multiboot.currentFirmwareTitleGet()
    end
    
    boottable = multiboot.firmwareTblGet()


    for k,v in pairs(boottable) do

        ent_title = multiboot.labelStrip (v.title)
        title_in = multiboot.labelStrip(title)

        if (ent_title == title_in) then
            return v
        end            
    end        

    return nil
end
    
----------------------------------------------------------------------------------
-- @name multiboot.firmwareTblGet - 
--
-- @description This function gets the boot configurations from all the attached
-- media.
-- 
-- @return 
--
--

function multiboot.firmwareTblGet()
	local resultTable = {}

    --
    -- read the boot table from flash
    --
    if (pcall (loadfile (flashBootConf))) then
        dofile (flashBootConf)
		for k,v in pairs (boottable) do
			resultTable [k] = {}
			resultTable [k] = boottable[k]		
		end
	end

	rowCount = #(resultTable)

    --
    -- read the boot table from SD card
    --
    if (pcall (loadfile (sdcardBootConf))) then
        dofile (sdcardBootConf)
		for k,v in pairs (boottable) do
			resultTable [k + rowCount] = {}
			resultTable [k + rowCount] = boottable[k]		
		end
	end

	-- TODO: add more blocks for other media types	


    return resultTable
end

----------------------------------------------------------------------------------
-- @name multiboot.firmwareChange - preapre to boot a different firmware
--
-- @description This function prepares the device to boot a different firmware
-- in the next reboot.
--
-- @return 
--

function multiboot.firmwareChange(title)

    -- change the boot command in u-boot
    multiboot.activeFirmwareSet(title)

    return "OK", "STATUS_OK"
end

----------------------------------------------------------------------------------
-- @name multiboot.activeFirmwareSet - change the active firmware
--
-- @description This function set the firmware to be used for next reboot. 
-- It updates the u-boot's boot command
-- 
-- @return 
--

function multiboot.activeFirmwareSet(title)

    local ent = multiboot.firmwareEntGet(title)
    if (ent == nil) then
        return "ERROR","MULTIBOOT_ERR_INVALID_TITLE"
    end

    -- change the u-boot command
    multiboot.changeBootcmd(ent)

    -- 
    -- update the current running configutation
    --
	if (pcall (loadfile (currFirmConf))) then
        dofile (currFirmConf)
    end

    if (currentFirmware == nil) then
        currentFirmware = {}
        currentFirmware[1] = {}
    end
            
	currentFirmware[1]["title"] = title
	multiboot.writeTableToFile (currentFirmware, currFirmConf, "currentFirmware")

    return "OK", "STATUS_OK"
end

----------------------------------------------------------------------------------
-- @name multiboot.currentFirmwareTitleGet - 
--
-- @description This function gets the title of the current running firmware
-- 
-- @return 
--
--

function multiboot.currentFirmwareTitleGet()

	if (pcall (loadfile (currFirmConf))) then
        dofile (currFirmConf)
    end

    if (currentFirmware == nil) then
        return nil
    end        
            
	local firmTitle = currentFirmware[1]["title"]

    return firmTitle 
end

----------------------------------------------------------------------------------
-- @name multiboot.addBootConf - add/get boot entry
--
-- @description This function adds or gets the existing boot configuration for
-- the given label.
-- 
-- @return bootIndex, bootmenu
--

function multiboot.addBootConf (conf)
    require "firmLib"
    local bootIndex = 1
    local bootMenuFile
    local bootmenu = {}

    if (conf == nil) then
        multiboot.dprint("addBootConf: invalid arguments")
        return -1
    end        

    if (type(conf) ~= "table") then
        multiboot.dprint("addBootConf: invalid arguments")
        return -1
    end        

    local label = conf["label"]
    if ((label == nil) or (string.len(label) == 0)) then
        multiboot.dprint("firmware label not provided")
        return -1
    end        
            
    if (conf["location"] == nil) then
        multiboot.dprint("storage location not provided")
        return -1
    end

    -- Generate the firmlabel
    local firmlabel = multiboot.labelStrip(label)
    if (firmlabel == nil) then
        multiboot.dprint("failed to generate firmlabel")
        return -1
    end        

    local desc = conf["desc"] or firmlabel
    local location = conf["location"]

    --
    -- Load boottable for this media.
    --
    bootMenuFile = multiboot.bootMenuFileGet(location)
	if (pcall (loadfile (bootMenuFile))) then
        dofile (bootMenuFile)

        -- Make a copy of the global variable
        bootmenu = boottable

        if (bootmenu ~= nil) then
		    bootIndex = (#(bootmenu) + 1)
        else            
            bootIndex = 1
        end
	else
        --
        -- No boot conf file was found on the storate mediun
        -- Create a new file.
        --
        bootIndex = 1
	end

    if (bootmenu == nil) then
        bootmenu = {}
    end            

    local bootent = multiboot.firmwareEntGet(label)
    if (bootent == nil) then
    	bootmenu [bootIndex] = {}
        multiboot.dprint("could not find label:" .. label)
    else
    	bootIndex =  tonumber(bootent["arg1"])
        multiboot.dprint("found label:" .. label)
        multiboot.dprint("Re-Using bootindex:" .. bootIndex)
    end            

	if (location == "sdcard") then
		local kernelpath = kernel_image_prefix .. firmlabel
		local fsPath = fs_image_prefix .. firmlabel
        local cfg = cfg_prefix .. "/" .. firmlabel .."/"

        -- create the configuration directory
        os.execute("mkdir -p " .. cfg)

	    bootmenu [bootIndex] = {   
                                title = label,
                                firmlabel = firmlabel,
                                valid = "0",
                                kernel = kernelpath,
                                fs = fsPath,
                                data = cfg,
                                arg1 = tonumber(bootIndex),
                                script = "/pfrm2.0/bin/changefirmware",
                                desc = desc,
                                location = location
                                }
	else
		-- For flash, just update the fields
		bootmenu[bootIndex]["title"] = label 
		bootmenu[bootIndex]["firmlabel"] = firmlabel
		bootmenu[bootIndex]["valid"] = "0"
		bootmenu[bootIndex]["desc"] = desc
		bootmenu[bootIndex]["arg1"] = tonumber(bootIndex)
		bootmenu[bootIndex]["location"] = location
	end

	-- write the updated bootmenu to file
	multiboot.writeTableToFile (bootmenu, bootMenuFile, "boottable")

	return bootIndex, bootmenu
end

----------------------------------------------------------------------------------
-- @name multiboot.deleteBootConf - delete boot entry
--
-- @description This function deletes the boot entry with the given label
-- 
-- @return  0 or -1
--

function multiboot.deleteBootConf (conf)
    local bootIndex = 1
    local bootMenuFile
    local bootmenu = {}

    if (conf == nil) then
        multiboot.dprint("deleteBootConf: invalid arguments")
        return -1
    end        

    if (type(conf) ~= "table") then
        multiboot.dprint("deleteBootConf: invalid arguments")
        return -1
    end        

    local label = conf["label"]
    if ((label == nil) or (string.len(label) == 0)) then
        multiboot.dprint("failed to specify label")
        return -1
    end        
            
    if (conf["location"] == nil) then
        multiboot.dprint("failed to specify storage location")
        return -1
    end

    local location = conf["location"]

    -- Load boottable for this media.
    bootMenuFile = multiboot.bootMenuFileGet(location)
	if (pcall (loadfile (bootMenuFile))) then
        dofile (bootMenuFile)

        -- Make a copy of the global variable
        bootmenu = boottable
        if (bootmenu ~= nil) then
		    bootIndex = (#(bootmenu) + 1)
        end
	end

    if (bootmenu == nil) then
        multiboot.dprint("failed to find bootmenu")
        return -1
    end            

    -- get the firmware entry using the label
    local bootent = multiboot.firmwareEntGet(label)
    if (bootent == nil) then
        multiboot.dprint("could not find label:" .. label)
        return -1
    else
    	bootIndex =  tonumber(bootent["arg1"])
        multiboot.dprint("found label:" .. label)
        table.remove(bootmenu, bootIndex)
    end            

	-- write the updated bootmenu to file
	multiboot.writeTableToFile (bootmenu, bootMenuFile, "boottable")

    return 0
end

----------------------------------------------------------------------------------
-- @name multiboot.updateBootConf - 
--
-- @description This function updates the boot entry for a given
-- label
--
-- @return 
--

function multiboot.updateBootConf (conf)
    require "firmLib"
    local bootIndex = 1
    local bootMenuFile
    local bootmenu = {}

    if (conf == nil) then
        multiboot.dprint("updateBootConf: invalid arguments")
        return nil
    end        

    if (type(conf) ~= "table") then
        multiboot.dprint("updateBootConf: invalid arguments")
        return nil
    end        

    if (conf["filename"] == nil) then
        multiboot.dprint("updateBootConf: invalid arguments. filename not provided")
        return nil
    end
            
    if (conf["location"] == nil) then
        multiboot.dprint("updateBootConf: invalid arguments. location not provided")
        return nil
    end

    local hdr = firmLib.hdrGet(conf["filename"])
    if (hdr == nil) then
        multiboot.dprint("Invalid firmware file:" .. conf["filename"])
        return nil
    end

    conf["hdr"] =  hdr

    local label = conf["label"]
    local location = conf["location"]
    -- Use the filename as the label if label is not provided
    if ((label == nil) or (string.len(label) == 0)) then
        label = hdr["fileName"]
        conf["label"] = label
    end        

    -- add or get existing boot configuration
    local bootIndex, bootmenu = multiboot.addBootConf(conf)
    if (bootIndex < 0) then
        multiboot.dprint("failed to add/get boot entry")
        return nil
    end

    -- update firmware information            
	bootmenu[bootIndex]["timestamp"] = hdr["timeStamp"]
	bootmenu[bootIndex]["valid"] = conf["valid"] or "0"
	bootmenu[bootIndex]["firmType"] = hdr["firmType"]
                
	-- write the updated bootmenu to file
    bootMenuFile = multiboot.bootMenuFileGet(location)
	multiboot.writeTableToFile (bootmenu, bootMenuFile, "boottable")

	return bootmenu[bootIndex]
end

----------------------------------------------------------------------------------
-- @name multiboot.changeBootcmd
--
-- @description This function changes the u-boot's boot command to boot the
-- firmware represented by the given entry in the next reboot.
-- 
-- @return 
--

function multiboot.changeBootcmd (ent)
	local def_script = "/pfrm2.0/bin/changefirmware " 
    local script = ent["script"]
    local location = ent["location"]
    local label = ent["firmlabel"]
    local firmType = ent["firmType"] or ""

    if (script == nil) then 
        script = def_script 
    end
            
    local cmd = script .. " " .. location .. " " ..  label .. " " .. firmType 

    local status = os.execute(cmd)

    return status
end

----------------------------------------------------------------------------------
-- @name multiboot.writeTableToFile
--
-- @description This function writes the given table into the given file
-- 
-- @return 
--
--

function multiboot.writeTableToFile (table, filename, tableName)
	local charNewLine = "\n"

	local file, err = io.open(filename, "wb+" )
    if err then 
        return "ERROR" 
    end

	file:write(tableName .. " = {}" .. charNewLine)
	for k,v in pairs (table) do
		file:write(tableName .. "[" .. k .. "]={}" .. charNewLine)
		if type(v) == "table" then
			for i,j in pairs (v) do
			file:write(tableName .. "[" .. k .. "][\"" ..tostring(i).."\"]=".."\""..j.."\"" .. charNewLine)
			end
		end
	end

    file:flush()

    file:close()
end

----------------------------------------------------------------------------------
-- @name multiboot.bootIdxGet - get the bootIndex for the given label.
--
-- @description This function gets the boot index for the given label. If the
-- label is already present it returns its index else new one.
-- 
-- @return bootIndex
--

function multiboot.bootIdxGet (label, location)
    local bootIndex = 1
    local bootMenuFile
    local bootmenu = {}

    bootMenuFile = multiboot.bootMenuFileGet(location)

    --
    -- Load boottable for this media.
    --
	if (pcall (loadfile (bootMenuFile))) then
        dofile (bootMenuFile)

        -- Make a copy of the global variable
        bootmenu = boottable

        if (bootmenu ~= nil) then
		    bootIndex = (#(bootmenu) + 1)
        else            
            bootIndex = 1
        end
	else
        --
        -- No boot conf file was found on the media
        -- Create a new file.
        --
        bootIndex = 1
	end

    local bootent = multiboot.firmwareEntGet(label)
    if (bootent ~= nil) then
        bootIndex =  tonumber(bootent["arg1"])
    end            

    return bootIndex
end

----------------------------------------------------------------------------------
-- @name multiboot.dprint
--
-- @description 
-- 
-- @return 
--
--

function multiboot.dprint(msg)
    if (tonumber(multiboot.debug) > 0) then
        os.execute("/pfrm2.0/bin/adpLog " .. multiboot.firmdCompId .. "  8  '" .. msg .. "'")
        if (multiboot.console == 1) then
            print ("MULTIBOOT: " .. message)
        end
    end    
end

----------------------------------------------------------------------------------
-- @name multiboot.labelStrip - generate firmware label
--
-- @description The function generates the firmware label by stripping spaces
-- in the user provided label. This label is used for comparison of boot entries.
-- and as a suffix to kernel and filesystem images on the storage medium.
--
-- @return firmware label
--

function multiboot.labelStrip (label)

    if (label == nil) then
        return nil
    end        

    -- convert to lower case
    label = string.lower(label)

    -- strip spaces
    label = string.gsub(label, "%s","")

    --TODO strip control characters except \0

    return label
end

----------------------------------------------------------------------------------
-- @name multiboot.bootMenuFileGet - get the bootmenu
--
-- @description  This function gets the boot menu file containing the list of
-- all the firmware images on this storage medium
--
-- @return 
--

function multiboot.bootMenuFileGet (location)
    local bootMenuFile

	if (location == "sdcard") then
		bootMenuFile = sdcardBootConf

        -- rc script mounts it as read-only
        os.execute ("umount /mnt/sdcard/boot")

        -- mount the sdcard read/write
        os.execute ("mount /dev/mmcblk0p1 /mnt/sdcard/boot/")

	elseif (location == "flash") then
		bootMenuFile = flashBootConf
	    -- add more if else conditions for more media types
	end

    return bootMenuFile
end    

----------------------------------------------------------------------------------
-- @name multiboot.firmwareEntValidate - make bootentry valid
--
-- @description  This function validates the bootenty which has the given
-- timestamp.
--
-- @return 
--

function multiboot.firmwareEntValidate (location, timestamp)

    local bootMenuFile = multiboot.bootMenuFileGet(location)
	if (pcall (loadfile (bootMenuFile))) then
        dofile (bootMenuFile)
    else
        multiboot.dprint("firmwareEntValidate: could not find bootmenu file")        
        return "ERROR", "MULTIBOOT_ERR_INVALID"
    end        

    for k,v in pairs(boottable) do
        if (timestamp == v.timestamp) then
            v["valid"] = "1"

            --  update the changes to the file
        	multiboot.writeTableToFile (boottable, bootMenuFile, "boottable")

            return v
        end            
    end        

    return nil
end

----------------------------------------------------------------------------------
-- @name multiboot.commitBootConf - commit installation status
--
-- @description  This function is called after a successful upgrade to mark
-- the boot entry corresponding to the give firmware file as valid
--
-- @return status, errCode, bootentry
--

function multiboot.commitBootConf (location, filename)
    require "firmLib"

    -- read the firmware header and parse it
    local hdr = firmLib.hdrGet(filename)
    if (hdr == nil) then
    	multiboot.dprint("commitBootConf: invalid firmware file provided")
        return "ERROR","MULTIBOOT_ERR_INVALID_FIRM"
    end

    -- make the entry valid and update the boot entry
    local ent = multiboot.firmwareEntValidate(location, hdr["timeStamp"])
    if (ent == nil) then
    	multiboot.dprint("commitBootConf: could not find boot entry")
        return "ERROR","MULTIBOOT_ERR_ENOENT"
    end    

    return "OK","STATUS_OK", ent
end
