-- @copyright Copyright (c) 2013, TeamF1, Inc. 

--************* Packages *************
isatap = {}

-------------------------------------------------------------------------
-- @name isatap.config
--
-- @description 
--
-- @return 

function isatap.config (name, inputTable, rowid, operation)
    -- validate
    if (operation == "add") then
        return db.insert(name, inputTable)
    elseif (operation == "edit") then
        return db.update(name, inputTable, rowid)
    elseif (operation == "delete") then
        return db.delete(name, inputTable)
    end
    return false
end

-------------------------------------------------------------------------
-- @name isatap.tunnelConfig
--
-- @description 
--
-- @return 

function isatap.tunnelConfig(inputTable, rowid, operation)
    local statusFlag = true
    

    inputTable = util.addPrefix(inputTable, "isatapTunnel.")
  
    statusFlag = isatap.config("isatapTunnel", inputTable, rowid, operation)
    
    -- return
    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "ISATAP_CONFIG_FAILED"
    end
end

-------------------------------------------------------------------------
-- @name isatap.tunnelDelete
--
-- @description 
--
-- @return 
--
function isatap.tunnelDelete (inputTable)
    local status
    local errCode

    local query = "_ROWID_='" .. inputTable["isatapTunnel._ROWID_"] .. "'"
    local row = db.getRowWhere("isatapTunnel", query, false)
    if (row == nil) then
        return "ERROR", "ISATAP_TUNNEL_NET_ERROR"
    end

    status, errCode = isatap.tunnelConnDel (row)
    if (status == "ERROR") then
        return status, errCode
    end

    status, errCode = isatap.tunnelNetDel (row)
    if (status == "ERROR") then
        return status, errCode
    end

    return isatap.tunnelConfig(inputTable, inputTable.__ROWID__, "delete")
end

--[[
*******************************************************************************
-- @name isatap.tunnelNetCfgInit 
--
-- @description The function add isatap tunnel network
--
-- @param  
--
-- @return  status, errCode
--]]

function isatap.tunnelNetCfgInit (conf, networkId, ifNameId, row)
    local ifName = "isatap" .. ifNameId
    local logIfName = ifName .. "-" .. row["transportIfName"]

    conf["interfaceName"] = "isatap" .. ifNameId
    conf["LogicalIfName"] = logIfName
    conf["networkName"] = ifName
    conf["networkId"] = networkId
    conf["enable"] = "0"
    conf["ifType"] = "tunnel"
    conf["mtu"] = "1500"
    conf["mac"] = ""
    conf["ifGroupId"] = 1 
    conf["ifMark"] = networkId
    conf["connectionType"] = ""
    conf["zoneType"] = "SECURE-ISATAP"

    return conf
end

--[[
*******************************************************************************
-- @name isatap.tunnelConnAdd 
--
-- @description The function add isatap tunnel Connection
--
-- @param  
--
-- @return  status, errCode
--]]

function isatap.tunnelConnAdd (ifNameId, row)
    local status = "ERROR"
    local errCode = "ISATAP_TUNNEL_ERR_INVALID_PARAMS"
    local conf = {}

    if (ifNameId == nil) then
        return status, errCode
    end

    if (conf == nil) then
        return status, errCode
    end

    conf = isatap.tunnelConnCfgInit(conf, ifNameId, row)
    conf = util.addPrefix(conf, "NimfConf.")
    local valid, errstr = db.insert("NimfConf", conf)
    if (not valid) then
        return "ERROR", "ISATAP_TUNNEL_CONN_ADD_FAILED"
    end

    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- @name isatap.tunnelConnCfgInit 
--
-- @description 
--
-- @param  
--
-- @return  status, errCode
--]]

function isatap.tunnelConnCfgInit (conf, ifNameId, row)
    local ifName = "isatap" .. ifNameId
    local logIfName = ifName .. "-" .. row["transportIfName"]

    conf["LogicalIfName"] = logIfName
    conf["AddressFamily"] = "10"
    conf["ConnectionKey"] = "0"
    conf["Enable"] = "0"
    conf["ConnectionType"] = "ifStatic6" 
    conf["WarnDisconnectDelay"] = ""
    conf["ConfigureDNS"] = "0"
    conf["ConfigureRoute"] = "0"
    conf["DefaultConnection"] = "0" 

    return conf
end

--[[
*******************************************************************************
-- @name isatap.tunnelNetDel 
--
-- @description
--
-- @param  
--
-- @return  status, errCode
--]]

function isatap.tunnelNetDel (inputTable)
    local status = "ERROR"
    local errCode = "ISATAP_TUNNEL_ERR_DEL_PARAMS"
    local conf = {}

    if (inputTable == nil) then
        return status, errCode
    end

    local query = "interfaceName='" .. inputTable["interfaceName"] .. "'"
    local row = db.getRowWhere("networkInterface", query, false)
    if (row == nil) then
        return "ERROR", "ISATAP_TUNNEL_NET_ERROR"
    end

    row = util.addPrefix(row, "networkInterface.")
    local valid, errstr = db.deleteRow("networkInterface", "_ROWID_", row["networkInterface._ROWID_"])
    if (not valid) then
        return "ERROR", "ISATAP_TUNNEL_NET_DEL_FAILED"
    end

    --delete ipaddresses
    local valid1, errstr1 = db.deleteRow("ipAddressTable", "LogicalIfName", row["networkInterface.LogicalIfName"])
    if (not valid1) then
        return "ERROR", "ISATAP_TUNNEL_IP_DEL_FAILED"
    end

    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- @name isatap.tunnelConnDel 
--
-- @description
--
-- @param  
--
-- @return  status, errCode
--]]

function isatap.tunnelConnDel (inputTable)
    local status = "ERROR"
    local errCode = "TUNNEL_ERR_DEL_PARAMS"
    local conf = {}

    if (inputTable == nil) then
        return status, errCode
    end

    local query = "interfaceName='" .. inputTable["interfaceName"] .. "'"
    local row = db.getRowWhere("networkInterface", query, false)
    if (row == nil) then
        return "ERROR", "ISATAP_TUNNEL_NET_ERROR"
    end

    local query1 = "LogicalIfName='" .. row["LogicalIfName"] .. "'"
    local row1 = db.getRowWhere("NimfConf", query1, false)
    if (row1 == nil) then
        return "ERROR", "ISATAP_TUNNEL_CONN_ERROR"
    end

    row1 = util.addPrefix(row1, "NimfConf.")
    local valid, errstr = db.deleteRow("NimfConf", "_ROWID_", row1["NimfConf._ROWID_"])
    if (not valid) then
        return "ERROR", "ISATAP_TUNNEL_CONN_DEL_FAILED"
    end

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name isatap.tunnelGet
--
-- @description 
--
-- @return 
--
function isatap.tunnelGet()
    return db.getTable("isatapTunnel",false)
end

-------------------------------------------------------------------------
-- @name isatap.tunnelAddSet
--
-- @description 
--
-- @return 
--
function isatap.tunnelAddSet(isatapTunnelTbl)
    local status
    local errCode
    local networks = {}
    local tunnels = {}

    status, errCode, networks = ifDev.cfgByQueryGet()
    if (stat == "ERROR") then
        return stat, errCode
    end
   
    status, errCode, tunnels = isatap.cfgByQueryGet()
    if (stat == "ERROR") then
        return stat, errCode
    end

    local tunnelNetId = #networks + 1
    local tunnelIfId = #tunnels + 1

    status, errCode = isatap.tunnelNetAdd (tunnelNetId, tunnelIfId, isatapTunnelTbl)
    if (state == "ERROR") then
        return stat, errCode
    end

    status, errCode = isatap.tunnelConnAdd (tunnelIfId, isatapTunnelTbl)
    if (state == "ERROR") then
        return stat, errCode
    end

    return isatap.tunnelConfig(isatapTunnelTbl, "-1", "add")  
end

-------------------------------------------------------------------------
-- @name isatap.tunnelEditSet
--
-- @description 
--
-- @return 
--
function isatap.tunnelEditSet(isatapTunnelTbl)
    return isatap.tunnelConfig(isatapTunnelTbl, isatapTunnelTbl._ROWID_, "edit")
end

-------------------------------------------------------------------------
-- @name isatap.tunnelEditGet
--
-- @description 
--
-- @return 
--
function isatap.tunnelEditGet(rowId)
    local configTbl = {}
    configTbl = db.getRow ("isatapTunnel", "_ROWID_", rowId)
    --configTbl = util.removePrefix(configTbl, "isatapTunnel.")
    return configTbl
end

-------------------------------------------------------------------------
-- @name isatap.import
--
-- @description 
--
-- @return 
--

function isatap.import (isatapTunnelConfig, defaultCfg, removeCfg)
    if (isatapTunnelConfig == nil) then
        isatapTunnelConfig = defaultCfg
    end

    local isatapTunnelTmp = {}

    isatapTunnelTmp = config.update (isatapTunnelConfig.isatapTunnel, defaultCfg.isatapTunnel, removeCfg.isatapTunnel)
    if (isatapTunnelTmp ~= nil and #isatapTunnelTmp ~= 0) then
        for i,v in ipairs (isatapTunnelTmp) do
            v = util.addPrefix (v, "isatapTunnel.");
            isatap.config ("isatapTunnel", v, -1, "add")
        end
    end
	
end

-------------------------------------------------------------------------
-- @name sixToFour.export
--
-- @description 
--
-- @return 
--

function isatap.export ()
	local isatapTbl = {}
	local table = {}
    table["isatapTunnel"] = {}

 	table["isatapTunnel"] = db.getTable("isatapTunnel" , false)
	if (table["isatapTunnel"] ~= nil) then
	    isatapTbl["isatapTunnel"] = table["isatapTunnel"]
	end

	return isatapTbl
end

if (config.register) then
   config.register("isatap", isatap.import, isatap.export, "1")
end

--[[
*******************************************************************************
-- @name isatap.cfgByQueryGet 
--
-- @description The function gets the configuration of the isatap that is 
-- stored in the database
--
-- @param  query  custom database query or nil to get full table
--
-- @return  status, errCode
--]]

function isatap.cfgByQueryGet (query)
    local records = {}

    if (query == nil) then
        records = db.getTable("isatapTunnel", false)
    else
        records = db.getRowsWhere("isatapTunnel", query, false)
    end
            
    if (records == nil) then
        return "ERROR", "ISATAP_ERR_QUERY_FAILED"
    end        

    return "OK", "STATUS_OK", records
end

--[[
*******************************************************************************
-- @name isatap.tunnelNetAdd 
--
-- @description The function add isatap tunnel network
--
-- @param  
--
-- @return  status, errCode
--]]

function isatap.tunnelNetAdd (networkId, ifNameId, row)
    local status = "ERROR"
    local errCode = "ISATAP_TUNNEL_ERR_INVALID_PARAMS"
    local conf = {}

    if (networkId == nil) then
        return status, errCode
    end

    if (ifNameId == nil) then
        return status, errCode
    end

    if (conf == nil) then
        return status, errCode
    end

    conf = isatap.tunnelNetCfgInit(conf, networkId, ifNameId, row)
    conf = util.addPrefix(conf, "networkInterface.")
    local valid, errstr = db.insert("networkInterface", conf)
    if (not valid) then
        return "ERROR", "ISATAP_TUNNEL_NET_ADD_FAILED"
    end

    return "OK", "STATUS_OK"
end


