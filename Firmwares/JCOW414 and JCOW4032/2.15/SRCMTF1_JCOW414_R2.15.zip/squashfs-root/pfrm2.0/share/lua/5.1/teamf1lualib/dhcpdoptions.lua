-- @copyright Copyright (c) 2012, TeamF1, Inc. 

dhcp.optpool = {}

-------------------------------------------------------------------------
-- @name dhcp.optpool.add
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcp.optpool.add(pool)
	require "teamf1lualib/service"
    local status="ERROR"
    local errCode="DHCPD_INVALID_PARAMS"

    if (pool == nil) then
        return status, errCode        
    end
            
    -- Default missing mandatory arguments
    if (pool["Enable"] == nil) then
        pool["Enable"] = "0"
    end        

    if (pool["DefaultPool"] == nil) then
        pool["DefaultPool"] = "0"        
    end        

    if (pool["PoolID"] == nil) then
        pool["PoolID"] = dhcp.uniquePoolIDGet()
    end        
            
    if (tonumber(pool["DefaultPool"]) > 0) then
        dhcp.dprintf("dhcp.optpool.add: default pool not allowed")
		return "ERROR","DHCPD_INVALID_POOL_TYPE"
    end        
                    
    dhcp.dprintf("dhcp.optpool.add: " .. util.tableToStringRec(pool))
                        
    -- Do basic pool validation                    
    status, errCode = dhcp.optpool.validate(pool)
    if (status ~= "OK") then
        dhcp.dprintf("dhcp.optpool.add: pool validation failed")
        return status, errCode
    end        
	
	-- update the database
	pool = util.addPrefix(pool, "DhcpServerPools.")
	local valid, errstr, rowid = db.insert("DhcpServerPools", pool)
    if (not valid) then
        dhcp.dprintf("dhcp.optpool.add: failed to add pool to " ..
                     "configuration.ERR:" .. errstr)
        dhcp.dprintf("POOL: " .. util.tableToStringRec(pool))
        return "ERROR","DHCD_DB_ERR"        
    end        

	-- re-write configuration and restart the DHCP server.
    service.restart("dhcpd", "1")

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------
-- @name dhcp.optpool.delete
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcp.optpool.delete(IDList)
	require "teamf1lualib/service"

    if (IDList == nil) then
        dhcp.dprintf("dhcp.optpool.delete: invalid arguments")        
        return "ERROR", "DHCPD_INVALID_ARG"
    end
            
    local valid, errstr = db.delete ("DhcpServerPools", IDList)
    if (not valid) then
        dhcp.dprintf("dhcp.optpool.delete: " ..
                     "failed to delete bindings from db. Err:" .. errstr)
        dhcp.dprintf("IDList: " .. util.tableToStringRec(IDList))
        return "ERROR","DHCPD_DB_ERR"
    end        

	-- re-write configuration and restart the DHCP server.
    service.restart("dhcpd", "1")

	return "OK","STATUS_OK"
end

-------------------------------------------------------------------------
-- @name dhcp.optpool.edit
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcp.optpool.edit(ID, pool)
	require "teamf1lualib/service"
    local query = nil

    -- Get the option pool configuration
	query = "_ROWID_=" .. ID
	local row = db.getRowWhere("DhcpServerPools", query, false)
	if (row == nil) then
		return "ERROR","DHCPD_POOL_NOT_FOUND"
	end

    -- Do basic pool validation                    
    status, errCode = dhcp.optpool.validate(pool)
    if (status ~= "OK") then
        dhcp.dprintf("dhcp.optpool.add: pool validation failed")
        return status, errCode
    end        

    -- initialise the pool configuration
    row = dhcp.poolCfgInit (row, pool)

	-- update the database
	row = util.addPrefix(row, "DhcpServerPools.")
	local valid, errstr = db.update("DhcpServerPools", row,
                                     row["DhcpServerPools._ROWID_"])
    if (not valid) then
        dhcp.dprintf("dhcp.optpool.edit: failed to edit optional pool" ..
                     "ERR: " .. errstr)
        dhcp.dprintf("POOL: " .. util.tableToStringRec(row))
        return "ERROR","DHCPD_DB_ERR"
    end        

	-- re-write configuration and restart the DHCP server.
    service.restart("dhcpd", "1")

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------
-- @name dhcp.optpool.get
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcp.optpool.get(LogicalIfName, filter)
    local query = nil

    if (LogicalIfName ~= nil) then
        query = "LogicalIfName='" .. LogicalIfName .. "' and DefaultPool=0 "
    else
        query = "DefaultPool=0 "
    end        

    if (filter ~= nil) then
        query = query .. " AND " .. filter        
    end        

    dhcp.dprintf("dhcp.optpool.get: query:" .. query)
    local pool = db.getRowsWhere("DhcpServerPools", query, false)
    if (pool == nil) then
        dhcp.dprintf("dhcp.optpool.get: query:" .. query .. " failed")
        return "ERROR","DHCPD_DB_ERR"
    end
            
    return "OK","STATUS_OK", pool            
end

-------------------------------------------------------------------------
-- @name dhcp.optpool.validate
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function dhcp.optpool.validate (pool)
    require "teamf1lualib/nimf"
    require "ifDevLib"
    local status = "ERROR"
    local errCode = "DHCPD_INVALID_PARAMS"

    if (pool == nil) then
        return status, errCode        
    end
     
    local net = ifDevLib.netIfInfoGet (pool["LogicalIfName"]);
    -- check of mandatory arguments:
    -- LogicalIfName 
    -- MinAddress       
    -- MaxAddress
    if ((pool["LogicalIfName"] == nil) or
        (pool["MinAddress"] == nil) or (pool["MaxAddress"] == nil) 
        or (net == nil)) then
        dhcp.dprintf("optpool.validate: mandatory argument check failed")
        return status, errCode
    end
            
    --  check if min and max address are in the subnet
    if ((nimfLib.isAddrInNetwork(net["interfaceName"], pool["MinAddress"])  == 0) or
        (nimfLib.isAddrInNetwork(net["interfaceName"], pool["MaxAddress"]) == 0)) then
	 	dhcp.dprintf ("dhcp.optpool.add: invalid pool address")
		return "ERROR","DHCPD_INVALID_POOL_ADDRESS"
    end        
                
	-- check of collision with other pools.
	if (dhcpLib.dhcpdPoolValidate(pool["MinAddress"], pool["MaxAddress"], 
                                  pool["PoolID"], pool["LogicalIfName"]) == 0) then
	 	dhcp.dprintf ("dhcp.optpool.add: Address pool collision")
		return "ERROR","DHCPD_POOL_RANGE_CONFLICT"
	end

    return "OK","STATUS_OK"
end
