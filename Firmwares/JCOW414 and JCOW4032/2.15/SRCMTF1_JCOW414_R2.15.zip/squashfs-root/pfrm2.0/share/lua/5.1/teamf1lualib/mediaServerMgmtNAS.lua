-- mediaServerMgmtNAS.lua - medias server NAS related routines

-- Copyright (c) 2010, TeamF1, Inc.

-- modification history
-- --------------------
-- 01a,31mar10,pnm  written.

-- ********************** Requires ********************
require "teamf1lualib/mediaServerMgmt"

--*****************************************************************************
--mediaServerMgmt.shareExport - exports media server related shares
--
--This routine exports media server related shares given the list of share
--names to export.
--
--RETURNS: table with share info
function  mediaServerMgmt.shareExport (nasShareTbl)
    -- local declarations
    local where = nil

    -- iterate through the table and create where string
    for i,v in ipairs (nasShareTbl) do
        if (where == nil) then
            where = "shareName='"..v["name"].."'"
        else
            where = where.."OR shareName='"..v["name"].."'"
        end
    end

    -- execute the query and return results
    if (where ~= nil) then
        return db.getRowsWhere ("mediaServerShares", where, false)
    end
end

--*****************************************************************************
--mediaServerMgmt.shareImport - imports media server related shares
--
--This routine imports media server related shares given the share info
--
--RETURNS: nothing
function  mediaServerMgmt.shareImport (configTable)
    -- Iterate through list of shares and add one at a time.
    if (configTable ~= nil) then
        for i, v in ipairs (configTable) do
            -- convert the from form <component name><column name to> to
            -- <"compName.columnName">
            v = util.addPrefix (v, "mediaServerShares.");
            util.appendDebugOut (util.tableToString (v))

            -- Add the row into the DB
            mediaServerMgmt.sharesTblConfig (v, "add", -1)
        end
    end
end

--*****************************************************************************
--mediaServerMgmt.shareDelete - deletes media server related shares
--
--This routine deletes media server related shares given the list of share
--names to export.
--
--RETURNS: table with share info
function  mediaServerMgmt.shareDelete (nasShareTbl)
    -- local declarations
    local where = nil

    -- iterate through the table and create where string
    for i,v in ipairs (nasShareTbl) do
        where = "shareName='"..v["name"].."'"
        db.deleteRowWhere ("mediaServerShares", where)
    end
end

--register to partitionMgmt service
if (partitionMgmt.shareConfigRegister) then
    partitionMgmt.shareConfigRegister ("mediaServer",
    mediaServerMgmt.shareImport, mediaServerMgmt.shareExport,
    mediaServerMgmt.shareDelete)
end
