#!/pfrm2.0/bin/lua 

--[[
-- Copywrite (c) 2013 TeamF1, Inc.

--
-- modification history
-- --------------------
-- 01a, 12Mar13, sen dervied from reference solution. for RIL.
]]--


--************* Requires *************
require "teamf1lualib/db"
require "ifDevLib"

--************* Logic *************
dbfile = arg[1]

db.connect (dbfile or "/tmp/system.db")

-- local rows = db.getRowsWithJoin ({"dot11VAP:dot11Interface:vapName"}, "dot11VAP.vapEnabled", 1)
local rows = db.getTableWithJoin ({"dot11VAP:dot11Interface:vapName"})

os.execute("ifconfig fp down")
for k,v in pairs(rows) do
    local ifName = v["dot11Interface.interfaceName"]
    local ifIdx = string.match (ifName,"%d")
    local ifMac = ifDevLib.getMac(ifName)
    if (ifMac ~= "00:00:00:00:00:00") then
        local arlLookup = string.format([[/pfrm2.0/bin/arl_table_func lookup %s 4095]]
                                     ,ifMac)
        local arlDel = string.format([[/pfrm2.0/bin/arl_table_func del %s 4095]]
                                     ,ifMac)
        local arlAdd = string.format([[/pfrm2.0/bin/arl_table_func add %s 4095 0x4 1]]
                                     ,ifMac)
        local ifAdd = string.format([[/pfrm2.0/bin/sppe_ioctl pcifp index:%d if:%s]]
                                     ,ifIdx,ifName)

        local fp = io.popen(arlLookup)
        if fp then
            for Line in fp:lines() do
                if (string.find (Line,"not found")) then
                    os.execute ("echo "..arlAdd.." >> /var/wlansppe.out")
                    os.execute (arlAdd)
                    break
                else
                    os.execute ("echo Entry found in arl >> /var/wlansppe.out")
                    break
                end
            end
            fp:close()
        end

        --os.execute ("echo "..arlDel.." >> /var/wlansppe.out")
        --os.execute ("echo "..arlAdd.." >> /var/wlansppe.out")
        os.execute ("echo "..ifAdd.." >> /var/wlansppe.out")
        --os.execute (arlDel)
        --os.execute (arlAdd)
        os.execute (ifAdd)
    end
end
os.execute ("echo >> /var/wlansppe.out")
os.execute("ifconfig fp up")
