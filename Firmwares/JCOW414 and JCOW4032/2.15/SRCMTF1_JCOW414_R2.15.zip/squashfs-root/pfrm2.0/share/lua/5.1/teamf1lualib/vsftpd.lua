-- vsftpd.lua : 

-- Copyright (c) 2013, TeamF1, Inc

vsftpd = {}

function vsftpd.config (tblName, inputTable, rowid, operation)
    -- validate
    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
            return db.insert(tblName, inputTable)
        elseif (operation == "edit") then
            return db.update(tblName, inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete(tblName,inputTable)
        end
    end
    return false
end

-------------------------------------------------------------------------------
-- @name : vsftpd.confGet()
--
-- @description : API to return vsftpd table
--
-- @return : Entire vsftpd table
-- 
function vsftpd.confGet()
    --local 
    local ftpdTbl = {}
    
    ftpdTbl = db.getRow ("ftpd", "_ROWID_", "1")   

    ftpdTbl = util.removePrefix(ftpdTbl, "ftpd.")
    --return
    return "OK", "STATUS_OK", ftpdTbl
end

-------------------------------------------------------------------------------
-- @name : vsftpd.configure()
--
-- @description : API to set values in vsftpd table
--
-- @return : status, error code
-- 
function vsftpd.configure(ftpdTbl)

    -- add table prefix
    ftpdTbl = util.addPrefix(ftpdTbl, "ftpd.")

    statusFlag = vsftpd.config ("ftpd", ftpdTbl, "1", "edit")

    -- check status
    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "VSFTPD_FAILED"
    end    
end

function vsftpd.import (inputTable, defaultCfg, remCfg)
    if (inputTable == nil) then
		inputTable = defaultCfg
	end

    local ftpdTmp = {}
    local ftpUsersTmp = {}

    -- import ftpUsers
    ftpUsersTmp = config.update (inputTable.ftpUsers, defaultCfg.ftpUsers, remCfg.ftpUsers)
    if (ftpUsersTmp ~= nil and #ftpUsersTmp ~= 0) then
        for i,v in ipairs (ftpUsersTmp) do
            v = util.addPrefix (v, "ftpUsers.");
            vsftpd.config ("ftpUsers", v, "-1", "add")
        end
    end

    -- import vsftpd
    ftpdTmp = config.update (inputTable.ftpd, defaultCfg.ftpd, remCfg.ftpd)
    if (ftpdTmp ~= nil and #ftpdTmp ~= 0) then
        for i,v in ipairs (ftpdTmp) do
            v = util.addPrefix (v, "ftpd.");
            vsftpd.config ("ftpd", v, "-1", "add")
        end
    end
end

function vsftpd.export ()
    local vsftpd = {}
    local table = {}

    -- export ftpUsers
    table["ftpUsers"] = db.getTable ("ftpUsers", false)
    if (table["ftpUsers"] ~= nil) then
        vsftpd["ftpUsers"] = table["ftpUsers"]
    end

    -- export vsftpd
    table["ftpd"] = db.getTable ("ftpd", false)
    if (table["ftpd"] ~= nil) then
        vsftpd["ftpd"] = table["ftpd"]
    end

    return vsftpd
end

if (config.register) then
   config.register("vsftpd", vsftpd.import, vsftpd.export, "1")
end

