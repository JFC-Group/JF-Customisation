
require "teamf1lualib/nimf"
require "nimfLib"

nimfProto = {}

-------------------------------------------------------------------------------
-- @name nimfProto.start 
--
-- @description This function starts the protocol
--
-- @param LogicalIfName NET ID
--
-- @return  status, errCode
--

function nimfProto.start (LogicalIfName, addressFamily)
    local status

    -- validate the parameters
    if (nimf.LogicalNameValidate(LogicalIfName) < 0) then
        return "ERROR",nimf.err.NIMF_ERR_INVALID_NETID
    end        

    if (nimf.protocolValidate(addressFamily) < 0) then
        return "ERROR",nimf.err.NIMF_ERR_INVALID_PROTOCOL        
    end
            
    -- send message to the NIMF daemon
    status = nimfLib.protoStart(LogicalIfName)
    if (status ~= 0) then
        return "ERROR", status
    end        

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name nimfProto.stop 
--
-- @description This function stops the protocol
--
-- @param LogicalIfName NET ID
--
-- @return  status, errCode
--

function nimfProto.stop (LogicalIfName, addressFamily)
    local status

    -- validate the parameters
    if (nimf.LogicalNameValidate(LogicalIfName) < 0) then
        return "ERROR",nimf.err.NIMF_ERR_INVALID_NETID
    end        

    if (nimf.protocolValidate(addressFamily) < 0) then
        return "ERROR",nimf.err.NIMF_ERR_INVALID_PROTOCOL        
    end
            
    -- send message to the NIMF daemon
    status = nimfLib.protoStop(LogicalIfName)
    if (status ~= 0) then
        return "ERROR", status
    end        

    return "OK","STATUS_OK"
end
