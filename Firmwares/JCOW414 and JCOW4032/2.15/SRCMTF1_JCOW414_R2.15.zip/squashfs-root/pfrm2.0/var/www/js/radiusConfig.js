/*
 * File: radiusConfig.js
 * Created on 4th Jan 2013 - bala krishan G
 * Copyright (c) 2012 TeamF1, Inc.
 * All rights reserved.
 */
/**
 * Form Validation
 * @method radiusValidate
 */
function radiusValidate(frmId){
    var txtFieldIdArr = new Array();
    txtFieldIdArr[0] = "tf1_txtIpAddress,Please enter a valid IPv4 Address for Primary Authentication Server.";
    txtFieldIdArr[1] = "tf1_txtIpv6Address,Please enter a valid IPv6 Address for Primary Authentication Server.";
    txtFieldIdArr[2] = "tf1_txtAuthPort,Please enter a valid Authentication Port for Primary Authentication Server.";
    txtFieldIdArr[3] = "tf1_txtSecret,Please enter a valid Secret value for Primary Authentication Server.";
    
    txtFieldIdArr[4] = "tf1_txtIpAddress2,Please enter a valid IPv4 Address for Secondary Authentication Server.";
    txtFieldIdArr[5] = "tf1_txtIpv6Address2,Please enter a valid IPv6 Address for Secondary Authentication Server.";
    txtFieldIdArr[6] = "tf1_txtAuthPort2,Please enter a valid Authentication Port for Secondary Authentication Server.";
    txtFieldIdArr[7] = "tf1_txtSecret2,Please enter a valid Secret value for Secondary Authentication Server.";

    txtFieldIdArr[8] = "tf1_primaryRadiusRetryInterval,Please enter a Retry Interval value  for Primary Radius Retry Interval.";
    txtFieldIdArr[9] = "tf1_txtTimeOut,Please enter a valid TimeOut value for Primary Authentication Server.";
    txtFieldIdArr[10] = "tf1_txtRetries,Please enter a valid Retries value for Primary Authentication Server.";
 
    txtFieldIdArr[11] = "tf1_dasServerPort,Please enter a valid DAS Server Port.";
    txtFieldIdArr[12] = "tf1_dasClientIPAddress,Please enter a valid DAS Client IP Address.";
    txtFieldIdArr[13] = "tf1_dasSecretShared,Please enter a valid DAS Secret Shared value.";
 
     
    if (txtFieldArrayCheck(txtFieldIdArr) == false) 
        return false;
    
	if (isProblemCharArrayCheck(txtFieldIdArr, "'\" ", NOT_SUPPORTED) == false) 
        return false;
  var txtFieldIdArr2 = new Array();
  txtFieldIdArr2[txtFieldIdArr2.length] = "tf1_txtSecret,Please enter a valid Secret value for Primary Authentication Server.";
  txtFieldIdArr2[txtFieldIdArr2.length] = "tf1_dasSecretShared,Please enter a valid DAS Secret Shared value.";
  txtFieldIdArr2[txtFieldIdArr2.length] = "tf1_timeWindow,Please enter a valid Time Window value.";

  	if (isProblemCharArrayCheck(txtFieldIdArr2, "|;", PIPE_SEMICOLON_NOT_SUPPORTED) == false) 
          return false;
    if (ipv4Validate('tf1_txtIpAddress', 'IP', false, true, "Invalid IP address.", "for octet ", true) ==
    false) 
        return false;

  if (ipv6Validate('tf1_txtIpv6Address', true, true, '') == false) 
        return false;
    
    /* get and validate port */
    var obj = document.getElementById('tf1_txtAuthPort');
    if (numericValueRangeCheck(obj, '', '', 1, 65535, true, '', '') == false) 
        return false;

  if (ipv4Validate('tf1_txtIpAddress2', 'IP', false, true, "Invalid IP address.", "for octet ", true) ==
    false) 
        return false;

if (ipv6Validate('tf1_txtIpv6Address2', true, true, '') == false) 
        return false;

 var authPort2Obj = document.getElementById('tf1_txtAuthPort2');
    if (numericValueRangeCheck(authPort2Obj, '', '', 1, 65535, true, '', '') == false) 
        return false;

    var intervalObj = document.getElementById('tf1_primaryRadiusRetryInterval');
    if (numericValueRangeCheck(intervalObj, '', '', 300, 65535, true, '', '') == false) 
        return false;


    var timeoutobj = document.getElementById('tf1_txtTimeOut');
    if (numericValueRangeCheck(timeoutobj, '', '', 1, 999, true, '', '') == false) 
        return false;

    var retryobj = document.getElementById('tf1_txtRetries');
    if (numericValueRangeCheck(retryobj, '', '', 1, 9, true, '', '') == false) 
        return false;
    
   
    
    // get and validate port 
    var obj2 = document.getElementById('tf1_dasServerPort');
    if (numericValueRangeCheck(obj2, '', '', 1, 65535, true, '', '') == false) 
        return false;

     if (ipv4Validate('tf1_dasClientIPAddress', 'IP', false, true, "Invalid IP address.", "for octet ", true) ==
    false) 
        return false;

   /* var timeoutobj2 = document.getElementById('tf1_txtTimeOut2');
    if (numericValueRangeCheck(timeoutobj2, '', '', 1, 999, true, '', '') == false) 
        return false;

    var retryobj2 = document.getElementById('tf1_txtRetries2');
    if (numericValueRangeCheck(retryobj2, '', '', 1, 9, true, '', '') == false) 
        return false;
*/
   setHiddenChks (frmId);
   displayProgressBar ();
   return true;
}

/**
 * This function calls Page loads
 * Onload validation
 * @method onloadCall
 */
jQuery(function(){
    onloadCall(enableRemoteConfig, {
        imageId: 'tf1_primaryRadiusRetry',
        disableIndividual: 'tf1_primaryRadiusRetryInterval',
        disableGrp: '',
        enableIndividual: '',
        enableGrp: '',
        hideClass: 'hide',
        showClass: 'configRow',
        breakDivs: 'break_primaryRadiusRetryInterval',
        breakClass: 'break',
        imagesInfo: {
            disableImages: '',
            enableImages: '',
            disableClass: '',
            enableClass: ''
        }
    })
});

// On body load call the respective function
window.onload = function(){
    modeChange();
    enableRemoteConfig({
        imageId: 'tf1_primaryRadiusRetry',
        disableIndividual: 'tf1_primaryRadiusRetryInterval',
        disableGrp: '',
        enableIndividual: '',
        enableGrp: '',
        hideClass: 'hide',
        showClass: 'configRow',
        breakDivs: 'break_primaryRadiusRetryInterval',
        breakClass: 'break',
        imagesInfo: {
            disableImages: '',
            enableImages: '',
            disableClass: '',
            enableClass: ''
        }
    });
}

/**
 * Wrapper function called onload
 * @method enableRemoteConfig
 * @param obj
 */
function enableRemoteConfig(toggleObj){
    onImageToggle(toggleObj);
 
}
 

/* Reset function for form */

function radiusConfigOnReset(frmId) {
	onloadCall();
	modeChange();
	resetImgOnOff(frmId);
	 enableRemoteConfig({
        imageId: 'tf1_primaryRadiusRetry',
        disableIndividual: 'tf1_primaryRadiusRetryInterval',
        disableGrp: '',
        enableIndividual: '',
        enableGrp: '',

        hideClass: 'hide',
        showClass: 'configRow',
        breakDivs: 'break_primaryRadiusRetryInterval',
        breakClass: 'break',
        imagesInfo: {
            disableImages: '',
            enableImages: '',
            disableClass: '',
            enableClass: ''
        }
    });
}



/**
 * State Mode Change
 * @method modeChange
 */
function modeChange(){
    var selValue = radioCheckedValueGet('tf1_ipv4Address');
    if (!selValue) 
        return;
    switch (parseInt(selValue, 10)) {
        case 0: /* Stateful */
        	fieldStateChangeWr("tf1_txtIpv6Address tf1_txtIpv6Address2", "", "tf1_txtIpAddress tf1_txtIpAddress2", "");
            vidualDisplay("tf1_txtIpv6Address tf1_txtIpv6Address2", 'hide');
            vidualDisplay("break_txtIpv6Address break_txtIpv6Address2", 'hide');
	    vidualDisplay("tf1_txtIpAddress tf1_txtIpAddress2", 'configRow');
            vidualDisplay("break_txtIpAddress break_txtIpAddress2", 'break');
            break;
            
        case 1: /* Stateless */
            fieldStateChangeWr("tf1_txtIpAddress tf1_txtIpAddress2", "", "tf1_txtIpv6Address tf1_txtIpv6Address2", "");
            vidualDisplay("tf1_txtIpv6Address tf1_txtIpv6Address2", 'configRow');
            vidualDisplay("break_txtIpv6Address break_txtIpv6Address2", 'break');
	    vidualDisplay("tf1_txtIpAddress tf1_txtIpAddress2", 'hide');
            vidualDisplay("break_txtIpAddress break_txtIpAddress2", 'hide');
            break;
    }
}

