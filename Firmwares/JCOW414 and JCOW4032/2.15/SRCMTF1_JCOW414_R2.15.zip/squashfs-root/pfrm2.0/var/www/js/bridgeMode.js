/*
* File: bridgeMode.js
* Created on 5th August 2013 - Bala Krishna G
* Copyright (c) 2013 TeamF1, Inc.
* All rights reserved.
*/
/**
 * Form Validation
 * @method pageValidate
 */
function pageValidate(frmId) {
	var txtFieldIdArr = new Array();
	txtFieldIdArr[0] = "tf1_vlanId,Please enter a valid VLAN ID";
	txtFieldIdArr[1] = "tf1_vlanId1,Please enter a valid VLAN ID 1";
	txtFieldIdArr[2] = "tf1_vlanId2,Please enter a valid VLAN ID 2";
	txtFieldIdArr[3] = "tf1_vlanId3,Please enter a valid VLAN ID 3";
	txtFieldIdArr[4] = "tf1_vlanId4,Please enter a valid VLAN ID 4";
	txtFieldIdArr[5] = "tf1_vlanId5,Please enter a valid VLAN ID 5";
	txtFieldIdArr[6] = "tf1_vlanId6,Please enter a valid VLAN ID 6";
	txtFieldIdArr[7] = "tf1_vlanId7,Please enter a valid VLAN ID 7";
	txtFieldIdArr[8] = "tf1_vlanId8,Please enter a valid VLAN ID 8";
	txtFieldIdArr[9] = "tf1_vlanId9,Please enter a valid VLAN ID 9";
	txtFieldIdArr[10] = "tf1_vlanId10,Please enter a valid VLAN ID 10";

	if (txtFieldArrayCheck(txtFieldIdArr) == false)
		return false;

	if (!isProblemChar(txtFieldIdArr, " '\"", "Invalid Characters") == false)
		return false;

	var vlanId1Obj = document.getElementById('tf1_vlanId');
	if (vlanId1Obj && !vlanId1Obj.disabled) {
		if (numericValueRangeCheck(vlanId1Obj, "", "", 2, 4094, true, "Invalid VLAN ID.", "") == false)
			return false;
	}

    for (i=1;i<=10;i++){
        vlanId1Obj = document.getElementById('tf1_vlanId'+i);
        if (vlanId1Obj && !vlanId1Obj.disabled) {
            if (vlanId1Obj.value != "0") {
                if (numericValueRangeCheck(vlanId1Obj, "", "", 2, 4094, true, "Invalid VLAN ID.", "") == false)
                    return false;
            }
        }   
        }

	setHiddenChks(frmId);
	displayProgressBar ();
   return true;

}

/**
 * This function calls Page loads
 * Onload validation
 * @method onloadCall
 */
jQuery(function() {
	onloadCall(enableBridgeMode, {
		imageId : 'tf1_bridgeMode',
		disableIndividual : 'tf1_port tf1_vlanId tf1_vlanId1 tf1_vlanId2 tf1_vlanId3 tf1_vlanId4 tf1_vlanId5 tf1_vlanId6 tf1_vlanId7 tf1_vlanId8 tf1_vlanId9 tf1_vlanId10',
		disableGrp : '',
		enableIndividual : '',
		enableGrp : '',
		hideClass : 'hide',
		showClass : 'configRow',
		breakDivs : 'break_port break_vlanId break_vlanId1 break_vlanId2 break_vlanId3 break_vlanId4 break_vlanId5 break_vlanId6 break_vlanId7 break_vlanId8 break_vlanId9 break_vlanId10',
		breakClass : 'break',
		imagesInfo : {
			disableImages : '',
			enableImages : '',
			disableClass : '',
			enableClass : ''
		}
	})
});

/* On body load call the respective function */
window.onload = function() {
	enableBridgeMode({
		imageId : 'tf1_bridgeMode',
		disableIndividual : 'tf1_port tf1_vlanId tf1_vlanId1 tf1_vlanId2 tf1_vlanId3 tf1_vlanId4 tf1_vlanId5 tf1_vlanId6 tf1_vlanId7 tf1_vlanId8 tf1_vlanId9 tf1_vlanId10',
		disableGrp : '',
		enableIndividual : '',
		enableGrp : '',
		hideClass : 'hide',
		showClass : 'configRow',
		breakDivs : 'break_port break_vlanId break_vlanId1 break_vlanId2 break_vlanId3 break_vlanId4 break_vlanId5 break_vlanId6 break_vlanId7 break_vlanId8 break_vlanId9 break_vlanId10',
		breakClass : 'break',
		imagesInfo : {
			disableImages : '',
			enableImages : '',
			disableClass : '',
			enableClass : ''
		}
	});
}
/**
 * Wrapper function called onload
 * @method changeDhcpStatus
 * @param obj
 */
function enableBridgeMode(toggleObj) {
	onImageToggle(toggleObj);

}

/**
 * Reset function for form
 * @method enableBridgeModeOnReset
 * @param frmId Form ID
 */

function enableBridgeModeOnReset(frmId) {
	resetImgOnOff(frmId);
	enableBridgeMode({
		imageId : 'tf1_bridgeMode',
		disableIndividual : 'tf1_port tf1_vlanId tf1_vlanId1 tf1_vlanId2 tf1_vlanId3 tf1_vlanId4 tf1_vlanId5 tf1_vlanId6 tf1_vlanId7 tf1_vlanId8 tf1_vlanId9 tf1_vlanId10',
		disableGrp : '',
		enableIndividual : '',
		enableGrp : '',

		hideClass : 'hide',
		showClass : 'configRow',
		breakDivs : 'break_port break_vlanId break_vlanId1 break_vlanId2 break_vlanId3 break_vlanId4 break_vlanId5 break_vlanId6 break_vlanId7 break_vlanId8 break_vlanId9 break_vlanId10',
		breakClass : 'break',
		imagesInfo : {
			disableImages : '',
			enableImages : '',
			disableClass : '',
			enableClass : ''
		}
	});
}

