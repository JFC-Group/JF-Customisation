#!/bin/sh

OBLO_DIR="/pfrm2.0/smartcable/obloliving"
SC_DIR="/pfrm2.0/smartcable"
PF_SC_DIR="/pfrm2.0/smartcable"
TMP_LOG_DIR="/tmp/smartcablelogs"
SC_LOG_DIR="/flash/smartcable/logs"
FLASH_SC_DIR="/flash/smartcable"
SC_LOGS_SIM="/flash/smartcable/obloliving/log/smartcableLogs"
SC_DATA_SIM="/flash/smartcable/obloliving/data/smartcableData"
SH_LOGS_SIM="/flash/smartcable/obloliving/log/smartHomeLogs"

search=$(grep -qw "localhost" /etc/hosts;echo $?)

if [ $search -eq 1 ]; then
 echo "127.0.0.1 localhost" >> /etc/hosts
fi
#whitelist jioUtils broker domain
#search=$(grep -qw "pp.cats.jvts.net" /etc/hosts;echo $?)
#if [ $search -eq 1 ]; then
# echo "13.71.1.88 pp.cats.jvts.net" >> /etc/hosts
#fi

#Create folder of ohm log if not present
awk '/log.file_name/ {print $3}' /flash/obloliving/cfg/ohm/ohm.properties | awk -v string="" 'BEGIN {FS="/"}{for(i=1;i<NF;i++){if(length($i)>0){string=string"/"$i}}} END{print string}' | xargs mkdir -p
if [ ! -d "$FLASH_SC_DIR" ]; then
 mkdir $FLASH_SC_DIR
fi

if [ ! -d "$TMP_LOG_DIR" ]; then
 mkdir $TMP_LOG_DIR
fi
#Smart cable logs folder check#
if [ ! -d "$SC_LOG_DIR" ]; then
 mkdir $SC_LOG_DIR
fi
#Smart cable config folder check#
if [ ! -d ${FLASH_SC_DIR}/config ]; then
 mkdir ${FLASH_SC_DIR}/config
fi

if [ ! -f ${FLASH_SC_DIR}/config/sc.cnf ]; then
 cp -rf ${PF_SC_DIR}/sc.cnf ${FLASH_SC_DIR}/config/
fi

if [ ! -f ${FLASH_SC_DIR}/firm_1.4.0 ]; then
 cp -rf ${PF_SC_DIR}/sc.cnf ${FLASH_SC_DIR}/config/
 touch ${FLASH_SC_DIR}/firm_1.4.0
fi

enableCable=$(grep -qw "ENABLE_SMARTCABLE" ${FLASH_SC_DIR}/config/sc.cnf;echo $?)
if [ $enableCable -eq 1 ]; then
 cableActivated=$(grep -qw "SMARTCABLE_ACTIVATED=1" ${FLASH_SC_DIR}/config/sc.cnf;echo $?)
 if [ $cableActivated -eq 0 ]; then
  echo "ENABLE_SMARTCABLE=1" >> /flash/smartcable/config/sc.cnf 
 else
  echo "ENABLE_SMARTCABLE=0" >> /flash/smartcable/config/sc.cnf 
 fi
fi

dummyDevice=$(grep -qw "DUMMY_DEVICE" ${FLASH_SC_DIR}/config/sc.cnf;echo $?)
if [ $dummyDevice -eq 1 ]; then
 echo "DUMMY_DEVICE=0" >> /flash/smartcable/config/sc.cnf
fi

cableActivated=$(grep -qw "SMARTCABLE_ACTIVATED" ${FLASH_SC_DIR}/config/sc.cnf;echo $?)
if [ $cableActivated -eq 1 ]; then
 enableCable=$(grep -qw "ENABLE_SMARTCABLE=1" ${FLASH_SC_DIR}/config/sc.cnf;echo $?)
 if [ $enableCable -eq 0 ]; then
  echo "SMARTCABLE_ACTIVATED=1" >> /flash/smartcable/config/sc.cnf 
 else
  echo "SMARTCABLE_ACTIVATED=0" >> /flash/smartcable/config/sc.cnf 
 fi
fi

iptablesNew=$(grep -qw "portExists" ${FLASH_SC_DIR}/iptables.sh;echo $?)
if [ $iptablesNew -eq 1 ]; then
 cp -rf ${PF_SC_DIR}/iptables.sh ${FLASH_SC_DIR}/iptables.sh
 chmod +x ${FLASH_SC_DIR}/iptables.sh
fi

if [ ! -f ${FLASH_SC_DIR}/firmware_file_version.txt ]; then
 cp -rf ${PF_SC_DIR}/firmware_file_version.txt ${FLASH_SC_DIR}/
fi

#if [ ! -f ${FLASH_SC_DIR}/ota.zip ]; then
 cp -rf ${PF_SC_DIR}/ota/ota.zip ${FLASH_SC_DIR}/
#fi


#Smart cable db folder check #
if [ ! -d ${FLASH_SC_DIR}/db ]; then
 mkdir ${FLASH_SC_DIR}/db
fi

export LD_LIBRARY_PATH=${SC_DIR}/lib:${LD_LIBRARY_PATH}


disabled=$(grep -qw "ENABLE_SMARTCABLE=0" ${FLASH_SC_DIR}/config/sc.cnf;echo $?)
if [ -d "$OBLO_DIR" ]; then
 # Run oblo script #
 echo "Oblo directory exists"
 chmod -R +x "$OBLO_DIR"
 if [ -f "${FLASH_SC_DIR}/iptables.sh" ]; then
  cp -rf ${PF_SC_DIR}/iptables.sh ${FLASH_SC_DIR}/iptables.sh
  chmod +x "${FLASH_SC_DIR}/iptables.sh"
  "${FLASH_SC_DIR}/iptables.sh"
 else
  echo "file not found iptables.sh in /flash/smartcable"
  cp -rf ${PF_SC_DIR}/iptables.sh ${FLASH_SC_DIR}/iptables.sh
  chmod +x ${FLASH_SC_DIR}/iptables.sh
  "${FLASH_SC_DIR}/iptables.sh"
 fi

 if [ -f "$OBLO_DIR/run_jco4032.sh" ]; then
   killall -9 run_jco4032.sh
   killall -9 runsmartcableONTApp.sh smartcableONTApp
   killall -9 systemManager; killall -9 oblomb; killall -9 oblomanager;
   killall -9 systemManager; killall -9 oblomb; killall -9 oblomanager;
  #If cable is disabled dont run smartcable app #
  if [ $disabled -ne 0 ]; then
    echo "starting oblo"
    $OBLO_DIR/run_jco4032.sh start &
  fi
  if [ -f "$SC_DIR/bin/runsmartcableONTApp.sh" ]; then
   #sleep 30
   if [ ! -L "$SC_LOGS_SIM" ]; then
    ln -s /flash/smartcable/logs/ $SC_LOGS_SIM ;
   fi
    
   if [ ! -L "$SC_DATA_SIM" ]; then
    ln -s /flash/smartcable/db/ $SC_DATA_SIM ;
   fi 
   if [ ! -L "$SH_LOGS_SIM" ]; then
    ln -s $TMP_LOG_DIR $SH_LOGS_SIM ;
   fi
   port=$(ls /dev/ttySmartcable* | awk '{if(NR==1)print $1;}')
   echo "${port}"
   echo -n -e '\x7b\x2a\x8e\x2a\x7d' > ${port}
   echo "starting smartcable app"
   killall -9 runsmartcableONTApp.sh smartcableONTApp
   $SC_DIR/bin/runsmartcableONTApp.sh &
  else
   echo "file not found runsmartcableONTApp.sh"
  fi
 else
  echo "file not found run_jco4032.sh"
 fi
else
 echo "${OBLO_DIR} directory doesnt exist. Oblo living is not installed" 
fi

