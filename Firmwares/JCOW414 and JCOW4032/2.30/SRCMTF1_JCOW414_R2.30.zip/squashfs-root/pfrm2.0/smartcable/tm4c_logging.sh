#/bin/sh


ls /dev/ttySmartcable* > /tmp/tm4c.log
cat /tmp/usbPort.txt >> /tmp/tm4c.log
portNum=$(ls /sys/bus/usb/devices/*:*/tty | awk 'END {print substr($1,7,7)}')
echo "$(date) /dev/ttySmartcable${portNum}" >> /tmp/tm4c.log

cat /dev/ttySmartcable${portNum} >> /tmp/tm4c.log &
echo "Running in background /dev/ttySmartcable${portNum}"

#sleep 10m
sleep 2m
fileSize=$(ls -l /tmp/tm4c.log | awk '/tm4c.log/ {print $5}')
echo "$fileSize"
if [ $fileSize -lt 750 ]; then
 echo "fileSize is less than 750" >> /tmp/tm4c.log &
 pid=$(ps | grep 'cat /dev/ttySmartcable*' | awk '/ttySmartcable[0-9]/ {print $1}')
 echo "pid is $pid"
 kill -9 $pid
 portNum=$(ls /sys/bus/usb/devices/*:*/tty | awk 'END {print substr($1,7,7)}')
 echo "$(date) /dev/ttySmartcable${portNum}" >> /tmp/tm4c.log
 tail -f /dev/ttySmartcable${portNum} >> /tmp/tm4c.log &

 sleep 15m
 pid=$(ps | grep 'tail -f /dev/ttySmartcable*' | awk '/ttySmartcable[0-9]/ {print $1}')
 echo "pid is $pid"
 kill -9 $pid

else
 sleep 13m
 pid=$(ps | grep 'cat /dev/ttySmartcable*' | awk '/ttySmartcable[0-9]/ {print $1}')
 echo "pid is $pid"
 kill -9 $pid
fi
echo "$(date) end" >> /tmp/tm4c.log

