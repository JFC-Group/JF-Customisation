--[[
#### Ashutosh Gautam.
#### TeamF1
#### www.TeamF1.com
#### Aug 09, 2013

#### File: dhcpv6Relay.lua
#### Description: dhcpv6Relay functions

#### Revisions:
]]--


--************* Requires *************

--************* Initial Code *************
--package dhcpv6Relay
dhcpv6Relay = {}
--************* Functions *************
-- dhcpv6Relay update Configuration

--******************************************************************************
	--The component specific functions 
--******************************************************************************

function dhcpv6Relay.config (inputTable, rowid, operation)
    local DBTable = "dhcpv6Relay"

    if (operation == "add") then
        return db.insert(DBTable, inputTable)
    elseif (operation == "edit") then
        return db.update(DBTable,inputTable,rowid)
    elseif (operation == "delete") then
        return false
    end
end

--********************************************************************************
--@name dhcpv6Relay.confGet (name)
--
--@description  - The function will get the table from the database
--		The function will check for the following-
--
--@param name -The networkname recevied from the management interface
--			
--@return 
--

function dhcpv6Relay.confGet(LogicalIfName)
	local dhcpv6RelayVar = {}
    local conf = {}
    local err, status = "ERROR", "DB_ERROR_TRY_AGAIN"
	local query = {}
    
    -- construct the query
	query = "logicalIfName='" .. LogicalIfName .. "'"
    -- get the tables according to the query
    dhcpv6RelayVar = db.getRowWhere("dhcpv6Relay", query ,false)
    if (dhcpv6RelayVar == nil ) then
        -- return the error status and nil value 
		return err, status, dhcpv6RelayVar
	end
	
    -- now load the values into the inputTable
    conf["dhcpv6RelayStatus"] = dhcpv6RelayVar["dhcpv6RelayStatus"] 
    conf["relayGw"] = dhcpv6RelayVar["relayGateway"]

    -- return the input Table
	return "OK", "SUCCESS", conf
end

--********************************************************************************
--@name dhcpv6Relay.defConfGet ()
--
--@description get the default relay configuration
--
--@param n/a
--			
--@return defconf
--

function dhcpv6Relay.defConfGet()
    local dhcpv6RelayVar = {}    

    -- by default disable the relay
    dhcpv6RelayVar["dhcpv6RelayStatus"] = 0
    dhcpv6RelayVar["relayGateway"] = "0::0" 
    dhcpv6RelayVar["interfaceID"] = "0"
    
    return dhcpv6RelayVar
end        

--********************************************************************************
--@name dhcpv6Relay.confEdit (inputTable)
--
--@description  - The function will edit the table in the database
--		The function will check for the following-
--
--@param inputTable -The inputTable recevied from the management interface
--			
--@return 
--

function dhcpv6Relay.confEdit(conf)
	local dhcpv6RelayVar = {}
    local err, errCode = "ERROR", "DHCP_RELAY_INVALID_PARAMS"
	local query = {}
    local insert = 0
    local valid = false
    local status = "ERROR"
    
    if (conf["LogicalIfName"] == nil) then
        return err, errCode
    end    
    
    -- construct the query
	query = "logicalIfName='" .. conf["LogicalIfName"] .. "'"
    -- get the Row
    dhcpv6RelayVar = db.getRowWhere("dhcpv6Relay", query ,false)
    if (dhcpv6RelayVar == nil) then
        dhcpv6RelayVar = dhcpv6Relay.defConfGet()        
        dhcpv6RelayVar["logicalIfName"] = conf["LogicalIfName"]
        insert = 1
    end

    if (conf["dhcpv6RelayStatus"] ~= nil) then
        dhcpv6RelayVar["dhcpv6RelayStatus"] = tonumber(conf["dhcpv6RelayStatus"])
    end    

    if (conf["relayGw"] ~= nil) then
        -- copy the relay gateway
        dhcpv6RelayVar["relayGateway"] = conf["relayGw"] 
    end        
  
    dhcpv6RelayVar = util.addPrefix(dhcpv6RelayVar, "dhcpv6Relay.")
    if (insert > 0) then
	    valid, errstr = dhcpv6Relay.config (dhcpv6RelayVar, -1, "add")
    else
    	valid, errstr = dhcpv6Relay.config (dhcpv6RelayVar,
                                            dhcpv6RelayVar["dhcpv6Relay._ROWID_"], "edit")
    end

    if (not valid) then
        status = "ERROR"
        errCode = "DHCPV6_RELAY_DB_ERR"
    else
        status = "OK"
        errCode = "STATUS_OK"
    end                

	return status, errCode
end

--********************************************************************************
--@name dhcpv6Relay.confDelete ()
--
--@description delete dhcp relay configuration
--
--@param n/a
--			
--@return status, errCode
--

function dhcpv6Relay.confDelete (conf)
    local status, errCode = "ERROR", "DHCPV6_RELAY_INVALID_PARAMS"
	local query = {}
    local valid , errstr
    
    if (conf["logicalIfName"] == nil) then
        return status, errCode
    end    
    
    query = "logicalIfName='" .. conf["logicalIfName"] .. "'"
    valid, errstr = db.deleteRowWhere ("dhcpv6Relay", query)
    if (not valid) then
        return status, "DHCPV6_RELAY_CONF_NOT_FOUND"
    end        

    return "OK", "STATUS_OK"
end

--********************************************************************************
--@name dhcpv6Relay.import (inputTable)
--
--@description  - The function will import the table in the database
--		The function will check for the following-
--
--@param inputTable -The inputTable recevied from the management interface
--			
--@return 
--

function dhcpv6Relay.import (inputTable, defaultCfg, remCfg)
    if (inputTable == nil) then
        inputTable = defaultCfg
    end

    --initializing a temp table
    local configTable = {}

    if (inputTable ~= nil) then 	
    	configTable = config.update (inputTable, defaultCfg, remCfg)
        if (configTable ~= nil and #configTable ~= 0) then
            for i,v in ipairs (configTable) do
                if (v ~= nil) then
                    v = util.addPrefix (v, "dhcpv6Relay.")
                    db.insert("dhcpv6Relay", v)
                end
            end
    	end
    end
end

--********************************************************************************
--@name dhcpv6Relay.export ()
--
--@description  - The function will export the table in the database
--		The function will check for the following-
--
--@param inputTable -The inputTable recevied from the management interface
--			
--@return 
--

function dhcpv6Relay.export ()
    -- local table
    local table = {}
    -- this function call returns all the table feilds and stores it in table
    table =  db.getTable ("dhcpv6Relay", false)
    return table
end

--************************************CONFIG*************************************
if (config.register) then
   config.register("dhcpv6Relay", dhcpv6Relay.import, dhcpv6Relay.export, "1")
end
