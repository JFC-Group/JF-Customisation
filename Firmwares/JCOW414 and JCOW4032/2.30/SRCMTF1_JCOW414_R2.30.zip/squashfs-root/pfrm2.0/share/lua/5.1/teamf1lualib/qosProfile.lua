--[[
#### Copyright (c) 2012, TeamF1, Inc.
#### File: qosProfile.lua
#### Description: 
#### Revisions:
]]--

qos.profile = {}
qos.profile.def = {}
qos.profile.def.class = {}
qos.profile.def.class[1] = {}
qos.profile.def.class[1]["QueueKey"]=""         -- QueueKey
qos.profile.def.class[1]["QueueName"]="root_"   -- root_profileId
qos.profile.def.class[1]["ProfileKey"]=""       -- profileId
qos.profile.def.class[1]["ParentId"]=""         -- n/a
qos.profile.def.class[1]["QueueId"]=""          -- profileId:0
qos.profile.def.class[1]["QueueLevel"]="0"
qos.profile.def.class[1]["QueueEnabled"]="1"
qos.profile.def.class[1]["ConfigDefault"]="1"
qos.profile.def.class[1]["QosEleType"]="1"
qos.profile.def.class[1]["QosQdiscType"]="1"
qos.profile.def.class[1]["HTBDefaultClass"]="2"
qos.profile.def.class[2]={}
qos.profile.def.class[2]["QueueKey"]=""         -- QueueKey
qos.profile.def.class[2]["QueueName"]=""        -- node_profileId
qos.profile.def.class[2]["ProfileKey"]=""       -- profileId
qos.profile.def.class[2]["ParentId"]=""         -- profileId:0
qos.profile.def.class[2]["QueueId"]=""          -- profileId:1 
qos.profile.def.class[2]["QueueLevel"]="1"
qos.profile.def.class[2]["QueueEnabled"]="1"
qos.profile.def.class[2]["ConfigDefault"]="1"
qos.profile.def.class[2]["QosEleType"]="2"
qos.profile.def.class[2]["QosClassType"]="1"
qos.profile.def.class[2]["HTBClassPrecedence"]="0"
qos.profile.def.class[3]={}
qos.profile.def.class[3]["QueueKey"]=""         -- QueueKey
qos.profile.def.class[3]["QueueName"]=""        -- def_profileId
qos.profile.def.class[3]["ProfileKey"]=""       -- profileId
qos.profile.def.class[3]["ParentId"]=""         -- profileId:1
qos.profile.def.class[3]["QueueId"]=""          -- profileId:2
qos.profile.def.class[3]["QueueLevel"]="2"
qos.profile.def.class[3]["QueueEnabled"]="1"
qos.profile.def.class[3]["ConfigDefault"]="1"
qos.profile.def.class[3]["QosEleType"]="3"
qos.profile.def.class[3]["QosClassType"]="1"
qos.profile.def.class[3]["RateUnitType"]="2"
qos.profile.def.class[3]["HTBShapingRate"]="30"
qos.profile.def.class[3]["HTBShapingRateMax"]="100"
qos.profile.def.class[3]["HTBClassPrecedence"]="3"
qos.profile.def.class[3]["QosQdiscType"]="2"
qos.profile.def.class[3]["REDlatency"]="500"
qos.profile.def.rules = {}
qos.profile.def.rules[1] = {}
qos.profile.def.rules[1]["IngressInterface"] = "LOCAL:"
qos.profile.def.rules[1]["ClassificationOrder"] = "1"
qos.profile.def.rules[1]["Protocol"] = "0"
qos.profile.def.rules[1]["Service"] = "ANY"
qos.profile.def.rules[1]["ClassificationEnable"] = "1"
qos.profile.def.rules[1]["ProfileKey"] = ""
qos.profile.def.rules[1]["ForwardingPolicy"] = "-2"
qos.profile.def.rules[1]["EthernetPriorityMark"] = "-1"
qos.profile.def.rules[1]["ConfigDefault"] = "1"

-------------------------------------------------------------------------------
-- @name qos.profile.create
--
-- @description This function creates a qos profile
--
-- @param name profile name
--
-- @return  0 for success, < 0 for failure
-- @return  errCode error code string
--

function qos.profile.create (name)
	local ret
	local errCode
	local profile= {}

	if (name == nil) then
		return -1, "QOS_INVALID_PROFILE_NAME"
	end

	-- initialize the profile
	profile["qosProfile.ProfileName"] = name
	profile["qosProfile.ProfileKey"] = 0

	-- add the profile to the daemon
	profileId, errCode = qosLib.profileCreate(name)
	if (profileId < 0) then
		return ret, errCode
	end

	profile["qosProfile.ProfileKey"] = profileId
	profile["qosProfile.BandwidthProfileStatus"] = "1"

	-- update the database 
	ret, errCode = db.insert("qosProfile", profile)
	if (not ret) then
        return -1, errCode
	end

    profile = util.removePrefix(profile, "qosProfile.")

	return 0, "STATUS_OK", profile
end

-------------------------------------------------------------------------------
-- @name qos.profile.delete 
--
-- @description This function deletes  a qos profile.
--
-- @param 
--
-- @return  0 for success, < 0 for failure
-- @return  errCode error code string
--

function qos.profile.delete (name)
	local ret
	local errCode

	if (name == nil) then
		return -1, "QOS_INVALID_PROFILE_NAME"
	end

    local profileId = qos.profile.NameToId (name)
    if (profileId == nil) then
		return -1, "QOS_INVALID_PROFILE_NOEXIST"
    end        

	-- delete the entry from the daemon
	ret, errCode = 	qosLib.profileDestroy(name)
	if (ret < 0) then
        qos.dprintf("profile.delete:failed to destroy profile")
		return ret, errCode
	end

	-- delete the entry from the database
	query = "ProfileName='" .. name .. "'"
	ret, errCode = db.deleteRowWhere("qosProfile", query)
	if (ret) then
		return 0, "STATUS_OK"
	else
		return -1, errCode
	end
end

-------------------------------------------------------------------------------
-- @name qos.profile.idToName
--
-- @description This function gets the profile name for the given profile ID
--
-- @param 
--
-- @return  profile name or nil
--

function qos.profile.idToName (ProfileKey)
    local ProfileName

	if (ProfileKey == nil) then
		return nil, "QOS_INVALID_PROFILE_ID"
	end

    ProfileName = qosLib.profileIdToName(ProfileKey)
    if (ProfileName == nil) then
	    ProfileName= db.getAttribute("qosProfile", "ProfileKey", 
									 ProfileKey, "ProfileName")
    end        

	return ProfileName
end

-------------------------------------------------------------------------------
-- @name qos.profile.NameToId
--
-- @description This function gets the profile ID for the given profile name
--
-- @param 
--
-- @return ProfileKey
--

function qos.profile.NameToId (ProfileName)
    local ProfileKey

	if (ProfileName == nil) then
		return nil, "QOS_INVALID_PROFILE_NAME"
	end

    ProfileKey = qosLib.profileNameToId(ProfileName)
    if (ProfileKey == nil) then
	    ProfileKey = db.getAttribute("qosProfile", "ProfileName", 
		    						 ProfileName, "ProfileKey")
    end

	return ProfileKey
end

-------------------------------------------------------------------------------
-- @name qos.profile.get
--
-- @description The function gets the qos profile with the given name or ID
--
-- @param profile name or ID
--
-- @return profile or nil
--

function qos.profile.get (ProfileId)
    local query = nil
    local profile = nil

    query = "ProfileKey='" .. ProfileId .. "' or " ..
            "ProfileName='" .. ProfileId .. "'"

    profile = db.getRowWhere("qosProfile", query, false)
    if (profile == nil) then
        return "ERROR","QOS_PROF_ERR_ENOENT"
    end

    return profile
end

-------------------------------------------------------------------------------
-- @name qos.profile.tableGet
--
-- @description This function gets the list of qos profiles that matches the
-- given search criteria.
--
-- @param query search criteria
--
-- @return OK or ERROR
-- @return errCode
-- @return table of profiles
--

function qos.profile.tableGet (query)
    local rows = {}

    if (query == nil) then            
        rows = db.getTable("qosProfile", false)
    else                
        rows = db.getRowsWhere("qosProfile", query, false)
    end

    if (rows == nil) then
        qos.dprintf("profile.tableGet: no results from the search query")
        return "ERROR","QOS_ERR_PROF_NOENT"        
    end        

    return "OK", "STATUS_OK", rows
end

-------------------------------------------------------------------------------
-- @name qos.profile.cfgByQueryGet
--
-- @description This functions gets the qos profile that matches the given
-- search criteria.
--
-- @param search criteria
--
-- @return OK or ERROR
-- @return errCode
-- @return profile
--

function qos.profile.cfgByQueryGet (query)
    local row = {}

    if (query == nil) then
        qos.dprintf("profile.get: failed to get qos profile");
        return "ERROR","QOS_ERR_PROF_GET_INVALID_ARGS"
    end
            
    -- check if the profile exists
    row = db.getRowWhere("qosProfile", query, false)
    if (row == nil) then
        qos.dprintf("profile.get: qos profile not found")
        return "ERROR","QOS_ERR_PROF_NOENT"        
    end        

    return "OK", "STATUS_OK", row
end

-------------------------------------------------------------------------------
-- @name qos.profile.bwLimitStatusGet
--
-- @description This function gets the status of bandwidth limiting in this
-- qos profile
--
-- @param ProfileId  profile key or profile name.
--
-- @return 1 if enabled , 0 if disabled, -1 in case of error
--

function qos.profile.bwLimitStatusGet (ProfileId)
    local query = nil

    if (ProfileId == nil) then
        return -1
    end
            
    local profile = qos.profile.get(ProfileId)
    if (profile == nil) then
        return -1
    end        

    if (profile["BandwidthProfileStatus"] == nil) then
        return 0
    end        
                
    return (tonumber(profile["BandwidthProfileStatus"]))                
end

-------------------------------------------------------------------------------
-- @name qos.profile.ifaceTableGet
--
-- @description This function gets interface on which this profile is installed.
--
-- @param ID profile ID
--
-- @return OK or ERROR
-- @return error code
-- @return table of qos interface settings on which the profile has been set
--

function qos.profile.ifaceTableGet(ID)
    local query 
    local status
    local errCode

    if (ID == nil) then
        return "ERROR","QOS_PROF_ERR_INVALID_ARGS"
    end
                
    -- check if the profile exists
    local profile = qos.profile.get(ID)
    if (profile == nil) then
        return "ERROR","QOS_PROF_ERR_NOTEXISTS"
    end        
    
    query = "ProfileKey=" .. ID            
    status, errCode, ifTbl = qos.iface.tableGet(query)
    if (status ~= "OK") then
        return "ERROR","QOS_PROF_ERR_NOTINSTALLED"
    end        

    return "OK", "STATUS_OK", ifTbl
end

-------------------------------------------------------------------------------
-- @name qos.profile.ifaceTableGet
--
-- @description This function gets list of interfaces on which this 
-- profile is installed.
--
-- @param ID profile ID
--
-- @return OK or ERROR
-- @return error code
-- @return list of interfaces on which the profile has been set
--

function qos.profile.ifaceTableGet(ID)
    local query 
    local status
    local errCode

    if (ID == nil) then
        return "ERROR","QOS_PROF_ERR_INVALID_ARGS"
    end
                
    -- check if the profile exists
    local profile = qos.profile.get(ID)
    if (profile == nil) then
        return "ERROR","QOS_PROF_ERR_NOTEXISTS"
    end        
    
    query = "ProfileKey=" .. ID            
    status, errCode, ifTbl = qos.iface.tableGet(query)
    if (status ~= "OK") then
        return "ERROR","QOS_PROF_ERR_NOTINSTALLED"
    end        

    return "OK", "STATUS_OK", ifTbl
end

-------------------------------------------------------------------------------
-- @name qos.profile.ifaceGet
--
-- @description This function gets interface on which this profile is installed.
--
-- @param ID profile ID
--
-- @return OK or ERROR
-- @return error code
-- @return interface on which the profile has been set
--

function qos.profile.ifaceGet(ID)
    local query 
    local status
    local errCode

    if (ID == nil) then
        return "ERROR","QOS_PROF_ERR_INVALID_ARGS"
    end
                
    -- check if the profile exists
    local profile = qos.profile.get(ID)
    if (profile == nil) then
        return "ERROR","QOS_PROF_ERR_NOTEXISTS"
    end        
    
    query = "ProfileKey=" .. ID            
    local status, errCode, iface = qos.iface.cfgByQueryGet(query)
    if (status ~= "OK") then
        return "ERROR","QOS_PROF_ERR_NOTINSTALLED"
    end        

    return "OK", "STATUS_OK", iface
end

-------------------------------------------------------------------------------
-- @name qos.profile.bwLimitEnable
--
-- @description This function enables bandwitdh limiting on the given profile
-- If input is nil, then bandwitdh limiting is enabled on all the profiles.
--
-- @param ID profile ID or nil
--
-- @return OK or ERROR
--

function qos.profile.bwLimitEnable (ID)
    local query = nil
    local status
    local errCode
    local profTbl = {}

    if (ID ~= nil) then
        query = "ProfileKey='" .. ID .. "'"
    end        

    status, errCode, profTbl =  qos.profile.tableGet (query)
    if (status ~= "OK") then
        return "ERROR", "QOS_PROF_ERR_ENOENT"
    end
            
    for k,v in pairs(profTbl) do
        status = qosLib.profileRlEnable(v["ProfileKey"])
        if (status == 0) then
            db.setAttribute("qosProfile", "ProfileKey", v["ProfileKey"],
                            "BandwidthProfileStatus", "1")
        end
    end                    

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name qos.profile.bwLimitDisable
--
-- @description This function disables bandwitdh limiting on the given profile.
-- If input is nil, then bandwitdh limiting is disabled on all its profiles. 
--
-- @param ID profile ID or nil
--
-- @return OK or ERROR
--

function qos.profile.bwLimitDisable (ID)
    local query = nil
    local status
    local errCode
    local profTbl = {}

    if (ID ~= nil) then
        query = "ProfileKey='" .. ID .. "'"
    end        

    status, errCode, profTbl =  qos.profile.tableGet (query)
    if (status ~= "OK") then
        return "ERROR", "QOS_PROF_ERR_ENOENT"
    end
            
    for k,v in pairs(profTbl) do
        status = qosLib.profileRlDisable(v["ProfileKey"])
        if (status == 0) then
            db.setAttribute("qosProfile", "ProfileKey", v["ProfileKey"],
                            "BandwidthProfileStatus", "0")
        end
    end                    

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name qos.profile.init
--
-- @param 
--
-- @description This function initialises the profile by creating default 
-- classes in its configuration
--
-- @return 0 for success, < 0 for error
--

function qos.profile.init (profileId)
    local class = {}
    
    -- allocate a new ID for the default queues
    local QueueKey = qos.classQueue.maxIDGet()

    for k,v in pairs(qos.profile.def.class) do
        class = v
        class["QueueKey"]= QueueKey
        QueueKey = QueueKey + 1

        if (tonumber(v["QueueLevel"]) == 0) then
            class["QueueName"]="root_" .. profileId  
            class["ProfileKey"]= profileId      
            class["ParentId"]="root"     
            class["QueueId"]=profileId .. ":0"
        elseif (tonumber(v["QueueLevel"]) == 1) then            
            class["QueueName"]="node_" .. profileId  
            class["ProfileKey"]= profileId      
            class["ParentId"]=profileId .. ":0"
            class["QueueId"]=profileId .. ":1"
        elseif (tonumber(v["QueueLevel"]) == 2) then            
            class["QueueName"]="def_" .. profileId  
            class["ProfileKey"]= profileId      
            class["ParentId"]=profileId .. ":1"
            class["QueueId"]=profileId .. ":2"
        end        

        qos.dprintf("DEF CLASS: " .. util.tableToStringRec(class))
        ret, errCode = qos.classQueue.add (class)
        if (ret < 0) then
            qos.dprintf("failed to add default classes for " ..
                        "profileId=" ..profileId .. ". Error:" .. errCode)
            -- TODO: Cleanup and exit
        end            
    end        

    -- add default rules 
    local rule = {}
    for k,v in pairs(qos.profile.def.rules) do
        rule = v
        rule["ProfileKey"]= profileId      

        qos.dprintf("DEF RULE: " .. util.tableToStringRec(rule))
        ret, errCode = qos.rule.add(rule)
        if (ret < 0) then
            qos.dprintf("failed to add default rules for " ..
                        "profileId=" ..profileId .. ". Error:" .. errCode)
            -- TODO: Cleanup and exit
        end            
    end        

    return 0, "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name qos.profile.deinit
--
-- @param profileId
--
-- @description This function de-initialises the profile 
--
-- @return 0 for success, < 0 for error
--

function qos.profile.deinit (profileId)
    local classId
    
    -- remove default rules
    for k,v in pairs(qos.profile.def.rules) do
        local query = "ProfileKey=" .. profileId .. 
                      " and ForwardingPolicy=-2"
        local status, errCode, rule = qos.rule.cfgByQueryGet(query)
        if (rule ~= nil) then
            local ret, errCode = qos.rule.delete (rule["ClassificationKey"])
            if (ret < 0) then
                qos.dprintf("failed to delete default rule for " ..
                            "profileId=" ..profileId .. ". Error:" .. errCode)
                -- TODO: Cleanup and exit
            end            
        end            
    end        
    
    -- remove default classes
    for k,v in pairs(qos.profile.def.class) do
        if (tonumber(v["QueueLevel"]) == 0) then
            classId = "root_" .. profileId  
        elseif (tonumber(v["QueueLevel"]) == 1) then            
            classId = "node_" .. profileId  
        elseif (tonumber(v["QueueLevel"]) == 2) then            
            classId = "def_" .. profileId  
        end        

        local ret, errCode = qos.classQueue.delete (classId)
        if (ret < 0) then
            qos.dprintf("failed to delete default classes for " ..
                        "profileId=" ..profileId .. ". Error:" .. errCode)
            -- TODO: Cleanup and exit
        end            
    end        

    return 0, "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name qos.profile.newClassIDGet
--
-- @param profileId
--
-- @description This function allocates a new classId in this profile
--
-- @return classId or nil
--

function qos.profile.newClassIDGet (ProfileKey)
    local query = "ProfileKey=" .. ProfileKey
    local classId = 0
    local maxId = 0

    -- Get all the classes belonging to this profile
    local status, errCode, queueTbl = qos.classQueue.tableGet (query)
    if (queueTbl == nil) then
        -- default classes not configured yet.
        return nil
    end        

    -- Get the max of all class ID's
    for k,v in pairs(queueTbl) do
        local splitparts = util.split(v["QueueId"], ":")
        classId = tonumber(splitparts[2])
        if (classId >= maxId) then
            maxId = classId
        end            
    end        

    -- return the next class ID
    return maxId + 1
end
