--[[
#### Copyright (c) 2014, TeamF1 Networks Pvt. Ltd. 
#### (Subsidiary of D-Link India)

#### 
#### File: tr181_captivePortalTrExtn.lua
#### Description: 
#### TR-181 handlers for Captive Portal. This file is included from tr181_tr69funcs.lua
####

#### Revisions:
01b,11Aug15,swr changes for SPR 52869 
01a,10oct14,swr written 
]]--

captivePortalTr = {}

--[[
--*****************************************************************************
-- captivePortalTr.fwRulesExec: add/delete the firewall rules.
--                  
-- This function is called to add/delete the firewall rules 
--
-- Returns: 
]]--
function captivePortalTr.fwRulesExec()
    local ContentFilterRow      = {}
    local macFilterConfigRow    = {}
    local CaptivePortalRow      = {}
    local p2pSesLimitRow        = {}
    local qosQueueManagementRow = {}
    local BwMonRow              = {}

    --To get the status of all the component
    BwMonRow                = db.getRow("BwMon", "_ROWID_", "1")
    ContentFilterRow        = db.getRow("ContentFiltering", "_ROWID_", "1")
    macFilterConfigRow      = db.getRow("macFilterConfig", "_ROWID_", "1")
    p2pSesLimitRow          = db.getRow("p2pSessionLimit", "_ROWID_", "1")
    captivePortalRow        = db.getRow("CaptivePortal", "_ROWID_", "1")
    qosQueueManagementRow   = db.getRow("qosQueueManagement", "_ROWID_", "1")


    -- if any of the component is enable then Delete the Firewall Rules
    if ((tonumber(ContentFilterRow["ContentFiltering.Status"]) + tonumber(macFilterConfigRow["macFilterConfig.MACFilteringStatus"]) + tonumber(p2pSesLimitRow["p2pSessionLimit.p2pSessionLimitStatus"]) + tonumber(captivePortalRow["CaptivePortal.enable"]) +tonumber(qosQueueManagementRow["qosQueueManagement.Enable"]) + tonumber(BwMonRow["BwMon.enable"]))== 1) then
        -- Deleting Firewall Rules
        os.execute("/pfrm2.0/bin/fwRulesScript.sh 0 &")
    -- if all the component are disable then Add the Firewall Rules
    elseif((tonumber(ContentFilterRow["ContentFiltering.Status"]) + tonumber(macFilterConfigRow["macFilterConfig.MACFilteringStatus"]) + tonumber(p2pSesLimitRow["p2pSessionLimit.p2pSessionLimitStatus"]) + tonumber(captivePortalRow["CaptivePortal.enable"]) + tonumber(qosQueueManagementRow["qosQueueManagement.Enable"]) + tonumber(BwMonRow["BwMon.enable"])) == 0) then
        -- Adding Firewall Rules
        os.execute("/pfrm2.0/bin/fwRulesScript.sh 1 &")
    end
end

--[[
--*****************************************************************************
-- captivePortalTr.captivePortalGet: get the CaptivePortal values.
--                  
-- This function is called to get the following parameters in
-- Device.CaptivePortal.
--
-- Enable
-- Status
-- AllowedList
-- URL
-- 
-- Returns: status, value
]]--
function captivePortalTr.captivePortalGet(input)
    local status = "0"
    local value = "0"
    local row = {}
    local query = nil
    local param = input["param"]
    local captPortalRow = {}
    local comma = 0

    --get corresponding db entry from CaptivePortal 
    query = "_ROWID_=1"
    row = db.getRowWhere ("CaptivePortal", query, false)
    if (row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end
 
    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = row["enable"]
    elseif(string.find(input["param"], "Status")) then
        -- Status
        if (row["enable"] == "1") then
            value="Enabled"
        else
            value="Disabled"
        end
    elseif(string.find(input["param"], "AllowedList")) then
        local capPortSessionRows = db.getTable("CaptivePortalSession", false)
        local ipAddrList = ""
        -- AllowedList
        if (capPortSessionRows ~= nil) then
            for k,v in pairs (capPortSessionRows) do
                if (v["ipAddr"] ~= nil) then
                    if (comma == 1) then
                        ipAddrList = ipAddrList .. ","
                    end
                    ipAddrList = ipAddrList .. v["ipAddr"] 
                    comma = 1
                end 
            end
        end
        value = ipAddrList
    elseif(string.find(input["param"], "URL")) then
        -- URL
        query = "ifName = 'bdg2'"
        portalVlanRow = db.getRowWhere ("CaptivePortalVlan", query, false)

        if(portalVlanRow ~= nil and portalVlanRow["redirectType"] == "0") then
            iprow = db.getRowWhere("ifstatic", "LogicalIfName='IF2' and AddressFamily=2", false)
            if (iprow ~= nil and iprow["StaticIp"] ~= nil and iprow["StaticIp"] ~= "") then                                               
                value = "http://"..iprow["StaticIp"].."/platform.cgi?page=captivePortal.html"
            else
                return "1", "DB_ERROR_TRY_AGAIN"
            end
        else
            value = ""
        end
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- captivePortalTr.captivePortalSet: set CaptivePortal parameters.
--
-- This function is called to set the following parameters in
-- Device.CaptivePortal.
-- 
-- Enable
-- AllowedList
-- URL
--
-- Returns: status
-- 
]]--
function captivePortalTr.captivePortalSet(input, rowids, actionType, tr69Param)
    require "teamf1lualib/captivePortal"

    local status = OK
    local faultTbl = {}
    local index = 0
    local conf = {}
    local query = nil
    local errMsg
    local portalRow = {}
    local portalVlanRow = {}
    local operation = nil
    local rowId = nil
    local valid = false

    --get corresponding db entry from 'CaptivePortal'
    query = "_ROWID_=1"
    portalRow = db.getRowWhere ("CaptivePortal", query, false)
    if(portalRow == nil) then
        tr69Glue.tf1Dbg("Couldn't fetch corresponding CaptivePortal portalRow..")
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    if(input["CaptivePortal"]["CaptivePortal.Enable"] ~= nil) then
        conf["enable"] = input["CaptivePortal"]["CaptivePortal.Enable"]

        portalRow["enable"] = conf["enable"]
        if (conf["enable"] == "1") then
            portalVlanRow["vlanId"] = "1"
            portalVlanRow["ifName"] = "bdg2" -- in future will construct base on vlanId
            portalVlanRow["accessType"] = "2"
            portalVlanRow["authServerId"] = "0"
            portalVlanRow["profileId"] = "1"
            portalVlanRow["redirectType"] = "0"
            if (db.existsRow("CaptivePortalVlan", "ifName", "bdg2")) then
                rowId = "1"
                operation = "edit"
            else
                operation = "add"
                rowId = "-1"
            end
        elseif(conf["enable"] == "0") then
            query = "ifName = 'bdg2'"
            portalVlanRow = db.getRowWhere ("CaptivePortalVlan", query, false)
            if (portalVlanRow == nil) then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
                return status, faultTbl;
            end
            operation = "delete"
            rowId = portalVlanRow["_ROWID_"]
        end
    
        portalRow = util.addPrefix (portalRow, "CaptivePortal.");
        valid = captivePortal.Config("CaptivePortal", portalRow, "1", "edit")

        if (valid) then
            portalVlanRow = util.addPrefix (portalVlanRow, "CaptivePortalVlan.");
            valid = captivePortal.Config ("CaptivePortalVlan", portalVlanRow, rowId, operation)

            if (valid) then
                db.save()
                -- executing firewall rules
                captivePortalTr.fwRulesExec()
                return 0;
            else
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
                return status, faultTbl;
            end
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl;
        end
    end

    tr69Glue.tf1Dbg("Leaving captivePortalSet..")
    return 0; 
end


