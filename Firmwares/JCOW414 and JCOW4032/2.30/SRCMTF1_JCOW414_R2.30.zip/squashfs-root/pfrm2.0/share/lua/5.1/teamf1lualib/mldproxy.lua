-- @copyright Copyright (c) 2013, TeamF1, Inc. 

--************* Packages *************
mldproxy = {}

-------------------------------------------------------------------------
-- @name mldproxy.config
--
-- @description 
--
-- @return 
--

function mldproxy.config (tableName, inputTable, rowid, operation)
    -- validate
    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
            return db.insert(tableName, inputTable)
        elseif (operation == "edit") then
            return db.update(tableName, inputTable, rowid)
        elseif (operation == "delete") then
           for k,v in pairs(inputTable) do
                valid  = db.deleteRow(tableName, "_ROWID_", v)
                if (not valid) then  return false end
            end
        end
    end

    return false
end


-------------------------------------------------------------------------
-- @name mldproxy.import
--
-- @description 
--
-- @return 
--

function mldproxy.import (mldproxyConfig, defaultCfg, removeCfg)
    if (mldproxyConfig == nil) then
        mldproxyConfig = defaultCfg
    end

    local mldproxyTmp = {}

    mldproxyTmp = config.update (mldproxyConfig, defaultCfg, removeCfg)
    if (mldproxyTmp ~= nil and #mldproxyTmp ~= 0) then
        for i,v in ipairs (mldproxyTmp) do
            v = util.addPrefix (v, "mldproxy.");
            mldproxy.config ("mldproxy", v, -1, "add")
        end
    end
	
end

-------------------------------------------------------------------------
-- @name mldproxy.export
--
-- @description 
--
-- @return 
--

function mldproxy.export ()
	local mldproxyTbl = {}
	local table = {}

 	table = db.getTable("mldproxy" , false)
	if (table ~= nil) then
	    mldproxyTbl = table
	end

	return mldproxyTbl
end
 

if (config.register) then
   config.register("mldproxy", mldproxy.import, mldproxy.export, "1")
end

-------------------------------------------------------------------------
-- @name mldproxy.cfgInit
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function mldproxy.cfgInit (row, conf)

    if (conf["isEnabled"] ~= nil) then
        row["isEnabled"] = conf["isEnabled"]  
    end        
    
    if (conf["LogicalIfName"] ~= nil) then
        row["LogicalIfName"] = conf["LogicalIfName"]  
    end        

    if (conf["maxQueryResponseTime"] ~= nil) then
        row["maxQueryResponseTime"] = conf["maxQueryResponseTime"]  
    end

    if (conf["queryTimeout"] ~= nil) then
        row["queryTimeout"] =  conf["queryTimeout"]
    end

    if (conf["queryInterval"] ~= nil) then
        row["queryInterval"] = conf["queryInterval"]
    end

    return row
end

-------------------------------------------------------------------------
-- @name mldproxy.defCfgGet
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function mldproxy.defCfgGet()
    local conf = {}
    conf["isEnabled"] ="0"
    conf["LogicalIfName"] = "IF1"
    conf["maxQueryResponseTime"] = "10000"
    conf["queryTimeout"] = "2"
    conf["queryInterval"] = "125"

    return conf
end

-------------------------------------------------------------------------
-- @name mldproxy.configure
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function mldproxy.configure (conf)
    local query

    -- Get the mldproxy configuration
    query = "_ROWID_='1'"
    local row = db.getRowWhere("mldproxy", query, false)
    if (row ~= nil) then
        row = mldproxy.cfgInit(row, conf)

        row = util.addPrefix(row, "mldproxy.")
        local valid, errstr = db.update("mldproxy", row, row["mldproxy._ROWID_"])
        if (not valid) then
            return "ERROR", "IPV6_MLD_CONFIG_FAILED"
        end            
    else
        row = mldproxy.defCfgGet()
        row = mldproxy.cfgInit(row, conf)

        util.appendDebugOut ("conf.." .. util.tableToStringRec(row))

        row = util.addPrefix(row, "mldproxy.")
        local valid, errstr, rowid  = db.insert("mldproxy", row)
        if (not valid) then
            return "ERROR", "IPV6_MLD_CONFIG_FAILED"
        end            
    end        

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name mldproxy.get
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function mldproxy.get (query)
    local rows = {}
    local index = 1
    local cfgTbl = {}

    cfgTbl = db.getRow ("mldproxy", "_ROWID_", "1")   

    cfgTbl = util.removePrefix(cfgTbl, "mldproxy.")
    return cfgTbl
end

