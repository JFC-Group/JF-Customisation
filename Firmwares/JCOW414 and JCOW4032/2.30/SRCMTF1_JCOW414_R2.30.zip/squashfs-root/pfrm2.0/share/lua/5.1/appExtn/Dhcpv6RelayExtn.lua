-- @copyright Copyright (c) 2012, TeamF1, Inc. 

require "teamf1lualib/evtDsptch"
require "teamf1lualib/dhcpv6Relay"
require "dhcpv6RelayLib"
require "appExtn/AppExtn"

Dhcpv6RelayExtn = OoUtil.inheritsFrom(AppExtn)
Dhcpv6RelayExtn.name    = "DHCPV6 Relay"
Dhcpv6RelayExtn.className  = "Dhcpv6RelayExtn"
Dhcpv6RelayExtn.classId = "dhcp6r"
Dhcpv6RelayExtn.dbTable = ""
Dhcpv6RelayExtn.logger  = nil

local SUPER = require("appExtn.AppExtn")

local netEvents  = {}
netEvents[evtDsptch.event.IFDEV_EVENT_NET_ADD] =  1
netEvents[evtDsptch.event.IFDEV_EVENT_NET_DEL] =  1
netEvents[evtDsptch.event.IFDEV_EVENT_IP6_NET_UP] =  1
netEvents[evtDsptch.event.IFDEV_EVENT_IP_ADDR_CHG] =  1
netEvents[evtDsptch.event.IFDEV_EVENT_IP6_NET_DOWN] =  1

local cfgEvents = {}
cfgEvents[db.event.SQLITE_INSERT] = 1
cfgEvents[db.event.SQLITE_UPDATE] = 1
cfgEvents[db.event.SQLITE_DELETE] = 1

-------------------------------------------------------------------------------
-- @name Dhcpv6RelayExtn:new
--
-- @description This function creates a new instance object for dhcpv6 relay, loads
-- the configuration and event subcriptions
--
-- @return  0 for success and -1 for error
--

function Dhcpv6RelayExtn:new(instanceId, props)

    assert(instanceId, "Instance ID must be specified")

    -- create a new instance
    self = Dhcpv6RelayExtn.create()

    SUPER.new(self, Dhcpv6RelayExtn.classId, instanceId, props)

    self.name  = Dhcpv6RelayExtn.name
    self.dbTable = Dhcpv6RelayExtn.dbTable
    self.dbconn = Dhcpv6RelayExtn.dbconn
    self.logger = Dhcpv6RelayExtn.logger

    -- initialize events for this instance
    self.netEvents = netEvents              
    self.cfgEvents = cfgEvents

    local handle = db.gethandle(self.dbconn)
    dhcpv6RelayLib.init(handle)

    -- load the configuration for this instance          
    local status, errCode, self = self:load()
    if (status == nil) then
        LOG:error("failed to load " .. classId .. 
                  "(" .. instanceId .. ")")
        return nil
    end        

    -- register with appd
    appd.appExtnRegister(self)                    

    return self
end

-------------------------------------------------------------------------------
-- @name Dhcpv6RelayExtn:load
--
-- @description This function loads the dhcpv6Relay configuration
--
-- @return  
--

function Dhcpv6RelayExtn:load() 

    self.ifTbl = {}

    -- load all interfaces
    local ifTbl = db.getTable("dhcpv6Relay", false)
    if (ifTbl ~= nil) then
        self.ifTbl = ifTbl
    end        

    dhcpv6RelayLib.cfgLoad()

    return  "OK", "STATUS_OK", self
end        

-------------------------------------------------------------------------------
-- @name Dhcpv6RelayExtn:delete
--
-- @description This function destroys an instance of this extension
--
-- @return  
--

function Dhcpv6RelayExtn:delete() 
    appd.appExtnUnregister(self)
    return 
end        

-------------------------------------------------------------------------------
-- @name Dhcpv6RelayExtn:start
--
-- @description This function starts dhcpv6 relay
--
-- @return  0 for success and -1 for error
--

function Dhcpv6RelayExtn:start ()

    LOG:info("Starting " .. self.name)

    local status = dhcpv6RelayLib.start()
    if (status < 0) then
        LOG:error(self.name .. " start failed")
        return status
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name Dhcpv6RelayExtn:restart
--
-- @description This function restarts dhcpv6 relay
--
-- @return  0 for success and -1 for error
--

function Dhcpv6RelayExtn:restart ()

    LOG:info("Re-starting " .. self.name)
    local status = dhcpv6RelayLib.restart()
    if (status < 0) then
        LOG:error(self.name .. " restart failed")
        return status
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name Dhcpv6RelayExtn:getAppName
--
-- @description This function gets the name of this extension
--
-- @return  
--

function Dhcpv6RelayExtn:getAppName()
   return self.name
end

-------------------------------------------------------------------------------
-- @name Dhcpv6RelayExtn:onNetEvent
--
-- @description This function handles network events for dhcpv6 relay
--
-- @param  netevent event info
--
-- @return  0 for success and -1 for error
--

function Dhcpv6RelayExtn:onNetEvent(netevent)
    local status
    local errCode
    local conf = {}

    if (self:isEventSubscribed(netevent) == false) then
        LOG:ddebug(self.name .. " not subscribed to event: " ..
                  netevent.event .. " on " .. netevent.ifname)
        return 0
    end        

    if (netevent.event == evtDsptch.event.IFDEV_EVENT_NET_ADD) then
        status, errCode, conf = dhcpv6Relay.confGet(netevent.ifname)
        if (status ~= "OK") then
            conf = {}
            conf["LogicalIfName"] = netevent.ifname
            status, errCode = dhcpv6Relay.confEdit(conf)
            if (status ~= "OK") then
                LOG:debug("failed to add dhcpv6-relay configurationf for: " .. 
                          netevent.ifname)
            end                
        end            
    elseif (netevent.event == evtDsptch.event.IFDEV_EVENT_NET_DEL) then
        status, errCode, conf = dhcpv6Relay.confGet(netevent.ifname)
        if (status == "OK") then
            status, errCode = dhcpv6Relay.confDelete(conf)
            if (status ~= "OK") then
                LOG:debug("failed to delete dhcpv6-relay configurationf for: " .. 
                          netevent.ifname)
            end                
        end            
    else
        self:restart()
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name Dhcpv6RelayExtn:isEventSubscribed
--
-- @description This function checks if this instance is subcribed to
-- the event pass as input
--
-- @param event event info
--
-- @return  0 for success and -1 for error
--

function Dhcpv6RelayExtn:isEventSubscribed(event)

    if (event.type == appd.eventType.APPD_EV_NET) then
        require "teamf1lualib/network"
        
        -- if it is not LAN, then skip 
        if (not network.isLAN(event.ifname)) then
            return false
        end

        local evstate = self.netEvents[event.event]
        if (evstate == nil) then
            return false
        end            
                    
        if (evstate > 0) then
            return true
        end        

    elseif (event.type == appd.eventType.APPD_EV_CFG) then

        -- are we subscribed to this event                        
        local evstate = self.cfgEvents[event.event]
        if (evstate == nil) then
            return false
        end            

        if (evstate > 0) then
            return true
        end        
    end

    return false
end

-------------------------------------------------------------------------------
-- @name Dhcpv6RelayExtn:onCfgEvent
--
-- @description This function is called by appd to handle configuration events
-- 
-- @param  cfgevent event information
--
-- @return  
--

function Dhcpv6RelayExtn:onCfgEvent(cfgevent)

    if (self:isEventSubscribed(cfgevent) == false) then
        LOG:ddebug(self.name .. " not subscribed to event: " ..
                   cfgevent.event .. " on " .. cfgevent.dbTable)
        return
    end        

    -- restart dhcpv6 relay
    self:restart()

    return
end

-------------------------------------------------------------------------------
-- @name Dhcpv6RelayExtn:print
--
-- @description This function is called by appd to bootstrap all instances of 
-- this application. 
--
-- @param  
--
-- @return  
--

function Dhcpv6RelayExtn:print()
    require "util/strlib"

    LOG:info("Class     : " .. self.classId)
    LOG:info("Instance  : " .. self.instanceId)
    LOG:info("App Name  : " .. self:getAppName())
    LOG:info("Conf      : " .. strlib.serializeTbl(self:getProps()))
    return
end

-------------------------------------------------------------------------------
-- @name Dhcpv6RelayExtn.cfgEventCallback
--
-- @description This function is called by appd whenever there is a configuration
-- event.
--
-- @param  
--
-- @return  
--

function Dhcpv6RelayExtn.cfgEventCallback(obj, info)
    local status
    local errCode

    LOG:debug(DhcpRelayExtn.classId .. " configuration callback called  " .. 
              "for event: " ..  info.event .. " on rowId " .. info.rowId)

    local obj = appd.appExtnFind(Dhcpv6RelayExtn.classId, "1")
    if (obj) then 
        status, errCode, obj = obj:load()
        if (status == "OK") then
            obj:onCfgEvent(info) 
        end
    end

    return 0
end

-------------------------------------------------------------------------------
-- @name Dhcpv6RelayExtn.bootstrap
--
-- @description This function is called by appd on startup to bootstrap all 
-- instances of this application. 
--
-- @param  
--
-- @return  
--

function Dhcpv6RelayExtn.bootstrap()
    local callbackTable= {}

    dhcpRelayLib.killAll()

    local callback = {}
    callback.type = appd.eventType.APPD_EV_CFG
    callback.dbTable = "dhcpv6Relay"
    callback.routine = Dhcpv6RelayExtn.cfgEventCallback
    table.insert(callbackTable, callback)

    appd.callbackRegister (Dhcpv6RelayExtn.classId, callbackTable)

    -- create an instance 
    local instanceId = "1"
    local obj = Dhcpv6RelayExtn:new(instanceId)
    if (obj) then
        obj:start()
    end                        

    return 0
end

return Dhcpv6RelayExtn
