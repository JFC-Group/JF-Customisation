--[[
#### Copyright (c) 2010, TeamF1, Inc.
#### Oct 12, 2010
#### File: qosSw.lua
#### Description: 
#### Revisions:
01a 12Oct10, sam written
]]--

--************* Requires *************
-- XXX: qos.lua includes this file

--************* Initial Code *************

--************* Global Variables *************

qos.swport = {}
qos.swport.trustmode = {}

--[[
--**************************************************************************
-- qos.swport.trustmode.set - set trustmode for a port
--
-- This function sets the trustmode for a switch port.
--
-- RETURNS: 0 for success, < 0 for failure
]]--

function qos.swport.trustmode.set (portNum, mode)
	local ret
	local errCode

	-- validate parameters
	if ((portNum == nil) or (mode == nil)) then
		return -1, "QOS_INVALID_ARG"
	end

	portNum = tonumber(portNum)
	mode = tonumber(mode)

	-- set the mapping in the switch
	ret, errCode = qosLib.swTrustModeSet(portNum, mode)
	if (ret < 0) then
		return ret, errCode
	end

	-- save the value into the database
	ret, errCode = db.setAttribute("swPortConfig", "portNum", 
									portNum, "trustMode", mode)
	if (ret) then
		return  0, errCode;
	else
		return -1, errCode;
	end
end
	

--[[
--**************************************************************************
-- qos.swport.trustmode.get - get trustmode of a port
--
-- This function gets the trust mode for a given port in the switch
--
-- RETURNS: trustmode value, < 0 for failure
]]--

function qos.swport.trustmode.get (portNum)
	local trustMode

	if (portNum == nil) then
		return -1, "QOS_INVALID_ARG"
	end

	trustMode = db.getAttribute("swConfig", "portNum", portNum, "trustMode")
	
	return trustMode
end

--[[
--***************************************************************************
-- qos.swport.trustmode.setLanQoS - ENABLES/DISABLES the QoS in Switch. 
--
-- This function enables or disables the QoS in switch.
--
-- RETURNS: 0 success, <0 for failure
]]--

function qos.swport.trustmode.setLanQoS(status)
    local ret
    local errCode

    status = tonumber(status)

    --validate parameters
    if(status == nil or status < 0 or status > 1) then
        return -1,"QOS_INVALID_ARG"
    end
    
    --configure the lan QoS in Switch
    ret, errCode = qosLib.swLanQoSSet(status)
	if (ret < 0) then
		return ret, errCode
	end

	-- save the value into the database
  	ret, errCode = db.setAttribute("swGlobalCfg", "_ROWID_", "1", 
								   "qosEnable", status)
	if (ret) then
		return  0, errCode;
	else
		return -1, errCode;
	end
end

--[[
--*************************************************************************
-- qos.swport.getActualPortNum - Get the actual port Number. 
-- 
-- Note: The reason we are writing this routine is switch used by DEVICE may
-- have different mapping between Phy Address of the actual port and front panel
-- port Number.
--
-- RETURNS: actualPortNumber success, <0 for failure. 
]]--
function qos.swport.getActualPortNum(portNum)
    local actualPortNum
    local ret 
    local errCode

    portNum = tonumber(portNum)

    -- Get Actual Port Number in switch
    actualPortNum,errCode = qosLib.swActPortNumGet(portNum)

    if (actualPortNum < 0) then
        return -1,errCode
    else
        return actualPortNum,errCode
    end
end

--[[
--*************************************************************************
-- qos.swport.getPhyPortNum - Get the Phy Port Number from Actual Port Number. 
-- 
-- Note: The reason we are writing this routine is switch used by DEVICE may
-- have different mapping between Phy Address of the actual port and front panel
-- port Number.
--
-- RETURNS: port Number success, <0 for failure. 
]]--
function qos.swport.getPhyPortNum(actualPortNum)
    local portNum
    local ret 
    local errCode

    actualPortNum = tonumber(actualPortNum)

    -- Get Actual Port Number in switch
    portNum,errCode = qosLib.swPhyPortNumGet(actualPortNum)

    if (portNum < 0) then
        return -1,errCode
    else
        return portNum,errCode
    end
end
