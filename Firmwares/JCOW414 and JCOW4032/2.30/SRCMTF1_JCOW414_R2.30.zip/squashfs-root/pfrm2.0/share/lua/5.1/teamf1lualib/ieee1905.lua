--table packages
ieee1905 = {}

local CMD_EXEC_SCRIPT = "/tmp/cmdExecscript.sh"

--ieee1905.config
function ieee1905.config (inputTable, rowid, operation)

    -- validate
    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
            return db.insert("ieee1905", inputTable)
        elseif (operation == "edit") then
            return db.update("ieee1905", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("ieee1905", inputTable)
        end
    end
    return false

end

-- ieee1905 config
function ieee1905.ieee1905_config (inputTable, rowid, operation)

    local valid = false
    local registrarName
    local cmdStr = "/pfrm2.0/bin/al_entity -m "
    if (operation == "add") then
        bootFlag = "1"
    else
        bootFlag = "0"
    end

    -- update the database
    valid = ieee1905.config(inputTable, rowid, operation)

    local iptableDropCmd = "/pfrm2.0/bin/iptables -D fwInBypass -p tcp --dport 8888 -j ACCEPT"
    local iptableAddCmd = "/pfrm2.0/bin/iptables -A fwInBypass -p tcp --dport 8888 -j ACCEPT"
    local ebtableDropCmd = "/usr/sbin/ebtables -D FORWARD -d 01:80:c2:00:00:13 -j DROP"
    local ebtableAddCmd = "/usr/sbin/ebtables -A FORWARD -d 01:80:c2:00:00:13 -j DROP"


    if (operation == "edit" or operation == "add" )then
        local apName = db.getAttribute("dot11Interface","interfaceName",inputTable["ieee1905.registrarName"],"vapName")
        local apEnabled = db.getAttribute("dot11VAP","vapName",apName,"vapEnabled")
        if (inputTable["ieee1905.ieee1905Enabled"] == "1" and apEnabled == "1") then
            local bridgeName = db.getAttribute("bridgePorts","interfaceName",inputTable["ieee1905.registrarName"],"bridgeInterface")
            if(bridgeName ~= nil)then
                --require "ifDevLib"

                local filename = "/tmp/lanMAC1"
                if(bridgeName == "bdg4")then
                    filename = "/tmp/lanMAC3"
                elseif(bridgeName == "bdg5")then
                    filename = "/tmp/lanMAC4"
                end
                local al_mac = util.fileToString(filename)

                if(al_mac ~= nil)then
                    local bridgePortsRow = db.getRowWhere("bridgePorts","bridgeInterface ='" ..bridgeName.."' and portType='ethernet'", false)
                    if(bridgePortsRow ~= nil and bridgePortsRow["interfaceName"] ~= nil)then
                        cmdStr = cmdStr..al_mac.." -i "..bridgePortsRow["interfaceName"]..","..inputTable["ieee1905.registrarName"].." -r " ..inputTable["ieee1905.registrarName"].." > /dev/console & "
                    else
                        cmdStr = cmdStr..al_mac.." -i "..bridgeName..","..inputTable["ieee1905.registrarName"].." -r " ..inputTable["ieee1905.registrarName"].." > /dev/console & "
                    end

                    if(operation == "add") then
                        os.execute(ebtableDropCmd)
                        os.execute(ebtableAddCmd)
                        os.execute(iptableDropCmd)
                        os.execute(iptableAddCmd)
                        os.execute(cmdStr)
                    else
                        os.execute("echo \'killall -9 al_entity\' >> "..CMD_EXEC_SCRIPT)
                        os.execute("echo \'"..ebtableDropCmd.."\' >> "..CMD_EXEC_SCRIPT)
                        os.execute("echo \'"..ebtableAddCmd.."\' >> "..CMD_EXEC_SCRIPT)
                        os.execute("echo \'"..iptableDropCmd.."\' >> "..CMD_EXEC_SCRIPT)
                        os.execute("echo \'"..iptableAddCmd.."\' >> "..CMD_EXEC_SCRIPT)
                        os.execute("echo \'"..cmdStr.."\' >> "..CMD_EXEC_SCRIPT)
                    end
                end
            end
        else
            os.execute("echo \'killall -9 al_entity\' >> "..CMD_EXEC_SCRIPT)
            os.execute("echo \'"..ebtableDropCmd.."\' >> "..CMD_EXEC_SCRIPT)
            os.execute("echo \'"..iptableDropCmd.."\' >> "..CMD_EXEC_SCRIPT)
        end
    end

    -- return
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "IEEE1905_CONFIG_FAILED"
    end

end


function ieee1905.import (configTable, defaultConfigTable, removeTbl)

    local status
    --if ieee1905Config comes nil fill with default configuration
    if (configTable == nil) then
        configTable = defaultConfigTable
    end

    local ieee1905Tbl = {}
    local bootFlag = "1"
    ieee1905Tbl = config.update (configTable, defaultConfigTable, removeTbl)

    -- configure ieee1905
    if (ieee1905Tbl ~= nil and #ieee1905Tbl ~= 0) then
        for i,v in ipairs (ieee1905Tbl) do
            v = util.addPrefix (v, "ieee1905.")
            config.recOp (ieee1905.ieee1905_config, v, "-1", "add");
        end
    end

end


function ieee1905.export ()

    local status
    local ieee1905Config =  {};
    ieee1905Config["ieee1905"] = db.getTable("ieee1905", false)
    return ieee1905Config

end

if (config.register) then

   config.register("ieee1905", ieee1905.import, ieee1905.export, "3")

end

