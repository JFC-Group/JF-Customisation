-- @copyright Copyright (c) 2013, TeamF1, Inc.
-- Copyright (c) 2016, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
--
--[[ Network settings ]]--
-- modification history
-- --------------------
-- 01c, 23Nov17, swr changes for spr 62635(XSS vulnerability) and 61441
-- 01b, 20Apr17, ash Added check for used vid
-- 01a, 30Aug16, vip Added switch_cli commnads for WIFI ports
--
gui.networking.network = {}
gui.networking.network.ipv4 = {}
gui.networking.network.ipv6 = {}
gui.networking.network.guest = {}
gui.networking.network.vlan = {}
gui.networking.network.dmz = {}
gui.networking.network.dmz6 = {}
gui.networking.network.eogre = {}

require "teamf1lualib/netUtil"
require "teamf1lualib/netipv4conf"
require "teamf1lualib/netipv6conf"

local numOfPorts = 0
local  portCorrection = 0 
if (util.fileExists ("/pfrm2.0/HW_JCO4032") or util.fileExists ("/pfrm2.0/HW_JCOW407") or util.fileExists ("/pfrm2.0/HW_JCOW402")) then
	numOfPorts = 4
	
else
	-- legacy code for JCO4031/JCO3021
	numOfPorts = 2
	portCorrection = 2
end


-------------------------------------------------------------------------
-- @name gui.networking.network.get
--
-- @description This routine gets the network data
--
-- @param name network name to get the info of the network.
-- ignore this param to get the data for a new network
--
-- @return status
-- @return errCode
-- @return data = {}
-- data["networkName"] -- Network Name
-- data["networkType"] -- Network Type
-- data["networkMode"] -- Network Mode
-- data["associateNetwork"] -- Routed / Bridge To Network
-- data["vlanId"] -- VLAN Id
-- data["igmpSnooping"] -- Enable IGMP Snooping
-- data["mldSnooping"] -- Enable MLD Snooping
-- data.ipv4["enable"] -- Enable IPv4
-- data.ipv6["enable"] -- Enable IPv6
-- data.networkList = {} network list to be populated in
-- "Routed / Bridged To Network" with network name
-- ** data.networkList[i]["networkName"] each network Network Name
--

function gui.networking.network.get (name)
    local status = "ERROR"
    local query
    local errCode = "NET_ERR_INVALID_PARAMS"
    local statusTbl = {}
    local data = {}
    local mode = {}
    local conf = {}

    data.ipv4 = {}
    data.ipv6 = {}
    data.networkList = {}

    -- need data for new network
    if (name == nil) then
        status, errCode, conf = gui.networking.network.ListGet ()
        if (status == "OK") then
            data.networkList = conf
        else
            return status, errCode
        end
    else -- get existing connection data
        require "teamf1lualib/network"
        require "teamf1lualib/ifDev"
        require "teamf1lualib/bridgeLib"
        local vlanId = nil

        status, errCode, conf = network.ifConfGet(name)
        if (status ~= "OK") then
            return status, errCode
        end

        data["networkName"] = name
        data["networkType"] = gui.networking.zoneTypeToNetworkType(conf["zoneType"])
        data["enable"] = conf["enable"]

        if (data["networkType"] == "LAN") then

            if(name == "Guest") then
                data["wirlessNetName"] = gui.networking.network.guestVapSsidGet ()
            elseif(name == "Local") then
                data["wirlessNetName"] = gui.networking.network.adminVapSsidGet ()
            else
                data["wirlessNetName"] = "N/A"
            end
            if (data["wirlessNetName"] == nil) then
                return status, errCode
            end

        end

        mode = ifDev.modeGet (conf["connectionType"])
        if ((mode ~= nil) and (mode[1] ~= nil)) then
            data["networkMode"] = tostring(mode[1]["mode"]) or ""
            data["associateNetwork"] = mode[1]["networkName"] or ""
        else
            data["networkMode"] = ""
            data["associateNetwork"] = ""
        end

        status, errCode, vlanId = network.vlanIDGet (conf)
        if (status == "OK") then
            data["vlanId"] = vlanId
        else
            data["vlanId"] = conf["networkId"]
        end

 query ="LogicalIfName='" .. conf["LogicalIfName"] .. "'"
 bdgIf = bridge.confGet("bridgeTable", query)
 if ((bdgIf ~= nil) or (bdgIf[1] ~= nil)) then
         data["igmpSnooping"] = bdgIf[1]["igmpSnooping"]
 end
        data["mldSnooping"] = false

        if (network.hasWirelessPort(conf) ~= nil) then
            data["enbWireless"] = "1"
        else
            data["enbWireless"] = "0"
        end

        if (network.hasL3Object(conf)) then
         require ("teamf1lualib/nimf")
         require ("teamf1lualib/nimfConn")
            local connID = {}

            -- Get IPv4 status
            connID["LogicalIfName"] = conf["LogicalIfName"]
            connID["AddressFamily"] = nimf.proto.NIMF_PROTO_TYPE_IPV4
            local status, errCode, ipv4 = nimfConn.confGet (connID)
            if (status == "OK") then
                data.ipv4["enable"] = ipv4 ["Enable"]
            end

            -- Get IPv6 status
            connID["AddressFamily"] = nimf.proto.NIMF_PROTO_TYPE_IPV6
            local status, errCode, ipv6 = nimfConn.confGet (connID)
            if (status == "OK") then
                data.ipv6["enable"] = ipv6 ["Enable"]
            end
        else
            data.ipv4["enable"] = "0"
            data.ipv6["enable"] = "0"
        end

        status, errCode, conf = gui.networking.network.associateNetworkListGet (name)
        if (status == "OK") then
            data.networkList = conf
        end
    end

    gui.dprintf("NETWORK: " .. util.tableToStringRec(data))

    return "OK","STATUS_OK", data
end

------------------------------------------------------------------------
-- @name gui.networking.network.adminVapSsidGet ()
--
-- @description This routine gets the ssid asociated with admin vap
--
-- @param vapName
--
-- @return ssid
--
--
function gui.networking.network.adminVapSsidGet ()
    return gui.networking.network.vapSsidGet ("vap0")
end

------------------------------------------------------------------------
-- @name gui.networking.network.guestVapSsidGet ()
--
-- @description This routine gets the ssid asociated with guest vap
--
-- @param vapName
--
-- @return ssid
--
--
function gui.networking.network.guestVapSsidGet ()
    return gui.networking.network.vapSsidGet ("vap1")
end

------------------------------------------------------------------------
-- @name gui.networking.network.vapSsidGet (vapName)
--
-- @description This routine gets the ssid asociated with given vap
--
-- @param vapName
--
-- @return ssid
--
--

function gui.networking.network.vapSsidGet (vapName)
    local whereQuery
    local tmpConf = {}

    if (vapName == nil) then
        return nil
    end

    whereQuery = "profileName=(select profileName from dot11vap where " ..
                 "vapName=(select  vapName from dot11interface where " ..
                 "interfaceName='" .. vapName .. "'))"

   tmpConf = db.getRowWhere ("dot11Profile", whereQuery, false)

   if (tmpConf == nil) then
       return nil
   end

   return tmpConf["ssid"]

end

------------------------------------------------------------------------
-- @name gui.networking.network.guestDefMapGet
--
-- @description
--
-- @param conf
--
-- @return portTbl, ifTbl
--
--

function gui.networking.network.guestDefMapGet(conf)
    local portTbl = {}
    local ifTbl = {}

    portTbl[1] = {}
    portTbl[1]["type"] = "vap"
    portTbl[1]["port"] = 1
    portTbl[1]["vlanId"] = 1
    portTbl[1]["ifname"] = "vap1"
    portTbl[1]["LogicalIfName"] = conf["LogicalIfName"]

    ifTbl[1] = {}
    ifTbl[1]["type"] = "vap"
    ifTbl[1]["vlanId"] = 1
    ifTbl[1]["ifname"] = "vap1"
    ifTbl[1]["LogicalIfName"] = conf["LogicalIfName"]

    return portTbl, ifTbl
end

------------------------------------------------------------------------
-- @name gui.networking.network.secureDefMapGet
--
-- @description This routine prepares the default port map table for LAN
-- network. we use this while creating LAN network.
--
-- @param ID
--
-- @return portTbl
--
--
function gui.networking.network.secureDefMapGet(conf)
    local portTbl = {}
    local ifTbl = {}
    local ID = conf["vlanId"]

    portTbl[1] = {}
    portTbl[1]["type"] = "vlan"
    portTbl[1]["port"] = 1
    portTbl[1]["vlanId"] = ID
    portTbl[1]["ifname"] = "eth0." .. ID
    portTbl[1]["LogicalIfName"] = conf["LogicalIfName"]
    portTbl[2] = {}
    portTbl[2]["type"] = "vlan"
    portTbl[2]["port"] = 2
    portTbl[2]["vlanId"] = ID
    portTbl[2]["ifname"] = "eth0." .. ID
    portTbl[2]["LogicalIfName"] = conf["LogicalIfName"]
    portTbl[3] = {}
    portTbl[3]["type"] = "vlan"
    portTbl[3]["port"] = 3
    portTbl[3]["vlanId"] = ID
    portTbl[3]["ifname"] = "eth0." .. ID
    portTbl[3]["LogicalIfName"] = conf["LogicalIfName"]
    portTbl[4] = {}
    portTbl[4]["type"] = "vlan"
    portTbl[4]["port"] = 4
    portTbl[4]["vlanId"] = ID
    portTbl[4]["ifname"] = "eth0." .. ID
    portTbl[4]["LogicalIfName"] = conf["LogicalIfName"]

    ifTbl[1] = {}
    ifTbl[1]["type"] = "vlan"
    ifTbl[1]["vlanId"] = ID
    ifTbl[1]["ifname"] = "eth0." .. ID
    ifTbl[1]["LogicalIfName"] = conf["LogicalIfName"]

    return portTbl, ifTbl
end

------------------------------------------------------------------------
-- @name gui.networking.network.insecureDefMapGet
--
-- @description This routine prepares the default port map table for WAN
-- network. we use this while creating WAN network.
--
-- @param ID
--
-- @return portTbl
--

function gui.networking.network.insecureDefMapGet(conf)
    local portTbl = {}
    local ifTbl = {}
    local ID = conf["vlanId"]

    portTbl[1] = {}
    portTbl[1]["type"] = "vlan"
    if (UNIT_NAME == "NPA211E") then
        portTbl[1]["port"] = 2
    else
        portTbl[1]["port"] = 5
    end
    portTbl[1]["vlanId"] = ID
    portTbl[1]["ifname"] = "eth1." .. ID
    portTbl[1]["LogicalIfName"] = conf["LogicalIfName"]

    ifTbl[1] = {}
    ifTbl[1]["type"] = "vlan"
    ifTbl[1]["vlanId"] = ID
    ifTbl[1]["ifname"] = "eth0." .. ID
    ifTbl[1]["LogicalIfName"] = conf["LogicalIfName"]

    return portTbl, ifTbl
end

------------------------------------------------------------------------
-- @name gui.networking.network.bridgeDefMapGet
--
-- @description This routine prepares the default port map table for VLAN Bridge
-- network. we use this while creating WAN network.
--
-- @param ID
--
-- @return portTbl
--
--
function gui.networking.network.bridgeDefMapGet(conf)
    local portTbl = {}
    local ifTbl = {}
    local ID = conf["vlanId"]

    portTbl[1] = {}
    portTbl[1]["type"] = "vlan"
    portTbl[1]["port"] = 1
    portTbl[1]["ifname"] = "eth0." .. ID
    portTbl[1]["vlanId"] = ID
    portTbl[1]["LogicalIfName"] = conf["LogicalIfName"]
    portTbl[2] = {}
    portTbl[2]["type"] = "vlan"
    portTbl[2]["port"] = 2
    portTbl[2]["ifname"] = "eth0." .. ID
    portTbl[2]["vlanId"] = ID
    portTbl[2]["LogicalIfName"] = conf["LogicalIfName"]
    portTbl[3] = {}
    portTbl[3]["type"] = "vlan"
    portTbl[3]["port"] = 3
    portTbl[3]["ifname"] = "eth0." .. ID
    portTbl[3]["vlanId"] = ID
    portTbl[3]["LogicalIfName"] = conf["LogicalIfName"]
    portTbl[4] = {}
    portTbl[4]["type"] = "vlan"
    portTbl[4]["port"] = 4
    portTbl[4]["ifname"] = "eth0." .. ID
    portTbl[4]["vlanId"] = ID
    portTbl[4]["LogicalIfName"] = conf["LogicalIfName"]
    portTbl[5] = {}
    portTbl[5]["type"] = "vlan"
    portTbl[5]["port"] = 5
    portTbl[5]["ifname"] = "eth1." .. ID
    portTbl[5]["vlanId"] = ID
    portTbl[5]["LogicalIfName"] = conf["LogicalIfName"]

    ifTbl[1] = {}
    ifTbl[1]["type"] = "vlan"
    ifTbl[1]["vlanId"] = ID
    ifTbl[1]["ifname"] = "eth0." .. ID
    ifTbl[1]["LogicalIfName"] = conf["LogicalIfName"]

    return portTbl, ifTbl
end

------------------------------------------------------------------------
-- @name gui.networking.network.L3ConfPrepare
--
-- @description This function prepares the Layer 3 configuration for
-- the network.
--
-- @param
-- conf - configuration being prepared to be sent to the backend
-- data - date from the user
--
-- @return configuration or nil
--

function gui.networking.network.L3ConfPrepare(conf, data)
    local connID = {}
    local ipv4conf = {}
    local ipv6conf = {}

    if (tonumber(data["networkMode"]) == ifDev.mode.IFDEV_MODE_BRIDGED) then
        ipv4conf["enable"] = 0
        ipv6conf["enable"] = 0

        conf["ipv6"] = ipv6conf
        conf["ipv4"] = ipv4conf
        return conf
    end

    connID["LogicalIfName"] = conf["LogicalIfName"] or ""
    connID["AddressFamily"] = "2"
    connID["ConnectionKey"] = "0"
    ipv4conf = connID
    status, errCode, ipv4conf = gui.networking.connConfGet(connID, ipv4conf)
    if (status ~= "OK") then
        -- configuration not found, then use default for this zone
        ipv4conf = gui.networking.defIpv4Conf(connID, conf["zoneType"])
    end

    -- override defaults
    if (data["ipv4.enable"] ~= nil) then
        ipv4conf["Enable"] = data["ipv4.enable"]
    end

    local connID = {}
    connID["LogicalIfName"] = conf["LogicalIfName"] or ""
    connID["AddressFamily"] = "10"
    connID["ConnectionKey"] = "0"
    ipv6conf = connID
    status, errCode, ipv6conf = gui.networking.connConfGet(connID, ipv6conf)
    if (status ~= "OK") then
        -- configuration not found, then use default for this zone
        ipv6conf = gui.networking.defIpv6Conf(connID, conf["zoneType"])
    end

    -- override defaults
    if (data["ipv6.enable"] ~= nil) then
        ipv6conf["Enable"] = data["ipv6.enable"]
    end

    ipv4conf["enable"] = data["ipv4.enable"]
    ipv6conf["enable"] = data["ipv6.enable"]

    conf["ipv6"] = ipv6conf
    conf["ipv4"] = ipv4conf

    return conf
end

-------------------------------------------------------------------------------
-- @name gui.networking.network.WirelessConfPrepare
--
-- @description
--
-- NOTE:
-- This project does not have a requirement to create new VAPs.
-- This device will have atmost two vaps - admin and guest(if configured)
-- If wireless is enabled on a given network then both the
-- VAP interfaces must be removed from the existing network and
-- added to the new network. This would mean that wireless is
-- is enabled on only one network at any given time.
--
-- @param
--
-- @return conf
--

function gui.networking.network.WirelessConfPrepare (conf, data)
    local userEnabledWireless = 0
    local netHasWireless = 0

    --
    -- For Guest network, add the guest vap to the network
    --
    if (platformLib.strcasecmp(conf["LogicalIfName"], "IF3") == 0) then
        local portTbl, ifTbl = gui.networking.network.guestDefMapGet (conf)
        if (tonumber(data["allowLANAccess"]) ~= 0) then
            status, errCode, ifcfg = ifDev.cfgByNameGet(data["associateNetwork"])
            -- Commented following if condition to fix #36172
            --[[if (status == "OK") then
                portTbl[1]["LogicalIfName"] = ifcfg["LogicalIfName"]
                ifTbl[1]["LogicalIfName"] = ifcfg["LogicalIfName"]
            end ]]--
        end
        conf["portTbl"] = portTbl
        conf["ifTbl"] = ifTbl
    else
        userEnabledWireless = tonumber(data["enbWireless"])
        if (network.hasWirelessPort(conf) ~= nil) then
            netHasWireless = 1
        end

        if ((userEnabledWireless == 0) and (netHasWireless ~= 0)) then

            -- remove wireless port from the network
           for k,v in pairs(conf["portTbl"]) do
               if ((platformLib.strcasecmp(v["type"], "Wireless") == 0) or
                   (platformLib.strcasecmp(v["type"], "vap") == 0)) then
                   table.remove(conf["portTbl"], k)
               end
           end

           for k,v in pairs(conf["ifTbl"]) do
               if ((platformLib.strcasecmp(v["type"], "Wireless") == 0) or
                   (platformLib.strcasecmp(v["type"], "vap") == 0)) then
                   table.remove(conf["ifTbl"], k)
               end
           end

           conf["wirelessDisabled"] = 1

      elseif (((userEnabledWireless ~= 0) and (userEnabledWireless ~= nil)) and (netHasWireless == 0)) then
            --
            -- Check if there are any available wireless ports assigned
            -- to this network
            --

            local wPortTbl = network.wirelessPortListGet(conf)
            if ((wPortTbl == nil) or (util.tableSize(wPortTbl) == 0)) then
                -- If no wireless ports were assigned to this network, then we
                -- need to disable wireless on other existing LAN networks
                -- and add it to this network.
                wPortTbl = gui.networking.network.wirelessEnabledLANGet()
                if ((wPortTbl ~= nil) and (wPortTbl[1] ~= nil)) then
                    network.wirelessDisable(wPortTbl[1]["LogicalIfName"])
                end
            end

            -- Add the vaps to the network's list of ports
            for k,v in pairs(wPortTbl) do
                v["LogicalIfName"] = conf["LogicalIfName"]
                table.insert(conf["portTbl"], v)
            end

            for k,v in pairs(wPortTbl) do
                v["LogicalIfName"] = conf["LogicalIfName"]
                table.insert(conf["ifTbl"], v)
            end

           conf["wirelessEnabled"] = 1

        elseif ((userEnabledWireless == 0) and (netHasWireless == 0)) then
            -- No CHANGE in wireless port status
        elseif ((userEnabledWireless ~= 0) and (netHasWireless ~= 0)) then
            -- No CHANGE in wireless port status
        end
    end

    return conf
end

------------------------------------------------------------------------
-- @name gui.networking.network.L2ConfPrepare
--
-- @description This function makes a list of all the network ports
-- that are part of this network. If no ports have been configured
-- then we get the defaults. If the status of wireless changes
-- (enable <--> disable) then we add/remove the wireless port
-- to/from the network.
--
-- @param
-- conf - configuration being prepared to be sent to the backend
-- data - data from the user
--
-- @return configuration or nil
--

function gui.networking.network.L2ConfPrepare (conf, data)
    require "teamf1lualib/network"
    local portTbl = {}
    local ifTbl = {}
    local ifcfg = {}
    local status
    local errCode

    conf["ifTbl"] = {}
    conf["portTbl"] = {}

    if ((data["createNetwork"] == 0) or
        (data["createNetwork"] == nil)) then
        --
        -- If the network has already been created then get the ports
        -- that belong to this network
        --
        status, errCode, portTbl, ifTbl = network.portConfGet (data)
        if (status ~= "OK") then
            gui.dprintf("failed to get port configuration for " .. conf["networkName"])
            return status, errCode
        end
    end

    if ((util.tableSize(portTbl) == 0)) then
        --
        -- Guest networks do not have ethernet ports.
        -- For non-guest networks, get the default port map based
        -- on the zone to which the network belongs.
        --

        if (platformLib.strcasecmp(conf["LogicalIfName"], "IF3") ~= 0) then

            gui.dprintf("No ports have been configured for " .. conf["networkName"])
            --
            -- No ports have been configured yet for this network. Let's
            -- get all the ports available to the given network zone
            --
            if (platformLib.strcasecmp(conf["zoneType"], "secure") == 0) then
                portTbl, ifTbl = gui.networking.network.secureDefMapGet (conf)
            elseif (platformLib.strcasecmp(conf["zoneType"], "insecure") == 0) then
                portTbl, ifTbl = gui.networking.network.insecureDefMapGet (conf)
            elseif (platformLib.strcasecmp(conf["zoneType"], "bridge") == 0) then
                portTbl, ifTbl = gui.networking.network.bridgeDefMapGet (conf)
            end

        end

    end

    conf["portTbl"] = portTbl
    conf["ifTbl"] = ifTbl

    --
    -- Prepare wireless port configuration for this network.
    --

    conf = gui.networking.network.WirelessConfPrepare (conf, data)


    return conf
end

------------------------------------------------------------------------
-- @name gui.networking.network.confPrepare
--
-- @description This routine prepares the configuration based on the
-- user input that needs to be passed to the backend
--
-- @param data user input from the GUI
--
-- @return conf
--

function gui.networking.network.confPrepare (data)
    require "teamf1lualib/ifDev"
    local conf = {}
    local mode = {}

    conf["networkName"] = data["networkName"]
    conf["LogicalIfName"] = data["LogicalIfName"]
    conf["vlanId"] = data["vlanId"]
    if (data["networkId"] == nil) then
        conf["networkId"] = data["vlanId"]
    end
    conf["enable"] = data["enable"] or 1
    conf["mac"] = data["mac"] or ""
    conf["mtu"] = data["mtu"] or 1500
    conf["interfaceName"] = data["interfaceName"]
    conf["ifType"] = data["ifType"]
    conf["igmpSnooping"] = data["igmpSnooping"] or 0

    -- get network zone type
    if (data["zoneType"] ~= nil) then
        conf["zoneType"] = data["zoneType"]
    else
        conf["zoneType"] = gui.networking.networkTypeToZoneType (data["networkType"])
        if (conf["zoneType"] == nil) then
            gui.dprintf("confPrepare: Failed to get network zone <br>")
            return nil, "NET_ERR_INVALID_ZONE"
        end
    end

    --
    -- Construct the connectionType string. The connection type
    -- defines how the network is associated with other networks - ROUTED, BRIDGED .. etc
    --
    if (platformLib.strcasecmp(conf["zoneType"], "secure") == 0) then
        if (data["connectionType"] ~= nil) then
            conf["connectionType"] = data["connectionType"]
        else
            -- Get network connection type
            local index = 1
            mode[index] = {}
            mode[index]["mode"] = data["networkMode"]
            mode[index]["networkName"] = data["associateNetwork"]
            status, errCode, conf["connectionType"] = ifDev.modeStrGet (mode)
            if (status ~= "OK") then
                gui.dprintf("confPrepare: Failed to get mode string <br>")
                return nil, "NET_ERR_INVALID_MODE"
             end
        end
    end

    -- Prepare L2 configurations for this network
    conf = gui.networking.network.L2ConfPrepare(conf, data)
    if (conf == nil) then
        gui.dprintf("confPrepare: Failed to prepare port association <br>")
        return nil, "NET_ERR_INVALID_L2_CONF"
    end

    -- Prepare L3 configurations for this network
    conf = gui.networking.network.L3ConfPrepare(conf, data)
    if (conf == nil) then
        gui.dprintf("confPrepare: Failed to prepare L3 configuration <br>")
        return nil, "NET_ERR_INVALID_L3_CONF"
    end

    gui.dprintf("network.confPrepare: " .. util.tableToStringRec(conf))

    return conf, "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name gui.networking.network.add
--
-- @description This routine adds a new network
--
-- @param data
--
-- @return status
-- @return errCode
--

function gui.networking.network.add (data)
    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"
    local conf = {}
    require "teamf1lualib/ifDev"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (data == nil) then
        return status, errCode
    end


    status, errCode, conf = ifDev.cfgByQueryGet ()
    if (status == "ERROR") then
        return status, errCode
    end

    -- check if we have reached the limit for the maximum number of networks
    if (#conf >= ifDev.IFDEV_MAX_NETIF) then
        return "ERROR", "NET_ERR_MAX_NETWORKS_LIMIT_REACHED"
    end

    -- check if the network with the same name exists
    for i, netConf in pairs(conf) do
        if (platformLib.strcasecmp(data["networkName"], netConf["networkName"]) == 0) then
            return "ERROR", "NET_ERR_NETWORK_ALREADY_EXISTS"
        end
    end

    -- check if vlan exists with the same ID
    for i,v in pairs (conf) do
        if (data["vlanId"] == v["networkId"]) then
            return "ERROR", "NET_ERR_NETWORK_ALREADY_EXISTS"
        end
    end

    --[[ check if vlan exists with the same ID
    if (gui.networking.network.vlanExists(data["networkType"],
                                          data["vlanId"]) == true) then
        return "ERROR", "NET_ERR_NETWORK_ALREADY_EXISTS"
    end
    ]]--
    -- Generate the logicalIfName for this network
    data["LogicalIfName"] = ifDev.lNameGen()
    data["createNetwork"] = 1

    db.beginTransaction()

    -- Prepare the configuration from the user input
    conf, errCode = gui.networking.network.confPrepare (data)
    if (conf == nil) then
        gui.dprintf("network.add: failed to load configuration<br>")
        db.rollback()
        return "ERROR", errCode
    end

    require "teamf1lualib/network"
    status, errCode = network.create (conf)
    if (status ~= "OK") then
        gui.dprintf("network.add: failed to create network<br>")
        db.rollback()
        return status, errCode
    end

    db.commitTransaction(true)

    db.save2()

    return status, errCode
end

------------------------------------------------------------------------
-- @name gui.networking.network.edit
--
-- @description This routine edit a network
--
-- @param name old network name
-- @param data
--
-- @return status
-- @return errCode
--

function gui.networking.network.edit (name, data)
    require "teamf1lualib/ifDev"
    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"
    local conf = {}

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (name == nil) then
        gui.dprintf("network.edit: network name not provided")
        return status, errCode
    end

    if (data == nil) then
        gui.dprintf("network.edit: configuration data not provided")
        return status, errCode
    end

    gui.dprintf("INPUT: " .. util.tableToStringRec(data))

    local query = "networkName = '" .. name .."'"
    status, errCode, conf = ifDev.cfgByQueryGet (query)
    if (status ~= "OK") then
        return "ERROR", "NET_ERR_NETWORK_QUERY_FAIL"
    end

    -- fill all the missing fields
    if (conf == nil or conf[1] == nil) then
        return "ERROR", "NET_ERR_DB_NOENT"
    end

    data["networkName"] = conf[1]["networkName"]
    data["zoneType"] = conf[1]["zoneType"]
    data["LogicalIfName"] = conf[1]["LogicalIfName"]
    data["interfaceName"] = conf[1]["interfaceName"]
    data["ifType"] = conf[1]["ifType"]

    --[[
    if ((platformLib.strcasecmp(data["zoneType"], "secure") == 0) and
        (platformLib.strcasecmp(data["networkName"], "Guest") ~= 0)) then

        if (gui.networking.network.hasModeChanged(data, conf[1]) == true) then
            --
            -- If the network is enabled and the mode has changed, then
            -- return an error. We are not supporting this use-case
            -- for now. The user must disable the network first.
            --
            if (gui.networking.network.isEnabled(conf[1]) == true) then
                return "ERROR", "NET_ERR_MODE_CHANGE_WITH_NET_ENABLE"
            end
        end
    end
    ]]--

    db.beginTransaction()

    conf = gui.networking.network.confPrepare (data)
    if (conf == nil) then
        db.rollback()
        return status, errCode
    end

    status, errCode = network.edit (name, conf)
    if (status ~= "OK") then
        db.rollback()
        return status, (errCode or "NET_ERR_EDIT")
    end

    --
    -- if wireless configuration has changed then
    -- make changes to guest network
    --
    if ((conf["wirelessEnabled"] ~= nil) or
        (conf["wirelessDisabled"] ~= nil)) then
        gui.networking.network.guest.edit(conf)
    end

    db.commitTransaction(true)

    db.save2()

    return "OK","STATUS_OK"
end

-----------------------------------------------------------------------
-- @name gui.networking.network.enable
--
-- @description This routine enables network(s)
--
-- @param nwTbl list of networks to be enabled
--
-- <ul>
-- <li><i>name</i> Name of the network
-- </ul>
--
-- @return status
-- @return errCode
--

function gui.networking.network.enable (nwTbl)
    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (nwTbl == nil) then
        return status, errCode
    end

    local valid = ""
    for rows, netName in pairs (nwTbl) do
        valid = gui.networking.network.checkIfDefaultNetwork(netName)
        if (valid == true) then
            return "ERROR", "DEFUALT_NETWORK_CONFIGURATION_NOT_ALLOWED"
        end
    end

    gui.dprintf("List of networks to enable: " .. util.tableToStringRec(nwTbl) .. "<br>")

    require "teamf1lualib/network"

    db.beginTransaction()
    for k,v in pairs(nwTbl) do
        gui.dprintf("Enabling network: " .. v .. "<br>")
        status, errCode = network.enable (v)
        if (status ~= "OK") then
            gui.dprintf("failed to enable network: " .. v .. "<br>")
            db.rollback()
            return status, errCode
        end
    end

    db.commitTransaction(true)

    db.save2()

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------
-- @name gui.networking.network.disable
--
-- @description This routine disables network(s)
--
-- @param nwTbl list of networks to be disabled
--
-- <ul>
-- <li><i>name</i> Name of the network
-- </ul>
--
-- @return status
-- @return errCode
--

function gui.networking.network.disable (nwTbl)
    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"
    local query
    local nwRow
    local retStr
    local tmpRow
    local tmpStr = ""

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (nwTbl == nil) then
        return status, errCode
    end

    local valid = ""

    for rows, netName in pairs (nwTbl) do
        valid = gui.networking.network.checkIfDefaultNetwork(netName)
        if (valid == true) then
            return "ERROR", "DEFUALT_NETWORK_CONFIGURATION_NOT_ALLOWED"
        end

        -- check if wan network is associated to any lan network
        query = "networkName='" .. netName .. "'"
        nwRow = db.getRowWhere ("networkInterface", query, false);
        if (nwRow == nil) then
            return status, "NETWORK_NOT_AVAILABLE"
        end

        retStr = "Network cannot be disabled as it is associated with "
        -- Check if network is getting routed from any lan network.
        if (nwRow["zoneType"] == "insecure") then
            query = "connectionType='ROUTED:" .. nwRow["networkName"] .. "' and zoneType='secure'"
            tmpRow = db.getRowsWhere ("networkInterface", query, false);
            if (#tmpRow ~= 0) then
                for i,v in pairs (tmpRow) do
                    for x,y in pairs (v) do
                        if (x == "networkName") then
                            tmpStr = tmpStr .. " " .. y
                        end
                    end
                end
                return status, retStr .. tmpStr
            end
        end
    end

    gui.dprintf("List of networks to disable: " .. util.tableToStringRec(nwTbl) .. "<br>")

    require "teamf1lualib/network"

    db.beginTransaction()
    for k,v in pairs(nwTbl) do
        gui.dprintf("Disabling network: " .. v .. "<br>")
        status, errCode = network.disable (v)
        if (status ~= "OK") then
            db.rollback()
            gui.dprintf("failed to disable network: " .. v .. "<br>")
            return status, errCode
        end
    end

    db.commitTransaction(true)

    db.save2()

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------
-- @name gui.networking.network.tableCountGetOnCond
--
-- @description This routine is used to get rows count from a given table
--
-- @param tableName
-- @param condition
--
-- <ul>
-- <li><i>tableName</i> Name of the db table
-- <li><i>condition</i> where condition
-- </ul>
--
-- @return row[1]
-- @return 0
--
function gui.networking.network.tableCountGetOnCond (tableName, condition)
    local cur = db.execute(string.format([[
  SELECT COUNT(*) FROM %s WHERE %s
 ]], tableName, condition))

 -- print all rows, the rows will be indexed by field names
 if (cur) then
  local row = cur:fetch ({}, "n")
  cur:close()
  return row[1]
 else
  return 0
 end
end

-------------------------------------------------------------------------
-- @name gui.networking.network.defaultPortAssociationCheck
--
-- @description This routine is used to check network has untagged
-- association with some port or not
--
-- @param netName
--
-- <ul>
-- <li><i>netName</i> networkname
-- </ul>
--
-- @return status OK or ERROR
-- @return errCode reason for error or STATUS_OK
--
function gui.networking.network.defaultPortAssociationCheck (netName)
    local query = nil
    local logicalIfName = nil

    -- get the logicalIfName to proceed checking
    query = "networkName='" .. netName .. "'"
    nwRow = db.getRowWhere ("networkInterface", query, false);
    if (nwRow == nil) then
        return status, "NETWORK_NOT_AVAILABLE"
    else
        logicalIfName = nwRow["LogicalIfName"]
    end

    local untagMap = db.getAttribute("vlanEncapIf",
                                       "LogicalIfName", logicalIfName, "untagMap")
    if(untagMap ~= "") then
     local tbl = network.stringSplitter(',', untagMap)
     local portSwapUntagMap = ""
     for i,v in pairs(tbl) do
      if (tonumber(v) == 1) then
             if(portSwapUntagMap == "") then
               portSwapUntagMap = portSwapUntagMap .. "4"
       else
               portSwapUntagMap = portSwapUntagMap .. ",4"
       end
         elseif (tonumber(v) == 2) then
              if(portSwapUntagMap == "") then
               portSwapUntagMap = portSwapUntagMap .. "3"
       else
               portSwapUntagMap = portSwapUntagMap .. ",3"
       end
         elseif (tonumber(v) == 3) then
              if(portSwapUntagMap == "") then
               portSwapUntagMap = portSwapUntagMap .. "2"
       else
               portSwapUntagMap = portSwapUntagMap .. ",2"
       end
         elseif (tonumber(v) == 4) then
              if(portSwapUntagMap == "") then
               portSwapUntagMap = portSwapUntagMap .. "1"
       else
               portSwapUntagMap = portSwapUntagMap .. ",1"
       end
         elseif (tonumber(v) == 5) then
              if(portSwapUntagMap == "") then
               portSwapUntagMap = portSwapUntagMap .. "5"
       else
               portSwapUntagMap = portSwapUntagMap .. ",5"
       end
         end
     end

     if(nwRow["zoneType"] == "secure") then
            return "ERROR", "Selected Network can't be deleted as it has default association with Port(s) " .. portSwapUntagMap .. ". Make default association of specified ports with other LAN Network then delete! "
     else
      return "ERROR", "Selected Network can't be deleted as it has default association with Port " .. portSwapUntagMap .. ". Make default association of specified ports with other WAN Network then delete! "
     end
    end

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------
-- @name gui.networking.network.networkInUseCheck
--
-- @description This routine is used to check the network's usage by
-- applications
--
-- @param netName
--
-- <ul>
-- <li><i>netName</i> networkname
-- </ul>
--
-- @return true,errorCode
-- @return false, success
--
function gui.networking.network.networkInUseCheck (netName)

    -- applications which support network binding
    -- 1. network routed
    -- 2. Static routing
    -- 3. port forwarding (from network: wan networks).
    -- 4. Firewall Rules (from network: lan networks).
    -- 5. Full cone Nat (for lan networks).
    -- 6. Port triggering (for lan networks).
    -- 7. SNMP
    -- 8. IGMP
    -- 9. SSH
    -- 10. Bonjour
    -- 11. UPnP
    -- 12. DDNS
    -- 13. HTTPS setup
    -- 14. TR69 client setup
    -- 15. Remote syslog setup
    -- 16. Time
    -- 17. Sharing setup
    -- 18. WAN Bandwidth Configuration (uplink speed)
    -- 19. Traffic selectors (source Network: lan networks)
    -- 20. QoS Bandwidth Profiles
    -- 21. Voip profile1/profile2

    local status = true
    local retVal = 0
    local nwRow = nil
    local query = nil
    local logicalIfName = nil
    local routeRows = nil
    local retStr = nil
    local comma = 0
    local componentCount = 0;
    local tmpRow = nil
    local tmpStr = "network(s) "

    -- sanity on field
    if (netName == nil) then
        return status, "NETWORK_NOT_AVAILABLE"
    end

    -- get the logicalIfName to proceed checking
    query = "networkName='" .. netName .. "'"
    nwRow = db.getRowWhere ("networkInterface", query, false);
    if (nwRow == nil) then
        return status, "NETWORK_NOT_AVAILABLE"
    else
        logicalIfName = nwRow["LogicalIfName"]
    end

    retStr = "Network " .. netName .. " cannot be deleted. This network is binded with "
    -- Check if network is getting routed from any lan network.
    if (nwRow["zoneType"] == "insecure") then
        query = "connectionType='ROUTED:" .. nwRow["networkName"] .. "' and zoneType='secure'"
        tmpRow = db.getRowsWhere ("networkInterface", query, false);
        if (#tmpRow ~= 0) then
            for i,v in pairs (tmpRow) do
                for x,y in pairs (v) do
                    if (x == "networkName") then
                        tmpStr = tmpStr .. " " .. y
                    end
                end
            end
            return true, "Network cannot be deleted as it is associated with " .. tmpStr
        end
    end

    -- Check firewall
    if (nwRow["zoneType"] == "insecure") then -- port forwarding (wan networks only)
        query = "RuleType='INSECURE_SECURE' and FromZoneNetwork='" .. netName .. "'"
        retVal = gui.networking.network.tableCountGetOnCond ("FirewallRules", query);
        if (tonumber(retVal) > 0) then
            --return status, "NETWORK_IN_USE_BY_PORT_FWD"
            retStr = retStr .. " port forwarding,"
            componentCount = componentCount +1;
        end
    else -- outbound (lan networks only)
        query = "RuleType='SECURE_INSECURE' and FromZoneNetwork='" .. netName .. "'"
        retVal = gui.networking.network.tableCountGetOnCond ("FirewallRules", query);
        if (tonumber(retVal) > 0) then
            --return status, "NETWORK_IN_USE_BY_FIREWALL"
            retStr = retStr .. " Firewall rules,"
            componentCount = componentCount +1;
        end
    end
    retVal = 0

    -- Check full cone Nat
    query = "localNetworkName='" .. netName .. "'"
    retVal = gui.networking.network.tableCountGetOnCond ("FullConeNat", query);
    if (tonumber(retVal) > 0) then
        --return status, "NETWORK_IN_USE_BY_FULLCONE_NAT"
        comma = 1
        retStr = retStr .. " Full Cone Nat,"
        componentCount = componentCount +1;
    end

    -- Check port triggering
    query = "NetworkName='" .. netName .. "'"
    retVal = gui.networking.network.tableCountGetOnCond ("PortTriggering", query);
    if (tonumber(retVal) > 0) then
        --return status, "NETWORK_IN_USE_BY_PORT_TRIGGER"
        retStr = retStr .. " Port Triggering,"
        componentCount = componentCount +1;
    end

    -- Check IGMP
    query = "(upstreamInterface='" .. logicalIfName .. "' or downstreamInterface='" .. logicalIfName .. "') and IgmpEnable='1'"
    retVal = gui.networking.network.tableCountGetOnCond ("Igmp", query);
    if (tonumber(retVal) > 0) then
        --return status, "NETWORK_IN_USE_BY_IGMP"
        retStr = retStr .. " Igmp,"
        componentCount = componentCount +1;
    end

    -- Check DDNS
    query = "interfaceName='" .. logicalIfName .. "' and ddnsService!='0'"
    retVal = gui.networking.network.tableCountGetOnCond ("ddns", query);
    if (tonumber(retVal) > 0) then
        --return status, "NETWORK_IN_USE_BY_DDNS"
        retStr = retStr .. " DDNS,"
        componentCount = componentCount +1;
    end

    -- Check if routing application is using this network
    query = "interfaceName='" .. logicalIfName .. "'"
    retVal = gui.networking.network.tableCountGetOnCond ("route", query);
    if (tonumber(retVal) > 0) then
        --return status, "NETWORK_IN_USE_BY_ROUTING"
        retStr = retStr .. " Routing,"
        componentCount = componentCount +1;
    end
    retVal = 0

    -- Check SNMP
    query = "LogicalIfName='" .. logicalIfName .. "' and snmpEnable='1'"
    retVal = gui.networking.network.tableCountGetOnCond ("snmp", query);
    if (tonumber(retVal) > 0) then
        --return status, "NETWORK_IN_USE_BY_SNMP"
        retStr = retStr .. " SNMP,"
        componentCount = componentCount +1;
    end
    retVal = 0

    -- Check SSH
    query = "LogicalIfName='" .. logicalIfName .. "' and sshdEnable='1'"
    retVal = gui.networking.network.tableCountGetOnCond ("sshd", query);
    if (tonumber(retVal) > 0) then
        --return status, "NETWORK_IN_USE_BY_SSHD"
        retStr = retStr .. " SSH,"
        componentCount = componentCount +1;
    end
    retVal = 0

    -- Check UPnP
    query = "LogicalIfName='" .. logicalIfName .. "' and upnpEnable='1'"
    retVal = gui.networking.network.tableCountGetOnCond ("upnp", query);
    if (tonumber(retVal) > 0) then
        --return status, "NETWORK_IN_USE_BY_UPNP"
        retStr = retStr .. " UPnP,"
        componentCount = componentCount +1;
    end
    retVal = 0

    -- Check https state
    query = "LogicalIfName='" .. logicalIfName .. "' and accessMgmtEnable='1'"
    retVal = gui.networking.network.tableCountGetOnCond ("accessMgmt", query);
    if (tonumber(retVal) > 0) then
        --return status, "NETWORK_IN_USE_BY_REMOTE_MGMT"
        retStr = retStr .. " Remote Management,"
        componentCount = componentCount +1;
    end
    retVal = 0

    -- Check TR-069
    query = "LogicalIfName='" .. logicalIfName .. "' and tr69Status='1'"
    retVal = gui.networking.network.tableCountGetOnCond ("tr69Config", query);
    if (tonumber(retVal) > 0) then
        --return status, "NETWORK_IN_USE_BY_TR069"
        retStr = retStr .. " TR-069,"
        componentCount = componentCount +1;
    end
    retVal = 0

    -- Check Remote syslog
    query = "LogicalIfName='" .. logicalIfName .. "' and Enable='1'"
    retVal = gui.networking.network.tableCountGetOnCond ("sysLogInfo", query);
    if (tonumber(retVal) > 0) then
        --return status, "NETWORK_IN_USE_BY_RSYSLOG"
        retStr = retStr .. " Remote logging,"
        componentCount = componentCount +1;
    end
    retVal = 0

    -- Check time
    query = "LogicalIfName='" .. logicalIfName .. "'"
    retVal = gui.networking.network.tableCountGetOnCond ("ntp", query);
    if (tonumber(retVal) > 0) then
        --return status, "NETWORK_IN_USE_BY_NTP"
        retStr = retStr .. " NTP,"
        componentCount = componentCount +1;
    end
    retVal = 0

    -- Check network sharing
    query = "LogicalIfName='" .. logicalIfName .. "' and serverEnable='1'"
    retVal = gui.networking.network.tableCountGetOnCond ("smbGlobalConfig", query);
    if (tonumber(retVal) > 0) then
        --return status, "NETWORK_IN_USE_BY_SMB"
        retStr = retStr .. " Network File Sharing,"
        componentCount = componentCount +1;
    end
    retVal = 0

    -- Check WAN Bandwidth Configuration (uplink speed)
    query = "LogicalIfName='" .. logicalIfName .. "'"
    retVal = gui.networking.network.tableCountGetOnCond ("qosBwMtrConf", query);
    if (tonumber(retVal) > 0) then
        --return status, "NETWORK_IN_USE_BY_QOS_BWMGR"
        retStr = retStr .. " QoS Bandwidth Management,"
        componentCount = componentCount +1;
    end
    retVal = 0

    -- Check traffic selectors
    query = "IngressInterface='" .. nwRow["interfaceName"] .. "'"
    retVal = gui.networking.network.tableCountGetOnCond ("qosClassification", query);
    if (tonumber(retVal) > 0) then
        --return status, "NETWORK_IN_USE_BY_QOS_TRAFFIC_SELECTOR"
        retStr = retStr .. " QoS traffic selection,"
        componentCount = componentCount +1;
    end
    retVal = 0

    -- Check QoS Bandwidth Profiles
    -- get qosProfile configuration
    require "teamf1lualib/qos"
    if (nwRow["zoneType"] == "insecure") then
        ProfileName, profile = qos.iface.profileGet (logicalIfName)
        if (profile ~= nil) then
            query = "ProfileKey='" .. profile["ProfileKey"] .."' and configDefault = 0"
            status = qos.classQueue.cfgByQueryGet(query)
            if (status == "OK") then
                retStr = retStr .. " QoS Bandwidth Profiles,"
                componentCount = componentCount +1;
            end
        end
    end

    -- Check voip
    query = "NetworkName='" .. logicalIfName .. "'"
    retVal = gui.networking.network.tableCountGetOnCond ("voipProfile", query);
    if (tonumber(retVal) > 0) then
        --return status, "NETWORK_IN_USE_BY_ROUTING"
        retStr = retStr .. " VoIP"
        componentCount = componentCount +1;
    end
    retVal = 0

    if (retVal == 0) then
        if (componentCount > 0) then
            return true, retStr .." remove binding in respective applications."
        else
            return false, nil
        end
    end
end
-------------------------------------------------------------------------
-- @name gui.networking.network.delete
--
-- @description This routine deletes network(s)
--
-- @param nwTbl list of networks to be deleted
--
-- <ul>
-- <li><i>name</i> Name of the network
-- </ul>
--
-- @return status
-- @return errCode
--

function gui.networking.network.delete (nwTbl)
    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (nwTbl == nil) then
        return status, errCode
    end

    local valid = ""
    for rows, netName in pairs (nwTbl) do
        valid = gui.networking.network.checkIfDefaultNetwork(netName)
        if (valid == true) then
            return "ERROR", "DEFUALT_NETWORK_CONFIGURATION_NOT_ALLOWED"
        end
    end

    -- check if any applications are in use
    for rows, netName in pairs (nwTbl) do
        stat, errMsg = gui.networking.network.networkInUseCheck(netName);
        if (stat) then
            return "ERROR", errMsg
        end
    end

    -- deleing the entries from the associatedvlans table
    require "teamf1lualib/bonjour"
    status, errCode, associatedVlansTbl = bonjour.associatedVlansGet()
    if (status == "OK") then
        for i,v in pairs (nwTbl) do
            for p,q in pairs (associatedVlansTbl) do
                if (v == q.vlanName) then
                    status, errCode = bonjour.associatedVlansDelete(q.vlanName)
                    if (status ~= "OK") then
                        gui.dprintf("network.delete: failed to delete network " ..
                                    "from associated vlans table (" .. v .. ") <br>")
                        return status, errCode
                    end
                end
            end
        end
    end

    gui.dprintf("INPUT: " .. util.tableToStringRec(nwTbl))

    db.beginTransaction()

    require "teamf1lualib/network"
    for k,v in pairs(nwTbl) do

        --Check selected network has untagged
        --association with some port or not,
        --if exists then return error
        --
        status, errCode = gui.networking.network.defaultPortAssociationCheck(v);
        if (status ~= "OK") then
            db.rollback()
            gui.dprintf("network.delete: failed to delete network (" .. v .. ") <br>")
            return status, errCode
        end

        status, errCode = network.destroy (v)
        if (status ~= "OK") then
            db.rollback()
            gui.dprintf("network.delete: failed to delete network (" .. v .. ") <br>")
            return status, errCode
        end
    end

    db.commitTransaction(true)

    db.save2()

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------
-- @name gui.networking.network.statusGet
--
-- @description This routine get the status of the network
--
-- @param name network name
--
-- @return status
-- @return errCode
-- @return status
--
-- <ul>
-- <li><i>mac</i> Mac Address
-- <li><i>ipv4Addr</i> IPv4 Address
-- <li><i>ipv6Addr</i> IPv6 Address
-- <li><i>dhcpServer</i> DHCP server status
-- <li><i>dhcpv6Server</i> DHCPv6 server status
-- </ul>
--

function gui.networking.network.statusGet (name)
    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"
    local conf = {}
    local statusTbl = {}
    local ifconf = {}
    local zone

    if (name == nil) then
        return status, errCode
    end

    if (string.len(name) == 0) then
        name = "Internet"
    end

    require "teamf1lualib/network"
    status, errCode, conf = network.statusGet (name)
    if (status ~= "OK") then
        return status, errCode
    end

    if ((conf == nil) or (conf ["ifconf"] ==nil)) then
        return "ERROR", "NET_ERR_STATUS"
    end

    statusTbl.ipv4 = {}
    statusTbl.ipv6 = {}
    statusTbl.ipv4.addrs = {}
    statusTbl.ipv6.addrs = {}
    ifconf = conf["ifconf"]
    zone = ifconf["zoneType"]

    if (zone == "bridge") then
        return "ERROR", "NET_ERR_VLANBRIDGE_STATUS_NOTSUPP", statusTbl
    end

    if (network.hasL3Object(conf)) then

        statusTbl["networkType"] = gui.networking.zoneTypeToNetworkType (zone)
        statusTbl["mac"] = conf["ifHwAddr"]
        statusTbl.ipv4 = gui.networking.ipv4StatusGet(conf)
        statusTbl.ipv6 = gui.networking.ipv6StatusGet(conf)
    else
        local mode = {}
        local name = ""
        ifconf = conf["ifconf"]

        mode = ifDev.modeGet (ifconf["connectionType"])
        if ((mode ~= nil) and (mode[1] ~= nil)) then
            name = mode[1]["networkName"]
        end

        status, errCode, conf = network.statusGet (name)
        if (status ~= "OK") then
            return status, errCode
        end

        ifconf = conf["ifconf"]
        zone = ifconf["zoneType"]

        statusTbl["networkType"] = gui.networking.zoneTypeToNetworkType (zone)
        statusTbl["mac"] = conf["ifHwAddr"]
        statusTbl.ipv4 = gui.networking.ipv4StatusGet(conf)
        statusTbl.ipv6 = gui.networking.ipv6StatusGet(conf)
    end

    return "OK","STATUS_OK",statusTbl
end

-------------------------------------------------------------------------
-- @name gui.networking.network.ListGet
--
-- @description This routine gets the list of available networks
--
--
-- @return status
-- @return errCode
-- @return nwTbl list of networks
-- <ul>
-- <li><i>networkName</i> network name
-- <li><i>vlanId</i> vlan Id
-- <li><i>networkType</i> type of the network. LAN or WAN or Bridge
-- <li><i>associateNetwork</i> Associate Network
-- <li><i>enable</i> status of the network
-- </ul>
--
function gui.networking.network.ListGet ()
    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"
    local nwTbl = {}
    local conf = {}
    local index = 1

    require "teamf1lualib/ifDev"
    require "teamf1lualib/swVlan"

    status, errCode, conf = ifDev.cfgByQueryGet ()
    if (status ~= "OK") then
        return status, errCode
    end

    for k, v in pairs (conf) do
        nwTbl[index] = {}
        for kk, vv in pairs (v) do
            local vlanId = nil
            local vconf

            nwTbl[index]["networkName"] = v["networkName"]

            status, errCode, vconf = swVlan.confGet(v["LogicalIfName"])
            if (status == "OK") then
                vlanId = vconf["vlanId"]
            end

            --
            -- Currently, networkId is set to as VLAN ID when a network is created.
            -- but there is no requirement to do so.
            --
            -- NOTE: In this project network Id and vlanID are used
            -- interchangebly. The backend expects vlanId to be set
            -- if we want to create/configure a vlan termination (ethX.Y)
            -- interface
            --
            nwTbl[index]["vlanId"] = vlanId or v["networkId"]
            nwTbl[index]["networkType"] = gui.networking.zoneTypeToNetworkType (v["zoneType"])

            mode = ifDev.modeGet (v["connectionType"])
            if (mode ~= nil) then
                nwTbl[index]["associateNetwork"] = mode[1]["networkName"]
                nwTbl[index]["networkMode"] = mode[1]["mode"]
            else
                nwTbl[index]["associateNetwork"] = "N/A"
            end

            if (tonumber(v["enable"]) == 1) then
                nwTbl[index]["enable"] = "Enable"
            else
                nwTbl[index]["enable"] = "Disable"
            end
        end
        index = index + 1
    end

    return "OK","STATUS_OK",nwTbl
end

-------------------------------------------------------------------------
-- @name gui.networking.network.associateNetworkListGet
--
-- @description This routine gets the list of available associate networks
--
--
-- @return status
-- @return errCode
-- @return nwTbl list of networks
-- <ul>
-- <li><i>networkName</i> network name
-- <li><i>networkType</i> type of the network. LAN or WAN or Bridge
-- <li><i>enable</i> status of the network
-- </ul>
--
function gui.networking.network.associateNetworkListGet (name)
    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"
    local nwTbl = {}
    local conf = {}
    local index = 1
    local query = "networkName != '" .. name .. "' and enable = 1"

    require "teamf1lualib/ifDev"
    status,errCode,conf = ifDev.cfgByQueryGet (query)
    if (status ~= "OK") then
        return status, errCode
    end

    for k, v in pairs (conf) do
        nwTbl[index] = {}
        for kk, vv in pairs (v) do
            nwTbl[index]["networkName"] = v["networkName"]
            nwTbl[index]["networkType"] = gui.networking.zoneTypeToNetworkType (v["zoneType"])
            nwTbl[index]["enable"] = v["enable"]
        end
        index = index + 1
    end

    return "OK","STATUS_OK",nwTbl
end

-------------------------------------------------------------------------
-- @name gui.networking.network.mapGet
--
-- @description This routine gets the connection configuration of this network
--
-- @param name network name
--
-- @return status
-- @return errCode
-- @return conf
-- conf[i]["networkName"] -- Name of this network.
-- conf[i]["networkId"] -- network ID to use for this network (a.k.a VLANID)
-- conf[i]["zoneType"] -- LAN/WAN/DMZ or SECURE/INSECURE/PUBLIC
-- conf[i].PortTbl={} -- table of switch ports that are part of this network.
-- conf[i].PortTbl[<networkName> .. "_port_" .. j .. "_member"] -- 1 - if port<j> is member 0 - not a member
-- conf[i].PortTbl[<networkName> .. "_port_" .. j .. "_default"] -- 1 - if port<j> is default 0 - not a member
-- conf[i].apTbl={} -- table of wireless ports that are part of this network.
-- conf[i].apTbl[<networkName> .. "_wireless_" .. j .. "_member"] -- 1 - if wireless<j> is member 0 - not a member
-- conf[i].apTbl[<networkName> .. "_wireless_" .. j .. "_default"] -- 1 - if wireless<j> is default 0 - not a member
--

function gui.networking.network.mapGet ()
    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"
    local conf = {}
    local mapTbl = {}
    local index = 0

    require "teamf1lualib/ifDev"
    require "teamf1lualib/swVlan"
    status, errCode, conf = ifDev.cfgByQueryGet ()
    if (status ~= "OK") then
        return status, errCode
    end

    for i,dev in pairs(conf) do
        if (dev ~= nil) then
            name = dev["networkName"]
            if (name ~= nil and name ~= "Guest") then
                local vconf = {}
                local vlanId

                index = index + 1
                mapTbl[index] = {}
                mapTbl[index]["networkName"] = name
                status, errCode, vconf = swVlan.confGet(dev["LogicalIfName"])
                if (status == "OK") then
                    vlanId = vconf["vlanId"]
                    mapTbl[index]["networkId"] = vlanId
                else
                    mapTbl[index]["networkId"] = conf["networkId"]
                end

                mapTbl[index]["zoneType"] =
                    gui.networking.zoneTypeToNetworkType (dev["zoneType"])

                require "teamf1lualib/network"
                status, errCode, portTbl, ifTbl = network.portConfGet (dev)
                if (status ~= "OK") then
                    gui.dprintf ("VLAN port association get failed \n");
                end

                portTbl = gui.networking.portSwap (portTbl)
                mapTbl[index].portTbl = {}
                mapTbl[index].apTbl = {}

                if (portTbl ~= nil and ifTbl ~= nil) then
                    for k,v in pairs(portTbl) do
                        if (v["name"] == "BCM") then
                            if (v["port"] ~= nil) then
                                memberKey = name .. "_port_" .. v["port"] .. "_member"
                                defaultKey = name .. "_port_" .. v["port"] .. "_default"
                                mapTbl[index]["portTbl"][memberKey] = "1"
                                mapTbl[index]["portTbl"][defaultKey] = "0"
                                if (tonumber(v["default"]) == 1) then
                                    mapTbl[index]["portTbl"][defaultKey] = "1"
                                end
                            end
                        elseif (v["name"] == "Wireless") then
                            if (v["port"] ~= nil) then
                                memberKey = name .. "_wireless_" .. v["port"] .. "_member"
                                defaultKey = name .. "_wireless_" .. v["port"] .. "_default"
                                mapTbl[index]["apTbl"][memberKey] = "1"
                                mapTbl[index]["apTbl"][defaultKey] = "0"
                                if (tonumber(v["default"]) == 1) then
                                    mapTbl[index]["apTbl"][defaultKey] = "1"
                                end
                            end
                        end -- membership update
                    end -- for each port
                end -- data check
            end -- name check
        end -- dev check
    end -- for loop

    if (index == 0) then -- no data
        return "ERROR", "NET_ERR_NO_NETWORKS"
    end

    return "OK","STATUS_OK",mapTbl
end

-------------------------------------------------------------------------
-- @name gui.networking.network.pvidUpdate
--
-- @description This routine gets the connection configuration of this network
--
-- @param portTbl
--
--
function gui.networking.network.pvidUpdate(defaultTags)
    require "teamf1lualib/swPort"

    for port, PVID in pairs(defaultTags) do
        swPort.PVIDSet("BCM", port, PVID)
        if (tonumber(port) == 5) then
            swPort.PVIDSet("PSE", "1", PVID)
            swPort.PVIDSet("PSE", "2", PVID)
        end
    end

    return
end

-------------------------------------------------------------------------
-- @name gui.networking.network.mapEdit
--
-- @description This routine gets the connection configuration of this network
--
-- @param conf
-- conf[<networkName> .. "_networkname"] -- Name of this network.
-- conf[<networkName> .. "_networkId"] -- network ID to use for this network
-- conf[<networkName> .. "_zoneType"] -- LAN/WAN/DMZ or SECURE/INSECURE/PUBLIC
-- conf[<networkName>.."_port_"..j.."_member"] -- 1 - if port<j> is member to "<networkName>_networkId"
-- 0 - not a member
-- conf[<networkName>.."_port_"..j.."_default"] -- 1 - if port<j> is default to "<networkName>_networkId"
-- 0 - not a default
-- conf[<networkName>.."_wireless_"..j.."_member"] -- 1 - if wireless<j> is member to "<networkName>_networkId"
-- 0 - not a member
-- conf[<networkName>.."_wireless_"..j.."_default"] -- 1 - if wireless<j> is default to "<networkName>_networkId"
-- 0 - not a member
-- @return status
-- @return errCode
--

function gui.networking.network.mapEdit (conf)
    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"
    local mapTbl = {}
    local index = 0

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (conf == nil) then
        return status, errCode
    end

    gui.dprintf("INPUT: " .. util.tableToStringRec(conf))

    -- prepare the network list first before updating its params
    for k,v in pairs(conf) do
       -- gui.dprintf ("Key is: " .. k .. "<br>")
        i1, i2, networkName = string.find (k,"([%w_]-)_networkname")
        if (networkName ~= nil) then
            index = index + 1
            mapTbl[networkName] = {}
            mapTbl[networkName]["networkName"] = networkName
            mapTbl[networkName]["portTbl"] = {}
        end
    end

    -- fill in all other params
    for k,v in pairs(conf) do
        i1, i2, networkName = string.find (k, "([%w_]-)_networkId$")
        if (networkName ~= nil and mapTbl[networkName] ~= nil) then
            mapTbl[networkName]["vlanId"] = v
        end


        i1, i2, networkName = string.find (k, "([%w_]-)_zoneType$")
        if (networkName ~= nil and mapTbl[networkName] ~= nil) then
            mapTbl[networkName]["zoneType"] = v
        end
    end

    for k,v in pairs(conf) do
        i1, i2, networkName, portNumber = string.find (k, "([%w_]-)_port_(%d-)_member$")
        if (networkName ~= nil and mapTbl[networkName] ~= nil
            and mapTbl[networkName]["portTbl"] ~= nil and tonumber(v) == 1) then
            if (mapTbl[networkName]["portTbl"][portNumber] == nil) then
                mapTbl[networkName]["portTbl"][portNumber] = {}
                mapTbl[networkName]["portTbl"][portNumber]["type"] = "vlan"
                mapTbl[networkName]["portTbl"][portNumber]["port"] = portNumber
                if (mapTbl[networkName]["zoneType"] == "LAN") then
                    mapTbl[networkName]["portTbl"][portNumber]["ifname"] = "eth0."..mapTbl[networkName]["vlanId"] or ""
                elseif (mapTbl[networkName]["zoneType"] == "WAN") then
                    mapTbl[networkName]["portTbl"][portNumber]["ifname"] = "eth1."..mapTbl[networkName]["vlanId"] or ""
                elseif (mapTbl[networkName]["zoneType"] == "VLANBridge") then
                    mapTbl[networkName]["portTbl"][portNumber]["ifname"] = "eth0."..mapTbl[networkName]["vlanId"] or ""
                end
            end
        end

        i1, i2, networkName, portNumber = string.find (k, "([%w_]-)_port_(%d-)_default$")
        if (networkName ~= nil and mapTbl[networkName] ~= nil and
            mapTbl[networkName]["portTbl"] ~= nil and tonumber(v) == 1) then
            if (mapTbl[networkName]["portTbl"][portNumber] == nil) then
                mapTbl[networkName]["portTbl"][portNumber] = {}
                mapTbl[networkName]["portTbl"][portNumber]["type"] = "vlan"
                mapTbl[networkName]["portTbl"][portNumber]["port"] = portNumber
                if (mapTbl[networkName]["zoneType"] == "LAN") then
                    mapTbl[networkName]["portTbl"][portNumber]["ifname"] = "eth0."..mapTbl[networkName]["vlanId"] or ""
                elseif (mapTbl[networkName]["zoneType"] == "WAN") then
                    mapTbl[networkName]["portTbl"][portNumber]["ifname"] = "eth1."..mapTbl[networkName]["vlanId"] or ""
                elseif (mapTbl[networkName]["zoneType"] == "VLANBridge") then
                    mapTbl[networkName]["portTbl"][portNumber]["ifname"] = "eth0."..mapTbl[networkName]["vlanId"] or ""
                end
            end

            mapTbl[networkName]["portTbl"][portNumber]["default"] = 1
        end
    end

    gui.dprintf("INPUT: " .. util.tableToStringRec(mapTbl))

    local defaultTags = {}
    require "teamf1lualib/switch"
    local status, errCode, portList = switch.portTblGet ("BCM")
    for k,v in pairs(portList) do
        defaultTags[v.portNumber] = "0"
    end


    for k,v in pairs (mapTbl) do
        require "teamf1lualib/network"
        if (network.hasSwitchPort(v["portTbl"]) ~= nil) then
            if ((util.tableSize(v.portTbl) ~= nil) and (util.tableSize(v.portTbl) > 0)) then
                require "teamf1lualib/swVlan"
                portTbl = gui.networking.portSwap (v.portTbl)
                status, errCode = swVlan.mapEdit (v["vlanId"], portTbl)
                if (status ~= "OK") then
                    return status, errCode
                end

                -- collect all the default tags.
                for kk, vv in pairs(portTbl) do
                    if (vv.default and (tonumber(vv.default) > 0)) then
                        defaultTags[vv.port] = v["vlanId"]
                    end
                end

            end
        end
    end

    gui.networking.network.pvidUpdate(defaultTags)

    db.save2()

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name gui.networking.network.checkIfDefaultNetwork
--
-- @description This routine gets the connection configuration of this network
--
-- @param netName
--
-- @return status
--

function gui.networking.network.checkIfDefaultNetwork(netName)

    local status = false

    if (netName == nil) then
        return status
    end

    -- check for row selected whether that network is a default network
    if ((netName == "Internet") or (netName == "Local") or (netName == "Guest")) then
        return true
    else
        return false
    end

end

-------------------------------------------------------------------------------
-- @name gui.networking.network.hasModeChanged
--
-- @description This function checks if the network association has changed
-- for a given network.
--
-- @param newMode - new networkMode
-- @param currConf - current configuration of the networkstatus, errCode
--
-- @return true if mode has changed else false
--

function gui.networking.network.hasModeChanged (newConf, currConf)
    local currMode = newConf["networkMode"]
    local assocNet = newConf["associateNetwork"]

    mode = ifDev.modeGet (currConf["connectionType"])
    if ((mode == nil) or (mode[1] == nil)) then
        return true
    end

    for k,v in pairs(mode) do
        if (v["mode"] ~= tonumber(currMode)) then
            return true
        end

        if (platformLib.strcasecmp(v["networkName"], assocNet) ~= 0) then
            return true
        end
    end

    return false
end

-------------------------------------------------------------------------------
-- @name gui.networking.network.isEnabled
--
-- @description This function checks if the given network is enabled or
-- disable.
--
-- @param
--
-- @return true or false
--

function gui.networking.network.isEnabled(currConf)
    if (tonumber(currConf["enable"]) > 0) then
        return true
    else
        return false
    end
end

-------------------------------------------------------------------------------
-- @name gui.networking.network.isLANAccessAllowedForGuest
--
-- @description This functions checks if LAN access is allowed for the guest
-- network.
--
-- @param N/A
--
-- @return true if access is allowed else false
--

function gui.networking.network.isLANAccessAllowedForGuest()
    local status = "ERROR"
    local errCode = ""
    local networkName = "Guest"
    local conf = {}

    status, errCode, conf = ifDev.cfgByNameGet(networkName)
    if (status ~= "OK") then
        return false, errCode
    end

    local isAssoc, bdgCfg = network.hasBridgedAssoc (conf["connectionType"])
    if (isAssoc) then
        return true, bdgCfg["networkName"]
    else
        return false, nil
    end
end

-------------------------------------------------------------------------------
-- @name gui.networking.network.wirelessEnabledLANGet
--
-- @description This functions looks up the list of LAN networks and returns
-- the network what has wireless enabled.
--
-- @param N/A
--
-- @return vapList : list of VAP ports
--

function gui.networking.network.wirelessEnabledLANGet()
    local wlLanPortTbl = {}
    require "teamf1lualib/network"

    local wPortTbl = network.wirelessPortListGet()
    if (wPortTbl == nil) then
        return nil
    end

    -- Make a list of all the VAP's in the secure zone
    for k,v in pairs(wPortTbl) do

        if ((v["LogicalIfName"] == nil) or (string.len(v["LogicalIfName"]) == 0)) then
            table.insert(wlLanPortTbl, v)
        end

        if (network.isInZone(v["LogicalIfName"], "secure") == true) then
            --
            -- Add guest vap to the network, add only if LAN access
            -- is allowed for guest
            --
            if (v["ifname"] == "vap1") then

                if (gui.networking.network.isLANAccessAllowedForGuest() == true) then
                    table.insert(wlLanPortTbl, v)
                end
            else
                table.insert(wlLanPortTbl, v)
            end
        end
    end

    return wlLanPortTbl
end

-------------------------------------------------------------------------------
-- @name gui.networking.network.vlanExists
--
-- @description
--
-- @param
--
--

function gui.networking.network.vlanExists (networkType, vlanId)
    require "teamf1lualib/swVlan"
    local status
    local errCode
    local vlanIf

    status, errCode, vlanIf = swVlan.confGet(vlanId)
    if (status == "OK") then
        return true
    end

    return false
end

-------------------------------------------------------------------------------
-- @name gui.networking.network.guest.edit
--
-- @description This function edits the guest wireless configuration. This
-- function is called if the wireless status of a LAN network has been
-- changed. The guest vap is always added to the LAN network which has
-- wireless enabled (if LAN access is enabled for guest).
--
-- @param conf configuration of the LAN network being edited
--
-- @return status
-- @return errCode
--

function gui.networking.network.guest.edit(conf)
    require "teamf1lualib/ifDev"
    require "teamf1lualib/network"
    local name = "Guest"
    local guestVap = {}
    local portTbl = {}
    local ifTbl = {}

    -- Get the current guest configuration
    status, errCode, gconf = network.ifConfGet(name)
    if (status ~= "OK") then
        return "ERROR", "NET_ERR_GET_GUEST_NETWORK_CONF"
    end

    local mode = ifDev.modeGet(gconf["connectionType"])
    local connMode = mode[1]["mode"]
    local assocNet = mode[1]["networkName"]

    -- check if LAN access was not enabled, then return
    if (connMode ~= ifDev.mode.IFDEV_MODE_BRIDGED) then
        return "OK","STATUS_OK"
    end

    -- If wireless was disabled then add the Guest VAP
    -- back to the guest network
    --
    if ((conf["wirelessDisabled"] ~= nil) and
        (tonumber(conf["wirelessDisabled"]) > 0)) then
        guestVap["LogicalIfName"] = "IF3"
        portTbl, ifTbl = gui.networking.network.guestDefMapGet(guestVap)
        gconf["connectionType"] = network.assocStrGet(ifDev.mode.IFDEV_MODE_ROUTED, "Internet")
        gconf["portTbl"] = portTbl
        gconf["ifTbl"] = ifTbl
    end

    --
    -- if wireless was enabled, the guest vap would have already been
    -- added to the network. We need to change the
    -- network association of the Guest network
    --
    if ((conf["wirelessEnabled"] ~= nil) and
        (tonumber(conf["wirelessEnabled"]) > 0)) then
        -- Change the network association
        gconf["connectionType"] = network.assocStrGet(ifDev.mode.IFDEV_MODE_BRIDGED, conf["networkName"])
    end

    -- Edit the Guest network
    status, errCode = network.edit(gconf["networkName"], gconf)
    if (status ~= "OK") then
        return status, errCode
    end

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name gui.networking.network.guest.set
--
-- @description This function changes the configuration of the Guest network.
-- The following scenarios have been taken care of
-- a) Enable/Disable Guest network
-- b) Enable/Disable LAN access for Guest
--
-- @param conf
--
-- @return status
-- @return errCode
--

function gui.networking.network.guest.set(newConf)
    require "teamf1lualib/ifDev"
    require "teamf1lualib/dot11"
    require "teamf1lualib/network"
    local conf = {}
    local cfg = {}
    local name = "Guest"
    local status = "ERROR"
    local errCode = "NET_ERR_GUEST_WIFI_CONF"
    local LANNetwork = nil
    local oldMode = {}
    local portTbl = {}
    local ifTbl = {}
    local guestVap = {}
    local newNetwork = nil
    local newConnMode
    local query = "profileName = 'guest1'"
    local guestTbl = {}
    local rowid

    status, errCode, conf = network.ifConfGet(name)
    if (status ~= "OK") then
        return "ERROR", "NET_ERR_GET_GUEST_NETWORK_CONF"
    end

    local oldMode = ifDev.modeGet(conf["connectionType"])
    if (oldMode == nil) then
        return "ERROR", "NET_ERR_GET_GUEST_NETWORK_CONF"
    end

    local oldConnMode = oldMode[1]["mode"]
    local oldAssocNet = oldMode[1]["networkName"]

    if (oldConnMode == ifDev.mode.IFDEV_MODE_BRIDGED) then
        conf["allowLANAccess"] = 1
    else
        conf["allowLANAccess"] = 0
    end

    if (tonumber(newConf["allowLANAccess"]) == 1) then
        newConnMode = ifDev.mode.IFDEV_MODE_BRIDGED
    else
        newConnMode = ifDev.mode.IFDEV_MODE_ROUTED
    end

    local oldStatus = tonumber(conf["enable"])
    local newStatus = tonumber(newConf["enable"])
     --
     -- Find the LAN network on which wireless is enabled.
     --
     local wPortTbl = gui.networking.network.wirelessEnabledLANGet()
     if (wPortTbl ~= nil) then
         for k,v in pairs(wPortTbl) do
             status, errCode, cfg = ifDev.cfgByNameGet(v["LogicalIfName"])
             if (status == "OK") then
                 LANNetwork = cfg["networkName"]
                 break
             end
         end
     end
    --
    -- if guest access has been disabled, then make the guest vap
    -- part of Guest network
    --
    if (newStatus == 0) then
        conf["networkMode"] = ifDev.mode.IFDEV_MODE_ROUTED
        conf["associateNetwork"] = "Internet"
        newConnMode = ifDev.mode.IFDEV_MODE_ROUTED
    else
        if (oldConnMode ~= newConnMode) then
            if (newConnMode == ifDev.mode.IFDEV_MODE_BRIDGED) then
                network.dprintf("wireless port table: " .. util.tableToStringRec(wPortTbl))
                conf["networkMode"] = newConnMode
                if(LANNetwork == nil) then
                    return "ERROR","NO_LAN_NET"
                end
                network.dprintf("LANNetwork: " .. LANNetwork)
                conf["associateNetwork"] = LANNetwork
                status = ifDevLib.cmdExec ("/bin/sh /pfrm2.0/bin/guestNwFwRule.sh 0", "/dev/null", 1);
                if (status ~= 0) then
                    return status,"FAILED_TO_DEL_RULE"
                end
            else
                conf["networkMode"] = newConnMode
                conf["associateNetwork"] = newConf["associateNetwork"]
            end
        end
    end

    conf["enable"] = newConf["enable"]
    if(conf["associateNetwork"] == nil) then
        conf["associateNetwork"] = newConf["associateNetwork"]
    end

    if ((conf["associateNetwork"] ~= nil) and (string.len(conf["associateNetwork"]) ~= 0)) then
        newNetwork = conf["associateNetwork"]
        conf["connectionType"] = network.assocStrGet(newConnMode, newNetwork)
    else
        newNetwork = LANNetwork
        conf["connectionType"] = network.assocStrGet(newConnMode, oldAssocNet)
    end

    db.beginTransaction()

    portTbl, ifTbl = gui.networking.network.guestDefMapGet(guestVap)
    guestVap["portTbl"] = portTbl
    guestVap["ifTbl"] = ifTbl
    --
    -- Either the network mode has changed (Allow LAN access) or
    -- routed network (Route to WAN network) has changed then
    -- remove the guest vap from the current network and re-add
    -- it to the correct network
    --
    if ((oldConnMode ~= newConnMode) or
        (platformLib.strcasecmp(oldAssocNet, newNetwork) ~= 0)) then

        if (oldConnMode == ifDev.mode.IFDEV_MODE_ROUTED) then
            network.dprintf("Deleting the guest vap from Guest network")
            status, errCode = network.portRemove(conf["networkName"], guestVap)
            if (status ~= "OK") then
                db.rollback()
                return status, errCode
            end
        else
            network.dprintf("Deleting the guest vap from " .. oldAssocNet)
            status, errCode = network.portRemove(oldAssocNet, guestVap)
            if (status ~= "OK") then
                db.rollback()
                return status, errCode
            end
        end

        if (newConnMode == ifDev.mode.IFDEV_MODE_ROUTED) then
            --
            -- Add vap to the guest network
            --
            network.dprintf("Adding guest vap to Guest network")
            status, errCode = network.portAdd(name, guestVap)
            if (status ~= "OK") then
                db.rollback()
                return status, errCode
            end

            status = ifDevLib.cmdExec ("/bin/sh /pfrm2.0/bin/guestNwFwRule.sh 1", "/dev/null", 1);
            if (status ~= 0) then
                return status, "FAILED_TO_ADD_RULE"
            end
        else
            --
            -- Add vap to the associated network
            --
            network.dprintf("Adding guest vap to " .. newNetwork)
            status, errCode = network.portAdd(newNetwork, guestVap)
            if (status ~= "OK") then
                db.rollback()
                return status, errCode
            end
        end
    end

    --
    -- Edit the guest network
    --
    network.dprintf("Editing guest network mode: " .. conf["connectionType"])
    status, errCode, errstr = network.register(conf)
    if (status == "ERROR") then
        gui.dprintf("failed to update conf for guest network. Err:" .. errstr)
        db.rollback()
        return status, errCode
    end

    --
    -- If the status of the guest network has changed,
    -- the enable/disbale guest vap
    --
    if ((oldStatus == 0) and (newStatus == 1)) then
        gui.dprintf("Enabling guest VAP")
        dot11VAP.ifstateSet (ifTbl, 1)
        guestTbl = db.getRowWhere("dot11Profile",query,false)
        rowid = guestTbl["_ROWID_"]
        guestTbl = util.addPrefix(guestTbl,"dot11Profile.")
        status,errCode = dot11.profile_config (guestTbl,rowid, "edit")
        if(status ~= "OK") then
            return status,errCode
        end
    elseif ((oldStatus == 1) and (newStatus == 0)) then
        gui.dprintf("Disabling guest VAP")
        dot11VAP.ifstateSet (ifTbl, 0)
    end

    db.commitTransaction(true)

    db.save2()

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name gui.networking.network.wanListGet
--
-- @description This function get the list of WAN networks
--
-- @param N/A
--
-- @return status
-- @return errCode
-- @return wanTbl list of wan network names
--

function gui.networking.network.wanListGet ()
    require "teamf1lualib/ifDev"
    require "platformLib"

    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"
    local wanTbl = {}
    local conf = {}

    status, errCode, conf = ifDev.cfgByQueryGet ()
    if (status ~= "OK") then
        return status, errCode
    end

    for k, v in pairs (conf) do
        if (platformLib.strcasecmp(v["zoneType"], "insecure") == 0) then
            local netIf = {}
            netIf["networkName"] = v["networkName"]
            table.insert (wanTbl, netIf)
        end
    end

    return "OK","STATUS_OK", wanTbl
end

-------------------------------------------------------------------------------
-- @name gui.networking.network.guest.get
--
-- @description
--
-- @param N/A
--
-- @return status
-- @return errCode
-- @return conf
--

function gui.networking.network.guest.get()
    local conf = {}
    local name = "Guest"
    local status = "ERROR"
    local errCode = "NET_ERR_GUEST_WIFI_CONF"
    local wanList = {}

    status, errCode, conf = gui.networking.network.get(name)
    if (status ~= "OK") then
        return "ERROR", "NET_ERR_GET_GUEST_NETWORK_CONF"
    end

    status, errCode, wanList = gui.networking.network.wanListGet ()
    if (status == "OK") then
        conf["networkList"] = wanList
    end

    if (tonumber(conf["networkMode"]) == ifDev.mode.IFDEV_MODE_BRIDGED) then
        conf["allowLANAccess"] = "1"
        conf["routeToWAN"] = "0"
        conf["associateNetwork"] = wanList[1]["networkName"]
    else
        conf["allowLANAccess"] = "0"
        conf["routeToWAN"] = "1"
    end
    conf["wirelessNetName"] = gui.networking.network.guestVapSsidGet ()

    return "OK", "STATUS_OK", conf
end

-------------------------------------------------------------------------------
-- @name gui.networking.network.vlan.listGet
--
-- @description - this function gets the list of vlan associated with a given network
--
-- @param N/A
--
-- @return status
-- @return errCode
--

function gui.networking.network.vlan.listGet (networkName)

    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"
    local nwTbl  = {}
    local conf   = {}
    local index  = 1
	local LogicalIfName = ""

    require "teamf1lualib/ifDev"
    require "teamf1lualib/swVlan"
    require "teamf1lualib/ethernet"

	if (networkName == "LAN") then 
		LogicalIfName="IF2"
		status,errCode, vconf =  swVlan.confsGet(LogicalIfName)

	elseif (networkName == "WAN") then
		LogicalIfName="IF1"
		status,errCode, vconf =  ethernet.vlansGet (LogicalIfName)
	end

    for i,v in ipairs (vconf) do
        vconf[i] = {}
        vconf[i] = v
        vconf[i]["vlanEncapIf.vlanId"] = util.filterXSSChars(v["vlanEncapIf.vlanId"])
    end

	return status,errCode, vconf

	

end

-------------------------------------------------------------------------------
-- @name gui.networking.network.vlan.maxStatusGet
--
-- @description - this function return if further vlan addition is allowed on network
--
-- @param N/A
--
-- @return status
-- @return 
--

function gui.networking.network.vlan.maxStatusGet (networkName)

	local maxVLANonLAN = 5
	local maxVLANonLAN = 5
	local status,errCode, vconf = gui.networking.network.vlan.listGet (networkName)
	if (#vconf == maxVLANonLAN) then
		return true
	else
		return false
	end
end

-------------------------------------------------------------------------------
-- @name gui.networking.network.vlan.duplicateStatusGet
--
-- @description - this function returns if duplicate vlanID is being added
--
-- @param N/A
--
-- @return status
-- @return 
--

function gui.networking.network.vlan.duplicateStatusGet (networkName, vlanID)

	local vlanRow = {}

	if (networkName == "LAN") then
		vlanRow = db.getRows ("vlanEncapIf", "vlanId", vlanID)
	elseif (networkName == "WAN") then
		vlanRow = db.getRows ("ethernetVLAN", "vlanId", vlanID)
	end

	if ((vlanRow ~= nil) and (#vlanRow > 0)) then
		return true
	else
		return false
	end

end

-------------------------------------------------------------------------------
-- @name gui.networking.network.vlan.memberShipGet
--
-- @description - this function gets the port and vlan membership
--
-- @param N/A
--
-- @return status
-- @return errCode
--

function gui.networking.network.vlan.memberShipGet (networkName)

    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"
    local nwTbl  = {}
    local conf   = {}
    local index  = 1
	local LogicalIfName = ""

    require "teamf1lualib/ifDev"
    require "teamf1lualib/swVlan"

	if (networkName == "LAN") then 
		LogicalIfName="IF2"
		status,errCode, vconf =  swVlan.confsGet(LogicalIfName)

	end

	local fwdMap = {}
	local untagMap = {}



	for k,v in pairs (vconf) do
		fwdMap = util.split (v["vlanEncapIf.fwdMap"],",")
		untagMap = util.split (v["vlanEncapIf.untagMap"],",")

		for i=1,numOfPorts do
			v["vlanEncapIf.fwdMap"..i] = "0"
			v["vlanEncapIf.default"..i] = "0"
		end

		if (v["vlanEncapIf.fwdMap"] ~= nil and v["vlanEncapIf.fwdMap"] ~= "") then
			for kk,vv in pairs (fwdMap) do
				v["vlanEncapIf.fwdMap"..(tonumber(vv)-portCorrection)] = "1"
			end
		end
		
		if (v["vlanEncapIf.untagMap"] ~= nil and v["vlanEncapIf.untagMap"] ~= "") then
			for kk,vv in pairs (untagMap) do
				v["vlanEncapIf.default"..(tonumber(vv)-portCorrection)] = "1"
			end
		end	
	end
	port = {}
	for i=1,numOfPorts do
		j = 0
		port[i]={}
		port[i]["noMember"] = "1"
		port[i]["noDefault"] = "1"
		port[i]["default"] = "0"
		port[i]["members"] = {}
		for k,v in pairs (vconf)  do
			if (v["vlanEncapIf.default"..i] == "1") then
				port[i]["noDefault"] = "0"
				port[i]["default"] = util.filterXSSChars(v["vlanEncapIf.vlanId"])
			end
			if (v["vlanEncapIf.fwdMap"..i] == "1") then
				port[i]["noMember"] = "0"
				port[i]["members"][j] = util.filterXSSChars(v["vlanEncapIf.vlanId"])
				j=j+1
			end			
            vconf[k]["vlanEncapIf.vlanId"] = util.filterXSSChars(v["vlanEncapIf.vlanId"])
		end
	
	end
	

	return status,errCode, vconf, port

	

end

-------------------------------------------------------------------------------
-- @name this function gets the trunk mode status for a given network
--
-- @description - this function sets the trunk mode status on WAN
--
-- @param N/A
--
-- @return status
-- @return errCode
--

function gui.networking.network.vlan.statusGet (networkName)

	require "teamf1lualib/ethernet"
	if (networkName == "LAN") then LogicalIfName="IF2"
	elseif (networkName == "WAN") then LogicalIfName="IF1"
	end

	status,errCode, vconf =  ethernet.trunkModeGet(LogicalIfName)
	return status,errCode, vconf	

end

-------------------------------------------------------------------------------
-- @name gui.networking.network.vlan.statusSet
--
-- @description - this function sets the trunk mode status on WAN
--
-- @param N/A
--
-- @return status
-- @return errCode
--

function gui.networking.network.vlan.statusSet (inputTable, networkName)
	require "teamf1lualib/ethernet"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (inputTable == nil or networkName == nil) then
        return status, errCode
    end

	if (networkName == "LAN") then LogicalIfName="IF2"
	elseif (networkName == "WAN") then LogicalIfName="IF1"
	end

	local gponRow = db.getRow ("gpon", "_ROWID_", "1")
	if (networkName == "WAN" and gponRow ~= nil and gponRow["gpon.status"] == "1") then
		return "ERROR", "In GPON mode VLAN on WAN is configured from the WAN Port type page"
	end


	db.beginTransaction ()

	status,errCode, vconf =  ethernet.trunkModeGet(LogicalIfName)

	vconf["ethernet.trunkPort"] = inputTable["trunkMode"]

	status,errCode =  ethernet.trunkModeSet(vconf, vconf["ethernet._ROWID_"],"edit")

    db.commitTransaction(true)

    db.save2()

	return status,errCode	

end

-------------------------------------------------------------------------------
-- @name gui.networking.network.vlan.vlanDelete
--
-- @description - this function deletes a vlan from WAN or LAN
--
-- @param N/A
--
-- @return status
-- @return errCode
--

function gui.networking.network.vlan.vlanDelete (inputTable, networkName)

	require "teamf1lualib/ethernet"
	require "teamf1lualib/swMgr"
	require "teamf1lualib/bridgeLib"
   
    local WANPORT = "5"
    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (inputTable == nil or networkName == nil) then
        return "ERROR", "VLAN_DELETE_FAILED"
    end

	if (networkName == "LAN") then

        local gponRow = db.getRow ("gpon", "_ROWID_", "1")
	    if (gponRow == nil ) then
		    return "ERROR", "WAN_VLAN_GET_FAILED"
	    end

		for k,v in pairs (inputTable) do
			local vlanRow = db.getRow ("vlanEncapIf", "_ROWID_", v)
			if (vlanRow == nil) then
				return "ERROR", "VLAN_DELETE_FAILED"
			end
			if  (vlanRow["vlanEncapIf.vlanId"] == "1") then
				return "ERROR", "DEFAULT_VLAN_CANNOT_BE_DELETED"
			end

			if (vlanRow["vlanEncapIf.untagMap"] ~= "") then
				return "ERROR", "SELECTED_VLAN_IS_SET_AS_DEFAULT"
			end

		end
		-- all sanity checks are done, do the delete

		for k,v in pairs (inputTable) do
			
			local vlanRow = db.getRow ("vlanEncapIf", "_ROWID_", v)
			local LogicalIfName = vlanRow["vlanEncapIf.LogicalIfName"]
			local iface = db.getAttribute ("ethernet", "LogicalIfName", LogicalIfName, "interfaceName")
			local vconf = {}
            local delRow = {}
            delRow["vlanEncapIf._ROWID_"]=vlanRow["vlanEncapIf._ROWID_"]
			local bridgeName= bridge.ifNameGet(LogicalIfName)
			vconf[1] = {}
			vconf[1]["ifname"] =  iface.."."..vlanRow["vlanEncapIf.vlanId"]
			status, errorCode = bridge.portDelete(bridgeName, vconf)
			status,errCode = swMgr.dbConfig ("vlanEncapIf", delRow, "" , "delete")
		local cmd="/pfrm2.0/bin/vlanUpdate.sh DEL " .. vlanRow["vlanEncapIf.vlanId"] .. " > /dev/null 2>&1"
				--print(cmd)
		os.execute(cmd)
		end
		

	elseif (networkName == "WAN") then

		status,errCode = ethernetVLAN.ethernetVLAN_config (inputTable, "-1", "delete")

	end

	if (status == "OK") then
		db.save2()
	end

	return 	status,errCode
end

-------------------------------------------------------------------------------
-- @name  gui.networking.network.vlan.vlanAdd
--
-- @description - this function is used for adding a vlan to both LAN and WAN
--
-- @param N/A
--
-- @return status
-- @return errCode
--

function gui.networking.network.vlan.vlanAdd (inputTable, networkName)
	require "teamf1lualib/ethernet"
	require "teamf1lualib/swMgr"
	require "teamf1lualib/bridgeLib"

    --locals
    local WIFIPORT = "7,8,9"
    local WANPORT = "5"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (inputTable == nil or networkName == nil) then
        return "ERROR", "VLAN_ADD_FAILED"
    end

	if (networkName == "LAN") then LogicalIfName="IF2"
	elseif (networkName == "WAN") then LogicalIfName="IF1"
	end

	local addStatus = gui.networking.network.vlan.maxStatusGet (networkName)
	if (addStatus) then
		return "ERROR","Max number of allowed vlans are configured"
	end

	local duplicateStatus = gui.networking.network.vlan.duplicateStatusGet (networkName, inputTable["vlanID"])
	if (duplicateStatus) then
		return "ERROR","Added VLAN ID is already present"
	end

	local bridgeVlanRow = db.getRow ("bridgeMode", "_ROWID_", "1")
	if (bridgeVlanRow["bridgeMode.status"] == "1" and bridgeVlanRow["bridgeMode.vlanID"] == inputTable["vlanID"]) then
		return "ERROR", "Added VLAN is already configured in bridge mode"
	end

	if (bridgeVlanRow["bridgeMode.status"] == "0") then
		-- invalidate the port number becuse bridge mode is off
		bridgeVlanRow["bridgeMode.portNumber"] = "0"
	end

	local gponRow = db.getRow ("gpon", "_ROWID_", "1")
	if (networkName == "WAN" and gponRow ~= nil and gponRow["gpon.status"] == "1" and gponRow["gpon.vlanID"] == inputTable["vlanID"]) then
		return "ERROR", "Added VLAN is already configured in GPON mode"
	end

    if (networkName == "LAN") then
        if (inputTable["vlanID"] ~= nil) then
            if (tonumber(inputTable["vlanID"]) > 4094 or tonumber(inputTable["vlanID"]) < 2) then
                return "ERROR", "INVALID_VLAN_ID"
            end
        end
    else
        if (inputTable["vlanID"] ~= nil) then
            if (tonumber(inputTable["vlanID"]) > 4094) then
                return "ERROR", "INVALID_VLAN_ID"
            end
        end
    end
    
	db.beginTransaction ()

	if (networkName == "WAN") then
		local vconf = {}
		vconf["LogicalIfName"] = LogicalIfName
		vconf["vlanId"] = inputTable["vlanID"]
		vconf = util.addPrefix (vconf, "ethernetVLAN.");

		status,errCode =  ethernetVLAN.ethernetVLAN_config(vconf, "-1","add")
	elseif (networkName == "LAN") then

	local defaultFwdMap = ""
	for i=1,numOfPorts do
		if ((i+portCorrection) ~= tonumber(bridgeVlanRow["bridgeMode.portNumber"])) then
			if (defaultFwdMap == "") then
				defaultFwdMap = (i+portCorrection)
			else
				defaultFwdMap = defaultFwdMap..","..(i+portCorrection)
			end		
		end
	end

	-- for econet devices , vlan rules are stored in indexes starting from 1
	-- Get the max rowID and add 1 to get next rowID which is used as  index in vlan rule 
	local vlanIndex = tonumber (db.getMaxVal ("vlanEncapIf", "inSwitchOnly")) + 1

	-- for lan side there are 2 operations. updating vlanEncapIf and bridgePorts

	local iface = db.getAttribute ("ethernet", "LogicalIfName", LogicalIfName, "interfaceName")
		local vconf = {}
		if (iface ~= nil or iface ~= "") then
			vconf["vlanId"] = inputTable["vlanID"]
			vconf["vlanName"] = LogicalIfName
			vconf["interfaceName"]  = iface
			vconf["ingressMap"] = ""
			vconf["egressMap"] = ""
			vconf["fwdMap"] = defaultFwdMap
			vconf["untagMap"] = ""
			-- inSwitchOnly is not used in econet devices , so use it for vlan index which is used to add vlan rules in econet eth driver. 
			vconf["inSwitchOnly"] = vlanIndex
			vconf["LogicalIfName"] = LogicalIfName
			vconf = util.addPrefix (vconf, "vlanEncapIf.");
			
			status,errCode = swMgr.dbConfig ("vlanEncapIf", vconf, -1  , "add")
		
			-- Call vlan script to do all required operations
			local cmd="/pfrm2.0/bin/vlanUpdate.sh ADD " .. vconf["vlanEncapIf.vlanId"] .. " " .. vconf["vlanEncapIf.fwdMap"] .. " " .. vlanIndex .. " " .. vconf["vlanEncapIf.untagMap"] .. " > /dev/null 2>&1"
			os.execute(cmd)
            swMgr.l2_vlan_rules_update_ECONET (1)
		end
		

	end

	if (status == "OK") then
   		db.commitTransaction(true)
    	db.save2()
	else
		db.rollback ()
	end

	local bridge = db.getAttribute ("bridgemode", "status","1" , "rowid")
    if (bridge ~= nil and bridge ~= "") then
       db.setAttribute ("bridgemode", "rowid", "1", "status","0") 
       db.setAttribute ("bridgemode", "rowid", "1", "status","1") 
    end

	return status,errCode	

end

-------------------------------------------------------------------------------
-- @name gui.networking.network.dmz.get
--
-- @description - this function updates the port membership for vlans
--
-- @param N/A
--
-- @return status
-- @return errCode
--

function  gui.networking.network.dmz.get ()

	require "teamf1lualib/dmz"
	local dmzRow = dmz.dmzGet ()
	if (dmzRow == nil) then
		return "ERROR", "ERROR", nil
	else
        dmzRow["ipAddr"] = util.filterXSSChars(dmzRow["ipAddr"])
		return "OK", "OK", dmzRow
	end

end

-------------------------------------------------------------------------------
-- @name gui.networking.network.dmz.set
--
-- @description - this function updates the port membership for vlans
--
-- @param N/A
--
-- @return status
-- @return errCode
--

function  gui.networking.network.dmz.set (inputTable)

	require "teamf1lualib/dmz"
    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (inputTable == nil) then
        return "ERROR", "Dmz configuration failed"
    end

	status, statusCode = dmz.dmzSet (inputTable)

	if (status == "OK") then db.save2() end

	return status, statusCode

end

-------------------------------------------------------------------------------
-- @name gui.networking.network.dmz6.get
--
-- @description - this function updates the port membership for vlans
--
-- @param N/A
--
-- @return status
-- @return errCode
--

function  gui.networking.network.dmz6.get ()

	require "teamf1lualib/dmz"
	local dmzRow = dmz.dmz6Get ()
	if (dmzRow == nil) then
		return "ERROR", "ERROR", nil
	else
        dmzRow["ipAddr"] = util.filterXSSChars(dmzRow["ipAddr"])
		return "OK", "OK", dmzRow
	end

end

-------------------------------------------------------------------------------
-- @name gui.networking.network.dmz6.set
--
-- @description - this function updates the port membership for vlans
--
-- @param N/A
--
-- @return status
-- @return errCode
--

function  gui.networking.network.dmz6.set (inputTable)

	require "teamf1lualib/dmz"
    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (inputTable == nil) then
        return "ERROR", "Dmz configuration failed"
    end

	status, statusCode = dmz.dmz6Set (inputTable)

	if (status == "OK") then db.save2() end

	return status, statusCode

end

-------------------------------------------------------------------------------
-- @name gui.networking.network.vlan.update
--
-- @description - this function updates the port membership for vlans
--
-- @param N/A
--
-- @return status
-- @return errCode
--

function  gui.networking.network.vlan.update (inputTable, networkName)

	require "teamf1lualib/swVlan"	

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (inputTable == nil or networkName == nil) then
        return "ERROR", "PORT_ASSOCIATION_CONFIG_FAILED"
    end

	if (networkName == "LAN") then LogicalIfName="IF2"
	elseif (networkName == "WAN") then LogicalIfName="IF1"
	end

	local bridgeRow = db.getRow ("bridgeMode", "_ROWID_", "1")
	for i=1,3 do
		if (bridgeRow["bridgeMode.status"] == "1" and inputTable["portAssoc"..bridgeRow["bridgeMode.portNumber"]] ~= "0") then
			return "ERROR", "Selected Port is configured in Bridge Mode"
		end
	end

	local vlanRow = {}
	local fwdMap = ""
	local unTagMap = ""
    local WIFIPORT = "7,8,9"
    local WANPORT = "5"

	db.beginTransaction ()

    local gponRow = db.getRow ("gpon", "_ROWID_", "1")
	if (gponRow == nil) then
	    return "ERROR", "Unable to get WAN VLAN"	
	end

	local vlanRows = db.getRows ("vlanEncapIf", "LogicalIfName", LogicalIfName)
	local numvlanRows = #vlanRows

	for k,v in pairs (vlanRows) do
		v["vlanEncapIf.fwdMap"] = ""
		v["vlanEncapIf.untagMap"] = ""
		for i=1,numOfPorts do
			local portMembers = {}
			if (inputTable["portMembers"][i] ~= nil) then
				portMembers = util.split (inputTable["portMembers"][i],",")
				for kk,vv in pairs(portMembers) do

					if (vv == v["vlanEncapIf.vlanId"]) then
						if (v["vlanEncapIf.fwdMap"] == "") then
							v["vlanEncapIf.fwdMap"] = (i+portCorrection)
						else
							v["vlanEncapIf.fwdMap"] = v["vlanEncapIf.fwdMap"]..","..(i+portCorrection)
						end
					end
				
				end
			end
			if (inputTable["portDefault"..i] == v["vlanEncapIf.vlanId"]) then
						if (v["vlanEncapIf.untagMap"] == "") then
							v["vlanEncapIf.untagMap"] = (i+portCorrection)
						else
							v["vlanEncapIf.untagMap"] = v["vlanEncapIf.untagMap"]..","..(i+portCorrection)
						end				
			end

		end

		if (v["vlanEncapIf.fwdMap"] == nil or v["vlanEncapIf.fwdMap"] == "") then
			fwdMap = "NO"
		else
			fwdMap = v["vlanEncapIf.fwdMap"]
		end


		status,errCode =swMgr.dbConfig ("vlanEncapIf", v, v["vlanEncapIf._ROWID_"], "edit")
		local cmd="/pfrm2.0/bin/vlanUpdate.sh DEL " .. v["vlanEncapIf.vlanId"] .. " > /dev/null 2>&1"
		os.execute(cmd)
		local cmd="/pfrm2.0/bin/vlanUpdate.sh ADD " .. v["vlanEncapIf.vlanId"] .. " " .. fwdMap .. " " ..v["vlanEncapIf.inSwitchOnly"] .. " " .. v["vlanEncapIf.untagMap"] .. " > /dev/null 2>&1"
		os.execute(cmd)
	end	

	if ( status == "OK") then

    	db.commitTransaction(true)

    	db.save2()

		swMgr.l2_vlan_rules_update_ECONET (1)
	else

		db.rollback ()
	end

	return status,errCode	

end
