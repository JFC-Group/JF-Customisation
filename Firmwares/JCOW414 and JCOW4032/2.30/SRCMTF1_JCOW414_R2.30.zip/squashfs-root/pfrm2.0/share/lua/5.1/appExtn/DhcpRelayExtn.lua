-- @copyright Copyright (c) 2012, TeamF1, Inc. 

require "teamf1lualib/evtDsptch"
require "teamf1lualib/dhcpRelay"
require "dhcpRelayLib"
require "appExtn/AppExtn"

DhcpRelayExtn = OoUtil.inheritsFrom(AppExtn)
DhcpRelayExtn.name    = "DHCP Relay"
DhcpRelayExtn.className  = "DhcpRelayExtn"
DhcpRelayExtn.classId = "dhcpr"
DhcpRelayExtn.dbTable = ""
DhcpRelayExtn.logger  = nil

local SUPER = require("appExtn.AppExtn")

local netEvents  = {}
netEvents[evtDsptch.event.IFDEV_EVENT_NET_ADD] =  1
netEvents[evtDsptch.event.IFDEV_EVENT_NET_DEL] =  1
netEvents[evtDsptch.event.IFDEV_EVENT_IP4_NET_UP] =  1
netEvents[evtDsptch.event.IFDEV_EVENT_IP_ADDR_CHG] =  1
netEvents[evtDsptch.event.IFDEV_EVENT_IP4_NET_DOWN] =  1

local cfgEvents = {}
cfgEvents[db.event.SQLITE_INSERT] = 1
cfgEvents[db.event.SQLITE_UPDATE] = 1
cfgEvents[db.event.SQLITE_DELETE] = 1

-------------------------------------------------------------------------------
-- @name DhcpRelayExtn:new
--
-- @description This function creates a new instance object for dhcp relay, loads
-- the configuration and event subcriptions
--
-- @return  0 for success and -1 for error
--

function DhcpRelayExtn:new(instanceId, props)

    assert(instanceId, "Instance ID must be specified")

    -- create a new instance
    self = DhcpRelayExtn.create()

    SUPER.new(self, DhcpRelayExtn.classId, instanceId, props)

    self.name  = DhcpRelayExtn.name
    self.dbTable = DhcpRelayExtn.dbTable
    self.dbconn = DhcpRelayExtn.dbconn
    self.logger = DhcpRelayExtn.logger

    -- initialize events for this instance
    self.netEvents = netEvents              
    self.cfgEvents = cfgEvents

    local handle = db.gethandle(self.dbconn)
    dhcpRelayLib.init(handle)

    -- load the configuration for this instance          
    local status, errCode, self = self:load()
    if (status == nil) then
        LOG:error("failed to load " .. classId .. 
                  "(" .. instanceId .. ")")
        return nil
    end        

    -- register with appd
    appd.appExtnRegister(self)                    

    return self
end

-------------------------------------------------------------------------------
-- @name DhcpRelayExtn:load
--
-- @description This function loads the dhcpRelay configuration
--
-- @return  
--

function DhcpRelayExtn:load() 

    self.ifTbl = {}

    -- load all interfaces
    local ifTbl = db.getTable("dhcpRelay", false)
    if (ifTbl ~= nil) then
        self.ifTbl = ifTbl
    end        

    dhcpRelayLib.cfgLoad()

    return  "OK", "STATUS_OK", self
end        

-------------------------------------------------------------------------------
-- @name DhcpRelayExtn:delete
--
-- @description This function destroys an instance of this extension
--
-- @return  
--

function DhcpRelayExtn:delete() 
    appd.appExtnUnregister(self)
    return 
end        

-------------------------------------------------------------------------------
-- @name DhcpRelayExtn:start
--
-- @description This function starts dhcp relay
--
-- @return  0 for success and -1 for error
--

function DhcpRelayExtn:start ()

    LOG:info("Starting " .. self.name)

    local status = dhcpRelayLib.start()
    if (status < 0) then
        LOG:error(self.name .. " start failed")
        return status
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name DhcpRelayExtn:restart
--
-- @description This function restarts dhcp relay
--
-- @return  0 for success and -1 for error
--

function DhcpRelayExtn:restart ()

    LOG:info("Re-starting " .. self.name)
    local status = dhcpRelayLib.restart()
    if (status < 0) then
        LOG:error(self.name .. " restart failed")
        return status
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name DhcpRelayExtn:getAppName
--
-- @description This function gets the name of this extension
--
-- @return  
--

function DhcpRelayExtn:getAppName()
   return self.name
end

-------------------------------------------------------------------------------
-- @name DhcpRelayExtn:onNetEvent
--
-- @description This function handles network events for dhcp relay
--
-- @param  netevent event info
--
-- @return  0 for success and -1 for error
--

function DhcpRelayExtn:onNetEvent(netevent)
    local status
    local errCode
    local conf = {}

    if (self:isEventSubscribed(netevent) == false) then
        LOG:ddebug(self.name .. " not subscribed to event: " ..
                  netevent.event .. " on " .. netevent.ifname)
        return 0
    end        

    if (netevent.event == evtDsptch.event.IFDEV_EVENT_NET_ADD) then
        status, errCode, conf = dhcpRelay.confGet(netevent.ifname)
        if (status ~= "OK") then
            conf = {}
            conf["LogicalIfName"] = netevent.ifname
            status, errCode = dhcpRelay.confEdit(conf)
            if (status ~= "OK") then
                LOG:debug("failed to add dhcp-relay configurationf for: " .. 
                          netevent.ifname)
            end                
        end            
    elseif (netevent.event == evtDsptch.event.IFDEV_EVENT_NET_DEL) then
        status, errCode, conf = dhcpRelay.confGet(netevent.ifname)
        if (status == "OK") then
            status, errCode = dhcpRelay.confDelete(conf)
            if (status ~= "OK") then
                LOG:debug("failed to delete dhcp-relay configurationf for: " .. 
                          netevent.ifname)
            end                
        end            
    else
        self:restart()
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name DhcpRelayExtn:isEventSubscribed
--
-- @description This function checks if this instance is subcribed to
-- the event pass as input
--
-- @param event event info
--
-- @return  0 for success and -1 for error
--

function DhcpRelayExtn:isEventSubscribed(event)

    if (event.type == appd.eventType.APPD_EV_NET) then
        require "teamf1lualib/network"
        
        -- if it is not LAN, then skip 
        if (not network.isLAN(event.ifname)) then
            return false
        end

        local evstate = self.netEvents[event.event]
        if (evstate == nil) then
            return false
        end            
                    
        if (evstate > 0) then
            return true
        end        

    elseif (event.type == appd.eventType.APPD_EV_CFG) then

        -- are we subscribed to this event                        
        local evstate = self.cfgEvents[event.event]
        if (evstate == nil) then
            return false
        end            

        if (evstate > 0) then
            return true
        end        
    end

    return false
end

-------------------------------------------------------------------------------
-- @name DhcpRelayExtn:onCfgEvent
--
-- @description This function is called by appd to handle configuration events
-- 
-- @param  cfgevent event information
--
-- @return  
--

function DhcpRelayExtn:onCfgEvent(cfgevent)

    if (self:isEventSubscribed(cfgevent) == false) then
        LOG:ddebug(self.name .. " not subscribed to event: " ..
                   cfgevent.event .. " on " .. cfgevent.dbTable)
        return
    end        

    -- restart dhcp relay
    self:restart()

    return
end

-------------------------------------------------------------------------------
-- @name DhcpRelayExtn:print
--
-- @description This function is called by appd to bootstrap all instances of 
-- this application. 
--
-- @param  
--
-- @return  
--

function DhcpRelayExtn:print()
    require "util/strlib"

    LOG:info("Class     : " .. self.classId)
    LOG:info("Instance  : " .. self.instanceId)
    LOG:info("App Name  : " .. self:getAppName())
    LOG:info("Conf      : " .. strlib.serializeTbl(self:getProps()))
    return
end

-------------------------------------------------------------------------------
-- @name DhcpRelayExtn.cfgEventCallback
--
-- @description This function is called by appd whenever there is a configuration
-- event.
--
-- @param  
--
-- @return  
--

function DhcpRelayExtn.cfgEventCallback(obj, info)
    local status
    local errCode

    LOG:debug(DhcpRelayExtn.classId .. " configuration callback called  " .. 
              "for event: " ..  info.event .. " on rowId " .. info.rowId)

    local obj = appd.appExtnFind(DhcpRelayExtn.classId, "1")
    if (obj) then 
        status, errCode, obj = obj:load()
        if (status == "OK") then
            obj:onCfgEvent(info) 
        end
    end

    return 0
end

-------------------------------------------------------------------------------
-- @name DhcpRelayExtn.bootstrap
--
-- @description This function is called by appd on startup to bootstrap all 
-- instances of this application. 
--
-- @param  
--
-- @return  
--

function DhcpRelayExtn.bootstrap()
    local callbackTable= {}

    dhcpRelayLib.killAll()

    local callback = {}
    callback.type = appd.eventType.APPD_EV_CFG
    callback.dbTable = "dhcpRelay"
    callback.routine = DhcpRelayExtn.cfgEventCallback
    table.insert(callbackTable, callback)

    appd.callbackRegister (DhcpRelayExtn.classId, callbackTable)

    -- create an instance 
    local instanceId = "1"
    local obj = DhcpRelayExtn:new(instanceId)
    if (obj) then
        obj:start()
    end                        

    return 0
end

return DhcpRelayExtn
