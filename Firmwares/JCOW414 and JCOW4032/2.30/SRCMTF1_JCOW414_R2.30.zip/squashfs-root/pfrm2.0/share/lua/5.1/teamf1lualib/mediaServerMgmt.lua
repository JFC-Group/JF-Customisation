-- mediaServerMgmt.lua - medias server lua code

-- Copyright (c) 2010, TeamF1, Inc.

-- modification history
-- --------------------
-- 01e,08apr10,pnm  adding rescanMedia support
-- 01d,02apr10,pnm  add bug fixes a per gui integration
-- 01c,31mar10,pnm  removed db.connect 
-- 01b,19mar10,pnm  updated the regular expression to allow numbers in name
-- 01a,10mar10,pnm  written.

-- ********************** Requires ********************
require "teamf1lualib/util"
require "teamf1lualib/db"

--package mediaServerMgmt
mediaServerMgmt = {}

-- This properties table contains information about various sizes and
-- supported mini and max length of various fields
mediaServerMgmt.propTbl = {}
mediaServerMgmt.propTbl["nameSize"] = 32
mediaServerMgmt.propTbl["nameMinLen"] = 1

--******************* Functions **********************
--[[
--*****************************************************************************
--mediaServerMgmt.globalCfgTblvalidateInput - validates the global table inputs
--
--This routines validates if the globalCfg tables values contains the correct
--info.
--
--RETURN: status - OK or ERROR
--        statusStr - MEDIA_SERVER_INVALID_SERVER_ENABLE_VAL - report this
--                      error message when the value provided for server
--                      enable field is not within the expected range.
--                    MEDIA_SERVER_INVALID_ALL_MEDIA_TYPE_VAL - report this
--                      error message when the value provided for allMediaType
--                      is not within the expected range.
]]--
function mediaServerMgmt.globalCfgTblValidateInput (tbl)
    -- Check if the serverEnable within range
    if ((tbl["mediaServerGlobalCfg.serverEnable"] > "1" ) or
        (tbl["mediaServerGlobalCfg.serverEnable"] < "0")) then
        return "ERROR", "MEDIA_SERVER_INVALID_SERVER_ENABLE_VAL"
    end

    -- Check if the allMediaType within range
    if ((tbl["mediaServerGlobalCfg.allMediaType"]) ~= nil and
        ((tbl["mediaServerGlobalCfg.allMediaType"] > "1" ) or
        (tbl["mediaServerGlobalCfg.allMediaType"] < "0"))) then
        return "ERROR", "MEDIA_SERVER_INVALID_ALL_MEDIA_TYPE_VAL"
    end

    -- return OK
    return "OK", "STATUS_OK"
end

--[[
--*****************************************************************************
--mediaServerMgmt.globalCfgTblConfig - adds the data into the database.
--
--This routine verifies the given data and then add the data into the
--database given the operation, and rowid
--
--RETURN: status - OK or ERROR
--        statusStr - MEDIA_SERVER_INVALID_OPERATION - report this error
--                      message when operation being performed is not
--                      supported.
--                    MEDIA_SERVER_CONFIG_ERROR - report this error message
--                      when database operation fails.
]]--
function mediaServerMgmt.globalCfgTblConfig (tbl, operation, rowid, dbFlag)
    -- Local Declarations
    local status
    local statusStr = ""
    local valid = false                    -- Val returned by db operation
    local tblName = "mediaServerGlobalCfg" -- table name

    -- Verify the operation
    if ((operation ~= "add") and (operation ~= "edit")) then
        return "ERROR", "MEDIA_SERVER_INVALID_OPERATION"
    end

    -- Verify the input
    status, statusStr = mediaServerMgmt.globalCfgTblValidateInput (tbl)
    if (status == "ERROR") then
        return status, statusStr
    end

    if (dbFlag == 1 ) then
        -- Start the db transaction
        db.beginTransaction ()
    end
    
    -- Add the data to db
    if (operation == "add") then
        -- Verify that there are no rows added into the db before this
        if (db.tableSize(tblName) >= "1") then
            util.appendDebugOut ("There is already an entry in db. " ..
                                tblName .. "can only have one entry. <br>\n")
        else
            valid, statusStr = db.insert (tblName, tbl)
        end
    elseif (operation == "edit")
    then
        --[[
        if (rowid < "0") then
            util.appendDebugOut ("rowid = "..rowid..
                    ". Invalid value for edit <br>\n")
        else
        ]]--
        util.appendDebugOut ("Inside edit option <br>")
        util.appendDebugOut (util.tableToString (tbl))
        valid,statusStr = db.update (tblName, tbl, rowid)
        --end
    end

    -- Return from function
    if (valid == false) then
        util.appendDebugOut (statusStr)
        util.appendDebugOut ("<br>\n")
        if (dbFlag == 1 ) then
            db.rollback ()
        end
        return "ERROR", "MEDIA_SERVER_CONFIG_ERROR"
    end
    if (dbFlag == 1 ) then
        db.commitTransaction (true)
    end
    return "OK", "STATUS_OK"
end

--[[
--*****************************************************************************
--mediaServerMgmt.shareTblvalidateInput - validates the shares table inputs
--
--This routines validates if the shares tables values contain the correct
--info.
--
--RETURN: status - OK or ERROR
--        statusStr - MEDIA_SERVER_INVALID_MEDIA_TYPE_VAL - report this
--                      error message when the value provided for server
--                      enable field is not within the expected range.
--                    MEDIA_SERVER_INVALID_NAME - report this
--                      error message when the value provided shareName is not
--                      valid.
--                    MEDIA_SERVER_INVALID_NAME_LEN - report this
--                      error message when the length of shareName is not
--                      within range.
--                    MEDIA_SERVER_DUPLICATE_NAME - report this error for
--                      duplicate entry.
]]--
function mediaServerMgmt.shareTblvalidateInput (tbl)
    -- Check if the pictures within range
    if ((tbl["mediaServerShares.pictures"] > "1" ) or
        (tbl["mediaServerShares.pictures"] < "0")) then
        return "ERROR", "MEDIA_SERVER_INVALID_MEDIA_TYPE_VAL"
    end

    -- Check if the video within range
    if ((tbl["mediaServerShares.video"] > "1" ) or
        (tbl["mediaServerShares.video"] < "0")) then
        return "ERROR", "MEDIA_SERVER_INVALID_MEDIA_TYPE_VAL"
    end

    -- Check if the music within range
    if ((tbl["mediaServerShares.music"] > "1" ) or
        (tbl["mediaServerShares.music"] < "0")) then
        return "ERROR", "MEDIA_SERVER_INVALID_MEDIA_TYPE_VAL"
    end

    -- Check if the name is within range
    if (util.verifyLength (tbl["mediaServerShares.shareName"],
        mediaServerMgmt.propTbl["nameMinLen"],
        mediaServerMgmt.propTbl["nameSize"]) == false) then
        return "ERROR", "MEDIA_SERVER_INVALID_NAME_LEN"
    end

    -- Verify the name is valid
    if (string.match (tbl["mediaServerShares.shareName"], "^[0-9a-zA-Z\-_]+$") ==
        nil) then
        return "ERROR", "MEDIA_SERVER_INVALID_NAME"
    end

    
    -- return OK
    return "OK", "STATUS_OK"
end

--[[
--*****************************************************************************
--mediaServerMgmt.sharesTblConfig - adds the data into the database.
--
--This routine verifies the given data and then add the data into the
--database given the operation, and rowid
--
--RETURN: status - OK or ERROR
--        statusStr - MEDIA_SERVER_CONFIG_ERROR - report this error message
--                      when database operation fails.
--                    MEDIA_SERVER_MAX_ERROR - report this error when there
--                      already MAX entries present in the database.
]]--
function mediaServerMgmt.sharesTblConfig (tbl, operation, rowid)
    -- Local Declarations
    local status
    local statusStr = ""
    local valid = false                 -- Val returned by db operation
    local tblName = "mediaServerShares" -- table name
    local maxShares

    -- We will be given multiple rows to delete 
    if (operation == "delete") then
        valid = true
        for k,v in pairs (tbl) do
            status, statusStr = db.delete (tblName, v)
            if (status == false) then
                valid = false
                util.appendDebugOut (statusStr)
                util.appendDebugOut ("<br>\n")
            end
        end
    else
        -- Remove trailing and leading spaces from the name
        tbl["mediaServerShares.shareName"] = util.stripLRSpaces (
        tbl["mediaServerShares.shareName"])

        -- Verify the input
        status, statusStr = mediaServerMgmt.shareTblvalidateInput (tbl)
        if (status == "ERROR") then
            return status, statusStr
        end
    end

    -- Add the data to db
    if (operation == "add") then
        -- Check for duplicate entry
        if (db.getRow ("mediaServerShares", "shareName",
            tbl["mediaServerShares.shareName"]) ~= nil) then
            return "ERROR", "MEDIA_SERVER_DUPLICATE_NAME"
        end

        -- get the number of MAX shares supported by the solution
        maxShares = db.getAttribute("environment","name","MAX_SHARES","value")
        
        -- verify that the environment variable is set
        if (maxShares == nil) then
            -- There is no environment variable name MAX_SHARES. This need to be
            -- set in the solution sql file.
            return "ERROR","SYSTEM_ERROR"
        end
        
        -- Verify the number of entries added don't exceed the MAX supported
        if (db.tableSize (tblName) == maxShares) then
            return "ERROR", "MEDIA_SERVER_MAX_ERROR"
        end

        -- Add the entry into DB
        valid, statusStr = db.insert (tblName, tbl)
    elseif (operation == "edit") then
        if (rowid < "0" ) then
            util.appendDebugOut ("rowid = "..rowid..
            ". Invalid value for edit <br>\n")
        else
            valid,statusStr = db.update (tblName, tbl, rowid)
        end
    end

    -- Return from function
    if (valid == false) then
        util.appendDebugOut (statusStr)
        util.appendDebugOut ("<br>\n")
        return "ERROR", "MEDIA_SERVER_CONFIG_ERROR"
    end
    return "OK", "STATUS_OK"
end

--[[
--*****************************************************************************
--mediaServerMgmt.rescanMedia - rescans the shares to for the media
--
--This routine scans the shares for the updated media files
--
--RETURN: status - OK or ERROR and status str
]]--
function mediaServerMgmt.rescanMedia ()

    -- Check if the DB file is defined.
    if (DB_FILE_NAME == nil) then
        return "ERROR", "SYSTEM_ERROR"
    end

    -- TODO: Here we are calling the binary file directly, this implementation
    -- need to change to call C LUA file instead which would call the C code
    -- to do the same operation.
    local status = os.execute ("/pfrm2.0/bin/mediaServerRescan " ..
    DB_FILE_NAME)
    if (status ~= 0) then
        return "ERROR", "MEDIA_SERVER_RESCAN_FAILED"
    end
    return "OK", "STATUS_OK"
end

--[[
--*****************************************************************************
--mediaServerMgmt.confGet - 
--
--
--RETURN: status - OK or ERROR and status str
]]--

function mediaServerMgmt.confGet()
    local conf = {}
    local query = "_ROWID_=1"

    conf = db.getRowWhere("mediaServerGlobalCfg", query, false)

    return "OK", "STATUS_OK", conf
end

--[[
--*****************************************************************************
--mediaServerMgmt.confSet - 
--
--
--RETURN: status - OK or ERROR and status str
]]--

function mediaServerMgmt.confSet(conf, dbFlag)
    local row = {}
    local query = "_ROWID_=1"

    row = db.getRowWhere("mediaServerGlobalCfg", query, false)
    if (row == nil) then
        return "ERROR", "MEDIA_SERVER_ERR_DB_QUERY_FAILED"
    end    

    if (conf.LogicalIfName ~= nil) then
        row.LogicalIfName = conf.LogicalIfName
    end
            
    if (conf.serverEnable ~= nil) then
        row.serverEnable = conf.serverEnable
    end

    if (conf.friendlyName ~= nil) then
        row.friendlyName = conf.friendlyName
    end

    row = util.addPrefix(row, "mediaServerGlobalCfg.")
    local status, errCode = 
        mediaServerMgmt.globalCfgTblConfig(row, "edit", 
                                           row["mediaServerGlobalCfg._ROWID_"], dbFlag)
    return status, errCode
end

function mediaServerMgmt.import (inputTable, defaultCfg, remCfg)

    if (inputTable == nil) then
        inputTable = defaultCfg
    end
    if (dbFlag == nil) then
        dbFlag = 1
    end
    -- initializing a temp table
    local configTable = inputTable
    -- configTable = config.update (inputTable, defaultCfg, remCfg)
 
     for i,v in pairs (configTable) do
         if (v["friendlyName"] == nil) then
             v["friendlyName"] = "Jio Media Server"
         end
     end

    if (configTable ~= nil) then
        configTable = util.addPrefix (configTable["global"],
                        "mediaServerGlobalCfg.");
        mediaServerMgmt.globalCfgTblConfig (configTable, "add", -1,dbFlag)
    end
end


function mediaServerMgmt.export ()
    local mediaServerConfig = {}
    mediaServerConfig["global"] = db.getTable ("mediaServerGlobalCfg", false)[1]
    return mediaServerConfig 
end

if (config.register) then
    config.register("mediaServer", mediaServerMgmt.import,
    mediaServerMgmt.export, "2")
end

