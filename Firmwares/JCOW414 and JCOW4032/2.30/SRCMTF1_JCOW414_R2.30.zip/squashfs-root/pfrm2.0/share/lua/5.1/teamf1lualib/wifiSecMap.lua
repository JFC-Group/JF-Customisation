-- wifi_config.lua - lua strings needed by wireless.lua as well as for htm files

-- Copywrite (c) 2013 TeamF1, Inc.


--modification history
-- --------------------
-- 01a,12mar12,abr  created.

require "teamf1lualib/wireless"

 securityStrs = {     {"1", "OPEN", "","","",""},
                      {"2", "WEP","","", "Open","64",},
                      {"3", "WEP","","", "Open","128",},
                      {"4", "WEP","","", "Shared","64",},
                      {"5", "WEP","","", "Shared","128",},
                      {"6", "WPA", "TKIP","PSK","","",},
                      {"7", "WPA", "CCMP","PSK","","",},
                      {"8", "WPA2", "CCMP","PSK","","",},
                      {"9", "WPA+WPA2", "TKIP+CCMP","PSK","",""}
                    
                }

 securityStrsAuthAP = {    {"1", "OPEN", "","",},
                           {"2", "WEP","","",},
                           {"3", "WPA","TKIP","PSK",},
                           {"4", "WPA","TKIP","RADIUS",},
                           {"5", "WPA","TKIP","PSK+RADIUS",},
                           {"6", "WPA", "AES","PSK",},
                           {"7", "WPA", "AES","RADIUS"},
                           {"8", "WPA", "AES","PSK+RADIUS"},
                           {"9", "WPA", "TKIP+AES","PSK",},
                           {"10", "WPA", "TKIP+AES","RADIUS",},
                           {"11", "WPA", "TKIP+AES","PSK+RADIUS",},
                           {"12", "WPA2", "AES","PSK",},
                           {"13", "WPA2", "AES","RADIUS",},
                           {"14", "WPA2", "AES","PSK+RADIUS",},
                           {"15", "WPA+WPA2", "TKIP+AES","PSK",},
                           {"16", "WPA+WPA2", "TKIP+AES","RADIUS",},
                           {"17", "WPA+WPA2", "TKIP+AES","RADIUS",}
                       }
                     
 modeStrs = { {"1", "g and b"},
				   {"2", "g only"},
				   {"3", "ng"},
				   {"4", "n only"}
				 }
