
require"ifDevLib"
if(util.fileExists("/pfrm2.0/BRCM_SDK_5_02_L05P1")) then
	require "teamf1lualib/dot11"
end

LAN_MAC_FILE = "/tmp/lanMAC1"
LAN_PHY_INTF_NAME = "eth0"

easyMeshMgmt = {}

function tcapiMeshUnSetCmdExecute(dbstring)

   local TCAPI_SET_CMD_BINARY = "/userfs/bin/tcapi unset Mesh"
   local cmdStr = TCAPI_SET_CMD_BINARY..dbstring
   --os.execute("echo "..cmdStr.. " > /dev/console")
   os.execute(cmdStr)

end

function tcapiEasyMeshSetExecute(dbstring, variable, value)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/tcapi set Mesh"
    local cmdStr = TCAPI_SET_CMD_BINARY..dbstring.." "..variable.." \""..value.."\""
    --os.execute("echo "..cmdStr.. " > /dev/console")
    os.execute(cmdStr)

end


function tcapiSetEasyMeshSSIDExecute(dbstring, variable, value)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/tcapi set WLan"
    local cmdStr = TCAPI_SET_CMD_BINARY..dbstring.." "..variable.." \""..value.."\""
    --os.execute("echo "..cmdStr.. " > /dev/console")
    os.execute(cmdStr)

end


function tcapiWLanEasyMeshCommitCmdExecute(dbstring)

    local TCAPI_COMMIT_CMD_BINARY = "/userfs/bin/tcapi commit WLan"
    local cmdStr = TCAPI_COMMIT_CMD_BINARY..dbstring
    --os.execute("echo "..cmdStr.. " > /dev/console")
    os.execute(cmdStr)

end


function tcapiEasyMeshSetCmdExecute(dbstring, variable, value)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/tcapi set Mesh"
    local cmdStr = TCAPI_SET_CMD_BINARY..dbstring.." "..variable.." "..value
    --os.execute("echo "..cmdStr.. " > /dev/console")
    os.execute(cmdStr)

end


function tcapiEasyMeshCommitCmdExecute(dbString)

    local TCAPI_COMMIT_CMD_BINARY = "/userfs/bin/tcapi commit Mesh"
    local cmdStr = TCAPI_COMMIT_CMD_BINARY..dbString
    --os.execute("echo "..cmdStr.. " > /dev/console")
    os.execute(cmdStr)

end

function tcapiSaveCmdExecute()

    local TCAPI_SAVE_CMD_BINARY = "/userfs/bin/tcapi save"
    --os.execute("echo "..TCAPI_SAVE_CMD_BINARY.. " > /dev/console")
    os.execute(TCAPI_SAVE_CMD_BINARY)

end

------------------------------------------------------------------------------
-- @name : easyMeshMgmt.easyMeshGet()
--
-- @description : API to return 'easyMesh' table
--
-- @return : Entire easyMesh table
-- 
function easyMeshMgmt.easyMeshGet ()
    --local 
    local meshTbl = {}
    
    meshTbl = db.getRow ("easyMesh","_ROWID_","1") 

    meshTbl = util.removePrefix(meshTbl, "easyMesh.")
    
    return meshTbl
end

-------------------------------------------------------------------------------
--When we Chnage the Mode of the Device(Controller/Agent).
--Setting the Default Values


function easyMeshMgmt.easyMeshSetValueMode()
	require "teamf1lualib/dot11"
	require "teamf1lualib/radius"

    local RadioDefaultTbl = db.getTable("dot11Radio", false) 

    local rowid = "1"
    RadioDefaultTbl["dot11Radio.configuredChannel"] = "0"
    RadioDefaultTbl["dot11Radio.txPower"] = "75"
    RadioDefaultTbl["dot11Radio.opMode"] = "802.11g/n"
    RadioDefaultTbl["dot11Radio.beaconInterval"] = "100"
    RadioDefaultTbl["dot11Radio.dtimInterval"] = "2"
    RadioDefaultTbl["dot11Radio.rtsThreshold"] = "2347"
    RadioDefaultTbl["dot11Radio.fragThreshold"] = "2346"
    RadioDefaultTbl["dot11Radio.sideBand"] = "0"
    RadioDefaultTbl["dot11Radio.chanWidth"] = "20"
    RadioDefaultTbl["dot11Radio.radioCountryRev"] = "987"
    RadioDefaultTbl["dot11Radio.txRate"] = "0"

    db.update("dot11Radio", RadioDefaultTbl, rowid)

    rowid = "2"
    RadioDefaultTbl["dot11Radio.configuredChannel"] = "0"
    RadioDefaultTbl["dot11Radio.txPower"] = "100"
    RadioDefaultTbl["dot11Radio.opMode"] = "802.11a/n/ac"
    RadioDefaultTbl["dot11Radio.beaconInterval"] = "100"
    RadioDefaultTbl["dot11Radio.dtimInterval"] = "2"
    RadioDefaultTbl["dot11Radio.rtsThreshold"] = "2347"
    RadioDefaultTbl["dot11Radio.fragThreshold"] = "2346"
    RadioDefaultTbl["dot11Radio.sideBand"] = "0"
    RadioDefaultTbl["dot11Radio.chanWidth"] = "20"
    RadioDefaultTbl["dot11Radio.radioCountryRev"] = "987"
    RadioDefaultTbl["dot11Radio.txRate"] = "0"

    db.update("dot11Radio", RadioDefaultTbl, rowid)
     
     
     local dot11vapdefault = db.getTable("dot11VAP", false)

     rowid = "1"
     dot11vapdefault["dot11VAP.vapEnabled"] = "1"
     dot11vapdefault["dot11VAP.maxClients"] = "22"
     dot11vapdefault["dot11VAP.apIsolation"] = "0"
     dot11vapdefault["dot11VAP.defACLPolicy"] = "Disable"

     db.update("dot11VAP", dot11vapdefault, rowid)


     rowid = "2"
     dot11vapdefault["dot11VAP.vapEnabled"] = "0"
     dot11vapdefault["dot11VAP.maxClients"] = "1"
     dot11vapdefault["dot11VAP.apIsolation"] = "0"
     dot11vapdefault["dot11VAP.defACLPolicy"] = "Disable"

     db.update("dot11VAP", dot11vapdefault, rowid)

     rowid = "3"
     dot11vapdefault["dot11VAP.vapEnabled"] = "0"
     dot11vapdefault["dot11VAP.maxClients"] = "1"
     dot11vapdefault["dot11VAP.apIsolation"] = "0"
     dot11vapdefault["dot11VAP.defACLPolicy"] = "Disable"

     db.update("dot11VAP", dot11vapdefault, rowid)

     rowid = "4"
     dot11vapdefault["dot11VAP.vapEnabled"] = "1"
     dot11vapdefault["dot11VAP.maxClients"] = "22"
     dot11vapdefault["dot11VAP.apIsolation"] = "0"
     dot11vapdefault["dot11VAP.defACLPolicy"] = "Disable"

     db.update("dot11VAP", dot11vapdefault, rowid)


     rowid = "5"
     dot11vapdefault["dot11VAP.vapEnabled"] = "0"
     dot11vapdefault["dot11VAP.maxClients"] = "1"
     dot11vapdefault["dot11VAP.apIsolation"] = "0"
     dot11vapdefault["dot11VAP.defACLPolicy"] = "Disable"

     db.update("dot11VAP", dot11vapdefault, rowid)

     rowid = "6"
     dot11vapdefault["dot11VAP.vapEnabled"] = "0"
     dot11vapdefault["dot11VAP.maxClients"] = "1"
     dot11vapdefault["dot11VAP.apIsolation"] = "0"
     dot11vapdefault["dot11VAP.defACLPolicy"] = "Disable"

     db.update("dot11VAP", dot11vapdefault, rowid)


     local dot11ProfileDefault = db.getTable ("dot11Profile", false)

     rowid = "1"
     local ssidRandomString = util.fileToString ("/tmp/ssidRandom") 
     local wpaPsk = util.fileToString ("/tmp/randPasswordWifi") 
     
     local radioDbString = "_Entry0" 
     tcapiSetEasyMeshSSIDExecute(radioDbString,"SSID",ssidRandomString)
     tcapiSetEasyMeshSSIDExecute(radioDbString,"WPAPSK",wpaPsk)
     tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID", "1")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"NoForwarding","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"HideSSID","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"AuthMode","WPA2PSK")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"IEEE8021X","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"EncrypType","AES")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"AccessPolicy","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"MaxStaNum","22")
     tcapiWLanEasyMeshCommitCmdExecute(radioDbString)
        
     local ssidRandomStringBH = ssidRandomString .. "-BH"
     radioDbString = "_Entry1" 
     tcapiSetEasyMeshSSIDExecute(radioDbString,"SSID",ssidRandomStringBH)
     tcapiSetEasyMeshSSIDExecute(radioDbString,"EncrypType","AES")
     local bhPwd = generateBHPasswd("a")
     if(bhPwd == nil) then
          bhPwd = util.fileToString ("/tmp/randPasswordWifi")
     end
     tcapiSetEasyMeshSSIDExecute(radioDbString,"WPAPSK",bhPwd)
     tcapiWLanEasyMeshCommitCmdExecute(radioDbString)
     
     
     radioDbString = "11ac_Entry1" 
     tcapiSetEasyMeshSSIDExecute(radioDbString,"SSID",ssidRandomStringBH)
     tcapiSetEasyMeshSSIDExecute(radioDbString,"WPAPSK",bhPwd)
     tcapiWLanEasyMeshCommitCmdExecute(radioDbString)
     
     dot11ProfileDefault["dot11Profile.ssid"] = ssidRandomString
     dot11ProfileDefault["dot11Profile.broadcastSSID"] = "1"
     dot11ProfileDefault["dot11Profile.pairwiseCiphers"] = "CCMP"
     dot11ProfileDefault["dot11Profile.authMethods"] = "PSK"
     dot11ProfileDefault["dot11Profile.security"] = "WPA2"
     dot11ProfileDefault["dot11Profile.pskPassAscii"] = wpaPsk
     db.update("dot11Profile", dot11ProfileDefault, rowid)

     rowid = "2"
     dot11ProfileDefault["dot11Profile.ssid"] = "Jio_2"
     dot11ProfileDefault["dot11Profile.broadcastSSID"] = "1"
     dot11ProfileDefault["dot11Profile.pairwiseCiphers"] = "CCMP"
     dot11ProfileDefault["dot11Profile.authMethods"] = "PSK"
     dot11ProfileDefault["dot11Profile.security"] = "WPA2"
     dot11ProfileDefault["dot11Profile.pskPassAscii"] = wpaPsk
     db.update("dot11Profile", dot11ProfileDefault, rowid)

     rowid = "3"
     dot11ProfileDefault["dot11Profile.ssid"] = "Jio_3"
     dot11ProfileDefault["dot11Profile.broadcastSSID"] = "1"
     dot11ProfileDefault["dot11Profile.pairwiseCiphers"] = "CCMP"
     dot11ProfileDefault["dot11Profile.authMethods"] = "PSK"
     dot11ProfileDefault["dot11Profile.security"] = "WPA2"
     dot11ProfileDefault["dot11Profile.pskPassAscii"] = wpaPsk
     db.update("dot11Profile", dot11ProfileDefault, rowid)


     ssidRandomString = ssidRandomString .. "_5G"
     rowid = "4"
      
     radioDbString = "11ac_Entry0" 
     tcapiSetEasyMeshSSIDExecute(radioDbString,"SSID",ssidRandomString)
     tcapiSetEasyMeshSSIDExecute(radioDbString,"WPAPSK",wpaPsk)
     tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID", "1")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"NoForwarding","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"HideSSID","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"AuthMode","WPA2PSK")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"IEEE8021X","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"EncrypType","AES")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"AccessPolicy","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"MaxStaNum","22")     
     tcapiWLanEasyMeshCommitCmdExecute(radioDbString)

     dot11ProfileDefault["dot11Profile.ssid"] = ssidRandomString
     dot11ProfileDefault["dot11Profile.broadcastSSID"] = "1"
     dot11ProfileDefault["dot11Profile.pairwiseCiphers"] = "CCMP"
     dot11ProfileDefault["dot11Profile.authMethods"] = "PSK"
     dot11ProfileDefault["dot11Profile.security"] = "WPA2"
     dot11ProfileDefault["dot11Profile.pskPassAscii"] = wpaPsk
     db.update("dot11Profile", dot11ProfileDefault, rowid)

     rowid = "5"
     dot11ProfileDefault["dot11Profile.ssid"] = "Jio_2"
     dot11ProfileDefault["dot11Profile.broadcastSSID"] = "1"
     dot11ProfileDefault["dot11Profile.pairwiseCiphers"] = "CCMP"
     dot11ProfileDefault["dot11Profile.authMethods"] = "PSK"
     dot11ProfileDefault["dot11Profile.security"] = "WPA2"
     dot11ProfileDefault["dot11Profile.pskPassAscii"] = wpaPsk
     db.update("dot11Profile", dot11ProfileDefault, rowid)


     rowid = "6"
     dot11ProfileDefault["dot11Profile.ssid"] = "Jio_3"
     dot11ProfileDefault["dot11Profile.broadcastSSID"] = "1"
     dot11ProfileDefault["dot11Profile.pairwiseCiphers"] = "CCMP"
     dot11ProfileDefault["dot11Profile.authMethods"] = "PSK"
     dot11ProfileDefault["dot11Profile.security"] = "WPA2"
     dot11ProfileDefault["dot11Profile.pskPassAscii"] = wpaPsk
     db.update("dot11Profile", dot11ProfileDefault, rowid)

     local dot11WPSDefault =  db.getTable ("dot11WPS", false)

     rowid = "1"
     dot11WPSDefault["dot11WPS.vapName"] = "ap1"
     dot11WPSDefault["dot11WPS.interfaceName"] = "ra0"
     dot11WPSDefault["dot11WPS.wpsEnabled"] = "1"

     db.update("dot11WPS", dot11WPSDefault , rowid)

      local radiusClientDefault = db.getTable ("radiusClient", false)

      rowid = "1"
      radiusClientDefault["radiusClient.authserver"] = "192.168.29.2"
      radiusClientDefault["radiusClient.authport"] = "1812"
      radiusClientDefault["radiusClient.authsecret"] = "password"
      radiusClientDefault["radiusClient.retryInterval"] = "300"
      radiusClientDefault["radiusClient.ipType"] = "0"
      radiusClientDefault["radiusClient.authtimeout"] = "1"
      radiusClientDefault["radiusClient.authretries"] = "2"
      radiusClientDefault["radiusClient.authType"] = "1"
      radiusClientDefault["radiusClient.serverinuse"] = "0"

      db.update("radiusClient", radiusClientDefault, rowid)

      db.save2()

     radioDbString = "_Common"
     
     tcapiSetEasyMeshSSIDExecute(radioDbString,"TxPowerLevel", "1")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"HT_MCS", "33")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"RTSThreshold", "2347")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"FragThreshold", "2346")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"BeaconPeriod", "100")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"DtimPeriod", "2")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"BGProtection", "0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"WirelessMode", "7")     
     tcapiSetEasyMeshSSIDExecute(radioDbString,"HT_OpMode", "0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"BasicRate", "351")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"Channel", "0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"AutoChannelSelect", "2")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"HT_BW", "0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"VHT_BW", "1")

     radioDbString = "11ac_Common"
     
     tcapiSetEasyMeshSSIDExecute(radioDbString,"TxPower", "100")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"HT_MCS", "33")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"RTSThreshold", "2347")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"FragThreshold", "2346")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"BeaconPeriod", "100")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"DtimPeriod", "2")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"BGProtection", "0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"WirelessMode", "14")     
     tcapiSetEasyMeshSSIDExecute(radioDbString,"BasicRate", "15")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"Channel", "0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"AutoChannelSelect", "2")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"AutoChannelSkipList", "165")     
     tcapiSetEasyMeshSSIDExecute(radioDbString,"HT_BW", "1")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"VHT_BW", "1")

          
     radioDbString = "_Entry2"
     tcapiSetEasyMeshSSIDExecute(radioDbString,"SSID", "Jio_2")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID", "0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"WPAPSK",wpaPsk)
     tcapiSetEasyMeshSSIDExecute(radioDbString,"NoForwarding","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"HideSSID","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"AuthMode","WPA2PSK")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"IEEE8021X","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"EncrypType","AES")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"AccessPolicy","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"MaxStaNum","1")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"RADIUS_Server","192.168.29.2")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"RADIUS_Port","1812")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"RADIUS_Key","password")
     
     radioDbString = "_Entry3"
     tcapiSetEasyMeshSSIDExecute(radioDbString,"SSID", "Jio_3")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID", "0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"WPAPSK",wpaPsk)
     tcapiSetEasyMeshSSIDExecute(radioDbString,"NoForwarding","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"HideSSID","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"AuthMode","WPA2PSK")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"IEEE8021X","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"EncrypType","AES")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"AccessPolicy","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"MaxStaNum","1")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"RADIUS_Server","192.168.29.2")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"RADIUS_Port","1812")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"RADIUS_Key","password")
     
     radioDbString = "11ac_Entry2"
     tcapiSetEasyMeshSSIDExecute(radioDbString,"SSID", "Jio_2")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID", "0")     
     tcapiSetEasyMeshSSIDExecute(radioDbString,"WPAPSK",wpaPsk)
     tcapiSetEasyMeshSSIDExecute(radioDbString,"NoForwarding","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"HideSSID","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"AuthMode","WPA2PSK")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"IEEE8021X","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"EncrypType","AES")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"AccessPolicy","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"MaxStaNum","1")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"RADIUS_Server","192.168.29.2")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"RADIUS_Port","1812")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"RADIUS_Key","password")
     
     radioDbString = "11ac_Entry3"
     tcapiSetEasyMeshSSIDExecute(radioDbString,"SSID", "Jio_3")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID", "0")     
     tcapiSetEasyMeshSSIDExecute(radioDbString,"WPAPSK",wpaPsk)
     tcapiSetEasyMeshSSIDExecute(radioDbString,"NoForwarding","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"HideSSID","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"AuthMode","WPA2PSK")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"IEEE8021X","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"EncrypType","AES")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"AccessPolicy","0")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"MaxStaNum","1")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"RADIUS_Server","192.168.29.2")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"RADIUS_Port","1812")
     tcapiSetEasyMeshSSIDExecute(radioDbString,"RADIUS_Key","password")

     tcapiSaveCmdExecute()
      

end


--------------------------------------------------------------------------------
--BhInfo case
--
--
--

function easyMeshMgmt.easyMeshBhInfoSet(meshBhTbl)

    local statusFlag = true
    local radioDbString = ""
    local MeshinterfaceAL_Mac = ""
    local meshTmp = db.getTable ("easyMeshBhInfo",false)
    
    -- add table prefix
    meshBhTbl = util.addPrefix(meshBhTbl, "easyMeshBhInfo.")

    statusFlag = easyMeshMgmt.config ("easyMeshBhInfo", meshBhTbl, "1", "edit")

    if(statusFlag) then
        if (tonumber(meshBhTbl["easyMeshBhInfo.deviceRole"]) == tonumber(1)) then

            os.execute("/bin/rm -rf /flash/JMA24_AGENT_MODE")
            os.execute("/bin/touch /flash/JMA24_CAP_MODE")
            radioDbString="_Common"
            tcapiEasyMeshSetExecute(radioDbString,"DeviceRole","1")
        else
            os.execute("/bin/rm -rf /flash/JMA24_CAP_MODE")
            os.execute("/bin/touch /flash/JMA24_AGENT_MODE")
            radioDbString="_Common"
            tcapiEasyMeshSetExecute(radioDbString,"DeviceRole","2")
        end

        tcapiSetEasyMeshSSIDExecute("_Entry2","EnableSSID","0")
        tcapiSetEasyMeshSSIDExecute("_Entry3","EnableSSID","0")
        tcapiSetEasyMeshSSIDExecute("11ac_Entry2","EnableSSID","0")
        tcapiSetEasyMeshSSIDExecute("11ac_Entry3","EnableSSID","0")
        tcapiMeshUnSetCmdExecute("_apclibh_Entry0")
        tcapiMeshUnSetCmdExecute("_apclibh_Entry1")

        tcapiEasyMeshCommitCmdExecute(radioDbString)
        easyMeshMgmt.easyMeshSetValueMode()
        tcapiSaveCmdExecute()
	   os.execute ("sleep 30") 
    else
    	return "ERROR", "FW_CONFIG_FAILED" 
    end

    return "OK" , "STATUS_OK"    
end



---------------------------------------
---wifiConfiguration
--

function easyMeshMgmt.easyMeshWifiSet(meshConfTbl)
    --locals
    local statusFlag = true
    local radioDbString = ""
    local MeshinterfaceAL_Mac = ""
    local meshTmp = db.getTable ("easyMesh",false)
    
    -- add table prefix
    meshConfTbl = util.addPrefix(meshConfTbl, "easyMesh.")

    statusFlag = easyMeshMgmt.config ("easyMesh", meshConfTbl, "1", "edit")

    -- check status
    if (statusFlag) then
	    if(meshConfTbl["easyMesh.wifiOn"] == "0") then
            --Disbaling the Mesh
                   if (util.fileExists("/flash/BRCM_MESH_ENABLED")) then
                               dot11meshDisable()
                               dot11meshReStart()
                               os.execute("rm -rf /flash/BRCM_MESH_ENABLED")
                               os.execute("echo '0' > /tmp/MESH_ENABLED")
                               local cmd ="/bin/wl -i  wl0 down"
                               os.execute(cmd)
                               local cmd ="/bin/wl -i  wl0.1 down"
                               os.execute(cmd)
                               local cmd ="/bin/wl -i  wl0.2 down"
                               os.execute(cmd)
                               local cmd ="/bin/wl -i  wl1 down"
                               os.execute(cmd)
                               local cmd ="/bin/wl -i  wl1.2 down"
                               os.execute(cmd)
                               local cmd ="/bin/wl -i  wl1.3 down"
                               os.execute(cmd)
                           end
            
               
            radioDbString="_dat"
            tcapiEasyMeshSetCmdExecute(radioDbString,"MapEnable",0)
            tcapiEasyMeshSetCmdExecute(radioDbString,"MAP_Turnkey",0)
            --disabling the VAP's
            tcapiSetEasyMeshSSIDExecute("_Entry0","EnableSSID","0")
            tcapiSetEasyMeshSSIDExecute("_Entry1","EnableSSID","0")
            tcapiSetEasyMeshSSIDExecute("_Entry2","EnableSSID","0")
            tcapiSetEasyMeshSSIDExecute("_Entry3","EnableSSID","0")
            tcapiSetEasyMeshSSIDExecute("11ac_Entry0","EnableSSID","0")
            tcapiSetEasyMeshSSIDExecute("11ac_Entry1","EnableSSID","0")
            tcapiSetEasyMeshSSIDExecute("11ac_Entry2","EnableSSID","0")
            tcapiSetEasyMeshSSIDExecute("11ac_Entry3","EnableSSID","0")
           
	    radioDbString = "" 
            tcapiWLanEasyMeshCommitCmdExecute(radioDbString)
            tcapiWLanEasyMeshCommitCmdExecute("11ac")
	    radioDbString="_dat"
            tcapiEasyMeshCommitCmdExecute(radioDbString)
            tcapiSaveCmdExecute()
            
        else
                        if (util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED")) then
                             os.execute("echo '1' > /tmp/MESH_ENABLED")
                             os.execute("touch /flash/BRCM_MESH_ENABLED")
                            local cmd ="/bin/wl -i  wl0 up"
                            os.execute(cmd)
                            local cmd ="/bin/wl -i  wl0.1 up"
                            os.execute(cmd)
                            local cmd ="/bin/wl -i  wl0.2 up"
                            os.execute(cmd)
                            local cmd ="/bin/wl -i  wl1 up"
                            os.execute(cmd)
                            local cmd ="/bin/wl -i  wl1.2 up"
                            os.execute(cmd)
                            local cmd ="/bin/wl -i  wl1.3 up"
                            os.execute(cmd)
                        end 
            -- Checking the Secondary Vap's Configuration
            local vapEnable = db.getAttribute("dot11VAP","vapName","ap2","vapEnabled")
            tcapiSetEasyMeshSSIDExecute("_Entry2","EnableSSID",vapEnable)

            vapEnable = db.getAttribute("dot11VAP","vapName","ap3","vapEnabled")
            tcapiSetEasyMeshSSIDExecute("_Entry3","EnableSSID",vapEnable)

                
            vapEnable = db.getAttribute("dot11VAP","vapName","ap1","vapEnabled")
            tcapiSetEasyMeshSSIDExecute("_Entry0","EnableSSID",vapEnable)

            radioDbString = ""
            tcapiWLanEasyMeshCommitCmdExecute(radioDbString)
            
            vapEnable = db.getAttribute("dot11VAP","vapName","ap4","vapEnabled")
            tcapiSetEasyMeshSSIDExecute("11ac_Entry0","EnableSSID",vapEnable)
            
            vapEnable = db.getAttribute("dot11VAP","vapName","ap5","vapEnabled")
            tcapiSetEasyMeshSSIDExecute("11ac_Entry2","EnableSSID",vapEnable)

            vapEnable = db.getAttribute("dot11VAP","vapName","ap6","vapEnabled")
            tcapiSetEasyMeshSSIDExecute("11ac_Entry3","EnableSSID",vapEnable)
            
            tcapiWLanEasyMeshCommitCmdExecute("11ac")
            
        local meshconf = "0"
               
        if((util.fileExists("/pfrm2.0/DEVICE_REPEATER"))) then
            meshconf = db.getAttribute("easyMesh","meshInterfacename","br0","meshEnable")
        else
            meshconf = db.getAttribute("easyMesh","meshInterfacename","bdg2","meshEnable")
        end
            
            if(meshconf == "1") then
                                   if (util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED")) then
                                            dot11meshInit()
                                            local  fh2SSID = db.getAttribute("dot11Profile","profileName","Jio_1","ssid")
                                            dot11SetFHSSIDOnly (fh2SSID , "b")
                                            local  fh5SSID = db.getAttribute("dot11Profile","profileName","Jio_4","ssid")
                                            dot11SetFHSSIDOnly (fh5SSID , "a")
                                            local  fh2PSK = db.getAttribute("dot11Profile","profileName","Jio_1","pskPassAscii")
                                            dot11SetFHPSKOnly (     fh2PSK , "b")
                                            local  fh5PSK = db.getAttribute("dot11Profile","profileName","Jio_4","pskPassAscii")
                                            dot11SetFHPSKOnly (fh5PSK , "a")
                                            local  bhSSID = db.getAttribute("dot11Profile","profileName","Jio_5","ssid")
                                            local  bhPSK = db.getAttribute("dot11Profile","profileName","Jio_5","pskPassAscii")
                                            dot11SetBHSSID (bhSSID, bhPSK)
                                            dot11meshReStart ()
                                    end 
                tcapiSetEasyMeshSSIDExecute("_Entry0","EnableSSID","1")
                tcapiSetEasyMeshSSIDExecute("_Entry1","EnableSSID","1")
                tcapiSetEasyMeshSSIDExecute("11ac_Entry0","EnableSSID","1")
                tcapiSetEasyMeshSSIDExecute("11ac_Entry1","EnableSSID","1")
                
                radioDbString="_dat"
                tcapiEasyMeshSetCmdExecute(radioDbString,"MapEnable",1)
                tcapiEasyMeshSetCmdExecute(radioDbString,"MAP_Turnkey",1)
	   	        tcapiEasyMeshCommitCmdExecute(radioDbString)
           	    tcapiSaveCmdExecute() 
		    end
        end
            return "OK", "STATUS_OK"
    else
        return "ERROR", "FW_CONFIG_FAILED"
    end
end

-------------------------------------------
--
--
function easyMeshMgmt.easyMeshSet(meshConfTbl)
    --locals
    local statusFlag = true
    local radioDbString = ""
    local MeshinterfaceAL_Mac = ""
    local meshTmp = db.getTable ("easyMesh",false)

    -- add table prefix
    meshConfTbl = util.addPrefix(meshConfTbl, "easyMesh.")

    statusFlag = easyMeshMgmt.config ("easyMesh", meshConfTbl, "1", "edit")

    -- check status
    if (statusFlag) then
	    if(meshConfTbl["easyMesh.meshEnable"] == "1") then
            os.execute("touch /flash/MeshOn_Enable")
            os.execute("touch /flash/MESH_ENABLED")
            os.execute("echo '1' > /tmp/MESH_ENABLED")
        if(util.fileExists("/pfrm2.0/BRCM_SDK_5_02_L05P1")) then
            os.execute("touch /flash/BRCM_MESH_ENABLED")                            
      	end
          --Checking the Radius Authentication Enabled
            --Setting to WPA2PSK
            local authMode = db.getAttribute("dot11Profile","profileName","Jio_1","authMethods")

            if(authMode == "RADIUS") then
                valid = db.setAttribute("dot11Profile", "profileName","Jio_1", "authMethods", "PSK") 
            end

            authMode = db.getAttribute("dot11Profile","profileName","Jio_4","authMethods")

            if(authMode == "RADIUS") then
                valid = db.setAttribute("dot11Profile", "profileName","Jio_4", "authMethods", "PSK") 
            end

            --Enabling the FH VAP's
            local vapEnable = db.getAttribute("dot11VAP","vapName","ap1","vapEnabled")
            if(vapEnable == "0") then
                local cmd ="/sbin/ifconfig ra0 up" 
                os.execute(cmd)
            if(not(util.fileExists("/pfrm2.0/DEVICE_REPEATER"))) then
                cmd = "/usr/bin/brctl addif bdg2 ra0"
                os.execute(cmd)
            end
               radioDbString = "_Entry0" 
               tcapiSetEasyMeshSSIDExecute(radioDbString,"HideSSID","1")
               tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID","1")
               tcapiWLanEasyMeshCommitCmdExecute(radioDbString)
            end

            vapEnable = db.getAttribute("dot11VAP","vapName","ap4","vapEnabled")
            if(vapEnable == "0") then
                cmd ="/sbin/ifconfig rai0 up" 
                os.execute(cmd)
                if(not(util.fileExists("/pfrm2.0/DEVICE_REPEATER"))) then
                cmd = "/usr/bin/brctl addif bdg2 rai0"
                os.execute(cmd)
                end
                radioDbString = "11ac_Entry0" 
                tcapiSetEasyMeshSSIDExecute(radioDbString,"HideSSID","1")
                tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID","1")
                tcapiWLanEasyMeshCommitCmdExecute(radioDbString)
            end

            local radioDbString = ""
            --Back Haul Vap's Name same as Primary AP's
    
            local vapName = util.fileToString ("/tmp/ssidRandom")
    
            vapName = vapName.. "-BH"
            radioDbString = "_Entry1" 
            tcapiSetEasyMeshSSIDExecute(radioDbString,"SSID",vapName)
            tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID","1")
            tcapiSetEasyMeshSSIDExecute(radioDbString,"AuthMode","WPA2PSK")
            tcapiSetEasyMeshSSIDExecute(radioDbString,"EncrypType","AES")
            local bhPwd = generateBHPasswd("a")
            if(bhPwd == nil) then
                bhPwd = util.fileToString ("/tmp/randPasswordWifi")
            end
            tcapiSetEasyMeshSSIDExecute(radioDbString,"WPAPSK",bhPwd)
            tcapiSetEasyMeshSSIDExecute(radioDbString,"HideSSID","1")
            radioDbString = "_radio2gbssinfo_entry1" 
            tcapiEasyMeshSetCmdExecute(radioDbString,"BackHaul",1)
            tcapiEasyMeshSetCmdExecute(radioDbString,"FrontHaul",0)
            --tcapiEasyMeshCommitCmdExecute(radioDbString)

            radioDbString = "11ac_Entry1" 
            tcapiSetEasyMeshSSIDExecute(radioDbString,"SSID",vapName)
            tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID","1")
            tcapiSetEasyMeshSSIDExecute(radioDbString,"AuthMode","WPA2PSK")
            tcapiSetEasyMeshSSIDExecute(radioDbString,"EncrypType","AES")
            --[[
	        bhPwd = generateBHPasswd("a")
            if(bhPwd == nil) then
                bhPwd = util.fileToString ("/tmp/randPasswordWifi")
            end
		    ]]--
            tcapiSetEasyMeshSSIDExecute(radioDbString,"WPAPSK",bhPwd)
            tcapiSetEasyMeshSSIDExecute(radioDbString,"HideSSID","1")
            radioDbString = "_radio5glbssinfo_entry1" 
            tcapiEasyMeshSetCmdExecute(radioDbString,"BackHaul",1)
            tcapiEasyMeshSetCmdExecute(radioDbString,"FrontHaul",0)
            --tcapiEasyMeshCommitCmdExecute(radioDbString)
    
            radioDbString = ""
		    radioDbString="_dat"
	        tcapiEasyMeshSetCmdExecute(radioDbString,"MapEnable",1)
	        tcapiEasyMeshSetCmdExecute(radioDbString,"MAP_Turnkey",1)
		    --tcapiSetCmdWrite("MapEnable","1")
	   	    --tcapiSetCmdWrite("MAP_Turnkey","1")
           	radioDbString="__mapcfg"
	   	    tcapiEasyMeshSetCmdExecute(radioDbString,"br_inf",meshTmp[1]["meshInterfacename"])
	   	    MeshinterfaceAL_Mac = ifDevLib.getMac(meshTmp[1]["meshInterfacename"])
	   	    tcapiEasyMeshSetCmdExecute(radioDbString,"AL-MAC",MeshinterfaceAL_Mac)
            radioDbString ="_dat"
	   	    tcapiEasyMeshCommitCmdExecute(radioDbString)
           	tcapiSaveCmdExecute() 
        else
            os.execute("rm -rf /flash/MESH_ENABLED")
       	    os.execute("echo '0' > /tmp/MESH_ENABLED")
           if(util.fileExists("/pfrm2.0/BRCM_SDK_5_02_L05P1")) then 
               os.execute("echo '0' > /tmp/MESH_ENABLED")
               os.execute("rm -rf /flash/BRCM_MESH_ENABLED")
               dot11meshDisable()
               dot11meshReStart()
           end

            local vapEnable = db.getAttribute("dot11VAP","vapName","ap1","vapEnabled")
            if(vapEnable == "0") then
                cmd ="/sbin/ifconfig ra0 down" 
                os.execute(cmd)
            if(not(util.fileExists("/pfrm2.0/DEVICE_REPEATER"))) then
                cmd = "/usr/bin/brctl delif bdg2 ra0"
                os.execute(cmd)
            end
               radioDbString = "_Entry0" 
               --tcapiSetEasyMeshSSIDExecute(radioDbString,"HideSSID","0")
               tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID","0")
               tcapiWLanEasyMeshCommitCmdExecute(radioDbString)
            end

            vapEnable = db.getAttribute("dot11VAP","vapName","ap4","vapEnabled")
            if(vapEnable == "0") then
                cmd ="/sbin/ifconfig rai0 down" 
                os.execute(cmd)
            if(not(util.fileExists("/pfrm2.0/DEVICE_REPEATER"))) then
                cmd = "/usr/bin/brctl delif bdg2 rai0"
                os.execute(cmd)
            end
                radioDbString = "11ac_Entry0" 
                --tcapiSetEasyMeshSSIDExecute(radioDbString,"HideSSID","0")
                tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID","0")
                tcapiWLanEasyMeshCommitCmdExecute(radioDbString)
            end
            
            --Disabling the BH Vap's When Mesh is disabled
            radioDbString = "_Entry1" 
            tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID","0")
            tcapiWLanEasyMeshCommitCmdExecute(radioDbString)

            radioDbString = "11ac_Entry1" 
            tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID","0")
            tcapiWLanEasyMeshCommitCmdExecute(radioDbString)

            
            radioDbString="_dat"
	        tcapiEasyMeshSetCmdExecute(radioDbString,"MapEnable",0)
	        tcapiEasyMeshSetCmdExecute(radioDbString,"MAP_Turnkey",0)
	   	    --tcapiSetCmdWrite("MapEnable","0")
	   	    --tcapiSetCmdWrite("MAP_Turnkey","0")
	   	    tcapiEasyMeshCommitCmdExecute(radioDbString)
           	tcapiSaveCmdExecute()
        end
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "FW_CONFIG_FAILED"
    end    
end


function easyMeshMgmt.config (name,inputTable,rowid,operation)

    if (operation == "add") then
        return db.insert(name, inputTable)
    elseif (operation == "edit") then
        return db.update(name, inputTable, rowid)
    elseif (operation == "delete") then
        return db.delete(name, inputTable)
    end

    return false

end

function easyMeshMgmt.import(easyMeshConfig,defaultConfig,removeConfig)

    --local BaseMac = util.fileToString(LAN_MAC_FILE)
    --os.execute("/sbin/ifconfig "..LAN_PHY_INTF_NAME.." hw ether "..BaseMac.." ;/sbin/ifconfig "..LAN_PHY_INTF_NAME.." up")
    local cmdpid = "/bin/ps | grep -v grep | grep '/userfs/bin/mapd' |awk '{print($1)}' > /tmp/mapdpidold"
    os.execute(cmdpid)

    if (easyMeshConfig == nil) then 
        easyMeshConfig = defaultConfig
    end

    local easyMeshTmp = {}  

    easyMeshTmp = config.update(easyMeshConfig.easyMesh,defaultConfig.easyMesh,removeConfig.easyMesh)

    if (easyMeshTmp ~= nil and #easyMeshTmp ~= 0) then
        for i,v in ipairs (easyMeshTmp) do
            v = util.addPrefix (v, "easyMesh.")
            if(util.fileExists("/pfrm2.0/HW_EN7528")) then
            	if(not(util.fileExists("/pfrm2.0/DEVICE_REPEATER"))) then
                	if(not(util.fileExists("/flash/FactoryResetMeshOn"))) then
                	    if(not(util.fileExists("/flash/MeshOn_Enable"))) then
                    		if(not(util.fileExists("/flash/AGENT_CONNECTED"))) then
                        		v["easyMesh.meshEnable"] = "0"
                    		end
                        else
                    		os.execute("/bin/rm -rf /flash/MeshOn_Enable")                
                        end
                	else
                    		os.execute("/bin/rm -rf /flash/FactoryResetMeshOn")                
                	end
            	end
	    end
            easyMeshMgmt.config("easyMesh",v,"-1","add")
        end
    end

    local easyMeshDevicesTmp = {}  
    easyMeshDevicesTmp = config.update(easyMeshConfig.easyMeshDevices,defaultConfig.easyMeshDevices,removeConfig.easyMeshDevices)
    if (easyMeshDevicesTmp ~= nil and #easyMeshDevicesTmp ~= 0) then
        for i,v in ipairs (easyMeshDevicesTmp) do
            v = util.addPrefix (v, "easyMeshDevices.")
            easyMeshMgmt.config("easyMeshDevices",v,"-1","add")
        end
    end

    local easyMeshBhInfoTmp ={}
    easyMeshBhInfoTmp = config.update(easyMeshConfig.easyMeshBhInfo,defaultConfig.easyMeshBhInfo,removeConfig.easyMeshBhInfo)
    if (easyMeshBhInfoTmp ~= nil and #easyMeshBhInfoTmp ~= 0) then
        for i,v in ipairs (easyMeshBhInfoTmp) do
            v = util.addPrefix (v, "easyMeshBhInfo.")
            if(util.fileExists("/pfrm2.0/DEVICE_REPEATER")) then
                if ((util.fileExists("/flash/configMerge/JMA24_DeviceRoleCheck")) == false) then
                    if(util.fileExists("/flash/JMA24_CAP_MODE")) then
                        v["easyMeshBhInfo.deviceRole"] = "1"
                    else
                        v["easyMeshBhInfo.deviceRole"] = "2"
                    end
                else
                    if(tonumber(v["easyMeshBhInfo.deviceRole"]) == tonumber("2")) then
                       v["easyMeshBhInfo.deviceName"] = "Agent"
                       os.execute("/bin/rm -rf /flash/JMA24_CAP_MODE")
                       os.execute("/bin/touch /flash/JMA24_AGENT_MODE")
                    else
                       v["easyMeshBhInfo.deviceName"] = "Controller"
                       os.execute("/bin/rm -rf /flash/JMA24_AGENT_MODE")
                       os.execute("/bin/touch /flash/JMA24_CAP_MODE")
                    end
                end
                local tmpvar = io.open("/flash/configMerge/JMA24_DeviceRoleCheck", "w")
                if(tmpvar ~= nil) then
                    tmpvar:close()
                end
            end
            easyMeshMgmt.config("easyMeshBhInfo",v,"-1","add")
        end
    end

   
    if(not(util.fileExists("/pfrm2.0/DEVICE_REPEATER"))) then
	--adding the BH Interfaces to bdg2
    local cmd ="/sbin/ifconfig ra1 up" 
    os.execute(cmd)
    cmd = "/usr/bin/brctl addif bdg2 ra1"
    os.execute(cmd)
    cmd ="/sbin/ifconfig rai1 up" 
    os.execute(cmd)
    cmd = "/usr/bin/brctl addif bdg2 rai1"
    os.execute(cmd)
    end

	if(not(util.fileExists("/pfrm2.0/DEVICE_REPEATER")) or (util.fileExists("/flash/JMA24_CAP_MODE"))) then

    radioDbString = "_radio2gbssinfo_entry0" 
    tcapiEasyMeshSetCmdExecute(radioDbString,"BackHaul",0)
    tcapiEasyMeshSetCmdExecute(radioDbString,"FrontHaul",1)
    --tcapiEasyMeshCommitCmdExecute(radioDbString)
    --tcapiSaveCmdExecute()
    
    radioDbString = "_radio2gbssinfo_entry2" 
    tcapiEasyMeshSetCmdExecute(radioDbString,"BackHaul",0)
    tcapiEasyMeshSetCmdExecute(radioDbString,"FrontHaul",1)
    --tcapiEasyMeshCommitCmdExecute(radioDbString)
    --tcapiSaveCmdExecute()
   
    radioDbString = "_radio2gbssinfo_entry3" 
    tcapiEasyMeshSetCmdExecute(radioDbString,"BackHaul",0)
    tcapiEasyMeshSetCmdExecute(radioDbString,"FrontHaul",1)
    --tcapiEasyMeshCommitCmdExecute(radioDbString)
    --tcapiSaveCmdExecute()
 
    radioDbString = "_radio5glbssinfo_entry0" 
    tcapiEasyMeshSetCmdExecute(radioDbString,"BackHaul",0)
    tcapiEasyMeshSetCmdExecute(radioDbString,"FrontHaul",1)
    --tcapiEasyMeshCommitCmdExecute(radioDbString)
    --tcapiSaveCmdExecute()
  
    radioDbString = "_radio5glbssinfo_entry2" 
    tcapiEasyMeshSetCmdExecute(radioDbString,"BackHaul",0)
    tcapiEasyMeshSetCmdExecute(radioDbString,"FrontHaul",1)
    --tcapiEasyMeshCommitCmdExecute(radioDbString)
    --tcapiSaveCmdExecute()
  
    radioDbString = "_radio5glbssinfo_entry3" 
    tcapiEasyMeshSetCmdExecute(radioDbString,"BackHaul",0)
    tcapiEasyMeshSetCmdExecute(radioDbString,"FrontHaul",1)
    --tcapiEasyMeshCommitCmdExecute(radioDbString)
    --tcapiSaveCmdExecute()


    local radioDbString = ""
    --Back Haul Vap's Name same as Primary AP's
    
    local vapName = util.fileToString ("/tmp/ssidRandom")
    
    vapName = vapName.. "-BH"
    radioDbString = "_Entry1" 
    tcapiSetEasyMeshSSIDExecute(radioDbString,"WNMEnable","1")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"MaxStaNum","10")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"AccessPolicy","0")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"IEEE8021X","0")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"WPSConfMode","4")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"SSID",vapName)
    tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID","1")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"AuthMode","WPA2PSK")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"EncrypType","AES")
    local bhPwd = generateBHPasswd("a")
    if(bhPwd == nil) then
        bhPwd = util.fileToString ("/tmp/randPasswordWifi")
    end
    tcapiSetEasyMeshSSIDExecute(radioDbString,"WPAPSK",bhPwd)
    tcapiSetEasyMeshSSIDExecute(radioDbString,"HideSSID","1")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"VapInfc","ra1")
    radioDbString = "_radio2gbssinfo_entry1" 
    tcapiEasyMeshSetCmdExecute(radioDbString,"BackHaul",1)
    tcapiEasyMeshSetCmdExecute(radioDbString,"FrontHaul",0)
    --tcapiEasyMeshCommitCmdExecute(radioDbString)
    --tcapiSaveCmdExecute()

    radioDbString = "11ac_Entry1" 
    tcapiSetEasyMeshSSIDExecute(radioDbString,"WNMEnable","1")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"MaxStaNum","10")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"AccessPolicy","0")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"IEEE8021X","0")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"WPSConfMode","4")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"SSID",vapName)
    tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID","1")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"AuthMode","WPA2PSK")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"EncrypType","AES")
    --[[bhPwd = generateBHPasswd("a")
    if(bhPwd == nil) then
        bhPwd = util.fileToString ("/tmp/randPasswordWifi")
    end]]--
    tcapiSetEasyMeshSSIDExecute(radioDbString,"WPAPSK",bhPwd)
    tcapiSetEasyMeshSSIDExecute(radioDbString,"HideSSID","1")
    tcapiSetEasyMeshSSIDExecute(radioDbString,"VapInfc","rai1")
    radioDbString = "_radio5glbssinfo_entry1" 
    tcapiEasyMeshSetCmdExecute(radioDbString,"BackHaul",1)
    tcapiEasyMeshSetCmdExecute(radioDbString,"FrontHaul",0)
    --tcapiEasyMeshCommitCmdExecute(radioDbString)
    --tcapiSaveCmdExecute()
    --radioDbString = "" 
    
    radioDbString="_Common"
    tcapiEasyMeshSetExecute(radioDbString,"DeviceRole","1")
    tcapiEasyMeshSetExecute(radioDbString,"SteerEnable","0")
    tcapiEasyMeshSetExecute(radioDbString,"NonMapIface","ra2;ra3;rai2;rai3")
    --tcapiSaveCmdExecute() 
    --tcapiEasyMeshCommitCmdExecute(radioDbString)
    --radioDbString="_mapcfg"
	--tcapiEasyMeshSetCmdExecute(radioDbString,"Agent_apply_M2_BSS_num","2")
    --radioDbString="_dat"
    --tcapiEasyMeshCommitCmdExecute(radioDbString)
    --tcapiSaveCmdExecute() 
    radioDbString="_SteerCfg"
	tcapiEasyMeshSetCmdExecute(radioDbString,"LowRSSIAPSteerEdge_RE","25")
	tcapiEasyMeshSetCmdExecute(radioDbString,"force_roam_rssi_th","-70")
	tcapiEasyMeshSetCmdExecute(radioDbString,"APsteer_thresh_tolerance","15")
	tcapiEasyMeshSetCmdExecute(radioDbString,"MinRssiIncTh_RE","5")
	tcapiEasyMeshSetCmdExecute(radioDbString,"MinRssiIncTh_Peer","5")
	tcapiEasyMeshSetCmdExecute(radioDbString,"CUOverloadTh_2G","70")
	tcapiEasyMeshSetCmdExecute(radioDbString,"CUOverloadTh_5G_L","80")
	tcapiEasyMeshSetCmdExecute(radioDbString,"CUOverloadTh_5G_H","80")
    --radioDbString="_dat"
    --tcapiEasyMeshCommitCmdExecute(radioDbString)
    --tcapiSaveCmdExecute() 
   
  
    local Status = "ERROR"
    local message = "" 
    local MeshAL_MAC = ""
   
    local meshConfTbl = db.getTable ("easyMesh",false)

    if(meshConfTbl ~= nil) then
	if(meshConfTbl[1]["meshEnable"] == "1") then
       os.execute("touch /flash/MESH_ENABLED")
       os.execute("echo '1' > /tmp/MESH_ENABLED")
              if(util.fileExists("/pfrm2.0/BRCM_SDK_5_02_L05P1")) then
                   os.execute("touch /flash/BRCM_MESH_ENABLED")
              end
       radioDbString="_dat"
	   tcapiEasyMeshSetCmdExecute(radioDbString,"MapEnable",1)
	   tcapiEasyMeshSetCmdExecute(radioDbString,"MAP_Turnkey",1)
	   --tcapiSetCmdWrite("MapEnable",1)
	   --tcapiSetCmdWrite("MAP_Turnkey",1)
	   --tcapiEasyMeshCommitCmdExecute(radioDbString)
       --tcapiSaveCmdExecute() 
       radioDbString="_mapcfg"
	   tcapiEasyMeshSetCmdExecute(radioDbString,"br_inf",meshConfTbl[1]["meshInterfacename"])
	   tcapiEasyMeshSetExecute(radioDbString,"bss_config_priority","ra1;ra0;rai1;rai0")
	   tcapiEasyMeshSetExecute(radioDbString,"lan","eth0.1,eth0.2,eth0.3,eth0.4")
	   MeshAL_MAC = ifDevLib.getMac(meshConfTbl[1]["meshInterfacename"])
	   tcapiEasyMeshSetCmdExecute(radioDbString,"AL-MAC",MeshAL_MAC)
	   radioDbString="_DefSetting"
	   tcapiEasyMeshSetCmdExecute(radioDbString,"DhcpCtl","0")
       radioDbString="_dat"
       tcapiEasyMeshCommitCmdExecute(radioDbString)
       tcapiSaveCmdExecute() 
     else
         os.execute("rm -rf /flash/MESH_ENABLED")
         os.execute("echo '0' > /tmp/MESH_ENABLED")

 
            --Disabling the BH Vap's When Mesh is disabled
            radioDbString = "_Entry1" 
            tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID","0")

            radioDbString = "11ac_Entry1" 
            tcapiSetEasyMeshSSIDExecute(radioDbString,"EnableSSID","0")

	   radioDbString="_dat"
	   tcapiEasyMeshSetCmdExecute(radioDbString,"MapEnable",0)
	   tcapiEasyMeshSetCmdExecute(radioDbString,"MAP_Turnkey",0)
	   --tcapiSetCmdWrite("MapEnable",0)
	   --tcapiSetCmdWrite("MAP_Turnkey",0)
	   tcapiEasyMeshCommitCmdExecute(radioDbString)
       tcapiSaveCmdExecute()
 	end
    end      
	if(meshConfTbl[1]["wifiOn"] == "0") then
	   os.execute ("sleep 60") 
              if (util.fileExists("/flash/BRCM_MESH_ENABLED")) then
                       dot11meshDisable()
                       dot11meshReStart()
                           os.execute("rm -rf /flash/BRCM_MESH_ENABLED")
                           os.execute("echo '0' > /tmp/MESH_ENABLED")
                       local cmd ="/bin/wl -i  wl0 down"
                       os.execute(cmd)
                       local cmd ="/bin/wl -i  wl0.1 down"
                       os.execute(cmd)
                       local cmd ="/bin/wl -i  wl0.2 down"
                       os.execute(cmd)
                       local cmd ="/bin/wl -i  wl1 down"
                       os.execute(cmd)
                       local cmd ="/bin/wl -i  wl1.2 down"
                       os.execute(cmd)
                       local cmd ="/bin/wl -i  wl1.3 down"
                       os.execute(cmd)
                   end
       radioDbString="_dat"
	   tcapiEasyMeshSetCmdExecute(radioDbString,"MapEnable",0)
	   tcapiEasyMeshSetCmdExecute(radioDbString,"MAP_Turnkey",0)
       tcapiSetEasyMeshSSIDExecute("_Entry0","EnableSSID","0")
       tcapiSetEasyMeshSSIDExecute("_Entry1","EnableSSID","0")
       tcapiSetEasyMeshSSIDExecute("_Entry2","EnableSSID","0")
       tcapiSetEasyMeshSSIDExecute("_Entry3","EnableSSID","0")
       tcapiSetEasyMeshSSIDExecute("11ac_Entry0","EnableSSID","0")
       tcapiSetEasyMeshSSIDExecute("11ac_Entry1","EnableSSID","0")
       tcapiSetEasyMeshSSIDExecute("11ac_Entry2","EnableSSID","0")
       tcapiSetEasyMeshSSIDExecute("11ac_Entry3","EnableSSID","0")
       
       radioDbString = ""	   
       tcapiWLanEasyMeshCommitCmdExecute(radioDbString)
       tcapiWLanEasyMeshCommitCmdExecute("11ac")
	radioDbString="_dat"
       tcapiEasyMeshCommitCmdExecute(radioDbString)
       tcapiSaveCmdExecute()

    end    

 end
  
end

function easyMeshMgmt.export()

    local easyMeshConfig= {}
  
    easyMeshConfig["easyMesh"] = db.getTable ("easyMesh", false)
    easyMeshConfig["easyMeshDevices"] = db.getTable ("easyMeshDevices", false)
    easyMeshConfig["easyMeshBhInfo"] = db.getTable ("easyMeshBhInfo", false)
  
    return easyMeshConfig
        
end

require "teamf1lualib/config"
if (config.register) then
   config.register("easyMeshMgmt", easyMeshMgmt.import, easyMeshMgmt.export, "2")
end

--
--PassWord Generate For BackHaul Based on the MAC Address 
--

function generateBHPasswd(band)
    local bspasswd = nil
    local FILE = "/tmp/lanMAC2"
    if(band == "a") then
        FILE = "/tmp/lanMAC3"
    end

    local macAddr = util.fileToString(FILE)  
    --print("MAC: " .. macAddr)
    
    if(ifDevLib.macAddrCheck(macAddr)== nil) then
        return nil
    end

    local cmd= "/pfrm2.0/bin/pwgen 16 1 -H "..FILE .." "
    local pipe = io.popen(cmd .. " 2>&1") -- redirect stderr to stdout
    local cmdOutput = pipe:read("*a")
    pipe:close()
    --print("rand password: " .. cmdOutput)
    bspasswd = string.gsub(cmdOutput, "\n", "")
    --print("rand password: " .. cmdOutput)
    --print("rand password len: " .. string.len(bspasswd))
    if(bspasswd == nil or string.len(bspasswd) ~= 16) then	
       return nil
    end
      return bspasswd
end 
