--[[ easyMeshChangePassword.lua - Handler for Easy Mesh Login passord Change.
--
-- Copyright (c) 2008-2014, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: easyMeshChangePassword.lua
-- Description: Handler for Easy Mesh Login passord Change.
-- 
-- modification history
-- --------------------
-- 01a, 17Dec19, ar written.
--
--]]

require "easyMeshLib"
require "ifDevLib"

-- List of WiFi_AP Tags as defined by Customer Specification.
local Mesh_obj = {
    ["Result"] = "Result"
}

-- Initialise the SSIDGetResponse_t Lua Table which will be coverted as JSON Object
local MeshStatusGetResponse_t = {
    ["Result"] = "ERROR",
    ["Response_Code"] = "400",
    ["Error_Message"] = "Failed to get WiFiSSID"
}

-- Supported Return Codes for "SSIDGetResponse"
local MeshStatusGetResponse_ReturnCodes = {
    ["OK"] = "OK",
    ["ERROR"] = "ERROR",
    ["SUCCESS"] = "Success",
    ["FAILED"]  = "Failed",
}


local WIFISON_NODE_DEVICE_MAC = "Device_MAC"
----------------------------------------------
--Mesh Status Get Request
--
-- @description This function Handles EasyMesh SSID Get Request Method.
--
--returns JSON response for EasyMesh SSID Get Request
--

function MeshStatusInfoHandler(methodObj, meshRequestMethod)

    local status
    local Mesh_obj = methodObj["Mesh_Obj"]
    local easyMesh_t
        
    if((Mesh_obj == nil) or (type(Mesh_obj) ~= "table"))then
        MeshStatusGetResponse_t["Result"] = MeshStatusGetResponse_ReturnCodes["FAILED"]  
        MeshStatusGetResponse_t["Response_Code"] = "400"
        MeshStatusGetResponse_t["Error_Message"] = "Bad Request"
        --mesh.sendResponse (MeshStatusGetResponse_t) 
        return "ERROR", "INVALID_METHOD", MeshStatusGetResponse_t
    end
   
    --Get the SSID Information from dot11VAP and dot11Profile Table
    easyMesh_t = db.getTable("easyMesh",false)

    if(easyMesh_t == nil) then
        MeshStatusGetResponse_t["Result"] = MeshStatusGetResponse_ReturnCodes["FAILED"]  
        MeshStatusGetResponse_t["Response_Code"] = "400"
        MeshStatusGetResponse_t["Error_Message"] = "Bad Request"
        --mesh.sendResponse (MeshStatusGetResponse_t) 
        return "ERROR", "INVALID_METHOD", MeshStatusGetResponse_t
    end    

    MeshStatusGetResponse_t["Mesh_Enable"] = db.getAttribute ("easyMesh", "_ROWID_", "1", "meshEnable") 
    MeshStatusGetResponse_t[WIFISON_NODE_DEVICE_MAC] = ifDevLib.getMac("bdg2")
    MeshStatusGetResponse_t["Result"] = MeshStatusGetResponse_ReturnCodes["OK"]  
    MeshStatusGetResponse_t["Error_Message"] = nil
    MeshStatusGetResponse_t["Response_Code"] = "200"
    --mesh.sendResponse (MeshStatusGetResponse_t) 
    return "OK", "SUCCESS", MeshStatusGetResponse_t

end

meshRequestMethodsList["MeshStatus"]["methodHandler"] = MeshStatusInfoHandler


