-- browse.lua - browsing the file structure of the box.

-- Copywrite (c) 2010 TeamF1, Inc.

--[[
 * DESCRIPTION
 * Browses the file structure of the DUT and returns the subdirectory and files contained in the browsing directory. 
--]]

--List of includes
require "lfs"

-- Package
browse = {}
 
function browse.dirtree(dir,dir1)
  assert(dir and dir ~= "", "directory parameter is missing or empty")
  if (dir ~= "/") then
  	if(string.sub(dir, -1) == "/") then
    	dir=string.sub(dir, 1, -2)
    end
  end
  local function yieldtree(dir)
    for entry in lfs.dir(dir) do
      if entry ~= "." and entry ~= ".." then
      	if(dir ~= "/") then
        	entry = dir.."/"..entry
        else
        	entry = dir..entry
        end
		local attr=lfs.attributes(entry)
		coroutine.yield(entry,attr)
		if(entry == dir1) then
			if(attr ~= nil) then
				if attr.mode == "directory" then
		  			yieldtree(entry)
		  		end
		  	end
		end
      end
    end
  end

  return coroutine.wrap(function() yieldtree(dir) end)
end
