--[[
#### 
#### File: routeTrExtn.lua
#### Description: 
#### TR-98 handlers for time. This file is included from
#### tr69Glue code.
####

#### Revisions:
01j 19Apr19,swr Changes for SPR 65926(validations for IPv4 route)
01i 21Jun18,swr Changes for SPR 62176(add dynamic routes to route DB table)
01h,21Nov17,swr Changes for SPR 62609
01g,17Oct17,swr Changes for SPR 62547(alias support for routes)
01f,02Feb17,swr Changes for SPR 58560
01e,22Jun16,rsr Removed bridges for ODU
01d,28oct15,swr  Changes for SPR 50822.
01c 28Sep15, swr changes for AddObject support for route and route6 from tr69  
01b,24jul15,sda  added validations for route parameters(SPR #51317 & SPR #51318) 
01a,14jul10,sam  moved functions from tr69funcs.lua
]]--

routeTr = {}

local dbFlag = 0

--[[
--*****************************************************************************
--  routeTr.routingModeGet: get parameters for RouteMode
--
-- This function gets values for the following parameters -
--
-- Device.Routing.Router.0.
-- Enable
-- Status
--
-- RETURN: 0 for success, > 0 for failure 
]]--

function routeTr.routingModeGet (input)
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local row = {}
    local query = nil
    local param = input["param"]
    
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "Router.")
    parentObjInstance = string.sub(param, 1, endIdx+2)
    
    --read the rowId mapping to qosClassQueue
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from qosClassification 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("routingMode", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

     --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = "1"
    elseif(string.find(input["param"], "Status")) then
        -- Status
        value = "Enabled"
    end

    return status, value
end

--[[
--*****************************************************************************
--  routeTr.routingGet: get parameters for Route
--
-- This function gets values for the following parameters -
--
-- Device.Routing.Router.0.IPv4Forwarding.0.
-- Enable
-- Status
-- Alias
-- DestIPAddress
-- DestSubnetMask
-- GatewayIPAddress
-- Interface
-- ForwardingMetric
--
-- RETURN: 0 for success, > 0 for failure 
]]--

function routeTr.routingGet (input)
    local status = "0"
    local value = "0"
    local rowId
    local row = {}
    local paramTbl = {}
    local query = nil
    local param = input["param"]
    
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --read the rowId mapping to route
    rowId = instanceMap[param]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from route 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("route", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

     --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = row ["active"]
    elseif(string.find(input["param"], "Status")) then
        -- Status
        if (row["active"] == "1") then
            value = "Enabled"
        elseif (row["active"] == "0") then
            value = "Disabled"
        end
    elseif(string.find(input["param"], "StaticRoute")) then
        -- route type
        if (row["routeType"] == "0" ) then
            value = "1"
        else
            value = "0"
        end
    elseif(string.find(input["param"], "Alias")) then
        -- Alias
        value = row["routeName"]
    elseif(string.find(input["param"], "DestIPAddress")) then
        -- DestIPAddress
        value = row ["dstIpAddr"]
    elseif(string.find(input["param"], "DestSubnetMask")) then
        -- DestSubnetMask
        value = row ["ipSNetMask"]
    elseif(string.find(input["param"], "GatewayIPAddress")) then
        -- GatewayIPAddress
        value = row ["gwIpAddr"]
    elseif(string.find(input["param"], "Interface")) then
        -- Interface
        value = nimfTr.getIfaceObjFromIfname(row["interfaceName"])
        if(value == nil or value == "") then
            return "1", "DB_ERROR_TRY_AGAIN"
        end
    elseif(string.find(input["param"], "ForwardingMetric")) then
        -- ForwardingMetric
        if (row["metric"] ~= nil) then
            value = row ["metric"]
        else
            value = "0"
        end
    elseif(string.find(input["param"], "ForwardingPolicy")) then
        -- ForwardingPolicy
        value = "-1"
    elseif(string.find(input["param"], "Origin")) then
        -- Origin
        query = "LogicalIfName='IF1' and AddressFamily='2'"
        nimfRow = db.getRowWhere ("NimfConf", query, false)

        if(row["routeType"] == "0") then
            value = "Static"
        elseif(row["routeType"]  == "1" ) then
            value = "RIP"
        elseif(row["routeType"]  == "2") then
            if(nimfRow["ConnectionType"] == "dhcpc") then
                value = "DHCPv4"
            else
                value = "Static"
            end
        end
    end

    return status, value
end

--[[
--*****************************************************************************
-- routeTr.routingModeSet- set route configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.Routing.Router.0.
-- 
-- Enable
--
-- Returns: status
]]--
function routeTr.routingModeSet(input, rowids, actionType, tr69Param)
    
    -- return
    return 0;

end

--[[
--*****************************************************************************
-- routeTr.routingSet- set route configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.Routing.Router.0.IPv4Forwarding.0.
-- 
-- Enable
-- Alias
-- dstIpAddr
-- ipSNetMask
-- gwIpAddr
-- interfaceObject
-- metric
--
-- Returns: status
]]--

function routeTr.routingSet(input, rowids, actionType, tr69Param)
    -- require
    require "teamf1lualib/iproute"
    require "teamf1lualib/ifDev"
    require "teamf1lualib/gui"
    require "teamf1lualib/routing"

    local row = {}
    local routeTbl = {}
    local rowId
    local query = nil
    local logicalIfName
    local status = OK
    local faultTbl = {}
    local index = 0
    local destIPFlag = 0
    local gwIPFlag = 0
    local interfaceFlag = 0
    local metricFlag = 0
    local errorFlag = 0
    
    
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --read the rowId mapping to route
    rowId = instanceMap[tr69Param]
    if (rowId == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get correspnding db entry from route 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("route", query, false)
    if(row == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end



    if(row["routeType"] == "1" or row["routeType"] == "2" ) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.REQUEST_DENIED)
        return status, faultTbl;
    end

    local routeTable = db.getTable("route",false)

    routeTbl = row

    if(routeTbl["interfaceName"] == "IF2") then
        routeTbl["interfaceName"] = "Local"
    elseif(routeTbl["interfaceName"] == "IF1") then
        routeTbl["interfaceName"] = "Internet"
    end

    --Enable
    if(input["route"]["route.Enable"] ~= nil) then
        routeTbl["active"] = input["route"]["route.Enable"]
    end 
   
    --Alias
    if(input["route"]["route.routeName"] ~= nil) then
        routeTbl["routeName"] = input["route"]["route.routeName"]
    end

    --DestIPAddress
    if(input["route"]["route.dstIpAddr"] ~= nil) then
        if(tr69Glue.tf1IpAddressValidate(input["route"]["route.dstIpAddr"],"","route.dstIpAddr","") == "OK") then
            routeTbl["dstIpAddr"] = input["route"]["route.dstIpAddr"]
        else
            tr69Glue.tf1Dbg("Invalid parameter for destip"..input["route"]["route.dstIpAddr"])
            status = ERROR
            index = index + 1
            destIPFlag = 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."DestIPAddress", error_code.INVALID_PARAM_VALUE)
        end
    end 
   
    --DestSubnetMask
    if(input["route"]["route.ipSNetMask"] ~= nil) then 
        if(tr69Glue.tf1CheckSubnetValue(input["route"]["route.ipSNetMask"], "route.ipSNetMask") ~= 1) then
            routeTbl["ipSNetMask"] = input["route"]["route.ipSNetMask"]
        else
            tr69Glue.tf1Dbg("Invalid DestSubnetMask")
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."DestSubnetMask", error_code.INVALID_PARAM_VALUE)
        end
    end
    
    --GatewayIPAddress
    if(input["route"]["route.gwIpAddr"] ~= nil) then
        if(tr69Glue.tf1IpAddressValidate(input["route"]["route.gwIpAddr"],"","route.gwIpAddr","") == "OK") then
            routeTbl["gwIpAddr"] = input["route"]["route.gwIpAddr"]
        else
            tr69Glue.tf1Dbg("Invalid value for "..input["route"]["route.gwIpAddr"])
            status = ERROR
            index = index + 1
            gwIPFlag = 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."GatewayIPAddress", error_code.INVALID_PARAM_VALUE)
        end
    end
    
    --Interface
    
    if(input["route"]["route.interfaceObject"] ~= nil) then
        --[[
        if(input["route"]["route.interfaceObject"] == "Device.IP.Interface.1." or input["route"]["route.interfaceObject"] == "Device.IP.Interface.2.") then
            if(input["route"]["route.interfaceObject"] == "Device.IP.Interface.1.") then
                routeTbl["interfaceName"] = "Internet"
            elseif(input["route"]["route.interfaceObject"] == "Device.IP.Interface.2.") then
                routeTbl["interfaceName"] = "Local"
            end
        else
            tr69Glue.tf1Dbg("Invalid value for "..input["route"]["route.interfaceObject"])
            status = ERROR
            index = index + 1
            interfaceFlag = 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Interface", error_code.INVALID_PARAM_VALUE)
        end
        ]]--

        local interfaceObj = input["route"]["route.interfaceObject"] 
        local len = string.len(interfaceObj)
        local interfaceStr = string.sub(interfaceObj, 1, len-2)
       
        if(interfaceStr == "Device.IP.Interface.") then
            netIntRowId = instanceMap[interfaceObj]
            if (netIntRowId ~= nil) then
                query = "_ROWID_="..netIntRowId
                networkInterfaceRow = db.getRowWhere ("networkInterface", query, false)
                if (networkInterfaceRow ~= nil) then
                    routeTbl["interfaceName"] = networkInterfaceRow["networkName"]
                else
                    interfaceFlag = 1
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Interface", error_code.INVALID_PARAM_VALUE)
                end
            else
                interfaceFlag = 1
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Interface", error_code.INVALID_PARAM_VALUE)
            end
        else
            interfaceFlag = 1
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Interface", error_code.INVALID_PARAM_VALUE)
        end
    end 
     
    --ForwardingMetric
    if(input["route"]["route.metric"] ~= nil) then
        if(tonumber(input["route"]["route.metric"]) >= ROUTE_METRIC_MIN_VAL and tonumber(input["route"]["route.metric"]) <= ROUTE_METRIC_MAX_VAL) then
            routeTbl["metric"] = input["route"]["route.metric"]
        else
            -- allowed range for route metric is (2-15)
            -- return invalid parameter code
            tr69Glue.tf1Dbg("Invalid value for "..input["route"]["route.metric"])
            status = ERROR
            index = index + 1
            metricFlag = 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."ForwardingMetric", error_code.INVALID_PARAM_VALUE)
        end
    end 
  
    -- check for same multiple routes
    for k,v in pairs (routeTable) do
        if(((v["dstIpAddr"] == routeTbl["dstIpAddr"] and v["gwIpAddr"] == routeTbl["gwIpAddr"]) or  
            (v["dstIpAddr"] == routeTbl["dstIpAddr"] and v["metric"] == routeTbl["metric"]) or 
            (v["routeName"] == routeTbl["routeName"])) and
            (v["_ROWID_"] ~= routeTbl["_ROWID_"])) then
            errorFlag = 1
            break;
        end
    end

    if(errorFlag == 1) then
        if(input["route"]["route.dstIpAddr"] ~= nil and destIPFlag == 0) then
            tr69Glue.tf1Dbg("route with same DestIPAddress and GatewayIPAddress or Metric already exists")
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."DestIPAddress", error_code.REQUEST_DENIED)
        end
        if(input["route"]["route.gwIpAddr"] ~= nil and gwIPFlag == 0) then
            tr69Glue.tf1Dbg("route with same GatewayIPAddress and DestIPAddress already exists")
            status = ERROR
            index = index + 1
            gwIPFlag = 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."GatewayIPAddress", error_code.REQUEST_DENIED)
        end
        if(input["route"]["route.metric"] ~= nil and metricFlag == 0) then
            tr69Glue.tf1Dbg("route with same Metric and DestIPAddress already exists")
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."ForwardingMetric", error_code.REQUEST_DENIED)
        end
        if(input["route"]["route.routeName"] ~= nil) then
            tr69Glue.tf1Dbg("route with Alias already exists")
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Alias", error_code.REQUEST_DENIED)
        end
    end


    local ifaceName = db.getAttribute("networkInterface", "networkName", routeTbl["interfaceName"], "LogicalIfName")

    --check if GatewayIPAddress is in the subnet of interface
    if (ifaceName ~= nil and ifDev.validateAddrInNetwork(routeTbl["gwIpAddr"], ifaceName) ~= 1) then
        if (input["route"]["route.gwIpAddr"] ~= nil and gwIPFlag == 0) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."GatewayIPAddress", error_code.INVALID_PARAM_VALUE)
        end
        if (input["route"]["route.interfaceObject"] ~= nil and interfaceFlag == 0) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Interface", error_code.INVALID_PARAM_VALUE)
        end
    end
    tr69Glue.tf1Dbg("routeTbl == " .. util.tableToStringRec(routeTbl))
 
    if (status ~= OK) then
        tr69Glue.tf1Dbg("return error with status = "..status)
        return status, faultTbl
    end

   
    errorFlag, statusCode = gui.networking.routing.static.ipv4.edit.set (routeTbl, dbFlag)

    if(errorFlag ~= "OK") then
        tr69Glue.tf1Dbg("Route edit failed with error = "..statusCode)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
    end
    
    -- return
    return status, faultTbl;
end

--[[
--*****************************************************************************
-- routeTr.IPv4ForwardingAdd - Add route configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.Routing.Router.0.IPv4Forwarding.0.
-- 
-- Enable
-- Alias
-- dstIpAddr
-- ipSNetMask
-- gwIpAddr
-- interfaceObject
-- metric
--
-- Returns: status
]]--
function routeTr.IPv4ForwardingAdd(input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering IPv4ForwardingAdd..")

    local status = "0"
    local row = {}
    local iprow = {}
    local statusCode = ""
    local errorFlag = ""

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = "1"
        return "1";
    end

    -- add a dummy row with gwIpAddr as LAN ipv4 address, user can edit the dummy values 
    -- after adding the row
    iprow = db.getRowWhere("ifstatic", "LogicalIfName='IF2' and AddressFamily=2", false)
    if (iprow == "" or iprow == nil) then                                               
        tr69Glue.tf1Dbg("Ip address not found in ifstatic")                              
        status = "1"                                                                     
        return "1";                                                             
    end

    -- Filling the parameters of route when Add Object for route is called
    input["routeName"] = "dummyName" 
    input["active"] = "0" 
    input["dstIpAddr"] = "192.168.29.250" 
    input["ipSNetMask"] = iprow["NetMask"] 
    input["interfaceName"] = "Local" 
    input["gwIpAddr"] = iprow["StaticIp"] 
    input["metric"] = "2"
    input["routeType"] = "0"
    
    require "teamf1lualib/gui"
    require "teamf1lualib/routing"
    statusCode, errorFlag = gui.networking.routing.static.ipv4.add.set (input, "-1", "add", dbFlag)
    
    if (statusCode ~= "OK") then
        tr69Glue.tf1Dbg("errorFlag : " .. errorFlag)
        return error_code.REQUEST_DENIED;
    end

    tr69Glue.tf1Dbg("Leaving IPv4ForwardingAdd..")
    return 0;
end

--[[
--*****************************************************************************
--  routeTr.routingIPv6Get: get parameters for Route6
--
-- This function gets values for the following parameters -
--
-- Device.Routing.Router.0.IPv6Forwarding.0.
-- Enable
-- Status
-- Alias
-- DestIPPrefix
-- NextHop
-- Interface
-- ForwardingMetric
--
-- RETURN: 0 for success, > 0 for failure 
]]--

function routeTr.routingIPv6Get (input)
    local status = "0"
    local value = "0"
    local rowId
    local row = {}
    local paramTbl = {}
    local query = nil
    local param = input["param"]
    
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --read the rowId mapping to route6
    rowId = instanceMap[param]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from route6 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("route6", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

     --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = row ["active"]
    elseif(string.find(input["param"], "Status")) then
        -- Status
        if (row["active"] == "1") then
            value = "Enabled"
        elseif (row["active"] == "0") then
            value = "Disabled"
        end
    elseif(string.find(input["param"], "Alias")) then
        -- Alias
        value = row["routeName"]
    elseif(string.find(input["param"], "DestIPPrefix")) then
        -- DestIPPrefix
        local ipv6Prefix = nimfLib.prefixGet(row["dstIpAddr"], row["prefix"]) 
        if(ipv6Prefix ~= nil) then
            value = ipv6Prefix.."/"..row["prefix"]
        else
            value = ""
        end
    elseif(string.find(input["param"], "NextHop")) then
        -- NextHop
        value = row ["gwIpAddr"]
    elseif(string.find(input["param"], "Interface")) then
        -- Interface
        value = nimfTr.getIfaceObjFromIfname(row["interfaceName"])
        if(value == nil or value == "") then
            return "1", "DB_ERROR_TRY_AGAIN"
        end
    elseif(string.find(input["param"], "ForwardingMetric")) then
        -- ForwardingMetric
        value = row ["metric"]
    elseif(string.find(input["param"], "ExpirationTime")) then
        -- ExpirationTime
        value = "9999-12-31T23:59:59Z"
    elseif(string.find(input["param"], "ForwardingPolicy")) then
        -- ForwardingPolicy
        value = "-1"
    elseif(string.find(input["param"], "Origin")) then
        -- Origin
        query = "LogicalIfName='IF1' and AddressFamily='10'"
        nimfRow = db.getRowWhere ("NimfConf", query, false)

        if(row["routeType"] == "0") then
            value = "Static"
        elseif(row["routeType"]  == "1" ) then
            value = "RIPng"
        else
                value = "DHCPv6"
        end
    end

    return status, value
end

--[[
--*****************************************************************************
-- routeTr.routingIPv6Set- set route configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.Routing.Router.0.IPv4Forwarding.0.
-- 
-- Enable
-- Alias
-- dstIpAddr
-- ipSNetMask
-- gwIpAddr
-- interfaceObject
-- metric
--
-- Returns: status
]]--
function routeTr.routingIPv6Set(input, rowids, actionType, tr69Param)
     -- require
    require "teamf1lualib/iproute"
    require "teamf1lualib/ifDev"

    local row = {}
    local routeTbl = {}
    local rowId
    local query = nil
    local networkName = ""
    local status = OK
    local faultTbl = {}
    local index = 0
    local prefixTbl = {}
    local destIPFlag = 0
    local gwIPFlag = 0
    local interfaceFlag = 0
    local metricFlag = 0
    local errorFlag = 0
    
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --read the rowId mapping to route6
    rowId = instanceMap[tr69Param]
    if (rowId == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get correspnding db entry from route6 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("route6", query, false)
    if(row == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end
    
    local routeTable = db.getTable("route6", false)

    routeTbl = row
    if(routeTbl["interfaceName"] == "IF2") then
        routeTbl["interfaceName"] = "Local"
    elseif(routeTbl["interfaceName"] == "IF1") then
        routeTbl["interfaceName"] = "Internet"
    end
    routeTbl["PrefixLength"] = routeTbl["prefix"]

    -- Alias
    if(input["route6"]["route6.routeName"] ~= nil) then
        routeTbl["routeName"] = input["route6"]["route6.routeName"]
    end

    -- Enable
    if(input["route6"]["route6.Enable"] ~= nil) then
        routeTbl["active"] = input["route6"]["route6.Enable"]
    end 
    
    -- DestIPPrefix
    if(input["route6"]["route6.dstIpAddr"] ~= nil) then
        if(string.find(input["route6"]["route6.dstIpAddr"], "/")) then
            prefixTbl = util.split(input["route6"]["route6.dstIpAddr"], "/")
            routeTbl["dstIpAddr"] = prefixTbl[1]
            if(prefixTbl[2] ~= nil) then
                routeTbl["PrefixLength"] = prefixTbl[2]
            end
            -- add nil checks
            --
            if((ifDevLib.isIpv6AddressReserved(routeTbl["dstIpAddr"]) > 0) or (tr69Glue.tf1ValidateIpv6Address(routeTbl["dstIpAddr"]) ~= 0 and tr69Glue.tf1ValidateIpv6Address(routeTbl["dstIpAddr"]) ~= "OK")) then
                status = ERROR
                index = index + 1
                destIPFlag = 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."DestIPPrefix", error_code.INVALID_PARAM_VALUE)
            end
        else
            status = ERROR
            index = index + 1
            destIPFlag = 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."DestIPPrefix", error_code.INVALID_PARAM_VALUE)
        end
    end 
 
    -- Interface
    if(input["route6"]["route6.interfaceObject"] ~= nil) then
        local interfaceObj = input["route6"]["route6.interfaceObject"] 
        local len = string.len(interfaceObj)
        local interfaceStr = string.sub(interfaceObj, 1, len-2)
       
        if(interfaceStr == "Device.IP.Interface.") then
            netIntRowId = instanceMap[interfaceObj]
            if (netIntRowId ~= nil) then
                query = "_ROWID_="..netIntRowId
                networkInterfaceRow = db.getRowWhere ("networkInterface", query, false)
                if (networkInterfaceRow ~= nil) then
                    routeTbl["interfaceName"] = networkInterfaceRow["networkName"]
                else
                    interfaceFlag = 1
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Interface", error_code.INVALID_PARAM_VALUE)
                end
            else
                interfaceFlag = 1
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Interface", error_code.INVALID_PARAM_VALUE)
            end
        else
            interfaceFlag = 1
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Interface", error_code.INVALID_PARAM_VALUE)
        end
    end 

    -- NextHop
    if(input["route6"]["route6.gwIpAddr"] ~= nil) then
        if((tr69Glue.tf1ValidateIpv6Address(input["route6"]["route6.gwIpAddr"]) ~= 0 and tr69Glue.tf1ValidateIpv6Address(input["route6"]["route6.gwIpAddr"]) ~= "OK") or (ifDevLib.isIpv6AddressReserved(input["route6"]["route6.gwIpAddr"]) > 0))  then
            gwIPFlag = 1
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."NextHop", error_code.INVALID_PARAM_VALUE)
        else
            -- check if the gateway ip is already configured on any interface
            local ipAddressTbl = db.getRowsWhere("ipAddressTable", "addressFamily=10", false)
            for k,v in pairs (ipAddressTbl) do
                if(v["ipAddress"] == input["route6"]["route6.gwIpAddr"]) then
                    gwIPFlag = 1
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."NextHop", error_code.INVALID_PARAM_VALUE)
                end
            end
            routeTbl["gwIpAddr"] = input["route6"]["route6.gwIpAddr"]
        end
    end

    -- ForwardingMetric
    if(input["route6"]["route6.metric"] ~= nil) then
        if(tonumber(input["route6"]["route6.metric"]) >= ROUTE_METRIC_MIN_VAL and tonumber(input["route6"]["route6.metric"]) <= ROUTE_METRIC_MAX_VAL) then
            routeTbl["metric"] = input["route6"]["route6.metric"]
        else
            status = ERROR
            index = index + 1
            metricFlag = 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."ForwardingMetric", error_code.INVALID_PARAM_VALUE)
        end
    end 

    --[[
    if (routeTbl["interfaceName"] == "6to4") then
        if ((iproute.validateTunnelNetwork(routeTbl["gwIpAddr"], routeTbl["interfaceName"]) ~= 1) or (tr69Glue.isGatewayInTunnelSubnet(routeTbl["gwIpAddr"]) ~= 0)) then
            if(input["route6"]["route6.interfaceObject"] ~= nil and interfaceErrorFlag == 0) then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Interface", error_code.REQUEST_DENIED)
            elseif(input["route6"]["route6.gwIpAddr"] ~= nil) then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."NextHop", error_code.INVALID_PARAM_VALUE)
            end
        end
    end
    ]]--
       
    -- check for same multiple routes
    for k,v in pairs (routeTable) do
        if(((v["dstIpAddr"] == routeTbl["dstIpAddr"] and v["gwIpAddr"] == routeTbl["gwIpAddr"]) or  
            (v["dstIpAddr"] == routeTbl["dstIpAddr"] and v["metric"] == routeTbl["metric"]) or 
            (v["routeName"] == routeTbl["routeName"])) and
            (v["_ROWID_"] ~= routeTbl["_ROWID_"])) then
            errorFlag = 1
            break;
        end
    end

    if(errorFlag == 1) then
        if(input["route6"]["route6.dstIpAddr"] ~= nil and destIPFlag == 0) then
            tr69Glue.tf1Dbg("route6 with same DestIPAddress and GatewayIPAddress or Metric already exists")
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."DestIPPrefix", error_code.REQUEST_DENIED)
        end
        if(input["route6"]["route6.gwIpAddr"] ~= nil and gwIPFlag == 0) then
            tr69Glue.tf1Dbg("route6 with same GatewayIPAddress and DestIPAddress already exists")
            status = ERROR
            index = index + 1
            gwIPFlag = 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."NextHop", error_code.REQUEST_DENIED)
        end
        if(input["route6"]["route6.metric"] ~= nil and metricFlag == 0) then
            tr69Glue.tf1Dbg("route6 with same Metric and DestIPAddress already exists")
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."ForwardingMetric", error_code.REQUEST_DENIED)
        end
        if(input["route6"]["route6.routeName"] ~= nil) then
            tr69Glue.tf1Dbg("route6 with Alias already exists")
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Alias", error_code.REQUEST_DENIED)
        end
    end
    ifaceName = db.getAttribute ("networkInterface", "networkName", routeTbl["interfaceName"], "LogicalIfName")
    --check if GatewayIPAddress is in the subnet of interface
    if(ifaceName ~= nil and ifDev.validateAddrInNetwork(routeTbl["gwIpAddr"], ifaceName) ~= 1) then
        if(input["route6"]["route6.interfaceObject"] ~= nil and interfaceFlag == 0) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Interface", error_code.REQUEST_DENIED)
        end
        if(input["route6"]["route6.gwIpAddr"] ~= nil and gwIPFlag == 0) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."NextHop", error_code.REQUEST_DENIED)
        end
    end
    tr69Glue.tf1Dbg("inputTbl ==" .. util.tableToStringRec(routeTbl))

    if (status ~= OK) then
       return status, faultTbl
    end


    local errorFlag, statusCode = gui.networking.routing.static.ipv6.edit.set (routeTbl, dbFlag)

    -- savedb if no error
    if(errorFlag == "OK") then 
        db.save() 
    else
        tr69Glue.tf1Dbg("statusCode == " .. statusCode)
        if(statusCode == "ROUTE_EDIT_FAILED") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.REQUEST_DENIED)
        end
    end
    
    -- return
    return status, faultTbl;
end

--[[
--*****************************************************************************
-- routeTr.IPv6ForwardingAdd - set route6 configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.Routing.Router.0.IPv6Forwarding.0.
-- 
-- Enable
-- Alias
-- DestIPPrefix
-- NextHop
-- Interface
-- ForwardingMetric
--
-- Returns: status
]]--
function routeTr.IPv6ForwardingAdd(input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering IPv6ForwardingAdd..")
    
    require "teamf1lualib/gui"
    require "teamf1lualib/routing"

    local status = "0"
    local iprow = {}
    local query = nil
    local iprow = {}
    local statusCode = ""
    local errorFlag = ""

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = "1"
        return "1";
    end

    -- add a dummy row with LAN ipv6 address as gateway IP, user can edit the dummy values 
    -- after adding the column
    iprow = db.getRowWhere("ifstatic", "LogicalIfName='IF2' and AddressFamily=10", false)
    if (iprow == "" or iprow == nil) then                                               
        tr69Glue.tf1Dbg("Ip address not found in ifstatic")                              
        status = "1"                                                                     
        return "1";                                                             
    end
    
    -- Filling the parameters of route6 when Add Object for route6 is called
    input["routeName"] = "dummyName" 
    input["active"] = "0" 
    input["dstIpAddr"] = "3ffe::1" 
    input["PrefixLength"] = iprow["PrefixLength"] 
    input["interfaceName"] = "Local" 
    input["gwIpAddr"] = iprow["StaticIp"] 
    input["metric"] = "2" 
    
    statusCode, errorFlag = gui.networking.routing.static.ipv6.add.set (input, "-1", "add", dbFlag)

    if (statusCode ~= "OK") then
        tr69Glue.tf1Dbg("errorFlag : " .. errorFlag)
        return error_code.REQUEST_DENIED;
    end

    tr69Glue.tf1Dbg("Leaving IPv6ForwardingAdd..")
    return 0;
end

--[[
--*****************************************************************************
--  routeTr.RouteInterfaceGet - get route interface value
--
-- This function gets a parameter value from the route object.
-- 
-- RETURN: value or nil
]]--

function routeTr.RouteInterfaceGet (interfaceName)

    --require
    require "teamf1lualib/tr69Glue"

    --locals
  local zoneType,LogicalIfName
    local tmp = ""
    local count = 1
    local k = 0
    local buffer = {}
    local interface = ""
    local rows = 0
    zoneType = db.getAttribute("networkInterface","LogicalIfName",interfaceName,"zoneType")
    networkInterface = db.getTable("networkInterface" ,false)
    nimfConf = db.getTable("NimfConf" ,false)
    local tr69Tbl = tr69Glue.instanceMapLoad()
    for _ in pairs(tr69Tbl) do
        rows = rows+1
    end
    for i,v in pairs(tr69Tbl) do
        for count=1,rows,1 do
            if(zoneType == "secure") then
                tmp = "InternetGatewayDevice.LANDevice." .. count ..".LANHostConfigManagement.IPInterface.1."  
            elseif(zoneType == "insecure") then
                tmp = "InternetGatewayDevice.WANDevice." .. count .. ".WANConnectionDevice." .. count .. ".WANIPConnection." .. count .. "."
            end
            if (tostring (i) == tostring (tmp)) then  
                buffer[count] = {}
                buffer[count]["name"] = i 
                buffer[count]["rowid"] = v
                count = count +1
            end
        end
    end
    if(zoneType == "secure") then
        for i,v in pairs(buffer) do
            for ii,vv in pairs(v) do
                LogicalIfName =  db.getAttribute("networkInterface","_ROWID_",vv,"LogicalIfName")
                if(interfaceName == LogicalIfName) then
                    interface = v.name
                    return interface
                end
            end
        end
    elseif(zoneType == "insecure") then 
        for i,v in pairs(buffer) do
            for ii,vv in pairs(v) do
                LogicalIfName =  db.getAttribute("NimfConf","_ROWID_",vv,"LogicalIfName")
                if(interfaceName == LogicalIfName) then
                    interface = v.name
                    return interface
                end
            end
        end
    end
end

--[[
--*****************************************************************************
--  routeTr.routingInfoGet: read proc file 
--
-- This function gets values for the following parameters -
--
-- Device.Routing.RouteInformation.
-- Enable
--
-- RETURN: 0 for success, > 0 for failure 
]]--

function routeTr.routingInfoGet (input)
    local status = "0"
    local value = "0"
    local filename
    if (util.fileExists ("/pfrm2.0/FXN_ODU")) then
        filename = "/proc/sys/net/ipv6/conf/eth0/accept_ra"
    else
        filename = "/proc/sys/net/ipv6/conf/bdg1/accept_ra"
    end
    local t
    local f = io.open(filename, "r")
     
    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        if (f ~= nil) then
            t = f.read(f)
            value = t
        else
            value = "0"
        end
    end
    
    -- closing file
    f:close ()

    return status, value

end

--[[
--*****************************************************************************
-- routeTr.routingInfoSet- set proc ra
-- 
-- This function is called to set the following parameters in
-- Device.Routing.RouteInformation.Enable
-- 
-- Enable
--
-- Returns: status
]]--
function routeTr.routingInfoSet(input, rowids, actionType, tr69Param)
    
    local status = "0"
    local errMsg = "STATUS_OK"
    local tmp
    local filename
    if (util.fileExists ("/pfrm2.0/FXN_ODU")) then
       filename = "/proc/sys/net/ipv6/conf/eth0/accept_ra" 
    else
       filename = "/proc/sys/net/ipv6/conf/bdg1/accept_ra" 
    end

    local f = io.open(filename, "w")
    if(input["routingMode"]["routingMode.Enable"] ~= nil) then
        tmp = input["routingMode"]["routingMode.Enable"]
        if (tmp ~= "0" and tmp ~= "1") then
            return 0;
        end
        if (f ~= nil) then
            f:write (tmp)
        end
    end

    -- closing file
    f:close ()
    
    -- return 
    return 0;

end
