-- @copyright Copyright (c) 2012, TeamF1, Inc. 

require "teamf1lualib/config"
require "ifDevLib"

--package ifDev
ifDev = {}

ifDev.IFDEV_NAMESZ=32
ifDev.IFDEV_NET_NAMESZ=64
ifDev.IFDEV_MIN_NETID=1
ifDev.IFDEV_MAX_NETID=4096
ifDev.IFDEV_MAX_NETIF=16
ifDev.debug=1

ifDev.tableName="networkInterface"
ifDev.table = {}
ifDev.prop={}
ifDev.prop.interfaceName="interfaceName"
ifDev.prop.LogicalIfName="LogicalIfName"
ifDev.prop.networkName="networkName"
ifDev.prop.networkId="networkId"
ifDev.prop.enable="enable"
ifDev.prop.ifType="ifType"
ifDev.prop.mtu="mtu"
ifDev.prop.mac="mac"
ifDev.prop.ifGroupId="ifGroupId"
ifDev.prop.ifMark="ifMark"
ifDev.prop.ifMode="connectionType"
ifDev.prop.ifZone="zoneType"

--------------------------------------------------------------------------------------
-- @class table 
-- @name ifDev.propType 
--
-- @field  IFDEV_PROP_TYPE_STATS     Get interface stats.
-- @field  IFDEV_PROP_TYPE_FLAGS     Get/Set interface flags.
-- @field  IFDEV_PROP_TYPE_MAC       Get/Set MAC address.
-- @field  IFDEV_PROP_TYPE_NAME      Get/Set network name(using logical interface name).
-- @field  IFDEV_PROP_TYPE_ID        Get/Set network ID.
-- @field  IFDEV_PROP_TYPE_IFTYPE    Get interface type.
-- @field  IFDEV_PROP_TYPE_STATUS    Get administrative status.
-- @field  IFDEV_PROP_TYPE_IFGROUP   Get/Set group membership information.
-- @field  IFDEV_PROP_TYPE_IFMARK    Get/Set interface mark information.
-- @field  IFDEV_PROP_TYPE_IFMODE    Get/Set interface mode. See ifDev.ifMode.
-- @field  IFDEV_PROP_TYPE_ZONE      Get/set interface zone. See ifDev.ifZone.
-- @field  IFDEV_PROP_TYPE_LIFNAME   Get Logical Interface name(using network name).
-- @field  IFDEV_PROP_TYPE_IFNAME    Get Physical Interface name.
--

ifDev.propType = {
      IFDEV_PROP_TYPE_STATS     =   0,
      IFDEV_PROP_TYPE_FLAGS     =   1,
      IFDEV_PROP_TYPE_MAC       =   2,
      IFDEV_PROP_TYPE_NAME      =   3,
      IFDEV_PROP_TYPE_ID        =   4,
      IFDEV_PROP_TYPE_IFTYPE    =   5,
      IFDEV_PROP_TYPE_STATUS    =   6,
      IFDEV_PROP_TYPE_IFGROUP   =   7,
      IFDEV_PROP_TYPE_IFMARK    =   8,
      IFDEV_PROP_TYPE_IFMODE    =   9,
      IFDEV_PROP_TYPE_ZONE      =   10,
      IFDEV_PROP_TYPE_LIFNAME   =   11,
      IFDEV_PROP_TYPE_IFNAME    =   12,
}

--------------------------------------------------------------------------------------
-- @class table
-- @name ifDev.flags
--
-- @field  IFF_UP               0x1
-- @field  IFF_BROADCAST        0x2  
-- @field  IFF_DEBUG            0x4    
-- @field  IFF_LOOPBACK         0x8  
-- @field  IFF_POINTOPOINT      0x10 
-- @field  IFF_NOTRAILERS       0x20 
-- @field  IFF_RUNNING          0x40   
-- @field  IFF_NOARP            0x80   
-- @field  IFF_PROMISC          0x100  
-- @field  IFF_ALLMULTI         0x200
--

ifDev.flags = {
    IFF_UP              =0x1,
    IFF_BROADCAST       =0x2,  
    IFF_DEBUG           =0x4,    
    IFF_LOOPBACK        =0x8,  
    IFF_POINTOPOINT     =0x10, 
    IFF_NOTRAILERS      =0x20, 
    IFF_RUNNING         =0x40,   
    IFF_NOARP           =0x80,   
    IFF_PROMISC         =0x100,  
    IFF_ALLMULTI        =0x200,
}

--------------------------------------------------------------------------------------
-- @class table
-- @name ifDev.ifType
--
-- @field  IFDEV_TYPE_UNKNOWN     0  
-- @field  IFDEV_TYPE_SWITCH      1
-- @field  IFDEV_TYPE_ETHERNET    2     
-- @field  IFDEV_TYPE_RADIO       3
-- @field  IFDEV_TYPE_VAP         4
-- @field  IFDEV_TYPE_BRIDGE      5
-- @field  IFDEV_TYPE_VLAN_ENCAP  6
-- @field  IFDEV_TYPE_MAX         7

ifDev.ifType = {
      IFDEV_TYPE_UNKNOWN    = 0,  
      IFDEV_TYPE_SWITCH     = 1,
      IFDEV_TYPE_ETHERNET   = 2,     
      IFDEV_TYPE_RADIO      = 3,
      IFDEV_TYPE_VAP        = 4,
      IFDEV_TYPE_BRIDGE     = 5,
      IFDEV_TYPE_VLAN_ENCAP = 6,
      IFDEV_TYPE_MAX        = 7,
}

--------------------------------------------------------------------------------------
-- @class table
-- @name ifDev.mode
--
-- @field  IFDEV_MODE_UNKNOWN   0
-- @field  IFDEV_MODE_BRIDGED   1
-- @field  IFDEV_MODE_ROUTED    2
-- @field  IFDEV_MODE_SWITCHED  3
--

ifDev.mode = {
      IFDEV_MODE_UNKNOWN       =   0,        
      IFDEV_MODE_BRIDGED       =   1, 
      IFDEV_MODE_ROUTED        =   2, 
      IFDEV_MODE_SWITCHED      =   3,  
}

--------------------------------------------------------------------------------------
-- @class table
-- @name ifDev.ifZone
--
-- @field  IFDEV_ZONE_TYPE_UNKNOWN      0
-- @field  IFDEV_ZONE_TYPE_SECURE       1
-- @field  IFDEV_ZONE_TYPE_UNSECURE     2
-- @field  IFDEV_ZONE_TYPE_INSECURE     2
-- @field  IFDEV_ZONE_TYPE_PUBLIC       3
-- @field  IFDEV_ZONE_TYPE_MAX          4
--

ifDev.ifZone = {
      IFDEV_ZONE_TYPE_UNKNOWN   =   0,
      IFDEV_ZONE_TYPE_SECURE    =   1,
      IFDEV_ZONE_TYPE_UNSECURE  =   2,
      IFDEV_ZONE_TYPE_INSECURE  =   2,
      IFDEV_ZONE_TYPE_PUBLIC    =   3,
      IFDEV_ZONE_TYPE_MAX       =   4,
}

--------------------------------------------------------------------------------------
-- @class table
-- @name ifDev.ifGroup
--
-- @field  IFDEV_GROUP_SECURE      1
-- @field  IFDEV_GROUP_UNSECURE    2
--

ifDev.ifGroup = {
    IFDEV_GROUPID_SECURE      =   1,
    IFDEV_GROUPID_UNSECURE    =   2,                
}

--------------------------------------------------------------------------------------
-- @class table
-- @name ifDev.netstate
--
-- @field  IFDEV_NET_UP      1
-- @field  IFDEV_NET_DOWN    2
--

ifDev.netstate = {
    IFDEV_NET_UP      =   1,
    IFDEV_NET_DOWN    =   2,
}

-------------------------------------------------------------------------------
-- @name  ifDev.import
--
-- @description The function imports all interface registrations.
--
-- @param cfg configuration is key-value format.
--
-- @return 
--

function ifDev.import (cfg, defaultCfg, removeCfg)
    if (cfg == nil) then
        cfg = defaultCfg       
    end
    
    local networkTmp = {}
    local singleApSupport = "0"
    singleApSupport = db.getAttribute ("environment", "name", "SINGLE_AP_SUPPORT" ,"value")

    
    if (cfg.ifTbl ~= nil) then
        networkTmp = config.update (cfg.ifTbl, defaultCfg.ifTbl, removeCfg.ifTbl)
        if (networkTmp ~= nil and #networkTmp ~= 0) then
            for i,v in ipairs (networkTmp) do
                --Changed the default "GuestWiFi" network name to "Guest"
                --following logic is to support config merge.
                if (v["networkName"] == "GuestWiFi") then
                    v["networkName"] = "Guest"
                end
                v = util.addPrefix (v, "networkInterface.")
                if (singleApSupport ~= nil and singleApSupport == "1")then
                    if (v["networkInterface.LogicalIfName"] ~= "IF4" and v["networkInterface.LogicalIfName"] ~= "IF5") then
                        ifDev.dbConfig ("networkInterface", v, -1, "add")
                    end
                else
                    if (v["networkInterface.LogicalIfName"] ~= "IF4" and v["networkInterface.LogicalIfName"] ~= "IF5" and v["networkInterface.LogicalIfName"] ~= "IF6" and v["networkInterface.LogicalIfName"] ~= "IF7") then
                        ifDev.dbConfig ("networkInterface", v, -1, "add")
                    end
                end
            end
        end
    end        
end

-------------------------------------------------------------------------------
--@name ifDev.netListGet
--
--@description The function gets the list of all the networks
--
--@param n/a
--
--@return status
--@return errCode
--@return netList
--

function ifDev.netListGet()
    local status, errCode, records = ifDev.cfgByQueryGet()
    return status, errCode, records
end

-------------------------------------------------------------------------------
--@name ifDev.netListByZoneGet
--
--@description The function gets the list of all networks belonging to a zone
--
--@zone zone network zone - secure, insecure, public .. etc
--
--@return status
--@return errCode
--@return netList
--

function ifDev.netListByZoneGet(zone)
    local query=nil

    if (type(zone) == "number") then
        zone = ifDev.zoneStrGet(zone)
        if (zone == nil) then
            return "ERROR", "IFDEV_ERR_INVALID_ZONE"
        end            
    end        

    query ="zoneType='" .. zone .. "'"

    local status, errCode, records = ifDev.cfgByQueryGet(query)
    return status, errCode, records
end

-------------------------------------------------------------------------------
--@name ifDev.zoneStrGet
--
--@description The function gets the string representation of a zone
--
--@param zone network zone
--
--@return zone string or nil
--

function ifDev.zoneStrGet(zone)
    local zoneStr = nil

    zone = tonumber(zone)

    if (zone == ifDev.ifZone.IFDEV_ZONE_TYPE_SECURE) then
        zoneStr = "secure"
    elseif (zone == ifDev.ifZone.IFDEV_ZONE_TYPE_INSECURE) then
        zoneStr = "insecure"
    elseif (zone == ifDev.ifZone.IFDEV_ZONE_TYPE_PUBLIC) then
        zoneStr = "public"
    else
        return nil
    end
end

-------------------------------------------------------------------------------
--@name ifDev.zoneNumGet
--
--@description The function gets the zone enumeration from the zone string
--
--@param zoneStr
--
--@return zone 
--

function ifDev.zoneNumGet(zoneStr)
    require "platformLib"
    local zoneNum = ifDev.ifZone.IFDEV_ZONE_TYPE_UNKNOWN

    if (zoneStr == nil) then
        return zoneNum
    end
            
    if (platformLib.strcasecmp(zoneStr, "secure") == 0) then
        zoneNum = ifDev.ifZone.IFDEV_ZONE_TYPE_SECURE
    elseif (platformLib.strcasecmp(zoneStr, "insecure") == 0) then
        zoneNum = ifDev.ifZone.IFDEV_ZONE_TYPE_INSECURE
    elseif (platformLib.strcasecmp(zoneStr, "public") == 0) then
        zoneNum = ifDev.ifZone.IFDEV_ZONE_TYPE_PUBLIC
    end        

    return zoneNum
end

-------------------------------------------------------------------------------
--@name ifDev.zoneGet
--
--@description The function gets the zone for the given network
--
--@param LogicalIfName  network name
--
--@return zone 
--

function ifDev.zoneGet(LogicalIfName)
    local cfg = {}
    require "platformLib"
    local zoneNum = ifDev.ifZone.IFDEV_ZONE_TYPE_UNKNOWN

    if (LogicalIfName == nil) then
        return zoneNum
    end
            
    status, errCode, cfg = ifDev.cfgByNameGet(LogicalIfName)
    if (status ~= "OK") then
        return zoneNum
    end        

    local zone = cfg["zoneType"]

    if (platformLib.strcasecmp(zone, "secure") == 0) then
        zoneNum = ifDev.ifZone.IFDEV_ZONE_TYPE_SECURE
    elseif (platformLib.strcasecmp(zone, "insecure") == 0) then
        zoneNum = ifDev.ifZone.IFDEV_ZONE_TYPE_INSECURE
    elseif (platformLib.strcasecmp(zone, "public") == 0) then
        zoneNum = ifDev.ifZone.IFDEV_ZONE_TYPE_PUBLIC
    end        

    return zoneNum
end

-------------------------------------------------------------------------------
--@name ifDev.isRouted
--
--@description The function checks if the network is routed. The function 
--assumes that there is only one network association
--
--@param mode network connection mode
--
--@return true or false
--@return network name of the associated network
--

function ifDev.isRouted(mode)
    local kv = util.split(mode, ":")
    if (platformLib.strcasecmp(kv[1], "ROUTED") == 0) then
        return true, kv[2]
    end        
    
    return false, kv[2]
end

-------------------------------------------------------------------------------
--@name ifDev.isBridged
--
--@description The function checks if the network is bridged. The function 
--assumes that there is only one network association
--
--@param mode network connection mode
--
--@return true or false
--@return network name of the associated network
--

function ifDev.isBridged(mode)
    local kv = util.split(mode, ":")
    if (platformLib.strcasecmp(kv[1], "BRIDGED") == 0) then
        return true, kv[2]
    end        
    
    return false, kv[2]
end

-------------------------------------------------------------------------------
--@name ifDev.isSwitched
--
--@description The function checks if the network is switched. The function 
--assumes that there is only one network association
--
--@param mode network connection mode
--
--@return true or false
--@return network name of the associated network
--

function ifDev.isSwitched(mode)
    local kv = util.split(mode, ":")
    if (platformLib.strcasecmp(kv[1], "SWITCHED") == 0) then
        return true, kv[2]
    end        
    
    return false, kv[2]
end

-------------------------------------------------------------------------------
-- @name ifDev.statsGet 
--
-- @description  This function gets the statistics for the given network.
--
-- @param name  network name
--
-- @return status   - OK or ERROR
-- @return errCode   
-- @return nil or table of statistics
--

function ifDev.statsGet (name)
    local   stats={}
    local   status = "ERROR"
    local   errCode = "IFDEV_ERR_INVALID_ARG"
    local   ifInfo = {}    
    local   ifname = ""

    if (name == nil) then
        return status, errCode
    end
            
    ifname = db.getAttribute(ifDev.tableName, ifDev.prop.networkName, name, 
                             ifDev.prop.LogicalIfName)
    if (ifname == nil ) then
        return status, errCode
    end            

    ifInfo = ifDevLib.netIfInfoGet(ifname)
    if (ifInfo == nil) then
        return status, errCode
    end        

    stats["timestamp"] = ifInfo["timestamp"]
    stats["date"] = ifInfo["date"] 
    stats["rx_packets"] = ifInfo["rx_packets"]
    stats["rx_bytes"] = ifInfo["rx_bytes"]
    stats["rx_dropped"] = ifInfo["rx_dropped"]
    stats["rx_errors"] = ifInfo["rx_errors"]
    stats["tx_packets"] = ifInfo["tx_packets"]
    stats["tx_bytes"] = ifInfo["tx_bytes"] 
    stats["tx_dropped"] = ifInfo["tx_dropped"] 
    stats["tx_errors"] = ifInfo["tx_errors"]
    stats["multicast"] = ifInfo["multicast"]

    return "OK", "STATUS_OK", stats
end

-------------------------------------------------------------------------------
-- @name ifDev.ifInfoGet
--
-- @description This function dumps interface information of this network
--
-- @param name  network name
--
-- @return status   - OK or ERROR
-- @return errCode   
-- @return table or nil
--

function ifDev.ifInfoGet (name)
    local   ifInfo = {}    

    if (name == nil) then
        return status, errCode
    end
            
    local LogicalIfName = db.getAttribute(ifDev.tableName, ifDev.prop.networkName, 
                                          name, ifDev.prop.LogicalIfName)            

    ifInfo = ifDevLib.netIfInfoGet(LogicalIfName)
    if (ifInfo == nil) then
        return status, errCode
    end        

    return "OK", "STATUS_OK", ifInfo
end

-------------------------------------------------------------------------------
-- @name ifDev.register
--
-- @description register interface with TeamF1 management framework.
--
-- @param prop   interface properties table.
-- @field interfaceName     Physical interface name. This field is mandatory.
-- @field LogicalIfName     LogicalInterface. An interface abstraction 
--                          identifying this interface.
-- @field networkName       Display/Network name for this interface.
-- @field networkId         unique ID 
-- @field ifType            Interface type. see ifDev.ifType for valid interface types.
-- @field enable            Administrative enable for this interface.
-- @field mtu               MTU of this interface.
-- @field mac               MAC address of this interface.
-- @field ifGroupId         a hex value indicating group membership
-- @field ifMark            a hex value indicating packet mark that can be used to 
--                          identify packets originating from this interface
-- @field connectionType    mode using which the interface is connected to the system. 
--                          The default mode is ifDev.IFDEV_MODE_ROUTED.see 
--                          ifDev.ifMode for other options.
-- @field zoneType          security zone to which this interface belongs. 
--                          The default zone is ifDev.IFDEV_ZONE_TYPE_SECURE. 
--                          see ifDev.ifZone for other options.
--
-- @return status   - OK or ERROR
-- @return errCode   
--

function ifDev.register (prop)
    local status = "ERROR"
    local errCode = "IFDEV_ERR_INVALID_ARG"
    local netIf = {}

    if (prop == nil) then
        return status, errCode        
    end        

    if (type(prop) ~= "table") then
        return status, errCode        
    end        

    -- check for mandatory arguments 
    if ((prop["ifType"] == nil) or (prop["interfaceName"] == nil))  then
        return status, errCode        
    end        

    -- validate type
    if (ifDev.ifTypeValidate(prop["ifType"]) == 0) then
        return status, "IFDEV_ERR_INVALID_IFTYPE"
    end       

    -- if network name is provided, then validate it
    if (prop["networkName"] ~= nil) then
        status, errCode = ifDev.nameValidate(prop["networkName"])
        if (status == "ERROR") then
            return status, errCode        
        end            
    end

    -- 
    -- if logical interface name is not provided, then 
    -- generate unique logicalIfname
    --
    if (prop["LogicalIfName"] == nil) then
        prop["LogicalIfName"] = ifDev.lNameGen()
    end

    -- if interface zone is provided, then validate it
    if (prop["zoneType"] ~= nil) then
        status, errCode = ifDev.zoneValidate(prop["zoneType"])
        if (status == "ERROR") then
            return status, errCode        
        end            
    else        
        prop["zoneType"] = ifDev.ifZone.IFDEV_ZONE_TYPE_SECURE
    end        
    
    if (prop["interfaceName"] ~= nil) then
        netIf[ifDev.prop.interfaceName] =  prop["interfaceName"]
    end

    if (prop["LogicalIfName"] ~= nil) then
        netIf[ifDev.prop.LogicalIfName] = prop["LogicalIfName"]
    end

    if (prop["networkName"] ~= nil) then
        netIf[ifDev.prop.networkName] = prop["networkName"] 
    end

    if (prop["networkId"] ~= nil) then
        netIf[ifDev.prop.networkId] = prop["networkId"]
    end

    if (prop["enable"] ~= nil) then
        netIf[ifDev.prop.enable] = prop["enable"] 
    end

    if (prop["ifType"] ~= nil) then
        netIf[ifDev.prop.ifType] = prop["ifType"] 
    end

    if (prop["mtu"] ~= nil) then
        netIf[ifDev.prop.mtu] = prop["mtu"] or ''
    end

    if (prop["mac"] ~= nil) then
        netIf[ifDev.prop.mac] = prop["mac"] or ''
    end

    if (prop["ifGroupId"] ~= nil) then
        netIf[ifDev.prop.ifGroupId] = prop["ifGroupId"] or ''
    end

    if (prop["ifMark"] ~= nil) then
        netIf[ifDev.prop.ifMark] = prop["ifMark"] or ''
    end

    if (prop["connectionType"] ~= nil) then
        netIf[ifDev.prop.ifMode] = prop["connectionType"] or ''
    end

    if (prop["zoneType"] ~= nil) then
        netIf[ifDev.prop.ifZone] = prop["zoneType"] or ''
    end

    -- check if the interface has already been registered
    local query =  ifDev.prop.LogicalIfName .. "='" .. prop["LogicalIfName"] .."' or " .. 
                   ifDev.prop.networkName .. "='" .. prop["networkName"] .."'"

    -- add the registration to the database
    netIf = util.addPrefix (netIf, "networkInterface.")

    local row = db.getRowWhere(ifDev.tableName, query, false)
    if (row ~= nil) then
        status, errCode = ifDev.dbConfig ("networkInterface", netIf, 
                                          row["_ROWID_"], "edit")
        if (status == "ERROR") then
            return status, errCode, errstr
        end        
    else
        status, errCode, errstr  = ifDev.dbConfig("networkInterface", netIf, -1, "add")
        if (status == "ERROR") then
            return status, errCode, errstr
        end        
     end        

    netIf = util.removePrefix (netIf, "networkInterface.")

    return "OK","STATUS_OK", netIf
end

-------------------------------------------------------------------------------
-- @name ifDev.netUp
--
-- @description This function brings up the network
--
-- @param name name of the network 
--
-- @return 
--

function ifDev.netUp (name)
    local status = "ERROR"
    local errCode = "IFDEV_ERR_INVALID_ARG"
    local ifcfg = {}
    
    status, errCode, ifcfg = ifDev.cfgByNameGet(name)
    if (status ~= "OK") then
        return status, errCode
    end        

    if (ifDev.if_up(ifcfg[ifDev.prop.interfaceName], 1) < 0) then
        return status, "IFDEV_ERR_NET_UP_FAILED"
    end
    
    return "OK","STATUS_OK"        
end

-------------------------------------------------------------------------------
-- @name ifDev.netDown
--
-- @description This function brings the network down
--
-- @param name name of the network 
--
-- @return 
--

function ifDev.netDown (name)
    local status = "ERROR"
    local errCode = "IFDEV_ERR_INVALID_ARG"
    local ifcfg = {}
    
    status, errCode, ifcfg = ifDev.cfgByNameGet(name)
    if (status ~= "OK") then
        return status, errCode
    end        

    if (ifDev.if_up(ifcfg[ifDev.prop.interfaceName], 0) < 0) then
        return status, "IFDEV_ERR_NET_DOWN_FAILED"
    end
    
    return "OK","STATUS_OK"        
end

-------------------------------------------------------------------------------
-- @name ifDev.unregister
--
-- @description unregister interface from TeamF1 management framework
--
-- @param prop interface properties table.
-- @field name Display/Network name for this interface. This field is mandatory.
--
-- @return 
--

function ifDev.unregister (prop)
    local query = nil
    local status = "ERROR"
    local errCode = "IFDEV_ERR_INVALID_ARG"

    if (prop == nil) then
        return status, errCode        
    end
    
    if (type(prop) ~= "table") then
        return status, errCode        
    end
--[[                    
    if (prop["interfaceName"] ~= nil) then
        query =  ifDev.prop.interfaceName .. "='" .. prop["interfaceName"] .. "'"
    end
    ]]        
    if (prop["LogicalInterface"] ~= nil) then
        if (query ~= nil) then        
            query = query .. " or " ..  ifDev.prop.LogicalIfName .. "='" .. prop["LogicalIfName"] .."'"
        else            
            query = ifDev.prop.LogicalIfName .. "='" .. prop["LogicalIfName"] .."'"
        end            
    end
    
    if (prop["networkName"] ~= nil) then
        if (query ~= nil) then        
            query = query .. " or " ..  ifDev.prop.networkName .. "='" .. prop["networkName"] .."'"
        else            
            query = ifDev.prop.networkName .. "='" .. prop["networkName"] .."'"
        end            
    end
    
    -- delete the row matching the query
    valid, errstr = db.deleteRowWhere(ifDev.tableName, query)
    if (not valid) then
        return status, "IFDEV_ERR_DB_TRANSACTION", errstr
    end        

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name ifDev.set
--
-- @description  This function sets network properties. See the ifDev.propType
-- for supported list.
--
-- @param name      network/logical name.
-- @param property  property type
-- @param value     The value of the property to be set
--
-- @return status   - OK or ERROR
-- @return errCode   
-- @return value       
--

function ifDev.set (name, property, value)
    local status = "ERROR"
    local errCode = "IFDEV_ERR_INVALID_ARG"

    if (name == nil) then
        return status, errCode 
    end

    if (property == nil) then
        return status, errCode 
    end

    property = tonumber(property)

    if (property == ifDev.propType.IFDEV_PROP_TYPE_MAC) then
        status, errCode = ifDev.macValidate(value) 
        if (status == "ERROR") then
            return status, errCode
        end            

        valid, errstr = db.setAttribute (ifDev.tableName, ifDev.prop.networkName, 
                                         name, ifDev.prop.mac, value)
        if (not valid) then
            return "ERROR", "IFDEV_ERR_DB_TRANSACTION", errstr
        end
    elseif (property ==ifDev.propType. IFDEV_PROP_TYPE_NAME) then
        status, errCode = ifDev.nameValidate(value)
        if (status == "ERROR") then
            return status, errCode
        end            
                
        valid , errstr = db.setAttribute (ifDev.tableName, ifDev.prop.LogicalIfName, 
                                          name, ifDev.prop.networkName, value)
        if (not valid) then
            return "ERROR", "IFDEV_ERR_DB_TRANSACTION", errstr
        end
    elseif (property == ifDev.propType.IFDEV_PROP_TYPE_ID) then
        status, errCode = ifDev.IDValidate(name, value)
        if (status == "ERROR") then
            return status, errCode
        end            
                
        valid , errstr = db.setAttribute (ifDev.tableName, ifDev.prop.networkName, 
                                          name, ifDev.prop.networkId, value)
        if (not valid) then
            return "ERROR", "IFDEV_ERR_DB_TRANSACTION", errstr
        end
    elseif (property == ifDev.propType.IFDEV_PROP_TYPE_STATUS) then
        if (value == nil) then
            return status, errCode
        end

        if ((tonumber(value) ~= 1) and (tonumber(value) ~= 0)) then
            return status, errCode
        end            
                
        valid, errstr = db.setAttribute (ifDev.tableName, ifDev.prop.networkName, 
                                         name, ifDev.prop.enable, value)
        if (not valid) then
            return "ERROR", "IFDEV_ERR_DB_TRANSACTION", errstr
        end
    elseif (property == ifDev.propType.IFDEV_PROP_TYPE_IFGROUP) then
        status, errCode = ifDev.ifgroupValidate(name, value)
        if (status == "ERROR") then
            return status, errCode
        end            
                
        valid , errstr = db.setAttribute (ifDev.tableName, ifDev.prop.networkName, 
                                          name, ifDev.prop.ifGroupId, value)
        if (not valid) then
            return "ERROR", "IFDEV_ERR_DB_TRANSACTION", errstr
        end

    elseif (property == ifDev.propType.IFDEV_PROP_TYPE_IFMARK) then
        status, errCode = ifDev.ifMarkValidate(name, value)
        if (status == "ERROR") then
            return status, errCode
        end            
                
        valid , errstr = db.setAttribute (ifDev.tableName, ifDev.prop.networkName,
                                          name, ifDev.prop.ifMark, value)
        if (not valid) then
            return "ERROR", "IFDEV_ERR_DB_TRANSACTION", errstr
        end
    elseif (property == ifDev.propType.IFDEV_PROP_TYPE_IFMODE) then
        status, errCode = ifDev.modeValidate(value)
        if (status == "ERROR") then
            return status, errCode
        end            
                
        valid , errstr = db.setAttribute (ifDev.tableName, ifDev.prop.networkName, 
                                          name, ifDev.prop.ifMode, value)
        if (not valid) then
            return "ERROR", "IFDEV_ERR_DB_TRANSACTION", errstr
        end
    elseif (property == ifDev.propType.IFDEV_PROP_TYPE_ZONE) then
        status, errCode = ifDev.zoneValidate(name, value)
        if (status == "ERROR") then
            return status, errCode
        end            
                
        valid , errstr = db.setAttribute (ifDev.tableName, ifDev.prop.networkName, 
                                          name, ifDev.prop.ifZone, value)
        if (not valid) then
            return "ERROR", "IFDEV_ERR_DB_TRANSACTION", errstr
        end
    else
        ifDev.dprintf("set: property: " .. property .. " not supported")
    end

    return status, errCode, value
end
 

-------------------------------------------------------------------------------
-- @name ifDev.get
--
-- @description This function gets the interface properties. See ifDev.propType 
-- for the list of supported properties
--
-- @param name      network/logical name
-- @param property  property type
--
-- @return status   - OK or ERROR
-- @return errCode   
-- @return value    - the value of the property
--

function ifDev.get (name, property)
    local status = "ERROR"
    local errCode = "IFDEV_ERR_INVALID_ARG"
    local value = ""
    local query = ""

    if (name == nil) then
        return status, errCode, value        
    end

    if (property == nil) then
        return status, errCode, value        
    end

    property = tonumber(property)

    if (property == ifDev.propType.IFDEV_PROP_TYPE_IFNAME) then
        value = db.getAttribute(ifDev.tableName, ifDev.prop.networkName, 
                                name, ifDev.prop.interfaceName)
        if (value == nil ) then
            errCode = "IFDEV_ERR_NETWORK_NAME"
            return status, errCode
        end            

    elseif (property == ifDev.propType.IFDEV_PROP_TYPE_STATS) then
        status, errCode, value = ifDev.statsGet(name)
        if (status == "ERROR") then
            errCode = "IFDEV_ERR_NETWORK_STATS"
            return status, errCode
        end            

    elseif (property == ifDev.propType.IFDEV_PROP_TYPE_MAC) then
        value = db.getAttribute(ifDev.tableName, ifDev.prop.networkName, 
                                name, ifDev.prop.interfaceName)
        if (value == nil ) then
            errCode = "IFDEV_ERR_NETWORK_NAME"
            return status, errCode
        end            

        value = ifDevLib.getMac(value)
        if (value == nil ) then
            errCode = "IFDEV_ERR_NETWORK_MAC"
            return status, errCode
        end            

    elseif (property == ifDev.propType.IFDEV_PROP_TYPE_NAME) then
        value = db.getAttribute(ifDev.tableName, ifDev.prop.LogicalIfName, 
                                name, ifDev.prop.networkName)
        if (value == nil ) then
            errCode = "IFDEV_ERR_NETWORK_NAME"
            return status, errCode
        end            
                    
    elseif (property == ifDev.propType.IFDEV_PROP_TYPE_ID) then
        value = db.getAttribute(ifDev.tableName, ifDev.prop.networkName, 
                                name, ifDev.prop.networkId)
        if (value == nil ) then
            errCode = "IFDEV_ERR_NETWORK_ID"
            return status, errCode
        end            

    elseif (property == ifDev.propType.IFDEV_PROP_TYPE_IFTYPE) then
        value = db.getAttribute(ifDev.tableName, ifDev.prop.networkName, 
                                name, ifDev.prop.ifType)
        if (value == nil ) then
            errCode = "IFDEV_ERR_NETWORK_IFTYPE"
            return status, errCode
        end            

    elseif (property == ifDev.propType.IFDEV_PROP_TYPE_STATUS) then
        value = db.getAttribute(ifDev.tableName, ifDev.prop.networkName, 
                                name, ifDev.prop.enable)
        if (value == nil ) then
            errCode = "IFDEV_ERR_NETWORK_STATUS"
            return status, errCode
        end            

    elseif (property == ifDev.propType.IFDEV_PROP_TYPE_IFGROUP) then
        value = db.getAttribute(ifDev.tableName, ifDev.prop.networkName, 
                                name, ifDev.prop.ifGroupId)
        if (value == nil ) then
            errCode = "IFDEV_ERR_NETWORK_IFGROUP"
            return status, errCode
        end            

    elseif (property == ifDev.propType.IFDEV_PROP_TYPE_IFMARK) then
        value = db.getAttribute(ifDev.tableName, ifDev.prop.networkName, 
                                name, ifDev.prop.ifMark)
        if (value == nil ) then
            errCode = "IFDEV_ERR_NETWORK_IFMARK"
            return status, errCode
        end            

    elseif (property == ifDev.propType.IFDEV_PROP_TYPE_IFMODE) then
        value = db.getAttribute(ifDev.tableName, ifDev.prop.networkName, 
                                name, ifDev.prop.ifMode)
        if (value == nil ) then
            errCode = "IFDEV_ERR_NETWORK_IFMODE"
            return status, errCode
        end            

    elseif (property == ifDev.propType.IFDEV_PROP_TYPE_ZONE) then
        value = db.getAttribute(ifDev.tableName, ifDev.prop.networkName, 
                                name, ifDev.prop.ifZone)
        if (value == nil ) then
            errCode = "IFDEV_ERR_NETWORK_ZONE"
            return status, errCode
        end            

    elseif (property == ifDev.propType.IFDEV_PROP_TYPE_LIFNAME) then
        value = db.getAttribute(ifDev.tableName, ifDev.prop.networkName, 
                                name, ifDev.prop.LogicalIfName)
        if (value == nil ) then
            errCode = "IFDEV_ERR_NETWORK_LOGICAL_IFNAME"
            return status, errCode
        end            

    else
        ifDev.dprintf("get: property: " .. property .. " not supported")
    end

    return "OK", "STATUS_OK", value
end

-------------------------------------------------------------------------------
-- @name ifDev.cfgByIdGet
--
-- @description  This function gets the interface configuration of the given
-- networkId.
--
-- @return status   - OK or ERROR
-- @return errCode   
-- @return cfg      - interface configuration.
--

function ifDev.cfgByIdGet(ID)
    local status = "ERROR"
    local errCode = "IFDEV_ERR_INVALID_ARG"
    local query=""

    if (ID == nil) then
        return status, errCode        
    end
            
    query = "select * from " .. ifDev.tableName .. " where networkId=" .. ID
    
    ifcfg = db.getRowWhere(ifDev.tableName, query, false)
    if (ifcfg == nil) then
        return status, "IFDEV_ERR_QUERY_FAILED"
    end        

    return "OK", "STATUS_OK", ifcfg
end

-------------------------------------------------------------------------------
-- @name ifDev.cfgByNameGet
--
-- @description  This function gets the interface configuration of the given
-- LogicalIfName/interfaceName/networkName
--
-- @param name LogicalIfName/interfaceName/networkName
--
-- @return status   - OK or ERROR
-- @return errCode   
-- @return cfg      - interface configuration.
--

function ifDev.cfgByNameGet(name)
    local status = "ERROR"
    local errCode = "IFDEV_ERR_INVALID_ARG"
    local query=""

    if (name == nil) then
        return status, errCode        
    end
            
    if (type(name) == "table") then
        if (name["LogicalIfName"] ~= nil) then                
            query = "LogicalIfName='" .. name["LogicalIfName"] .. "'"
        elseif (name["networkName"] ~= nil) then                
            query = "networkName='" .. name["networkName"] .. "'"
        elseif (name["interfaceName"] ~= nil) then                
            query = "interfaceName='" .. name["interfaceName"] .. "'"
        else
            return status, errCode        
        end
    else
        query = " LogicalIfName='" ..  name ..  "' or " .. 
                " networkName='" .. name ..  "' or " .. 
                " interfaceName='" .. name .. "'"
    end            
   
    ifcfg = db.getRowWhere(ifDev.tableName, query, false)
    if (ifcfg == nil) then
        return status, "IFDEV_ERR_QUERY_FAILED"
    end        


    
    return "OK", "STATUS_OK", ifcfg
end

-------------------------------------------------------------------------------
-- @name ifDev.export
--
-- @description  export interface registrations
--
-- @return interface registration table.
--

function ifDev.export ()
    local ifDevConfig = {}
    ifDevConfig.ifTbl = db.getTable("networkInterface", false)
    return ifDevConfig
end

-------------------------------------------------------------------------------
-- @name config.register
--
-- @description register this component with TeamF1 configuration framework.
--
-- @param 
--
-- @return 
--

if (config.register) then
   config.register("ifDev", ifDev.import, ifDev.export, "1")
end

-------------------------------------------------------------------------------
-- @name ifDev.if_up 
--
-- @description This function sets interface state
--
-- @param  ifName  physical interface name
-- @oaram  enable if 1 set else clear
--
-- @return 0 or -1

function ifDev.if_up (ifName, enable)
    result = ifDevLib.flagsChange(ifName, ifDev.flags.IFF_UP , enable)
    return result
end

-------------------------------------------------------------------------------
-- @name ifDev.macValidate
--
-- @description This function validates the mac address
--
-- @param mac   mac address
--
-- @return OK or ERROR
-- @return errCode or STATUS_OK
--

function ifDev.macValidate (mac)
    local status = "ERROR"
    local errCode = "IFDEV_ERR_INVALID_ARG"

    if (mac == nil) then
        return status, errCode
    end
               
    if (ifDevLib.macAddrCheck(mac) == nil) then
        return status, "IFDEV_ERR_INVALID_MAC"
    end       

    return "OK","STATUS_OK"    
end

-------------------------------------------------------------------------------
-- @name ifDev.macGet
--
-- @description This function gets the mac address of the given network
--
-- @param name  network name
--
-- @return OK or ERROR
-- @return errCode or STATUS_OK
-- @return mac address
--

function ifDev.macGet (name)
    local status = "ERROR"
    local errCode = "IFDEV_ERR_INVALID_ARG"

    if (name == nil) then
        return status, errCode
    end

    local ifname = db.getAttribute(ifDev.tableName, ifDev.prop.networkName, 
                                   name, ifDev.prop.interfaceName)

    local mac = ifDevLib.getMac(ifname)           
    if (mac == nil) then
        return status, "IFDEV_ERR_IF_NOT_FOUND"        
    end        

    return  "OK","STATUS_OK", mac
end    

-------------------------------------------------------------------------------
-- @name ifDev.modeValidate
--
-- @description This function validates the network mode. The network mode has
-- the following format:
--
--    <mode>:<networkName>
--
-- Here mode is "ROUTED" or "BRIDGED" or "SWITCHED"
-- networkName is the name of the network to which this network is ROUTED or BRIDGED.
-- Currently assoication with only one network is allowed.
--
-- @param mode connection mode with other networks
--
-- @return status
-- @return errCode

function ifDev.modeValidate (mode)
    local status =  "ERROR"
    local errCode = "NET_ERR_INVALID_MODE"

    if (mode == nil) then
        return status, errCode            
    end

    if (string.len(mode) == 0) then
        return "OK", "STATUS_OK"        
    end
            
    netTbl = util.split(mode, ",")
    if (netTbl == nil) then
        return status, errCode        
    end        
            
    local count = 1            
    for k,v in pairs(netTbl) do
        local kv = util.split(v, ":")

        if (count > 1) then
            return "ERROR","NET_ERR_INVALID_MODE"
        end            

        -- check if mode is valid
        if ((platformLib.strcasecmp(kv[1], "ROUTED") ~= 0) and
            (platformLib.strcasecmp(kv[1], "SWITCHED") ~= 0) and
            (platformLib.strcasecmp(kv[1], "BRIDGED") ~= 0)) then
            return "ERROR","NET_ERR_INVALID_MODE"
        end            

        -- check if network is configured.
        if (ifDev.cfgByNameGet(kv[2]) ~= "OK") then
            return "ERROR","NET_ERR_INVALID_NETWORK"
        end            

        count =  count + 1
    end                    

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name ifDev.modeGet
--
-- @description This function gets the mode with which this interface is
-- connected to the rest of the sytstem.( eg: ROUTED, SWITCHED, BRIDGED)
--
-- @param mode
--
-- @return bridged network name or nil
--

function ifDev.modeGet (connType)
    local errCode = "NET_ERR_INVALID_MODE"
    local mode = {}
    local index = 1

    if (connType == nil) then
        return  nil
    end

    if (string.len(connType) == 0) then
        return nil
    end
            
    netTbl = util.split(connType, ",")
    if (netTbl == nil) then
        return nil, errCode        
    end        
            
    for k,v in pairs(netTbl) do
        local kv = util.split(v, ":")
        if (kv ~= nil) then
            if (kv[1] ~= nil) then
              mode[index] = {}
              if (platformLib.strcasecmp(kv[1], "ROUTED") == 0) then
                    mode[index]["mode"] = ifDev.mode.IFDEV_MODE_ROUTED
                elseif (platformLib.strcasecmp(kv[1], "SWITCHED") == 0) then
                    mode[index]["mode"] = ifDev.mode.IFDEV_MODE_SWITCHED
                elseif (platformLib.strcasecmp(kv[1], "BRIDGED") == 0) then
                    mode[index]["mode"] = ifDev.mode.IFDEV_MODE_BRIDGED
                end
            end
                            
            if (kv[2] ~= nil) then                            
                mode[index]["networkName"] = kv[2]
            end
        end           
        index = index + 1
    end                    

    return mode
end

-------------------------------------------------------------------------------
-- @name ifDev.modeStrGet
--
-- @description This function gets the connection type string from the mode
-- information ( eg: ROUTED:IF1,SWITCHED:IF2,BRIDGED:IF3)
--
-- @param mode
--
-- @return connType
--

function ifDev.modeStrGet (mode)
    local status =  "ERROR"
    local errCode = "NET_ERR_INVALID_MODE"
    local connectionType = nil
    local modeType

    if (mode == nil) then
        return status,errCode
    end

    for index, value in pairs (mode) do
        if (value["networkName"] == nil) then
            return "ERROR", "NET_ERR_NETWORK_NAME"
        end
        
        if (value["mode"] == nil) then
            return "ERROR", "NET_ERR_NETWORK_MODE"
        end

        if (tonumber(value["mode"]) == ifDev.mode.IFDEV_MODE_ROUTED) then
            modeType = "ROUTED"
        elseif (tonumber(value["mode"]) == ifDev.mode.IFDEV_MODE_BRIDGED) then
            modeType = "BRIDGED"
        elseif (tonumber(value["mode"]) == ifDev.mode.IFDEV_MODE_SWITCHED) then
            modeType = "SWITCHED"
        else
            return "ERROR", "NET_ERR_NETWORK_MODE"
        end
     
        if (connectionType ~= nil) then
            connectionType = connectionType .. "," .. modeType ..":".. value["networkName"]
        else
            connectionType = modeType ..":".. value["networkName"]
        end
    end

    return "OK","STATUS_OK", connectionType
end

-------------------------------------------------------------------------------
-- @name ifDev.modeDelete
--
-- @description This function deletes the given network from the mode string.
--
-- @param mode
--
-- @return bridged network name or nil
--

function ifDev.modeDelete (connType, network)
    local status =  "ERROR"
    local errCode = "NET_ERR_INVALID_MODE"
    local mode = {}
    local index = 1

    if (connType == nil) then
        return  nil
    end

    if (string.len(connType) == 0) then
        return nil
    end
            
    netTbl = util.split(connType, ",")
    if (netTbl == nil) then
        return status, errCode        
    end        
            
    for k,v in pairs(netTbl) do
        local kv = util.split(v, ":")
        if (kv ~= nil) then
            if (kv[2] ~= nil) then
              if (platformLib.strcasecmp(kv[2], network) ~= 0) then
                    mode[index] = {}
                    mode[index]["mode"] = kv[1]
                    mode[index]["networkName"] = kv[2]
                end
            end
        end           
        index = index + 1
    end                    

    status, errCode, connType = ifDev.modeStrGet (mode)
    if (status ~= "OK") then
        return nil        
    end        

    return connType
end

-------------------------------------------------------------------------------
-- @name ifDev.isAVLAN
--
-- @description This function check(s) if the interface is a VLAN
--
-- @param netIf network interface name or the interface record
--
-- @return 1 if it is a network bridge or else 0
-- @return interface record
--

function ifDev.isAVLAN(netIf)
    return ifDev.isAType(netIf, "vlan")
end

-------------------------------------------------------------------------------
-- @name ifDev.isANetworkBridge
--
-- @description This function check(s) if the interface is a network bridge
--
-- @param netIf network interface name or the interface record
--
-- @return 1 if it is a network bridge or else 0
-- @return interface record
--

function ifDev.isANetworkBridge(netIf)
    return ifDev.isAType(netIf, "bridge")
end


--[[
*********************************************************************************
-- @name ifDev.isAType
--
-- @description This function check(s) if the interface is a network bridge
--
-- @param netIf network interface name or the interface record
--
-- @return 1 if it is a network bridge or else 0
-- @return interface record
--
--]]

function ifDev.isAType(netIf, ifType)
    local result = 0
    local query =  nil
    local ifRecord = nil

    if ((netIf == nil) or (ifType == nil)) then
        return result
    end        

    if (type(netIf) == "table") then
        if (netIf.ifType ~= nil) then
            if (platformLib.strcasecmp(netIf.ifType, ifType) == 0) then
                result = 1
            else
                result = 0
            end                
        else
            if (netIf["LogicalIfName"] ~= nil) then                
                query = "LogicalIfName='" .. netIf["LogicalIfName"] .. "'"
            elseif (netIf["networkName"] ~= nil) then                
                query = "networkName='" .. netIf["networkName"] .. "'"
            elseif (netIf["interfaceName"] ~= nil) then
                query = "interfaceName='" .. netIf["interfaceName"] .. "'"
            else
               return -1
            end
                                            
            ifRecord = db.getRowWhere(ifDev.tableName, query, false) 
            if (ifRecord == nil) then
                return -1
            else
                if (platformLib.strcasecmp(ifRecord.ifType, ifType) == 0) then
                    result = 1
                else
                    result = 0
                end                
            end                
        end                        
    else
        query = "interfaceName='" .. netIf ..  "' or  " ..
                "LogicalIfName='" .. netIf ..  "' or  " ..
                "networkName='" .. netIf .. "'"
        ifRecord = db.getRowWhere(ifDev.tableName, query, false) 
        if (ifRecord == nil) then
            return -1
        else
            if (platformLib.strcasecmp(ifRecord.ifType, ifType) == 0) then
                result = 1
            else
                result = 0
            end                
        end                
    end

    return result, ifRecord
end

--
--
--
--  LOCAL FUNCTIONS
--
--

--[[
*******************************************************************************
-- @name ifDev.dbConfig -
--
-- @description 
--
-- @param 
--
-- @return 
--]]

function ifDev.dbConfig (tableName, cfg, rowid, operation)
    
    local valid = false

	-- validate
	if (operation == "add") then
		valid, errstr, rowid = db.insert(tableName, cfg, rowid)
	elseif (operation == "edit") then
		valid, errstr  = db.update(tableName, cfg, rowid)
	elseif (operation == "delete") then
		valid, errstr = db.delete(tableName, cfg)
	end

    -- return
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "IFDEV_CONFIG_FAILED", errstr
    end
end

--[[
*******************************************************************************
-- @name ifDev.nameValidate
--
-- @description This function validates the network name
--
-- @param  name network name
--
-- @return OK or ERROR
-- @return errCode or STATUS_OK
--]]

function ifDev.nameValidate(name)
    local status = "ERROR"
    local errCode = "IFDEV_ERR_INVALID_ARG"

    if (name == nil) then
        return status, errCode
    end        

    if (string.len(name) >= ifDev.IFDEV_NET_NAMESZ) then
        return status, "IFDEV_ERR_INVALID_NETWORK_NAME"        
    end        
                
    return "OK","STATUS_OK"
end

--[[
*******************************************************************************
-- @name ifDev.IDValidate
--
-- @description This function validates the network ID
--
-- @param ID    network ID
--
-- @return OK or ERROR
-- @return errCode or STATUS_OK
--]]

function ifDev.IDValidate(ID)
    return "OK","STATUS_OK"
end

--[[
*******************************************************************************
-- @name ifDev.ifgroupValidate - validates group membership
--
-- @description This function validates the group membership information
--
-- @param mark      network name
-- @param groupID   groupID
--
-- @return OK or ERROR
-- @return errCode or STATUS_OK
--]]

function ifDev.ifgroupValidate(name, groupID)
    local status = "ERROR"
    local errCode = "IFDEV_ERR_INVALID_ARG"

    if (groupID == nil) then
        return status, errCode
    end        

    return "OK","STATUS_OK"
end

--[[
*******************************************************************************
-- @name ifDev.ifMarkValidate - validate interface mark
--
-- @description This function validates the interface mark. 
--
-- @param name  network name
-- @param mark  interface mark
--
-- @return OK or ERROR
-- @return errCode or STATUS_OK
--]]

function ifDev.ifMarkValidate(name, mark)
    local status = "ERROR"
    local errCode = "IFDEV_ERR_INVALID_ARG"

    if (mark == nil) then
        return status, errCode
    end        

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name ifDev.zoneValidate
--
-- @description The function validates the network zone
--
-- @param zone network zone
--
-- @return OK or ERROR
-- @return errCode or STATUS_OK
--
function ifDev.zoneValidate (zone)

    if (zone == nil) then
        return "ERROR"
    end
            
    if (platformLib.strcasecmp(zone, "LAN") == 0) then
        return "OK"
    elseif (platformLib.strcasecmp(zone, "WAN") == 0) then
        return "OK"
    elseif (platformLib.strcasecmp(zone, "DMZ") == 0) then
        return "OK"
    elseif (platformLib.strcasecmp(zone, "SECURE") == 0) then
        return "OK"
    elseif (platformLib.strcasecmp(zone, "INSECURE") == 0) then
        return "OK"
    elseif (platformLib.strcasecmp(zone, "PUBLIC") == 0) then
        return "OK"
    elseif (platformLib.strcasecmp(zone, "BRIDGE") == 0) then
        return "OK"
    end        
                    
    return "ERROR"
end

--[[
*******************************************************************************
-- @name ifDev.lNameGen - generate a logical interface name.
--
-- @description This function generates a logical interface name.
--
-- @return OK or ERROR
-- @return errCode or STATUS_OK
--]]

function ifDev.lNameGen()
    local ifTbl = {}
    local index = 0
    local found
    local suffix
    local lname

    ifTbl = db.getTable(ifDev.tableName, false)
    for kk,vv in pairs(ifTbl) do
        found = 0
        index = string.gsub(vv[ifDev.prop.LogicalIfName], "IF", "")
        index = index + 1
        for k,v in pairs(ifTbl) do
            suffix = string.gsub(v[ifDev.prop.LogicalIfName], "IF", "")
            if (tonumber(suffix) == tonumber(index)) then
                found  = 1
            end            
        end

        if (found == 0) then
            lname = "IF" .. index
        end 
    end

    return lname
end

--[[
*******************************************************************************
-- @name ifDev.ifTypeValidate - validate interface type
--
-- @description This function validates the interface type
--
-- @return OK or ERROR
-- @return errCode or STATUS_OK
--]]

function ifDev.ifTypeValidate(ifType)

    if (ifType == nil) then
        return "ERROR"
    end        

    if (platformLib.strcasecmp(ifType, "vlan") == 0) then
        return "OK"
    elseif (platformLib.strcasecmp(ifType, "radio") == 0) then
        return "OK"
    elseif (platformLib.strcasecmp(ifType, "switch") == 0) then
        return "OK"
    elseif (platformLib.strcasecmp(ifType, "ethernet") == 0) then
        return "OK"
    elseif (platformLib.strcasecmp(ifType, "bridge") == 0) then
        return "OK"
    elseif (platformLib.strcasecmp(ifType, "vap") == 0) then
        return "OK"
    end        

    return "ERROR"
end

--[[
*******************************************************************************
-- @name ifDev.CheckIfExists - check if the interface exists
--
-- @description This function checks if the interface exists in the system
--
-- @return OK or ERROR
-- @return errCode or STATUS_OK
--]]

function ifDev.CheckIfExists(ifname)
    local status = "ERROR"
    local errCode = "IFDEV_ERR_INVALID_ARG"

    if (ifname == nil) then
        return status, errCode        
    end
            
    local valid = ifDevLib.getMac(ifname)           
    if (valid == nil) then
        return status, "IFDEV_ERR_IF_NOT_FOUND"        
    end        

    return "OK","STATUS_OK"
end

--[[
*******************************************************************************
-- @name ifDev.dprintf - 
--
-- @description 
--
-- @return
--]]

function ifDev.dprintf(str)
    if (str == nil) then
        return
    end        

    local blob = "IFDEV:" .. str .. " <br>"

    if (tonumber(ifDev.debug) == 1) then
        print(blob)
    end        

    if ((gui ~= nil) and (gui.debug == 1)) then
        util.appendDebugOut(blob)
    end        

    return    
end

--[[
*******************************************************************************
-- @name ifDev.cfgByQueryGet 
--
-- @description The function gets the configuration of the interface that is 
-- stored in the database
--
-- @param  query  custom database query or nil to get full table
--
-- @return  status, errCode
--]]

function ifDev.cfgByQueryGet (query)
    local records = {}

    if (query == nil) then
        records = db.getTable(ifDev.tableName, false)
    else
        records = db.getRowsWhere(ifDev.tableName, query, false)
    end
            
    if (records == nil) then
        return "ERROR", "IFDEV_ERR_QUERY_FAILED"
    end        

    return "OK", "STATUS_OK", records
end



--[[
--*****************************************************************************
-- ifDev.validateAddrInNetwork - validate if an address is in the network 
-- 
-- This function validates if the address belongs to the subnet/network of any
-- of the adrresses configured on the specified interface
--
-- RETURN: 
-- -3 other errors
-- -2 invalid addresss
-- -1 no address configured on the interface
--  0 address does not belong to the same network
--  1 if the address belongs to same subnet/network 
]]--

function ifDev.validateAddrInNetwork (addr, ifname)
	local ipRows = {}
	local family = ifDevLib.addrFamilyGet(addr)
    local where = "LogicalIfName = '" .. ifname .. "' and addressFamily=" .. family 

	-- get all the addresses that belong to the 
	-- specified interface
	ipRows = db.getRowsWhere("ipAddressTable", where, false)
	if (ipRows == nil) then
		return -1
	end

	for k,v in pairs(ipRows) do 
		if (family == 2) then
			
			if (ifDevLib.subnetCompare(addr, v["ipAddress"], v["subnetMask"]) == 1) then
				return 1
			end
		else
			-- get the network prefix of the address on the interface
			addr1 = ifDevLib.prefixGet(v["ipAddress"], v["ipv6PrefixLen"])
			if (addr1 == nil) then
				return -3
			end

			-- get the network prefix of the given address
			addr2 = ifDevLib.prefixGet(addr, v["ipv6PrefixLen"])
			if (addr2 == nil) then
				return -2
			end
		
			-- check if both the prefixes are equal
			if (ifDevLib.prefixCompare(addr1, addr2) == 1) then
				return 1
			end
		end
	end

	return 0
end

--****************************************************************************
--@name ifDev.wiredStatsGet()
--
--@description The function gets the port statics 
--table
--
--@return

function ifDev.wiredStatsGet()

    -- include
    require "swMgrLib"
   
    -- locals
    local statsTbl = {}
    local localTbl = {}
    local portTbl = {}
    local page = {}
    local value = {}
    local itera = {1,2,3,4,5}
    
    -- getting the physical port statistics
    for i,v in pairs (itera) do
        value[i], portTbl[i] = swMgrLib.statsGet(itera[i])
    end
    
    if (portTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN", localTbl
    end

    page.statsTbl = {}

    -- matching of the fields as required after checking the value = 0
    for i,v in pairs (portTbl) do
        page.statsTbl[i] = {}
        if (value[i] == 0) then
            page.statsTbl[i]["rx_MulicastPackets"]    = v.rxMulticastPackets
            page.statsTbl[i]["rx_UnicastPackets"]     = v.rxUnicastPackets
            page.statsTbl[i]["rx_DroppedPackets"]     = v.rxDroppedPackets
            page.statsTbl[i]["rx_BroadcastPackets"]   = v.rxBroadcastPackets
            page.statsTbl[i]["tx_MulicastPackets"]    = v.txMulticastPackets
            page.statsTbl[i]["tx_UnicastPackets"]     = v.txUnicastPackets
            page.statsTbl[i]["tx_DroppedPackets"]     = v.txDroppedPackets
            page.statsTbl[i]["tx_BroadcastPackets"]   = v.txBroadcastPackets
            page.statsTbl[i]["rxBytes"]               = v.rxBytes
            page.statsTbl[i]["txBytes"]               = v.txBytes
        end
    end
    page.statsTbl[5]["interface"] = "LAN4"
    page.statsTbl[4]["interface"] = "LAN3"
    page.statsTbl[3]["interface"] = "LAN2"
    page.statsTbl[2]["interface"] = "LAN1"
    page.statsTbl[1]["interface"] = "WAN"

    local err = "OK"
    local status = ""

    -- return
    return err, status, page

end 

--******************************************************************************
--@name ifDev.wifiStatsGet()
--
--@description The function gets the wireless statics
--table
--
--@return

function ifDev.wifiStatsGet()

    -- locals
    local vapTbl = {}
    local localTbl = {}
    local page = {}
	local j = 1
	local k = 1

    -- getting the statistics for all vap interfaces in use
	local wifiInterfaceRows = db.getTable ("dot11Interface")
	for k,v in pairs (wifiInterfaceRows) do
		if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED"))then
			if(v["dot11Interface.interfaceName"] ~= "wl1.1")then 
				if (v["dot11Interface.vapName"] ~= "unused") then
					vapTbl[j] = ifDevLib.interfaceStatsGet(v["dot11Interface.interfaceName"])
					vapTbl[j]["vapName"] = v["dot11Interface.vapName"]
					if (vapTbl[j] == nil) then
						return "ERROR", "DB_ERROR_TRY_AGAIN", localTbl
					end
				end
				j = j + 1
			end
		else
			if (v["dot11Interface.vapName"] ~= "unused") then
				vapTbl[j] = ifDevLib.interfaceStatsGet(v["dot11Interface.interfaceName"])
				vapTbl[j]["vapName"] = v["dot11Interface.vapName"]
				if (vapTbl[j] == nil) then
					return "ERROR", "DB_ERROR_TRY_AGAIN", localTbl
				end
			end
			j = j + 1

		end
	end

    page.statsTbl = {}
    for i,v in pairs (vapTbl) do
    
    if((not(util.fileExists ("/pfrm2.0/DEVICE_REPEATER"))) or util.fileExists("/flash/JMA24_CAP_MODE")) then
        page.statsTbl[i] = {}
        page.statsTbl[i].interface = vapTbl[i].vapName
        page.statsTbl[i].rx_packets = vapTbl[i].rx_packets
        page.statsTbl[i].rx_errors = vapTbl[i].rx_errors
        page.statsTbl[i].rx_dropped = vapTbl[i].rx_dropped
        page.statsTbl[i].tx_packets = vapTbl[i].tx_packets
        page.statsTbl[i].tx_errors = vapTbl[i].tx_errors
        page.statsTbl[i].tx_dropped = vapTbl[i].tx_dropped
        page.statsTbl[i].rx_bytes = vapTbl[i].rx_bytes
        page.statsTbl[i].tx_bytes = vapTbl[i].tx_bytes
        page.statsTbl[i].multicast = vapTbl[i].multicast
    else
        if((util.fileExists("/flash/JMA24_AGENT_MODE")) and (v["vapName"] == "ap1" or v["vapName"] == "ap4")) then
        page.statsTbl[k] = {}
        page.statsTbl[k].interface = vapTbl[i].vapName
        page.statsTbl[k].rx_packets = vapTbl[i].rx_packets
        page.statsTbl[k].rx_errors = vapTbl[i].rx_errors
        page.statsTbl[k].rx_dropped = vapTbl[i].rx_dropped
        page.statsTbl[k].tx_packets = vapTbl[i].tx_packets
        page.statsTbl[k].tx_errors = vapTbl[i].tx_errors
        page.statsTbl[k].tx_dropped = vapTbl[i].tx_dropped
        page.statsTbl[k].rx_bytes = vapTbl[i].rx_bytes
        page.statsTbl[k].tx_bytes = vapTbl[i].tx_bytes
        page.statsTbl[k].multicast = vapTbl[i].multicast
        k=k+1
        end
    end
    end
    local err = "OK"
    local status = ""

    -- return 
    return  err, status, page   

end

--******************************************************************************
--@name ifDev.networkStatsGet()
--
--@description The function gets statics of all the networks
--
--@return

function ifDev.networkStatsGet()

    -- locals
    local netStatsTbl = {}
    local localTbl = {}
    local netwrkInterfaceTbl = {}
    local networkInfo = {}
    local page = {}
    
    -- getting the networkInterface table
    netwrkInterfaceTbl = db.getTable("networkInterface", false)
    if (netwrkInterfaceTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN", localTbl
    end
    
    -- getting the statistics of all the networks configured
    for i,v in pairs (netwrkInterfaceTbl) do
        if (v["LogicalIfName"] == "IF1" or v["LogicalIfName"] == "IF2") then
            networkInfo[i] = ifDevLib.netIfInfoGet(v.LogicalIfName)
        end
    end    
    
    if (networkInfo == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN", localTbl
    end
    

    -- returning it in the manner as gui required
    
    page.statsTbl = {}
    for i,v in pairs (networkInfo) do
        page.statsTbl[i] = {}
        page.statsTbl[i].interface = networkInfo[i].networkName
        page.statsTbl[i].rx_packets = networkInfo[i].rx_packets
        page.statsTbl[i].rx_errors = networkInfo[i].rx_errors
        page.statsTbl[i].rx_dropped = networkInfo[i].rx_dropped
        page.statsTbl[i].tx_packets = networkInfo[i].tx_packets
        page.statsTbl[i].tx_errors = networkInfo[i].tx_errors
        page.statsTbl[i].tx_dropped = networkInfo[i].tx_dropped
        page.statsTbl[i].rx_bytes = networkInfo[i].rx_bytes
        page.statsTbl[i].tx_bytes = networkInfo[i].tx_bytes
        page.statsTbl[i].multicast = networkInfo[i].multicast
    end
      
    local err = "OK"
    local status = ""

    -- return 
    return err, status, page
end

--******************************************************************************
--@name ifDev.userGrpIdGet
--
--@description The function gets groupId of this network
--
--@return

function ifDev.userGrpIdGet (LogicalIfName)
    local usrGrpId = 0

    if (LogicalIfName == nil) then
        return 0
    end
            
    local status, errCode, cfg = ifDev.cfgByNameGet(LogicalIfName)
    if (status ~= "OK") then
        ifDev.dprintf("ifDev.userGrpIdGet: failed to get configuration for " .. LogicalIfName)
        return 0
    end        

    if ((cfg["ifMark"] ~= nil) and (string.len(cfg["ifMark"]) > 0)) then
       usrGrpId = tonumber(cfg["ifMark"]) + 4000
    end

    return usrGrpId
end

