--[[ easyMeshDeviceRename.lua - Handler for renaming Easy Mesh devices.
--
-- Copyright (c) 2008-2014, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: easyMeshDeviceRename.lua
-- Description: Handler for renaming Easy Mesh devices.
-- 
-- modification history
-- --------------------
-- 01a, 07Jan20, ar written.
--
--]]

require "teamf1lualib/ifDev"
require "teamf1lualib/dot11_ul"

-- Rename Request Object as defined by Customer Specification.
local RenameRequestObj = {
    ["Device_NickName"]      = "Device_NickName",
    ["Device_Type"]  = "Device_Type",
    ["Device_MAC"]  = "Device_MAC"
}

-- Initialise the RenameRespose_t Lua Table which will be coverted as JSON Object
local RenameResponse_t = {
    ["Result"] = "ERROR",
    ["Device_MAC"] = nil,
    ["Response_Code"] = "400",
    ["Error_Message"] = "Failed to Rename Device"
}

-- Supported Return Codes for "LoginResponse"
local RenameResponse_ReturnCodes = {
    ["OK"] = "OK",
    ["ERROR"] = "ERROR",
    ["SUCCESS"] = "Success",
    ["FAILED"]  = "Failed",
}

function deviceNameCheck(deviceName)
   
    local MinLength = "1"
    local MaxLength = "32"

    if (deviceName == nil) then
        return "ERROR", "INVALID_NAME"
    end
    
    if (db.sqlInjectionCheck(deviceName)) then
        return "ERROR", "INVALID_NAME"
    end

    -- Verify that device name is not set to restricted names
    local lowerName = string.lower(deviceName)
    -- set restricted name always in lower
    local restrictedNameList = {'jiocentrum'}
    for _, restrictedName in pairs(restrictedNameList) do
        if (string.match (lowerName, restrictedName)) then
	    return "ERROR", "DEVICENAME_NOT_ALLOWED"
        end
    end

    local status = LengthCheck(MinLength,MaxLength,deviceName,"deviceName")
    if(status == "ERROR") then
        return "ERROR","Device_Nickname should be 1-32 characters"
    end

   
    return "OK", "VALID_NAME"
end

----------------------------------------------------------------------------------
-- @name renameEasyMeshDeviceHandler
--
-- @description This function Handles EasyMesh Rename Request Method.
--
-- @return JSON responses to EasyMesh Rename requests
--
function renameEasyMeshDeviceHandler(methodObj, meshRequestMethod)

	local deviceName = methodObj["Device_NickName"]
	local deviceType = methodObj["Device_Type"]
	local deviceMac = methodObj["Device_MAC"]
	local valid = false

	if ((deviceName == nil) or (deviceType == nil) or (deviceMac == nil) or 
	    ((deviceType ~= "CAP") and (deviceType ~= "RE") and (deviceType ~= "Client") and (deviceType ~= "LAN")) or 
	    (ifDev.macValidate(deviceMac) ~= "OK") ) then
	    RenameResponse_t["Result"] = RenameResponse_ReturnCodes["FAILED"]
	    RenameResponse_t["Response_Code"] = "400"
	    RenameResponse_t["Error_Message"] = "Bad Request"
	    --mesh.sendResponse (RenameResponse_t) 
	    return "ERROR", "INVALID_METHOD", RenameResponse_t
	end
	
	if (deviceNameCheck(deviceName) ~= "OK") then
	    RenameResponse_t["Result"] = RenameResponse_ReturnCodes["FAILED"]
	    RenameResponse_t["Response_Code"] = "400"
	    RenameResponse_t["Error_Message"] = "Invalid Name"
	    --mesh.sendResponse (RenameResponse_t) 
	    return "ERROR", "INVALID_NAME", RenameResponse_t
	end


	db.beginTransaction() --begin transaction
	
	local currDeviceName
	currDeviceName = db.getAttribute("easyMeshDevices", "macAddr", string.upper(deviceMac), "deviceName")
	if (currDeviceName ~= nil) then
	    valid = db.setAttribute("easyMeshDevices","macAddr",string.upper(deviceMac), "deviceName", deviceName)
	else
	    local deviceTbl = {}
	    deviceTbl["easyMeshDevices"] = {}
	    deviceTbl["easyMeshDevices.macAddr"] = string.upper(deviceMac)
	    deviceTbl["easyMeshDevices.deviceName"] = deviceName
	    valid = db.insert("easyMeshDevices", deviceTbl)
	end
	
	if (valid) then
	    db.commitTransaction(true)
            db.save2()
	    RenameResponse_t["Result"] = RenameResponse_ReturnCodes["OK"]
	    RenameResponse_t["Response_Code"] = "200"
	    RenameResponse_t["Device_MAC"] = deviceMac
	    RenameResponse_t["Error_Message"] = nil
	    --mesh.sendResponse (RenameResponse_t) 
            return "OK", "STATUS_OK", RenameResponse_t
	else
            db.rollback()
	    RenameResponse_t["Result"] = RenameResponse_ReturnCodes["FAILED"]
	    RenameResponse_t["Response_Code"] = "400"
	    RenameResponse_t["Error_Message"] = "Database Error"
	    --mesh.sendResponse (RenameResponse_t) 
            return "ERROR", "OPERATION_FAILED", RenameResponse_t
	end
end

meshRequestMethodsList["Rename"]["methodHandler"] = renameEasyMeshDeviceHandler
