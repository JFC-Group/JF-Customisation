-- diskMgmt.lua
-- Copyright (c) 2010 TeamF1, Inc.
-- All rights reserved. 
--
-- Modification History
-- --------------------
-- 01e,22nov12,bng  added nil check for reading the file in 'r' format
-- 01d,20jan11,bng  added check disk implementation for ext2 and ext3 format
-- 01c,09arp10,pnm  updated remove disk to remove disk info.
-- 01b,31mar10,pnm  fixed a typo
-- 01a,25mar10,pnm  written
--
-- Description
-- Disk management component core routines and API
--

--********************** Requires **************************
require "diskMgmtLib"
require "teamf1lualib/util"

--********************** Packages ***************************
diskMgmt = {}

diskMgmt.PartitionRecognitionEnum = {
   RECOGNIZED = 1,
   HIDDEN = 2, 
}

diskMgmt.FsTypeEnum = {
   INVALID = 0,	
   EXT2 = 1,
   EXT3 = 2,
   FAT16 = 3,
   FAT32 = 4,
   MSDOS = 5,
   VFAT = 6,
   NTFS = 7,
   HFSPLUS = 8,
   HFSX = 9,
   EXFAT = 10,
}

diskMgmt.PartitionPermEnum = {
   INVALID = 0,	
   READ_ONLY = 1,
   READ_WRITE = 2,
}

function diskMgmt.permTypeGet(fsType)

	if (fsType == nil) then
		return diskMgmt.PartitionPermEnum.INVALID
	end

	if (fsType == diskMgmt.FsTypeEnum.HFSPLUS) then
		return diskMgmt.PartitionPermEnum.READ_ONLY
	elseif (fsType == diskMgmt.FsTypeEnum.HFSX) then
		return diskMgmt.PartitionPermEnum.READ_ONLY
	elseif (fsType == diskMgmt.FsTypeEnum.NTFS) then
		return diskMgmt.PartitionPermEnum.READ_ONLY
	else
		return diskMgmt.PartitionPermEnum.READ_WRITE
	end
end

function diskMgmt.fsStrGet(fsType)

	if (fsType == nil) then
		return ""
    end        

    fsType = tonumber(fsType)

	if (fsType == diskMgmt.FsTypeEnum.EXT2) then
		return "ext2"
	elseif (fsType == diskMgmt.FsTypeEnum.EXT3) then
		return "ext3"
	elseif (fsType == diskMgmt.FsTypeEnum.FAT16) then
		return "fat16"
	elseif (fsType == diskMgmt.FsTypeEnum.FAT32) then
		return "fat32"
	elseif (fsType == diskMgmt.FsTypeEnum.MSDOS) then
		return "msdos"
	elseif (fsType == diskMgmt.FsTypeEnum.VFAT) then
		return "vfat"
	elseif (fsType == diskMgmt.FsTypeEnum.EXFAT) then
		return "exfat"
	elseif (fsType == diskMgmt.FsTypeEnum.NTFS) then
		return "ntfs"
	elseif (fsType == diskMgmt.FsTypeEnum.HFSPLUS) then
		return "hfs+"
	elseif (fsType == diskMgmt.FsTypeEnum.HFSX) then
		return "hfsx"
	elseif (fsType == diskMgmt.FsTypeEnum.HFSPLUS) then
		return "hfsplus"
	else
		return "unknown"
	end

	return "unknown"
end

function diskMgmt.fsTypeEnumGet(fsType)
	if (fsType == nil) then
		return diskMgmt.FsTypeEnum.INVALID
	elseif (fsType == "ext2") then
		return diskMgmt.FsTypeEnum.EXT2
	elseif (fsType == "ext3") then
		return diskMgmt.FsTypeEnum.EXT3
	elseif (fsType == "fat16") then
		return diskMgmt.FsTypeEnum.FAT16
	elseif (fsType == "fat32") then
		return diskMgmt.FsTypeEnum.FAT32
	elseif (fsType == "msdos") then
		return diskMgmt.FsTypeEnum.MSDOS
	elseif (fsType == "vfat") then
		return diskMgmt.FsTypeEnum.VFAT
	elseif (fsType == "exfat") then
		return diskMgmt.FsTypeEnum.EXFAT
	elseif (fsType == "ntfs") then
		return diskMgmt.FsTypeEnum.NTFS
	elseif (fsType == "hfs+") then
		return diskMgmt.FsTypeEnum.HFSPLUS
	elseif (fsType == "hfsx") then
		return diskMgmt.FsTypeEnum.HFSX
	elseif (fsType == "hfsplus") then
		return diskMgmt.FsTypeEnum.HFSPLUS
	else
		return diskMgmt.FsTypeEnum.INVALID
	end

	return diskMgmt.FsTypeEnum.INVALID
end

--*****************************************************************************
--diskMgmt.getAllDisksInfo - get info about all the disks.
--
--This routine calls appropriate routine to get the disks info. It then checks
--the return code to see if the operation is successful. If the return code is
--not success, it will then call appropriate routine to map the code with
--string.
--
--RETURNS: table with disk info and status and statusStr
function diskMgmt.getAllDiskInfo ()
    local fileName      -- File name which holds the output
    local statusCode    -- status code returned by the function
    local statusStr     -- status string to return 

    -- Check if the DB file name is define
    if (DB_FILE_NAME == nil) then
        --DB_FILE_NAME is defined in the platform.lua. This is required by the
        --system to open the DB. If this is not define, please define it.
        util.appendDebugOut ("getAllDiskInfo: DB_FILE_NAME is nil <br>")
        return "ERROR", "SYSTEM_ERROR", nil
    end

    -- Call the backend routine to get the disk info.
    statusCode, fileName = diskMgmtLib.getAllDisksInfo (DB_FILE_NAME)

    -- Get the table from the file.
    if (statusCode ~= 0) then
        -- convert the error code into meaningful string
        statusStr = diskMgmt.mapCode2Str (statusCode)
        return "ERROR", statusStr, nil
    end

    -- If the status code == 0
    dofile (fileName)
    return "OK", "STATUS_OK", diskAllStat
end

--*****************************************************************************
--diskMgmt.mapCode2Str - maps the code to string
--
--This routine takes the code value and maps it with meaning string.
--
--RETURNS: error string
function diskMgmt.mapCode2Str (statusCode)
    local codeMapTbl = {"DISKMGMT_FAILED_TO_GET_DISK_INFO"}

    -- check if the statusCode provided is within the range in the code map
    -- table.
    local tblSize = #codeMapTbl
    if ((statusCode > tblSize) or (statusCode < 0)) then
        util.appendDebugOut ("DiskMgmt: statusCode passed in is greater than ")
        util.appendDebugOut ("table size code = " .. statusCode .. "<br>")
        statuCode = tblSize
    end

    return codeMapTbl[statusCode]
end

--*****************************************************************************
--diskMgmt.getDiskPartitionInfo - get info about a disk.
--
--This routine calls appropriate routine to get the partition info of a disk
--given the diskId of the disk.
--
--RETURNS: table with disk info and status and statusStr
function diskMgmt.getDiskPartitionInfo (diskId)
    local fileName      -- File name which holds the output
    local statusCode    -- status code returned by the function
    local statusStr     -- status string to return 

    --Verify that the partition disk id is not nil
    if (diskId == nil) then
        return "ERROR", "DISKMGMT_DISK_ID_NIL",nil
    end

    -- Check if the DB file name is define
    if (DB_FILE_NAME == nil) then
        --DB_FILE_NAME is defined in the platform.lua. This is required by the
        --system to open the DB. If this is not define, please define it.
        util.appendDebugOut ("getDiskPartitionInfo: DB_FILE_NAME is nil <br>")
        return "ERROR", "SYSTEM_ERROR", nil
    end

    -- Call the backend routine to get the disk info.
    statusCode, fileName = diskMgmtLib.getDiskPartitionInfo (DB_FILE_NAME,
                                            diskId)

    -- Get the table from the file.
    if (statusCode ~= 0) then
        -- convert the error code into meaningful string
        statusStr = diskMgmt.mapCode2Str (statusCode)
        return "ERROR", statusStr, nil
    end

    -- If the status code == 0
    dofile (fileName)
    local tbl = {}
    tbl.diskStat = diskStat
    tbl.diskPartition = diskPartition

    return "OK", "STATUS_OK", tbl
end
--*****************************************************************************
--diskMgmt.deleteDiskPartitions - deletes disk partitions from DB.
--
--This routine gets list of partitios for given disk and deletes the data from
--DB.
--
--RETURNS: status and status str
function diskMgmt.deleteDiskPartitions (diskId)
    -- Local Variables
    local partTbl = db.getRows ("diskMgmtPartition", "diskId", diskId)
    if (partTbl == nil) then
        return "ERROR", "DISKMGMT_FAILED_TO_DISK_PARTITION_INFO"
    end

    -- iterate through partition list and delete each partition
    local valid = false
    for i,v in ipairs (partTbl) do
        valid = db.deleteRow ("diskMgmtPartition", "partId",
        v["diskMgmtPartition.partId"])
        if (not valid) then
            return "ERROR", "DISKMGMT_FAILED_TO_DELETE_PARTITION_INFO"
        end
    end
    return "OK", "STATUS_OK"
end
--*****************************************************************************
--diskMgmt.removeDisks - removes the disk.
--
--This routine prepares the disk for physical removal of disk.
--
--RETURNS: status and status str
function diskMgmt.removeDisks (tbl)
    -- Check for permission
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- Check if the DB file name is define
    if (DB_FILE_NAME == nil) then
        --DB_FILE_NAME is defined in the platform.lua. This is required by the
        --system to open the DB. If this is not define, please define it.
        util.appendDebugOut ("removeDisks: DB_FILE_NAME is nil <br>")
        return "ERROR", "SYSTEM_ERROR"
    end

    -- start db transaction
    db.beginTransaction() --begin transaction

    local status = "OK"
    local statusStr = "STATUS_OK"
    local statusCode
    -- Iterate through disk list and process one disk at a time.
    for i,v in pairs (tbl) do
        -- Verify the input
        status, statusStr = diskMgmt.removeDiskValidInput (v["diskId"])
        if (status == "ERROR") then
            return status, statusStr
        end

        -- Process the disk
        statusCode = diskMgmtLib.removeDisk (DB_FILE_NAME, v["diskId"])
        if (statusCode ~= 0) then
            status = "ERROR"
            statusStr = "DISKMGMT_FAILED_TO_REMOVE_DISK"
            break
        end

        -- Delete partitions for this disk
        status, statusStr = diskMgmt.deleteDiskPartitions (v["diskId"])
        if (status == "ERROR") then
            break
        end

        -- Remove the disk info from the DB
        statusCode = db.deleteRow ("diskMgmtVolume", "deviceId", v["diskId"])
        if (not statusCode) then
            status = "ERROR"
            statusStr = "DISKMGMT_FAILED_TO_REMOVE_DISK"
            break
        end
    end

    -- commit the changes
    if (status == "ERROR") then
        db.rollback()
    else
        if (util.fileExists ("/pfrm2.0/HW_ALU")) then
            os.execute ("/bin/ledctl USB off")
        end
        db.commitTransaction(true)
    end

    return status, statusStr
end

--*****************************************************************************
--diskMgmt.removeDiskValidInput - validates the input.
--
--This routine will check if the provided disk ID is valid or not.
--
--RETURNS: status and status str
function diskMgmt.removeDiskValidInput (diskId)
    -- Verify that the disk id is not nil
    if (diskId == nil) then
        return "ERROR", "DISKMGMT_DISK_ID_NIL"
    end

    -- Verify that disk ID is valid by checking with database
    if (db.getRow ("diskMgmtVolume", "deviceId", diskId) == nil) then
        return "ERROR", "DISKMGMT_INVALID_DISK_ID"
    end

    return "OK", "STATUS_OK"
end

--*****************************************************************************
--diskMgmt.checkFsTab - check for device entry.
--
--This routine will check if an entry exists in /etc/fstab file for provided
--device details.
--
--RETURNS: status 
function diskMgmt.checkFsTab (row)
    local deviceStr1 = "(.-)" .. row["partId"] .. "(.-)" .. row["mntDir"] .. "(.-)" .. row["partFSFormat"]
    local deviceStr2 = "(.-)" .. row["partId"] 
    local existFlag = 0

    -- open fstab file
    local pFile = io.open ("/etc/fstab", "r")
    if (pFile == nil) then
        return "ERROR"
    end

    local lineNumber = 1
    local lineTmp = 0
    local dataToWrite = ""
    for line in pFile:lines() do
        for data in string.gmatch(line, deviceStr1) do
            existFlag = 1
        end

        if (existFlag == 1) then
            return "OK"
        else
            for data in string.gmatch(line, deviceStr2) do
                lineTmp = lineNumber
            end
            if (lineTmp ~= lineNumber) then
                dataToWrite = dataToWrite .. line .. "\n"
            end
        end
        lineNumber = lineNumber + 1
    end
    io.close (pFile)

    if (existFlag ~= 1) then
        -- open fstab file and update the device entry
        pFile = io.open ("/etc/fstab", "w")
        dataToWrite = dataToWrite .. row["partId"] .. "\t" .. row["mntDir"] .. "\t" .. row["partFSFormat"] .. "\t" .. "defaults" .. "\t" .. "0 0" .. "\n"
        pFile:write (dataToWrite)
        io.close (pFile) 
    end
    return "OK"
end

--*****************************************************************************
--diskMgmt.unMountDisk - unmount partition.
--
--This routine will do umount on parition provided .
--
--RETURNS: NA 
function diskMgmt.unMountDisk (partitionId)
    local cmd = "umount " .. partitionId
    local maxusers = db.getAttribute("environment", "name", "MAX_USERS", "value");
    local count = 0

    maxusers = tonumber(maxusers)
    while (count < maxusers) do

        status = os.execute (cmd)
        if (status ~= 0) then
            return;
        end        

        count = count + 1
    end

end

--*****************************************************************************
--diskMgmt.mountDisk - mount partition.
--
--This routine will mount parition provided .
--
--RETURNS: NA 
function diskMgmt.mountDisk (row)
   local cmd = "mount " .. row["partId"] .. " " .. row["mntDir"]
   os.execute (cmd)

end
--*****************************************************************************
--diskMgmt.checkExt2Partition - check disk on ext2 file format.
--
--This routine will run fsck.ext2 binary.
--
--RETURNS: status and status str
function diskMgmt.checkExt2Partition (partitionId)
    local cmd = "fsck -y -t ext2 " .. partitionId .. " > /dev/null"
    os.execute (cmd)
    return "OK", "DISKMGMT_CHECKDISK_SUCCESS"
end

--*****************************************************************************
--diskMgmt.checkExt3Partition - check disk on ext3 file format
--
--This routine will run fsck.ext3 binary.
--
--RETURNS: status and status str
function diskMgmt.checkExt3Partition (partitionId)
    local cmd = "fsck -y -t ext3 " .. partitionId .. " > /dev/null"
    os.execute (cmd)
    return "OK", "DISKMGMT_CHECKDISK_SUCCESS"
end

--*****************************************************************************
--diskMgmt.checkExt4Partition - check disk on ext4 file format.
--
--This routine will run fsck.ext4 binary.
--
--RETURNS: status and status str
function diskMgmt.checkExt4Partition (partitionId)
    return "ERROR", "EXT4_FILE_TYPE_NOT_SUPPORTED"
end

--*****************************************************************************
--diskMgmt.checkNtfsPartition - check disk on ntfs file format.
--
--This routine will run fsck.ntfs binary.
--
--RETURNS: status and status str
function diskMgmt.checkNtfsPartition (partitionId)
    return "ERROR", "NTFS_FILE_TYPE_NOT_SUPPORTED"
end

--*****************************************************************************
--diskMgmt.checkFatPartition - check disk on fat file format.
--
--This routine will run fsck.vfat binary.
--
--RETURNS: status and status str
function diskMgmt.checkFatPartition (partitionId)
    local cmd = "fsck -y -t vfat " .. partitionId .. " > /dev/null"
    return "ERROR", "FAT_FILE_TYPE_NOT_SUPPORTED"
end

--*****************************************************************************
--diskMgmt.checkExFatPartition - check disk on Exfat file format.
--
--RETURNS: status and status str
function diskMgmt.checkExFatPartition (partitionId)
    return "ERROR", "EXFAT_FILE_TYPE_NOT_SUPPORTED"
end

--*****************************************************************************
--diskMgmt.checkDisk - check disk.
--
--This routine will perform disc checking for provided device.
--
--RETURNS: status and status str
function diskMgmt.checkDisk (deviceName)
    local status = "ERROR"
    -- Check for permission
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- check for device details with device name in database
    local row = db.getRowWhere("diskMgmtPartition", "name='" .. deviceName .. "'", false)
    if (row == nil) then
        return status, "DISKMGMT_DEVICE_NOT_FOUND"
    end

    -- check for the device entry in "/etc/fstab"
    status = diskMgmt.checkFsTab (row)

    if (status ~= "OK") then
        return status, "DISKMGMT_CHECKDISK_FAILED"
    end

    -- unmount the device before running fsck on mounted devices
    diskMgmt.unMountDisk (row["partId"])

    -- run fsck 
    if (row ["partFSFormat"] == "ext2") then
        status, statusStr = diskMgmt.checkExt2Partition (row["partId"])
    elseif (row ["partFSFormat"] == "ext3") then
        status, statusStr = diskMgmt.checkExt3Partition (row["partId"])
    elseif (row ["partFSFormat"] == "ext4") then
        status, statusStr = diskMgmt.checkExt3Partition (row["partId"])
    elseif (row ["partFSFormat"] == "fat16" or row ["partFSFormat"] == "fat32") then
        status, statusStr = diskMgmt.checkFatPartition (row["partId"])
    elseif (row ["partFSFormat"] == "ntfs") then
        status, statusStr = diskMgmt.checkNtfsPartition (row["partId"])
    elseif (row ["partFSFormat"] == "exfat")  then
        status, statusStr = diskMgmt.checkExFatPartition (row["partId"])
    end
    
    -- mount the disk again
    diskMgmt.mountDisk (row)
    
    return status, statusStr
end

--*****************************************************************************
--diskMgmt.partitionNameGet - get the parititon name
--
-- This function gets the partition name
--
--RETURNS:  partition name or nil
--
function diskMgmt.partitionNameGet(partId)
	local query
	local row = {}
	
	if (partId == nil) then
		return nil
	end

	query = "partId='" .. partId .. "'"

	row = db.getRowWhere("diskMgmtPartition", query,  false)
	if (row ~= nil) then
		return row["name"]
	end

	return nil
end

--*****************************************************************************
--diskMgmt.diskNameByPartIdGet - get the disk name
--
-- This function gets the disk name for the given parititon.
--
--RETURNS:  disk name or nil
--
function diskMgmt.diskNameByPartIdGet(partId)
	local query
	local row = {}
	
	if (partId == nil) then
		return nil
	end

	query = "partId='" .. partId .. "'"

	row = db.getRowWhere("diskMgmtPartition", query,  false)
	if (row ~= nil) then
		local diskId = row["diskId"]

		query = "deviceId='" .. diskId .. "'"
		row = db.getRowWhere("diskMgmtVolume", query,  false)
		if (row ~= nil) then
			return row["name"]
		end
	end

	return nil
end

--*****************************************************************************
--diskMgmt.diskUidByPartIdGet - get the disk uuid
--
-- The function gets the unique identifier for the disk on which the
-- given paritition exists.
--
--RETURNS:  uuid or nil
--
function diskMgmt.diskUidByPartIdGet(partId)
	local query
	local row = {}
	
	if (partId == nil) then
		return nil
	end

	query = "partId='" .. partId .. "'"

	row = db.getRowWhere("diskMgmtPartition", query,  false)
	if (row ~= nil) then
		local diskId = row["diskId"]

		query = "deviceId='" .. diskId .. "'"
		row = db.getRowWhere("diskMgmtVolume", query,  false)
		if (row ~= nil) then
			return row["uuid"]
		end
	end

	return nil
end

--*****************************************************************************
--diskMgmt.partInfoByNameGet - get the partition info by name
--
-- This function gets the paritition info by name.
--
--RETURNS:  partition info or nil
--

function diskMgmt.partInfoByNameGet(partName)
	local query 
	local partInfo = {}

	if (partName == nil) then
		return nil
	end		

	query = "name='" .. partName .. "'"
	partInfo = db.getRowWhere("diskMgmtPartition", query, false)
		
	return partInfo
end

--*****************************************************************************
--diskMgmt.unMountAllDisks - unmount all the disks  
--
-- This function unmounts all the partitions in all the disks.
--
-- TODO: Very in-efficient. Called just before reboot.
--
-- RETURNS:  OK
--

function diskMgmt.unMountAllDisks()
	local allDisks = {}
    require "teamf1lualib/partitionMgmt"
	
	allDisks = db.getTable ("diskMgmtVolume", false)
	if (allDisks == nil) then
		return "ERROR","DISKMGMT_NO_DEVICE_FOUND"
	end

    -- delete all shares
	for k,v in pairs(allDisks) do
		local query = "diskId='" .. v["deviceId"] .. "'"
		local allPartitions = db.getRowsWhere ("diskMgmtPartition", query, false)
		if (allPartitions ~= nil) then
			for kk,vv in pairs(allPartitions) do
                partitionMgmt.deletePartitionShares(vv["partId"])
			end
		end
	end

    -- unmount partitions
	for k,v in pairs(allDisks) do
		local query = "diskId='" .. v["deviceId"] .. "'"
		local allPartitions = db.getRowsWhere ("diskMgmtPartition", query, false)
		if (allPartitions ~= nil) then
			for kk,vv in pairs(allPartitions) do
				diskMgmt.unMountDisk(vv["partId"])
			end
		end
	end

    -- delete database entries
	for k,v in pairs(allDisks) do
        diskMgmt.deleteDiskPartitions (v["deviceId"])
        db.deleteRow ("diskMgmtVolume", "deviceId", v["deviceId"])
	end

	return "OK","STATUS_OK"
end

function diskMgmt.usbConnStatusGet ()
    local fileName="/tmp/diskMmgtAllDiskInfo"
    local usbConnStatus = {}
   
    -- Initializing the connection status.
    usbConnStatus["usb_connection_status"] = "0"
    usbConnStatus["eSATA_connection_status"] = "0"

    -- the table gets filled here
    if (pcall (loadfile (fileName))) then
        dofile (fileName)
    end
    
    if (diskAllStat ~= nil) then
        for i,v in pairs (diskAllStat) do
            if (v["diskType"] == "usb") then
                usbConnStatus["usb_connection_status"] = "1"
            elseif (v["diskType"] == "scsi") then
                usbConnStatus["eSATA_connection_status"] = "1"
            end
        end
    else
        usbConnStatus["usb_connection_status"] = "0"
        usbConnStatus["eSATA_connection_status"] = "0"
    end
    
    return usbConnStatus
end

function diskMgmt.usbMountNameGet ()
    local fileName = "/tmp/diskPartStat"
    local mountName=nil
    local confFile = io.open(fileName,"rb")
    if (confFile == nil) then
        return nil
    end
    local counter =0
    local tokenCount = 0
    for line in confFile:lines() do
        if (counter == 1) then
            for token in string.gmatch(line, "[^%s]+") do
                tokenCount=tokenCount+1
                if (tokenCount == 6) then
                    mountName = token
                end
            end
        end
        counter= counter+1
    end

    return mountName
end

function diskMgmt.usbFileListGet (mountName, configType)
    local usb_data = {}
    local usbFileListPath = "/var/usb_filelist1.txt";

    -- get files with .cfg extension
    local cmd = "find " .. mountName

    -- get files with .img extension
    if (configType == "1") then -- get only .img files
        cmd = "find " .. mountName .. " -name *.img > " .. usbFileListPath
        os.execute (cmd);
    elseif (configType == "2") then -- get only .cfg files
        cmd = "find " .. mountName .. " -name *.cfg > " .. usbFileListPath
        os.execute (cmd);
    else
        cmd = "find " .. mountName .. " -name *.img > " .. usbFileListPath
        os.execute (cmd);
        cmd = "find " .. mountName .. " -name *.cfg >> " .. usbFileListPath
        os.execute (cmd);
    end

    -- read the images and configuration files in usb
    local pFile2 = io.open(usbFileListPath, "rb")
    if (pFile2 ~= nil) then
        -- Calling table.insert call to fill a lua table with the file content.
        for line in pFile2:lines() do
            table.insert(usb_data, line)
        end
    else
        usb_data = {"","",""}
    end

    return usb_data;
end

function diskMgmt.diskMgmtGet ()
    -- locals
    local diskTbl = {}
    diskTbl = db.getTable ("diskMgmtPartition", false)
    if (diskTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN" 
    end

    -- return
    return "OK", "STATUS_OK", diskTbl
end

function diskMgmt.diskSet (conf,dbFlag)

    --locals 
    local diskconf = {}
    local status, errorCode
    local valid

    status ,errorCode, diskconf = diskMgmt.diskMgmtGet () 
    if (status ~= "OK") then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end
   
    for k,v in pairs (diskconf) do
       if (v.status ~= conf ["serverEnable"]) then 
           v.status = conf ["serverEnable"]
            -- adding prefix
            v = util.addPrefix(v, "diskMgmtPartition.")
            --update table diskMgmtPartition.
            DBTable = "diskMgmtPartition"
            valid, status = diskMgmt.config(v, v["diskMgmtPartition._ROWID_"], "edit")
            -- Return from function
            if (valid == false) then
                if (dbFlag == 1 ) then
                    db.rollback ()
                end
                return "ERROR", "DISK_CONFIG_FAILED"
            end 
        end
    end

    -- returns
    return "OK", "STATUS_OK"
end

function diskMgmt.config (inputTable, rowid, operation)
    if (operation == "add") then
        return db.insert(DBTable,inputTable)
    elseif (operation == "edit") then
        return db.update(DBTable,inputTable,rowid)
    elseif (operation == "delete") then
        return db.delete(DBTable,inputTable)
    end
end
