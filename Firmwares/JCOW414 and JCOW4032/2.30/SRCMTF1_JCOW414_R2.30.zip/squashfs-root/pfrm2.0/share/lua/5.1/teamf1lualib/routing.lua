-- @copyright Copyright (c) 2013, TeamF1, Inc.
--
-- modification history
-- --------------------
-- 01g, 19Apr19, swr Changes for SPR 65926(validations for IPv4 route)
-- 01f, 21Jun18, swr Changes for SPR 62176(add dynamic routes to route DB table)
-- 01e, 11Apr18, swr changes for spr 62547
-- 01d, 23Nov17, swr changes for spr 62635(XSS vulnerability) and 61441
-- 01c, 21Nov17, swr Changes for SPR 62609
-- 01b, 24Aug17, sjr changes for #61523
-- 01a, 10aug13, ash added support for ripng
--

--[[ Routing Settings ]]--
gui.networking.routing = {}
-- ipv4 static routes
gui.networking.routing.static = {}
gui.networking.routing.static.ipv4 = {}
gui.networking.routing.static.ipv4.add = {}
gui.networking.routing.static.ipv4.edit = {}
-- ipv6 static routes
gui.networking.routing.static.ipv6 = {}
gui.networking.routing.static.ipv6.add = {}
gui.networking.routing.static.ipv6.edit = {}
--Dynamic routing
gui.networking.routing.dynamic = {}

gui.networking.ipv6DynamicRouting = {}

-------------------------------------------------------------------------------
-- @name gui.networking.routing.static.ipv4.get
--
-- @description This function will get the list of available ipv4 static routes
-- added in system.
--
-- @return 
--
function gui.networking.routing.static.ipv4.get ()

    -- require
    require "teamf1lualib/iproute"

    -- locals
    local ipv4routeTbl = {}
    local page = {}	--local table containing the Ipv4 route Info
    local errMsg = nil
    local statusMsg = nil
    page.static = {}

    -- TODO: get ipv4 routes 
    ipv4routeTbl = iproute.ipv4routeTblGet ();
    if (ipv4routeTbl == nil) then
        return "ERROR", "IPV4_ROUTE_GET_FAILED"
    end

    local netName

    for i,v in ipairs (ipv4routeTbl)
    do
        if(v["routeType"] == "0") then
        page.static[i] = {}
        page.static[i].routeName = util.filterXSSChars(v["routeName"])
        page.static[i].dstIpAddr = util.filterXSSChars(v["dstIpAddr"])
        page.static[i].ipSNetMask = util.filterXSSChars(v["ipSNetMask"])
        page.static[i].gwIpAddr = util.filterXSSChars(v["gwIpAddr"])

        --[[ Get the "Logical" Interface name of the interface and using this
        --get the Network name to which this interface belongs to.
        --Now send this modified table for GUI display. ]]--
        netName = db.getAttribute("networkInterface", "LogicalIfName", v["interfaceName"], "networkName")
        page.static[i].interfaceName = netName or ''

        page.static[i].interfaceObject = v["interfaceObject"]
        page.static[i].metric = util.filterXSSChars(v["metric"])
        page.static[i].active = v["active"]
        page.static[i].private = v["private"]
        page.static[i].srcIpAddr = v["srcIpAddr"]
        page.static[i].srcNetMask = v["srcNetMask"]
        page.static[i]._ROWID_ = v["_ROWID_"]
        end
    end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

    --return
	return errMsg, statusMsg, page
end

-------------------------------------------------------------------------------
-- @name gui.networking.routing.static.ipv4.add.get
--
-- @description This function will get the defaults for adding a ipv4 static
-- route in device.
--
-- @return 
--
function gui.networking.routing.static.ipv4.add.get ()

    -- require
    require "teamf1lualib/iproute"
    require "teamf1lualib/platform"
    require "teamf1lualib/ifDev"


    -- locals
    local ipv4routeTbl = {}
    local netTbl = {}
    local errMsg = nil
    local statusMsg = nil

    -- TODO: get ipv4 default configuration and interfaces on which ipv4 route can be
    -- added
    ipv4routeTbl = iproute.ipv4routeGet ();
    
    ipv4routeTbl.networks = {}
   
    local query = "LogicalIfName ='IF2' or LogicalIfName ='IF1'"
    errMsg, statusMsg, netTbl = ifDev.cfgByQueryGet (query)
    if (netTbl == nil) then
        return "ERROR", "AVAILABLE_NETWORKS_GET_FAILED"
    end

    --[[ get the network names of all the available "IPv4" networks in the device. 
    --These IPv4 network names are used for displaying in the dropdown box. 
    --And the ipaddress & subnetmask are sent to front end, to have subnet 
    --validations of the adding route.]]--
    for i,v in ipairs (netTbl)
    do
        ipv4routeTbl.networks[i] = {}
        ipv4routeTbl.networks[i].networkname = v["networkName"]
        local query = "LogicalIfName ='" .. v["LogicalIfName"] .. "' and addressFamily = 2"
        row = db.getRowsWhere("ipAddressTable", query, false)
        
        if(row == nil) then
            ipv4routeTbl.networks[i].ipaddress = ''
            ipv4routeTbl.networks[i].subnetmask = ''
            ipv4routeTbl.networks[i].networkname = ''
        else
            for p,q in pairs (row) do
                    if (v["LogicalIfName"] == q["LogicalIfName"]) then
                        if (ipv4routeTbl.networks[i].ipaddress ~= nil) then
                            ipv4routeTbl.networks[i].ipaddress =  ipv4routeTbl.networks[i].ipaddress .."/" ..q["ipAddress"]
                        else
                            ipv4routeTbl.networks[i].ipaddress = q["ipAddress"]
                        end
                        if (ipv4routeTbl.networks[i].subnetmask ~= nil) then
                            ipv4routeTbl.networks[i].subnetmask = ipv4routeTbl.networks[i].subnetmask .."/"..q["subnetMask"]
                        else
                            ipv4routeTbl.networks[i].subnetmask = q["subnetMask"]
                        end
                        
                        ipv4routeTbl.networks[i].networkname = v["networkName"]
                    end
                end
            end
        end

    if (ipv4routeTbl == nil) then
        return "ERROR", "IPV4_ROUTE_ADD_GET_FAILED"
    end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

    -- return
    return errMsg, statusMsg, ipv4routeTbl
end

-------------------------------------------------------------------------------
-- @name gui.networking.routing.static.ipv4.add.set
--
-- @description This function will add a ipv4 static route in device.
--
-- @param lua table containing ipv4 static route configuration
--
-- @return 
--
function gui.networking.routing.static.ipv4.add.set (ipv4routeCfg, dbFlag)

    -- require
    require "teamf1lualib/iproute"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if(dbFlag == nil) then
        dbFlag = 1
    end

    local errorStr = ""
    local statusCode = ""

    --[[ We will get the "network name" for which the current IPv4 static route should
    --be set, but we will map it to "Logical" interface name of the network and
    --store this Logical interface name to database.]]--
    local ifaceName = db.getAttribute("networkInterface", "networkName", ipv4routeCfg["interfaceName"], "LogicalIfName")
    ipv4routeCfg["interfaceName"] = ifaceName or ''
    ipv4routeCfg["routeType"] = "0"

    -- TODO: add ipv4 static route
    errorStr, statusCode = iproute.ipv4routeSet (ipv4routeCfg, dbFlag);

    -- savedb if no error
    if(errorStr == "OK") then db.save2() end

    return errorStr, statusCode
end

-------------------------------------------------------------------------------
-- @name gui.networking.routing.static.ipv4.add.tr69set
--
-- @description This function will add a ipv4 static route in device.
--
-- @param lua table containing ipv4 static route configuration
--
-- @return 
--
function gui.networking.routing.static.ipv4.add.tr69set (ipv4routeCfg)

    -- require
    require "teamf1lualib/iproute"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --[[ We will get the "network name" for which the current IPv4 static route should
    --be set, but we will map it to "Logical" interface name of the network and
    --store this Logical interface name to database.]]--
    local ifaceName = db.getAttribute("networkInterface", "networkName", ipv4routeCfg["interfaceName"], "LogicalIfName")
    ipv4routeCfg["interfaceName"] = ifaceName or ''

    -- TODO: add ipv4 static route
    local errorStr, statusCode = iproute.tr69IPv4routeSet (ipv4routeCfg);

    -- savedb if no error
    if(errorStr == "OK") then db.save2() end

    return errorStr, statusCode
end

-------------------------------------------------------------------------------
-- @name gui.networking.routing.static.ipv4.edit.get
--
-- @description This function will get the ipv4 static route details available
-- in device for a given rowid.
--
-- @param rowid for which route information has to be queried.
--
-- @return 
--
function gui.networking.routing.static.ipv4.edit.get (rowid)

    -- require
    require "teamf1lualib/iproute"
    require "teamf1lualib/platform"
    require "teamf1lualib/ifDev"


    -- locals
    local ipv4routeTbl = {}
    local netTbl = {}
    local netName
    local errMsg = nil
    local statusMsg = nil


    -- get the current configuration of the selected IPv4 route.
    ipv4routeTbl = iproute.ipv4routeEditGet (rowid);

    ipv4routeTbl.networks = {}
    
    -- get all the available networks in the device.
    local query = "LogicalIfName ='IF2' or LogicalIfName ='IF1'"
    errMsg, statusMsg, netTbl = ifDev.cfgByQueryGet (query)
    if (netTbl == nil) then
        return "ERROR", "AVAILABLE_NETWORKS_GET_FAILED"
    end

    --[[ get the network names of all the available networks in the device. 
    --These network names are used for displaying in the dropdown box. 
    --And the ipaddress & subnetmask are sent to front end, to have subnet 
    --validations of the adding route.]]--
    for i,v in ipairs (netTbl)
    do
        ipv4routeTbl.networks[i] = {}
        ipv4routeTbl.networks[i].networkname = v["networkName"]
        
        local query = "LogicalIfName ='" .. v["LogicalIfName"] .. "' and addressFamily = 2"
        row = db.getRowsWhere("ipAddressTable", query, false)

        if(row == nil) then
            ipv4routeTbl.networks[i].ipaddress = ''
            ipv4routeTbl.networks[i].subnetmask = ''
        else
            for p,q in pairs (row) do
                    if (v["LogicalIfName"] == q["LogicalIfName"]) then
                        if (ipv4routeTbl.networks[i].ipaddress ~= nil) then
                            ipv4routeTbl.networks[i].ipaddress =  ipv4routeTbl.networks[i].ipaddress .."/" ..q["ipAddress"]
                        else
                            ipv4routeTbl.networks[i].ipaddress = q["ipAddress"]
                        end
                        if (ipv4routeTbl.networks[i].subnetmask ~= nil) then
                            ipv4routeTbl.networks[i].subnetmask = ipv4routeTbl.networks[i].subnetmask .."/"..q["subnetMask"]
                        else
                            ipv4routeTbl.networks[i].subnetmask = q["subnetMask"]
                        end
                        
                        ipv4routeTbl.networks[i].networkname = v["networkName"]
                    end
                end
            end

        -- Find the network name that should be displayed in the dropdown.
        if (v["LogicalIfName"] == ipv4routeTbl["interfaceName"]) then
            netName = v["networkName"]
        end
    end
    ipv4routeTbl["interfaceName"] = netName or ''
    ipv4routeTbl["routeName"] = util.filterXSSChars(ipv4routeTbl["routeName"]) or ''
    ipv4routeTbl["dstIpAddr"] = util.filterXSSChars(ipv4routeTbl["dstIpAddr"]) or ''
    ipv4routeTbl["ipSNetMask"] = util.filterXSSChars(ipv4routeTbl["ipSNetMask"]) or ''
    ipv4routeTbl["gwIpAddr"] = util.filterXSSChars(ipv4routeTbl["gwIpAddr"]) or ''
    ipv4routeTbl["metric"] = util.filterXSSChars(ipv4routeTbl["metric"]) or ''

    if (ipv4routeTbl == nil) then
        return "ERROR", "IPV4_ROUTE_EDIT_GET_FAILED"
    end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

    -- return
    return errMsg, statusMsg, ipv4routeTbl
end

-------------------------------------------------------------------------------
-- @name gui.networking.routing.static.ipv4.edit.set
--
-- @description This function will reconfigure a ipv4 static route in device.
--
-- @param lua table containing ipv4 static route details.
--
-- @return 
--
function gui.networking.routing.static.ipv4.edit.set (ipv4routeCfg, dbFlag)

    -- require
    require "teamf1lualib/iproute"

	--locals
	local status, err

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if(dbFlag == nil) then
        dbFlag = 1
    end

    --[[ We will get the "network name" for which the current IPv4 static route should
    --be set, but we will map it to "Logical" interface name of the network and
    --store this Logical interface name to database.]]--
    local ifaceName = db.getAttribute("networkInterface", "networkName", ipv4routeCfg["interfaceName"], "LogicalIfName")
    ipv4routeCfg["interfaceName"] = ifaceName or ''

    -- TODO: add ipv4 static route
 	status, err = iproute.ipv4routeEditSet (ipv4routeCfg, dbFlag)
    
    -- savedb if no error
    if(status == "OK") then db.save2() end

    return status, err
end

-------------------------------------------------------------------------------
-- @name gui.networking.routing.static.ipv4.delete
--
-- @description This function will delete ipv4 static route(s) available in
-- device.
--
-- @param rowid(s) for which routes are to be deleted.
--
-- @return 
--
function gui.networking.routing.static.ipv4.delete (rowids)

     -- require
    require "teamf1lualib/iproute"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- TODO: add ipv4 static route
    errorStr, statusCode = iproute.ipv4routeDelete (rowids);

    -- savedb if no error
    if(errorStr == "OK") then db.save2() end

    return errorStr, statusCode
end

-------------------------------------------------------------------------------
-- @name gui.networking.routing.static.ipv6.get
--
-- @description This function will get the list of available ipv6 static routes
-- added in system.
--
-- @return 
--
function gui.networking.routing.static.ipv6.get ()

    -- require
    require "teamf1lualib/iproute"
    require "teamf1lualib/ripng"

    -- locals
    local ipv6routeTbl = {}
    local ripngTbl = {}
    local page = {} --local table containing the Ipv6 route Info
    local errMsg = nil
    local statusMsg = nil
    page.ipv6StaticRoutes = {}
    page.Ripng = {}

    ripngTbl = ripng.ripngConfigGet()
    if (ripngTbl == nil) then
        return "ERROR", "RIPNG_GET_FAILED"
    end
    
    page.Ripng.isEnabled = ripngTbl["RipngEnable"]

    -- get ipv6 routes 
    ipv6routeTbl = iproute.ipv6routeTblGet ()
    if (ipv6routeTbl == nil) then
        return "ERROR", "IPV6_ROUTE_GET_FAILED"
    end
    
    local netName
    
    for i,v in ipairs (ipv6routeTbl) do
        if(v["routeType"] == "0" ) then
            page.ipv6StaticRoutes[i] = {}
            page.ipv6StaticRoutes[i].routeName = util.filterXSSChars(v["routeName"])
            page.ipv6StaticRoutes[i].dstIpAddr = util.filterXSSChars(v["dstIpAddr"])
            page.ipv6StaticRoutes[i].gwIpAddr = util.filterXSSChars(v["gwIpAddr"])

            --[[ Get the "Logical" Interface name of the interface and using this
            --get the Network name to which this interface belongs to.
            --Now send this modified table for GUI display. ]]--
            netName = db.getAttribute("networkInterface", "LogicalIfName", v["interfaceName"], "networkName")
            page.ipv6StaticRoutes[i].interfaceName = netName or ''

            page.ipv6StaticRoutes[i].metric = util.filterXSSChars(v["metric"])
            page.ipv6StaticRoutes[i].active = v["active"]
            page.ipv6StaticRoutes[i]._ROWID_ = v["_ROWID_"]
        end   
    end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

    --return
    return errMsg, statusMsg, page
end

-------------------------------------------------------------------------------
-- @name gui.networking.routing.static.ipv6.add.get
--
-- @description This function will get the defaults for adding a ipv6 static
-- route in device.
--
-- @return 
--
function gui.networking.routing.static.ipv6.add.get ()

    -- require
    require "teamf1lualib/iproute"
    require "teamf1lualib/platform"

    -- locals
    local ipv6routeTbl = {}
    local netTbl = {}
    local errMsg = nil
    local statusMsg = nil

    -- TODO: get ipv6 default configuration and interfaces on which ipv6 route can be
    -- added
    ipv6routeTbl = iproute.ipv6routeGet ();
    
    ipv6routeTbl.networks = {}
    
    netTbl = platform.availableIPv6NetworkGet()
    if (netTbl == nil) then
        return "ERROR", "AVAILABLE_NETWORKS_GET_FAILED"
    end

    --[[ get the network names of all the available "ipv6" networks in the device. 
    --These ipv6 network names are used for displaying in the dropdown box. 
    --And the ipaddress & subnetmask are sent to front end, to have subnet 
    --validations of the adding route.]]--
    for i,v in ipairs (netTbl)
    do
        ipv6routeTbl.networks[i] = {}
        ipv6routeTbl.networks[i].ipv6var = {}
        ipv6routeTbl.networks[i].networkname = v["networkName"]
        local query = "LogicalIfName ='" .. v["LogicalIfName"] .. "' and addressFamily = 10"
        row = db.getRowsWhere("ipAddressTable", query, false)
        
        if(row ~= nil) then
            for p,q in pairs(row) do
                ipv6routeTbl.networks[i].ipv6var[p] = {}
                ipv6routeTbl.networks[i].ipv6var[p].ipAddress = q["ipAddress"]
                ipv6routeTbl.networks[i].ipv6var[p].prefixLength = q["ipv6PrefixLen"]
            end
        else
            ipv6routeTbl.networks[i].ipv6var[p] = {}
            ipv6routeTbl.networks[i].ipv6var[p].ipAddress = ''
            ipv6routeTbl.networks[i].ipv6var[p].prefixLength = ''
        end
    end

    if (ipv6routeTbl == nil) then
        return "ERROR", "IPV6_ROUTE_ADD_GET_FAILED"
    end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

    -- return
    return errMsg, statusMsg, ipv6routeTbl
end

-------------------------------------------------------------------------------
-- @name gui.networking.routing.static.ipv6.add.set
--
-- @description This function will add a ipv6 static route in device.
--
-- @param lua table containing ipv6 static route configuration
--
-- @return 
--
function gui.networking.routing.static.ipv6.add.set (ipv6routeCfg, dbFlag)

    -- require
    require "teamf1lualib/iproute"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if(dbFlag == nil) then
        dbFlag = 1
    end
    
    --[[ We will get the "network name" for which the current IPv4 static route should
    --be set, but we will map it to "Logical" interface name of the network and
    --store this Logical interface name to database.]]--
    local ifaceName = db.getAttribute("networkInterface", "networkName", ipv6routeCfg["interfaceName"], "LogicalIfName")
    ipv6routeCfg["interfaceName"] = ifaceName or ''
    ipv6routeCfg["prefix"] = ipv6routeCfg["PrefixLength"] or ''
    ipv6routeCfg["routeType"] = "0"

	--locals	
	local errMsg, status	

    -- TODO: add ipv6 static route
    errMsg, status = iproute.ipv6routeSet (ipv6routeCfg, dbFlag);

    -- return
    return errMsg, status
end

-------------------------------------------------------------------------------
-- @name gui.networking.routing.static.ipv6.add.tr69set
--
-- @description This function will add a ipv6 static route in device.
--
-- @param lua table containing ipv6 static route configuration
--
-- @return 
--
function gui.networking.routing.static.ipv6.add.tr69set (ipv6routeCfg)

    -- require
    require "teamf1lualib/iproute"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
    
    --[[ We will get the "network name" for which the current IPv4 static route should
    --be set, but we will map it to "Logical" interface name of the network and
    --store this Logical interface name to database.]]--
    local ifaceName = db.getAttribute("networkInterface", "networkName", ipv6routeCfg["interfaceName"], "LogicalIfName")
    ipv6routeCfg["interfaceName"] = ifaceName or ''
    ipv6routeCfg["prefix"] = ipv6routeCfg["PrefixLength"] or ''

	--locals	
	local errMsg, status	

    -- TODO: add ipv6 static route
    errMsg, status = iproute.tr69IPv6routeSet (ipv6routeCfg);

    -- return
    return errMsg, status
end

-------------------------------------------------------------------------------
-- @name gui.networking.routing.static.ipv6.edit.get
--
-- @description This function will get the ipv6 static route details available
-- in device for a given rowid.
--
-- @param rowid for which route information has to be queried.
--
-- @return 
--
function gui.networking.routing.static.ipv6.edit.get (rowid)

    -- require
    require "teamf1lualib/iproute"
    require "teamf1lualib/platform"

    -- locals
    local ipv6routeTbl = {}
    local netTbl = {}
    local netName = {}
    local errMsg = nil
    local statusMsg = nil

    -- TODO: get ipv6 default configuration and interfaces on which ipv6 route can be
    -- added
    ipv6routeTbl = iproute.ipv6routeEditGet (rowid);
    if (ipv6routeTbl == nil) then
        return "ERROR", "IPV6_ROUTE_GET_FAILED"
    end
    
    ipv6routeTbl.networks = {}
    
    netTbl = platform.availableIPv6NetworkGet()
    if (netTbl == nil) then
        return "ERROR", "AVAILABLE_NETWORKS_GET_FAILED"
    end

    --[[ get the network names of all the available "ipv6" networks in the device. 
    --These ipv6 network names are used for displaying in the dropdown box. 
    --And the ipaddress & subnetmask are sent to front end, to have subnet 
    --validations of the adding route.]]--
    for i,v in ipairs (netTbl)
    do
        ipv6routeTbl.networks[i] = {}

        ipv6routeTbl.networks[i].networkname = v["networkName"]
        local query = "LogicalIfName ='" .. v["LogicalIfName"] .. "' and addressFamily = 10"
        row = db.getRowsWhere("ipAddressTable", query, false)
        
        ipv6routeTbl.networks[i].ipv6var = {}
        if(row ~= nil) then
            for p,q in pairs(row) do
                ipv6routeTbl.networks[i].ipv6var[p] = {}
                ipv6routeTbl.networks[i].ipv6var[p].ipAddress = q["ipAddress"]
                ipv6routeTbl.networks[i].ipv6var[p].prefixLength = q["ipv6PrefixLen"]
            end
        else
            ipv6routeTbl.networks[i].ipv6var[p] = {}
            ipv6routeTbl.networks[i].ipv6var[p].ipAddress = ''
            ipv6routeTbl.networks[i].ipv6var[p].prefixLength = ''
        end

        -- Find the network name that should be displayed in the dropdown.
        if (v["LogicalIfName"] == ipv6routeTbl["interfaceName"]) then
            netName = v["networkName"]
        end
    end
    ipv6routeTbl["PrefixLength"] = util.filterXSSChars(ipv6routeTbl["prefix"]) or ''
    ipv6routeTbl["dstIpAddr"] = util.filterXSSChars(ipv6routeTbl["dstIpAddr"]) or ''
    ipv6routeTbl["metric"] = util.filterXSSChars(ipv6routeTbl["metric"]) or ''
    ipv6routeTbl["gwIpAddr"] = util.filterXSSChars(ipv6routeTbl["gwIpAddr"]) or ''
    ipv6routeTbl["routeName"] = util.filterXSSChars(ipv6routeTbl["routeName"]) or ''
    ipv6routeTbl["interfaceName"] = netName or ''

    errMsg = "OK"
    statusMsg = "STATUS_OK"

    -- return
    return errMsg, statusMsg, ipv6routeTbl
end

-------------------------------------------------------------------------------
-- @name gui.networking.routing.static.ipv6.edit.set
--
-- @description This function will reconfigure a ipv6 static route in device.
--
-- @param lua table containing ipv6 static route details.
--
-- @return 
--
function gui.networking.routing.static.ipv6.edit.set (ipv6routeCfg, dbFlag)

    -- require
    require "teamf1lualib/iproute"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if(dbFlag == nil) then
        dbFlag = 1
    end

    --[[ We will get the "network name" for which the current IPv4 static route should
    --be set, but we will map it to "Logical" interface name of the network and
    --store this Logical interface name to database.]]--
    local ifaceName = db.getAttribute("networkInterface", "networkName", ipv6routeCfg["interfaceName"], "LogicalIfName")
    ipv6routeCfg["interfaceName"] = ifaceName or ''
    ipv6routeCfg["prefix"] = ipv6routeCfg["PrefixLength"] or ''

    -- TODO: add ipv6 static route
    local errMsg, statusMsg = iproute.ipv6routeEditSet (ipv6routeCfg, dbFlag);

    -- return
    return errMsg, statusMsg
end

-------------------------------------------------------------------------------
-- @name gui.networking.routing.static.ipv6.delete
--
-- @description This function will delete ipv6 static route(s) available in
-- device.
--
-- @param rowid(s) for which routes are to be deleted.
--
-- @return 
--
function gui.networking.routing.static.ipv6.delete (rowids)

     -- require
    require "teamf1lualib/iproute"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- TODO: add ipv6 static route
    errorStr, statusCode = iproute.ipv6routeDelete (rowids);

    -- return
    return errorStr, statusCode
end

-------------------------------------------------------------------------------
-- @name gui.networking.routing.dynamic.get
--
-- @description This function will get rip information available in system
--
-- @return 
--
function gui.networking.routing.dynamic.get ()

    -- require
    require "teamf1lualib/rip"


    -- locals
    local ripTbl = {}
    local errMsg = nil
    local statusMsg = nil

    -- get rip configuration
    ripTbl = rip.configurationGet ()
    if (ripTbl == nil) then
        return "ERROR", "RIP_CONFIG_GET_FAILED"
    end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

    ripTbl["FirstKeyId"] = util.filterXSSChars(ripTbl["FirstKeyId"])
    ripTbl["FirstAuthenticationKeyId"] = util.filterXSSChars(ripTbl["FirstAuthenticationKeyId"])
    ripTbl["SecondKeyId"] = util.filterXSSChars(ripTbl["SecondKeyId"])
    ripTbl["SecondAuthenticationKeyId"] = util.filterXSSChars(ripTbl["SecondAuthenticationKeyId"])
    
    -- return
    return errMsg, statusMsg, ripTbl
end

-------------------------------------------------------------------------------
-- @name gui.networking.routing.dynamic.set
--
-- @description This function will configure (enable/disbale/reconfigure) rip 
-- in system.
--
-- @param lua table containing rip configuration.
--
-- @return 
--
function gui.networking.routing.dynamic.set (ripCfg)

    -- require
    require "teamf1lualib/rip"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

        if(ripCfg["FirstAuthenticationKeyId"] ~=nil and util.isAllMasked(ripCfg["FirstAuthenticationKeyId"])) then
            ripCfg["FirstAuthenticationKeyId"] = db.getAttribute("Rip","_ROWID_","1","FirstAuthenticationKeyId")
        end
        if(ripCfg["SecondAuthenticationKeyId"] ~=nil and util.isAllMasked(ripCfg["SecondAuthenticationKeyId"])) then
            ripCfg["SecondAuthenticationKeyId"] = db.getAttribute("Rip","_ROWID_","1","SecondAuthenticationKeyId")
        end

    -- update rip table
    local localRipTbl = util.addPrefix(ripCfg, "Rip.")
    errorFlag, statusCode = rip.config(localRipTbl, "1", "edit")

    -- save db if no error
    if (errorFlag == "OK") then db.save2() end

    -- return
    return errorFlag, statusCode
end


function gui.networking.ipv6DynamicRouting.set (RipngCfg)
    -- require
    require "teamf1lualib/ripng"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (RipngCfg == nil) then
        return "ERROR", "RIPNG_CONFIG_FAILED"    
    end

    local tmpTbl = {}

  tmpTbl["Ripng.RipngEnable"] = RipngCfg["isEnabled"]

    -- update ripng table
    errorFlag, statusCode = ripng.ripngConfig(tmpTbl, "1", "edit")

    -- save db if no error
    if (errorFlag == "OK") then db.save2() end

    -- return
    return errorFlag, statusCode
end

