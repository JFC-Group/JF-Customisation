-- @copyright Copyright (c) 2013, TeamF1, Inc. 

--************* Packages *************
sixToFour = {}

-------------------------------------------------------------------------
-- @name sixToFour.config
--
-- @description 
--
-- @return 
--

function sixToFour.config (tableName, inputTable, rowid, operation)
    -- validate
    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
            return db.insert(tableName, inputTable)
        elseif (operation == "edit") then
            return db.update(tableName, inputTable, rowid)
        elseif (operation == "delete") then
           for k,v in pairs(inputTable) do
                valid  = db.deleteRow(tableName, "_ROWID_", v)
                if (not valid) then  return false end
            end
        end
    end

    return false
end


-------------------------------------------------------------------------
-- @name sixToFour.import
--
-- @description 
--
-- @return 
--

function sixToFour.import (sixToFourConfig, defaultCfg, removeCfg)
    if (sixToFourConfig == nil) then
        sixToFourConfig = defaultCfg
    end

    local sixToFourTmp = {}

    sixToFourTmp = config.update (sixToFourConfig.sixToFourTunnel, defaultCfg.sixToFourTunnel, removeCfg.sixToFourTunnel)
    if (sixToFourTmp ~= nil and #sixToFourTmp ~= 0) then
        for i,v in ipairs (sixToFourTmp) do
            v = util.addPrefix (v, "sixToFourTunnel.");
            sixToFour.config ("sixToFourTunnel", v, -1, "add")
        end
    end
	
end

-------------------------------------------------------------------------
-- @name sixToFour.export
--
-- @description 
--
-- @return 
--

function sixToFour.export ()
	local sixToFourTbl = {}
	local table = {}
    table["sixToFourTunnel"] = {}

 	table["sixToFourTunnel"] = db.getTable("sixToFourTunnel" , false)
	if (table["sixToFourTunnel"] ~= nil) then
	    sixToFourTbl["sixToFourTunnel"] = table["sixToFourTunnel"]
	end

	return sixToFourTbl
end
 

if (config.register) then
   config.register("sixToFour", sixToFour.import, sixToFour.export, "1")
end

-------------------------------------------------------------------------
-- @name sixToFour.cfgInit
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function sixToFour.cfgInit (row, conf)

    if (conf["tunnelStatus"] ~= nil) then
        row["tunnelStatus"] = conf["tunnelStatus"]  
    end        
    
    if (conf["LogicalIfName"] ~= nil) then
        row["LogicalIfName"] = conf["LogicalIfName"]  
    end        

    if (conf["interfaceName"] ~= nil) then
        row["interfaceName"] = conf["interfaceName"]  
    end

    if (conf["localAddr"] ~= nil) then
        row["localAddr"] =  conf["localAddr"]
    end

    if (conf["destAddr"] ~= nil) then
        row["destAddr"] = conf["destAddr"]
    end

    return row
end

-------------------------------------------------------------------------
-- @name sixToFour.defCfgGet
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function sixToFour.defCfgGet()
    local conf = {}
    conf["tunnelStatus"] ="0"
    conf["LogicalIfName"] = "IF1"
    conf["interfaceName"] = "sit0"
    conf["localAddr"] = "0.0.0.0"
    conf["destAddr"] = "0.0.0.0"

    return conf
end

-------------------------------------------------------------------------
-- @name sixToFour.configure
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function sixToFour.configure (conf)
    local query

    -- Get the sixToFour configuration
    query = "_ROWID_='1'"
    local row = db.getRowWhere("sixToFourTunnel", query, false)
    if (row ~= nil) then
        row = sixToFour.cfgInit(row, conf)

        row = util.addPrefix(row, "sixToFourTunnel.")
        local valid, errstr = db.update("sixToFourTunnel", row, row["sixToFourTunnel._ROWID_"])
        if (not valid) then
            return "ERROR", "6TO4_UPDATE_FAILED"
        end            
    else
        row = sixToFour.defCfgGet()
        row = sixToFour.cfgInit(row, conf)

        util.appendDebugOut ("conf.." .. util.tableToStringRec(row))

        row = util.addPrefix(row, "sixToFourTunnel.")
        local valid, errstr, rowid  = db.insert("sixToFourTunnel", row)
        if (not valid) then
            return "ERROR", "6To4_ADD_FAILED"
        end            
    end        

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name sixToFour.get
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function sixToFour.get (query)
    local rows = {}
    local index = 1
    local cfgTbl = {}

    if (query ~= nil) then
        rows = db.getRowsWhere("sixToFourTunnel", query, false)
    else
        rows = db.getTable("sixToFourTunnel", false)
    end        
    
    if (rows ~= nil) then
        for k,v in pairs(rows) do
            cfgTbl[index] = {}                
            cfgTbl[index] = v
            index = index + 1
        end            
    end

    return "OK","STATUS_OK", cfgTbl
end

-------------------------------------------------------------------------
-- @name sixToFour.tunnelGet
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function sixToFour.tunnelGet ()
    local rows = {}
    local index = 1
    local cfgTbl = {}
    local query = "ifType='tunnel'"

    
    rows = db.getRowsWhere("networkInterface", query, false)

    if (rows ~= nil) then
        for k,v in pairs(rows) do
            cfgTbl[index] = {}                
            cfgTbl[index] = v
            index = index + 1
        end            
    end
   
    return cfgTbl
end

-------------------------------------------------------------------------
-- @name sixToFour.tunnelIpaddr
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function sixToFour.tunnelIpaddr (name)
    local rows = {}
    local index = 1
    local cfgTbl = {}

    local query = "LogicalIfName='" .. name .. "'"
    
   rows = db.getRowsWhere("ipAddressTable", query, false)
    
    if (rows ~= nil) then
        for k,v in pairs(rows) do
            cfgTbl[index] = {}                
            cfgTbl[index] = v
            index = index + 1
        end            
    end
   
    return cfgTbl
end
