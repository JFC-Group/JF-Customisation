--[[
#### Abdul Muheedh.
#### TeamF1
#### www.TeamF1.com
#### Mar 31, 2012

#### File: dhcpRelayConfig.lua
#### Description: dhcpRelay functions

#### Revisions:
]]--


--************* Requires *************

--************* Initial Code *************
--package dhcpRelay
dhcpRelay = {}
--************* Functions *************
-- dhcpRelay update Configuration

--******************************************************************************
	--The component specific functions 
--******************************************************************************

function dhcpRelay.config (inputTable, rowid, operation)
    local DBTable = "dhcpRelay"

    if (operation == "add") then
        return db.insert(DBTable, inputTable)
    elseif (operation == "edit") then
        return db.update(DBTable,inputTable,rowid)
    elseif (operation == "delete") then
        return false
    end
end

--********************************************************************************
--@name dhcpRelay.confGet (name)
--
--@description  - The function will get the table from the database
--		The function will check for the following-
--
--@param name -The networkname recevied from the management interface
--			
--@return 
--

function dhcpRelay.confGet(LogicalIfName)
	local dhcpRelayVar = {}
    local conf = {}
    local err, status = "ERROR", "DB_ERROR_TRY_AGAIN"
	local query = {}
    
    -- construct the query
	query = "logicalIfName='" .. LogicalIfName .. "'"
    -- get the tables according to the query
    dhcpRelayVar = db.getRowWhere("dhcpRelay", query ,false)
    if (dhcpRelayVar == nil ) then
        -- return the error status and nil value 
		return err, status, dhcpRelayVar
	end
	
    -- now load the values into the inputTable
    conf["dhcpRelayStatus"] = dhcpRelayVar["dhcpRelayStatus"] 
    conf["relayGw"] = dhcpRelayVar["relayGateway"]
    conf["option82"] =  "0"

    -- if only the option feild is enabled */
    if (tonumber(dhcpRelayVar["option82"]) == 1) then
        -- circuit and remote id parameters
        conf["option82"] =  "1"
        conf["circuitID"] = dhcpRelayVar["circuitAgentID"]
        conf["remoteID"] = dhcpRelayVar["remoteAgentID"]
    end
    
    -- return the input Table
	return "OK", "SUCCESS", conf
end

--********************************************************************************
--@name dhcpRelay.defConfGet ()
--
--@description get the default relay configuration
--
--@param n/a
--			
--@return defconf
--

function dhcpRelay.defConfGet()
    local dhcpRelayVar = {}    

    -- by default disable the relay
    dhcpRelayVar["dhcpRelayStatus"] = 0
    dhcpRelayVar["relayGateway"] = "0.0.0.0" 
    -- by default dont allow the option 82
    dhcpRelayVar["option82"] = 0
    dhcpRelayVar["action82"] = "append"
    dhcpRelayVar["circuitAgentID"] = "00.00.00.00.00.00"
    dhcpRelayVar["remoteAgentID"] = "0000"

    return dhcpRelayVar
end        

--********************************************************************************
--@name dhcpRelay.confEdit (inputTable)
--
--@description  - The function will edit the table in the database
--		The function will check for the following-
--
--@param inputTable -The inputTable recevied from the management interface
--			
--@return 
--

function dhcpRelay.confEdit(conf)
	local dhcpRelayVar = {}
    local err, errCode = "ERROR", "DHCP_RELAY_INVALID_PARAMS"
	local query = {}
    local insert = 0
    local valid = false
    local status = "ERROR"
    
    if (conf["LogicalIfName"] == nil) then
        return err, errCode
    end    
    
    -- construct the query
	query = "logicalIfName='" .. conf["LogicalIfName"] .. "'"
    -- get the Row
    dhcpRelayVar = db.getRowWhere("dhcpRelay", query ,false)
    if (dhcpRelayVar == nil) then
        dhcpRelayVar = dhcpRelay.defConfGet()        
        dhcpRelayVar["logicalIfName"] = conf["LogicalIfName"]
        insert = 1
    end

    if (conf["dhcpRelayStatus"] ~= nil) then
        dhcpRelayVar["dhcpRelayStatus"] = tonumber(conf["dhcpRelayStatus"])
    end    

    if (conf["relayGw"] ~= nil) then
        -- copy the relay gateway
        dhcpRelayVar["relayGateway"] = conf["relayGw"] 
    end        
  
    if (conf["option82"] ~= nil) then
        -- option 82 feild values
        dhcpRelayVar["option82"] = tonumber(conf["option82"])

        -- if the option 82 is enabled 
        if (dhcpRelayVar["option82"] == 1) then
            dhcpRelayVar["action82"] = "append" 

            if (conf["circuitID"] ~= nil) then
                dhcpRelayVar["circuitAgentID"] = conf["circuitID"]
            end
                        
            if (conf["remoteID"] ~= nil) then                        
                dhcpRelayVar["remoteAgentID"] = conf["remoteID"]        
            end
        end
    end        
    
    dhcpRelayVar = util.addPrefix(dhcpRelayVar, "dhcpRelay.")
    if (insert > 0) then
	    valid, errstr = dhcpRelay.config (dhcpRelayVar, -1, "add")
    else
    	valid, errstr = dhcpRelay.config (dhcpRelayVar, 
                                        dhcpRelayVar["dhcpRelay._ROWID_"], 
                                        "edit")
    end

    if (not valid) then
        status = "ERROR"
        errCode = "DHCP_RELAY_DB_ERR"
    else
        status = "OK"
        errCode = "STATUS_OK"
    end                

	return status, errCode
end

--********************************************************************************
--@name dhcpRelay.confDelete ()
--
--@description delete dhcp relay configuration
--
--@param n/a
--			
--@return status, errCode
--

function dhcpRelay.confDelete (conf)
    local status, errCode = "ERROR", "DHCP_RELAY_INVALID_PARAMS"
	local query = {}
    local valid , errstr
    
    if (conf["LogicalIfName"] == nil) then
        return status, errCode
    end    
    
    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "'"
    valid, errstr = db.deleteRowWhere ("dhcpRelay", query)
    if (not valid) then
        return status, "DHCP_RELAY_CONF_NOT_FOUND"
    end        

    return "OK", "STATUS_OK"
end

--********************************************************************************
--@name dhcpRelay.import (inputTable)
--
--@description  - The function will import the table in the database
--		The function will check for the following-
--
--@param inputTable -The inputTable recevied from the management interface
--			
--@return 
--

function dhcpRelay.import (inputTable, defaultCfg, remCfg)
    if (inputTable == nil) then
        inputTable = defaultCfg
    end

    --initializing a temp table
    local configTable = {}

    if (inputTable ~= nil) then 	
    	configTable = config.update (inputTable, defaultCfg, remCfg)
        if (configTable ~= nil and #configTable ~= 0) then
            for i,v in ipairs (configTable) do
                if (v ~= nil) then
                    v = util.addPrefix (v, "dhcpRelay.")
                    db.insert("dhcpRelay", v)
                end
            end
    	end
    end
end

--********************************************************************************
--@name dhcpRelay.export ()
--
--@description  - The function will export the table in the database
--		The function will check for the following-
--
--@param inputTable -The inputTable recevied from the management interface
--			
--@return 
--

function dhcpRelay.export ()
    -- local table
    local table = {}
    -- this function call returns all the table feilds and stores it in table
    table =  db.getTable ("dhcpRelay", false)
    return table
end

--************************************CONFIG*************************************
if (config.register) then
   config.register("dhcpRelay", dhcpRelay.import, dhcpRelay.export, "1")
end
