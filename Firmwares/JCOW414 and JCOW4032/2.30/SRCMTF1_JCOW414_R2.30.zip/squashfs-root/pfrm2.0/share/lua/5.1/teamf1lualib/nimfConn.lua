-- @copyright Copyright (c) 2012, TeamF1, Inc. 

nimfConn = {}

require "teamf1lualib/nimfUtil"
require "teamf1lualib/nimfConnUtil"

nimfConn.StateVal = {
    NIMF_CONN_STATE_INIT            =   0,
    NIMF_CONN_STATE_SETUP           =   1,
    NIMF_CONN_STATE_CONNECTED       =   2,
    NIMF_CONN_STATE_TEARDOWN        =   3,
    NIMF_CONN_STATE_STOPPED         =   4,
    NIMF_CONN_STATE_STANDBY         =   5,
    NIMF_CONN_STATE_WAIT            =   6,
    NIMF_CONN_STATE_FAIL            =   7,
    NIMF_CONN_STATE_IDLE            =   8,
} 

nimfConn.status = {
    NIMF_NET_F_IPV4_UP  =   1,
    NIMF_NET_F_IPV6_UP  =   2,
}

-------------------------------------------------------------------------------
-- @name nimfConn.start 
--
-- @description This function starts the connection.
--
-- @param  connID  the connection ID
-- <ul>
-- <li><i> LogicalIfName</i>    Logical Name of this network
-- <li><i> AddressFamily</i>    network protocol of the connection
-- <li><i> ConnectionKey</i>    connection key. (Optional. Default = 0)
-- </ul>
--
-- @return  status OK or ERROR
-- @return  errCode error code string
--

function nimfConn.start (connID)
    local status
    local errCode

    status, errCode = nimfConn.IDValidate (connID) 
    if (status ~= "OK") then
        return status, errCode        
    end        

    errCode = nimfLib.connStart(connID)
    if (errCode ~= 0) then
        nimf.dprintf("Failed to start Connection " ..  nimf.connStrGet(connID))
        return "ERROR", errCode
    end        

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name nimfConn.stop 
--
-- @description This function stops the connection.
--
-- @param  connID  the connection ID
-- <ul>
-- <li><i> LogicalIfName</i>    Logical Name of this network
-- <li><i> AddressFamily</i>    network protocol of the connection
-- <li><i> ConnectionKey</i>    connection key. (Optional. Default = 0)
-- </ul>
--
-- @return  status OK or ERROR
-- @return  errCode error code string
--

function nimfConn.stop (connID)
    local status
    local errCode

    status, errCode = nimfConn.IDValidate (connID) 
    if (status ~= "OK") then
        return status, errCode        
    end        

    status = nimfLib.connStop(connID)
    if (status ~= 0) then
        nimf.dprintf("Failed to start Connection " ..  nimf.connStrGet(connID))
        return "ERROR", status
    end        

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name nimfConn.configure
--
-- @description 
--
-- @param conf  array of network configuration have the following fields
-- <ul>
-- <li><i> AddressFamily</i>     network protocol of the connection
-- <li><i> Enable</i>            enable/disable connection
-- <li><i> ConnectionType</i>    type of the network connection. see nimf.method table   
-- <li><i> StaticIp</i>          static IP address to be configured for this network
-- <li><i> PrefixLength</i>      prefix length if static IP address is an IPv6 address.
-- <li><i> NetMask</i>           netmask if static IP address is an IPv4 address
-- <li><i> Gateway</i>           Gateway router IP address of this network
-- <li><i> PrimaryDns</i>        Primary DNS server IP address of this network
-- <li><i> SecondaryDns</i>      Secondary DNS server IP address of this network
-- <li><i> IdleDisconnectTime</i> Idle Timeout in case of PPP connections   
-- <li><i> Username</i>          username for PPP authentication
-- <li><i> Password</i>          password for PPP authentication
-- <li><i> GetIpFromIsp</i>      1 if this network gets IP parameters from ISP
-- <li><i> GetDnsFromIsp</i>     1 if this network gets DNS from ISP
-- <li><i> AccountName</i>       account name to be used for the PPP connection
-- <li><i> DomainName</i>        domain name to be used for the PPP connection
-- <li><i> AuthOpt</i>           list of authentication protocol to be used for PPP
-- <li><i> MyIPAddress</i>       IP address to be configured for this network for PPTP/L2TP 
-- <li><i> ServerIP</i>          IP address of the PPTP/L2TP server
-- <li><i> MppeEncryptSupport</i>Mppe Encryption
-- <li><i> StatelessMode</i>     DHCPv6 client mode
-- </ul>
--
-- @return  status, errCode

function nimfConn.configure(conf)
    local status = "ERROR"
    local errCode = ""
    
    -- validate configuration
    status, errCode = nimfConn.confValidate(conf)
    if (status ~= "OK") then
        nimf.dprintf("nimfConn.configure: failed to validate configuration")
        return status, errCode
    end        

    -- update configuration
    status, errCode = nimfConn.confUpdate(conf)
    if (status ~= "OK") then
        nimf.dprintf("nimfConn.configure: failed to update configuration")
        return status, errCode
    end        

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name nimfConn.deconfigure
--
-- @description This function stops the connection and deletes all its
-- configuration
--
-- @param  connID  the connection ID
-- <ul>
-- <li><i> LogicalIfName</i>    Logical Name of this network
-- <li><i> AddressFamily</i>    network protocol of the connection
-- <li><i> ConnectionKey</i>    connection key. (Optional. Default = 0)
-- </ul>
--
-- @return  status OK or ERROR
-- @return  errCode error code string
--

function nimfConn.deconfigure(connID)
    local connType
    local status = "ERROR"
    local errCode = ""

    nimf.dprintf("network.deconfigure:Stopping connection:" .. nimf.connStrGet(connID))

    -- stop the connection
    nimfLib.connStop(connID)

    --
    -- Wait until the connection stops..
    -- But this gives a bad user experience.
    --

    -- update configuration
    status, errCode = nimfConn.confDelete(connID)
    if (status ~= "OK") then
        return status, errCode
    end        

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name nimfConn.statusGet 
--
-- @description The function gets the status of the given connection
--
-- @param  connID  the connection ID
-- <ul>
-- <li><i> LogicalIfName</i>    Logical Name of this network
-- <li><i> AddressFamily</i>    network protocol of the connection
-- <li><i> ConnectionKey</i>    connection key. (Optional. Default = 0)
-- </ul>
--
-- @return  status OK or ERROR
-- @return  errCode error code string
-- @return  connection status table
--

function nimfConn.statusGet (connID)
    local status
    local errCode
    local connstatus = {}
    local addrTbl = {}
    local dnsTbl = {}

    status, errCode = nimfConn.IDValidate (connID) 
    if (status ~= "OK") then
        return status, errCode        
    end        

    connstatus, errCode = nimfLib.connGet(connID)
    if (connstatus == nil) then
        return status, errCode        
    end        

    connstatus["addrs"] = {}
    status, errCode, addrTbl = nimfConn.ipAddrGet(connID) 
    if (status == "OK") then
        connstatus["addrs"] = addrTbl
    end        

    connstatus["dns"] = {}
    status, errCode, dnsTbl = nimfConn.dnsGet(connID) 
    if (status == "OK") then
        connstatus["dns"] = dnsTbl
    end        

    return "OK","STATUS_OK", connstatus
end

-------------------------------------------------------------------------------
-- @name nimfConn.confGet
--
-- @description This function gets the current configuration of this
-- connection.
--
-- @param  connID  the connection ID
-- <ul>
-- <li><i> LogicalIfName</i>    Logical Name of this network
-- <li><i> AddressFamily</i>    network protocol of the connection
-- <li><i> ConnectionKey</i>    connection key. (Optional. Default = 0)
-- </ul>
--
-- @return  status OK or ERROR
-- @return  errCode error code string
-- @return  conf the table that was passed as an argument to nimfConn.configure()
--
-- @see nimfConn.configure()
--

function nimfConn.confGet(connID)
    local status="ERROR"
    local errCode=""
    local conf = {}

    -- get the connection configuration
    status, errCode, conf = nimfConn.cfgGet (connID)
    if (status ~= "OK") then
        return status, errCode
    end        
    
    -- get the method configuration
    status, errCode, conf = nimfConn.methodConfGet(conf)
    if (status ~= "OK") then
        return status, errCode
    end        

    return "OK", "STATUS_OK", conf
end

-------------------------------------------------------------------------------
-- @name nimfConn.defConfGet
--
-- @description This function gets the default configuration of a
-- give connection type
--
-- @param  connID  the connection ID
-- <ul>
-- <li><i> LogicalIfName</i>    Logical Name of this network
-- <li><i> AddressFamily</i>    network protocol of the connection
-- <li><i> ConnectionKey</i>    connection key. (Optional. Default = 0)
-- <li><i> ConnectionType</i>   type of connection.
-- </ul>
--
-- @return  status OK or ERROR
-- @return  errCode error code string
-- @return  conf the table that was passed as an argument to nimfConn.configure()
--
-- @see nimfConn.configure()
--

function nimfConn.defConfGet(connID)
    local status="ERROR"
    local errCode=""
    local conf = {}

    -- get the default connection configuration
    conf = nimfConn.defCfgGet (connID)
    
    -- get the default method configuration
    status, errCode, conf = nimfConn.methodDefConfGet(conf)
    if (status ~= "OK") then
        return status, errCode
    end        

    return "OK", "STATUS_OK", conf
end

-------------------------------------------------------------------------------
-- @name nimfConn.isUp
--
-- @description  This function returns true if any connection is up for the 
-- given network
--
-- @param  LogicalIfName   Logical Name of this network
--
-- @return  true or false
--

function nimfConn.isUp (LogicalIfName)
    local status 

    assert(LogicalIfName, "LogicalIfName not provided")

    local status = nimfLib.isNetworkUp(LogicalIfName)
    if (status < 0) then
        return false
    end        

    return true
end

-------------------------------------------------------------------------------
-- @name nimfConn.isIPv4Up
--
-- @description  This function returns true if an IPv4 connection is up for the 
-- given network
--
-- @param  LogicalIfName   Logical Name of this network
--
-- @return  true or false
--

function nimfConn.isIPv4Up (LogicalIfName)
    local status 

    assert(LogicalIfName, "LogicalIfName not provided")

    local status = nimfLib.isNetworkUp(LogicalIfName)
    if (status < 0) then
        return false
    end        

    if (status == nimfConn.status.NIMF_NET_F_IPV4_UP) then
        return true
    end                

    if (status == 
        (nimfConn.status.NIMF_NET_F_IPV4_UP + 
         nimfConn.status.NIMF_NET_F_IPV6_UP)) then
        return true
    end                

    return false
end

-------------------------------------------------------------------------------
-- @name nimfConn.isIPv6Up
--
-- @description  This function returns true if an IPv4 connection is up for the 
-- given network
--
-- @param  LogicalIfName   Logical Name of this network
--
-- @return  true or false
--

function nimfConn.isIPv6Up (LogicalIfName)
    local status 

    assert(LogicalIfName, "LogicalIfName not provided")

    local status = nimfLib.isNetworkUp(LogicalIfName)
    if (status < 0) then
        return false
    end        

    if (status == nimfConn.status.NIMF_NET_F_IPV6_UP) then
        return true
    end                

    if (status == 
        (nimfConn.status.NIMF_NET_F_IPV4_UP + 
         nimfConn.status.NIMF_NET_F_IPV6_UP)) then
        return true
    end                

    return false
end

--[[
*******************************************************************************
-- @name nimfConn.methodInit
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.methodInit(conf)
    local connType
    local status = "ERROR"
    local errCode = ""

    -- check if the connection type is supported
    connType = nimfConn.isMethodSupported(conf["ConnectionType"])
    if ((connType == nil) or (connType == nimf.method.NIMF_CONN_NONE)) then
        nimf.dprintf("network.methodInit:Connection type(" .. 
                     conf["ConnectionType"] or 'NULL'.. ") not supported")
        errCode = "NET_ERR_INVALID_CONN_TYPE"
        return status, errCode
    end        

    if (connType == nimf.method.NIMF_IPV4_CONN_PPTP) then
        status, errCode = nimfConn.ipv4PPTPTransportEnable(conf)
    elseif (connType == nimf.method.NIMF_IPV4_CONN_L2TP) then
        status, errCode = nimfConn.ipv4L2TPTransportEnable(conf)
    else
        return "OK", "STATUS_OK"
    end

    return status, errCode
end

--[[
*******************************************************************************
-- @name nimfConn.methodDeInit
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.methodDeInit(conf)
    local connType
    local status = "ERROR"
    local errCode = ""

    -- check if the connection type is supported
    connType = nimfConn.isMethodSupported(conf["ConnectionType"])
    if ((connType == nil) or (connType == nimf.method.NIMF_CONN_NONE)) then
        nimf.dprintf("network.methodDeInit:Connection type(" .. 
                     conf["ConnectionType"] or 'NULL'.. ") not supported")
        errCode = "NET_ERR_INVALID_CONN_TYPE"
        return status, errCode
    end        

    if (connType == nimf.method.NIMF_IPV4_CONN_PPTP) then
        status, errCode = nimfConn.ipv4PPTPTransportDisable(conf)
    elseif (connType == nimf.method.NIMF_IPV4_CONN_L2TP) then
        status, errCode = nimfConn.ipv4L2TPTransportDisable(conf)
    else
        return "OK", "STATUS_OK"
    end

    return status, errCode
end
