-- @copyright Copyright (c) 2012, TeamF1, Inc. 

slaac = {}

-- C slaac library
require "teamf1lualib/db"
require "slaacLib"

function slaac.config (inputTable, rowid, operation)
    if (operation == "add") then
        return db.insert("slaac", inputTable)
    elseif (operation == "edit") then
        return db.update("slaac", inputTable, rowid)
    elseif (operation == "delete") then
        return nil
    end
end

function slaac.import (configTable, defaultConfigTable, removeConfig)

    local slaacTable = {}
    if (configTable ~= nil) then
        slaacTable = config.update (configTable, defaultConfigTable, removeConfig)
        if (slaacTable ~= nil and #slaacTable ~= 0) then 
            for i,v in ipairs (slaacTable) do
                v = util.addPrefix (v, "slaac.");
                slaac.config (v, -1, "add")
            end
        end
    end
end

function slaac.export ()
    return db.getTable ("slaac", false)
end

if (config.register) then
   config.register("slaac", slaac.import, slaac.export, "1")
end
