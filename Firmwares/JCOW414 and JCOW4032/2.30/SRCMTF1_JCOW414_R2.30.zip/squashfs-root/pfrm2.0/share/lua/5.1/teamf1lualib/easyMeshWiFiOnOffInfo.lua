--[[ easyMeshWiFiOnOff.lua - Handler for Easy Mesh WiFi On Off Change.
--
-- Copyright (c) 2008-2014, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: easyMeshWiFiOnOff.lua
-- Description: Handler for Easy Mesh WiFi On off Change.
-- 
-- modification history
-- --------------------
-- 01a, 15Jun21, vin written.
--
--]]

require "easyMeshLib"
require "ifDevLib"
require "teamf1lualib/dot11"
require "teamf1lualib/dot11_ul"
require "teamf1lualib/gui"


local CMD_EXEC_SCRIPT = "/tmp/cmdExecscript.sh"
local SH_BIN          = "/bin/sh "


-- Initialise the SSIDGetResponse_t Lua Table which will be coverted as JSON Object
local WiFiSetResponse_t = {
    ["Result"] = "ERROR",
    ["Response_Code"] = "400",
    ["Error_Message"] = "Failed to Set WiFiConfig"
}

-- Supported Return Codes for "SSIDGetResponse"
local WiFiSetResponse_ReturnCodes = {
    ["OK"] = "OK",
    ["ERROR"] = "ERROR",
    ["SUCCESS"] = "Success",
    ["FAILED"]  = "Failed",
}


----------------------------------------------
--WiFi On Off Set Request
--
-- @description This function Handles EasyMesh WiFi On Off Set Request Method.
--
--returns JSON response for EasyMesh WiFiOnOff Set Request
--
function WiFiOnOffInfoHandler(methodObj, meshRequestMethod)

    require "teamf1lualib/easyMeshMgmt"
    local status = "ERROR"
    local errorFlag
    local inputTable = {}
    local rowid="1"
  
    inputTable["wifiOn"] = methodObj["WiFi_Enable"]
    --inputTable["Device_Mac"] = methodObj["Device_MAC"]
    
    --sanity Check
    
    --if((inputTable["wifiOn"] == nil) or (inputTable["Device_Mac"] == nil) or (string.upper(inputTable["Device_Mac"]) ~= ifDevLib.getMac("bdg2")) ) then
    if((inputTable["wifiOn"] == nil)) then
        WiFiSetResponse_t["Result"] = WiFiSetResponse_ReturnCodes["FAILED"]  
        WiFiSetResponse_t["Response_Code"] = "400"
        WiFiSetResponse_t["Error_Message"] = "Bad Request"
        --mesh.sendResponse (WiFiSetResponse_t) 
        return "ERROR", "INVALID_METHOD", WiFiSetResponse_t
    end

    
    local easyMeshRow = db.getRowWhere("easyMesh", "_ROWID_ ='" ..rowid.."'" , false)
    
    if(easyMeshRow["wifiOn"] == inputTable["wifiOn"]) then
            status = "OK"
    end

    if(status == "OK") then
        WiFiSetResponse_t["Result"] = WiFiSetResponse_ReturnCodes["OK"]  
        WiFiSetResponse_t["Error_Message"] = nil
        WiFiSetResponse_t["Response_Code"] = "200"
        WiFiSetResponse_t["Device_Mac"] = ifDevLib.getMac("bdg2")
        --mesh.sendResponse (WiFiSetResponse_t) 
        return "OK", "SUCCESS", WiFiSetResponse_t
    end

    --WiFiOnOff 
   status,errorFlag = easyMeshMgmt.easyMeshWifiSet(inputTable) 

    if(status ~= "OK") then
        WiFiSetResponse_t["Result"] = WiFiSetResponse_ReturnCodes["FAILED"]  
        WiFiSetResponse_t["Response_Code"] = "400"
        WiFiSetResponse_t["Error_Message"] = "WiFi is Disabled,No WiFi Operation is Allowed"
        --mesh.sendResponse (WiFiSetResponse_t) 
        return "ERROR", "INVALID_METHOD",WiFiSetResponse_t
    end    
 
    --Save to DB
    db.save2()

    WiFiSetResponse_t["Result"] = WiFiSetResponse_ReturnCodes["OK"]  
    WiFiSetResponse_t["Error_Message"] = nil
    WiFiSetResponse_t["Response_Code"] = "200"
    WiFiSetResponse_t["Device_Mac"] = inputTable["Device_Mac"]
    --mesh.sendResponse (WiFiSetResponse_t) 
    return "OK", "SUCCESS", WiFiSetResponse_t

end

meshRequestMethodsList["WiFiOnOff"]["methodHandler"] = WiFiOnOffInfoHandler

