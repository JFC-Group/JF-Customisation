-- @copyright Copyright (c) 2012, TeamF1, Inc. 

require "teamf1lualib/evtDsptch"
require "ripngLib"
require "appExtn/AppExtn"

RipngExtn = OoUtil.inheritsFrom(AppExtn)
RipngExtn.name    = "RIP-NG(IPv6)"
RipngExtn.className   = "RipngExtn"
RipngExtn.classId = "ripng"
RipngExtn.dbTable = "Ripng"
RipngExtn.logger  = nil

local SUPER = require("appExtn.AppExtn")

local netEvents  = {}
netEvents[evtDsptch.event.IFDEV_EVENT_IP6_NET_UP] =  1
netEvents[evtDsptch.event.IFDEV_EVENT_IP6_NET_DOWN] =  1

local cfgEvents = {}
cfgEvents[db.event.SQLITE_INSERT] = 1
cfgEvents[db.event.SQLITE_UPDATE] = 1
cfgEvents[db.event.SQLITE_DELETE] = 1

-------------------------------------------------------------------------------
-- @name RipngExtn:new
--
-- @description This function creates a new instance object for ripng, loads
-- the configuration and event subcriptions
--
-- @return  0 for success and -1 for error
--

function RipngExtn:new(instanceId, props)

    assert(instanceId, "Instance ID must be specified")

    -- create a new instance
    self = RipngExtn.create()

    SUPER.new(self, RipngExtn.classId, instanceId, props)

    self.name  = RipngExtn.name
    self.dbTable = RipngExtn.dbTable
    self.dbconn = RipngExtn.dbconn
    self.logger = RipngExtn.logger

    -- initialize events for this instance
    self.netEvents = netEvents              
    self.cfgEvents = cfgEvents

    -- register with appd
    appd.appExtnRegister(self)                    

    -- load the configuration for this instance          
    local status = self:load()
    if (status < 0) then
        LOG:error("failed to load " .. self.classId .. 
                  "(" .. self.instanceId .. ")")
        return nil
    end        

    return self
end

-------------------------------------------------------------------------------
-- @name RipngExtn:load
--
-- @description This function loads the configuration for the application
--
-- @return  
--

function RipngExtn:load() 
    require "teamf1lualib/nimf"

    local status, errCode, self = SUPER.load(self)
    if (status == nil) then
        LOG:error(self.name .. "failed to load ripng configuration")        
        return -1
    end        

    return 0
end        

-------------------------------------------------------------------------------
-- @name RipngExtn:delete
--
-- @description This function destroys an instance of this extension
--
-- @return  
--

function RipngExtn:delete() 
    appd.appExtnUnregister(self)
    return 
end        

-------------------------------------------------------------------------------
-- @name RipngExtn:stop
--
-- @description This function stops ripng
--
-- @return  0 for success and -1 for error
--

function RipngExtn:stop ()

    LOG:info("Stopping " .. self.name ..  "(" ..  self.instanceId .. ")")

    ripngLib.stop()

    return 0
end

-------------------------------------------------------------------------------
-- @name RipngExtn:start
--
-- @description This function starts ripng
--
-- @return  0 for success and -1 for error
--

function RipngExtn:start ()

    LOG:info("Starting " .. self.name ..  "(" ..  self.instanceId .. ")")

    -- is configuration enabled
    if (not self:isEnabled()) then
        return 0
    end 

    self.ifList = {}
            
    local status, errCode, connList = nimf.connListGet ()
    if (connList == nil) then
        LOG:error(self.name .. "failed to get list of ipv6 interfaces")        
        return  -1
    end        

    -- get list of all ipv6 connections            
    for k,v in pairs(connList) do
        if ((tonumber(v["AddressFamily"])  == nimf.proto.NIMF_PROTO_TYPE_IPV6) and
            (tonumber(v["StateVal"]) == nimfConn.StateVal.NIMF_CONN_STATE_CONNECTED)) then
            table.insert (self.ifList, v["Interface"])
        end            
    end
            
    ripngLib.cfgLoad(self.ifList);

    local status = ripngLib.start()
    if (status < 0) then
        LOG:error(self.name .. " start failed")
        return status
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name RipngExtn:restart
--
-- @description This function restarts ripng
--
-- @return  0 for success and -1 for error
--

function RipngExtn:restart ()

    LOG:info("Re-starting " .. self.name ..  "(" ..  self.instanceId .. ")")

    self:stop()

    local status = self:start()
    if (status < 0) then
        return status
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name RipngExtn:isEnabled
--
-- @description This function checks the configuration if ripng is enabled
--
-- @return  
--

function RipngExtn:isEnabled()
    local props = self:getProps()

    if (tonumber(props.RipngEnable) > 0) then
        return true
    end        

    return false
end

-------------------------------------------------------------------------------
-- @name RipngExtn:getAppName
--
-- @description This function gets the name of this extension
--
-- @return  
--

function RipngExtn:getAppName()
   return self.name
end

-------------------------------------------------------------------------------
-- @name RipngExtn:getDbTableName
--
-- @description This function gets the database table name which contains
-- configuration records for all instances of this application.
--
-- @return  
--

function RipngExtn:getDbTableName()
   return self.dbTable
end

-------------------------------------------------------------------------------
-- @name RipngExtn:onNetEvent
--
-- @description This function handles network events for ripng
--
-- @param  netevent event info
--
-- @return  0 for success and -1 for error
--

function RipngExtn:onNetEvent(netevent)

    if (self:isEventSubscribed(netevent) == false) then
        LOG:ddebug(self.classId .. " not subscribed to event: " ..
                  netevent.event .. " on " .. netevent.ifname)
        return 0
    end        

    -- re-load configuration and interface list
    self:load()

    -- restart
    self:restart()

    return 0
end

-------------------------------------------------------------------------------
-- @name RipngExtn:isEventSubscribed
--
-- @description This function checks if this instance is subcribed to
-- the event pass as input
--
-- @param event event info
--
-- @return  0 for success and -1 for error
--

function RipngExtn:isEventSubscribed(event)

    if (event.type == appd.eventType.APPD_EV_NET) then
        
        local evstate = self.netEvents[event.event]
        if (evstate == nil) then
            return false
        end            
                    
        if (evstate > 0) then
            return true
        end        

    elseif (event.type == appd.eventType.APPD_EV_CFG) then

        -- are we subscribed to this event                        
        local evstate = self.cfgEvents[event.event]
        if (evstate == nil) then
            return false
        end            

        if (evstate > 0) then
            return true
        end        
    end

    return false
end

-------------------------------------------------------------------------------
-- @name RipngExtn:onCfgEvent
--
-- @description This function is called by appd to handle configuration events
-- 
-- @param  cfgevent event information
--
-- @return  
--

function RipngExtn:onCfgEvent(cfgevent)

    if (self:isEventSubscribed(cfgevent) == false) then
        LOG:ddebug(self.classId .. " not subscribed to event: " ..
                   cfgevent.event .. " on " .. cfgevent.dbTable)
        return
    end        

    if (cfgevent.event == db.event.SQLITE_INSERT) then
        -- start ripng
        self:start()
    elseif (cfgevent.event == db.event.SQLITE_UPDATE) then
        -- re-load configuration and interface list
        self:load()

        -- restart ripng
        self:restart()
    elseif (cfgevent.event == db.event.SQLITE_DELETE) then
        self:stop()
    end                

    return
end

-------------------------------------------------------------------------------
-- @name RipngExtn:print
--
-- @description This function is called by appd to bootstrap all instances of 
-- this application. 
--
-- @param  
--
-- @return  
--

function RipngExtn:print()
    require "util/strlib"

    LOG:info("Class     : " .. self.classId)
    LOG:info("Instance  : " .. self.instanceId)
    LOG:info("App Name  : " .. self:getAppName())
    LOG:info("Conf      : " .. strlib.serializeTbl(self:getProps()))
    return
end

-------------------------------------------------------------------------------
-- @name RipngExtn.cfgEventCallback
--
-- @description 
--
-- @param  
--
-- @return  
--

function RipngExtn.cfgEventCallback(obj, info)

    LOG:ddebug(RipngExtn.classId .. " configuration callback called  " .. 
               "for event: " ..  info.event .. " on rowId " .. info.rowId)

    if (info.event == db.event.SQLITE_INSERT) then
        if (obj ~= nil) then 
            assert(nil, obj.classId .. "(" .. obj.rowId  .. ")" ..
                   "already created")
            return -1
        end        

        -- create instance and process event
        obj = RipngExtn:new(info.rowId)
        if (obj) then 
            obj:onCfgEvent(info) 
        end

    elseif (info.event == db.event.SQLITE_UPDATE) then
        -- process event
        if (obj) then 
            obj:onCfgEvent(info) 
        end
    elseif (info.event == db.event.SQLITE_DELETE) then
        -- process event and destroy instance
        if (obj) then
            obj:onCfgEvent(info)
            self:delete()
        end
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name RipngExtn.bootstrap
--
-- @description This function is called by appd on startup to bootstrap all 
-- instances of this application. 
--
-- @param  
--
-- @return  
--

function RipngExtn.bootstrap()
    local instanceId=nil
    local callbackTable= {}

    ripngLib.killAll()

    local callback = {}
    callback.type = appd.eventType.APPD_EV_CFG
    callback.dbTable = RipngExtn.dbTable
    callback.routine = RipngExtn.cfgEventCallback
    table.insert(callbackTable, callback)
    appd.callbackRegister (RipngExtn.classId, callbackTable)

    local cfg = db.getTable(RipngExtn.dbTable, false)
    if (cfg == nil) then
        return 0
    end        

    for index, record in pairs(cfg) do
        instanceId = record["_ROWID_"]

        -- create an instance and restart it
        local obj = RipngExtn:new(instanceId)
        if (obj and obj:isEnabled()) then
            obj:start()
        end                        
    end

    return 0
end

return RipngExtn
