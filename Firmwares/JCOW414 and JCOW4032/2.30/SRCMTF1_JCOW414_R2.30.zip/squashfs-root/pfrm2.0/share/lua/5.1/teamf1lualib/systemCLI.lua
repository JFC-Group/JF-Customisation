-- systemCLI.lua 
-- Gaurav Mathur
-- TeamF1
-- 10/23/07
--
-- Modification History
-- 09apr08,rbh removed a soln specific check
-- 25dec07,gnm Added check for nil firmwareVer and system name fields
--	       in sysInfoGet; Added alias interface name argument
--	       value to aliasipGet() call in sysStatusGet; Added
--	       ethCLISingleGet() calls to display eth1 and eth0
--	       information for show system status command
-- 24dec07,gnm modified sysLogFacilityInfoGet() to add check for
--	       invalid facility values
-- 28nov07 gnm written
--
-- Description
-- CLISH system LUA routines
--

local dayTab = {
"Sunday", 
"Monday",
"Tuesday",
"Wednesday",
"Thursday", 
"Friday", 
"Saturday",
}

local timezoneTab= {
"(GMT) Greenwich Mean Time : Edinburgh, London",
"(GMT-12:00) Eniwetok,Kwajalein",
"(GMT-11:00) Midway Island,Samoa",
"(GMT-10:00) Hawaii",
"(GMT-09:30) Marqesas Is.",
"(GMT-09:00) Alaska",
"(GMT-08:30) Pitciarn Is.",
"(GMT-08:00) Pacific Time(Canada); Tijuana",
"(GMT-08:00) Pacific Time(US); Tijuana",
"(GMT-07:00) Mountain Time, Arizona(Canada)",
"(GMT-07:00) Mountain Time, Arizona(US)",
"(GMT-06:00) Mexico City(US, Canada)",
"(GMT-06:00) CentralTime(USA)",
"(GMT-05:00) EasternTime",
"(GMT-05:00) EasternTime(USA),Lima,Indiana East",
"(GMT-04:00) Atlantic Time(Canada), Caracas",
"(GMT-03:30) Newfoundland",
"(GMT-03:00) Brasilia, Buenos Aires",
"(GMT-02:00) Mid-Atlantic",
"(GMT-01:00) Azores, Cape Verde Is.",
"(GMT+01:00) Europe",
"(GMT+02:00) Athens, Istanbul, Minsk, Cairo",
"(GMT+03:00) Baghdad, Kuwait, Moscow",
"(GMT+03:30) Tehran",
"(GMT+04:00) Abu Dhabi, Muscat, Baku",
"(GMT+04:30) Kabul",
"(GMT+05:00) Ekaterinburg, Islamabad, Karachi",
"(GMT+05:30) Bombay, Calcutta, Madras, Delhi",
"(GMT+06:00) Almaty, Dhaka, Colombo",
"(GMT+06:30) Burma",
"(GMT+07:00) Bangkok, Hanoi, Jakarta",
"(GMT+08:00) Beijing, Chongqing, Hong Kong",
"(GMT+09:00) Osaka, Sapporo, Tokyo, Seoul",
"(GMT+09:30) Adelaide, Darwin",
"(GMT+10:00) Brisbane, Guam, Port Moresby",
"(GMT+10:30) Lord Howe Is.",
"(GMT+11:00) Magadan, Solomon Is, New Caledonia",
"(GMT+11:30) Norfolk I.",
"(GMT+12:00) Auckland, Wellington, New Zealand, Fiji",
"(GMT+13:00) Tonga",
"(GMT+14:00) Kiribati,Western Samoa"
}

function tzInfoGet ()
    local resultTab = {}
    local idx = "1"
    row = db.getRow("ntp", "ntp._ROWID_", 1) -- the ntp table should
					--only have one entry
    resTab.insertField (resultTab, "Current Time", util.time())
    idx = tonumber(row["ntp.timezone"])
    idx = idx + 1
    resTab.insertField (resultTab, "Timezone", timezoneTab[idx])
    if (row["ntp.autoDaylight"] == "1") then 
       resTab.insertField (resultTab, "Automatically Adjust for Daylight " ..
       				      "Savings Time", "Yes")
    else
       resTab.insertField (resultTab, "Automatically Adjust for Daylight " ..
				      "Savings Time", "No")
    end				     
    if (row["ntp.useDefServers"] == "1") then
       resTab.insertField (resultTab, "Default NTP servers used ", "Yes")
    else
       resTab.insertField (resultTab, "Default NTP servers used ", "No")
       resTab.insertField (resultTab, "Server 1 Name / IP Address",
			  row["ntp.server1"])
       resTab.insertField (resultTab, "Server 2 Name / IP Address",
			  row["ntp.server2"])
    end

    return resultTab 	    
end

--
-- This routine returns the Identifier that's prepended to all log messages
-- in the system
--
function logIdentifierGet ()
    local ident = db.getAttribute("emailLogs","_ROWID_",1,"logId")
    return ident
end

--
-- This routine returns the Syslog server set on the system
--
function syslogServerGet ()
    return db.getAttribute("sysLogInfo","_ROWID_", 1, "serverName")
end

function sysLogFacilityInfoGet (facility)

    if (facility == nil) then --sanity check
       local resultTab = {}
       resTab.insertField (resultTab, "", "No such facility")
       return resultTab
    end

    local logTab = db.getRow ("logConfig", "logConfig.facility", facility)
    if (logTab == nil) then --sanity check
       local resultTab = {}
       resTab.insertField (resultTab, "", "No such facility")
       return resultTab
    end

    local resultTab = resTab.createRowLbl ("Emergency", "Alert", "Critical", 
	    "Error", "Warning",	"Notification", "Information", "Debugging")
    
    local emergencyChoices = util.integerToBits(logTab["logConfig.emergency"])
    local alertChoices = util.integerToBits(logTab["logConfig.alert"])
    local criticalChoices = util.integerToBits(logTab["logConfig.critical"])
    local errorChoices = util.integerToBits(logTab["logConfig.error"])
    local warningChoices = util.integerToBits(logTab["logConfig.warning"])
    local noticeChoices = util.integerToBits(logTab["logConfig.notice"])
    local informationChoices = util.integerToBits(logTab["logConfig.information"])
    local dbgChoices = util.integerToBits(logTab["logConfig.debug"])
    
    local idxTab = {1,3,4}
    for i, idx in ipairs (idxTab) do
	if (idx == 1) then colLbl = "Display in event log"
	elseif (idx == 3) then colLbl = "Send to syslog"
	elseif (idx == 4) then colLbl = "Display on telnet/SSH monitor"
	end
	
	resTab.insertYNField (resultTab, emergencyChoices[idx] == 1, colLbl)
        resTab.insertYNField (resultTab, alertChoices[idx] == 1, colLbl)
	resTab.insertYNField (resultTab, criticalChoices[idx] == 1, colLbl)
        resTab.insertYNField (resultTab, errorChoices[idx] == 1, colLbl)
	resTab.insertYNField (resultTab, warningChoices[idx] == 1, colLbl)
	resTab.insertYNField (resultTab, noticeChoices[idx] == 1, colLbl)
	resTab.insertYNField (resultTab, informationChoices[idx] == 1,colLbl)
	resTab.insertYNField (resultTab, dbgChoices[idx] == 1, colLbl)
    end

    return resultTab 	    
end

--
--
--
local function eth2Get ()
    local resultTab = {}
    local row = db.getRowWithJoin(
	  	  {"ethernet:networkInterface:interfaceName"}, 
		  "ethernet.interfaceName", "eth1")
    if (row["ethernet.vlanEnabled"] == "0") then
        row["ethernet.vlanId"]= "0";
    end
    resTab.insertField (resultTab, "MAC Address",
		       row["ethernet.macAddress"] or "")
    resTab.insertField (resultTab, "IP Address", 
		       row["networkInterface.ipaddr"])
    resTab.insertField (resultTab, "IP Subnet Mask", 
		       row["networkInterface.subnetmask"])
    resTab.insertField (resultTab, "Gateway IP Address", 
		       row["networkInterface.gateway"] or "")
    resTab.insertField (resultTab, "DNS Server", 
		       row["networkInterface.dns1"] or "")
    resTab.insertField (resultTab, "VLAN", vlanId or "")
    return resultTab    
end


--
--
--
local function eth1Get ()
    local resultTab = {}

    local rowBdg = db.getRowWithJoin(
		 {"bridgeTable:networkInterface:interfaceName"},
		 "bridgeTable.interfaceName", "bdg")
    local rowEth = db.getRowWithJoin({"ethernet:networkInterface:interfaceName"},
		 "ethernet.interfaceName", "eth0")
    local vlanId = "0";

    if (rowEth["ethernet.vlanEnabled"] == "1") then 
       vlanId = db.getAttribute("ethernet", "interfaceName", "eth0", "vlanId")
    end

    resTab.insertField (resultTab, "MAC Address",
		       rowBdg["bridgeTable.macAddress"] or "")
    resTab.insertField (resultTab, "IP Address", 
		       rowBdg["networkInterface.ipaddr"])
    resTab.insertField (resultTab, "IP Subnet Mask", 
		       rowBdg["networkInterface.subnetmask"])
    resTab.insertField (resultTab, "Gateway IP Address", 
		       rowBdg["networkInterface.gateway"] or "")
    resTab.insertField (resultTab, "DNS Server", 
		       rowBdg["networkInterface.dns1"] or "")
    resTab.insertField (resultTab, "VLAN", vlanId or "")
    return resultTab
end

--
-- build SNMP result table
-- 
local function buildSNMP (resultTab, row)
    if (row == nil) then return end --sanity check

    resTab.insertField (resultTab, "IP Address", row["snmpTrap.ipAddr"])
    resTab.insertField (resultTab, "Subnet Mask", row["snmpTrap.subnetMask"])
    resTab.insertField (resultTab, "Port", row["snmpTrap.port"])
    resTab.insertField (resultTab, "Community", row["snmpTrap.commName"])
end

--
-- This routine gets the system SNMP configuration
-- 
function sysSNMPConfigGet ()
    local resultTab = {}

    row = db.getRow ("system","system._ROWID_", 1)
    if (row == nil) then
       return nil
    end
    resTab.insertField (resultTab, "SysContact", row["system.sysContact"] or "")
    resTab.insertField (resultTab, "SysLocation", row["system.sysLoc"] or "")
    resTab.insertField (resultTab, "SysName", row["system.name"])
    return resultTab
end

--
-- get general system information
-- 
local function sysInfoGet (args)
    local resultTab = {}
    local system = db.getRow("system", "_ROWID_", "1")

    resTab.insertField (resultTab, "System Up Time", util.uptime())
    resTab.insertField (resultTab, "System Name", 
		       system["system.name"] or "")
    resTab.insertField (resultTab, "Firmware Version", 
		       system["system.firmwareVer"] or "")

    local userRow = db.getRow("users", "username", "admin")
    local val = userRow["users.loginTimeout"] .. " (Minutes)"
    resTab.insertField (resultTab, "Administrator login times out " ..
		       "after idle for", val)

    return resultTab
end

--
--
--
local function hourStringMake (field)
    local hour = "-1"

    if (field == nil) then return hour end --sanity check
    hour = tonumber (field)
    if (hour >= 0 and hour < 12) then         
	hour = hour .. ":00" .. " A.M."
    elseif (hour >= 12 and hour <= 23) then
	hour = hour - 12
	hour = hour .. ":00" .. " P.M."
    end
    return hour     
end


--
--
--
local function schedGet (resultTab, cmd)
    row = db.getRow ("cronTab", "command", cmd)
    if (row == nil) then
        resTab.insertField (resultTab, "Unit", "Never")
	resTab.insertField (resultTab, "Day", "-")
	resTab.insertField (resultTab, "Time", "-")
	return resultTab
    end
    if (row["cronTab.unit"] == "1") then
        resTab.insertField (resultTab, "Unit", "Hourly")
        resTab.insertField (resultTab, "Day", "-")
        resTab.insertField (resultTab, "Time", "-")
    elseif (row["cronTab.unit"] == "2") then                    
        resTab.insertField (resultTab, "Unit", "Daily")
        resTab.insertField (resultTab, "Day", "-")
        resTab.insertField (resultTab, "Time", hourStringMake(row["cronTab.hour"]))
    elseif (row["cronTab.unit"] == "3") then
	resTab.insertField (resultTab, "Unit", "Weekly")
	local day = row["cronTab.dayOfWeek"]
	day = tonumber(day) + 1
	resTab.insertField (resultTab, "Day", dayTab[day])
	resTab.insertField (resultTab, "Time", hourStringMake(row["cronTab.hour"]))
    end
end

--
--
--
function sysSchedGet ()
    local resultTab = resTab.create ()
        
    emailLogs = db.getAttribute ("emailLogs", "_ROWID_", 1, "mailLogs")
    if (emailLogs ~= "1") then
       return nil
    end

    schdCmd = db.getAttribute("environment","name","EMAILLOGS_PROGRAM","value") .. 
	    " " .. DB_FILE_NAME
    schedGet (resultTab, schdCmd)	
    return resultTab
end

--
--
--
function sysEmailLogGet ()
    local resultTab = resTab.create ()

    emailLogs = db.getAttribute ("emailLogs", "_ROWID_", 1, "mailLogs")
    if (emailLogs ~= "1") then
       return nil
    end

    local entryName = db.getAttribute("emailLogs","_ROWID_",1,"entryName")
    row = db.getRow ("smtpServer", "entryName", entryName)
    if (row == nil ) then
    else
        resTab.insertField (resultTab, "E-Mail Server Address", 
			   row['smtpServer.emailServer'])
        resTab.insertField (resultTab, "Return E-Mail Address", 
			   row['smtpServer.fromAddr'])
        resTab.insertField (resultTab, "Send to E-Mail Address", 
			   row['smtpServer.toAddr'])
        resTab.insertField (resultTab, "Send to E-Mail Address", 
			   row['smtpServer.toAddr'])

        local auth = row['smtpServer.auth']
	auth = tonumber (auth)
	local tmpStr = ""
	if (auth == -1) then tmpStr = "No Authentication" 
	elseif (auth == 0) then tmpStr = "Login Plain"
	elseif (auth == 1) then tmpStr = "CRAM-MD5"
	end
        resTab.insertField (resultTab, "Authentication", tmpStr)
	
	if (auth == 0 or auth == 1) then 
	   resTab.insertField (resultTab, "User Name", row['smtpServer.userName'])
	   resTab.insertField (resultTab, "Password", row['smtpServer.passWord'])
        end
	resTab.insertYNField (resultTab, row['smtpServer.respondIdentd'] == "1", 
			     "Respond to Identd from SMTP Server")
    end
    return resultTab
end

--
--
--
function sysEmailSchedGet (args)

    print ("\n" .. "Log Identifier: " .. logIdentifierGet())	 	 
    resultTab = sysEmailLogGet ()
    if (resultTab == nil) then
        print ("\n" .. "E-Mail logs are disabled" .. "\n")
    else	
        printLabel ("Enable E-Mail Logs")
        resTab.print (resultTab, 0)
    end
    resultTab = sysSchedGet()
    if (resultTab ~= nil) then
       printLabel ("Send E-mail logs by Schedule")
       resTab.print (resultTab, 0)
    end                       
end

--
-- main function for system get
-- 
function sysLoggingGet (args)
    local facility = args[1]
    local ident = logIdentifierGet() or "" 	  
    local server = syslogServerGet() or ""

    print ("\n" .. "Log Identifier: " .. ident)
    print ("Syslog Server: " .. server)

    printLabel ("Logs Facility and Level Configuration")
    if (facility == "all") then
       local logTab = db.getTable ("logConfig")
       for k, v in pairs (logTab) do
	   printLabel (v["logConfig.facility"])
	   resultTab = sysLogFacilityInfoGet(v["logConfig.facility"])
           resTab.print (resultTab)
       end
    else
       resultTab = sysLogFacilityInfoGet (facility)
       printLabel (facility)
       resTab.print (resultTab)
    end
end
--
-- main function for system get
-- 
function sysTimezoneGet (args)
    printLabel ("Time Zone & NTP Servers Configuration")    
    resultTab = tzInfoGet()
    resTab.print (resultTab, 0)    
end   

--
-- main function for system get
-- 
function sysUsersGet (args)
    printLabel ("User Selection")    
    resultTab = sysUserGet ()
    resTab.print (resultTab, 0)
    printLabel ("Available Access Points")
    resultTab = dot11APAllGet ()
    resTab.print (resultTab, 0)
    printLabel ("Ethernet Port 1")    
    resultTab = eth1Get()
    resTab.print (resultTab, 0)
    printLabel ("Ethernet Port 2")    
    resultTab = eth2Get()
    resTab.print (resultTab, 0)
end   

--
-- main function to get system status 
-- 
function sysStatusGet (args)
    printLabel ("System Info")    
    resultTab = sysInfoGet ()
    resTab.print (resultTab, 0)
    printLabel ("Available Access Points")
    resultTab = dot11APAllGet ()
    resTab.print (resultTab, 0)
    printLabel ("TCP/IP Settings")    
    resultTab = eth1Get()
    resTab.print (resultTab, 0)
    printLabel ("Alias IP Settings")
    resultTab = aliasipGet({"bdg:0"})
    resTab.print (resultTab, 0)
    printLabel ("Ethernet Port1")
    resultTab = ethCLISingleGet ("eth0")
    resTab.print (resultTab, 0)
    printLabel ("Ethernet Port2")
    resultTab = ethCLISingleGet ("eth1")
    resTab.print (resultTab, 0)
end   

--
-- main function to get SNMP configuration information
-- 
function sysBOOTPGet (args)
    local resultTab1 = {}
    local resultTab2 = {}

    row = db.getRow ("bootpc", "bootpc._ROWID_", 1)
    if (row ~= nil) then
       resTab.insertYNField (resultTab1, row["bootpc.bootpUpgrade"] == "1",
			    "Enable Bootp upgrade")
       resTab.insertYNField (resultTab1, row["bootpc.bootTimeCheck"] == "1",
			    "Disable bootp check at boot time")
       resTab.insertField (resultTab1, "Bootp Server", row["bootpc.bootpServer"])
    else
       resTab.insertField (resultTab1, "", "BOOTP disabled")
    end
    
    cmd = db.getAttribute("environment","name","BOOTPC_DB_PROGRAM","value")
    cmd = cmd .. " " .. DB_FILE_NAME .. " " .. "bootpc"
    schedGet (resultTab2, cmd)

    printLabel ("Bootp Configuration")
    resTab.print (resultTab1, 0)
    printLabel ("Bootp Schedule Configuration")
    resTab.print (resultTab2, 0)
end

--
--
--
function sysUsageRepGet (args)
    local resultTab = {}

    schedGet (resultTab, "/pfrm2.0/bin/ifDevUsageRecord " .. DB_FILE_NAME)
    printLabel ("Usage Reports Schedule Configurations")
    resTab.print (resultTab, 0)    	
end

--
-- main function to get SNMP configuration information
-- 
function sysSNMPGet (args)
    local agentIP = args[1]
    local resultTab = {}

    sysCfgTab = sysSNMPConfigGet()
    if (sysCfgTab ~= nil) then
       printLabel ("SNMP System Configuration")
       resTab.print (sysCfgTab, 0)
    end
       
    if (agentIP == nil) then
        local snmpTab = db.getTable("snmpTrap")
	local idx = 0
	for k,v in pairs(snmpTab) do
	    idx = idx + 1
	    local row = snmpTab[idx]
	    buildSNMP (resultTab, row)
        end
    else 
	local row = db.getRow ("snmpTrap", "snmpTrap.ipAddr", agentIP)	
	buildSNMP (resultTab, row)
    end
    printLabel ("Trap Agent IP Address")
    resTab.print (resultTab, 0)
end    
