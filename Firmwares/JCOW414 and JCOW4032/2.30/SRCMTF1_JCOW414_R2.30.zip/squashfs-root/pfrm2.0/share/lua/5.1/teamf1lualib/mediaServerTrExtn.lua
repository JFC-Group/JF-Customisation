--[[
#### Copyright (c) 2014, TeamF1 Networks Pvt. Ltd. 
#### (Subsidiary of D-Link India)

#### 
#### File: tr181_mediaServerTrExtn.lua
#### Description: 
#### TR-181 handlers for MediaServer. This file is included from tr181_tr69funcs.lua
####

#### Revisions:
01a,20march18,aks written 
]]--

mediaServerTr = {}
local dbFlag = 0


--[[
--*****************************************************************************
-- mediaServerTr.dmsServerCfgGet: get the MediaServer values.
--                  
-- Enable
-- Status
-- 
-- Returns: status, value
]]--
function mediaServerTr.dmsServerCfgGet(input)
    local status = "0"
    local value = "0"
    local row = {}
    local query = nil
    local param = input["param"]

    --get corresponding db entry from dmsServerSettings
    query = "_ROWID_=1"
    row = db.getRowWhere ("dmsServerSettings", query, false)
    if (row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from dmsServerConfig 
    query = "_ROWID_=1"
    rowFr = db.getRowWhere ("dmsServerConfig", query, false)
    if (rowFr == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find & return parameter values
    if(string.find(input["param"], "DMS_Enabled")) then
        -- DMS_Enabled
        value = row["serverEnable"]
    elseif(string.find(input["param"], "FriendlyName")) then
        -- FriendlyName
            value= rowFr["friendlyName"]
            
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- mediaServerTr.dmsServerCfgSet: set DMS parameters.
--
-- This function is called to set the following parameters in
-- 
-- Enable
-- FriendlyName
--
-- Returns: status
-- 
]]--
function mediaServerTr.dmsServerCfgSet(input, rowids, actionType, tr69Param)
    local status = OK
    local faultTbl = {}
    local index = 0
    local query = nil
    local errMsg
    local dmsRow = {}

    query = "_ROWID_=1"
    dmsRow = db.getRowWhere ("dmsServerSettings", query, false)
    if(dmsRow == nil) then
        tr69Glue.tf1Dbg("Couldn't fetch corresponding dms server Row..")
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    if(input["dmsServerSettings"]["dmsServerSettings.serverEnable"] ~= nil) then
        status = input["dmsServerSettings"]["dmsServerSettings.serverEnable"]
        db.setAttribute("dmsServerSettings","_ROWID_", "1", "serverEnable",status )
    end


    if(input["dmsServerSettings"]["dmsServerSettings.FriendlyName"] ~= nil) then
        FriendlyName = input["dmsServerSettings"]["dmsServerSettings.FriendlyName"]
            local length
            local lowerCase
            local upperCase
            local specialChar
            length = string.len(FriendlyName)

            if( length > 0 or length <= 26 ) then
                lowerCase = string.match(FriendlyName, '[a-z]')
                upperCase = string.match(FriendlyName, '[A-Z]')
                specialChar = string.match(FriendlyName, '&')
            end

            if ( length <= 0 or length > 26 or ( lowerCase == nil and upperCase == nil) or specialChar ~= nil ) then
                tr69Glue.tf1Dbg("Couldn't fetch corresponding dms server Row..")
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param .. "FriendlyName", error_code.INVALID_PARAM_VALUE)
                return status, faultTbl;
            end
        db.setAttribute("dmsServerConfig","_ROWID_", "1", "friendlyName",FriendlyName )
    end

    tr69Glue.tf1Dbg("Leaving dms..")
    return 0; 
end

--[[
--*****************************************************************************
-- mediaServerTr.dlnaServerCfgGet: get the MediaServer values.
--                  
-- Enable
-- Status
-- 
-- Returns: status, value
]]--
function mediaServerTr.dlnaServerCfgGet(input)
    local status = "0"
    local value = "0"
    local row = {}
    local query = nil
    local param = input["param"]

    --get corresponding db entry from mediaServerGlobalCfg
    query = "_ROWID_=1"
    row = db.getRowWhere ("mediaServerGlobalCfg", query, false)
    if (row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- DMS_Enabled
        value = row["serverEnable"]
    elseif(string.find(input["param"], "FriendlyName")) then
        -- FriendlyName
        value= row["friendlyName"]
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- mediaServerTr.dlnaServerCfgSet: set DMS parameters.
--
-- This function is called to set the following parameters in
-- 
-- Enable
-- FriendlyName
--
-- Returns: status
-- 
]]--
function mediaServerTr.dlnaServerCfgSet(input, rowids, actionType, tr69Param)
    local status = OK
    local faultTbl = {}
    local index = 0
    local query = nil
    local errMsg
    local dmsRow = {}

    query = "_ROWID_=1"
    dlnaRow = db.getRowWhere ("mediaServerGlobalCfg", query, false)
    if(dlnaRow == nil) then
        tr69Glue.tf1Dbg("Couldn't fetch corresponding dlna server Row..")
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    if(input["mediaServerGlobalCfg"]["mediaServerGlobalCfg.serverEnable"] ~= nil) then
        dlnaRow["shareSettings"] = input["mediaServerGlobalCfg"]["mediaServerGlobalCfg.serverEnable"]
    end

    if(input["mediaServerGlobalCfg"]["mediaServerGlobalCfg.friendlyName"] ~= nil) then
        dlnaRow["friendlyName"] = input["mediaServerGlobalCfg"]["mediaServerGlobalCfg.friendlyName"]
    end

    errorFlag, statusCode = gui.administration.fileShareSet(dlnaRow,dbFlag)
    if (errorFlag ~= "OK") then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return  status, faultTbl;
    end

    tr69Glue.tf1Dbg("Leaving dlnaServerCfgSet..")
    return 0; 
end


