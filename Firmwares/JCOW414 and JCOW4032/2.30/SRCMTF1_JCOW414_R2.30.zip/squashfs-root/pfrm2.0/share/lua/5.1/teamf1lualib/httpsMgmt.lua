--[[
#### Hussain Vali
#### TeamF1
#### www.TeamF1.com
#### Dec 15, 2007

#### File: httpsMgmt.lua
#### Description: Remote Management functions

#### Revisions:
None
]]--


--************* Requires *************


--************* Initial Code *************

--package httpsMgmt
httpsMgmt = {}

--************* Functions *************
-------------------------------------------------------------------------------
-- @name : httpsMgmt.tf1Dbg - print dbg messages
-- 
-- @description : This function prints dbg messages to a file
--
function httpsMgmt.tf1Dbg(dbgMessage) 
   local dbgfile = ""
   dbgfile = io.open("/var/log/tf1RmtMgmtDbg.log","a")
   if dbgfile~=nil then 
       dbgfile:write(dbgMessage .. "\n")
       io.close(dbgfile) 
   end
end

-- httpsMgmt config
function httpsMgmt.config (inputTable, rowid, operation)
	-- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "Administrator Privileges Are Required"
	end
	local valid = false

	-- validate
	if (httpsMgmt.inputvalidate(inputTable, operation)) then        
        if (operation == "add") then
            valid = db.insert("httpsMgmt", inputTable)
        elseif (operation == "edit") then
            if (inputTable["httpsMgmt.httpsMgmtPort"] == "0") then
                return "ERROR", "Invalid Port Configured."
            elseif (inputTable["httpsMgmt.httpsMgmtPort"] == "80") then
                return "ERROR", "This Port Already Reserved."
            end
            valid = db.update("httpsMgmt", inputTable, rowid)
        elseif (operation == "delete") then
            return nil
		end
	end
	
	-- return
	if (valid) then
		return "OK", "Operation Succeeded"
	else
		return "ERROR", "Configuration Update Failed"
	end
end

-- httpsMgmt inputvalidate
function httpsMgmt.inputvalidate (inputTable, operation)
	if (true) then
            return db.typeAndRangeValidate(inputTable)
        end
	return false
end

-- config get function
function httpsMgmt.configGet()
    --local 
    local httpsMgmtConfigTbl = {}
    local configTbl = {}
    
    httpsMgmtConfigTbl = db.getRow ("httpsMgmt", "_ROWID_", "1")   
    --This was giving issue because some fields have table name in the beginning
    --httpsMgmtConfigTbl = util.removePrefix(httpsMgmtConfigTbl, "httpsMgmt.")
    configTbl["httpsMgmtEnable"] = httpsMgmtConfigTbl["httpsMgmt.httpsMgmtEnable"]
    configTbl["httpsMgmtAccessType"] = httpsMgmtConfigTbl["httpsMgmt.httpsMgmtAccessType"]
    configTbl["httpsMgmtIP1"] = httpsMgmtConfigTbl["httpsMgmt.httpsMgmtIP1"]
    configTbl["httpsMgmtIP2"] = httpsMgmtConfigTbl["httpsMgmt.httpsMgmtIP2"]
    configTbl["httpsMgmtPort"] = httpsMgmtConfigTbl["httpsMgmt.httpsMgmtPort"]
    --return
    return configTbl
end

-- config set function
function httpsMgmt.configSet(inputTbl)
    local status, errMsg
    local configRow = {}

    configRow = util.addPrefix(inputTbl, "httpsMgmt.")
    status, errMsg = httpsMgmt.config(configRow, 1, "edit")

    return status, errMsg
end

function httpsMgmt.import (configTable, defaultCfgTbl, removeConfig)
	if (configTable == nil) then
		configTable = defaultCfgTbl
	end

    local httpsMgmtTbl = {}
    httpsMgmtTbl = config.update (configTable.httpsMgmt, defaultCfgTbl.httpsMgmt, removeConfig.httpsMgmt)

    local   configMergeDone = "0"

    if (httpsMgmtTbl ~= nil and #httpsMgmtTbl ~= 0) then
        for i,v in pairs(httpsMgmtTbl) do
            v = util.addPrefix(v, "httpsMgmt.")
            if(util.fileExists("/flash/configMerge/httpsMgmtDisable") == false) then
				v["httpsMgmt.httpsMgmtEnable"] = "0"
				configMergeDone = "1"
			end
            httpsMgmt.config (v, "-1", "add")
        end
        if (configMergeDone == "1") then
			local httpsMgmtDisable = io.open("/flash/configMerge/httpsMgmtDisable", "w")                                                          
            if(httpsMgmtDisable ~= nil) then                                                                       
            	httpsMgmtDisable:close()                                                                           
            end
		end
    end    
end

function httpsMgmt.export ()
    local rmtMgmtall = {}
    local table = {}
    table["httpsMgmt"] = {}

    table["httpsMgmt"] = db.getTable ("httpsMgmt", false)
    if (table["httpsMgmt"] ~= nil) then
    	rmtMgmtall["httpsMgmt"] = table["httpsMgmt"]
    end

	return rmtMgmtall    
end

if (config.register) then
   config.register("rmtMgmt", httpsMgmt.import, httpsMgmt.export, "1")
end
