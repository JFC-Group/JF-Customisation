-- @copyright Copyright (c) 2012, TeamF1, Inc. 

require "teamf1lualib/pptp"

--[[
*******************************************************************************
-- @name nimfConn.ipv4PPTPCfgInit
--
-- @description The function initialises the PPTP configuration.
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv4PPTPCfgInit(cur, conf)
    local cfg = {}

    if (cur ==  nil) then
        cfg["LogicalIfName"] = conf["LogicalIfName"]
    else
        cfg = cur        
    end                

    cfg["UserName"] = conf["UserName"]
    cfg["Password"] = conf["Password"]
    cfg["IspName"]  = conf["IspName"]
    cfg["GetIpFromIsp"] = conf["GetIpFromIsp"]
    cfg["GetDnsFromIsp"] = conf["GetDnsFromIsp"]
    cfg["PrimaryDns"] = conf["PrimaryDns"]
    cfg["SecondaryDns"] = conf["SecondaryDns"]
    cfg["Mtu"] = conf["Mtu"]
    cfg["IdleTimeOutFlag"] = conf["IdleDisconnect"]
    cfg["IdleTimeOutValue"] = "0"
    if (conf["IdleDisconnectTime"] ~= nil and 
        tonumber(conf["IdleDisconnectTime"]) > 0) then
        cfg["IdleTimeOutValue"] = conf["IdleDisconnectTime"]
    end
    
    -- PPTP Transport
    cfg["MyIp"] = conf["MyIPAddress"]
    cfg["StaticIp"] = conf["StaticIp"]
    cfg["NetMask"] = conf["NetMask"]
    cfg["Gateway"] = conf["Gateway"]
    cfg["ServerIp"] = conf["ServerIp"]

    -- PPTP Options
    cfg["MppeEncryptSupport"] = conf["MppeEncryptSupport"] or "0"
    cfg["SplitTunnel"] = conf["SplitTunnel"] or "0"
    cfg["DualAccess"] = conf["DualAccess"] or "0"

    return cfg
end

--[[
*******************************************************************************
-- @name nimfConn.ipv4PPTPConfigure
--
-- @description This function conigures the PPTP Connection
--
-- @param conf configuration table with the following fields
-- <ul>
-- <li><i> LogicalIfName</i>        Logical name of the network.
-- <li><i> AddressFamily</i>        network protocol of the connection
-- <li><i> Enable</i>               enable/disable connection
-- <li><i> StaticIp</i>             Static IP Address
-- <li><i> NetMask</i>              Subnetmask of the above IP address.
-- <li><i> Gateway</i>              Gateway IP Address
-- <li><i> PrimaryDns</i>           Primary DNS server IP address of this network
-- <li><i> SecondaryDns</i>         Secondary DNS server IP address of this network
-- <li><i> IdleDisconnectTime</i>   Idle Timeout in case of PPP connections   
-- <li><i> Username</i>             username for PPP authentication
-- <li><i> Password</i>             password for PPP authentication
-- <li><i> GetIpFromIsp</i>         1 if this network gets IP parameters from ISP
-- <li><i> GetDnsFromIsp</i>        1 if this network gets DNS from ISP
-- <li><i> IspName</i>              ISP Name
-- <li><i> MyIPAddress</i>          PPTP Transport IP
-- <li><i> ServerIP</i>             PPTP Server IP Address
-- <li><i> MppeEncryptSupport</i>   Mppe Encryption
-- </ul>
--
-- @return  OK or ERROR
-- @errCode error string.
--]]

function nimfConn.ipv4PPTPConfigure(conf)
    local query = nil
    local record = {}
    local cfg = {}
    local errstr = ""
    local valid
    local rowid
    local status = "ERROR"
    local errCode  ="NET_ERR_PPTP_CONF"

    query = "LogicalIfName='" .. conf["LogicalIfName"].."'"

    nimf.dprintf ("Configuring PPTP connection for " ..  conf["LogicalIfName"])
    record = db.getRowWhere("Pptp", query, false)
    if (record == nil) then
        -- initialize configuration
        cfg = nimfConn.ipv4PPTPCfgInit(record, conf)
    if (cfg["Password"] ~= nil) then
        if (util.isAllMasked (cfg["Password"])) then
            cfg["Password"] = db.getAttribute ("Pptp","_ROWID_",cfg["_ROWID_"],"Password")
        end
    end

        -- Configure PPTP transport
        status, errCode =  nimfConn.ipv4PPTPTransportConfigure (cfg)
        if (status ~= "OK") then
            return status, errCode
        end

        -- add configuration
        cfg = util.addPrefix(cfg, "Pptp.")

        nimf.dprintf ("Adding PPTP connection " ..  util.tableToStringRec(cfg))
        valid, errstr, rowid = pptp.config (cfg, nil, "add")
    else
        -- initialize configuration
        cfg = nimfConn.ipv4PPTPCfgInit(record, conf)
        if (cfg["Password"] ~= nil) then
            if (util.isAllMasked (cfg["Password"])) then
                cfg["Password"] = db.getAttribute ("Pptp","_ROWID_",cfg["_ROWID_"],"Password")
            end
        end

        local changed = nimf.hasTableChanged("Pptp", cfg, cfg["_ROWID_"])
        if (not changed) then
            return "OK","STATUS_OK", false
        end            

        -- Configure PPTP transport
        status, errCode =  nimfConn.ipv4PPTPTransportConfigure (cfg)
        if (status ~= "OK") then
            return status, errCode
        end
                        
        --
        -- Set this to true to indicate configuration has changed
        --
        rowid = true

        -- update configuration
        cfg = util.addPrefix(cfg, "Pptp.")
        valid, errstr = pptp.config (cfg, cfg["Pptp._ROWID_"], "edit")
    end                

    if (not valid) then
        nimf.dprintf("ipv4PPTPConfigure: " ..
                     "IPv4 PPTP Connection configuration failed")
        return "ERROR", errstr
    end
            
    return "OK", "STATUS_OK", rowid
end

--[[
*******************************************************************************
-- @name  nimfConn.ipv4PPTPDeconfigure
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv4PPTPDeconfigure(conf)
    local query = nil
    local errstr = ""
    local valid
    local status = "ERROR"
    local errCode = "NET_ERR_PPTP_DECONF"

    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "'"

    nimf.dprintf ("Deleting IPv4 PPTP connection for " ..  conf["LogicalIfName"])
    valid, errstr = db.deleteRowWhere("Pptp", query)
    if (not valid) then
        nimf.dprintf("ipv4PPTPDeconfigure: failed to deconfigure PPTP on " .. 
                     conf["LogicalIfName"] .. " Err: " .. errstr or "Uknown")
        return status, errCode
    end
            
    nimf.dprintf ("Deleting IPv4 PPTP transport for " ..  conf["LogicalIfName"])
    status, errCode = nimfConn.ipv4PPTPTransportDeconfigure(conf)
    if (status ~= "OK") then
        nimf.dprintf("ipv4PPTPDeconfigure:failed to deconfigure PPTP transport on " .. 
                     conf["LogicalIfName"])
        return status, errCode
    end
                        
    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- nimfConn.ipv4PPTPConfValidate
--
-- @description This function validates parameters for IPv4 PPTP configuration
--
-- @param conf configuration table with the following fields
-- <ul>
-- <li><i> LogicalIfName</i>        Logical name of the network.
-- <li><i> AddressFamily</i>        network protocol of the connection
-- <li><i> Enable</i>               enable/disable connection
-- <li><i> StaticIp</i>             Static IP Address
-- <li><i> NetMask</i>              Subnetmask of the above IP address.
-- <li><i> Gateway</i>              Gateway IP Address
-- <li><i> PrimaryDns</i>           Primary DNS server IP address of this network
-- <li><i> SecondaryDns</i>         Secondary DNS server IP address of this network
-- <li><i> IdleDisconnectTime</i>   Idle Timeout in case of PPP connections   
-- <li><i> Username</i>             username for PPP authentication
-- <li><i> Password</i>             password for PPP authentication
-- <li><i> GetIpFromIsp</i>         1 if this network gets IP parameters from ISP
-- <li><i> GetDnsFromIsp</i>        1 if this network gets DNS from ISP
-- <li><i> IspName</i>              ISP Name
-- <li><i> MyIPAddress</i>          PPTP Transport IP
-- <li><i> ServerIP</i>             PPTP Server IP Address
-- <li><i> MppeEncryptSupport</i>   Mppe Encryption
-- </ul>
--
-- @return  OK or ERROR
-- @errCode error string.
--]]

function nimfConn.ipv4PPTPConfValidate(conf)
    local ipAddr=nil

    if ((conf["UserName"] == nil) or (conf["Password"] == nil))  then
        nimf.dprintf("ipv4PPTPConfValidate: Invalid conn credentials")
        return "ERROR", "NIMF_ERR_INVALID_PPP_CRED"
    end        

    -- check if StaticIp is valid
    ipAddr = conf["StaticIp"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv4AddrCheck(ipAddr) == nil)) then
        nimf.dprintf("ipv4PPTPConfValidate: Invalid preferred IP address")
        return "ERROR", "NIMF_ERR_INVALID_STATIC_IP"
    end        

    -- check if primary DNS is valid
    ipAddr = conf["PrimaryDns"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv4AddrCheck(ipAddr) == nil)) then
        nimf.dprintf("ipv4PPTPConfValidate: Invalid primary DNS")
        return "ERROR", "NIMF_ERR_INVALID_PRIMARY_DNS"
    end        

    -- check if secondary DNS is valid
    ipAddr = conf["SecondaryDns"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv4AddrCheck(ipAddr) == nil)) then
        nimf.dprintf("ipv4PPTPConfValidate: Invalid secondary DNS")
        return "ERROR", "NIMF_ERR_INVALID_SECONDARY_DNS"
    end        

    -- check if PPTP Transport IP is valid
    ipAddr = conf["MyIPAddress"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv4AddrCheck(ipAddr) == nil)) then
        nimf.dprintf("ipv4PPTPConfValidate: Invalid PPTP transport IP")
        return "ERROR", "NIMF_ERR_INVALID_MYIP"
    end        

    -- 
    -- Check if PPTP Server Ip is ok
    -- TODO: nimf need to support getaddinfo style
    -- address checking to check for domain names
    --

    -- check if PPTP Server Gateway IP is valid
    ipAddr = conf["Gateway"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv4AddrCheck(ipAddr) == nil)) then
        nimf.dprintf("ipv4PPTPConfValidate: Invalid PPTP transport gateway")
        return "ERROR", "NIMF_ERR_INVALID_SERVERIP"
    end        

    -- check idle timeout
    local idleTimeout = conf["IdleDisconnectTime"]
    if ((idleTimeout ~= nil) and (tonumber(idleTimeout) < 0)) then
        nimf.dprintf("ipv4PPTPConfValidate: Invalid idle disconnect time")
        return "ERROR", "NIMF_ERR_INVALID_IDLE_TIMEOUT"
    end        

    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- @name nimfConn.pptpConfGet
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.pptpConfGet(conf)
    local query = nil
    local record = {}
    local cfg = {}

    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "'"
    record = db.getRowWhere("Pptp", query, false)
    if (record ~= nil) then
        cfg["LogicalIfName"] = record["LogicalIfName"]
        cfg["AddressFamily"] = "2"
        cfg["IspName"] = record["IspName"]
        cfg["UserName"] = record["UserName"]
		cfg["Password"] = util.mask (record["Password"])
        cfg["IdleDisconnect"] = record["IdleTimeOutFlag"]
        cfg["IdleDisconnectTime"] = record["IdleTimeOutValue"]

        -- IP negotiation
        cfg["GetIpFromIsp"] = record["GetIpFromIsp"]
        cfg["StaticIp"] = record["StaticIp"]
        cfg["NetMask"] = record["NetMask"]
        cfg["GetDnsFromIsp"] = record["GetDnsFromIsp"]
        cfg["PrimaryDns"] = record["PrimaryDns"]
        cfg["SecondaryDns"] = record["SecondaryDns"]

        -- PPTP Transport
        cfg["MyIPAddress"] = record["MyIp"]
        cfg["Gateway"] = record["Gateway"]
        cfg["ServerIp"] = record["ServerIp"]

        -- PPTP Options
        cfg["MppeEncryptSupport"] = record["MppeEncryptSupport"]
        cfg["SplitTunnel"] = record["SplitTunnel"]
        cfg["DualAccess"] = record["DualAccess"]
        cfg["Mtu"] = record["Mtu"]
    end        

    return "OK", "STATUS_OK", cfg
end

--[[
*******************************************************************************
-- @name nimfConn.ipv4PPTPConfGet
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv4PPTPConfGet(conf)
    return nimfConn.pptpConfGet(conf)
end

--[[
*******************************************************************************
-- @name nimfConn.ipv4PPTPTransportConfigure
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv4PPTPTransportConfigure (conf)
    local status = "ERROR"
    local errCode = "NET_ERR_PPTP_TRANSPORT_CONF"
    local conn = {}

    conn["LogicalIfName"] = conf["LogicalIfName"]
    conn["AddressFamily"] = "2"
    conn["ConnectionKey"] = "1"
    conn["StaticIp"] = conf["MyIp"]
    if ((conf["NetMask"] ~= nil) and (string.len(conf["NetMask"]) > 0)) then
        conn["NetMask"] = conf["NetMask"] 
    else
        conn["NetMask"] = "255.255.255.0"
    end                

    conn["Gateway"] = conf["Gateway"] or ""
    conn["DefaultConnection"] = "0"
    conn["ConfigureRoute"] = "0"
    conn["ConfigureDNS"] = "0"
    conn["Enable"] = "1"
    conn["PrimaryDns"] = ""
    conn["SecondaryDns"] = ""

    if ((conf["MyIp"] ~= nil) and 
        (string.len(conf["MyIp"]) > 0)) then
        conn["ConnectionType"] = "ifStatic"
    else
        conn["ConnectionType"] = "dhcpc"
    end                

    -- update configuration
    nimf.dprintf("Configuring PPTP Transport: " .. util.tableToStringRec(conn))
    status, errCode = nimfConn.configure(conn)
    if (status ~= "OK") then
        nimf.dprintf("nimfConn.ipv4PPTPTransportConfigure: failed to create " .. 
                     "transport connection ")
        return status, errCode
    end        

    return "OK","STATUS_OK"
end

--[[
*******************************************************************************
-- @name nimfConn.ipv4PPTPTransportDeconfigure
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv4PPTPTransportDeconfigure (conf)
    local connID = {}
    local status = "ERROR"
    local errCode = "NET_ERR_PPTP_TRANSPORT_DECONF"

    connID["LogicalIfName"] = conf["LogicalIfName"]
    connID["AddressFamily"] = conf["AddressFamily"] or "2"
    connID["ConnectionKey"] = "1"

    status, errCode = nimfConn.deconfigure(connID)
    if (status ~= "OK") then
        nimf.dprintf("nimfConn.ipv4PPTPTransportDeconfigure: failed to deconfigure " ..
                     "PPTP transport")
        return status, errCode        
    end
            
    return "OK", "STATUS_OK"            
end

--[[
*******************************************************************************
-- @name nimfConn.ipv4PPTPTransportEnable 
--
-- @description This function Enable pptp transport connection.
--
-- @param connID    Connection ID
-- @field LogicalIfName NET ID
-- @field AddressFamily Protocol 
-- @field ConnectionKey unique connection number
--
-- @return  status, errCode
--
--]]

function nimfConn.ipv4PPTPTransportEnable (conf)
    local valid
    local errstr=""
    local status = "ERROR"
    local errCode = "NET_ERR_PPTP_TRANSPORT_ENABLE"
    local conn = {}

    conn["LogicalIfName"] = conf["LogicalIfName"]
    conn["AddressFamily"] = "2"
    conn["ConnectionKey"] = "1"
    
    query = "LogicalIfName='" .. conn["LogicalIfName"].."' and AddressFamily='" .. conn["AddressFamily"]
            .."' and ConnectionKey='" .. conn["ConnectionKey"].."'"

    record = db.getRowWhere("nimfConf", query, false)
    if (record == nil) then
        nimf.dprintf ("PPTP transport Enable failed")
        return "ERROR", "PPTP_TRANSPORT_CONF_ERR"
    end

    -- set connection as enable
    record["Enable"] = "1"
    
    -- update the configuration
    record = util.addPrefix(record, "NimfConf.")
    if (record == nil) then
        return "ERROR", nimf.err.NIMF_ERR_INVALID_ARG   
    end        

    -- commit 
    valid, errstr = nimf.config(record, record["NimfConf._ROWID_"], "edit")
    if (not valid) then
        if (errstr) then 
            nimf.dprintf("nimfConn..ipv4PPTPTransportEnable: update failed. reason:" .. errstr) 
        end
        nimf.dprintf("nimfConn..ipv4PPTPTransportEnable: failed to update connection configuration")
        return "ERROR", nimf.err.NIMF_ERR_DB_UPDATE
    end
    
    return "OK","STATUS_OK"
end

--[[
*******************************************************************************
-- @name nimfConn.ipv4PPTPTransportDisable 
--
-- @description This function Disable pptp transport connection.
--
-- @param connID    Connection ID
-- @field LogicalIfName NET ID
-- @field AddressFamily Protocol 
-- @field ConnectionKey unique connection number
--
-- @return  status, errCode
--
--]]

function nimfConn.ipv4PPTPTransportDisable (conf)
    local valid
    local errstr=""
    local status = "ERROR"
    local errCode = "NET_ERR_PPTP_TRANSPORT_DISABLE"
    local conn = {}

    conn["LogicalIfName"] = conf["LogicalIfName"]
    conn["AddressFamily"] = "2"
    conn["ConnectionKey"] = "1"
    
    query = "LogicalIfName='" .. conn["LogicalIfName"].."' and AddressFamily='" .. conn["AddressFamily"]
            .."' and ConnectionKey='" .. conn["ConnectionKey"].."'"

    record = db.getRowWhere("nimfConf", query, false)
    if (record == nil) then
        nimf.dprintf ("PPTP transport disable failed")
        return "ERROR", "PPTP_TRANSPORT_CONF_ERR"
    end
    -- set connection as disable
    record["Enable"] = "0"
    
    -- update the configuration
    record = util.addPrefix(record, "NimfConf.")
    if (record == nil) then
        return "ERROR", nimf.err.NIMF_ERR_INVALID_ARG   
    end        

    -- commit 
    valid, errstr = nimf.config(record, record["NimfConf._ROWID_"], "edit")
    if (not valid) then
        if (errstr) then 
            nimf.dprintf("nimfConn..ipv4PPTPTransportDisable: update failed. reason:" .. errstr) 
        end
        nimf.dprintf("nimfConn..ipv4PPTPTransportDisable: failed to update connection configuration")
        return "ERROR", nimf.err.NIMF_ERR_DB_UPDATE
    end
    
    return "OK","STATUS_OK"
end
