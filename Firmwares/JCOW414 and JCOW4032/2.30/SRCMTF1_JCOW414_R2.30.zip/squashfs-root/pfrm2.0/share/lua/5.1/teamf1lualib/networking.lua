-- network.lua - lua wrapper calls for network tab

-- Copywrite (c) 2013 TeamF1, Inc.
-- Copyright (c) 2017, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
--
--
-- modification history
-- --------------------
-- 01e, 23Nov17, swr changes for spr 62635(XSS vulnerability) and 61441
-- 01d, 08Jun17, sjr added packet capture check for LAN/WAN
-- 01c, 20Apr17, ash added checks for dependencies for used vlans
-- 01b, Aug2213, sen added checks for dependencies between LAN/WAN side vlans
--               and bridgeMode
-- 01a, 12Mar13, sen dervied from reference solution. for RIL.
--
---------------------------------------------------------------------------------
-- The routines in this lua wrapper are called by htm(user interface) layer to
-- get the information to display in user interface or to configure network
-- properties for which the respective routines will satisfy the purpose of
-- creating/modifying/destroying a network such as (re)start/stop network
-- bound application.
---------------------------------------------------------------------------------
gui.networking= {}


-- Dynamic DNS set-up
gui.networking.ddns = {}
gui.networking.ddns.get = {}
gui.networking.ddns.set = {}
--[[ Network tests ]]--
gui.networking.diagnostics = {}
--Ping or Trace an IP Address
gui.networking.diagnostics.ping = {}
gui.networking.diagnostics.traceroute = {}
--DNS lookup
gui.networking.diagnostics.dnslookup = {}
gui.networking.packetTrace = {}
gui.networking.bridgeMode = {}
gui.networking.gpon = {}

local  portCorrection = 0 
if (util.fileExists ("/pfrm2.0/HW_JCO4032") or util.fileExists ("/pfrm2.0/HW_JCOW407") or util.fileExists ("/pfrm2.0/HW_JCOW402")) then
	portCorrection = 0 
	
else
	portCorrection = 2
end

require "teamf1lualib/netconf"
require "teamf1lualib/routing"
require "teamf1lualib/wifiSecMap"
require "teamf1lualib/wireless"
--require "teamf1lualib/wizard"

--util.setDebugStatus(true)
-------------------------------------------------------------------------------
-- @name gui.networking.ddns.get
--
-- @description This function will get the status of ddns in device.
--
--
-- @return
--
function gui.networking.ddns.get ()

    -- require
    require "teamf1lualib/ddns"

    -- locals
    local ddnsTbl = {}
    local errMsg = nil
    local statusMsg = nil

    -- Logic
    ddnsTbl = ddns.ddnsGet()
 if (ddnsTbl == nil) then
  return "ERROR", "DB_ERROR_TRY_AGAIN"
 end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

    -- return
    return errMsg, statusMsg, ddnsTbl
end

-------------------------------------------------------------------------------
-- @name gui.networking.ddns.set
--
-- @description This function will configure ddns service in device.
--
-- @return
--
function gui.networking.ddns.set (ddnsCfg)

    -- require
 require "teamf1lualib/ddns"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- locals
    local status, err

    -- Logic
    status, err = ddns.ddnsSet(ddnsCfg)

    -- return
    return status, err
end
-------------------------------------------------------------------------------
-- @name gui.networking.diagnostics.networksGet
--
-- @description This function will get the currently available networks in the
-- system.
--
-- @param
--
-- @return
--
function gui.networking.diagnostics.networksGet()

    -- require
    require "teamf1lualib/platform"

    -- locals
    local netTbl = {}
    local errMsg = nil
    local statusMsg = nil
    local page = {} --local table containing the available networks Info
    page.networks = {}

    netTbl = platform.availableNetworkGet()
    if (netTbl == nil) then
        return "ERROR", "AVAILABLE_NETWORKS_GET_FAILED"
    end

    for i,v in ipairs (netTbl)
    do
        page.networks[i] = {}
        page.networks[i].networkname = v["networkName"]
    end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

    --return
 return errMsg, statusMsg, page
end

-------------------------------------------------------------------------------
-- @name gui.networking.diagnostics.ping.set
--
-- @description This function will execute ping for given ip address or FQDN.
--
-- @param lua table containing ip/fqdn to which ping has to be tested.
--
-- @return
--
function gui.networking.diagnostics.ping.set (pingCfg)

    -- require
    require "teamf1lualib/platform"

    -- Sanity for privilages
    --if (ACCESS_LEVEL ~= 0) then
      -- return "ACCESS_DENIED", "ADMIN_REQD"
    --end

    -- locals
    local status, err

    -- execute ping command for given ip/fqdn
    status, err = platform.pingTest (pingCfg);

 --return
 return status, err
end


-------------------------------------------------------------------------------
-- @name gui.networking.diagnostics.ping.get
--
-- @description This function will get the ping output stored in a file.
--
-- @param lua table containing ping
--
-- @return
--
function gui.networking.diagnostics.ping.get()

    -- require
 require "teamf1lualib/platform"

 -- locals
 local pingTbl = {} -- local table containing ping output
 local localTbl = {}
    local errMsg = nil
    local statusMsg = nil

    local arg="ping"
 -- we only write the ping Result into a file
 pingTbl = platform.diagnosticResultGet(arg)

    if(pingTbl == nil) then
        return localTbl
    end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

    return errMsg, statusMsg, pingTbl
end




-------------------------------------------------------------------------------
-- @name gui.networking.diagnostics.traceroute.set
--
-- @description This function will execute traceroute for given ip address or
-- FQDN and print the route packets trace to network host.
--
-- @param lua table containing ip/fqdn to which traceroute has to be tested.
--
-- @return
--
function gui.networking.diagnostics.traceroute.set (traceCfg)

    -- require
    require "teamf1lualib/platform"

    -- Sanity for privilages
    --if (ACCESS_LEVEL ~= 0) then
      -- return "ACCESS_DENIED", "ADMIN_REQD"
    --end

    -- locals
    local status, err

    -- execute ping command for given ip/fqdn
    status, err = platform.traceroute (traceCfg);

 --return
 return status, err
end

-------------------------------------------------------------------------------
-- @name gui.networking.diagnostics.traceroute.get
--
-- @description This function will get traceroute result from the stored file.
--
-- @param
--
-- @return
--
function gui.networking.diagnostics.traceroute.get()

    -- require
 require "teamf1lualib/platform"

 -- locals
 local traceTbl = {} -- local table containing traceroute output
    local localTbl = {}
    local errMsg = nil
    local statusMsg = nil

    local arg="traceroute"
 -- we only write the ping Result into a file
 traceTbl = platform.diagnosticResultGet(arg)

    if(traceTbl == nil) then
        return localTbl
    end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

    return errMsg, statusMsg, traceTbl

end

-------------------------------------------------------------------------------
-- @name gui.networking.diagnostics.dnslookup.set
--
-- @description This function will execute nslookup for given ip address or
-- FQDN and query Internet name servers interactively.
--
-- @param lua table containing ip/fqdn to which dnslookup has to be tested.
--
-- @return
--
function gui.networking.diagnostics.dnslookup.set (lookupCfg)

    -- require
    require "teamf1lualib/platform"

    -- Sanity for privilages
    --if (ACCESS_LEVEL ~= 0) then
      -- return "ACCESS_DENIED", "ADMIN_REQD"
    --end

    -- locals
    local status, err

    -- TODO: execute nslookup command for the domain name entered
    status, err = platform.nslookup(lookupCfg)

 --return
 return status, err

end

function gui.networking.diagnostics.dnslookup.get()

    -- require
 require "teamf1lualib/platform"

 -- locals
 local lookTbl = {} -- local table containing traceroute output
    local localTbl = {}
    local errMsg = nil
    local statusMsg = nil

    local arg="nslookup"
 -- we only write the ping Result into a file
 lookTbl = platform.diagnosticResultGet(arg)

    if(lookTbl == nil) then
        return localTbl
    end

   errMsg = "OK"
   statusMsg = "STATUS_OK"

    return errMsg, statusMsg, lookTbl
end

function gui.networking.packetTrace.set(conf)

    -- require
    require "teamf1lualib/tcpdump"

   	if (ACCESS_LEVEL ~= 0 and ACCESS_LEVEL ~= 3) then
		return "ACCESS_DENIED", "ADMIN_REQD"    
	end 
   
    if (conf == nil) then
        return "ERROR", "PTRACE_INVALID_PARAM"        
    end

    if (conf["networkName"] == nil) then
        return "ERROR", "INVALID_NETWORK_NAME"        
    end

    local query = "networkName='" .. conf["networkName"] .. "'"
    local row = db.getRowWhere("networkInterface", query, false)
    if (row == nil) then
        return "ERROR", "FAILED_TO_GET_NETWORK"
    end

    conf["interfaceName"] = row["interfaceName"]

--[[ Remove this check because RIL wants packet capture when WAN is down

    local status, errCode, networkInfo = gui.networking.network.statusGet(row["LogicalIfName"])
    if (status ~= "OK") then
        return status, errCode
    end

    if (networkInfo.ipv4 ~= "nil") then
        if (networkInfo.ipv4["ConnectionStatus"] ~= "CONNECTED") then
            return "ERROR", "NETWORK_DOWN"
        end
    end

--]]

    errMsg, statusMsg = tcpdump.configure(conf)

    return errMsg, statusMsg
end

function gui.networking.packetTrace.get()

    local lookTbl = {}
    local netwrkInterfaceTbl = {}
    local page = {}
    local i = 0
    local j = 0
    page.networks = {}

    local intName = nil
    -- require
    require "teamf1lualib/tcpdump"
    local tcpdumpTbl = tcpdump.get()
    if (tcpdumpTbl ~= nil) then
        for k,v in pairs(tcpdumpTbl) do
            i = i + 1
		    local row = tcpdumpTbl[i]
		    if (row["tcpdumpEnabled"] == "1") then
                intName = row["interfaceName"]
                break
		    end
	    end
    end
   
    if (intName ~= nil) then
        local query = "interfaceName='" .. intName .. "'"
        lookTbl = db.getRowWhere("networkInterface", query, false)
        if (lookTbl == nil) then
            return "ERROR", "FAILED_TO_GET_NETWORK", netwrkInterfaceTbl
        end
    end

    -- getting the networkInterface table
    netwrkInterfaceTbl = db.getTable("networkInterface", false)
    if (netwrkInterfaceTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN", netwrkInterfaceTbl 
    end
    
    -- getting the statistics of all the networks configured
    for k,v in pairs (netwrkInterfaceTbl) do
        j = j + 1
        if (v["LogicalIfName"] == "IF1" or v["LogicalIfName"] == "IF2") then
            page.networks[k] = {}
            page.networks[k].interfaceName = v["interfaceName"]
            page.networks[k].LogicalIfName = v["LogicalIfName"]
            page.networks[k].networkName = v["networkName"]
        end
    end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

    return errMsg, statusMsg, lookTbl, page
end

function gui.networking.bridgeMode.get ()

	local bridgeTable = {}

    -- require
    require "teamf1lualib/bridgeLib"
	bridgeRow = bridgeMode.get ()
	
	if (bridgeRow == nil) then
		return  "ERROR", "DB_ERROR_TRY_AGAIN", nil
	end

	
    bridgeRow["bridgeMode.portNumber"] = tonumber (bridgeRow["bridgeMode.portNumber"]) - portCorrection
    bridgeRow["bridgeMode.vlanID"] = util.filterXSSChars (bridgeRow["bridgeMode.vlanID"])
	return errMsg, statusMsg, bridgeRow

end

function gui.networking.bridgeMode.set (inputTable)

	local errMsg = ""
	local statusMsg = ""

	local valid  = true
    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
      return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- require
    require "teamf1lualib/bridgeLib"

    if (UNIT_INFO == "ODU") then
        errMsg, statusMsg = bridge.changeBridgeMode (inputTable["bridgeModeStatus"])
        
        if (errMsg == "OK") then
            db.save2()
        else
            errMsg = "ERROR"
            statusMsg = "BRIDGE_MODE_CONFIG_FAILED"
        end	
        
        return errMsg, statusMsg    
    end

    if (inputTable["vlanId"] ~= nil) then
        if (tonumber(inputTable["vlanId"]) > 4094 or tonumber(inputTable["vlanId"]) < 2) then
            return "ERROR", "INVALID_VLAN_ID"
        end
    end

    if (util.fileExists ("/pfrm2.0/HW_JCO410")) then
        local reservedVid = db.getAttribute ("environment", "name", "FALCON_VID", "value")
        if (reservedVid ~= nil) then
            if (reservedVid == inputTable["vlanId"]) then
                return "ERROR", "VlanId is already in Use"
            end
        end
    end

	local bridgeRow = {}
	bridgeRow["bridgeMode.status"] = inputTable["bridgeModeStatus"]
	if (inputTable["bridgeModeStatus"] == "1") then
		bridgeRow["bridgeMode.portNumber"] = tonumber (inputTable["portNumber"]) + portCorrection
	end
	bridgeRow["bridgeMode.vlanID"] = inputTable["vlanId"]


	if (inputTable["bridgeModeStatus"] == "1") then
		-- do the sanity checks
		local wanVlanRows = db.getRows ("ethernetVLAN", "vlanId", inputTable["vlanId"])
		if (#wanVlanRows ~= 0) then
			return "ERROR", "SELECTED_VLAN_ID_PRESENT_ON_WAN"
		end

		local lanVlanRows = db.getRows ("vlanEncapIf", "vlanId", inputTable["vlanId"])
		if (#lanVlanRows ~= 0) then
			return "ERROR", "SELECTED_VLAN_ID_PRESENT_ON_LAN"
		end

		local gponRow = db.getRow ("gpon", "_ROWID_", "1")
		if ((gponRow["gpon.status"] == "1") and gponRow ~= nil and (gponRow["gpon.vlanStatus"] == "1") and (gponRow["gpon.vlanID"] == inputTable["vlanId"])) then
			return "ERROR", "SELECTED_VLAN_ID_PRESENT_ON_GPON"
		end
		

		lanVlanRows = db.getTable("vlanEncapIf")
		for k,v in pairs (lanVlanRows) do
			if (string.find (v["vlanEncapIf.fwdMap"], (tonumber(inputTable["portNumber"])+portCorrection)) ~= nil ) then
				return "ERROR", "CONFIGURED_PORT_PRESENT_IN_FWD_MAP"
			end
		end
	else
		bridgeRow["bridgeMode.portNumber"] = "3"
		bridgeRow["bridgeMode.vlanID"] = "0"
	end

	db.beginTransaction() -- begin transcation

	valid = bridgeMode.config (bridgeRow, "1", "edit")
	
	if (valid) then
                local insertFlag = "1"
	        local status  = true
                local vlanRows = db.getTable("bridgeModeVlan", false)

                if(#vlanRows >= 1) then
                    for k,v in pairs (vlanRows) do
                        if(inputTable["vlanId"] == v["vlanID"]) then
                            insertFlag = "0"
                        end
                    end
                end

                if(insertFlag == "1" and inputTable["vlanId"] ~= nil) then
                    local input = {}
                    input["bridgeModeVlan.Enable"] = "1" 
    		    input["bridgeModeVlan.vlanID"] = inputTable["vlanId"] 
    		    input["bridgeModeVlan.Name"] = "VLAN" 
    		    status = bridgeModeVlan.config (input, nil, "add")
                end

                if(status) then
		    errMsg = "OK"
		    statusMsg = "STATUS_OK"
		    db.commitTransaction()
		    db.save2()
                else
                    errMsg = "ERROR"
		    statusMsg = "BRIDGE_MODE_CONFIG_FAILED"
		    db.rollback()
                end
	else
		errMsg = "ERROR"
		statusMsg = "BRIDGE_MODE_CONFIG_FAILED"
		db.rollback()
	end		
	
	return errMsg, statusMsg

end

function gui.networking.gpon.get ()

	local gponTable = {}

    -- require
    require "teamf1lualib/gpon"
	gponRow = gpon.get ()
	
	if (gponRow == nil) then
		return  "ERROR", "DB_ERROR_TRY_AGAIN", nil
	end

    gponRow["vlanID"] = util.filterXSSChars(gponRow["vlanID"])

	return errMsg, statusMsg, gponRow

end

function gui.networking.gpon.set (inputTable)

	local errMsg = ""
	local statusMsg = ""

	local valid  = true
    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
      return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (util.fileExists ("/pfrm2.0/HW_JCO410")) then
        local reservedVid = db.getAttribute ("environment", "name", "FALCON_VID", "value")
        if (reservedVid ~= nil) then
            if (reservedVid == inputTable["vlanID"]) then
                return "ERROR", "VlanId is already in Use"
            end
        end
    end

    -- require
    require "teamf1lualib/gpon"
	local bridgeRow = db.getRow ("bridgeMode", "_ROWID_", "1")
	if ((bridgeRow["bridgeMode.status"] == "1") and (bridgeRow["bridgeMode.vlanID"] == inputTable ["vlanID"])) then
		return "ERROR", "SELECTED_VLAN_ID_PRESENT_ON_BRIDGE"
	end

	if (inputTable ["vlanID"] ~= nil) then
		local ethernetVLANRows = db.getRows ("ethernetVLAN", "vlanId" , inputTable ["vlanID"])
		if (ethernetVLANRows ~= nil and #ethernetVLANRows > 0) then
			return "ERROR", "SELECTED_VLAN_ID_PRESENT_ON_WAN"
		end
	end

	db.beginTransaction() -- begin transcation

	local tmpRow = {}
	if (inputTable ["wanPortType"] == "1" ) then
		tmpRow ["gpon.status"] = "0"
	else
		tmpRow ["gpon.status"] = "1"
	end
	tmpRow ["gpon.vlanStatus"] = "1"
	tmpRow ["gpon.vlanID"] = inputTable ["vlanID"]
	tmpRow ["enableDisableSerialNumber"] = inputTable["enableDisableSerialNumber"]
	tmpRow ["ponPasswd"] = inputTable["ponPasswd"]
	tmpRow ["serialNum"] = inputTable["serialNum"]

	valid = gpon.configure (tmpRow, "1", "edit")

	if (valid) then
		errMsg = "OK"
		statusMsg = "STATUS_OK"
		db.commitTransaction()
		db.save2()
	else
		errMsg = "ERROR"
		statusMsg = "WAN_PORT_MODE_CONFIG_FAILED"
		db.rollback()
	end		
	
	return errMsg, statusMsg
	

end
