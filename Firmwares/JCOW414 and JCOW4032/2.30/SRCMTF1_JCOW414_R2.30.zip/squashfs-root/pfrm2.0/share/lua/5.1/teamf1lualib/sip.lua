--[[
#### 
#### TeamF1
#### www.TeamF1.com
#### Feb 03, 2009
#### File: sip.lua
#### Description: SIP configuration functions
#### Revisions:
]]--

--************* Requires *************

--************* Initial Code *************

--package SIP Configuration
sip = {}

--************* Functions *************

-- sip config function
function sip.config (tableName, inputTable, rowid, operation)

    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
    	return "ACCESS_DENIED", "ADMIN_REQD"
    end
    local valid = false

    if (operation == "add") then
        valid = db.insert(tableName, inputTable)
    elseif (operation == "edit") then
        valid = db.update(tableName, inputTable, rowid)
    elseif (operation == "delete") then
        valid = false
    end

	if (valid) then
		return "OK", "STATUS_OK"
	else
		return "ERROR", "SIP_CONFIG_FAILED"
	end
end

-- config get function
function sip.configGet()
    --local 
    local sipConfigTbl = {}
    
    sipConfigTbl = db.getRow ("SipStatusCtrl", "_ROWID_", "1")   
    sipConfigTbl = util.removePrefix(sipConfigTbl, "SipStatusCtrl.")

    --return 
    return sipConfigTbl
end

-- config set function
function sip.configSet(inputTbl)
    local status, errMsg
    local configRow = {}

    configRow = util.addPrefix(inputTbl, "SipStatusCtrl.")
    status, errMsg = sip.config("SipStatusCtrl", configRow, 1, "edit")

    return status, errMsg
end

-- import function
function sip.import (configTable, defaultCfgTbl, removeConfig)
	if (configTable == nil) then
		configTable = defaultCfgTbl
	end

    local sipTbl = {}
    sipTbl = config.update (configTable.SipStatusCtrl, defaultCfgTbl.SipStatusCtrl, removeConfig.SipStatusCtrl)
    if (sipTbl ~= nil and #sipTbl ~= 0) then
        for i,v in pairs(sipTbl) do
            v = util.addPrefix(v, "SipStatusCtrl.")
            sip.config ("SipStatusCtrl", v, "-1", "add")
        end
    end    
end

-- export function
function sip.export ()
    local sipall = {}
    local table = {}
    table["SipStatusCtrl"] = {}

    table["SipStatusCtrl"] = db.getTable ("SipStatusCtrl", false)
    if (table["SipStatusCtrl"] ~= nil) then
    	sipall["SipStatusCtrl"] = table["SipStatusCtrl"]
    end

	return sipall    
end

if (config.register) then
   config.register("sip", sip.import, sip.export, "1")
end

