BEGIN;
CREATE TABLE eventLog
(
	component  text NOT NULL,
	facilityId integer NOT NULL,
	logLevel  integer NOT NULL,
	time  integer NOT NULL,
	textMessage  text NOT NULL,
    binMessage blob,
    FOREIGN KEY (component,facilityId) REFERENCES compFacilityMap(component,facilityId)
)
;
COMMIT;
