/*
 * File: deviceAccess.js
 * Created on 21st May 2018 - Bala Krishna G
 * Copyright (c) 2018 TeamF1 Networks (P) Ltd.
 * All rights reserved.
 */
jQuery(function(){
    onloadCall(changeDeviceAccess, {
        imageId: 'tf1_deviceAccess',
        disableIndividual: 'tf1_macAddress',
        disableGrp: '',
        enableIndividual: '',
        enableGrp: '',
        hideClass: 'hide',
        showClass: 'configRow',
        breakDivs: 'break_macAddress',
        breakClass: 'break',
        imagesInfo: {
            disableImages: '',
            enableImages: '',
            disableClass: '',
            enableClass: ''
        }
    })
});

// On body load call the respective function
window.onload = function(){
    changeDeviceAccess({
        imageId: 'tf1_deviceAccess',
        disableIndividual: 'tf1_macAddress',
        disableGrp: '',
        enableIndividual: '',
        enableGrp: '',
        hideClass: 'hide',
        showClass: 'configRow',
        breakDivs: 'break_macAddress',
        breakClass: 'break',
        imagesInfo: {
            disableImages: '',
            enableImages: '',
            disableClass: '',
            enableClass: ''
        }
    });
}
/**
 * Wrapper function called onload
 * @method changeDhcpStatus
 * @param obj
 */
function changeDeviceAccess(toggleObj){
    onImageToggle(toggleObj);
}

function deviceAccessOnReset(frmId) {

	resetImgOnOff(frmId);
    changeDeviceAccess({
        imageId: 'tf1_deviceAccess',
        disableIndividual: 'tf1_macAddress',
        disableGrp: '',
        enableIndividual: '',
        enableGrp: '',
        hideClass: 'hide',
        showClass: 'configRow',
        breakDivs: 'break_macAddress',
        breakClass: 'break',
        imagesInfo: {
            disableImages: '',
            enableImages: '',
            disableClass: '',
            enableClass: ''
        }
    });
}

/**
 * Form Validation
 * @method upnpStatusCheck
 */
function pageValidate(frmId){

    var txtFieldIdArr = new Array();
    txtFieldIdArr[0] = "tf1_macAddress, Please enter valid MAC Address";
     
    if (txtFieldArrayCheck(txtFieldIdArr) == false) 
        return false;
	
     macObj = document.getElementById('tf1_macAddress');
    if (!(macAddrValidate(macObj.value, true, "", '', macObj))) {
        macObj.focus();
        return false;
    }
    
    setHiddenChks(frmId);
    displayProgressBar ();
    return true;
}
