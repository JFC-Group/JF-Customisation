-- To download the CSV file from DUT to local host

-- if not allowed to edit
   if (ACCESS_LEVEL ~= 0) then
       errorFlag, statusMessage = -1, "Administrator Privileges Are Required" 
       Page = "exportWebFilter"
       web.goToPage(Page, true, true)
   else
       local valid = false
       local tableName = cgi.tableName or ''
       local fileToExport = ""
       local fileName = ""

       -- check if table name exists
       if (tableName == nil) then
           return "ERROR", "NULL_PARAMETER"
       end

       if (tableName == "BlockSites") then
           valid = os.execute ("/pfrm2.0/bin/exportBlockedKeyword " .. tableName)
       elseif (tableName == "TrustedDomains") then
           valid = os.execute ("/pfrm2.0/bin/exportApprovedUrls " .. tableName)
       else
           return "ERROR", "TABLE_NOT_SUPPORTED"
       end

       if (tableName == "BlockSites") then
           fileToExport = "/tmp/exportBlockedKeyword.csv"
           fileName = "blockedKeywords"
       elseif (tableName == "TrustedDomains") then
           fileToExport = "/tmp/exportApprovedUrls.csv"
           fileName = "approvedUrls"
       end

       web.download (fileToExport, fileName .. ".csv")
   end

