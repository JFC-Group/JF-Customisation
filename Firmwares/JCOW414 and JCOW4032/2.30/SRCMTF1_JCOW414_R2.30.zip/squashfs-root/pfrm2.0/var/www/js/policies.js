/*
 * File: policies.js
 * Created on 14th July 2020 - Devaki N
 * Copyright (c) 2020 TeamF1, Inc.
 * All rights reserved.
 */

/**
 * Form Validation
 * @method policiesPageValidate
 */
function policiesPageValidate(frmId) {
	var txtFieldIdArr = new Array();
	txtFieldIdArr[0] = "tf1_txtremoteEndpoint, Please enter a valid Remote Endpoint.";
	txtFieldIdArr[1] = "tf1_txtlocalEndpoint, Please enter a valid Local Endpoint.";
	txtFieldIdArr[2] = "tf1_txtlocalIkeIdentifier, Please enter a valid Local IKE Identifier.";
	txtFieldIdArr[3] = "tf1_txtremoteIkeIdentifier, Please enter a valid Remote IKE Identifier.";
	txtFieldIdArr[4] = "tf1_txtpresharedkey, Please enter a valid Preshared key.";
	txtFieldIdArr[5] = "tf1_txtlocalStartIP, Please enter a valid Local Start IP.";
	txtFieldIdArr[6] = "tf1_txtremoteStartIP, Please enter a valid Remote Start IP.";
	txtFieldIdArr[7] = "tf1_txtlifeTime, Please enter a valid Lifetime for Phase1.";
	txtFieldIdArr[8] = "tf1_txtlifeTimePhase2, Please enter a valid Lifetime for Phase2.";

	if (txtFieldArrayCheck(txtFieldIdArr) == false)
		return false;

	if (isProblemCharArrayCheck(txtFieldIdArr, "'\" ", NOT_SUPPORTED) == false)
		return false;

	if (ipv4Validate('tf1_txtremoteEndpoint', 'IP', false, true, 'Invalid IP address.', 'for octet ', true) == false)
		return false;
	if (ipv4Validate('tf1_txtlocalEndpoint', 'IP', false, true, 'Invalid IP address.', 'for octet ', true) == false)
		return false;
	if (ikeTypeCheck ('tf1_txtlocalIkeIdentifier') == false)
	    return false; 
	if (ikeTypeCheck ('tf1_txtremoteIkeIdentifier') == false)
	    return false;  
	var preSharedObj = document.getElementById('tf1_txtpresharedkey');

	if (preSharedObj.value.length < 8 || preSharedObj.value.length > 10) {
		alert("Password field length should be between 8 and 10 characters only");
		preSharedObj.focus();
		return false;
	}
	if (ipv4Validate('tf1_txtLocalStartIP', 'NSN', false, true, 'Invalid IP address.', 'for octet ', true) == false)
		return false;
	if (ipv4Validate('tf1_txtremoteStartIP', 'NSN', false, true, 'Invalid IP address.', 'for octet ', true) == false)
		return false;
	/* Subnet checking */
	var lanIpAddrObj = document.getElementById('tf1_lanIpAddress');
	var localStIpAddressObj = document.getElementById('tf1_txtlocalStartIP');
  var lanSnMaskObj = document.getElementById('tf1_lanSubnetMask');
  var localSubnetObj =document.getElementById('tf1_selLocalSubnet');
  var localSubnet = $("#tf1_selLocalSubnet option:selected").text();
  localSubnet = localSubnet.split("/");
  var LocalSubnetselValue = comboSelectedValueGet  ('tf1_selLocalSubnet'); 
  
	//if (lanIpAddrObj && localStIpAddressObj) {
    //if(lanIpAddrObj.value != localStIpAddressObj.value ){
	//	alert('Local Start IP and LAN IP should be same.');
	//	document.getElementById('tf1_txtlocalStartIP').focus();
	//	return false;
    //}
	//}

    
    
  if (lanSnMaskObj && localSubnetObj) {
    if(lanSnMaskObj.value != localSubnet[0] ){
		alert('Local Subnet & LAN Subnet should be same.');
		document.getElementById('tf1_selLocalSubnet').focus();
		return false;
    }
    	
	}
  if(localSubnetObj && LocalSubnetselValue == "24"){
		lanIpVal = lanIpAddrObj.value.split(".");
		localStartIpVal = localStIpAddressObj.value.split(".");
		if (lanIpVal[0]!=localStartIpVal[0] || lanIpVal[1]!=localStartIpVal[1] || lanIpVal[2]!=localStartIpVal[2]) {
			alert('Local Start IP and LAN IP should be in same subnet.');
			document.getElementById('tf1_txtlocalStartIP').focus();
		 	return false;
		}
	}
  var lifeTimeObj = document.getElementById('tf1_txtlifeTime');
	if (lifeTimeObj && !lifeTimeObj.disabled) {
		if (numericValueRangeCheck(lifeTimeObj, '', '', 3600, 36000, true, 'Invalid Lifetime for Phase1.', 'Seconds.') == false) {
			return false;
		}
	}

	var lifeTimeObj1 = document.getElementById('tf1_txtlifeTimePhase2');
	if (lifeTimeObj1 && !lifeTimeObj1.disabled) {
		if (numericValueRangeCheck(lifeTimeObj1, '', '', 300, 3600, true, 'Invalid  Lifetime for Phase2.', 'Seconds.') == false) {
			return false;
		}
	}

	setHiddenChks(frmId);
	displayProgressBar();
	return true;
}
/****
 * This function calls when user selects an option from IKE Identifier type
 * OnChange event
 * @method ikeTypeCheck 
 */
function ikeTypeCheck (txtFieldIp){		
    var selValue = comboSelectedValueGet  ('tf1_selIkeIdentifiertype');        
    if (parseInt (selValue, 10) == 1){
			if (ipv4Validate(txtFieldIp, 'IP', false, true, 'Invalid IP address.', 'for octet ', true) == false)
				return false;
		}else{
			if (validateFQDN (txtFieldIp) == false)
		        return false;
		}
	 return true;
}
