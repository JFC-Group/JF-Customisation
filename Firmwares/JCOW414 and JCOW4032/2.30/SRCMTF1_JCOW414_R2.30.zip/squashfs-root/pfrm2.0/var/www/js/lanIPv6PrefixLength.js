/*
 * File: lanIPv6PrefixLength.js
 * Created on 28th Nov 2019 - Devaki N
 * Copyright (c) 2019 TeamF1, Inc.
 * All rights reserved.
 */
 /* Prefix Length Page Validation Start */
/****
 * validate the form
 * @method prefixValidate
 */
function prefixValidate(){
    var txtFieldIdArr = new Array();
    txtFieldIdArr[0] = "tf1_clientIdentifier,Please enter a valid IPv6 Client Identifier: HexaDecimal XX:XX:XX:XX:XX.XX";
    txtFieldIdArr[1] = "tf1_prefix,Please enter a valid IPv6 Prefix";
    txtFieldIdArr[2] = "tf1_ipv6PreLen,Please enter a valid IPv6 Prefix Length";
    
    if (txtFieldArrayCheck(txtFieldIdArr) == false) 
        return false;
		
	if (isProblemCharArrayCheck(txtFieldIdArr, "'\" ", NOT_SUPPORTED) == false) 
        return false;		

    if (validateClientIdentifier("tf1_clientIdentifier") == false) {
		alert("Please enter a valid Client Identifier format: HexaDecimal XX:XX:XX:XX:XX....");
		document.getElementById("tf1_clientIdentifier").focus();
		return false;
	}
    
		
    if (ipv6Validate('tf1_prefix', false, true, '') == false) 
        return false;
    
    var preLenObj = document.getElementById('tf1_ipv6PreLen');
    if (numericValueRangeCheck(preLenObj, '', '', 1, 128, true, 'Invalid IPv6 Prefix Length.', '') == false) 
        return false;
	 displayProgressBar ();
    return true;
}

/**
 * Validating the form elements
 * @method validateClientIdentifier
 * @param fieldId
 */
function validateClientIdentifier(fieldId) {
	var fldObj = document.getElementById(fieldId);
    if (!fldObj || fldObj.disabled) {
        return true;
	}
	var fieldValue = fldObj.value;
	var hexaDecimalBlocks = fieldValue.split(":");
	if ( hexaDecimalBlocks.length < 6 || hexaDecimalBlocks.length  > 20 ) {
		return false;	
	}
	for (var i=0; i < hexaDecimalBlocks.length; i++) {		
		if(alphaNumericValueCheck(hexaDecimalBlocks[i],'ABCDEFabcdef') == false || hexaDecimalBlocks[i].length != 2) {			
			 return false
		}	
	}
	return true;

}
