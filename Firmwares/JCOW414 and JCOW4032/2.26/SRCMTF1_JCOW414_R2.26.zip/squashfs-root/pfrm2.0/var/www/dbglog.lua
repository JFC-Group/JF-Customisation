--[[
#### File: dbglog.lua
#### Description: dbglog handler for lua pages.

#### Revisions:
01a,23oct12,bng written
]]--

-- requires -- 
require "teamf1lualib/db"
require "teamf1lualib/web"
require "teamf1lualib/util"

-- variables -- 
local filename     ="dbglog-enc.tgz";
DBGLOG_FILE  ="/var/dbglog.tgz";
DBGLOG_FILE_ENC  ="/var/dbglog-enc.tgz";

-- update dbglog file name using system name --
local name     = db.getAttribute("system", "_ROWID_", "1", "name");
filename = name .. "-" .. filename;

-- call mcpctl to update logs to syslog
os.execute ("/bin/mcpctl allinfo")

-- tar the conf. files --
os.execute("mkdir /tmp/dbg")
os.execute("ps >/tmp/dbg/ps.output ");

--luaError Trace
os.execute("cp -f /tmp/luaErrorTrace.txt /tmp/dbg")

--slic status
os.execute("cp -f /tmp/slic-status.txt  /tmp/dbg")


-- network state --
os.execute("route -n >/tmp/dbg/route.output ");
os.execute("ip -6 route >>/tmp/dbg/route.output ");

if(not(util.fileExists("/pfrm2.0/ECONET")))then
-- TODO: ifconfig output does not show up in the logs
    os.execute("/sbin/ifconfig -a > /tmp/dbg/ifconfig_a_1.output & wl -i wl0 counters > /tmp/dbg/wl_counters_24gz_1.log & wl -i wl1 counters > /tmp/dbg/wl_counters_5gz_1.log & sleep 5");
    os.execute("/sbin/ifconfig -a > /tmp/dbg/ifconfig_a_2.output & wl -i wl0 counters > /tmp/dbg/wl_counters_24gz_2.log & wl -i wl1 counters > /tmp/dbg/wl_counters_5gz_2.log & sleep 5");
else
    os.execute("/sbin/ifconfig -a > /tmp/dbg/ifconfig_a_1.output & iwpriv ra0 stat > /tmp/dbg/wl_counters_24gz_1.log & iwpriv rai0 stat > /tmp/dbg/wl_counters_5gz_1.log & sleep 5");
    os.execute("/sbin/ifconfig -a > /tmp/dbg/ifconfig_a_2.output & iwpriv ra0 stat > /tmp/dbg/wl_counters_24gz_2.log & iwpriv rai0 stat > /tmp/dbg/wl_counters_5gz_2.log & sleep 5");
    os.execute("/userfs/bin/iwconfig > /tmp/dbg/iwconfig.output");
    os.execute("/userfs/bin/tcapi show WLan > /tmp/dbg/tcapi_WLan.output");
    os.execute("/userfs/bin/tcapi show WLan11ac > /tmp/dbg/tcapi_WLan11ac.output");
    os.execute("cat /etc/wts_bss_info_config > /tmp/dbg/wts_bss_info_config.output");
    os.execute("cat /tmp/dump.txt > /tmp/dbg/dump.txt");
    os.execute("cat /tmp/dump_v2.txt > /tmp/dbg/dump_v2.txt");
    os.execute("cat /etc/Wireless/RT2860AP/RT2860AP.dat > /tmp/dbg/2g_dat.txt");
    os.execute("cat /etc/Wireless/RT2860AP_AC/RT2860AP.dat > /tmp/dbg/5g_dat.txt");
    os.execute("cp -f /tmp/WirelessReapply.txt /tmp/dbg")
end
os.execute("/sbin/ifconfig -a > /tmp/dbg/ifconfig_a_3.output ");

--ifgroup
os.execute("/pfrm2.0/bin/ifgroup -L > /tmp/dbg/ifgroup.output ");

if (util.fileExists ("/pfrm2.0/BRCMJCO300")) then
--mcpd
os.execute("cat /var/mcpd.conf > /tmp/dbg/mcpd.conf");

os.execute("date > /tmp/dbg/bs_gem_1.output  & date >/tmp/dbg/bs_iptv_1.output");
os.execute("bdmf_shell -c `cat /var/bdmf_sh_id` -cmd /b/e gem >> /tmp/dbg/bs_gem_1.output & bdmf_shell -c `cat /var/bdmf_sh_id` -cmd /b/e iptv >> /tmp/dbg/bs_iptv_1.output & sleep 2");
os.execute("date > /tmp/dbg/bs_gem_2.output  & date >/tmp/dbg/bs_iptv_2.output");
os.execute("bdmf_shell -c `cat /var/bdmf_sh_id` -cmd /b/e gem >> /tmp/dbg/bs_gem_2.output & bdmf_shell -c `cat /var/bdmf_sh_id` -cmd /b/e iptv >> /tmp/dbg/bs_iptv_2.output & sleep 2");
os.execute("date > /tmp/dbg/bs_gem_3.output  & date >/tmp/dbg/bs_iptv_3.output");
os.execute("bdmf_shell -c `cat /var/bdmf_sh_id` -cmd /b/e gem >> /tmp/dbg/bs_gem_3.output & bdmf_shell -c `cat /var/bdmf_sh_id` -cmd /b/e iptv >> /tmp/dbg/bs_iptv_3.output & sleep 2");
end

os.execute ("cat /proc/net/igmp > /tmp/dbg/proc.net.igmp ");

-- firewall rules
os.execute("/pfrm2.0/bin/iptables -L -n -v > /tmp/dbg/filter.log");
os.execute("/pfrm2.0/bin/iptables -t nat -L -n -v > /tmp/dbg/nat.log");
os.execute("/pfrm2.0/bin/iptables -t mangle -L -n -v > /tmp/dbg/mangle.log");
os.execute("/pfrm2.0/bin/ip6tables -L -n -v > /tmp/dbg/filter6.log");
os.execute("/pfrm2.0/bin/ip6tables -t mangle -L -n -v > /tmp/dbg/mangle6.log");

-- free memory
os.execute("echo '1' > /proc/sys/vm/drop_caches")
os.execute("free > /tmp/dbg/free.log")

os.execute("cp -f /tmp/nosignal.txt /tmp/dbg/nosignal.txt");
os.execute("cp -f /tmp/igmp-proxy.log /tmp/dbg/igmp-proxy.log");
os.execute("cp -f /etc/igmpproxy.conf /tmp/dbg/igmpproxy.conf");
os.execute("cp -f /tmp/igmp-proxy-old.log /tmp/dbg/igmp-proxy-old.log");

-- arp
os.execute("cat /proc/net/stat/arp_cache > /tmp/dbg/arp.log ");
os.execute("cat /proc/net/ip_conntrack > /tmp/dbg/ip_conntrack.log ");
os.execute("cat /proc/net/arp >> /tmp/dbg/arp.log ");
os.execute("cp -f /flash/teamf1.cfg.ascii.bak /tmp/dbg/teamf1.cfg.ascii.bak");
os.execute("cp -f /flash/teamf1.cfg.ascii /tmp/dbg/teamf1.cfg.ascii");
os.execute("cp -f /tmp/asciiCorrupted1 /tmp/dbg/asciiCorrupted1");
os.execute("cp -f /tmp/asciiCorrupted2 /tmp/dbg/asciiCorrupted2");
os.execute("cp -f /tmp/asciiCorruptedbkp /tmp/dbg/asciiCorruptedbkp");

--dms, ras and ras_proxy logs
os.execute("cp -f /tmp/dms.log /tmp/dbg/");
os.execute("cp -f /tmp/ras.log /tmp/dbg/");
os.execute("cp -f /var/twine/ras_proxy/ras_proxy.log /tmp/dbg/");
os.execute("cp -f /tmp/OntNetworkLock.txt /tmp/dbg/");

-- Handpick what is needed. FIXME:lighttpd has issues uploading huge files.
-- System
os.execute("cp -f /pfrm2.0/firmVersion /tmp/dbg/");
os.execute("cp -f /pfrm2.0/etc/svnVersion /tmp/dbg/");
os.execute("cp -f /tmp/system.db /tmp/dbg/");
os.execute("cp -f /tmp/logging.db /tmp/dbg/");
os.execute("cp -f /tmp/tr69Instance.map /tmp/dbg/");
os.execute("cp -f /tmp/tr69client.log /tmp/dbg/");
os.execute("cp -f /tmp/tr69client_error.log /tmp/dbg/");
os.execute("cp -f /tmp/tf1GlueLua.log /tmp/dbg/");
os.execute("cp -af /tmp/core/ /tmp/dbg/");
os.execute("cp -f /var/log/messages /tmp/dbg/syslog_messages")
os.execute("cp -f /etc/resolv.conf /tmp/dbg/")
os.execute("cp -f /tmp/tr69client.log.old /tmp/dbg/")
os.execute("cp -f /tmp/tr69client_error.log.old /tmp/dbg/")
os.execute("cp -f /tmp/dimclient_restart_info.txt /tmp/dbg/")
os.execute("cp -a /tmp/cpe3 /tmp/dbg/")
os.execute("ls -la /tmp/ > /tmp/dbg/ls_a_tmp.log")
os.execute("cat /proc/locks > /tmp/dbg/proc_locks.log")
os.execute("cp -f /tmp/dbgLogsKmsg.txt /tmp/dbg/proc_kmsg.log")
os.execute("ls -i /tmp/system.db > /tmp/dbg/system_db_inode.log")
os.execute("brctl show > /tmp/dbg/brctl_show.log")
os.execute("netstat -an > /tmp/dbg/netstat.log")
os.execute("nvram show > /tmp/dbg/nvram_show.log")
if(not(util.fileExists("/pfrm2.0/ECONET")))then
    os.execute("wl -i wl0 status >> /tmp/dbg/wl_status.log")
    os.execute("wl -i wl0.1 status >> /tmp/dbg/wl_status.log")
    os.execute("wl -i wl0.2 status >> /tmp/dbg/wl_status.log")
    --os.execute("wl -i wl0.3 status >> /tmp/dbg/wl_status.log")
    os.execute("wl -i wl1 status >> /tmp/dbg/wl_status.log")
    os.execute("wl -i wl1.1 status >> /tmp/dbg/wl_status.log")
    os.execute("wl -i wl1.2 status >> /tmp/dbg/wl_status.log")
    --os.execute("wl -i wl1.3 status >> /tmp/dbg/wl_status.log")
end
os.execute("cp /tmp/jhvlogs/comlib-encrypt.log /tmp/dbg/")
os.execute("cp /tmp/jhvlogs/comlib-encrypt.zip /tmp/dbg/")
os.execute("cp /tmp/jhvlogs/* /tmp/dbg/")
os.execute("cp /tmp/juicelogs/JuiceLog.txt /tmp/dbg/")
os.execute("sh /pfrm2.0/bin/copy-juice-logs.sh")

os.execute("cp /flash/juice/JuiceConfig.cfg /tmp/dbg/")
os.execute("cp /flash/juice/FixedVoiceCCS.dat /tmp/dbg/")
os.execute("cp /flash/juice/FixedVoiceCcsXML.dat /tmp/dbg/")
os.execute("cp /flash/juice/FixedVoiceFLN.dat.bkp /tmp/dbg/")
os.execute("cp /flash/juice/FixedVoiceFQDN.dat.bkp /tmp/dbg/")
os.execute("cp /flash/juice/WhitelistData.dat /tmp/dbg/")
os.execute("cp /flash/juice/PushlistData.dat /tmp/dbg/")
os.execute("cp /flash/juice/JfvSvcConfig.xml /tmp/dbg/")
os.execute("cp /flash/juice/sslCertificates/* /tmp/dbg/")


os.execute("cp /tmp/ont_dc_logs /tmp/dbg/")
os.execute("cp /tmp/ont_dc_logs.0 /tmp/dbg/")
os.execute("cp /tmp/OntNetworkLock.txt /tmp/dbg/")

os.execute("cp /var/wanMac /tmp/dbg/")
os.execute("cp /tmp/Logs/VoipApp00.log /tmp/dbg/")
os.execute("ls -l /flash/thirdparty/ > /tmp/dbg/ls_flash.txt")
os.execute("ls -l /flash/dms_xml/ > /tmp/dbg/ls_dms_xml.txt")
os.execute("cp -f /var/tmp/bootupmessages /tmp/dbg/bootupmessages.log")

os.execute("cp -a /flash/smartcable/ /tmp/dbg/")
os.execute("cp -a /tmp/smartcablelogs/ /tmp/dbg/")
os.execute("cp -a /flash/OTAtest.txt /tmp/dbg/")
os.execute("cp -a /tmp/Cable_log.txt /tmp/dbg/")
os.execute("cp -a /tmp/tm4c.log /tmp/dbg/")
os.execute("cp -a /tmp/tm4c.log.0.gz /tmp/dbg/")
os.execute("cp -a /flash/smartcable/Mqtt_credentials /tmp/dbg/")


--packet capture on LAN/WAN
--TODO - check if packet capture can cause any issue
--os.execute("tcpdump -b -s 1600 -ni bdg2 -w /tmp/dbg/lan.cap  -C 2 -W 1 & sleep 30 && killall -15 tcpdump")
--os.execute("tcpdump -b -s 1600 -ni bdg1 -w /tmp/dbg/wan.cap  -C 2 -W 1 & sleep 30 && killall -15 tcpdump")


-- MISC (network)
os.execute("date > /tmp/dbg/date.log ")

-- proc
os.execute ("cat /proc/cpuinfo > /tmp/dbg/proc.cpuinfo ");
os.execute ("cat /proc/devices > /tmp/dbg/proc.devices ");
os.execute ("cat /proc/filesystems > /tmp/dbg/proc.filesystems ");
os.execute ("cat /proc/meminfo > /tmp/dbg/proc.meminfo ");
os.execute ("cat /proc/modules > /tmp/dbg/proc.modules ");
os.execute ("cat /proc/mounts > /tmp/dbg/proc.mounts ");
os.execute ("cat /proc/slabinfo > /tmp/dbg/proc.slabinfo ");
os.execute ("cat /proc/uptime > /tmp/dbg/proc.uptime ");
os.execute ("top -n 1 > /tmp/dbg/top.output ");

if(util.fileExists("/pfrm2.0/ECONET"))then
	os.execute("cp -f /tmp/wl_info.txt /tmp/dbg/")
	os.execute("cp -af /var/wadt_log/ /tmp/dbg/")
end

--veip0 error log 
if(util.fileExists("/tmp/veiplog.txt"))then
	os.execute("cp -f /tmp/veiplog.txt /tmp/dbg/")
end


if (util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED")) then
	-- mesh and wifi related in BRCM  mesh devices
	os.execute ("/bin/nvram show > /tmp/dbg/nvram.show.txt ");	
	os.execute ("/usr/sbin/wb_cli -m info > /tmp/dbg/wb_cli_into.txt ");	
	os.execute ("/usr/sbin/i5ctl dm > /tmp/dbg/i5ctl_dm.txt ");	
	os.execute ("cp -f /tmp/ce0.log  /tmp/dbg/ce0.log ");	
end

local opMode_24GZ     = db.getAttribute("dot11Radio", "_ROWID_", "1", "opMode");
if (opMode_24GZ ~= nil) then       
    if (tonumber(opMode_24GZ) == 1 ) then 
        os.execute("echo Wifi Mode for 2.4 GZ = b and g mode > /tmp/dbg/wifiMode_status") 
    elseif (tonumber(opMode_24GZ) == 2 ) then
        os.execute("echo Wifi Mode for 2.4 GZ = b only mode > /tmp/dbg/wifiMode_status")
    elseif (tonumber(opMode_24GZ) == 3 ) then 
        os.execute("echo Wifi Mode for 2.4 GZ = b/g/n mode > /tmp/dbg/wifiMode_status")
    elseif (tonumber(opMode_24GZ) == 4 ) then 
        os.execute("echo Wifi Mode for 2.4 GZ = n only mode > /tmp/dbg/wifiMode_status")
    elseif (tonumber(opMode_24GZ) == 5 ) then 
        os.execute("echo Wifi Mode for 2.4 GZ = ng mode > /tmp/dbg/wifiMode_status")
    elseif (tonumber(opMode_24GZ) == 6 ) then 
        os.execute("echo Wifi Mode for 2.4 GZ = g only mode > /tmp/dbg/wifiMode_status")
    else
        os.execute("echo Wifi Mode for 2.4 GZ= " .. opMode_24GZ .. " > /tmp/dbg/wifiMode_status")
    end
end                                                                             
                                                                                
local opMode_5GZ     = db.getAttribute("dot11Radio", "_ROWID_", "2", "opMode"); 
if (opMode_5GZ ~= nil) then                                                    
    if (tonumber(opMode_5GZ) == 1 ) then 
        os.execute("echo Wifi Mode for 5 GZ = a only mode >> /tmp/dbg/wifiMode_status") 
    elseif (tonumber(opMode_5GZ) == 2 ) then
        os.execute("echo Wifi Mode for 5 GZ = a/n/ac mode >> /tmp/dbg/wifiMode_status")
    elseif (tonumber(opMode_5GZ) == 3 ) then 
        os.execute("echo Wifi Mode for 5 GZ = ac mode >> /tmp/dbg/wifiMode_status")
    elseif (tonumber(opMode_5GZ) == 4 ) then 
        os.execute("echo Wifi Mode for 5 GZ = n only mode >> /tmp/dbg/wifiMode_status")
    elseif (tonumber(opMode_5GZ) == 5 ) then 
        os.execute("echo Wifi Mode for 5 GZ = a/n mode >> /tmp/dbg/wifiMode_status")
    elseif (tonumber(opMode_5GZ) == 6 ) then 
        os.execute("echo Wifi Mode for 5 GZ = n/ac mode >> /tmp/dbg/wifiMode_status")
    else
        os.execute("echo Wifi Mode for 5 GZ = " .. opMode_5GZ .. " >> /tmp/dbg/wifiMode_status")
    end
end       

-- All files in /tmp and /var
-- os.execute("cd /tmp/dbg && tar -czf " .. DBGLOG_FILE .. " * /var/* /tmp/* /etc/minidlna.conf /proc/* --exclude=kcore");
os.execute("cd /tmp/dbg && /bin/tar -c -f " .. DBGLOG_FILE .. " * && cd");

-- remove dbglog encryption for now from econet because openssl tool is not present in econet rootfs
-- Encrypting conf file
    local encKey="/pfrm2.0/etc/server.key"
    local outFile=DBGLOG_FILE

    command = "/pfrm2.0/bin/usrKlite openssl aes-128-cbc -kfile /pfrm2.0/etc/server.key -in " .. DBGLOG_FILE .. " -out " .. DBGLOG_FILE_ENC
    util.runShellCmd(command, nil, nil, nil);

-- send the tarred file back to agent --
web.download(DBGLOG_FILE_ENC, filename);


-- delete the temp tar file created -- 
os.execute("/bin/rm -rf ".. DBGLOG_FILE);
os.execute("/bin/rm -rf /tmp/dbg " .. DBGLOG_FILE);
