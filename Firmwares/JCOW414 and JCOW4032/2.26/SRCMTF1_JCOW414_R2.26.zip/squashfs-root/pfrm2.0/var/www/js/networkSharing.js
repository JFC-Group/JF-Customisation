/*
 * File: networkSharing.js
 * Created on 19th Sep 2013 - Bala Krishna G
 * Copyright (c) 2013 TeamF1, Inc.
 * All rights reserved.
 */
/**
 * Form Validation
 * @method pageValidate
 */
function pageValidate (frmId){
    var txtFieldIdArr = new Array ();
    txtFieldIdArr[0] = "tf1_txtfriendlyName,Please enter a valid Friendly Name";
    
    if (txtFieldArrayCheck (txtFieldIdArr) == false)
         return false;
    


if (friendlyNameValidate() == false)
        return false;

    // Removing space before and after string value
    var submitVal = $('#tf1_txtfriendlyName').val().trim();
    var input = $("<input>").attr("type", "hidden").attr("name", "friendlyName").val(submitVal);
    // Appending input value to form data.
    $('#tf1_enablenetworkSharing').append($(input));



	setHiddenChks (frmId);
    displayProgressBar ();
   return true;
}
    
function validateTextField (txtFldEvent, errMsg){
    if (!isProblemChar (txtFldEvent, " '\"", errMsg) == false)
        return false;
    return true;
}

 
/**
 * This function calls Page loads
 * Onload validation
 * @method onloadCall
 */
jQuery(function(){
    onloadCall(enableDMSSetup, {
        imageId: '',
        disableIndividual: '',
        disableGrp: '',
        enableIndividual: '',
        enableGrp: '',
        hideClass: 'hide',
        showClass: 'configRow',
        breakDivs: '',
        breakClass: 'break',
        imagesInfo: {
            disableImages: '',
            enableImages: '',
            disableClass: '',
            enableClass: ''
        }
    });
 enableDisableSharing();
	/* Commenting changes for ContentAggregation in SDK 1.2.0 */
    /* enableDisableContentAggregaion(); */
    var dmsVal = $("#hdShareSettingsVal").val();
      if(dmsVal == "0"){
            fieldStateChangeWr("tf1_txtfriendlyName", "", "", "");
            vidualDisplay("tf1_txtfriendlyName", 'hide');
            vidualDisplay("break_txtfriendlyName", 'hide');
        } 
	else{
	fieldStateChangeWr("", "", "tf1_txtfriendlyName", "");
       vidualDisplay("tf1_txtfriendlyName", 'configRow');
       vidualDisplay("break_txtfriendlyName", 'break');
	}
});

 

/**
 * Wrapper function called onload
 * @method changeDhcpStatus
 * @param obj
 */
function enableNetworkSharing(toggleObj){
    onImageToggle(toggleObj);
    enableDisableSharing();
var dmsVal = $("#hdShareSettingsVal").val();
      if(dmsVal == "0"){
            fieldStateChangeWr("tf1_txtfriendlyName", "", "", "");
            vidualDisplay("tf1_txtfriendlyName", 'hide');
            vidualDisplay("break_txtfriendlyName", 'hide');
        } 
        else if (dmsVal == "1"){
            fieldStateChangeWr("", "", "tf1_txtfriendlyName", "");
            vidualDisplay("tf1_txtfriendlyName", 'configRow');
            vidualDisplay("break_txtfriendlyName", 'break');
            /* Commenting changes for ContentAggregation in SDK 1.2.0 */
            /* enableDisableContentAggregaion(); */
        }	
}

/**
 * Wrapper function called onload
 * @method changeDhcpStatus
 * @param obj
 */
function networkSharingOnReset(toggleObj){
 
    onImageToggle(toggleObj);
    enableDisableSharing();
var dmsVal = $("#hdShareSettingsVal").val();
      if(dmsVal == "0"){
            fieldStateChangeWr("tf1_txtfriendlyName", "", "", "");
            vidualDisplay("tf1_txtfriendlyName", 'hide');
            vidualDisplay("break_txtfriendlyName", 'hide');
        } 
        else if (dmsVal == "1"){
            fieldStateChangeWr("", "", "tf1_txtfriendlyName", "");
            vidualDisplay("tf1_txtfriendlyName", 'configRow');
            vidualDisplay("break_txtfriendlyName", 'break');
            /* Commenting changes for ContentAggregation in SDK 1.2.0 */
            /* enableDisableContentAggregaion(); */
        }	
}
  
function enableDisableSharing(){

    var imgObjVal = document.getElementById('tf1_enablenetworkSharing').src;
    var hddmsVal = $("#hdShareSettingsVal").val();
            var imageName = imgObjVal.substring(imgObjVal.lastIndexOf('/') + 1);
            if (imageName == "button_off.png") {
 
                fieldStateChangeWr("tf1_txtfriendlyName", "", "", "");
                vidualDisplay("tf1_txtfriendlyName", 'hide');
                vidualDisplay("break_txtfriendlyName", 'hide');
                /* Commenting changes for ContentAggregation in SDK 1.2.0 */
                /* enableDisableContentAggregaion(); */
            }
            else if(hddmsVal == "1" && imageName == "button_on.png"){
 
                fieldStateChangeWr("", "", "tf1_txtfriendlyName", "");
                vidualDisplay("tf1_txtfriendlyName", 'configRow');
                vidualDisplay("break_txtfriendlyName", 'break');
               /* Commenting changes for ContentAggregation in SDK 1.2.0  */
               /* enableDisableContentAggregaion(); */
            }
}

/**
 * This function for enable or disable fields while clicking on on off image
 * Onclick event
 * @method enableTextFieldByImageClick
 * @param imgId - image Id
 * @param fieldIds - space separated field names
 * @param brk - space separated break names
 */
function enableTextFieldByImageClick(imgId,fieldIds,brk){   
    
    var imgObjVal = document.getElementById(imgId).src;    
    var imageName = imgObjVal.substring (imgObjVal.lastIndexOf ('/') + 1);
    if (imageName == ON_IMAGE) {                   
        fieldStateChangeWr ('', '', fieldIds, '');
        vidualDisplay(fieldIds,'configRow');       
        vidualDisplay (brk,'break');
    }else if (imageName == OFF_IMAGE) {   
        fieldStateChangeWr (fieldIds, '', '', '');
        vidualDisplay(fieldIds,'hide');
        vidualDisplay (brk,'hide');
    }
}

/**
 * Wrapper function called onload
 * @method enableDMSSetup
 * @param obj
 */
function enableDMSSetup(obj, thisObj){
    onImageToggle(obj);
    var imgId=thisObj.id;
    switch(imgId){
        case 'tf1_enablenetworkSharing':  
           enableDisableSharing();
        break;
   }
}
