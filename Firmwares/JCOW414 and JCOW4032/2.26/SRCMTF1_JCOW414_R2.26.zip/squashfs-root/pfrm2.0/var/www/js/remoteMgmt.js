/*
 * File: remoteMgmt.js
 * Created on 4th Jan 2013 - Bala krishna G
 * Modified on 8th Jan 2013 - Lakshmi
 * Copyright (c) 2012 TeamF1, Inc.
 * All rights reserved.
 */
/**
 * This function calls Page loads
 * Onload validation
 * @method onloadCall
 */
jQuery(function(){
    onloadCall(enableRemoteMgmt, {
        imageId: 'tf1_chkEnable',
        disableIndividual: 'tf1_txtOnlyThisPC tf1_txtPort',
        disableGrp: '',
        enableIndividual: '',
        enableGrp: '',
        hideClass: 'hide',
        showClass: 'configRow',
        breakDivs: 'break_txtOnlyThisPC break_txtPort',
        breakClass: 'break',
        imagesInfo: {
            disableImages: '',
            enableImages: '',
            disableClass: '',
            enableClass: ''
        }
    })
});

// On body load call the respective function
window.onload = function(){
    enableRemoteMgmt({
        imageId: 'tf1_chkEnable',
        disableIndividual: 'tf1_txtOnlyThisPC tf1_txtPort',
        disableGrp: '',
        enableIndividual: '',
        enableGrp: '',
        hideClass: 'hide',
        showClass: 'configRow',
        breakDivs: 'break_txtOnlyThisPC break_txtPort',
        breakClass: 'break',
        imagesInfo: {
            disableImages: '',
            enableImages: '',
            disableClass: '',
            enableClass: ''
        }
    });
}

/**
 * Wrapper function called onload
 * @method changeDhcpStatus
 * @param obj
 */
function enableRemoteMgmt(toggleObj){
    onImageToggle(toggleObj);
}

/* Reset function for form

*/

function remoteManagementOnReset(frmId) {

	resetImgOnOff(frmId);
	enableRemoteMgmt({
        imageId: 'tf1_chkEnable',
        disableIndividual: 'tf1_txtOnlyThisPC tf1_txtPort',
        disableGrp: '',
        enableIndividual: '',
        enableGrp: '',
        hideClass: 'hide',
        showClass: 'configRow',
        breakDivs: 'break_txtOnlyThisPC break_txtPort',
        breakClass: 'break',
        imagesInfo: {
            disableImages: '',
            enableImages: '',
            disableClass: '',
            enableClass: ''
        }
    });

	

}
/****
 * validate the form
 * OnClick validation
 * @method remoteMgmtValidation
 */
function remoteMgmtValidation(frmId){

    var txtFieldIdArr = new Array();
    txtFieldIdArr[0] = "tf1_txtOnlyThisPC, Please enter a valid IP Address.";    
    txtFieldIdArr[1] = "tf1_txtPort, Please enter a valid Port.";
    
    if (txtFieldArrayCheck(txtFieldIdArr) == false) 
        return false;

	if (isProblemCharArrayCheck(txtFieldIdArr, "'\" ", NOT_SUPPORTED) == false) 
        return false;
    
    if (ipv4Validate("tf1_txtOnlyThisPC", "IP", false, true, "Invalid IP address.", "for octet ", true) == false) 
        return false;
    
    var portObj = document.getElementById("tf1_txtPort");
    if (!portObj.disabled) {
        if (numericValueRangeCheck(portObj, "", "", 1, 65535, true, "", "") == false) 
            return false;
    }
    setHiddenChks (frmId);
   displayProgressBar ();
   return true;
}
