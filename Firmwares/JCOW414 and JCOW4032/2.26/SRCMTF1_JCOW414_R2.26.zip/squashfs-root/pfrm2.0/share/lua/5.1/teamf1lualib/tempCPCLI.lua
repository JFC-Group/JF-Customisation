-- tempCLI.lua
-- Arvind ratnu
-- TeamF1
-- www.TeamF1.com
-- 10Oct2012

require "teamf1lualib/captivePortal"

-- This routine reads in the current captive Portal Billing configuration information
-- into a configuration object.
function tmpProfileCfgInit (args)  
	local configRow={}

    if(args[1] == nil)then
		configRow["tempCPUserProfiles._ROWID_"] = "-1"
		configRow["tempCPUserProfiles.MaxUsageTrafficCheck"] = "0"
		configRow["tempCPUserProfiles.MaxUsageTimeCheck"] = "0"
    else
		configRow = captivePortal.getBillingProfileDetails(args[1])
    end

  	if(configRow == nil)then
        print("Entered rowid does not exist\n")
        return -1, {}
    end

    return rowId,configRow
end

-- This routine saves the modified configuration information.
function tmpProfileCfgSave (configRow)
    local errorFlag = "OK"
    local statusCode = ""
    local statusMessage = ""

	if(configRow["tempCPUserProfiles._ROWID_"] == "-1") then
		errorFlag, statusCode = captivePortal.bilingProfileConfig(configRow, "-1", "add")
	else
		errorFlag, statusCode = captivePortal.bilingProfileConfig(configRow,configRow["tempCPUserProfiles._ROWID_"],"edit")
	end

    -- save db if no error
    if (errorFlag == "OK") then db.save() end
    statusMessage = db.getAttribute("stringsMap", "stringId", statusCode, LANGUAGE)   or ''

    return errorFlag, statusMessage or ''
end

-- This routine validates the ospf configuration information.                                                
function tmpProfileCfgInputVal (configRow)
	if(configRow["tempCPUserProfiles.ProfileName"] == nil) then
		print("Please enter Profile Name")
		return false
	end
	if(configRow["tempCPUserProfiles.ProfileDesc"] == nil) then
		print("Please enter Profile Description")
		return false
	end
	if(configRow["tempCPUserProfiles.IdleTimeout"] == nil) then
		print("Please enter Session Idle Timeout Value")
		return false
	end
	if(configRow["tempCPUserProfiles.MultiLogin"] == nil or configRow["tempCPUserProfiles.MultiLogin"] == "") then
		print("Please either Enable or Disable Multi Login Support:<allow_multiple_login>")
		return false
	end
	if(configRow["tempCPUserProfiles.ModifyAccount"] == nil or configRow["tempCPUserProfiles.ModifyAccount"] == "") then
		print("Please either Enable or Disable Customization at Front Desk:<allow_customization_at_frontdesk>")
		return false
	end
	if(configRow["tempCPUserProfiles.BatchGen"] == nil or configRow["tempCPUserProfiles.BatchGen"] == "") then
		print("Please either Enable or Disable Batch Generation:<allow_batch_frontdesk>")
		return false
	end
	if(configRow["tempCPUserProfiles.ValidDurationCheck"] == nil or configRow["tempCPUserProfiles.ValidDurationCheck"] == "") then
		print("Please either Enable or Disable Valid Duration With Begin and End Time:<enable_begin_end_time>")
		return false
	end
	if(configRow["tempCPUserProfiles.AlertType"] == nil or configRow["tempCPUserProfiles.AlertValue"] == nil or configRow["tempCPUserProfiles.AlertType"] == "" or configRow["tempCPUserProfiles.AlertValue"] == "") then
		print("Please enter Alert Interval Value and Alert Interval Type:<alert_customize>")
		return false
	end

	if(configRow["tempCPUserProfiles.ValidDurationCheck"] == "1") then
		if(configRow["tempCPUserProfiles.DurationType"] == nil) then
			print("Please enter a Duration Type:<valid_begin_type>")
			return false
		end

		if(configRow["tempCPUserProfiles.DurationType"] == "0") then
			if(configRow["tempCPUserProfiles.StartCreatedTime"] == "" or configRow["tempCPUserProfiles.StartCreatedTime"] == nil or configRow["tempCPUserProfiles.StartCreatedType"] == nil or configRow["tempCPUserProfiles.StartCreatedType"] == "") then
				print("Please enter Start creation time Value and Type:<valid_begin start_created>")
				return false
			end
			if(configRow["tempCPUserProfiles.StartCreatedType"] == "0") then
				if( tonumber(configRow["tempCPUserProfiles.StartCreatedTime"]) > 23) then
					print("Range of Start Created Value is 1-23 Hours")
					return false
				end
			end
			if(configRow["tempCPUserProfiles.StartCreatedType"] == "1") then
				if( tonumber(configRow["tempCPUserProfiles.StartCreatedTime"]) > 365) then
					print("Range of Start Created Value is 1-365 days")
					return false
				end
			end	
		end

		if(configRow["tempCPUserProfiles.DurationType"] == "1") then
			if(configRow["tempCPUserProfiles.StartLoginTime"] == "" or configRow["tempCPUserProfiles.StartLoginTime"] == nil or configRow["tempCPUserProfiles.StartLoginType"] == nil or configRow["tempCPUserProfiles.StartLoginType"] == "") then
				print("Please enter Start login time Value and Type:<valid_begin start_login>")
				return false
			end
			if(configRow["tempCPUserProfiles.StartLoginType"] == "0") then
				if( tonumber(configRow["tempCPUserProfiles.StartLoginTime"]) > 23) then
					print("Range of Start Login Value is 1-23 Hours")
					return false
				end
			end
			if(configRow["tempCPUserProfiles.StartLoginType"] == "1") then
				if( tonumber(configRow["tempCPUserProfiles.StartLoginTime"]) > 365) then
					print("Range of Start Login Value is 1-365 days")
					return false
				end
			end
		end

		if(configRow["tempCPUserProfiles.DurationType"] == "2") then
			if(configRow["tempCPUserProfiles.BeginDate"] == nil or configRow["tempCPUserProfiles.BeginDate"] == "") then
				print("Please enter Begin Date:<valid_begin begin_time>")
				return false
			end
		end
	end

	if(configRow["tempCPUserProfiles.ModifyUsage"] == "1") then
		if(configRow["tempCPUserProfiles.MaxUsageTimeCheck"] == nil and configRow["tempCPUserProfiles.MaxUsageTrafficCheck"] == nil) then
			print("Please enter Max Usage or Max Traffic")
			return false
		end
		if(configRow["tempCPUserProfiles.MaxUsageTimeCheck"] == "1") then
			if(configRow["tempCPUserProfiles.MaxUsageTimeValue"] == nil) then
				print("Please enter Max Usage Time Value")
				return false
			end
			if(configRow["tempCPUserProfiles.MaxUsageTimeType"] == nil) then
				print("Please enter Max Usage Time Type")
				return false
			end
		end
		if(configRow["tempCPUserProfiles.MaxUsageTrafficCheck"] == "1") then
			if(configRow["tempCPUserProfiles.MaxUsageTrafficValue"] == nil) then
				print("Please enter Max Usage Traffic Value")
				return false
			end
			if(configRow["tempCPUserProfiles.MaxUsageTrafficType"] == nil) then
				print("Please enter Max Usage Traffic Type")
				return false
			end
		end
	end
	
	if(tonumber(configRow["tempCPUserProfiles.IdleTimeout"]) > 60) then
		print("Range of Session Idle Timeout is 1 - 60 minutes")
		return false
	end

	if(configRow["tempCPUserProfiles.AlertType"] == "0") then
		if( tonumber(configRow["tempCPUserProfiles.AlertValue"]) > 23) then
			print("Range of Alert Interval is 1-23 Hours")
			return false
		end
	end

	if(configRow["tempCPUserProfiles.AlertType"] == "1") then
		if( tonumber(configRow["tempCPUserProfiles.AlertValue"]) > 365) then
			print("Range of Alert Interval is 1-365 days")
			return false
		end
	end

	if(configRow["tempCPUserProfiles.AlertType"] == "2") then
		if( tonumber(configRow["tempCPUserProfiles.AlertValue"]) > 1000) then
			print("Range of Alert Interval is 1-1000 MB")
			return false
		end
	end

	if(configRow["tempCPUserProfiles.AlertType"] == "3") then
		if( tonumber(configRow["tempCPUserProfiles.AlertValue"]) > 100) then
			print("Range of Alert Interval is 1-100 GB")
			return false
		end
	end

	if(configRow["tempCPUserProfiles.MaxUsageTimeCheck"] == "1") then
		if(configRow["tempCPUserProfiles.MaxUsageTimeType"] == "0") then
			if( tonumber(configRow["tempCPUserProfiles.MaxUsageTime"]) > 23) then
				print("Range of Max Usage Time Value is 1-23 Hours")
				return false
			end
		end

		if(configRow["tempCPUserProfiles.MaxUsageTimeType"] == "1") then
			if( tonumber(configRow["tempCPUserProfiles.MaxUsageTimeValue"]) > 365) then
				print("Range of Max Usage Time Value is 1-365 days")
				return false
			end
		end
	end

	if(configRow["tempCPUserProfiles.MaxUsageTrafficCheck"] == "1") then
		if(configRow["tempCPUserProfiles.MaxUsageTrafficType"] == "2") then
			if( tonumber(configRow["tempCPUserProfiles.MaxUsageTrafficValue"]) > 1000) then
				print("Range of Max Usage Traffic Value is 1-1000 MB")
				return false
			end
		end

		if(configRow["tempCPUserProfiles.MaxUsageTrafficType"] == "3") then
			if( tonumber(configRow["tempCPUserProfiles.MaxUsageTrafficValue"]) > 100) then
				print("Range of Max Usage Taffic Value is 1-100 GB")
				return false
			end
		end
	end

	return true	
end

function tmpProfileCfgDel(args)
	configRow = db.getRow("tempCPUserProfiles", "_ROWID_", args[1])
	if(configRow == nil)then
        print("Entered rowid does not exist\n")
        return
    end
	errorFlag, statusCode = captivePortal.cpTempUserProfileConfig (configRow,"delete")
	if (errorFlag == "OK") then db.save() end
	return
end

function tmpProfileCfgShow(args)
	local groupTable = captivePortal.getBillingProfileDetails(args[1])
    local resultTab = {}
    if (groupTable == nil) then
    	print("The Billing profile specified does not exist.Please use <show net cp all_billing_profile> to see all billing profiles configured")
    else
		printLabel ("-------------CP Billing Profile----------------\n")
       	resTab.insertField (resultTab, "Profile Name", groupTable["tempCPUserProfiles.ProfileName"]  or "")
		resTab.insertField (resultTab, "Profile Description", groupTable["tempCPUserProfiles.ProfileDesc"]  or "")
		if(groupTable["tempCPUserProfiles.MultiLogin"] == "1") then
			resTab.insertField (resultTab, "Multiple Login", "Enable")
		else
			resTab.insertField (resultTab, "Multiple Login", "Disable")
		end
		if(groupTable["tempCPUserProfiles.ModifyAccount"] == "1") then
			resTab.insertField (resultTab, "customize on Front Desk", "Enable")
		else
			resTab.insertField (resultTab, "customize account on Front Desk", "Disable")
		end
		if(groupTable["tempCPUserProfiles.BatchGen"] == "1") then
			resTab.insertField (resultTab, "batch generation on Front Desk", "Enable")
		else
			resTab.insertField (resultTab, "batch generation on Front Desk", "Disable")
		end
		resTab.insertField (resultTab, "Session Idle Timeout", groupTable["tempCPUserProfiles.IdleTimeout"] .." mins"  or "")
		if(groupTable["tempCPUserProfiles.AlertType"] == "0") then
			resTab.insertField (resultTab, "ALert Interval", groupTable["tempCPUserProfiles.AlertValue"] .." hours" or "")
		elseif (groupTable["tempCPUserProfiles.AlertType"] == "1") then
			resTab.insertField (resultTab, "ALert Interval", groupTable["tempCPUserProfiles.AlertValue"] .." days" or "")
		elseif (groupTable["tempCPUserProfiles.AlertType"] == "2") then
			resTab.insertField (resultTab, "ALert Interval", groupTable["tempCPUserProfiles.AlertValue"]  .." MB" or "")
		else
			resTab.insertField (resultTab, "ALert Interval", groupTable["tempCPUserProfiles.AlertValue"]  .." GB" or "")
		end
		if(groupTable["tempCPUserProfiles.ValidDurationCheck"] == "1") then
			if(groupTable["tempCPUserProfiles.DurationType"] == "2") then
				resTab.insertField (resultTab, "Begin Date", groupTable["tempCPUserProfiles.BeginDate"]  or "")
			end
			if(groupTable["tempCPUserProfiles.DurationType"] == "1") then
				if(groupTable["tempCPUserProfiles.StartLoginType"] == "0") then
					resTab.insertField (resultTab, "Start Time Value", groupTable["tempCPUserProfiles.StartLoginTime"] .." hours" or "")
				else
					resTab.insertField (resultTab, "Start Time Value", groupTable["tempCPUserProfiles.StartLoginTime"]  .." days" or "")
				end
			end
			if(groupTable["tempCPUserProfiles.DurationType"] == "0") then
				if(groupTable["tempCPUserProfiles.StartCreatedType"] == "0") then
					resTab.insertField (resultTab, "Start Time Value", groupTable["tempCPUserProfiles.StartCreatedTime"] .." hours" or "")
				else
					resTab.insertField (resultTab, "Start Time Value", groupTable["tempCPUserProfiles.StartCreatedTime"] .." days" or "")
				end
			end
		end
		if(groupTable["tempCPUserProfiles.MaxUsageTrafficCheck"] == "1") then
			if(groupTable["tempCPUserProfiles.MaxUsageTrafficType"] == "2") then
				resTab.insertField (resultTab, "Max Usage Traffic", groupTable["tempCPUserProfiles.MaxUsageTrafficValue"] .. " MB" or "")
			else
				resTab.insertField (resultTab, "Max Usage Traffic", groupTable["tempCPUserProfiles.MaxUsageTrafficValue"]  .. " GB" or "")
			end
		end
		if(groupTable["tempCPUserProfiles.MaxUsageTimeCheck"] == "1") then
			if(groupTable["tempCPUserProfiles.MaxUsageTimeType"] == "0") then
				resTab.insertField (resultTab, "Max Usage Time ", groupTable["tempCPUserProfiles.MaxUsageTimeValue"] .." hours" or "")
			else
				resTab.insertField (resultTab, "Max Usage Time ", groupTable["tempCPUserProfiles.MaxUsageTimeValue"] .." days" or "")
			end
		end
		if(groupTable["tempCPUserProfiles.ModifyDuration"] == "1") then
			resTab.insertField (resultTab, "Frontdesk to Modify Duration", "Enable")
		else
			resTab.insertField (resultTab, "Frontdesk to Modify Duration", "Disable")
		end
		if(groupTable["tempCPUserProfiles.ModifyUsage"] == "1") then
			resTab.insertField (resultTab, "Frontdesk to Modify Usage", "Enable")
		else
			resTab.insertField (resultTab, "Frontdesk to Modify Usage", "Disable")
		end		
		
	end
    resTab.print (resultTab, 0)
end


function tmpProfileCfgShowAll(args)
 	local groupTable = db.getTable ("tempCPUserProfiles")
    local resultTab = {}
    local groupRow = nil
    local rowId = 0
	local groupname = ""
	local description = ""
    printLabel ("-------------CP Billing Profiles----------------\n")
    if (groupTable == nil) then
    	print("There are no entries in system")
    else
        for col, val in pairs(groupTable) do
        	rowId = rowId+1
        	groupRow = groupTable[rowId]
      		if (groupRow ~= nil) then
        		groupname = groupRow["tempCPUserProfiles.ProfileName"] or ''
           		description = groupRow["tempCPUserProfiles.ProfileDesc"] or ''
            	resTab.insertField (resultTab, "ROWID", groupRow["tempCPUserProfiles._ROWID_"]  or "")
          		resTab.insertField (resultTab, "Profile Name", groupname or "")
        		resTab.insertField (resultTab, "Profile Description", description or "")
      		end
    	end
    resTab.print (resultTab, 0)
    end
end
