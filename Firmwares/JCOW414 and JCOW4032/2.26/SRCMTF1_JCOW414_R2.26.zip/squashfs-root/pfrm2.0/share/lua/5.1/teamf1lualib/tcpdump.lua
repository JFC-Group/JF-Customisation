--[[
#### Sat
#### TeamF1
#### www.TeamF1.com
#### Jan 22, 2008

#### File: tcpdump.lua
#### Description: tcpdump functions

#### Revisions:
None
]]--


--************* Requires *************

--************* Initial Code *************
--package tcpdump
tcpdump = {}
--************* Functions *************
-- tcpdump config
function tcpdump.config (inputTable, rowid, operation)
    -- validate
    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
            return db.insert("tcpdump", inputTable)
        elseif (operation == "edit") then
            return db.update("tcpdump", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("tcpdump",inputTable)
        end
    end
    return false
end

--[[
function tcpdump.config2 (inputTable, rowid, operation)
        -- if not allowed to edit
        if (ACCESS_LEVEL ~= 0) then
                return "ACCESS_DENIED", "ADMIN_REQD"
        end
        db.beginTransaction() --begin transaction
        local valid = false

        
    
    if (inputTable ["tcpdump.tcpdumpEnabled"] == "1" ) then
        local interfaceName = db.getAttribute ("tcpdump", "_ROWID_", rowid, "interfaceName")
        
        local lanIf = db.getAttribute("networkInterface","interfaceName",interfaceName,"interfaceName")
        local wanIf = db.getAttribute("networkInterface","LogicalIfName","WAN1","interfaceName")
        if (interfaceName == lanIf or interfaceName == wanIf) then
        local ret = db.getRowsWhere ("networkInterface", "interfaceName = '" .. interfaceName .. "'")
        for key,value1 in pairs (ret) do
            local WanInterface = value1 ["networkInterface.LogicalIfName"]
            if (WanInterface ~= "WAN1") then
                break
            else 
            local status = db.getRowsWhere ("nimfStatus", "LogicalIfName = '" .. WanInterface .. "'")
                for key2,value2 in pairs (status) do
                    local WanStatus = value2 ["nimfStatus.Nimfstatus"]
                    if (WanStatus == "Connected") then 
                        break
                    else
                        db.rollback()
                        return "ERROR", "TCPDUMP_IFACE_DOWN"
                    end
                end            
            end
        end
    else
            local ConfigPort = db.getAttribute ("ConfigPort", "_ROWID_", 1, "LogicalIfName")   
            local status = db.getRowsWhere ("nimfStatus", "LogicalIfName = '" .. ConfigPort .. "'")   
            for key2,value2 in pairs (status) do
                    local WanStatus = value2 ["nimfStatus.Nimfstatus"]
                    if (WanStatus == "Connected") then 
                        break
                    else
                        db.rollback()
                        return "ERROR", "TCPDUMP_IFACE_DOWN"
                    end
              end            
          end
      end
     
                

        -- validate
        if (true) then
                if (operation == "add") then
                        return nil
                elseif (operation == "edit") then
                        valid = tcpdump.update_config(inputTable,rowid)
                elseif (operation == "delete") then
                        return nil
                end
        end

        -- return
        if (valid) then
                db.commitTransaction()
                return "OK", "STATUS_OK"
        else
                db.rollback()
                return "ERROR", "TCPDUMP_CONFIG_FAILED"
        end
end
]]--
-------------------------------------------------------------------------
-- @name tcpdump.cfgInit
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function tcpdump.cfgInit(row, conf)

    if (conf["interfaceName"] ~= nil) then
        row["interfaceName"] = conf["interfaceName"]
    end

    if (conf["tcpdumpEnabled"] ~= nil) then
        row["tcpdumpEnabled"] = conf["tcpdumpEnabled"]
    end
                    
    return row
end

-------------------------------------------------------------------------
-- @name tcpdump.set
--
-- @description 
--
-- @return 
--
function tcpdump.configure(confTbl)
   
    local tcpdumpTbl = {}
    local valid = false
    if (confTbl == nil) then
        return "ERROR", "TCPDUMP_INVALID_PARAM"        
    end
                    
    local query = "interfaceName='" .. confTbl["interfaceName"] .. "'"
    local row = db.getRowWhere("tcpdump", query, false)
    if (row == nil) then
        return "ERROR", "FAILED_TO_GET_CONF"
    end
   
    row = tcpdump.cfgInit(row, confTbl)

    row = util.addPrefix(row, "tcpdump.")

    local valid, errstr = db.update("tcpdump", row, row["tcpdump._ROWID_"])
    if (not valid) then
        return "ERROR", "PTRACE_UPDATE_FAILED"
    end
	
	-- no need to save capture status across reboot SPR:61649
    --db.save()
    return "OK", "STATUS_OK"

end

-------------------------------------------------------------------------
-- @name tcpdump.get
--
-- @description 
--
-- @return 
--
function tcpdump.get()
    return db.getTable("tcpdump",false)
end

-- Updating Configurations
function tcpdump.update_config (inputTable,rowid)
    -- updating TCPDUMP Configurations
    valid = db.update("tcpdump",inputTable,rowid)
    return valid
end

function tcpdump.import (configTable, defaultConfig, removeConfig)

    if (configTable == nil) then
        configTable = defaultConfig 
    end
    
    local confTbl = {}
    confTbl = config.update (configTable, defaultConfig, removeConfig)
	
    if (confTbl ~= nil and #confTbl ~= 0) then
        for i,v in ipairs (confTbl) do
            -- change virtual WAN interface
            if ( v["phyInterface"] ~= nil and v["phyInterface"] == "veip0") then
                v["phyInterface"] = "bdg1"
            end
            if ( v["phyInterface"] ~= nil and v["phyInterface"] == "pon") then
                v["phyInterface"] = "bdg1"
            end
            v = util.addPrefix (v, "tcpdump.");
            tcpdump.config (v, -1, "add")
        end
    end
end

function tcpdump.export ()
    return db.getTable ("tcpdump", false)
end

if (config.register) then
   config.register("tcpdump", tcpdump.import, tcpdump.export, "1")
end
