-- @copyright Copyright (c) 2012, TeamF1, Inc. 

require "teamf1lualib/evtDsptch"
require "dhcpLib"
require "appExtn/AppExtn"

DhcpdExtn = OoUtil.inheritsFrom(AppExtn)
DhcpdExtn.name    = "IPv4 DHCP Server"
DhcpdExtn.className   = "DhcpdExtn"
DhcpdExtn.classId = "dhcpd"
DhcpdExtn.dbTable =  nil
DhcpdExtn.logger  = nil

local SUPER = require("appExtn.AppExtn")

local netEvents  = {}
netEvents[evtDsptch.event.IFDEV_EVENT_IP4_NET_UP] =  1
netEvents[evtDsptch.event.IFDEV_EVENT_IP4_NET_DOWN] =  1
netEvents[evtDsptch.event.IFDEV_EVENT_NET_DEL] =  1

local cfgEvents = {}
cfgEvents[db.event.SQLITE_INSERT] = 1
cfgEvents[db.event.SQLITE_UPDATE] = 1
cfgEvents[db.event.SQLITE_DELETE] = 1

-------------------------------------------------------------------------------
-- @name DhcpdExtn:new
--
-- @description This function creates a new instance object for dhcpd 
--
-- @return  
--

function DhcpdExtn:new(instanceId, props)

    assert(instanceId, "Instance ID must be specified")

    -- create a new instance
    self = DhcpdExtn.create()

    SUPER.new(self, DhcpdExtn.classId, instanceId, props)

    self.name  = DhcpdExtn.name
    self.dbTable = DhcpdExtn.dbTable
    self.dbconn = DhcpdExtn.dbconn
    self.logger = DhcpdExtn.logger

    -- initialize events for this instance
    self.netEvents = netEvents              
    self.cfgEvents = cfgEvents

    -- 
    -- onCreate hook to initialize the backend
    -- for this instance of the application
    -- TODO: pass instanceId
    --
    local handle = db.gethandle(self.dbconn)
    dhcpLib.init(handle)

    -- list of dhcp configured interfaces
    self.ifTbl = {}

    -- load the configuration for the instance
    if (self:load() < 0) then
        return nil
    end        

    -- register with appd
    appd.appExtnRegister(self)                    

    return self
end

-------------------------------------------------------------------------------
-- @name DhcpdExtn:delete
--
-- @description This function deletes an instance of this extension
--
-- @return  
--

function DhcpdExtn:delete() 
    appd.appExtnUnregister(self)
    return 
end        

-------------------------------------------------------------------------------
-- @name DhcpdExtn:cfgFileWrite
--
-- @description This function re-writes the configuration file
--
-- @return  0 for success and -1 for error
--

function DhcpdExtn:cfgFileWrite ()

    LOG:info("Re-writing configuration for " .. self.name ..  
             "(" ..  self.instanceId .. ")")

    local status = dhcpLib.v4CfgWrite()
    if (status < 0) then
        LOG:error(self.name .. " configuration re-write failed.")
        return status
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name DhcpdExtn:start
--
-- @description This function starts dhcpd
--
-- @return  0 for success and -1 for error
--

function DhcpdExtn:start ()

    -- is configuration enabled
    --[[if (not self:isEnabled()) then
        return 0
    end ]]--       

    -- is IPv6 network Up on dhcpv6 enabled interfaces
    if (not self:isDhcpdIfUp()) then
        LOG:debug("IPv4 network is not up for DHCP server enabled interfaces")
        -- TODO: stop the DHCP server if it is running
        return 0
    end        

    -- write configuration
    local status = self:cfgFileWrite()
    if (status < 0) then
        return status
    end        
    
    -- start
    LOG:info("Starting " .. self.name ..  "(" ..  self.instanceId .. ")")
    local status = dhcpLib.v4Restart()
    if (status < 0) then
        LOG:error(self.name .. " start failed")
        return status
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name DhcpdExtn:stop
--
-- @description This function stops dhcpd
--
-- @return  0 for success and -1 for error
--

function DhcpdExtn:stop ()

    -- stop
    LOG:info("Stoping " .. self.name ..  "(" ..  self.instanceId .. ")")
    local status = dhcpLib.v4Stop()
    if (status < 0) then
        LOG:error(self.name .. " stop failed")
        return status
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name DhcpdExtn:restart
--
-- @description This function restarts dhcpd
--
-- @return  0 for success and -1 for error
--

function DhcpdExtn:restart ()

    --[[local status = self:stop()
    if (status < 0) then
        return -1
    end]]--

    local status = self:start()
    if (status < 0) then
        return -1
    end        
    
    return 0
end

-------------------------------------------------------------------------------
-- @name DhcpdExtn:getAppName
--
-- @description This function gets the name of this extension
--
-- @return  
--

function DhcpdExtn:getAppName()
   return self.name
end

-------------------------------------------------------------------------------
-- @name DhcpdExtn:load
--
-- @description This function loads the dhcp server configuration from the
-- data store
--
-- @return  
--

function DhcpdExtn:load()
    local poolTbl = {} -- list of all DHCPv6 pools 
    local optionTbl = {}
    local reservedAddrTbl = {}

    -- get all the pools
    poolTbl = db.getTable("DhcpServerPools", false)
    if (poolTbl == nil) then
        return -1        
    end        

    -- get all the reserved addresses
    addrTbl = db.getTable("DhcpfixedIpAddress", false)
    if (addrTbl == nil) then
        return -1        
    end

    -- get all the options
    optionTbl = db.getTable("DhcpOption", false)
    if (poolTbl == nil) then
        return -1        
    end        

    -- sort address reservations by pool ID
    local sortedAddrTbl = {}
    for index, addr in pairs(addrTbl) do
        local PoolID = addr.PoolID
        if (sortedAddrTbl[PoolID] == nil) then
            sortedAddrTbl[PoolID] = {}
        end            
        table.insert(sortedAddrTbl[PoolID], addr)
    end        
    
    -- sort option table by pool ID
    local sortedOptTbl = {}
    for index, option in pairs (optionTbl) do
        local PoolID = option.PoolID
        if (sortedOptTbl[PoolID] == nil) then
            sortedOptTbl[PoolID] = {}
        end
        table.insert(sortedOptTbl[PoolID], option)
    end        

    -- sort all the pools by interface
    local ifTbl = {}
    for index, pool in pairs (poolTbl) do

        -- add options to the pool
        pool.options = {}
        table.insert(pool.options, sortedOptTbl[pool.PoolID])

        -- add reserved addresses to the pool
        pool.reservedAddrTbl = {}
        table.insert(pool.reservedAddrTbl, sortedAddrTbl[pool.PoolID])

        local LogicalIfName = pool.LogicalIfName
        if (ifTbl[LogicalIfName] == nil) then
            ifTbl[LogicalIfName] = {}
        end
        table.insert(ifTbl[LogicalIfName], pool)
    end        

    self.ifTbl = ifTbl

    return 0
end

-------------------------------------------------------------------------------
-- @name DhcpdExtn:isDhcpdIfUp 
--
-- @description This function checks if IPv4 connection is UP on the given
-- interface. if LogicalIfName is nil then it checks if connection is UP on
-- any of the configured interfaces
--
-- @return  0 for success and -1 for error
--

function DhcpdExtn:isDhcpdIfUp(LogicalIfName)
    require "teamf1lualib/nimf"

    for ifName, pool in pairs(self.ifTbl) do
        --
        -- check if LogicalIfName is nil or
        -- if it matches an entry in our configuration
        --
        if ((LogicalIfName == nil) or 
            ((LogicalIfName ~= nil) and 
             (strlib.strcasecmp(LogicalIfName, ifName)  == 0))) then
            if (nimfConn.isIPv4Up(ifName)) then             
                return true
            end                
        end
    end

    return false
end

-------------------------------------------------------------------------------
-- @name DhcpdExtn:isEnabled
--
-- @description This function checks if DHCP server is enabled on the given
-- interface. if LogicalIfName is nil, then it checks if it is enabled on
-- any interface
-- 
-- @param  LogicalIfName
--
-- @return  0 for success and -1 for error
--

function DhcpdExtn:isEnabled(LogicalIfName)

    for ifName, poolTbl in pairs(self.ifTbl) do

        for index, pool in pairs(poolTbl) do        
            --
            -- check if LogicalIfName is nil or
            -- if it matches an entry in our configuration
            --
            if ((LogicalIfName == nil) or 
                ((LogicalIfName ~= nil) and 
                 (strlib.strcasecmp(LogicalIfName, ifName)  == 0))) then
                if (tonumber(pool.Enable) > 0) then
                    return true
                end                
            end
        end

    end
                
    return false
end

-------------------------------------------------------------------------------
-- @name DhcpdExtn:ifDelete
--
-- @description This function deletes dhcp configuration on an interface
--
-- @param  LogicalIfName
--
-- @return  0 for success and -1 for error
--

function DhcpdExtn:ifDelete(LogicalIfName)

    assert(LogicalIfName, "LogicalIfName not provided") 

    if (dhcpLib.v4PoolDelete(LogicalIfName) < 0) then
        return -1
    end         

    return 0
end

-------------------------------------------------------------------------------
-- @name DhcpdExtn:onNetEvent
--
-- @description This function handles network events for dhcpd
--
-- @param  netevent event info
--
-- @return  0 for success and -1 for error
--

function DhcpdExtn:onNetEvent(netevent)

    if (self:isEventSubscribed(netevent) == false) then
        LOG:ddebug(self.classId .. " not subscribed to event: " ..
                  netevent.event .. " on " .. netevent.ifname)
        return 0
    end        

    if (netevent.event == evtDsptch.event.IFDEV_EVENT_NET_DEL) then
        self:ifDelete(netevent.ifname)
    else
        if (netevent.ifname == "IF2") then 
            self:restart()
        end
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name DhcpdExtn:isEventSubscribed
--
-- @description This function checks if the application is subcribed to
-- the event 
--
-- @param event event info
--
-- @return  0 for success and -1 for error
--

function DhcpdExtn:isEventSubscribed(event)

    if (event.type == appd.eventType.APPD_EV_NET) then

        local evstate = self.netEvents[event.event]
        if (evstate == nil) then
            return false
        end            
                    
        if (evstate > 0) then
            return true
        end        

    elseif (event.type == appd.eventType.APPD_EV_CFG) then

        -- are we subscribed to this event                        
        local evstate = self.cfgEvents[event.event]
        if (evstate == nil) then
            return false
        end            

        if (evstate > 0) then
            return true
        end        
    end

    return false
end

-------------------------------------------------------------------------------
-- @name DhcpdExtn:onCfgEvent
--
-- @description This function is called to handle configuration events
-- 
-- @param  cfgevent event information
--
-- @return  
--

function DhcpdExtn:onCfgEvent(cfgevent)

    if (self:isEventSubscribed(cfgevent) == false) then
        LOG:ddebug(self.classId .. " not subscribed to event: " ..
                  cfgevent.event .. " on " .. cfgevent.dbTable)
        return
    end        

    -- load the configuration for the instance
    if (self:load() < 0) then
        return nil
    end        

    -- restart dhcpd
    self:restart()

    return
end

-------------------------------------------------------------------------------
-- @name DhcpdExtn:print
--
-- @description This function is called by appd to bootstrap all instances of 
-- this application. 
--
-- @param  
--
-- @return  
--

function DhcpdExtn:print()
    require "util/strlib"

    LOG:info("Class     : " .. self.classId)
    LOG:info("Instance  : " .. self.instanceId)
    LOG:info("App Name  : " .. self:getAppName())

    return
end

-------------------------------------------------------------------------------
-- @name DhcpdExtn.cfgEventCallback
--
-- @description 
--
-- @return  
--

function DhcpdExtn.cfgEventCallback(obj, info)

    LOG:ddebug(DhcpdExtn.classId .. " configuration callback called  " .. 
              "for event: " ..  info.event .. " on rowId " .. info.rowId)

    obj:onCfgEvent(info) 

    return 0
end

-------------------------------------------------------------------------------
-- @name DhcpdExtn.bootstrap
--
-- @description This function is called by appd on startup to bootstrap all 
-- instances of this application. 
--
-- @param  
--
-- @return  
--

function DhcpdExtn.bootstrap()
    local instanceId="1"
    local callbackTable= {}

    local callback = {}
    callback.type = appd.eventType.APPD_EV_CFG
    callback.routine = DhcpdExtn.cfgEventCallback
    callback.dbTable = "DhcpServerPools"
    table.insert(callbackTable, callback)

    local callback = {}
    callback.type = appd.eventType.APPD_EV_CFG
    callback.routine = DhcpdExtn.cfgEventCallback
    callback.dbTable = "DhcpOption"
    table.insert(callbackTable, callback)

    local callback = {}
    callback.type = appd.eventType.APPD_EV_CFG
    callback.routine = DhcpdExtn.cfgEventCallback
    callback.dbTable = "DhcpfixedIpAddress"
    table.insert(callbackTable, callback)

    appd.callbackRegister (DhcpdExtn.classId, callbackTable)

    -- create an instance and restart it
    local obj = DhcpdExtn:new(instanceId)
    if (obj) then
        obj:restart()
    end                        

    return 0
end

return DhcpdExtn
