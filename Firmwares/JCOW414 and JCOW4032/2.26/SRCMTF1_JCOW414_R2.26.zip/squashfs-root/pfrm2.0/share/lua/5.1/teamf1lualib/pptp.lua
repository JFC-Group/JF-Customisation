--[[
#### Hussain Vali.
#### TeamF1
#### www.TeamF1.com
#### Mar 11, 2008
#### File: pptp.lua
#### Description: PPTP Setup functions
#### Revisions:
01a, 08oct13, ash changes for Password encryption/decryption
]]--

--************* Requires *************
require "passwdSecureLib"

--************* Initial Code *************

pptp = {}

-- PPTP config
function pptp.config (inputTable, rowid, operation)
    -- validate
    if (operation == "add") then
        return db.insert("Pptp", inputTable)
    elseif (operation == "edit") then
        return db.update("Pptp", inputTable, rowid)
    elseif (operation == "delete") then
        return db.delete("Pptp", inputTable)
    end
end

function pptp.import (inputTable, defaultCfg, remCfg)
   local status
   if (inputTable == nil) then
        inputTable = defaultCfg
    end
    
    --initializing a temp table
    local configTable = {}

    configTable = config.update (inputTable, defaultCfg, remCfg)
    if (configTable ~= nil and #configTable ~= 0)then
        for i,v in ipairs (configTable) do
            if (v["Password"] ~= nil and v["Password"] ~= "") then 
                status, v["Password"] = passwdSecureLib.decryptData (v["Password"], "")
            end
            v = util.addPrefix (v, "Pptp.")
            db.insert ("Pptp", v)
        end
    end
end

function pptp.export ()
    local status
    local pptpconf = db.getTable ("Pptp", false)
    for i, v in ipairs (pptpconf) do
        if (v["Password"] ~= nil and v["Password"] ~= "") then
            status, pptpconf[i].Password = passwdSecureLib.encryptData (v["Password"], "")
        end
    end
    return pptpconf
end

if (config.register) then
   config.register("pptp", pptp.import, pptp.export, "1")
end
