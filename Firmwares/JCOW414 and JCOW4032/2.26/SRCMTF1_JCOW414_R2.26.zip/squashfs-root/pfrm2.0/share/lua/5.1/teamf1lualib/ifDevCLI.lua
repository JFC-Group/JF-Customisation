-- ethernetCLI.lua
-- Gaurav Mathur
-- TeamF1
-- www.TeamF1.com

-- Copyright (c) 2017, TeamF1 Networks Pvt. Ltd. 
-- (Subsidiary of D-Link India)

-- Modification History
-- 17Apr18,swr Changes for SPR 63646(csv result format)
-- 08Aug17,swr Changes for SPR 60819(health monitoring)
-- 25dec07,gnm Modified bdgCLIStatsGet() to use ifStatsPrint() to
--             print fields to CLI; Added ifStatsPrint(); Added
--	       ifCLIStatsGet() as generic interface stats print
--	       routine.
-- 23dec07,gnm modified aliasipGet(); added lanSetupGet; added
--             bdgCLIStatsGet()
-- 09dev07 gnm written
--
-- Description
-- CLI interface set and get routines

require "teamf1lualib/ifDev"

--
-- This routine validates the LAN configuration information.
function aliasipCfgInputVal(configRow)
    return true
end

--
-- This routine saves the modified LAN configuration information.
function aliasipCfgSave(configRow)	 
    local errorFlag = "ERROR"
    local statusCode = ""
    local statusMessage = ""

    errorFlag, statusCode = networkInterface.config (configRow, 
	       configRow["networkInterface._ROWID_"], "edit")
    if (statusCode == "") then 
        errorFlag = "OK"		   
	statusCode = "STATUS_OK"
        db.save()
    else
	statusCode = "IFDEV_CONFIG_FAILED"
    end

    statusMessage = db.getAttribute("stringsMap", "stringId", statusCode, LANGUAGE)
    return errorFlag, statusMessage           	 
end

--
-- This routine reads in the current LAN configuration information
-- into a configuration object.
function aliasipCfgInit(args)
    local rowId = -1

    local configRow = db.getRow("networkInterface","interfaceName","bdg:0")
    if configRow == nil then
       return rowId, {}
    end
    rowId = configRow["networkInterface._ROWID_"]       
    return rowId, configRow
end

--
-- This routine validates the LAN configuration information.
function lanCfgInputVal(configRow)
    if (configRow["networkInterface.ipaddr"] == nil) then
        printCLIError ("Invalid IP address")
        return false
    end
    if (configRow["networkInterface.subnetmask"] == nil) then
        printCLIError ("Invalid IP subnetmask.")
        return false
    end
    if (configRow["networkInterface.gateway"] == nil) then
        printCLIError ("Invalid gateway IP Address.")
        return false
    end
    if (configRow["networkInterface.dns1"] == nil) then
        printCLIError ("Invalid DNS Server IP address.")
        return false
    end
    return true
end

--
-- This routine saves the modified LAN configuration information.
function lanCfgSave(configRow)
    local errorFlag = nil
    local statusCode = ""
    local statusMessage = nil

    errorFlag, statusMessage = networkInterface.config (configRow, 
	       configRow["networkInterface._ROWID_"], "edit")
    if (statusMessage == "") then 
        statusCode = "STATUS_OK"
	errorFlag = "OK"
        db.save()
    else
	errorFlag = "ERROR"
	statusCode = "IFDEV_CONFIG_FAILED"
    end

    statusMessage = db.getAttribute("stringsMap", "stringId", statusCode, LANGUAGE)
    return errorFlag, statusMessage           	 
end

--
-- This routine reads in the current LAN configuration information
-- into a configuration object.
function lanCfgInit(args)
    local rowId = -1

    local configRow = db.getRow("networkInterface", "interfaceName", "bdg")
    if configRow == nil then
       return rowId, {}
    end
    
    rowId = configRow["networkInterface._ROWID_"]   
    return rowId, configRow
end

--
-- This routine takes in a table which has sets of interface
-- statistics and prints them
function ifStatsPrint (table)
    local resultTab = {}

    for _, row in pairs(table) do
	resTab.insertField (resultTab, "IFACE", row["interfaceStats.interfaceName"])
	resTab.insertField (resultTab, "PktRx", row["interfaceStats.rx_packets"])
	resTab.insertField (resultTab, "PktTx", row["interfaceStats.tx_packets"])
	resTab.insertField (resultTab, "ByteRx", row["interfaceStats.rx_bytes"])
	resTab.insertField (resultTab, "ByteTx", row["interfaceStats.tx_bytes"])
	resTab.insertField (resultTab, "ErrRx", row["interfaceStats.rx_errors"])
	resTab.insertField (resultTab, "ErrTx", row["interfaceStats.tx_errors"])
	resTab.insertField (resultTab, "DropRx", row["interfaceStats.rx_dropped"])
	resTab.insertField (resultTab, "DropTx", row["interfaceStats.tx_dropped"])
	resTab.insertField (resultTab, "Mcast", row["interfaceStats.multicast"])
	resTab.insertField (resultTab, "Coll", row["interfaceStats.collisions"])
    end
    printLabel ("Interface Statistics")
    resTab.print (resultTab, 0)
end

--
-- This routine implements the CLI command to display bridge interface
-- statistics.
function bdgCLIStatsGet (args)
    -- run program to read the stats and update DB
    local prog = db.getAttribute("environment", "name", "IFDEVSTATS_PROGRAM", "value")
    os.execute(prog .. " " .. DB_FILE_NAME)

    local bdgTab = db.getTable ("bridgeTable")
    local resultTab = {}
    local tableIfaceInfo = {}

    for _,v in pairs(bdgTab) do
        local row = db.getRow("interfaceStats", "interfaceStats.interfaceName", 
	      v["bridgeTable.interfaceName"])
	if (row ~= nil) then
	    table.insert (tableIfaceInfo, row)
        end
    end

    ifStatsPrint (tableIfaceInfo)
    resTab.print (resultTab, 0)
end   

--
-- This routine can be used to print statistics for a set of
-- one or more interfaces. The set of interfaces is passed to this
-- routine as a table with interface names are it's elements
function ifCLIStatsGet (args)
    local tableIfaceInfo = {}	 
    local row = nil

    -- run program to read the stats and update DB
    local prog = db.getAttribute("environment", "name", "IFDEVSTATS_PROGRAM", "value")
    os.execute(prog .. " " .. DB_FILE_NAME)
    for _, iface in pairs (args) do
	row = db.getRow ("interfaceStats", "interfaceStats.interfaceName", iface)
	if (row ~= nil) then
	    table.insert (tableIfaceInfo, row)
        end
    end
    ifStatsPrint (tableIfaceInfo)
end
    
--
-- This routine implements the CLI command to show alias IP
-- configuration
function aliasipGet (args)
    local resultTab = {} -- table to store LAN setup information
    local ifdevTable = nil

    printLabel ("Alias IP Configuration")    
    for _, iface in pairs (args) do
        ifdevTable = db.getRow ("networkInterface","interfaceName", iface)
	if (ifdevTable ~= nil) then
	   resTab.insertField (resultTab, "IP Address", 
			      ifdevTable["networkInterface.ipaddr"] or "")
           resTab.insertField (resultTab, "IP Subnet Mask", 
			      ifdevTable["networkInterface.subnetmask"] or "")
        end
    end
    resTab.print (resultTab, 0)
end

--
-- This routine implements the CLI command to show the LAN
-- configuration
function lanSetupGet (args)
    local resultTab = {} -- table to store LAN setup information
    local ifdevTable = nil

    printLabel ("LAN Setup")
    for _, iface in pairs (args) do
        ifdevTable = db.getRow ("networkInterface", "interfaceName", iface)
	if (ifdevTable ~= nil) then --sanity check
	    resTab.insertField (resultTab, "IP Address", 
			       ifdevTable["networkInterface.ipaddr"] or "")
            resTab.insertField (resultTab, "IP Subnet Mask", 
			       ifdevTable["networkInterface.subnetmask"] or "")
            resTab.insertField (resultTab, "Gateway IP Address", 
			       ifdevTable["networkInterface.gateway"]  or "")
            resTab.insertField (resultTab, "DNS Server", 
			       ifdevTable["networkInterface.dns1"] or "")
        end
    end			               
    resTab.print (resultTab, 0)
end   

--
-- main function for lan clients get
-- 
function lanClientsGet (args)
    printLabel ("LAN clients")
    local resultTab = {}
    lanClientsTab = db.getTable("lanHosts", false)

    for k,v in pairs(lanClientsTab) do
        resTab.insertField (resultTab, "MACAddress", v["MACAddress"])
        if((v["IPv6Address"] ~= nil) and (v["IPv6Address"] ~= '')) then
            resTab.insertField (resultTab, "IP Address", v["IPv6Address"])
        else
            resTab.insertField (resultTab, "IP Address", v["IPAddress"])
        end
    end

    resTab.print (resultTab, 0)
end   

--
-- main function for lan stats get
-- 
function lanStatsGet (args)
    require "teamf1lualib/gui"
    require "teamf1lualib/wireless"

    --printLabel ("LAN stats")

    local resultTab = {}
    errorFlag, statusCode, networkTable = gui.status.statistics.network.get ()
    connTbl =  gui.status.networkInfo.get()
    lanUpTime = connTbl.networkLanInfoTbl.ipv4["ConnectionTime"]

    local i = 0
    for k,v in pairs(networkTable.statsTbl) do
        i = i+1
        local networkRow = networkTable.statsTbl[i]
        if (networkRow["interface"] == "Local") then
            resTab.insertField (resultTab, "PktRx", networkRow["tx_packets"])
            resTab.insertField (resultTab, "PktTx", networkRow["tx_packets"])
            resTab.insertField (resultTab, "ByteRx", networkRow["rx_bytes"])
            resTab.insertField (resultTab, "ByteTx", networkRow["tx_bytes"])
            resTab.insertField (resultTab, "ErrRx", networkRow["rx_errors"])
            resTab.insertField (resultTab, "ErrTx", networkRow["tx_errors"])
            resTab.insertField (resultTab, "DropRx", networkRow["rx_dropped"])
            resTab.insertField (resultTab, "DropTx", networkRow["tx_dropped"])
            resTab.insertField (resultTab, "Mcast", networkRow["multicast"])
            resTab.insertField (resultTab, "Uptime", lanUpTime)
        end
    end
    resTab.print (resultTab, 0)
end   
