--[[
#### Adarsh Uppula
#### TeamF1
#### www.TeamF1.com
#### June 29, 2007

####Copyright (c) 2014, TeamF1 Networks Pvt. Ltd.
####(Subsidiary of D-Link India)

####modification history
####--------------------
####01a,06dec14,mmk  Added manual time support.

#### File: time.lua
#### Description: time functions

#### Revisions:
None
]]--


--************* Requires *************

require "timeLib"

--************* Initial Code *************

--package time
time = {}

--table packages
ntp = {}

--************* Functions *************

--Function will set manual time dy execution date command
function deviceTimeSet(currentTime, timezone, dayligtSavings)
    local dateFormat = util.split(currentTime, " ")
    local date = util.split (dateFormat[1], "/")
    local year = date[3]
    local month = date[1]
    local day = date[2]
    local time = util.split(dateFormat[2], ":")
    local hours = time[1]
    local minutes = time[2]
    local seconds = "00"
    local timeFormat = dateFormat[3]
    if (timeFormat == "PM") then
        if (tonumber(hours) ~= 12) then
           hours = tonumber(hours) +12
        end
    else
        if (tonumber(hours) == 12) then
            hours = tonumber(hours) - 12
        end
    end
  
    if (tonumber(month)>12) then
	return returnCodes.ERROR
    end
        timeLib.logManualTime(1)
        local stat = os.execute("date -s".." "..year.."."..month.."."..day.."-"..hours..":"..minutes..":"..seconds)
        timeLib.logManualTime(2)
    stat = os.execute("setRtcTime".." ".."1".." "..day.." "..month.." "..year.." "..hours.." ".. minutes.." "..seconds.." "..timezone.." "..dayligtSavings) 
    return stat
end

-- time setTimeAndDate
function time.setTimeAndDate(inputTable)
	-- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end
	if (db.typeAndRangeValidate(inputTable)) then
		--call C function
		local result = timeLib.setTimeAndDate(inputTable["ntp.month"], inputTable["ntp.date"], inputTable["ntp.year"], inputTable["ntp.hours"], inputTable["ntp.minutes"], inputTable["ntp.seconds"])
		return "OK", "STATUS_OK"
	else
		return "ERROR", "TIME_STATUS_TIMEDATE_FAILED"
	end
end

-- time config
function time.ntp_config (inputTable, rowid, operation)
	-- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end
	db.beginTransaction() --begin transaction
	local valid = false
	local errorFlag1, statusCode1 = "",""
	
	valid = ntp.config(inputTable, rowid, operation)
	
	--set time-date manually
	if (inputTable["ntp.enabled"] == "0") then
		errorFlag1, statusCode1 = time.setTimeAndDate(inputTable)
		if (errorFlag1 ~= "OK") then
			valid = false
		end
	end
	
	-- return
	if (valid) then
		db.commitTransaction(true)
		return "OK", "STATUS_OK"
	else
		db.rollback()
		if (errorFlag1 == "") then
			return "ERROR", "TIME_STATUS_NTP_FAILED"
		else
			return errorFlag1, statusCode1
		end
	end
end

-- ntp config
function ntp.config (inputTable, rowid, operation)
	-- validate
	if (true) then --ntp.inputvalidate(inputTable, operation)) then
		if (operation == "add") then
			return db.insert("ntp", inputTable)
		elseif (operation == "edit") then
			return db.update("ntp", inputTable, rowid)
		elseif (operation == "delete") then
			return db.delete("ntp", inputTable)
		end
	end
	return false
end

-- ntp inputvalidate
function ntp.inputvalidate (inputTable, operation)
	if (true) then
		return db.typeAndRangeValidate(inputTable)
	end
	return false
end

--*****************************************************************************
--@name  ntp.timeGet()
--
--@description This function gets ntp configuration available in system
--
--@return

function ntp.timeGet()

    --require
    require "teamf1lualib/platform"
    --locals
	local timeTable={}
	local inputTable = {}
	local networkTbl = {}

	-- query the ntp configuration
    query = " _ROWID_=1"
    timeTable = db.getRowWhere("ntp", query, false)
	if (timeTable == nil) then
		return inputTable
	end
    timeTable.networks = {}

	-- Get all the available IPv4 network for dropdown display.
	networkTbl = platform.availableIPv4NetworkGet()
	if (networkTbl == nil) then		
        return "ERROR", "NETWORKS_GET_FAILED"
    end
    
    for i,v in pairs(networkTbl) do
        timeTable.networks[i] = {}
        timeTable.networks[i].networkname = v["networkName"]
        -- set the logical ifname selected by the user.
        -- TODO: What if the earlier user selected network does not exist at
        -- this point ?????? 
        if(timeTable["LogicalIfName"] == v["LogicalIfName"]) then
            timeTable["networkname"] = v["networkName"]
        end
    end	

    -- Set this field with the current system time, to show up in the GUI page.
    timeTable.currentTime = util.time()

    -- Set DHCP NTP Servers
    if (timeTable["dhcpNtpServer1"] == "0.0.0.0") then
        timeTable["dhcpNtpServers"] = "N/A"
    else
        timeTable["dhcpNtpServers"] = timeTable["dhcpNtpServer1"]
        if (timeTable["dhcpNtpServer2"] ~= "0.0.0.0") then
            timeTable["dhcpNtpServers"] = timeTable["dhcpNtpServers"] .. "/" .. timeTable["dhcpNtpServer2"]
        end
    end

	--return
	return timeTable
end

--******************************************************************************
--@name ntp.timeSet(inputTable)
--
--@description This function configures time insystem by calling appropriate
-- mgmt routine(s)
--
--@return
function ntp.timeSet(ntpCfgTable)

	-- include
	require "timeLib"
    require "teamf1lualib/validations"
	
	-- locals
	local statusMsg = nil
	local errMsg = nil
	local ntpInfo = {}
	local query = nil

    if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end

    if(ntpCfgTable == nil) then
        return "ERROR", "NTP_CONFIGURATION_FAILED"
    end

    -- query the SYSLOG INFO configuration
    query = " _ROWID_=1"
    ntpInfo = db.getRowWhere("ntp", query, false)
    if(ntpInfo == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    if (ntpCfgTable["networkname"] ~= nil) then
        ntpInfo["LogicalIfName"] = db.getAttribute("networkInterface", "networkName", ntpCfgTable["networkname"], "LogicalIfName")
    end

    if (ntpCfgTable["timezone"] ~= nil) then
        ntpInfo["timezone"] = ntpCfgTable["timezone"]
    end

    if (ntpCfgTable["autoDaylight"] ~= nil) then
        ntpInfo["autoDaylight"] = ntpCfgTable["autoDaylight"]
    else
		ntpInfo["autoDaylight"] = "0"
	end

     if (ntpCfgTable["enabled"] ~= nil) then
        ntpInfo["enabled"] = ntpCfgTable["enabled"]
    end 
    
    if ( ntpInfo["enabled"] == "0") then
        local valid = deviceTimeSet(ntpCfgTable["dateTime.currentTime"], ntpInfo["timezone"], ntpInfo["autoDaylight"])
    else
        if (ntpCfgTable["useDefServers"] ~= nil) then
            ntpInfo["useDefServers"] = ntpCfgTable["useDefServers"]
        end
    
        if (tonumber(ntpCfgTable["useDefServers"]) == 1) then

            ntpInfo["server1"] = db.getAttribute("environment", "name", "NTP_CUSTOM_SERVER1","value")
            ntpInfo["server2"] = db.getAttribute("environment", "name", "NTP_CUSTOM_SERVER2","value")
        else

            if (ntpCfgTable["server1"] ~= nil) then
                ntpInfo["server1"] = ntpCfgTable["server1"]
                --Verify valid ip address
                local error_msg = ntp.ipAddrValidate(ntpInfo["server1"])
                if (error_msg) then
                    return "ERROR", error_msg
                end
            end
        
            if (ntpCfgTable["server2"] ~= nil) then 
                ntpInfo["server2"] = ntpCfgTable["server2"]
                --Verify valid ip address
                local error_msg = ntp.ipAddrValidate(ntpInfo["server2"])
                if (error_msg) then
                    return "ERROR", error_msg
                end
            end
        end

        if (ntpCfgTable["reSyncNtpVal"] ~= nil) then
            ntpInfo["reSyncNtpVal"] = ntpCfgTable["reSyncNtpVal"]
        end
    end
 
    -- for the device which only have auto ntp time sync, but no manual time
    -- setting configuration.
    --ntpInfo["enabled"] = "1"

    local tmpNtpInfo = util.addPrefix (ntpInfo, "ntp.")
    errMsg, statusMsg = time.ntp_config(tmpNtpInfo,"1", "edit")
   
    -- save db if no error
    if (errMsg == "OK") then db.save() end

    return errMsg, statusMsg
end



function ntp.import (configTable, defaultConfigTable,removeConfig)
   if (configTable == nil) then
        configTable = defaultConfigTable
   end
   
   local clientTbl = {}
   local defServersTbl = {}
   local  configMergeDone = "0"
   local  configMergeDone2 = "0"
   
   defservers = configTable["defservers"]
	if (defservers ~= nil) then
        defServersTbl = config.update (configTable.defservers, defaultConfigTable.defservers, removeConfig.defservers)
        if (defServersTbl ~= nil and #defServersTbl ~= 0) then
            for i,v in ipairs (defServersTbl) do
                v = util.addPrefix (v, "ntpDefServers.")
                if (v["ntpDefServers.serverName"] == "0.pool.ntp.org") then
                    v["ntpDefServers.serverName"] = "acs.oss.jio.com"
                elseif (v["ntpDefServers.serverName"] == "1.pool.ntp.org") then
                    v["ntpDefServers.serverName"] = "in.pool.ntp.org"
                end
                db.insert("ntpDefServers", v)
            end
        end
	end

	client = configTable["client"]
	if (client ~= nil) then
        clientTbl = config.update (configTable.client, defaultConfigTable.client, removeConfig.client)
        if (clientTbl ~= nil and #clientTbl ~= 0) then
            for i,v in ipairs (clientTbl) do
                v = util.addPrefix (v, "ntp.")
                if(util.fileExists("/flash/configMerge/ntpSyncTimeChange") == false) then
                    v["ntp.reSyncNtpVal"] = 1440
                    configMergeDone = "1"
                end
                if(util.fileExists("/flash/configMerge/ntpServerUpdate") == false) then
                    v["ntp.server1"] = "acs.oss.jio.com"
                    v["ntp.server2"] = "in.pool.ntp.org"
                    configMergeDone2 = "1"
                end
                ntp.config (v, "-1", "add");
            end
            if (configMergeDone == "1") then
			    local ntpSyncTime = io.open("/flash/configMerge/ntpSyncTimeChange", "w")                                                          
                if(ntpSyncTime ~= nil) then                                                                       
            	    ntpSyncTime:close()                                                                           
                end
            end
            if (configMergeDone2 == "1") then
			    local ntpSyncTime = io.open("/flash/configMerge/ntpServerUpdate", "w")                                                          
                if(ntpSyncTime ~= nil) then                                                                       
            	    ntpSyncTime:close()                                                                           
                end
            end
        end
	end
end

function ntp.export ()
	local table = {}

    local client = db.getTable ("ntp", false)
	table["client"] = client

	local defservers = db.getTable("ntpDefServers", false)
	table["defservers"] = defservers
    
	return table
end

if (config.register) then
   config.register("ntp", ntp.import, ntp.export, "1")
end

--***************************************************************************
--ntp.ipAddrValidate - Verify whether ip address is valid or not
--check for both ipv4 and ipv6
--
--Returns: error message or nil on success
function ntp.ipAddrValidate(ipAddr)
    require "teamf1lualib/ifDev"
    require "teamf1lualib/validations"

    local lastOctateVal = ""
    local ipAddTbl = {}
    local status = "Not a valid IP Address"

    if (ipAddr == nil or ipAddr == "" or  (string.find(ipAddr,".") == nil and string.find(ipAddr,":") == nil)) then
         return status
    end

    ipAddTbl= util.split(ipAddr, ".")
    -- Get the last octet
    if (util.tableSize(ipAddTbl)) then
        lastOctateVal = ipAddTbl[util.tableSize(ipAddTbl)]
    end
    
    -- check whether the last octet is an empty value
    if (lastOctateVal == nil or lastOctateVal == "") then 
        return status
    end

    -- if it is string it will return nil otherwise it gives number
    if (tonumber(lastOctateVal)) then
        --ipv4 validate
        if (validations.ipAddressValidate(ipAddr,"","","") ~= "OK" or (#(ipAddTbl)) ~= 4) then
            return status
        end
    elseif(string.find(ipAddr, ":")) then
        --ipv6 validate
        if (string.match(ipAddr, '^fe80') or string.match(ipAddr, '^FE80')) then
            -- check if the ipv6 is not a link-local address
            return "Link-Local ip addresses are not allowed"
        elseif (ifDevLib.isIpv6AddressReserved(ipAddr) > 0) then
            -- check if the ipv6 is a reserved
            return "Reserved ip addresses are not allowed"
        elseif(ifDevLib.isIpv6AddressMulticast(ipAddr) > 0) then
            -- check if the ipv6 is multicast address
            return "Multicast ip addresses are not allowed"
        elseif (validations.ipv6AddrValidate(ipAddr,"", "") ~= 0) then
            return status
        end
    elseif(validations.tf1domainNameValidate(ipAddr,lastOctateVal) ~= "OK") then
        --domain name validate
        return status
    end

end
--***************************************************************************
