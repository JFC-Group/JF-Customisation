--[[
#### Adarsh Uppula
#### TeamF1
#### www.TeamF1.com
#### June 29, 2007
-- Copyright (c) 2017, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
#### File: dot11.lua
#### Description: dot11 functions

#### Revisions:
01x,29Aug17, sjr changes for WIFI optimization
01w,26May17, sjr Added Multiple subnets for WLAN.
01v,07apr17, ash Added changes for DSCP to P marking for lantiq
01u,18Apr17, sjr fix for SPR #59793, modified import logic for dot11Profile table
01q,25Jul16, sjr fix for the SPR #56832 
01t,20Jul16, sjr added changes to mask WPA password
01s,14Jul16, vip added hostapd_start_boot function
01r,14Jul16, vip added WPS session changes
01q,12Jul16,sjr Added changes to get SSID, password & mac from flash
01p,07Jul16,vip Removed driver initialization.
01o,18sep14, sjr added logic to set ssid & password info from devdata partition
01n,26Oct13,sen Add some delay between enabling WPS and creating bridge interface.
01m,08Oct13,ash Changes for password encryption/decryption
01l,19nov12,abr removed code of enabling/disabling rogueAP at the time of calling import function.Added that code in seperate function which is being called from GUI and in case of reboot/upgrade rogueAPEnable.lua will call that function indirectly.
01k,24han12,nrb added dot11interface table entries from ascii file
01j,22jan11,bng  changed dot11profile input validate for radius auth mode
01i,14sep09,pnm  added logic to bring up monitor mode VAP
01h,16apr09,rks  config.recOp change to hold off calling operations till
                 config is validated for all comps.
01g,14Apr09,sar  Fixed SPR 11284(Hide SSID issue).
01f,16mar09,sam  calling pnacIfAuthorize in case of repeater.This
                 would allow data packets in the kernel module in case
                 of WDS.
01e,28jan09,rks merged dot11View.lua to dot11.lua. views are not treated slution
                specific and will be implemented in solution lua files.
01d,16jan09,rks changes to move from db update based event handling to direct
                calls. cleanup to keep only dot11 related code here
01c,11Sep08,shv changes with respect to radio configuration.
01b,23dec07,sdk modified set BSSID secret function.
01a,07nov07,sdk added functions for IAPP.
]]--

--package dot11
dot11 = {}
dscpToQueueMapping = {}
dscpToCosMapping = {}
cosToQueueMapping = {}

local dscpCosMaps = {}
dscpCosMaps["Best Effort"] = 2
dscpCosMaps["Background"] = 3
dscpCosMaps["Video"] = 1
dscpCosMaps["Voice"] = 0

-- P bit mark is mapped to queue mark
-- mark = 0x00000000 |1 <<(p bit +1)
local dscpToCosMaps = {}
dscpToCosMaps[0] = 64
dscpToCosMaps[1] = 128
dscpToCosMaps[2] = 192 
dscpToCosMaps[3] = 256
dscpToCosMaps[4] = 320
dscpToCosMaps[5] = 384
dscpToCosMaps[6] = 448
dscpToCosMaps[7] = 512

--As per request from reliance changing all default values
DEFAULT_RADIO_MAX_CLIENT = "24"
DEFAULT_MAX_CLIENT = "8"
DEFAULT_MAX_CLIENT_PRIMARY_AP = "22"
DEFAULT_MAX_CLIENT_GUEST_AP = "1"
DEFAULT_2_4_AP_NAME="ap1"
DEFAULT_5_AP_NAME="ap4"


local dcspTo8021P56="6"	
local dcspTo8021P34="4"	
local dcspTo8021P20="4"	
local dcspTo8021P40="7"	
local dcspTo8021P46="6"	
local dcspTo8021P26="5"
DSCP_PBIT_FLASH_FILE="/flash/dscpTo8021Pconfig.lua"

--local IWCONFIG = "/usr/sbin/iwconfig "
local IWPRIV = "/userfs/bin/iwpriv "
local TMPDIR="/tmp"
local BINDIR="/bin"
local CMD_EXEC_SCRIPT = "/tmp/cmdExecscript.sh"

LAN_MAC_FILE = "/tmp/lanMAC1"

--table packages
dot11Interface = {}
dot11Card = {}
dot11ACL = {}
dot11Radio = {}
dot11Profile = {}
dot11VAP = {}
dot11WPS = {}
dot11WPSStations = {}
dot11pmf = {}
dot11InterfaceToBridge = {}
apGroupName = {}

-- locals
local currentVersion = "1.0.0"

function iwprivSetCmdExecute(interfaceName, variable, value)

    local IWPRIV_CMD_BINARY = "/userfs/bin/iwpriv "
    local cmdStr = IWPRIV_CMD_BINARY..interfaceName.." set "..variable.."="..value
    --os.execute("echo "..cmdStr.. " > /dev/console")
    os.execute(cmdStr)

end

function tcapiSetCmdExecute(dbstring, variable, value)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/tcapi set WLan"
    local cmdStr = TCAPI_SET_CMD_BINARY..dbstring.." "..variable.." '"..value.."'"
    --os.execute("echo "..cmdStr.. " > /dev/console")
    os.execute(cmdStr)

end

function tcapiCommitCmdExecute(dbstring)

    local TCAPI_COMMIT_CMD_BINARY = "/userfs/bin/tcapi commit WLan"
    local cmdStr = TCAPI_COMMIT_CMD_BINARY..dbstring
    --os.execute("echo "..cmdStr.. " > /dev/console")
    os.execute(cmdStr)

end

function tcapiSaveCmdExecute()

    local TCAPI_SAVE_CMD_BINARY = "/userfs/bin/tcapi save"
    --os.execute("echo "..TCAPI_SAVE_CMD_BINARY.. " > /dev/console")
    os.execute(TCAPI_SAVE_CMD_BINARY)

end

function iwprivSetCmdWrite(interfaceName, variable, value)

    local IWPRIV_CMD_BINARY = "/userfs/bin/iwpriv "
    local cmdStr = IWPRIV_CMD_BINARY..interfaceName.." set "..variable.."="..value
    --os.execute("echo "..cmdStr.. " > /dev/console")
    util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)

end

function tcapiSetCmdWrite(dbstring, variable, value)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/tcapi set WLan"
    local cmdStr = TCAPI_SET_CMD_BINARY..dbstring.." "..variable.." '"..value.."'"
    --os.execute("echo "..cmdStr.. " > /dev/console")
    util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)

end

function tcapiWebcurSetCmdWrite(variable, value)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/tcapi set WebCurSet_Entry "
    local cmdStr = TCAPI_SET_CMD_BINARY.." "..variable.." "..value
    --os.execute("echo "..cmdStr.. " > /dev/console")
    util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)

end

function tcapiInfoWLanCmdWrite(dbstring, variable, value)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/tcapi set Info_WLan"
    local cmdStr = TCAPI_SET_CMD_BINARY..dbstring.." "..variable.." "..value
    --os.execute("echo "..cmdStr.. " > /dev/console")
    util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)

end


function tcapiCommitCmdWrite(dbstring, variable, value)

    local TCAPI_COMMIT_CMD_BINARY = "/userfs/bin/tcapi commit WLan"
    local cmdStr = TCAPI_COMMIT_CMD_BINARY..dbstring
    --os.execute("echo "..cmdStr.. " > /dev/console")
    util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)

end
function tcapiMeshSetCmdWrite(dbstring, variable, value)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/tcapi set Mesh"
    local cmdStr = TCAPI_SET_CMD_BINARY..dbstring.." "..variable.." "..value
    --os.execute("echo "..cmdStr.. " > /dev/console")
    util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)

end

function tcapiMeshSetCmdExecute(dbstring, variable, value)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/tcapi set Mesh"
    local cmdStr = TCAPI_SET_CMD_BINARY..dbstring.." "..variable.." "..value
    --os.execute("echo "..cmdStr.. " > /dev/console")
    os.execute(cmdStr)

end

function tcapiMeshUnSetCmdExecute(dbstring)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/tcapi unset Mesh"
    local cmdStr = TCAPI_SET_CMD_BINARY..dbstring
    --os.execute("echo "..cmdStr.. " > /dev/console")
    os.execute(cmdStr)

end

function tcapiMeshCommitCmdWrite(dbString)

    local TCAPI_COMMIT_CMD_BINARY = "/userfs/bin/tcapi commit Mesh"
    local cmdStr = TCAPI_COMMIT_CMD_BINARY..dbString
    --os.execute("echo "..cmdStr.. " > /dev/console")
    util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)

end

function tcapiMeshCommitCmdExecute(dbString)

    local TCAPI_COMMIT_CMD_BINARY = "/userfs/bin/tcapi commit Mesh"
    local cmdStr = TCAPI_COMMIT_CMD_BINARY..dbString
    --os.execute("echo "..cmdStr.. " > /dev/console")
    os.execute(cmdStr)

end

function tcapiSaveCmdWrite()

    local TCAPI_SAVE_CMD_BINARY = "/userfs/bin/tcapi save"
    --os.execute("echo "..TCAPI_SAVE_CMD_BINARY.. " > /dev/console")
    util.fileAppend(CMD_EXEC_SCRIPT, TCAPI_SAVE_CMD_BINARY)

end



function tcapiSetChannelCmdWrite(dbString,value)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/mapd_cli /tmp/mapd_ctrl set "
    local cmdStr = TCAPI_SET_CMD_BINARY.." "..dbString.." '"..value.."'"
    --os.execute("echo "..cmdStr.. " > /dev/console")
    cmdStr = cmdStr.." >/dev/null"
    util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)
    --os.execute(cmdStr)

end

function tcapiSetChannelCmdExecute(dbString,value)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/mapd_cli /tmp/mapd_ctrl set "
    local cmdStr = TCAPI_SET_CMD_BINARY.." "..dbString.." '"..value.."'"
    --os.execute("echo "..cmdStr.. " > /dev/console")
    cmdStr = cmdStr.." >/dev/null"
    --util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)
    os.execute(cmdStr)

end



function tcapiSetMeshMacCmdExecute(dbString)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/mapd_cli /tmp/mapd_ctrl block_acl_mode "
    local cmdStr = TCAPI_SET_CMD_BINARY..dbString
    --os.execute("echo "..cmdStr.. " > /dev/console")
    cmdStr = cmdStr.." >/dev/null"
    --util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)
    os.execute(cmdStr)

end

function tcapiSetMeshMacCmdWrite(dbString)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/mapd_cli /tmp/mapd_ctrl block_acl_mode "
    local cmdStr = TCAPI_SET_CMD_BINARY..dbString
    --os.execute("echo "..cmdStr.. " > /dev/console")
    cmdStr = cmdStr.." >/dev/null"
    util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)
    --os.execute(cmdStr)

end

function tcapiSetWhiteMacCmdWrite(dbString,value)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/mapd_cli /tmp/mapd_ctrl block_acl 2 254 0 "
    local cmdStr = TCAPI_SET_CMD_BINARY.." "..dbString.." '"..value.."'"
    --os.execute("echo "..cmdStr.. " > /dev/console")
    cmdStr = cmdStr.." >/dev/null"
    util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)
    --os.execute(cmdStr)

end


function tcapiSetWhiteMacCmdExecute(dbString,value)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/mapd_cli /tmp/mapd_ctrl block_acl 2 254 0 "
    local cmdStr = TCAPI_SET_CMD_BINARY.." "..dbString.." '"..value.."'"
    --os.execute("echo "..cmdStr.. " > /dev/console")
    cmdStr = cmdStr.." >/dev/null"
    --util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)
    os.execute(cmdStr)

end

function tcapiSetBlockMacCmdWrite(dbString,value)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/mapd_cli /tmp/mapd_ctrl block_acl 2 0 0 "
    local cmdStr = TCAPI_SET_CMD_BINARY.." "..dbString.." '"..value.."'"
    --os.execute("echo "..cmdStr.. " > /dev/console")
    cmdStr = cmdStr.." >/dev/null"
    util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)
    --os.execute(cmdStr)

end

function tcapiSetBlockMacCmdExecute(dbString,value)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/mapd_cli /tmp/mapd_ctrl block_acl 2 0 0 "
    local cmdStr = TCAPI_SET_CMD_BINARY.." "..dbString.." '"..value.."'"
    --os.execute("echo "..cmdStr.. " > /dev/console")
    cmdStr = cmdStr.." >/dev/null"
    --util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)
    os.execute(cmdStr)

end


function tcapiSetUnBlockMacCmdWrite(dbString,value)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/mapd_cli /tmp/mapd_ctrl block_acl 2 1 0 "
    local cmdStr = TCAPI_SET_CMD_BINARY.." "..dbString.." '"..value.."'"
    --os.execute("echo "..cmdStr.. " > /dev/console")
    cmdStr = cmdStr.." >/dev/null"
    util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)
    --os.execute(cmdStr)

end

function tcapiSetUnBlockMacCmdExecute(dbString,value)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/mapd_cli /tmp/mapd_ctrl block_acl 2 1 0 "
    local cmdStr = TCAPI_SET_CMD_BINARY.." "..dbString.." '"..value.."'"
    --os.execute("echo "..cmdStr.. " > /dev/console")
    cmdStr = cmdStr.." >/dev/null"
    --util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)
    os.execute(cmdStr)

end

function tcapiGetValue(dbString,value)

    local TCAPI_SET_CMD_BINARY = "/userfs/bin/tcapi get WLan"
    local cmdStr = TCAPI_SET_CMD_BINARY..dbString.." "..value
    --os.execute("echo "..cmdStr.." > /dev/console")
    cmdStr = cmdStr.."> /tmp/tcapivalue"
    os.execute(cmdStr)

end



---Confiuration checks
--Vap Enable/disable case
--
function dot11VapConfigurationCheck(rowid)

    local errMsg = ""

    local dot11VAP = db.getRowWhere("dot11VAP", "_ROWID_ ='" ..rowid.."'" , false)
    local dot11Interfaces = db.getRowsWhere ("dot11Interface", "radioNo = " .. dot11VAP["radioNo"], false) 
    local profileRow = db.getRowWhere("dot11Profile", "_ROWID_ ='" ..rowid.."'" , false)    

    local vapDbStringIndex = dot11VAP["radioNo"]
    local vapDbString ="_Entry"
    local meshDbString =" "
    local ssid = ""
    local wpapsk = ""
    local hidessid = ""
    local enablessid = ""
    local maxsta = ""
    local noforwarding = ""

    if(rowid == "1" or rowid == "4") then
        if(tonumber(dot11VAP["radioNo"])==1)then
            vapDbStringIndex = rowid-1
            vapDbString ="_Entry"..vapDbStringIndex
        elseif(tonumber(dot11VAP["radioNo"])==2)then
            vapDbStringIndex = rowid-#dot11Interfaces-1
            vapDbString ="11ac_Entry"..vapDbStringIndex
        end
    else
        if(tonumber(dot11VAP["radioNo"])==1)then
            vapDbStringIndex = rowid
            vapDbString ="_Entry"..vapDbStringIndex
        elseif(tonumber(dot11VAP["radioNo"])==2)then
            vapDbStringIndex = rowid-#dot11Interfaces
            vapDbString ="11ac_Entry"..vapDbStringIndex
        end
    end

    tcapiGetValue(vapDbString,"EnableSSID") 
    enablessid = util.fileToString("/tmp/tcapivalue") 

    tcapiGetValue(vapDbString,"SSID") 
    ssid = util.fileToString("/tmp/tcapivalue") 
    ssid = ssid:sub(1, (#ssid - 1))
    
    tcapiGetValue(vapDbString,"WPAPSK") 
    wpapsk = util.fileToString("/tmp/tcapivalue") 
    
    wpapsk = wpapsk:sub(1, (#wpapsk - 1))
    tcapiGetValue(vapDbString,"HideSSID") 
    hidessid = util.fileToString("/tmp/tcapivalue") 

    tcapiGetValue(vapDbString,"MaxStaNum") 
    maxsta = util.fileToString("/tmp/tcapivalue") 
    
    tcapiGetValue(vapDbString,"NoForwarding") 
    noforwarding = util.fileToString("/tmp/tcapivalue") 

    if (util.fileExists("/flash/MESH_ENABLED") and ((dot11VAP["vapName"] == "ap1") or (dot11VAP["vapName"] == "ap4"))) then
        if(dot11VAP["vapEnabled"] == "0") then
            if(tonumber(hidessid) == tonumber(0)) then
                os.execute ("echo  Reapply the configuration in the driver From HideSSID and VapEnabled >> /tmp/WirelessReapply.txt")                
                return "ERROR"
            end
        end   
        if(tonumber(enablessid) == tonumber(0)) then
            os.execute ("echo  Reapply the configuration in the driver VapEnabled Case >> /tmp/WirelessReapply.txt")                
            return "ERROR"
        end
    else
        if(tonumber(enablessid) ~= tonumber(dot11VAP["vapEnabled"])) then
            os.execute ("echo  Reapply the configuration in the driver For VapEnabled  Secondary SSID >> /tmp/WirelessReapply.txt")                
            return "ERROR"
        end
    end

    if(profileRow["ssid"] ~= ssid or profileRow["pskPassAscii"] ~= wpapsk) then
         os.execute ("echo  Reapply the configuration in the driver For SSID and WPAPSK >> /tmp/WirelessReapply.txt")                
        return "ERROR"
    end

    if((tonumber(dot11VAP["apIsolation"]) ~= tonumber(noforwarding)) or (tonumber(dot11VAP["maxClients"]) ~= tonumber(maxsta))) then
        os.execute ("echo  Reapply the configuration in the driver For APISOLATION and NOFORWARDING >> /tmp/WirelessReapply.txt")                
        return "ERROR"
    end

    if (util.fileExists("/flash/MESH_ENABLED") and ((dot11VAP["vapName"] == "ap1") or (dot11VAP["vapName"] == "ap4"))) then
        if(dot11VAP["vapEnabled"] == "1" ) then
            if(tonumber(profileRow["broadcastSSID"]) == tonumber(hidessid)) then
                os.execute ("echo  Reapply the configuration in the driver For HideSSID  Primary Vap >> /tmp/WirelessReapply.txt")                
                return "ERROR"
            end
        end
    else
        if(tonumber(profileRow["broadcastSSID"]) == tonumber(hidessid)) then
            os.execute ("echo  Reapply the configuration in the driver For HideSSID Secondary Vap  >> /tmp/WirelessReapply.txt")                
            return "ERROR"
        end
    end

    return "OK"

end


-- dot11Interface inputvalidate
function dot11Interface.inputvalidate (inputTable, operation)

    if (true) then
        return db.typeAndRangeValidate(inputTable)
    end
    return false

end

-- dot11Interface config
function dot11Interface.config (inputTable, rowid, operation)

    -- validate
    if (dot11Interface.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("dot11Interface", inputTable)
        elseif (operation == "edit") then
            return db.setAttribute("dot11Interface", "_ROWID_", rowid, "vapName", inputTable["dot11Interface.vapName"])
        elseif (operation == "delete") then
            return nil
        end
    end
    return false

end

-- dot11 Interface_config
function dot11.Interface_config (inputTable, rowid, operation)
    
    -- config dot11Card
    local valid = dot11Interface.config(inputTable, rowid, operation)
    -- return
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DOT11_CARD_CONFIG_FAILED"
    end

end

-- dot11Card inputvalidate
function dot11Card.inputvalidate (inputTable, operation)

    if (true) then
        return db.typeAndRangeValidate(inputTable)
    end
    return false

end

-- dot11Card config
function dot11Card.config (inputTable, rowid, operation)

    -- validate
    if (dot11Card.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("dot11Card", inputTable)
        elseif (operation == "edit") then
            return db.update("dot11Card", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("dot11Card", inputTable)
        end
    end
    return false

end

-- dot11 Card_config
function dot11.Card_config (inputTable, rowid, operation)
    
    -- config dot11Card
    local valid = dot11Card.config(inputTable, rowid, operation)
    -- return
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DOT11_CARD_CONFIG_FAILED"
    end

end

-- dot11Radio inputvalidate
function dot11Radio.inputvalidate (inputTable, operation)

    if (true) then
        return db.typeAndRangeValidate(inputTable)
    end
    return false
end

-- dot11Radio config
function dot11Radio.config (inputTable, rowid, operation)

    -- validate
    if (dot11Radio.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("dot11Radio", inputTable)
        elseif (operation == "edit") then
            return db.update("dot11Radio", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("dot11Radio", inputTable)
        end
    end
    return false

end

--dot11 Radio_config
function dot11.radio_config (inputTable, rowid, operation)

    -- configg dot11Radio
    local valid = dot11Radio.config (inputTable, rowid, operation)

    -- return
    if (valid) then
        if(operation == "edit")then
             dot11.radio_config_apply(inputTable)
        end
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DOT11_RADIO_CONFIG_FAILED"
    end

end

-- dot11Profile inputvalidate
function dot11Profile.inputvalidate (inputTable, operation)

    -- check wep key length ... (hex length)
    if (inputTable["dot11Profile.security"] == "WEP" and inputTable["dot11Profile.wepKeyLength"]) then
        local wepKeyLength = inputTable["dot11Profile.wepKeyLength"]
        if (inputTable["dot11Profile.wepkey0"] and
            string.len (inputTable["dot11Profile.wepkey0"]) ~= (wepKeyLength-24)/4 and
            string.len (inputTable["dot11Profile.wepkey0"]) ~= (wepKeyLength)/4) then
            return false
        elseif (inputTable["dot11Profile.wepkey1"] and
            string.len (inputTable["dot11Profile.wepkey1"]) ~= (wepKeyLength-24)/4 and
            string.len (inputTable["dot11Profile.wepkey1"]) ~= (wepKeyLength)/4) then
            return false
        elseif (inputTable["dot11Profile.wepkey2"] and
            string.len (inputTable["dot11Profile.wepkey2"]) ~= (wepKeyLength-24)/4 and
            string.len (inputTable["dot11Profile.wepkey2"]) ~= (wepKeyLength)/4) then
            return false
        elseif (inputTable["dot11Profile.wepkey3"] and
            string.len (inputTable["dot11Profile.wepkey3"]) ~= (wepKeyLength-24)/4 and
            string.len (inputTable["dot11Profile.wepkey3"]) ~= (wepKeyLength)/4) then
            return false
        end
    elseif((inputTable["dot11Profile.security"] == "WPA") or 
        (inputTable["dot11Profile.security"] == "WPA2") or 
        (inputTable["dot11Profile.security"] == "WPA+WPA2")) then
        if ((inputTable["dot11Profile.authMethods"] == "PSK" or inputTable["dot11Profile.authMethods"] == "RADIUS")) then
            return true
        end
        if(inputTable["dot11Profile.pskPassAscii"] and
           (( string.len (inputTable["dot11Profile.pskPassAscii"]) < 8) or
           ( string.len (inputTable["dot11Profile.pskPassAscii"]) > 63))) then
           return false
        end
    elseif(inputTable["dot11Profile.security"] == "OPEN") then
        return true
    end
    if (true) then
        return db.typeAndRangeValidate(inputTable)
    end
    return false

end

--dot11Profile config
function dot11Profile.config (inputTable, rowid, operation)

    -- validate
    if (dot11Profile.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("dot11Profile", inputTable)
        elseif (operation == "edit") then
            return db.update("dot11Profile", inputTable, rowid)
        elseif (operation == "delete") then
            for k,v in pairs(inputTable) do
                valid = db.deleteRow ("dot11Profile", "_ROWID_", v)
                if (not valid) then
                    return false
                end
            end
            return true
        end
    end
    return false

end

-- dot11 Profile_config
function dot11.profile_config (inputTable, rowid, operation)

    -- config dot11Profile
    local valid = dot11Profile.config(inputTable, rowid, operation)

    if(operation == "edit")then
        valid = dot11.profile_config_apply(inputTable)
    end
    --return 
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DOT11_PROFILE_CONFIG_FAILED"
    end

end

-- dot11VAP inputvalidate
function dot11VAP.inputvalidate (inputTable, operation)
   
    if (true) then
        return db.typeAndRangeValidate(inputTable)
    end
    return false

end

-- dot11VAP config
function dot11VAP.config (inputTable, rowid, operation)

    -- validate
    if (dot11VAP.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("dot11VAP", inputTable)
        elseif (operation == "edit") then
            return db.update("dot11VAP", inputTable, rowid)
        elseif (operation == "delete") then
            for k,v in pairs(inputTable) do
                valid = db.deleteRow("dot11VAP", "_ROWID_", v)
                if (not valid) then 
                    return false 
                end
            end
            return true
        end
    end
    return false

end
-- dot11 VAP_config
function dot11.VAP_config (inputTable, rowid, operation)

    -- config dot11VAP
    local valid = dot11VAP.config(inputTable, rowid, operation)

    if(operation == "edit")then
        valid = dot11.vap_config_apply(inputTable)
    end
    --return 
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DOT11_AP_CONFIG_FAILED"
    end

end

-- dot11ACL inputvalidate
function dot11ACL.inputvalidate (inputTable, operation)

    if (true) then
        return db.typeAndRangeValidate(inputTable)
    end
    return false

end

-- dot11ACL config
function dot11ACL.config (inputTable, rowid, operation)

    -- validate
    if (dot11ACL.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("dot11ACL", inputTable)
        elseif (operation == "edit") then
            return db.update("dot11ACL", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("dot11ACL", inputTable)
        end
    end
    return false

end

-- dot11 ACL_config
function dot11.ACL_config (inputTable, rowid, operation)

    -- config dot11ACL
    local valid = dot11ACL.config(inputTable, rowid, operation)
    -- return
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DOT11_ACL_CONFIG_FAILED"
    end

end

-- dot11pmf config
function dot11pmf.config (inputTable, rowid, operation)
 
    -- validate
    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
            return db.insert("dot11pmf", inputTable)
        elseif (operation == "edit") then
            return db.update("dot11pmf", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("dot11pmf", inputTable)
        end
    end
    return false

end

-- dot11 pmf_config
function dot11.pmf_config (inputTable, rowid, operation)

    -- config dot11pmf
    local valid = dot11pmf.config(inputTable, rowid, operation)
    -- return
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DOT11_PMF_CONFIG_FAILED"
    end

end

-- dot11InterfaceToBridge config
function dot11InterfaceToBridge.config (inputTable, rowid, operation)
 
    -- validate
    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
            return db.insert("dot11InterfaceToBridge", inputTable)
        elseif (operation == "edit") then
            return db.update("dot11InterfaceToBridge", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("dot11InterfaceToBridge", inputTable)
        end
    end
    return false

end

-- dot11 InterfaceToBridge_config
function dot11.InterfaceToBridge_config (inputTable, rowid, operation)

    -- config dot11InterfaceToBridge
    local valid = dot11InterfaceToBridge.config(inputTable, rowid, operation)
    -- return
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DOT11_INTERFACETOBRIDGE_CONFIG_FAILED"
    end

end

-- dot11WPS inputvalidate
function dot11WPS.inputvalidate (inputTable, operation)

    if (true) then
        return db.typeAndRangeValidate(inputTable)
    end
    return false

end

-- dot11WPS config
function dot11WPS.config (inputTable, rowid, operation)
    -- validate
    if (dot11WPS.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("dot11WPS", inputTable)
        elseif (operation == "edit") then
            return db.update("dot11WPS", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("dot11WPS", inputTable)
        end
    end
    return false

end

-- dot11 WPS_config
function dot11.WPS_config (inputTable, rowid, operation)

    local valid = false
    local vapInterfaceName
    local oldEnabled

    local dot11Interface = db.getRowWhere("dot11Interface", "vapName ='" ..inputTable["dot11WPS.vapName"].."'" , false)
    local dot11Interfaces = db.getRowsWhere("dot11Interface", "radioNo ='" ..dot11Interface["radioNo"].."'" , false)
    if(dot11Interface == nil or dot11Interfaces == nil or #dot11Interfaces == nil)then
        return false
    end
    local vapDbStringIndex = dot11Interface["radioNo"]
    local vapDbString ="_Entry"
        
    if(dot11Interface["_ROWID_"] == "1" or dot11Interface["_ROWID_"] == "4")then                
    	if(tonumber(dot11Interface["radioNo"]) == 1)then
        	vapDbStringIndex = dot11Interface["_ROWID_"]-1
        	vapDbString ="_Entry"..vapDbStringIndex
    	elseif(tonumber(dot11Interface["radioNo"]) == 2)then
        	--TODO We assume same number of vap's are being created on both
	        --radio's. Check when different number of vap's are being created 
        	--on radio's
        	vapDbStringIndex = dot11Interface["_ROWID_"]-#dot11Interfaces-1
	        vapDbString ="11ac_Entry"..vapDbStringIndex
    	end
    else
    	if(tonumber(dot11Interface["radioNo"]) == 1)then
        	vapDbStringIndex = dot11Interface["_ROWID_"]
        	vapDbString ="_Entry"..vapDbStringIndex
    	elseif(tonumber(dot11Interface["radioNo"]) == 2)then
        	--TODO We assume same number of vap's are being created on both
	        --radio's. Check when different number of vap's are being created 
        	--on radio's
        	vapDbStringIndex = dot11Interface["_ROWID_"]-#dot11Interfaces
	        vapDbString ="11ac_Entry"..vapDbStringIndex
    	end
    end

    if (operation == "edit") then
        local oldConfig = db.getRowWhere ("dot11WPS", "_ROWID_='1'", false)
        vapInterfaceName = oldConfig["interfaceName"]
        if(vapInterfaceName ~= inputTable["dot11WPS.interfaceName"])then
            local olddot11Interface = db.getRowWhere("dot11Interface", "interfaceName ='"..vapInterfaceName.."'",false)
            local olddot11Interfaces = db.getRowsWhere("dot11Interface", "radioNo ='" ..olddot11Interface["radioNo"].."'" , false)
            if(olddot11Interface == nil or olddot11Interfaces == nil or #olddot11Interfaces == nil)then
                return false
            end
            local oldvapDbStringIndex = olddot11Interface["radioNo"]
            local oldvapDbString ="_Entry"
        
            if(olddot11Interface["_ROWID_"] == "1" or olddot11Interface["_ROWID_"] == "4")then                
                if(tonumber(olddot11Interface["radioNo"]) == 1)then
                    oldvapDbStringIndex = olddot11Interface["_ROWID_"]-1
                    oldvapDbString ="_Entry"..oldvapDbStringIndex
                elseif(tonumber(olddot11Interface["radioNo"]) == 2)then
                    --TODO We assume same number of vap's are being created on both
                    --radio's. Check when different number of vap's are being created 
                    --on radio's
                    oldvapDbStringIndex = olddot11Interface["_ROWID_"]-#olddot11Interfaces-1
                    oldvapDbString ="11ac_Entry"..oldvapDbStringIndex
                end
	        else
                if(tonumber(olddot11Interface["radioNo"]) == 1)then
                    oldvapDbStringIndex = olddot11Interface["_ROWID_"]
                    oldvapDbString ="_Entry"..oldvapDbStringIndex
                elseif(tonumber(olddot11Interface["radioNo"]) == 2)then
                    --TODO We assume same number of vap's are being created on both
                    --radio's. Check when different number of vap's are being created 
                    --on radio's
                    oldvapDbStringIndex = olddot11Interface["_ROWID_"]-#olddot11Interfaces
                    oldvapDbString ="11ac_Entry"..oldvapDbStringIndex
                end
	        end
            --disable WPS on old interface
            tcapiSetCmdWrite(oldvapDbString, "WPSConfMode", 4)
            dot11.RadioSetVapState(olddot11Interface["radioNo"])
        end
    end

    
    local valid = dot11WPS.config(inputTable, rowid, operation)

    if (valid and operation == "edit") then
        if (inputTable["dot11WPS.wpsEnabled"] == "1") then
            tcapiSetCmdWrite(vapDbString, "WPSConfMode", 4)
            tcapiSetCmdWrite(vapDbString, "WPSConfStatus", 2)
        else
            tcapiSetCmdWrite(vapDbString, "WPSConfStatus", 2)
            tcapiSetCmdWrite(vapDbString, "WPSConfMode", 4)
        end
        dot11.RadioSetVapState(dot11Interface["radioNo"])
    end
    os.execute("echo "..inputTable["dot11WPS.interfaceName"].." > /tmp/wpsinterface")
    os.execute("echo "..inputTable["dot11WPS.interfaceName"].." > /tmp/wpsinterfaceName")
    os.execute("echo "..inputTable["dot11WPS.wpsEnabled"].." > /tmp/WPS_ENABLE")
    -- return
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DOT11_WPS_CONFIG_FAILED"
    end

end

--dot11 WPS_Pbc config

function dot11.WpsConfigPbc()

    local radioCommitString = ""

    local vapName = db.getAttribute("dot11WPS", "_ROWID_", 1, "vapName")
    local radioNo = db.getAttribute("dot11Interface","vapName",vapName,"radioNo")
    
    local dot11Interface = db.getRowWhere("dot11Interface", "vapName ='"..vapName.."'", false)
    local dot11Interfaces = db.getRowsWhere("dot11Interface", "radioNo ="..radioNo, false)
    if(dot11Interface == nil or dot11Interfaces == nil or #dot11Interfaces == nil)then
        return false
    end

    local vapInterface = dot11Interface["interfaceName"]
    local vapDbStringIndex = dot11Interface["radioNo"]
    local vapDbString ="_Entry"
    
    if(dot11Interface["_ROWID_"] == "1" or dot11Interface["_ROWID_"] == "4")then                
        if(tonumber(dot11Interface["radioNo"]) == 1)then
            vapDbStringIndex = dot11Interface["_ROWID_"]-1
            vapDbString ="_Entry"..vapDbStringIndex
        elseif(tonumber(dot11Interface["radioNo"]) == 2)then
            --TODO We assume same number of vap's are being created on both
            --radio's. Check when different number of vap's are being created 
            --on radio's
            radioCommitString = "11ac"
            vapDbStringIndex = dot11Interface["_ROWID_"]-#dot11Interfaces-1
            vapDbString ="11ac_Entry"..vapDbStringIndex
        end
    else
        if(tonumber(dot11Interface["radioNo"]) == 1)then
            vapDbStringIndex = dot11Interface["_ROWID_"]
            vapDbString ="_Entry"..vapDbStringIndex
        elseif(tonumber(dot11Interface["radioNo"]) == 2)then
            --TODO We assume same number of vap's are being created on both
            --radio's. Check when different number of vap's are being created 
            --on radio's
            radioCommitString = "11ac"
            vapDbStringIndex = dot11Interface["_ROWID_"]-#dot11Interfaces
            vapDbString ="11ac_Entry"..vapDbStringIndex
        end
    end
   
  -- tcapiInfoWLanCmdWrite(radioCommitString, "WPSActiveStatus", 1)
  -- tcapiSetCmdWrite(vapDbString, "WPSMode", 1)
  -- tcapiSetCmdWrite(vapDbString, "WPSConfMode", 7)
    iwprivSetCmdExecute(vapInterface, "WscConfMode", 4)
    iwprivSetCmdExecute(vapInterface, "WscMode", 2)
    iwprivSetCmdExecute(vapInterface, "WscConfStatus", 2)
    iwprivSetCmdExecute(vapInterface, "WscGetConf", 1)
    
  -- tcapiCommitCmdWrite(radioCommitString)
  -- tcapiSaveCmdWrite()
    return "OK","STATUS_OK"
end

--WPS PIN configuration

function dot11.WpsConfigPin(pinNumber)

    local radioCommitString = ""

    local vapName = db.getAttribute("dot11WPS", "_ROWID_", 1, "vapName")
    local radioNo = db.getAttribute("dot11Interface","vapName",vapName,"radioNo")
    
    local dot11Interface = db.getRowWhere("dot11Interface", "vapName ='"..vapName.."'", false)
    local dot11Interfaces = db.getRowsWhere("dot11Interface", "radioNo ="..radioNo, false)
    if(dot11Interface == nil or dot11Interfaces == nil or #dot11Interfaces == nil)then
        return false
    end

    local vapInterface = dot11Interface["interfaceName"]
    local vapDbStringIndex = dot11Interface["radioNo"]
    local vapDbString ="_Entry"
    
    if(tonumber(dot11Interface["radioNo"]) == 1)then
        vapDbStringIndex = dot11Interface["_ROWID_"]
        vapDbString ="_Entry"..vapDbStringIndex
    elseif(tonumber(dot11Interface["radioNo"]) == 2)then
        --TODO We assume same number of vap's are being created on both
        --radio's. Check when different number of vap's are being created 
        --on radio's
        radioCommitString = "11ac"
        vapDbStringIndex = dot11Interface["_ROWID_"]-#dot11Interfaces
        vapDbString ="11ac_Entry"..vapDbStringIndex
    end
   
    tcapiSetCmdWrite(vapDbString, "enrolleePinCode", pinNumber)
    tcapiInfoWLanCmdWrite(radioCommitString, "WPSActiveStatus", 1)
    tcapiSetCmdWrite(vapDbString, "WPSMode", 0)
    tcapiSetCmdWrite(vapDbString, "WPSConfMode", 7)
    
    tcapiCommitCmdWrite(radioCommitString)
    tcapiSaveCmdWrite()
    return "OK","STATUS_OK"

end    

function dot11.dscpToCosMappingFlashConfigCreate (inputTable)

	--print ("Creating ".. DSCP_PBIT_FLASH_FILE .. " from current settings")

	io.output(DSCP_PBIT_FLASH_FILE)
	io.write ("dscp1P = {}\n")
	io.write ("dscp1PMapSetFromAcs = {}\n")
	for k,v in pairs (inputTable) do
		if (k ~= "dscpToCosMapping._ROWID_") then
			io.write("dscp1P[\""..k.."\"] = \""..v.. "\"\n")
		end
	end
	if (inputTable["dscpToCosMapping.dscpMapSetFromTr"] == "1") then
		io.write("dscp1PMapSetFromAcs[\"mapSet\"] = \"1\"\n")
	else
		io.write("dscp1PMapSetFromAcs[\"mapSet\"] = \"0\"\n")
	end
	io.close ()

	--print ("printing file content as a string")
	--print (util.fileToString (DSCP_PBIT_FLASH_FILE))

end

function dot11.import (dot11Config, defaultConfig, removeConfig)
    --if dot11Config comes nil fill with default configuration
    if (dot11Config == nil) then
        dot11Config = defaultConfig
    end

    local BaseMac = util.fileToString(LAN_MAC_FILE)
    --RJIL need Mesh Enabled by default
    local configMergeDone = "0"
    
    if(util.fileExists("/flash/configMerge/singleBuild") == false) then
	      os.execute("touch /flash/MESH_ENABLED")	
          configMergeDone = "1"
    end

    if (configMergeDone == "1") then
        local sbEnabled = io.open("/flash/configMerge/singleBuild", "w")                                                          
        if(sbEnabled ~= nil) then                                                                       
            sbEnabled:close()                                                                           
        end
	-- touch saveDB flag to do a DB export to flash after import is complete
	    local saveDBFile  = io.open("/tmp/callDbSave", "w")                                                          
        if(saveDBFile ~= nil) then                                                                       
      	    saveDBFile:close()                                                                           
        end
    end

    local interfaceTmp = {}
    local vapTmp = {}
    local radioTmp = {}
    local cardTmp = {}
    local profileTmp = {}
    local aclTmp = {}
    local wpsTmp = {}
    local dot11ScheduleTmp = {}
    local globalTmp = {}
    local authorizedTmp = {}
    local dscpMappingTmp = {}
    local cosMappingTmp = {}
    local pmfTmp = {}
    local interfaceToBridgeTmp = {}
    --local apGroupNameTmp = {}
    local status
    local bootFlag = "1"

    for i,v in ipairs (dot11Config.profile) do
        if (v["pskPassAscii"] ~= nil and v["pskPassAscii"] ~= "") then
            status, v["pskPassAscii"] = passwdSecureLib.decryptData (v["pskPassAscii"], "")
        end
    end

    interfaceTmp = config.update (dot11Config.interface, defaultConfig.interface, removeConfig.interface)
    vapTmp = config.update (dot11Config.vap, defaultConfig.vap, removeConfig.vap)
    radioTmp = config.update (dot11Config.radio, defaultConfig.radio, removeConfig.radio)
    cardTmp = config.update (dot11Config.card, defaultConfig.card, removeConfig.card)
    profileTmp = config.update (dot11Config.profile, defaultConfig.profile, removeConfig.profile)
    aclTmp = config.update (dot11Config.acl, defaultConfig.acl, removeConfig.acl)
    wpsTmp = config.update (dot11Config.wps, defaultConfig.wps, removeConfig.wps)
    globalTmp = config.update (dot11Config.global, defaultConfig.global, removeConfig.global)
    guestTmp = config.update (dot11Config.guestZone, defaultConfig.guestZone, removeConfig.guestZone)
    authorizedTmp = config.update (dot11Config.authorizedAP, defaultConfig.authorizedAP, removeConfig.authorizedAP)
    dscpMappingTmp = config.update (dot11Config.dscpToQueueMapping, defaultConfig.dscpToQueueMapping, removeConfig.dscpToQueueMapping)
    cosMappingTmp = config.update (dot11Config.cosToQueueMapping, defaultConfig.cosToQueueMapping, removeConfig.cosToQueueMapping)
    pmfTmp = config.update (dot11Config.dot11pmf, defaultConfig.dot11pmf, removeConfig.dot11pmf)
    interfaceToBridgeTmp = config.update (dot11Config.dot11InterfaceToBridge, defaultConfig.dot11InterfaceToBridge, removeConfig.dot11InterfaceToBridge)
    --apGroupNameTmp = config.update (dot11Config.apGroupName, defaultConfig.apGroupName, removeConfig.apGroupName)
  
    local status = "ERROR"
    local message = ""
    local cmdStr
    local dot11If = {}
    local radio1vaps = 0
    local radio2vaps = 0
	if(not(util.fileExists("/pfrm2.0/DEVICE_REPEATER"))) then
	-- not using bdg2 in JMA24
    os.execute("/usr/bin/brctl addbr bdg2")
	end
    --create interfaces from ascii file
    if (interfaceTmp ~= nil and #interfaceTmp ~= 0) then
        for i,v in ipairs (interfaceTmp) do
            dot11If[i]=v
            if(tonumber(v["radioNo"]) == 1)then
                radio1vaps = radio1vaps+1
            end
            if(tonumber(v["radioNo"]) == 2)then
                radio2vaps = radio2vaps+1
            end
            v = util.addPrefix (v, "dot11Interface.")

	        if(not(util.fileExists("/pfrm2.0/DEVICE_REPEATER"))) then
                if (v["dot11Interface.vapName"] == "ap1") then
                    v["dot11Interface.interfaceName"] = "ra0"
                elseif (v["dot11Interface.vapName"] == "ap2") then
                    v["dot11Interface.interfaceName"] = "ra2"
                elseif (v["dot11Interface.vapName"] == "ap3") then
                    v["dot11Interface.interfaceName"] = "ra3"
                elseif (v["dot11Interface.vapName"] == "ap4") then
                    v["dot11Interface.interfaceName"] = "rai0"
                elseif (v["dot11Interface.vapName"] == "ap5") then
                    v["dot11Interface.interfaceName"] = "rai2"
                elseif (v["dot11Interface.vapName"] == "ap6") then
                    v["dot11Interface.interfaceName"] = "rai3"
                end
            else
                if (tonumber(v["dot11Interface._ROWID_"]) == tonumber(1)) then
                    v["dot11Interface.interfaceName"] = "ra0"
                    v["dot11Interface.vapName"] = "ap1"
                    v["dot11Interface.radioNo"] = "1"
                elseif (tonumber(v["dot11Interface._ROWID_"]) == tonumber(2)) then
                    v["dot11Interface.interfaceName"] = "ra2"
                    v["dot11Interface.vapName"] = "ap2"
                    v["dot11Interface.radioNo"] = "1"
                elseif (tonumber(v["dot11Interface._ROWID_"]) == tonumber(3)) then
                    v["dot11Interface.interfaceName"] = "ra3"
                    v["dot11Interface.vapName"] = "ap3"
                    v["dot11Interface.radioNo"] = "1"
                elseif (tonumber(v["dot11Interface._ROWID_"]) == tonumber(4)) then
                    v["dot11Interface.interfaceName"] = "rai0"
                    v["dot11Interface.vapName"] = "ap4"
                    v["dot11Interface.radioNo"] = "2"
                elseif (tonumber(v["dot11Interface._ROWID_"]) == tonumber(5)) then
                    v["dot11Interface.interfaceName"] = "rai2"
                    v["dot11Interface.vapName"] = "ap5"
                    v["dot11Interface.radioNo"] = "2"
                elseif (tonumber(v["dot11Interface._ROWID_"]) == tonumber(6)) then
                    v["dot11Interface.interfaceName"] = "rai3"
                    v["dot11Interface.vapName"] = "ap6"
                    v["dot11Interface.radioNo"] = "2"
                end
            end
            status, message = dot11.Interface_config (v, "-1", "add")
            util.appendDebugOut ("dot11.Interface_config(" .. i .. ") returned " .. status .. "," .. message .. "\n")
        end
    end
        
    --global settings
    local globalConfig = util.addPrefix (globalTmp, "dot11GlobalConfig.");
    db.insert ("dot11GlobalConfig", globalConfig);
    
    --apply card settings
    if (cardTmp ~= nil and #cardTmp ~= 0) then
        for i,v in ipairs (cardTmp) do
            v = util.addPrefix (v, "dot11Card.")
            status ,message = dot11.Card_config (v, "-1", "add");
            util.appendDebugOut ("dot11.Card_config(" .. i .. ") returned " .. status .. "," .. message .. "\n")
        end
    end

    --apply radio settings
    if (radioTmp ~= nil and #radioTmp ~= 0) then
        for i,v in ipairs (radioTmp) do
            v = util.addPrefix (v, "dot11Radio.")
    	    if((v["dot11Radio.configuredChannel"] == "12") or (v["dot11Radio.configuredChannel"] == "13")) then
	            v["dot11Radio.configuredChannel"] = "0"
            end
            if ((tonumber(v["dot11Radio.txPower"]) ~= nil) and (tonumber(v["dot11Radio.radioNo"])== 1)) then
                if(util.fileExists("/flash/configMerge/TxPowerChange") == false) then
                    v["dot11Radio.txPower"] = 75
                    local tmpvar = io.open("/flash/configMerge/TxPowerChange", "w")
                    if(tmpvar ~= nil) then
                         tmpvar:close()
                     end
                 end
             end
            status, message = dot11.radio_config (v, "-1", "add");
            util.appendDebugOut ("dot11.radio_config(" .. i .. ") returned " .. status .. "," .. message .. "\n")
        end
    end

    --create profiles
    if (profileTmp ~= nil and #profileTmp ~= 0) then
		local wpaPsk = ""
		local ssidRandomString = ""
		local ssidRandomString2 = ""
		local ssidRandomString5HZ = ""
		if (util.fileExists("/flash/teamf1.cfg.ascii") == false) then
			wpaPsk = util.fileToString ("/tmp/randPasswordWifi")
			ssidRandomString = util.fileToString ("/tmp/ssidRandom")
			ssidRandomString2 = util.fileToString ("/tmp/ssidRandom2")
	                tcapiSetCmdExecute("_Common", "ACSCheckTime","1")
	                tcapiSetCmdExecute("11ac_Common", "ACSCheckTime","1")

            if(util.fileExists("/pfrm2.0/DEVICE_REPEATER")) then
		        wpaPsk = util.fileToString ("/tmp/randPassword")
                tcapiSetCmdExecute("_Entry0", "SSID",ssidRandomString)
                tcapiSetCmdExecute("_Entry0", "WPAPSK",wpaPsk)
                tcapiCommitCmdExecute("_Entry0")
	    		ssidRandomString5HZ = ssidRandomString2 .. "_5G" 
                tcapiSetCmdExecute("11ac_Entry0", "SSID",ssidRandomString5HZ)
                tcapiSetCmdExecute("11ac_Entry0", "WPAPSK",wpaPsk)
                tcapiCommitCmdExecute("11ac_Entry0")
                if(util.fileExists("/flash/configMerge/JMA24FirstUpgrade")) then
	        		ssidRandomString5HZ = ssidRandomString2 .. "-BH" 
                    tcapiSetCmdExecute("_Entry1", "SSID",ssidRandomString5HZ)
                    tcapiSetCmdExecute("_Entry1", "WPAPSK",wpaPsk)
                    tcapiCommitCmdExecute("_Entry1")
                    tcapiSetCmdExecute("11ac_Entry1", "SSID",ssidRandomString5HZ)
                    tcapiSetCmdExecute("11ac_Entry1", "WPAPSK",wpaPsk)
                    tcapiCommitCmdExecute("11ac_Entry1")
                    tcapiMeshUnSetCmdExecute("_apclibh_Entry0")
                    tcapiMeshUnSetCmdExecute("_apclibh_Entry1")
                end
                tcapiSaveCmdExecute()
                local configMergeDone = "0"

                if(util.fileExists("/flash/configMerge/JMA24FirstUpgrade") == false) then
                    configMergeDone = "1"
                end
                if (configMergeDone == "1") then
                    local sbEnabled = io.open("/flash/configMerge/JMA24FirstUpgrade", "w")
                    if(sbEnabled ~= nil) then
                        sbEnabled:close()
                    end
                    -- touch saveDB flag to do a DB export to flash after import is complete
                    local saveDBFile  = io.open("/tmp/callDbSave", "w")
                    if(saveDBFile ~= nil) then
                        saveDBFile:close()
                    end
                end
            end
		end


        for i,v in ipairs (profileTmp) do
            v = util.addPrefix (v, "dot11Profile.")
	        if(util.fileExists("/pfrm2.0/DEVICE_REPEATER")) then
               if(tonumber(v["dot11Profile._ROWID_"]) == tonumber(1)) then
                    v["dot11Profile.profileName"] = "Jio_1"
               elseif(tonumber(v["dot11Profile._ROWID_"]) == tonumber(2)) then
                    v["dot11Profile.profileName"] = "Jio_2"
               elseif(tonumber(v["dot11Profile._ROWID_"]) == tonumber(3)) then
                    v["dot11Profile.profileName"] = "Jio_3"
               elseif(tonumber(v["dot11Profile._ROWID_"]) == tonumber(4)) then
                    v["dot11Profile.profileName"] = "Jio_4"
               elseif(tonumber(v["dot11Profile._ROWID_"]) == tonumber(5)) then
                    v["dot11Profile.profileName"] = "Jio_5"
               elseif(tonumber(v["dot11Profile._ROWID_"]) == tonumber(6)) then
                    v["dot11Profile.profileName"] = "Jio_6"
               end
            end
			if (wpaPsk ~= "") then
				print ("Setting random WPA PSK")
				v["dot11Profile.pskPassAscii"] = wpaPsk
			end
			if (ssidRandomString ~= "") then
				-- set ssid as per ssid string from flash + JioFibre concatenated
				if (v["dot11Profile.profileName"] == "Jio_1" ) then v["dot11Profile.ssid"] = ssidRandomString end
                if (v["dot11Profile.profileName"] == "Jio_4" ) then v["dot11Profile.ssid"] = ssidRandomString2 .. "_5G" end
            end
            

            status, message = dot11.profile_config (v, "-1", "add"); 
            util.appendDebugOut ("dot11.profile_config(" .. i .. ") returned " .. status .. "," .. message .. "\n")
        end
    end

    --configure vaps
    if (vapTmp ~= nil and #vapTmp ~= 0) then
        for i,v in ipairs (vapTmp) do
            v = util.addPrefix (v, "dot11VAP.")
	        if(util.fileExists("/pfrm2.0/DEVICE_REPEATER")) then
                if(tonumber(v["dot11VAP._ROWID_"]) == tonumber(1)) then
                    v["dot11VAP.vapName"] = "ap1"
                    v["dot11VAP.profileName"] = "Jio_1"
                    v["dot11VAP.radioList"] = "1"
                    v["dot11VAP.radioNo"] = "1"
                elseif(tonumber(v["dot11VAP._ROWID_"]) == tonumber(2)) then 
                    v["dot11VAP.vapName"] = "ap2"
                    v["dot11VAP.profileName"] = "Jio_2"
                    v["dot11VAP.radioList"] = "1"
                    v["dot11VAP.radioNo"] = "1"
                elseif(tonumber(v["dot11VAP._ROWID_"]) == tonumber(3)) then 
                    v["dot11VAP.vapName"] = "ap3"
                    v["dot11VAP.profileName"] = "Jio_3"
                    v["dot11VAP.radioList"] = "1"
                    v["dot11VAP.radioNo"] = "1"
                elseif(tonumber(v["dot11VAP._ROWID_"]) == tonumber(4)) then 
                    v["dot11VAP.vapName"] = "ap4"
                    v["dot11VAP.profileName"] = "Jio_4"
                    v["dot11VAP.radioList"] = "2"
                    v["dot11VAP.radioNo"] = "2"
                elseif(tonumber(v["dot11VAP._ROWID_"]) == tonumber(5)) then 
                    v["dot11VAP.vapName"] = "ap5"
                    v["dot11VAP.profileName"] = "Jio_5"
                    v["dot11VAP.radioList"] = "2"
                    v["dot11VAP.radioNo"] = "2"
                elseif(tonumber(v["dot11VAP._ROWID_"]) == tonumber(6)) then 
                    v["dot11VAP.vapName"] = "ap6"
                    v["dot11VAP.profileName"] = "Jio_6"
                    v["dot11VAP.radioList"] = "2"
                    v["dot11VAP.radioNo"] = "2"
               end
            end
            status,message = dot11.VAP_config (v, "-1", "add");
            util.appendDebugOut ("dot11.VAP_config(" .. i .. ") returned " .. status .. "," .. message .. "\n")
        end
    end

    -- configure ACL
    if (aclTmp ~= nil and #aclTmp ~= 0) then
        for i,v in ipairs (aclTmp) do
            v = util.addPrefix (v, "dot11ACL.")
            status,message = dot11.ACL_config (v, "-1", "add");
            util.appendDebugOut ("dot11.ACL_config(" .. i .. ") returned " .. status .. "," .. message .. "\n")
        end
    end

    --[[configure switch dscp to queue mapping
    if (dscpMappingTmp ~= nil and #dscpMappingTmp ~= 0) then
        for i,v in ipairs (dscpMappingTmp) do
            v = util.addPrefix (v, "dscpToQueueMapping.")
            status,message = dot11.dscpToQueueMapping_config (v, "-1", "add");
            util.appendDebugOut ("dot11.dscpToQueueMapping_config(" .. i .. ") returned " .. status .. "," .. message .. "\n")
        end
    end

    --configure switch cos to queue mapping
    if (cosMappingTmp ~= nil and #cosMappingTmp ~= 0) then
        for i,v in ipairs (cosMappingTmp) do
            v = util.addPrefix (v, "cosToQueueMapping.")
            status,message = dot11.cosToQueueMapping_config (v, "-1", "add");
            util.appendDebugOut ("dot11.cosToQueueMapping_config(" .. i .. ") returned " .. status .. "," .. message .. "\n")
        end
    end

    -- configure apGroupName
    if (apGroupNameTmp ~= nil and #apGroupNameTmp ~= 0) then
        for i,v in ipairs (apGroupNameTmp) do
            v = util.addPrefix (v, "apGroupName.")
            config.recOp (dot11.apGroupName_config, v, "-1", "add");
        end
    end
    ]]--

    if (pmfTmp ~= nil and #pmfTmp ~= 0) then
        for i,v in ipairs (pmfTmp) do
            v = util.addPrefix (v, "dot11pmf.")
            status,message = dot11.pmf_config (v, "-1", "add");
            util.appendDebugOut ("dot11.pmf_config(" .. i .. ") returned " .. status .. "," .. message .. "\n")
        end
    end

    if (interfaceToBridgeTmp ~= nil and #interfaceToBridgeTmp ~= 0) then
        for i,v in ipairs (interfaceToBridgeTmp) do
            v = util.addPrefix (v, "dot11InterfaceToBridge.")
            if(v["dot11InterfaceToBridge._ROWID_"] == 1)then
                v["dot11InterfaceToBridge.interfaceName"] = "ra0"
            elseif(v["dot11InterfaceToBridge._ROWID_"] == 2)then
                v["dot11InterfaceToBridge.interfaceName"] = "ra2"
            elseif(v["dot11InterfaceToBridge._ROWID_"] == 3)then
                v["dot11InterfaceToBridge.interfaceName"] = "ra3"
            elseif(v["dot11InterfaceToBridge._ROWID_"] == 4)then
                v["dot11InterfaceToBridge.interfaceName"] = "rai0"
            elseif(v["dot11InterfaceToBridge._ROWID_"] == 5)then
                v["dot11InterfaceToBridge.interfaceName"] = "rai2"
            elseif(v["dot11InterfaceToBridge._ROWID_"] == 6)then
                v["dot11InterfaceToBridge.interfaceName"] = "rai3"
            end
            status,message = dot11.InterfaceToBridge_config (v, "-1", "add");
            util.appendDebugOut ("dot11.InterfaceToBridge_config(" .. i .. ") returned " .. status .. "," .. message .. "\n")
        end
    end


    -- configure WPS
    if (wpsTmp ~= nil and #wpsTmp ~= 0) then
        for i,v in ipairs (wpsTmp) do
            v = util.addPrefix (v, "dot11WPS.")
            if(v["dot11WPS.vapName"] == "ap1") then
                v["dot11WPS.interfaceName"] = "ra0"
            elseif(v["dot11WPS.vapName"] == "ap2") then
                v["dot11WPS.interfaceName"] = "ra2"
            elseif(v["dot11WPS.vapName"] == "ap3") then
                v["dot11WPS.interfaceName"] = "ra3"
            elseif(v["dot11WPS.vapName"] == "ap4") then
                v["dot11WPS.interfaceName"] = "rai0"
            elseif(v["dot11WPS.vapName"] == "ap5") then
                v["dot11WPS.interfaceName"] = "rai2"
            elseif(v["dot11WPS.vapName"] == "ap6") then
                v["dot11WPS.interfaceName"] = "rai3"
            end
            status,message = dot11.WPS_config (v, "-1", "add");
            util.appendDebugOut ("dot11.WPS_config(" .. i .. ") returned " .. status .. "," .. message .. "\n")
        end
    end

	if(not(util.fileExists("/pfrm2.0/DEVICE_REPEATER")) or (util.fileExists("/flash/JMA24_CAP_MODE"))) then
	-- do not run any backend handler for JMA24

    local radioTable = db.getTable("dot11Radio",true)
    if(radioTable ~= nil)then
        --radio settings apply
        for k,v in pairs(radioTable)do
            local rate = 0
            local inputTable = v
            local radioDbString = "_Common"
            local radioCommitString = ""
            local dot11Radios = db.getRowsWhere ("dot11Radio", "radioNo = " .. inputTable["dot11Radio.radioNo"], false) 
            local dot11Interfaces = db.getRowsWhere ("dot11Interface", "radioNo = " .. inputTable["dot11Radio.radioNo"], false) 
            -- no interface corresponding to the radio
            if (dot11Interfaces == nil or dot11Interfaces[1] == nil) then
                return false
            end
            local radioInterface = dot11Radios[1]["interfaceName"]

            --create multiple vap's here
            if(tonumber(inputTable["dot11Radio.radioNo"]) == 2)then
                radioDbString = "11ac_Common"
                radioCommitString = "11ac"
                if(tonumber(radio2vaps)>1)then
                    tcapiSetCmdExecute(radioDbString, "MultiSSIDConfigEnable", "Yes")
                end
                tcapiSetCmdExecute(radioDbString, "APOn", 1)
                tcapiSetCmdExecute(radioDbString, "BssidNum", radio2vaps+1)
                --Tx Power(in % for econet 100%=1, 75%=2, 50%=3, 25%=4, 15%=5)
                tcapiSetCmdExecute(radioDbString, "TxPower", inputTable["dot11Radio.txPower"])
            elseif(tonumber(inputTable["dot11Radio.radioNo"])== 1)then
                if(tonumber(radio1vaps)>1)then
                    tcapiSetCmdExecute(radioDbString, "MultiSSIDConfigEnable", "Yes")
                end
                tcapiSetCmdExecute(radioDbString, "APOn", 1)
                tcapiSetCmdExecute(radioDbString, "BssidNum", radio1vaps+1)
        
                --Tx Power(in % for econet 100%=1, 75%=2, 50%=3, 25%=4, 15%=5)
                if(tonumber(inputTable["dot11Radio.txPower"]) == 100)then
                    tcapiSetCmdExecute(radioDbString, "TxPowerLevel", 1)
                elseif(tonumber(inputTable["dot11Radio.txPower"]) == 75)then
                    tcapiSetCmdExecute(radioDbString, "TxPowerLevel", 2)
                elseif(tonumber(inputTable["dot11Radio.txPower"]) == 50)then
                    tcapiSetCmdExecute(radioDbString, "TxPowerLevel", 3)
                elseif(tonumber(inputTable["dot11Radio.txPower"]) == 25)then
                    tcapiSetCmdExecute(radioDbString, "TxPowerLevel", 4)
                elseif(tonumber(inputTable["dot11Radio.txPower"]) == 15)then
                    tcapiSetCmdExecute(radioDbString, "TxPowerLevel", 5)
                end
            end

            --os.execute(cmdStr)
            -- TODO: rate
            --Auto Rate
            if (inputTable["dot11Radio.txRate"] == "0") then
                tcapiSetCmdExecute(radioDbString, "HT_MCS", 33)
            end
            
            --[[
            --Tx Preamble (2=auto, 1=short, 0=long)
            if(inputTable["dot11Radio.preambleMode"] == "Long")then
                tcapiSetCmdExecute(radioDbString, "TxPreamble", 0)
            elseif(inputTable["dot11Radio.preambleMode"] == "Short")then
                tcapiSetCmdExecute(radioDbString, "TxPreamble", 1)
            else
                tcapiSetCmdExecute(radioDbString, "TxPreamble", 2)
            end
            ]]--


            --RTS Threshold
            tcapiSetCmdExecute(radioDbString, "RTSThreshold", inputTable["dot11Radio.rtsThreshold"])

            --Frag Threshold
            tcapiSetCmdExecute(radioDbString, "FragThreshold", inputTable["dot11Radio.fragThreshold"])

            --Beacon Interval
            tcapiSetCmdExecute(radioDbString, "BeaconPeriod", inputTable["dot11Radio.beaconInterval"])

            --Dtim Interval
            tcapiSetCmdExecute(radioDbString, "DtimPeriod", inputTable["dot11Radio.dtimInterval"])

            --802.11bg protection mode(Auto=0, On=1, Off=2)
            tcapiSetCmdExecute(radioDbString, "BGProtection", inputTable["dot11Radio.rtsCtsProtect"])

            --set wireless Mode(0=11bg, 1=11b, 2=11a, 3=11abg, 4=11g, 5=11abgn, 6=11n[2.4G], 7=11gn, 8=11an, 9=11bgn, 10=11agn, 11=11n[5G], 12=b/g/gn/a/an/ac, 13=g/gn/a/an/ac, 14=11a/an/ac, 15=n/ac)
            --Basic Rate(11bg,11bgn,11n=15, 11b=3, 11g,11gn=351)
            if (inputTable["dot11Radio.opMode"] == "802.11b/g") then
                tcapiSetCmdExecute(radioDbString, "WirelessMode", 0)
                --tcapiSetCmdExecute(radioDbString, "HT_OpMode", 0)
                tcapiSetCmdExecute(radioDbString, "BasicRate", 15) -- 1, 2, 5.5, 11
            elseif (inputTable["dot11Radio.opMode"] == "802.11b") then
                tcapiSetCmdExecute(radioDbString, "WirelessMode", 1)
                tcapiSetCmdExecute(radioDbString, "HT_OpMode", 0)
                if (inputTable["dot11Radio.txRate"] ~= "0") then
                    tcapiSetCmdExecute(radioDbString, "HT_MCS", inputTable["dot11Radio.txRate"]) --HT_MCS = 0 = 1Mbps, HT_MCS = 1 = 2Mbps, HT_MCS = 2 = 5.5Mbps, HT_MCS = 3 = 11Mbps
                end
                --tcapiSetCmdExecute(radioDbString, "FixedTxMode", 1) CCK=1
                tcapiSetCmdExecute(radioDbString, "BasicRate", 3) -- 1, 2
            elseif (inputTable["dot11Radio.opMode"] == "802.11g") then
                tcapiSetCmdExecute(radioDbString, "WirelessMode", 4)
                tcapiSetCmdExecute(radioDbString, "HT_OpMode", 1)
                if (inputTable["dot11Radio.txRate"] ~= "0") then
                    tcapiSetCmdExecute(radioDbString, "HT_MCS", inputTable["dot11Radio.txRate"]) --HT_MCS = 0 = 6Mbps, HT_MCS = 1 = 9Mbps, HT_MCS = 2 = 12Mbps, HT_MCS = 3 = 18Mbps, HT_MCS = 4 = 24Mbps, HT_MCS = 5 = 36Mbps, HT_MCS = 6 = 48Mbps, HT_MCS = 7 = 54Mbps
                end
                --tcapiSetCmdExecute(radioDbString, "FixedTxMode", 2) OFDM=2
                tcapiSetCmdExecute(radioDbString, "BasicRate", 351) -- 1, 2, 5.5, 11, 6, 12, 24
            elseif (inputTable["dot11Radio.opMode"] == "802.11g/n") then
                tcapiSetCmdExecute(radioDbString, "WirelessMode", 7)
                tcapiSetCmdExecute(radioDbString, "HT_OpMode", 0)
                tcapiSetCmdExecute(radioDbString, "BasicRate", 351)
            elseif (inputTable["dot11Radio.opMode"] == "802.11n") then
                --tcapiSetCmdExecute(radioDbString, "FixedTxMode", 0) HT=0
                if(inputTable["dot11Radio.band"] == "a")then
                    tcapiSetCmdExecute(radioDbString, "WirelessMode", 11)
                    tcapiSetCmdExecute(radioDbString, "BasicRate", 336)
                else
                    tcapiSetCmdExecute(radioDbString, "WirelessMode", 6)
                    tcapiSetCmdExecute(radioDbString, "HT_OpMode", 1)
                    tcapiSetCmdExecute(radioDbString, "BasicRate", 15)
                end
            elseif (inputTable["dot11Radio.opMode"] == "802.11b/g/n") then
                --tcapiSetCmdExecute(radioDbString, "FixedTxMode", 0) HT=0
                tcapiSetCmdExecute(radioDbString, "WirelessMode", 9)
                tcapiSetCmdExecute(radioDbString, "HT_OpMode", 0)
                tcapiSetCmdExecute(radioDbString, "BasicRate", 15)
            elseif (inputTable["dot11Radio.opMode"] == "802.11a") then
                --tcapiSetCmdExecute(radioDbString, "FixedTxMode", 2) OFDM=2
                tcapiSetCmdExecute(radioDbString, "WirelessMode", 2)
                tcapiSetCmdExecute(radioDbString, "BasicRate", 336)
            elseif (inputTable["dot11Radio.opMode"] == "802.11a/n") then
                tcapiSetCmdExecute(radioDbString, "WirelessMode", 8)
                tcapiSetCmdExecute(radioDbString, "BasicRate", 336) -- 6, 12, 24
            elseif (inputTable["dot11Radio.opMode"] == "802.11a/n/ac") then
                tcapiSetCmdExecute(radioDbString, "WirelessMode", 14)
                tcapiSetCmdExecute(radioDbString, "BasicRate", 15)
            elseif (inputTable["dot11Radio.opMode"] == "802.11n/ac") then
                tcapiSetCmdExecute(radioDbString, "WirelessMode", 15)
                tcapiSetCmdExecute(radioDbString, "BasicRate", 15)
            end
            
            --set country 
            --Econet is having different variable to set country for 2.4GHz(CountryRegion) and 5GHz(CountryRegionABand)
            --INDIA=>Code=356,ISOName=IN,CountryRegionABand=0,CountryRegion=1 
            --UNITED ARAB EMIRATES=>Code=784,ISOName=AE,CountryRegionABand=0,CountryRegion=1 
            --UNITED STATES=>Code=840,ISOName=US,CountryRegionABand=0,CountryRegion=0 
            --TAIWAN=>Code=158,ISOName=TW,CountryRegionABand=3,CountryRegion=0 
            local country = db.getAttribute ("dot11GlobalConfig", "_ROWID_", "1", "country")
            --local countrycode = db.getAttribute ("dot11GlobalConfig", "_ROWID_", "1", "countrycode")
            if (inputTable["dot11Radio.band"] == "a")then
                if(country=="IN" or country=="AE" or country=="US") then
                    tcapiSetCmdExecute(radioDbString, "CountryRegionABand", 10)
                elseif(country=="TW")then
                    tcapiSetCmdExecute(radioDbString, "CountryRegionABand", 3)
                end
                --tcapiSetCmdExecute(radioDbString, "Country", country)
                --tcapiSetCmdExecute(radioDbString, "CountryCode", countrycode)
            elseif(inputTable["dot11Radio.band"] == "b")then
                if(tonumber(inputTable["dot11Radio.radioCountryRev"]) == 987 and country=="IN" or country=="AE")then
                    tcapiSetCmdExecute(radioDbString, "CountryRegion", 0)
                elseif(tonumber(inputTable["dot11Radio.radioCountryRev"]) == 991 or country=="US" or country=="TW")then
                    tcapiSetCmdExecute(radioDbString, "CountryRegion", 0)
                end
                --tcapiSetCmdExecute(radioDbString, "Country", country)
                --tcapiSetCmdExecute(radioDbString, "CountryCode", countrycode)
            end
            if(country == "IN") then
                tcapiSetCmdExecute(radioDbString, "Country", "INDIA")
            else
                tcapiSetCmdExecute(radioDbString, "Country", "INDIA")
            end  

            --channel/bandwidth settings
	    if(util.fileExists("/tmp/JioSmartcable"))then
	    	if (tonumber(inputTable["dot11Radio.configuredChannel"]) == tonumber(9) or tonumber(inputTable["dot11Radio.configuredChannel"]) == tonumber(10) or tonumber(inputTable["dot11Radio.configuredChannel"]) == tonumber(11)) then
			inputTable["dot11Radio.configuredChannel"] = 0
  	    	end
	    end
            if(inputTable["dot11Radio.configuredChannel"]~= nil and tonumber(inputTable["dot11Radio.configuredChannel"]) ~= tonumber(0))then
                if(util.fileExists("/flash/MESH_ENABLED")) then
                    tcapiSetChannelCmdExecute("user_preferred_channel",inputTable["dot11Radio.configuredChannel"])
                end    
                tcapiSetCmdExecute(radioDbString, "Channel", inputTable["dot11Radio.configuredChannel"])
                tcapiSetCmdExecute(radioDbString, "AutoChannelSelect", 0)
                if (inputTable["dot11Radio.chanWidth"] == "20") then
	    	    if(util.fileExists("/tmp/JioSmartcable")) then
                    	tcapiSetCmdExecute(radioDbString, "AutoChannelSkipList","0;9;10;11")
		    else
                    	tcapiSetCmdExecute(radioDbString, "AutoChannelSkipList","0")
                    end
		    tcapiSetCmdExecute(radioDbString, "HT_BW", 0)
                    tcapiSetCmdExecute(radioDbString, "VHT_BW", 0)
                elseif (inputTable["dot11Radio.chanWidth"] == "40" or inputTable["dot11Radio.chanWidth"] == "2040") then
	    	    if(util.fileExists("/tmp/JioSmartcable")) then
                    	tcapiSetCmdExecute(radioDbString, "AutoChannelSkipList","0;9;10;11")
		    else
                    	tcapiSetCmdExecute(radioDbString, "AutoChannelSkipList","0")
		    end
                    tcapiSetCmdExecute(radioDbString, "HT_BW", 1)
                    tcapiSetCmdExecute(radioDbString, "VHT_BW", 0)
                    if (tonumber(inputTable["dot11Radio.sideBand"]) == 0) then
                        tcapiSetCmdExecute(radioDbString, "HT_EXTCHA", 0) -- 0=Below
                    else
                        tcapiSetCmdExecute(radioDbString, "HT_EXTCHA", 1) -- 1=Above
                    end
                    if (tonumber(inputTable["dot11Radio.chanWidth"]) == "40") then
                        tcapiSetCmdExecute(radioDbString, "HT_BSSCoexistence", 0) -- 0=Disable, 1=Enable
                    else
                        tcapiSetCmdExecute(radioDbString, "HT_BSSCoexistence", 1) -- 0=Disable, 1=Enable
                    end
                elseif (inputTable["dot11Radio.chanWidth"] == "80" or inputTable["dot11Radio.chanWidth"] == "4080") then
	    	    if(util.fileExists("/tmp/JioSmartcable")) then
                    	tcapiSetCmdExecute(radioDbString, "AutoChannelSkipList","0;9;10;11")
		    else
                    	tcapiSetCmdExecute(radioDbString, "AutoChannelSkipList","0")
		    end
                    tcapiSetCmdExecute(radioDbString, "HT_BW", 1)
                    tcapiSetCmdExecute(radioDbString, "VHT_BW", 1) -- 0=Disable, 1=80M, 2=160M, 3=80+80M
                elseif (inputTable["dot11Radio.chanWidth"] == "160") then
	    	    if(util.fileExists("/tmp/JioSmartcable")) then
                        tcapiSetCmdExecute(radioDbString, "AutoChannelSkipList","0;9;10;11")
		    else
                        tcapiSetCmdExecute(radioDbString, "AutoChannelSkipList","0")
		    end
                    tcapiSetCmdExecute(radioDbString, "HT_BW", 1)
                    tcapiSetCmdExecute(radioDbString, "VHT_BW", 2) -- 0=Disable, 1=80M, 2=160M, 3=80+80M
                elseif (inputTable["dot11Radio.chanWidth"] == "8080") then
	    	    if(util.fileExists("/tmp/JioSmartcable")) then
                    	tcapiSetCmdExecute(radioDbString, "AutoChannelSkipList","0;9;10;11")
		    else
                    	tcapiSetCmdExecute(radioDbString, "AutoChannelSkipList","0")
		    end
                    tcapiSetCmdExecute(radioDbString, "HT_BW", 1)
                    tcapiSetCmdExecute(radioDbString, "VHT_BW", 3) -- 0=Disable, 1=80M, 2=160M, 3=80+80M
                end
            else
                tcapiSetCmdExecute(radioDbString, "Channel", 0)
                tcapiSetCmdExecute(radioDbString, "AutoChannelSelect", 2)
                if (inputTable["dot11Radio.chanWidth"] == "20") then
	    	    if(util.fileExists("/tmp/JioSmartcable")) then
		    	tcapiSetCmdExecute(radioDbString, "AutoChannelSkipList","0;9;10;11")
		    end
                    tcapiSetCmdExecute(radioDbString, "HT_BW", 0)
                    tcapiSetCmdExecute(radioDbString, "VHT_BW", 0)
                elseif (inputTable["dot11Radio.chanWidth"] == "40" or inputTable["dot11Radio.chanWidth"] == "2040") then
	    	    if(util.fileExists("/tmp/JioSmartcable")) then
		    	tcapiSetCmdExecute(radioDbString, "AutoChannelSkipList","0;9;10;11")
		    end
                    tcapiSetCmdExecute(radioDbString, "HT_BW", 1)
                    tcapiSetCmdExecute(radioDbString, "VHT_BW", 0)
                    if (tonumber(inputTable["dot11Radio.sideBand"]) == 0) then
                        if(tonumber(inputTable["dot11Radio.radioCountryRev"]) == 991)then
	    	    	    if(util.fileExists("/tmp/JioSmartcable")) then
                            	tcapiSetCmdExecute(radioDbString, "AutoChannelSkipList","9;10;11;12;13;40;48;153;161;165")
			    else
                            	tcapiSetCmdExecute(radioDbString, "AutoChannelSkipList","10;11;12;13;40;48;153;161;165")
			    end
                        else
                            tcapiSetCmdExecute(radioDbString, "AutoChannelSkipList","8;9;10;11;40;48;153;161;165")
                        end
                        tcapiSetCmdExecute(radioDbString, "HT_EXTCHA", 0) -- 0=Below
                    else
                        tcapiSetCmdExecute(radioDbString, "HT_EXTCHA", 1) -- 1=Above
                        tcapiSetCmdExecute(radioDbString, "AutoChannelSkipList","1;2;3;4;9;10;11;36;44;149;157;165")
                    end
                    if (tonumber(inputTable["dot11Radio.chanWidth"]) == "40") then
                        tcapiSetCmdExecute(radioDbString, "HT_BSSCoexistence", 0) -- 0=Disable, 1=Enable
                    else
                        tcapiSetCmdExecute(radioDbString, "HT_BSSCoexistence", 1) -- 0=Disable, 1=Enable
                    end
                elseif (inputTable["dot11Radio.chanWidth"] == "80" or inputTable["dot11Radio.chanWidth"] == "4080") then
	    	    if(util.fileExists("/tmp/JioSmartcable")) then
                    	tcapiSetCmdExecute(radioDbString, "AutoChannelSkipList","165;9;10;11")
		    else
                    	tcapiSetCmdExecute(radioDbString, "AutoChannelSkipList","165")
		    end
                    tcapiSetCmdExecute(radioDbString, "HT_BW", 1)
                    tcapiSetCmdExecute(radioDbString, "VHT_BW", 1) -- 0=Disable, 1=80M, 2=160M, 3=80+80M
                elseif (inputTable["dot11Radio.chanWidth"] == "160") then
	    	    if(util.fileExists("/tmp/JioSmartcable")) then
                    	tcapiSetCmdExecute(radioDbString, "AutoChannelSkipList","165;9;10;11")
		    else
                    	tcapiSetCmdExecute(radioDbString, "AutoChannelSkipList","165")
		    end
                    tcapiSetCmdExecute(radioDbString, "HT_BW", 1)
                    tcapiSetCmdExecute(radioDbString, "VHT_BW", 2) -- 0=Disable, 1=80M, 2=160M, 3=80+80M
                elseif (inputTable["dot11Radio.chanWidth"] == "8080") then
	    	    if(util.fileExists("/tmp/JioSmartcable")) then
                    	tcapiSetCmdExecute(radioDbString, "AutoChannelSkipList","165;9;10;11")
		    else
                    	tcapiSetCmdExecute(radioDbString, "AutoChannelSkipList","165")
		    end
                    tcapiSetCmdExecute(radioDbString, "HT_BW", 1)
                    tcapiSetCmdExecute(radioDbString, "VHT_BW", 3) -- 0=Disable, 1=80M, 2=160M, 3=80+80M
                end
            end

            

            --apply the VAP setting from here now
            for kk,vv in pairs(dot11Interfaces)do
                local dot11VAP = db.getRowWhere("dot11VAP", "vapName ='" ..vv["vapName"].."'" , false)
                local dot11ACL = db.getRowsWhere("dot11ACL", "vapName ='" ..vv["vapName"].."'" , false)
                local profileRow = db.getRow ("dot11Profile", "profileName", dot11VAP["profileName"])
                local pmfRow = db.getRow ("dot11pmf", "profileName", dot11VAP["profileName"])
                local vapInterface = vv["interfaceName"]

                local vapDbStringIndex = vv["radioNo"]
                local vapDbString ="_Entry"

                if((vv["_ROWID_"] == "1") or (vv["_ROWID_"] == "4") )then 
                    if(tonumber(vv["radioNo"])==1)then
                        vapDbStringIndex = vv["_ROWID_"]-1
                        vapDbString ="_Entry"..vapDbStringIndex
                    elseif(tonumber(vv["radioNo"])==2)then
                        vapDbStringIndex = vv["_ROWID_"]-radio1vaps-1
                        vapDbString ="11ac_Entry"..vapDbStringIndex
                    end
                else
                    if(tonumber(vv["radioNo"])==1)then
                        vapDbStringIndex = vv["_ROWID_"]
                        vapDbString ="_Entry"..vapDbStringIndex
                    elseif(tonumber(vv["radioNo"])==2)then
                        vapDbStringIndex = vv["_ROWID_"]-radio1vaps
                        vapDbString ="11ac_Entry"..vapDbStringIndex
                    end
                end
                --InterfaceName
                    tcapiSetCmdExecute(vapDbString, "VapInfc",vapInterface)
                --ap isolation
                if (dot11VAP["apIsolation"] == "1") then
                    tcapiSetCmdExecute(vapDbString, "NoForwarding", 1)
                else
                    tcapiSetCmdExecute(vapDbString, "NoForwarding", 0)
                end

                if (profileRow ~= nil) then

                    --set ssid
                    tcapiSetCmdExecute(vapDbString, "SSID", profileRow["dot11Profile.ssid"])

                    --broadcast ssid settings
                    if (profileRow["dot11Profile.broadcastSSID"] == "1") then
                        tcapiSetCmdExecute(vapDbString, "HideSSID", 0)
                    else
                        tcapiSetCmdExecute(vapDbString, "HideSSID", 1)
                    end
                        
                    tcapiSetCmdExecute(vapDbString, "WNMEnable", 1)
                    tcapiSetCmdExecute(vapDbString, "WPSConfMode", 4)

                    --set security
                    if (profileRow["dot11Profile.security"] == "OPEN") then
                        tcapiSetCmdExecute(vapDbString, "AuthMode", "OPEN")
                        tcapiSetCmdExecute(vapDbString, "EncrypType", "NONE")
                        tcapiSetCmdExecute(vapDbString, "IEEE8021X", "0")
                    elseif (profileRow["dot11Profile.authMethods"] == "PSK") then
                        if (profileRow["dot11Profile.security"] == "WPA+WPA2") then
                            tcapiSetCmdExecute(vapDbString, "AuthMode", "WPAPSKWPA2PSK")
                            tcapiSetCmdExecute(vapDbString, "IEEE8021X", "0")
                        elseif (profileRow["dot11Profile.security"] == "WPA") then
                            tcapiSetCmdExecute(vapDbString, "AuthMode", "WPAPSK")
                            tcapiSetCmdExecute(vapDbString, "IEEE8021X", "0")
                        elseif (profileRow["dot11Profile.security"] == "WPA2") then
                            tcapiSetCmdExecute(vapDbString, "AuthMode", "WPA2PSK")
                            tcapiSetCmdExecute(vapDbString, "IEEE8021X", "0")
                        end
                        if (profileRow["dot11Profile.pairwiseCiphers"] == "CCMP") then
                            tcapiSetCmdExecute(vapDbString, "EncrypType", "AES")
                        elseif (profileRow["dot11Profile.pairwiseCiphers"] == "TKIP") then
                            tcapiSetCmdExecute(vapDbString, "EncrypType", "TKIP")
                        elseif (profileRow["dot11Profile.pairwiseCiphers"] == "TKIP+CCMP") then
                            tcapiSetCmdExecute(vapDbString, "EncrypType", "TKIPAES")
                        end
                        if (profileRow["dot11Profile.pskPassAscii"] ~= nil) then
                            tcapiSetCmdExecute(vapDbString, "WPAPSK", profileRow["dot11Profile.pskPassAscii"])
                        end
                    elseif(profileRow["dot11Profile.authMethods"] == "RADIUS") then
                        if (profileRow["dot11Profile.security"] == "WPA+WPA2") then
                            tcapiSetCmdExecute(vapDbString, "AuthMode", "WPA1WPA2")
                            tcapiSetCmdExecute(vapDbString, "IEEE8021X", "1")
                        end			
                        if (profileRow["dot11Profile.security"] == "WPA") then
                            tcapiSetCmdExecute(vapDbString, "AuthMode", "WPA")
                            tcapiSetCmdExecute(vapDbString, "IEEE8021X", "1")
                        end			
                        if (profileRow["dot11Profile.security"] == "WPA2") then
                            tcapiSetCmdExecute(vapDbString, "AuthMode", "WPA2")
                            tcapiSetCmdExecute(vapDbString, "IEEE8021X", "1")
                        end
                    elseif (profileRow["dot11Profile.security"] == "WEP") then
                        if (profileRow["dot11Profile.wepAuth"]== "Shared") then
                            tcapiSetCmdExecute(vapDbString, "WEPAuthType", "SharedKey")
                        elseif(profileRow["dot11Profile.wepAuth"]== "Open")then
                            tcapiSetCmdExecute(vapDbString, "WEPAuthType", "OpenSystem")
                        elseif(profileRow["dot11Profile.wepAuth"]== "Open+Shared")then
                            tcapiSetCmdExecute(vapDbString, "WEPAuthType", "Both")
                        end
                        if(profileRow["dot11Profile.groupCipher"]== "64")then
                            tcapiSetCmdExecute(vapDbString, "AuthMode", "WEP-64Bits")
                        elseif(profileRow["dot11Profile.groupCipher"]== "128")then
                            tcapiSetCmdExecute(vapDbString, "AuthMode", "WEP-128Bits")
                        end
                        if (profileRow["dot11Profile.defWepKeyIdx"] ~= nil) then
                            tcapiSetCmdExecute(vapDbString, "DefaultKeyID", profileRow["dot11Profile.defWepKeyIdx"])
                        end
                        if (profileRow["dot11Profile.wepkey0"] ~= nil) then
                            tcapiSetCmdExecute(vapDbString, "Key1Str", profileRow["dot11Profile.wepkey0"])
                        end
                        if (profileRow["dot11Profile.wepkey1"] ~= nil) then
                            tcapiSetCmdExecute(vapDbString, "Key2Str", profileRow["dot11Profile.wepkey1"])
                        end
                        if (profileRow["dot11Profile.wepkey2"] ~= nil) then
                            tcapiSetCmdExecute(vapDbString, "Key3Str", profileRow["dot11Profile.wepkey2"])
                        end
                        if (profileRow["dot11Profile.wepkey3"] ~= nil) then
                            tcapiSetCmdExecute(vapDbString, "Key4Str", profileRow["dot11Profile.wepkey3"])
                        end
                    end
 
                end --profileRow nil check end

                --[[
                --pmf settings
                tcapiSetCmdExecute(vapDbString, "PMFMFPC", "pmfRow["dot11pmf.pmfEnable"]")
                tcapiSetCmdExecute(vapDbString, "PMFMFPR", "pmfRow["dot11pmf.pmfRequire"]")
                tcapiSetCmdExecute(vapDbString, "PMFSHA256", "pmfRow["dot11pmf.useSHA256"]")
                ]]--

                --acl policy set
                if(util.fileExists("/flash/MESH_ENABLED")) then
                    if(dot11VAP["defACLPolicy"] == "Allow")then
                        tcapiSetCmdExecute(vapDbString, "AccessPolicy", 1)
                    elseif(dot11VAP["defACLPolicy"] == "Deny")then
                        tcapiSetCmdExecute(vapDbString, "AccessPolicy", 2)
                    else
                        tcapiSetCmdExecute(vapDbString, "AccessPolicy", 0)
                    end
                else
                    if(dot11VAP["defACLPolicy"] == "Allow")then
                        tcapiSetCmdExecute(vapDbString, "AccessPolicy", 1)
                    elseif(dot11VAP["defACLPolicy"] == "Deny")then
                        tcapiSetCmdExecute(vapDbString, "AccessPolicy", 2)
                    else
                        tcapiSetCmdExecute(vapDbString, "AccessPolicy", 0)
                    end
                end

                --acl mac configuration
                if(dot11ACL ~= nil)then
                    for a,b in pairs(dot11ACL)do
                        local a = a-1
                        tcapiSetCmdExecute(vapDbString, "WLan_MAC"..a, b["macAddress"])
                    end
                end

                -- max clients
                tcapiSetCmdExecute(vapDbString, "MaxStaNum", dot11VAP["maxClients"])

            end --vap Setting for loop end
            --RadioSetVapStateBootUP will take care of these commands
            --[[
            tcapiSaveCmdExecute()
            tcapiCommitCmdExecute(radioCommitString)
            dot11.if_up(radioInterface, 0)
            dot11.if_up(radioInterface, 1)
            ]]--
            dot11.RadioSetVapStateBootUP(inputTable["dot11Radio.radioNo"])
        end --for loop for radioTable
    end

    -- get vap's mac in DB table
    local inputTable = {}
    for i,v in ipairs (dot11If) do
        inputTable["dot11Interface.macAddress"] = ifDevLib.getMac (v["interfaceName"])
        db.update ("dot11Interface", inputTable, i);
    end
	end --JMA24 File check End

end


function dot11.export ()

    local status
    local dot11Config =  {};
    local globalConfig = db.getTable("dot11GlobalConfig", false) 
    dot11Config["global"] = globalConfig[1]
    dot11Config["version"] = currentVersion
    dot11Config["card"] = db.getTable ("dot11Card", false)
    dot11Config["radio"] = db.getTable("dot11Radio", false) 
    dot11Config["vap"] = db.getTable("dot11VAP", false) 
    dot11Config["profile"] = db.getTable ("dot11Profile", false)
    dot11Config["acl"] = db.getTable ("dot11ACL", false) 
    dot11Config["wps"] = db.getTable ("dot11WPS", false)
    dot11Config["dot11Schedule"] = db.getTable ("dot11Schedule", false)
    dot11Config["interface"] = db.getTable ("dot11Interface", false)
    dot11Config["dscpToQueueMapping"] = db.getTable ("dscpToQueueMapping", false)
    dot11Config["cosToQueueMapping"] = db.getTable ("cosToQueueMapping", false)
    dot11Config["dot11pmf"] = db.getTable ("dot11pmf", false)
    dot11Config["dot11InterfaceToBridge"] = db.getTable ("dot11InterfaceToBridge", false)
    --dot11Config["apGroupName"] = db.getTable("apGroupName", false) 
    		
    for i, v in ipairs (dot11Config["profile"]) do
        if (v["pskPassAscii"] ~= nil and v["pskPassAscii"] ~= "") then
            status, dot11Config["profile"][i].pskPassAscii = passwdSecureLib.encryptData (v["pskPassAscii"], "")
        end
    end
    return dot11Config

end

require "teamf1lualib/config"
if (config.register) then

   config.register("dot11", dot11.import, dot11.export, "2")

end

-- radio settings apply
function dot11.radio_config_apply (inputTable)

    if (inputTable == nil or inputTable["dot11Radio.radioNo"] == nil) then
        return false
    end
    
    local BaseMac = util.fileToString(LAN_MAC_FILE)
    local radioDbString = "_Common"
    local radioCommitString = ""
    local dot11Radios = db.getRowsWhere ("dot11Radio", "radioNo = " .. inputTable["dot11Radio.radioNo"], false) 
    local dot11Interfaces = db.getRowsWhere ("dot11Interface", "radioNo = " .. inputTable["dot11Radio.radioNo"], false) 
    -- no interface corresponding to the radio
    if (dot11Interfaces == nil or dot11Interfaces[1] == nil) then
        return false
    end
    local radioInterface = dot11Radios[1]["interfaceName"]

    --create multiple vap's here
    if(tonumber(inputTable["dot11Radio.radioNo"]) == 2)then
        radioCommitString = "11ac"
        radioDbString = "11ac_Common"
        --Tx Power(in % for econet 100%=1, 75%=2, 50%=3, 25%=4, 15%=5)
        tcapiSetCmdWrite(radioDbString, "TxPower", inputTable["dot11Radio.txPower"])
    else
        --Tx Power(in % for econet 100%=1, 75%=2, 50%=3, 25%=4, 15%=5)
        if(tonumber(inputTable["dot11Radio.txPower"]) == 100)then
            tcapiSetCmdWrite(radioDbString, "TxPowerLevel", 1)
        elseif(tonumber(inputTable["dot11Radio.txPower"]) == 75)then
            tcapiSetCmdWrite(radioDbString, "TxPowerLevel", 2)
        elseif(tonumber(inputTable["dot11Radio.txPower"]) == 50)then
            tcapiSetCmdWrite(radioDbString, "TxPowerLevel", 3)
        elseif(tonumber(inputTable["dot11Radio.txPower"]) == 25)then
            tcapiSetCmdWrite(radioDbString, "TxPowerLevel", 4)
        elseif(tonumber(inputTable["dot11Radio.txPower"]) == 15)then
            tcapiSetCmdWrite(radioDbString, "TxPowerLevel", 5)
        end
    end
    -- TODO: rate
    --Auto Rate
    if (inputTable["dot11Radio.txRate"] == "0") then
        tcapiSetCmdWrite(radioDbString, "HT_MCS", 33)
    end

    --[[
    --Tx Preamble (2=auto, 1=short, 0=long)
    if(inputTable["dot11Radio.preambleMode"] == "Long")then
        tcapiSetCmdWrite(radioDbString, "TxPreamble", 0)
    elseif(inputTable["dot11Radio.preambleMode"] == "Short")then
        tcapiSetCmdWrite(radioDbString, "TxPreamble", 1)
    else
        tcapiSetCmdWrite(radioDbString, "TxPreamble", 2)
    end
    ]]--

    --RTS Threshold
    tcapiSetCmdWrite(radioDbString, "RTSThreshold", inputTable["dot11Radio.rtsThreshold"])

    --Frag Threshold
    tcapiSetCmdWrite(radioDbString, "FragThreshold", inputTable["dot11Radio.fragThreshold"])

    --Beacon Interval
    tcapiSetCmdWrite(radioDbString, "BeaconPeriod", inputTable["dot11Radio.beaconInterval"])
 
    --Dtim Interval
    tcapiSetCmdWrite(radioDbString, "DtimPeriod", inputTable["dot11Radio.dtimInterval"])

    --802.11bg protection mode(Auto=0, On=1, Off=2)
    tcapiSetCmdWrite(radioDbString, "BGProtection", inputTable["dot11Radio.rtsCtsProtect"])

            
    --set wireless Mode(0=11bg, 1=11b, 2=11a, 3=11abg, 4=11g, 5=11abgn, 6=11n[2.4G], 7=11gn, 8=11an, 9=11bgn, 10=11agn, 11=11n[5G], 12=b/g/gn/a/an/ac, 13=g/gn/a/an/ac, 14=11a/an/ac, 15=n/ac)
    --Basic Rate(11bg,11bgn,11n=15, 11b=3, 11g,11gn=351)
    if (inputTable["dot11Radio.opMode"] == "802.11b/g") then
        tcapiSetCmdWrite(radioDbString, "WirelessMode", 0)
      --tcapiSetCmdWrite(radioDbString, "HT_OpMode", 0)
        tcapiSetCmdWrite(radioDbString, "BasicRate", 15) -- 1, 2, 5.5, 11
    elseif (inputTable["dot11Radio.opMode"] == "802.11b") then
        tcapiSetCmdWrite(radioDbString, "WirelessMode", 1)
        tcapiSetCmdWrite(radioDbString, "HT_OpMode", 0)
        if (inputTable["dot11Radio.txRate"] ~= "0") then
            tcapiSetCmdWrite(radioDbString, "HT_MCS", inputTable["dot11Radio.txRate"]) --HT_MCS = 0 = 1Mbps, HT_MCS = 1 = 2Mbps, HT_MCS = 2 = 5.5Mbps, HT_MCS = 3 = 11Mbps
        end
      --tcapiSetCmdWrite(radioDbString, "FixedTxMode", 1) CCK=1
        tcapiSetCmdWrite(radioDbString, "BasicRate", 3) -- 1, 2
    elseif (inputTable["dot11Radio.opMode"] == "802.11g") then
        tcapiSetCmdWrite(radioDbString, "WirelessMode", 4)
        tcapiSetCmdWrite(radioDbString, "HT_OpMode", 1)
        if (inputTable["dot11Radio.txRate"] ~= "0") then
            tcapiSetCmdWrite(radioDbString, "HT_MCS", inputTable["dot11Radio.txRate"]) --HT_MCS = 0 = 6Mbps, HT_MCS = 1 = 9Mbps, HT_MCS = 2 = 12Mbps, HT_MCS = 3 = 18Mbps, HT_MCS = 4 = 24Mbps, HT_MCS = 5 = 36Mbps, HT_MCS = 6 = 48Mbps, HT_MCS = 7 = 54Mbps
        end
      --tcapiSetCmdWrite(radioDbString, "FixedTxMode", 2) OFDM=2
        tcapiSetCmdWrite(radioDbString, "BasicRate", 351) -- 1, 2, 5.5, 11, 6, 12, 24
    elseif (inputTable["dot11Radio.opMode"] == "802.11g/n") then
        tcapiSetCmdWrite(radioDbString, "WirelessMode", 7)
        tcapiSetCmdWrite(radioDbString, "HT_OpMode", 0)
        tcapiSetCmdWrite(radioDbString, "BasicRate", 351)
    elseif (inputTable["dot11Radio.opMode"] == "802.11n") then
      --tcapiSetCmdWrite(radioDbString, "FixedTxMode", 0) HT=0
        if(inputTable["dot11Radio.band"] == "a")then
            tcapiSetCmdWrite(radioDbString, "WirelessMode", 11)
            tcapiSetCmdWrite(radioDbString, "BasicRate", 336)
        else
            tcapiSetCmdWrite(radioDbString, "WirelessMode", 6)
            tcapiSetCmdWrite(radioDbString, "HT_OpMode", 1)
            tcapiSetCmdWrite(radioDbString, "BasicRate", 15)
        end
        if (inputTable["dot11Radio.txRate"] ~= "0") then
            tcapiSetCmdWrite(radioDbString, "HT_MCS", inputTable["dot11Radio.txRate"]) --HT_MCS = 0 = MCS0, HT_MCS = 1 = MCS1, HT_MCS = 2 = MCS2, HT_MCS = 3 = MCS3, HT_MCS = 4 = MCS4, HT_MCS = 5 = MCS5, HT_MCS = 6 = MCS6, HT_MCS = 7 = MCS7, HT_MCS = 8 = MCS8, HT_MCS = 9 = MCS9, HT_MCS = 10 = MCS10, HT_MCS = 11 = MCS11, HT_MCS = 12 = MCS12, HT_MCS = 13 = MCS13, HT_MCS = 14 = MCS14, HT_MCS = 15 = MCS15
        end
    elseif (inputTable["dot11Radio.opMode"] == "802.11b/g/n") then
      --tcapiSetCmdWrite(radioDbString, "FixedTxMode", 0) HT=0
        tcapiSetCmdWrite(radioDbString, "WirelessMode", 9)
        tcapiSetCmdWrite(radioDbString, "HT_OpMode", 0)
        tcapiSetCmdWrite(radioDbString, "BasicRate", 15)
    elseif (inputTable["dot11Radio.opMode"] == "802.11a") then
      --tcapiSetCmdWrite(radioDbString, "FixedTxMode", 2) OFDM=2
        tcapiSetCmdWrite(radioDbString, "WirelessMode", 2)
        tcapiSetCmdWrite(radioDbString, "BasicRate", 336)
        if (inputTable["dot11Radio.txRate"] ~= "0") then
            tcapiSetCmdWrite(radioDbString, "HT_MCS", inputTable["dot11Radio.txRate"]) --HT_MCS = 0 = 6Mbps, HT_MCS = 1 = 9Mbps, HT_MCS = 2 = 12Mbps, HT_MCS = 3 = 18Mbps, HT_MCS = 4 = 24Mbps, HT_MCS = 5 = 36Mbps, HT_MCS = 6 = 48Mbps, HT_MCS = 7 = 54Mbps
        end
    elseif (inputTable["dot11Radio.opMode"] == "802.11a/n") then
        tcapiSetCmdWrite(radioDbString, "WirelessMode", 8)
        tcapiSetCmdWrite(radioDbString, "BasicRate", 336) -- 6, 12, 24
        if (inputTable["dot11Radio.txRate"] ~= "0") then
            tcapiSetCmdWrite(radioDbString, "HT_MCS", inputTable["dot11Radio.txRate"]) --HT_MCS = 0 = 6Mbps, HT_MCS = 1 = 9Mbps, HT_MCS = 2 = 12Mbps, HT_MCS = 3 = 18Mbps, HT_MCS = 4 = 24Mbps, HT_MCS = 5 = 36Mbps, HT_MCS = 6 = 48Mbps, HT_MCS = 7 = 54Mbps
        end
    elseif (inputTable["dot11Radio.opMode"] == "802.11a/n/ac") then
        tcapiSetCmdWrite(radioDbString, "WirelessMode", 14)
        tcapiSetCmdWrite(radioDbString, "BasicRate", 15)
    elseif (inputTable["dot11Radio.opMode"] == "802.11n/ac") then
        tcapiSetCmdWrite(radioDbString, "WirelessMode", 15)
        tcapiSetCmdWrite(radioDbString, "BasicRate", 15)
    end

       if (inputTable["dot11Radio.band"] == "a")then
               tcapiSetCmdWrite(radioDbString, "CountryRegionABand", 10)
       elseif(inputTable["dot11Radio.band"] == "b")then
           if(tonumber(inputTable["dot11Radio.radioCountryRev"]) == 987 )then
               tcapiSetCmdWrite(radioDbString, "CountryRegion", 0)
           elseif(tonumber(inputTable["dot11Radio.radioCountryRev"]) == 991)then
               tcapiSetCmdWrite(radioDbString, "CountryRegion", 0)
           end
       end

    --channel/bandwidth settings
    if(inputTable["dot11Radio.configuredChannel"]~= nil and tonumber(inputTable["dot11Radio.configuredChannel"]) ~= tonumber(0))then
        tcapiSetCmdWrite(radioDbString, "Channel", inputTable["dot11Radio.configuredChannel"])
        tcapiSetCmdWrite(radioDbString, "AutoChannelSelect", 0)
        if (inputTable["dot11Radio.chanWidth"] == "20") then
	    if(util.fileExists("/tmp/JioSmartcable")) then
            	tcapiSetCmdWrite(radioDbString, "AutoChannelSkipList","0;9;10;11")
	    else
            	tcapiSetCmdWrite(radioDbString, "AutoChannelSkipList","0")
	    end
            tcapiSetCmdWrite(radioDbString, "HT_BW", 0)
            tcapiSetCmdWrite(radioDbString, "VHT_BW", 0)
        elseif (inputTable["dot11Radio.chanWidth"] == "40" or inputTable["dot11Radio.chanWidth"] == "2040") then
	    if(util.fileExists("/tmp/JioSmartcable")) then
            	tcapiSetCmdWrite(radioDbString, "AutoChannelSkipList","0;9;10;11")
	    else
            	tcapiSetCmdWrite(radioDbString, "AutoChannelSkipList","0")
	    end
            tcapiSetCmdWrite(radioDbString, "HT_BW", 1)
            tcapiSetCmdWrite(radioDbString, "VHT_BW", 0)
            if (tonumber(inputTable["dot11Radio.sideBand"]) == 0) then
                tcapiSetCmdWrite(radioDbString, "HT_EXTCHA", 0) -- 0=Below
            else
                tcapiSetCmdWrite(radioDbString, "HT_EXTCHA", 1) -- 1=Above
            end
            if (tonumber(inputTable["dot11Radio.chanWidth"]) == "40") then
                tcapiSetCmdWrite(radioDbString, "HT_BSSCoexistence", 0) -- 0=Disable, 1=Enable
            else
                tcapiSetCmdWrite(radioDbString, "HT_BSSCoexistence", 1) -- 0=Disable, 1=Enable
            end
        elseif (inputTable["dot11Radio.chanWidth"] == "80" or inputTable["dot11Radio.chanWidth"] == "4080") then
	    if(util.fileExists("/tmp/JioSmartcable")) then
            	tcapiSetCmdWrite(radioDbString, "AutoChannelSkipList","0;9;10;11")
	    else
            	tcapiSetCmdWrite(radioDbString, "AutoChannelSkipList","0")
	    end
            tcapiSetCmdWrite(radioDbString, "HT_BW", 1)
            tcapiSetCmdWrite(radioDbString, "VHT_BW", 1) -- 0=Disable, 1=80M, 2=160M, 3=80+80M
        elseif (inputTable["dot11Radio.chanWidth"] == "160") then
	    if(util.fileExists("/tmp/JioSmartcable")) then
            	tcapiSetCmdWrite(radioDbString, "AutoChannelSkipList","0;9;10;11")
	    else
            	tcapiSetCmdWrite(radioDbString, "AutoChannelSkipList","0")
	    end
            tcapiSetCmdWrite(radioDbString, "HT_BW", 1)
            tcapiSetCmdWrite(radioDbString, "VHT_BW", 2) -- 0=Disable, 1=80M, 2=160M, 3=80+80M
        elseif (inputTable["dot11Radio.chanWidth"] == "8080") then
	    if(util.fileExists("/tmp/JioSmartcable")) then
            	tcapiSetCmdWrite(radioDbString, "AutoChannelSkipList","0;9;10;11")
	    else
            	tcapiSetCmdWrite(radioDbString, "AutoChannelSkipList","0")
	    end
            tcapiSetCmdWrite(radioDbString, "HT_BW", 1)
            tcapiSetCmdWrite(radioDbString, "VHT_BW", 3) -- 0=Disable, 1=80M, 2=160M, 3=80+80M
        end
        if(util.fileExists("/flash/MESH_ENABLED")) then
            tcapiSetChannelCmdWrite("user_preferred_channel",inputTable["dot11Radio.configuredChannel"])
        end    
    else
        tcapiSetCmdWrite(radioDbString, "Channel", 0)
        tcapiSetCmdWrite(radioDbString, "AutoChannelSelect", 2)
        if (inputTable["dot11Radio.chanWidth"] == "20") then
            tcapiSetCmdWrite(radioDbString, "HT_BW", 0)
            tcapiSetCmdWrite(radioDbString, "VHT_BW", 0)
        elseif (inputTable["dot11Radio.chanWidth"] == "40" or inputTable["dot11Radio.chanWidth"] == "2040") then
            tcapiSetCmdWrite(radioDbString, "HT_BW", 1)
            tcapiSetCmdWrite(radioDbString, "VHT_BW", 0)
            if (tonumber(inputTable["dot11Radio.sideBand"]) == 0) then
                 if(tonumber(inputTable["dot11Radio.radioCountryRev"]) == 991)then
	    		if(util.fileExists("/tmp/JioSmartcable")) then
                     		tcapiSetCmdWrite(radioDbString, "AutoChannelSkipList","9;10;11;12;13;40;48;153;161;165")
			else
                     		tcapiSetCmdWrite(radioDbString, "AutoChannelSkipList","10;11;12;13;40;48;153;161;165")
			end
                 else
                     tcapiSetCmdWrite(radioDbString, "AutoChannelSkipList","8;9;10;11;40;48;153;161;165")
                 end
                tcapiSetCmdWrite(radioDbString, "HT_EXTCHA", 0) -- 0=Below
            else
                tcapiSetCmdWrite(radioDbString, "HT_EXTCHA", 1) -- 1=Above
                tcapiSetCmdWrite(radioDbString, "AutoChannelSkipList","1;2;3;4;36;44;149;157;165")
            end
            if (tonumber(inputTable["dot11Radio.chanWidth"]) == "40") then
                tcapiSetCmdWrite(radioDbString, "HT_BSSCoexistence", 0) -- 0=Disable, 1=Enable
            else
                tcapiSetCmdWrite(radioDbString, "HT_BSSCoexistence", 1) -- 0=Disable, 1=Enable
            end
        elseif (inputTable["dot11Radio.chanWidth"] == "80" or inputTable["dot11Radio.chanWidth"] == "4080") then
	    if(util.fileExists("/tmp/JioSmartcable")) then
            	tcapiSetCmdWrite(radioDbString, "AutoChannelSkipList","165;9;10;11")
	    else
            	tcapiSetCmdWrite(radioDbString, "AutoChannelSkipList","165")
	    end
            tcapiSetCmdWrite(radioDbString, "HT_BW", 1)
            tcapiSetCmdWrite(radioDbString, "VHT_BW", 1) -- 0=Disable, 1=80M, 2=160M, 3=80+80M
        elseif (inputTable["dot11Radio.chanWidth"] == "160") then
	    if(util.fileExists("/tmp/JioSmartcable")) then
            	tcapiSetCmdWrite(radioDbString, "AutoChannelSkipList","165;9;10;11")
	    else
            	tcapiSetCmdWrite(radioDbString, "AutoChannelSkipList","165")
	    end
            tcapiSetCmdWrite(radioDbString, "HT_BW", 1)
            tcapiSetCmdWrite(radioDbString, "VHT_BW", 2) -- 0=Disable, 1=80M, 2=160M, 3=80+80M
        elseif (inputTable["dot11Radio.chanWidth"] == "8080") then
	    if(util.fileExists("/tmp/JioSmartcable")) then
            	tcapiSetCmdWrite(radioDbString, "AutoChannelSkipList","165;9;10;11")
	    else
            	tcapiSetCmdWrite(radioDbString, "AutoChannelSkipList","165")
	    end
            tcapiSetCmdWrite(radioDbString, "HT_BW", 1)
            tcapiSetCmdWrite(radioDbString, "VHT_BW", 3) -- 0=Disable, 1=80M, 2=160M, 3=80+80M
        end
            
        if(util.fileExists("/flash/MESH_ENABLED")) then
            meshDbString = "_dat"
            tcapiMeshCommitCmdWrite(meshDbString) 
        end 
    end
    --TODO:Rate Settings
            
    --RadioSetVapState will take care of these commands
    --[[
    tcapiSaveCmdWrite()
    tcapiCommitCmdWrite(radioCommitString)
    dot11.if_up(radioInterface, 0)
    dot11.if_up(radioInterface, 1)
    ]]--
    dot11.RadioSetVapState(inputTable["dot11Radio.radioNo"])

    return true

end

-- profile settings apply
function dot11.profile_config_apply (inputTable)

    local profileRow = db.getRow ("dot11Profile", "profileName", inputTable["dot11Profile.profileName"])
    local dot11VAP = db.getRowWhere("dot11VAP", "profileName ='" ..inputTable["dot11Profile.profileName"].."'" , false)
    --local radioDbString = "_Common"
    --local radioCommitString = ""

    if (profileRow ~= nil and dot11VAP ~= nil) then
        local dot11Interfaces = db.getRowsWhere("dot11Interface", "radioNo ='" ..dot11VAP["radioNo"].."'" , false)
        local dot11Interface = db.getRowWhere("dot11Interface", "vapName ='" ..dot11VAP["vapName"].."'" , false)
        if(dot11Interface == nil or dot11Interfaces == nil or #dot11Interfaces == nil)then
            return false
        end
        --local radioInterface = db.getAttribute("dot11Radio","radioNo", dot11Interface["radioNo"],"interfaceName")
        local vapInterface = dot11Interface["interfaceName"]
        local vapDbStringIndex = dot11Interface["radioNo"]
        local vapDbString ="_Entry"
        local meshDbString =" "
        if(dot11Interface["_ROWID_"] == "1" or dot11Interface["_ROWID_"] == "4")then        
            if(tonumber(dot11Interface["radioNo"]) == 1)then
                vapDbStringIndex = dot11Interface["_ROWID_"]-1
                vapDbString ="_Entry"..vapDbStringIndex
                meshDbString = "_radio2gbssinfo_entry"..vapDbStringIndex
                --Set WebCurSet_Entry
                tcapiWebcurSetCmdWrite("wlan_id",vapDbStringIndex)
            elseif(tonumber(dot11Interface["radioNo"]) == 2)then
                --TODO We assume same number of vap's are being created on both
                --radio's. Check when different number of vap's are being created 
                --on radio's
                --radioDbString = "11ac_Common"
                --radioCommitString = "11ac"
                vapDbStringIndex = dot11Interface["_ROWID_"]-#dot11Interfaces-1
                vapDbString ="11ac_Entry"..vapDbStringIndex
                meshDbString = "_radio5glbssinfo_entry"..vapDbStringIndex
                --Set WebCurSet_Entry
                tcapiWebcurSetCmdWrite("wlan_ac_id",vapDbStringIndex)
            end
        else
            if(tonumber(dot11Interface["radioNo"]) == 1)then
            vapDbStringIndex = dot11Interface["_ROWID_"]
            vapDbString ="_Entry"..vapDbStringIndex
            meshDbString = "_radio2gbssinfo_entry"..vapDbStringIndex
            --Set WebCurSet_Entry
            tcapiWebcurSetCmdWrite("wlan_id",vapDbStringIndex)
            elseif(tonumber(dot11Interface["radioNo"]) == 2)then
            --TODO We assume same number of vap's are being created on both
            --radio's. Check when different number of vap's are being created 
            --on radio's
            --radioDbString = "11ac_Common"
            --radioCommitString = "11ac"
            vapDbStringIndex = dot11Interface["_ROWID_"]-#dot11Interfaces
            vapDbString ="11ac_Entry"..vapDbStringIndex
            meshDbString = "_radio5glbssinfo_entry"..vapDbStringIndex
            --Set WebCurSet_Entry
            tcapiWebcurSetCmdWrite("wlan_ac_id",vapDbStringIndex)
        end
      end
        --InterfaceName
            tcapiSetCmdWrite(vapDbString, "VapInfc",vapInterface)
        --set ssid
        tcapiSetCmdWrite(vapDbString, "SSID", profileRow["dot11Profile.ssid"])
        --broadcast ssid settings
        if (profileRow["dot11Profile.broadcastSSID"] == "1") then
            tcapiSetCmdWrite(vapDbString, "HideSSID", 0)
        else
           tcapiSetCmdWrite(vapDbString, "HideSSID", 1)
        end
        --set security
        if (profileRow["dot11Profile.security"] == "OPEN") then
            tcapiSetCmdWrite(vapDbString, "AuthMode", "OPEN")
            tcapiSetCmdWrite(vapDbString, "EncrypType", "NONE")
            tcapiSetCmdWrite(vapDbString, "IEEE8021X", "0")
        elseif (profileRow["dot11Profile.authMethods"] == "PSK") then
            if (profileRow["dot11Profile.security"] == "WPA+WPA2") then
                tcapiSetCmdWrite(vapDbString, "AuthMode", "WPAPSKWPA2PSK")
                tcapiSetCmdWrite(vapDbString, "IEEE8021X", "0")
            elseif (profileRow["dot11Profile.security"] == "WPA") then
                tcapiSetCmdWrite(vapDbString, "AuthMode", "WPAPSK")
                tcapiSetCmdWrite(vapDbString, "IEEE8021X", "0")
            elseif (profileRow["dot11Profile.security"] == "WPA2") then
                tcapiSetCmdWrite(vapDbString, "AuthMode", "WPA2PSK")
                tcapiSetCmdWrite(vapDbString, "IEEE8021X", "0")
            end
            if (profileRow["dot11Profile.pairwiseCiphers"] == "CCMP") then
                tcapiSetCmdWrite(vapDbString, "EncrypType", "AES")
            elseif (profileRow["dot11Profile.pairwiseCiphers"] == "TKIP") then
                tcapiSetCmdWrite(vapDbString, "EncrypType", "TKIP")
            elseif (profileRow["dot11Profile.pairwiseCiphers"] == "TKIP+CCMP") then
                tcapiSetCmdWrite(vapDbString, "EncrypType", "TKIPAES")
            end
            if (profileRow["dot11Profile.pskPassAscii"] ~= nil) then
                tcapiSetCmdWrite(vapDbString, "WPAPSK", profileRow["dot11Profile.pskPassAscii"])
            end
        elseif(profileRow["dot11Profile.authMethods"] == "RADIUS") then
            if (profileRow["dot11Profile.security"] == "WPA+WPA2") then
                tcapiSetCmdWrite(vapDbString, "AuthMode", "WPA1WPA2")
                tcapiSetCmdWrite(vapDbString, "IEEE8021X", "1")
            end			
            if (profileRow["dot11Profile.security"] == "WPA") then
                tcapiSetCmdWrite(vapDbString, "AuthMode", "WPA")
                tcapiSetCmdWrite(vapDbString, "IEEE8021X", "1")
            end			
            if (profileRow["dot11Profile.security"] == "WPA2") then
                tcapiSetCmdWrite(vapDbString, "AuthMode", "WPA2")
                tcapiSetCmdWrite(vapDbString, "IEEE8021X", "1")
            end    
        elseif (profileRow["dot11Profile.security"] == "WEP") then
            if (profileRow["dot11Profile.wepAuth"]== "Shared") then
                tcapiSetCmdWrite(vapDbString, "WEPAuthType", "SharedKey")
            elseif(profileRow["dot11Profile.wepAuth"]== "Open")then
                tcapiSetCmdWrite(vapDbString, "WEPAuthType", "OpenSystem")
            elseif(profileRow["dot11Profile.wepAuth"]== "Open+Shared")then
                tcapiSetCmdWrite(vapDbString, "WEPAuthType", "Both")
            end
            if(profileRow["dot11Profile.groupCipher"]== "64")then
            
                tcapiSetCmdWrite(vapDbString, "AuthMode", "WEP-64Bits")
                
            elseif(profileRow["dot11Profile.groupCipher"]== "128")then
                tcapiSetCmdWrite(vapDbString, "AuthMode", "WEP-128Bits")
            end
            if (profileRow["dot11Profile.defWepKeyIdx"] ~= nil) then
                tcapiSetCmdWrite(vapDbString, "DefaultKeyID", profileRow["dot11Profile.defWepKeyIdx"])
            end
            if (profileRow["dot11Profile.wepkey0"] ~= nil) then
                tcapiSetCmdWrite(vapDbString, "Key1Str", profileRow["dot11Profile.wepkey0"])
            end
            if (profileRow["dot11Profile.wepkey1"] ~= nil) then
                tcapiSetCmdWrite(vapDbString, "Key2Str", profileRow["dot11Profile.wepkey1"])
            end
            if (profileRow["dot11Profile.wepkey2"] ~= nil) then
                tcapiSetCmdWrite(vapDbString, "Key3Str", profileRow["dot11Profile.wepkey2"])
            end
            if (profileRow["dot11Profile.wepkey3"] ~= nil) then
                tcapiSetCmdWrite(vapDbString, "Key4Str", profileRow["dot11Profile.wepkey3"])
            end
        end
        dot11.SetVapState(vapDbString,meshDbString,dot11VAP)
    else
        return false
    end
    return true

end

-- vap settings apply
function dot11.vap_config_apply (inputTable)

    if(inputTable == nil)then
        return false
    end
 
    --local radioDbString = "_Common"
    --local radioCommitString = ""
    local dot11Interfaces = db.getRowsWhere("dot11Interface", "radioNo ='" ..inputTable["dot11VAP.radioNo"].."'" , false)
    local dot11Interface = db.getRowWhere("dot11Interface", "vapName ='" ..inputTable["dot11VAP.vapName"].."'" , false)
    local dot11VAP = db.getRowWhere("dot11VAP", "vapName ='" ..inputTable["dot11VAP.vapName"].."'" , false)
    if(dot11Interface == nil or dot11Interfaces == nil or #dot11Interfaces == nil)then
        return false
    end
    --local radioInterface = db.getAttribute("dot11Radio","radioNo", dot11Interface["radioNo"],"interfaceName")
    local vapInterface = dot11Interface["interfaceName"]
    local vapDbStringIndex = dot11Interface["radioNo"]
    local vapDbString ="_Entry"
    local meshDbString =" "
        
    if(dot11Interface["_ROWID_"] == "1" or dot11Interface["_ROWID_"] == "4")then        
        if(tonumber(dot11Interface["radioNo"]) == 1)then
            vapDbStringIndex = dot11Interface["_ROWID_"]-1
            vapDbString ="_Entry"..vapDbStringIndex
            meshDbString = "_radio2gbssinfo_entry"..vapDbStringIndex
            --Set WebCurSet_Entry
            tcapiWebcurSetCmdWrite("wlan_id",vapDbStringIndex)
        elseif(tonumber(dot11Interface["radioNo"]) == 2)then
            --TODO We assume same number of vap's are being created on both
            --radio's. Check when different number of vap's are being created 
            --on radio's
            --radioDbString = "11ac_Common"
            --radioCommitString = "11ac"
            vapDbStringIndex = dot11Interface["_ROWID_"]-#dot11Interfaces-1
            vapDbString ="11ac_Entry"..vapDbStringIndex
            meshDbString = "_radio5glbssinfo_entry"..vapDbStringIndex
            --Set WebCurSet_Entry
            tcapiWebcurSetCmdWrite("wlan_ac_id",vapDbStringIndex)
        end
    else
        if(tonumber(dot11Interface["radioNo"]) == 1)then
            vapDbStringIndex = dot11Interface["_ROWID_"]
            vapDbString ="_Entry"..vapDbStringIndex
            meshDbString = "_radio2gbssinfo_entry"..vapDbStringIndex
            --Set WebCurSet_Entry
            tcapiWebcurSetCmdWrite("wlan_id",vapDbStringIndex)
        elseif(tonumber(dot11Interface["radioNo"]) == 2)then
            --TODO We assume same number of vap's are being created on both
            --radio's. Check when different number of vap's are being created 
            --on radio's
            --radioDbString = "11ac_Common"
            --radioCommitString = "11ac"
            vapDbStringIndex = dot11Interface["_ROWID_"]-#dot11Interfaces
            vapDbString ="11ac_Entry"..vapDbStringIndex
            meshDbString = "_radio5glbssinfo_entry"..vapDbStringIndex
            --Set WebCurSet_Entry
            tcapiWebcurSetCmdWrite("wlan_ac_id",vapDbStringIndex)
        end
    end
                
    --ap isolation
    if (inputTable["dot11VAP.apIsolation"] == "1") then
        tcapiSetCmdWrite(vapDbString, "NoForwarding", 1)
    else
        tcapiSetCmdWrite(vapDbString, "NoForwarding", 0)
    end
    -- max clients
    tcapiSetCmdWrite(vapDbString, "MaxStaNum", inputTable["dot11VAP.maxClients"])
    
    if(util.fileExists("/flash/MESH_ENABLED") and (dot11Interface["_ROWID_"] == "1" or dot11Interface["_ROWID_"] == "4"))then
        tcapiCommitCmdWrite(vapDbString)
    end
    --dot11.RadioSetVapState(dot11Interface["radioNo"])
    dot11.SetVapState(vapDbString,meshDbString ,dot11VAP)
    return true

end


--When Mapd Restart need to re apply MAC Rules again
--

function dot11.vap_acl_config_reapply()
    
 
    local vapDbString ="_Entry0"
    local meshDbString = "_radio2gbssinfo_entry0"
            

    local dot11VAP = db.getRowWhere("dot11VAP", "vapName='ap1'" , false)
    --acl policy set
    if(dot11VAP["defACLPolicy"] == "Allow")then
        tcapiSetMeshMacCmdExecute(1)
        tcapiSetCmdExecute(vapDbString, "AccessPolicy", 1)
    elseif(dot11VAP["defACLPolicy"] == "Deny")then
        tcapiSetMeshMacCmdExecute(0)
        tcapiSetCmdExecute(vapDbString, "AccessPolicy", 2)
    else
        tcapiSetMeshMacCmdExecute(1)
        tcapiSetMeshMacCmdExecute(0)
        tcapiSetCmdWrite(vapDbString, "AccessPolicy", 0)
    end
    
    local ACLrows = db.getRowsWhere ("dot11ACL", "vapName='ap1'", false)
    local MacAddr = ifDevLib.getMac("ra0")
    local MacAddr1 = ifDevLib.getMac("rai0")
           
    if ACLrows[1] ~= nil then 
        --acl mac configuration
        for a,b in pairs(ACLrows)do
            local a = a-1
            tcapiSetCmdExecute(vapDbString, "WLan_MAC"..a, b["macAddress"])
            if(dot11VAP["defACLPolicy"] == "Allow")then
                tcapiSetWhiteMacCmdExecute(b["macAddress"] , MacAddr)
                tcapiSetWhiteMacCmdExecute(b["macAddress"] , MacAddr1)
            elseif(dot11VAP["defACLPolicy"] == "Deny")then
                tcapiSetBlockMacCmdExecute(b["macAddress"] , MacAddr)
                tcapiSetBlockMacCmdExecute(b["macAddress"] , MacAddr1)
            else
                tcapiSetWhiteMacCmdExecute(b["macAddress"] , MacAddr)
                tcapiSetUnBlockMacCmdExecute(b["macAddress"],MacAddr)
                tcapiSetWhiteMacCmdExecute(b["macAddress"] , MacAddr1)
                tcapiSetUnBlockMacCmdExecute(b["macAddress"],MacAddr1)
            end
        end
    end
 
end

-- vap acl policy settings apply
function dot11.vap_acl_config_apply (inputTable, policy)

    if(inputTable == nil)then
        return false
    end
 
    --local radioDbString = "_Common"
    --local radioCommitString = ""
    local dot11Interfaces = db.getRowsWhere("dot11Interface", "radioNo ='" ..inputTable["dot11VAP.radioNo"].."'" , false)
    local dot11Interface = db.getRowWhere("dot11Interface", "vapName ='" ..inputTable["dot11VAP.vapName"].."'" , false)
    local dot11VAP = db.getRowWhere("dot11VAP", "vapName ='" ..inputTable["dot11VAP.vapName"].."'" , false)
    if(dot11Interface == nil or dot11Interfaces == nil or #dot11Interfaces == nil)then
        return false
    end
    --local radioInterface = db.getAttribute("dot11Radio","radioNo", dot11Interface["radioNo"],"interfaceName")
    local vapInterface = dot11Interface["interfaceName"]
    local vapDbStringIndex = dot11Interface["radioNo"]
    local vapDbString ="_Entry"
    local meshDbString =" "

    if(dot11Interface["_ROWID_"] == "1" or dot11Interface["_ROWID_"] == "4")then        
        if(tonumber(dot11Interface["radioNo"]) == 1)then
            vapDbStringIndex = dot11Interface["_ROWID_"]-1
            vapDbString ="_Entry"..vapDbStringIndex
            meshDbString = "_radio2gbssinfo_entry"..vapDbStringIndex
            --Set WebCurSet_Entry
            tcapiWebcurSetCmdWrite("wlan_id",vapDbStringIndex)
        elseif(tonumber(dot11Interface["radioNo"]) == 2)then
            --TODO We assume same number of vap's are being created on both
            --radio's. Check when different number of vap's are being created 
            --on radio's
            --radioDbString = "11ac_Common"
            --radioCommitString = "11ac"
            vapDbStringIndex = dot11Interface["_ROWID_"]-#dot11Interfaces-1
            vapDbString ="11ac_Entry"..vapDbStringIndex
            meshDbString = "_radio5glbssinfo_entry"..vapDbStringIndex
            --Set WebCurSet_Entry
            tcapiWebcurSetCmdWrite("wlan_ac_id",vapDbStringIndex)
        end
    else
        if(tonumber(dot11Interface["radioNo"]) == 1)then
            vapDbStringIndex = dot11Interface["_ROWID_"]
            vapDbString ="_Entry"..vapDbStringIndex
            meshDbString = "_radio2gbssinfo_entry"..vapDbStringIndex
            --Set WebCurSet_Entry
            tcapiWebcurSetCmdWrite("wlan_id",vapDbStringIndex)
        elseif(tonumber(dot11Interface["radioNo"]) == 2)then
            --TODO We assume same number of vap's are being created on both
            --radio's. Check when different number of vap's are being created 
            --on radio's
            --radioDbString = "11ac_Common"
            --radioCommitString = "11ac"
            vapDbStringIndex = dot11Interface["_ROWID_"]-#dot11Interfaces
            vapDbString ="11ac_Entry"..vapDbStringIndex
            meshDbString = "_radio5glbssinfo_entry"..vapDbStringIndex
            --Set WebCurSet_Entry
            tcapiWebcurSetCmdWrite("wlan_ac_id",vapDbStringIndex)
        end
    end
                
    --acl policy set
    if((util.fileExists("/flash/MESH_ENABLED")) and (dot11Interface["_ROWID_"] == "1" or dot11Interface["_ROWID_"] == "4")) then
        if(inputTable["dot11VAP.defACLPolicy"] == "Allow")then
            tcapiSetMeshMacCmdWrite(1)
            tcapiSetCmdWrite(vapDbString, "AccessPolicy", 1)
        elseif(inputTable["dot11VAP.defACLPolicy"] == "Deny")then
            tcapiSetMeshMacCmdWrite(0)
            tcapiSetCmdWrite(vapDbString, "AccessPolicy", 2)
        else
            tcapiSetMeshMacCmdWrite(1)
            tcapiSetMeshMacCmdWrite(0)
            tcapiSetCmdWrite(vapDbString, "AccessPolicy", 0)
        end
    else
        if(inputTable["dot11VAP.defACLPolicy"] == "Allow")then
            tcapiSetCmdWrite(vapDbString, "AccessPolicy", 1)
        elseif(inputTable["dot11VAP.defACLPolicy"] == "Deny")then
            tcapiSetCmdWrite(vapDbString, "AccessPolicy", 2)
        else
            tcapiSetCmdWrite(vapDbString, "AccessPolicy", 0)
        end
    end

    if(util.fileExists("/flash/MESH_ENABLED")) then
        if((dot11Interface["_ROWID_"] == "1") or (dot11Interface["_ROWID_"] == "4")) then
            ACLrows = db.getRowsWhere ("dot11ACL", "vapName='".. inputTable["dot11VAP.vapName"] .."'", false)
            --[[if(inputTable["dot11VAP.defACLPolicy"] == "Allow") then
                tcapiSetMeshMacCmdWrite(0)
                tcapiSetMeshMacCmdWrite(1)
            else
                tcapiSetMeshMacCmdWrite(1)
                tcapiSetMeshMacCmdWrite(0)
            end]]--
            local MacAddr = ifDevLib.getMac("ra0")
            local MacAddr1 = ifDevLib.getMac("rai0")
            if ACLrows[1] ~= nil then 
                --acl mac configuration
                for a,b in pairs(ACLrows)do
                    local a = a-1
                    tcapiSetCmdWrite(vapDbString, "WLan_MAC"..a, b["macAddress"])
                    if(dot11VAP["defACLPolicy"] == "Allow")then
                        tcapiSetWhiteMacCmdWrite(b["macAddress"] , MacAddr)
                        tcapiSetWhiteMacCmdWrite(b["macAddress"] , MacAddr1)
                    elseif(dot11VAP["defACLPolicy"] == "Deny")then
                        tcapiSetBlockMacCmdWrite(b["macAddress"] , MacAddr)
                        tcapiSetBlockMacCmdWrite(b["macAddress"] , MacAddr1)
                    else
                        tcapiSetWhiteMacCmdWrite(b["macAddress"] , MacAddr)
                        tcapiSetUnBlockMacCmdWrite(b["macAddress"],MacAddr)                    
                        tcapiSetWhiteMacCmdWrite(b["macAddress"] , MacAddr1)
                        tcapiSetUnBlockMacCmdWrite(b["macAddress"],MacAddr1)                    
                    end
                end
            end
        else
            ACLrows = db.getRowsWhere ("dot11ACL", "vapName='".. inputTable["dot11VAP.vapName"] .."'", false)
            if ACLrows[1] ~= nil then 
                --acl mac configuration
                for a,b in pairs(ACLrows)do
                    local a = a-1
                    tcapiSetCmdWrite(vapDbString, "WLan_MAC"..a, b["macAddress"])
                end
            end
        end
    end
    --dot11.RadioSetVapState(dot11Interface["radioNo"])
    dot11.SetVapState(vapDbString,meshDbString,dot11VAP)
    return true
                
end

-- acl mac settings apply
function dot11.acl_mac_config_apply (inputTable, oldTableRowCount)

    -- locals
    if(inputTable == nil)then
        return false
    end
 
    --local radioDbString = "_Common"
    --local radioCommitString = ""
    local dot11Interfaces = db.getRowsWhere("dot11Interface", "radioNo ='" ..inputTable["dot11VAP.radioNo"].."'" , false)
    local dot11Interface = db.getRowWhere("dot11Interface", "vapName ='" ..inputTable["dot11VAP.vapName"].."'" , false)
    local dot11VAP = db.getRowWhere("dot11VAP", "vapName ='" ..inputTable["dot11VAP.vapName"].."'" , false)
    if(dot11Interface == nil or dot11Interfaces == nil or #dot11Interfaces == nil)then
        return false
    end
    --local radioInterface = db.getAttribute("dot11Radio","radioNo", dot11Interface["radioNo"],"interfaceName")
    local vapInterface = dot11Interface["interfaceName"]
    local vapDbStringIndex = dot11Interface["radioNo"]
    local vapDbString ="_Entry"
    local meshDbString =" "

    if(dot11Interface["_ROWID_"] == "1" or dot11Interface["_ROWID_"] == "4")then                
        if(tonumber(dot11Interface["radioNo"]) == 1)then
            vapDbStringIndex = dot11Interface["_ROWID_"]-1
            vapDbString ="_Entry"..vapDbStringIndex
            meshDbString = "_radio2gbssinfo_entry"..vapDbStringIndex
            --Set WebCurSet_Entry
            tcapiWebcurSetCmdWrite("wlan_id",vapDbStringIndex)
        elseif(tonumber(dot11Interface["radioNo"]) == 2)then
            --TODO We assume same number of vap's are being created on both
            --radio's. Check when different number of vap's are being created 
            --on radio's
            --radioDbString = "11ac_Common"
            --radioCommitString = "11ac"
            vapDbStringIndex = dot11Interface["_ROWID_"]-#dot11Interfaces-1
            vapDbString ="11ac_Entry"..vapDbStringIndex
            meshDbString = "_radio5glbssinfo_entry"..vapDbStringIndex
            --Set WebCurSet_Entry
            tcapiWebcurSetCmdWrite("wlan_ac_id",vapDbStringIndex)
        end
    else
        if(tonumber(dot11Interface["radioNo"]) == 1)then
            vapDbStringIndex = dot11Interface["_ROWID_"]
            vapDbString ="_Entry"..vapDbStringIndex
            meshDbString = "_radio2gbssinfo_entry"..vapDbStringIndex
            --Set WebCurSet_Entry
            tcapiWebcurSetCmdWrite("wlan_id",vapDbStringIndex)
        elseif(tonumber(dot11Interface["radioNo"]) == 2)then
            --TODO We assume same number of vap's are being created on both
            --radio's. Check when different number of vap's are being created 
            --on radio's
            --radioDbString = "11ac_Common"
            --radioCommitString = "11ac"
            vapDbStringIndex = dot11Interface["_ROWID_"]-#dot11Interfaces
            vapDbString ="11ac_Entry"..vapDbStringIndex
            meshDbString = "_radio5glbssinfo_entry"..vapDbStringIndex
            --Set WebCurSet_Entry
            tcapiWebcurSetCmdWrite("wlan_ac_id",vapDbStringIndex)
        end
    end
    if(tonumber(oldTableRowCount)>0)then
        for i = 0, oldTableRowCount-1 do
            tcapiSetCmdWrite(vapDbString, "WLan_MAC"..i, "00:00:00:00:00:00")
        end
    end
                

    if((util.fileExists("/flash/MESH_ENABLED")) and ((dot11Interface["_ROWID_"] == "1") or (dot11Interface["_ROWID_"] == "4"))) then
        ACLrows = db.getRowsWhere ("dot11ACL", "vapName='".. inputTable["dot11VAP.vapName"] .."'", false)
        if(inputTable["dot11VAP.defACLPolicy"] == "Allow") then
            tcapiSetMeshMacCmdWrite(0)
            tcapiSetMeshMacCmdWrite(1)
        else
            tcapiSetMeshMacCmdWrite(1)
            tcapiSetMeshMacCmdWrite(0)
        end

        local MacAddr = ifDevLib.getMac("ra0")
        local MacAddr1 = ifDevLib.getMac("rai0")
        if ACLrows[1] ~= nil then 
            --acl mac configuration
            for a,b in pairs(ACLrows)do
                local a = a-1
                tcapiSetCmdWrite(vapDbString, "WLan_MAC"..a, b["macAddress"])
                if(dot11VAP["defACLPolicy"] == "Allow")then
                    tcapiSetWhiteMacCmdWrite(b["macAddress"] , MacAddr)
                    tcapiSetWhiteMacCmdWrite(b["macAddress"] , MacAddr1)
                elseif(dot11VAP["defACLPolicy"] == "Deny")then
                    tcapiSetBlockMacCmdWrite(b["macAddress"] , MacAddr)
                    tcapiSetBlockMacCmdWrite(b["macAddress"] , MacAddr1)
                else
                    tcapiSetWhiteMacCmdWrite(b["macAddress"] , MacAddr)
                    tcapiSetUnBlockMacCmdWrite(b["macAddress"],MacAddr)                    
                    tcapiSetWhiteMacCmdWrite(b["macAddress"] , MacAddr1)
                    tcapiSetUnBlockMacCmdWrite(b["macAddress"],MacAddr1)                    
                end
            end
        end
    else
        ACLrows = db.getRowsWhere ("dot11ACL", "vapName='".. inputTable["dot11VAP.vapName"] .."'", false)
        if ACLrows[1] ~= nil then 
            --acl mac configuration
            for a,b in pairs(ACLrows)do
                local a = a-1
                tcapiSetCmdWrite(vapDbString, "WLan_MAC"..a, b["macAddress"])
            end
        end
    end

    --dot11.RadioSetVapState(dot11Interface["radioNo"])
    dot11.SetVapState(vapDbString,meshDbString,dot11VAP)
    return true 
end

-------------------------------------------------------------------------------
-- @name dot11.RadioSetVapStateBootUP
--
-- @description This function sets state of all vap's on given radio at boot up
--
-- @param query
--
-- @return true or false
--

function dot11.RadioSetVapStateBootUP(radioNo)

    if (radioNo == nil) then
        return false
    end
    
    local radioDbString = "_Common"
    local radioCommitString = ""
    local meshDbString =" "
    local dot11Radios = db.getRowsWhere ("dot11Radio", "radioNo = " .. radioNo, false) 
    local dot11Interfaces = db.getRowsWhere ("dot11Interface", "radioNo = " .. radioNo, false) 
    -- no interface corresponding to the radio
    if (dot11Interfaces == nil or dot11Interfaces[1] == nil) then
        return false
    end
    --local radioInterface = dot11Radios[1]["interfaceName"]

    --create multiple vap's here
    if(tonumber(radioNo) == 2)then
        radioDbString = "11ac_Common"
        radioCommitString = "11ac"
    end
    
    --apply the VAP setting from here now
    for kk,vv in pairs(dot11Interfaces)do
        local dot11VAP = db.getRowWhere("dot11VAP", "vapName ='" ..vv["vapName"].."'" , false)
        local vapInterface = vv["interfaceName"]
        local vapDbStringIndex = radioNo
        local vapDbString ="_Entry"
        if(vv["_ROWID_"] == "1" or vv["_ROWID_"] == "4")then
            if(tonumber(radioNo)==1)then
                vapDbStringIndex = vv["_ROWID_"]-1
                vapDbString ="_Entry"..vapDbStringIndex
                meshDbString = "_radio2gbssinfo_entry"..vapDbStringIndex
            elseif(tonumber(radioNo)==2)then
                --TODO We assume same number of vap's are being created on both
                --radio's. Check when different number of vap's are being created 
                --on radio's
                vapDbStringIndex = vv["_ROWID_"]-#dot11Interfaces-1
                vapDbString ="11ac_Entry"..vapDbStringIndex
                meshDbString = "_radio5glbssinfo_entry"..vapDbStringIndex
            end
        else
            if(tonumber(radioNo)==1)then
                vapDbStringIndex = vv["_ROWID_"]
                vapDbString ="_Entry"..vapDbStringIndex
                meshDbString = "_radio2gbssinfo_entry"..vapDbStringIndex
            elseif(tonumber(radioNo)==2)then
                --TODO We assume same number of vap's are being created on both
                --radio's. Check when different number of vap's are being created 
                --on radio's
                vapDbStringIndex = vv["_ROWID_"]-#dot11Interfaces
                vapDbString ="11ac_Entry"..vapDbStringIndex
                meshDbString = "_radio5glbssinfo_entry"..vapDbStringIndex
            end
        end
        if((util.fileExists("/flash/MESH_ENABLED")) and (vapInterface == "ra0" or vapInterface == "ra1" or vapInterface == "rai0" or vapInterface == "rai1"))then    
            if(dot11VAP["vapEnabled"] == "1")then
                tcapiSetCmdExecute(vapDbString, "EnableSSID", 1)
                --tcapiCommitCmdExecute(radioDbString)
                --tcapiSetCmdExecute(vapDbString, "HideSSID",0)
                tcapiMeshSetCmdExecute(meshDbString,"BackHaul",0)
                tcapiMeshSetCmdExecute(meshDbString,"FrontHaul",1)
                --tcapiMeshCommitCmdExecute(meshDbString)
            else
                tcapiSetCmdExecute(vapDbString, "EnableSSID", 1)
                --tcapiCommitCmdExecute(radioDbString)
                tcapiSetCmdExecute(vapDbString, "HideSSID", 1)
                tcapiMeshSetCmdExecute(meshDbString,"BackHaul",0)
                tcapiMeshSetCmdExecute(meshDbString,"FrontHaul",1)
                --tcapiMeshCommitCmdExecute(meshDbString)
            end
        else
            if(dot11VAP["vapEnabled"] == "1")then
                tcapiSetCmdExecute(vapDbString, "EnableSSID", 1)
                tcapiCommitCmdExecute(radioDbString)
            else
                tcapiSetCmdExecute(vapDbString, "EnableSSID", 0)
                tcapiCommitCmdExecute(radioDbString)
            end
        end
    end
             
    tcapiSaveCmdExecute()
    --apply the VAP setting from here now
    for kk,vv in pairs(dot11Interfaces)do
        local dot11VAP = db.getRowWhere("dot11VAP", "vapName ='" ..vv["vapName"].."'" , false)
        local vapInterface = vv["interfaceName"]
        if((util.fileExists("/flash/MESH_ENABLED")) and (vapInterface == "ra0" or vapInterface == "ra1" or vapInterface == "rai0" or vapInterface == "rai1"))then    
            if(dot11VAP["vapEnabled"] == "1")then
                dot11.if_up_bootup (vapInterface, 1)
            else
                dot11.if_up_bootup (vapInterface, 1)
            end
        else
            if(dot11VAP["vapEnabled"] == "1")then
                dot11.if_up_bootup (vapInterface, 1)
            else
                dot11.if_up_bootup (vapInterface, 0)
            end
        end
    end

end

-------------------------------------------------------------------------------
-- @name dot11.RadioSetVapState
--
-- @description This function sets state of all vap's on given radio
--
-- @param query
--
-- @return true or false
--

function dot11.RadioSetVapState(radioNo)

    if (radioNo == nil) then
        return false
    end
    
    local radioDbString = "_Common"
    local radioCommitString = ""
    local dot11Radios = db.getRowsWhere ("dot11Radio", "radioNo = " .. radioNo, false) 
    local dot11Interfaces = db.getRowsWhere ("dot11Interface", "radioNo = " .. radioNo, false) 
    -- no interface corresponding to the radio
    if (dot11Interfaces == nil or dot11Interfaces[1] == nil) then
        return false
    end
    local radioInterface = dot11Radios[1]["interfaceName"]

    --create multiple vap's here
    if(tonumber(radioNo) == 2)then
        radioDbString = "11ac_Common"
        radioCommitString = "11ac"
    end
    
    --apply the VAP setting from here now
    for kk,vv in pairs(dot11Interfaces)do
        local dot11VAP = db.getRowWhere("dot11VAP", "vapName ='" ..vv["vapName"].."'" , false)
        local vapInterface = vv["interfaceName"]
        local vapDbStringIndex = radioNo
        local vapDbString ="_Entry"
        local meshDbString =""
        if(vv["_ROWID_"] == "1" or vv["_ROWID_"] == "4")then
            if(tonumber(radioNo)==1)then
                vapDbStringIndex = vv["_ROWID_"]-1
                vapDbString ="_Entry"..vapDbStringIndex
                meshDbString = "_radio2gbssinfo_entry"..vapDbStringIndex
            elseif(tonumber(radioNo)==2)then
                --TODO We assume same number of vap's are being created on both
                --radio's. Check when different number of vap's are being created 
                --on radio's
                vapDbStringIndex = vv["_ROWID_"]-#dot11Interfaces-1
                vapDbString ="11ac_Entry"..vapDbStringIndex
                meshDbString = "_radio5glbssinfo_entry"..vapDbStringIndex
            end
        else
            if(tonumber(radioNo)==1)then
                vapDbStringIndex = vv["_ROWID_"]
                vapDbString ="_Entry"..vapDbStringIndex
                meshDbString = "_radio2gbssinfo_entry"..vapDbStringIndex
            elseif(tonumber(radioNo)==2)then
                --TODO We assume same number of vap's are being created on both
                --radio's. Check when different number of vap's are being created 
                --on radio's
                vapDbStringIndex = vv["_ROWID_"]-#dot11Interfaces
                vapDbString ="11ac_Entry"..vapDbStringIndex
                meshDbString = "_radio5glbssinfo_entry"..vapDbStringIndex
            end
        end
        if((util.fileExists("/flash/MESH_ENABLED")) and (vapInterface == "ra0" or vapInterface == "ra1" or vapInterface == "rai0" or vapInterface == "rai1"))then    
            if(dot11VAP["vapEnabled"] == "1")then
                tcapiSetCmdWrite(vapDbString, "EnableSSID", 1)
                --tcapiCommitCmdWrite(radioDbString)
                --tcapiSetCmdWrite(vapDbString, "HideSSID", 0)
                tcapiMeshSetCmdWrite(meshDbString,"BackHaul",0)
                tcapiMeshSetCmdWrite(meshDbString,"FrontHaul",1)
                tcapiMeshCommitCmdWrite(meshDbString) 
            else
                tcapiSetCmdWrite(vapDbString, "EnableSSID", 1)
                --tcapiCommitCmdWrite(radioDbString)
                tcapiSetCmdWrite(vapDbString, "HideSSID", 1)
                tcapiMeshSetCmdWrite(meshDbString,"BackHaul",0)
                tcapiMeshSetCmdWrite(meshDbString,"FrontHaul",1)
                tcapiMeshCommitCmdWrite(meshDbString) 
            end
        else
            if(dot11VAP["vapEnabled"] == "1")then
                tcapiSetCmdWrite(vapDbString, "EnableSSID", 1)
                --tcapiCommitCmdWrite(radioDbString)
            else
                tcapiSetCmdWrite(vapDbString, "EnableSSID", 0)
                --tcapiCommitCmdWrite(radioDbString)
            end
        end
    end
            
    tcapiCommitCmdWrite(radioCommitString)
    tcapiSaveCmdWrite()
    --apply the VAP setting from here now
    for kk,vv in pairs(dot11Interfaces)do
        local dot11VAP = db.getRowWhere("dot11VAP", "vapName ='" ..vv["vapName"].."'" , false)
        local vapInterface = vv["interfaceName"]
        if((util.fileExists("/flash/MESH_ENABLED")) and (vapInterface == "ra0" or vapInterface == "ra1" or vapInterface == "rai0" or vapInterface == "rai1"))then    
            if(dot11VAP["vapEnabled"] == "1")then
                dot11.if_up (vapInterface, 1)
            else
                dot11.if_up (vapInterface, 1)
            end
        else
            if(dot11VAP["vapEnabled"] == "1")then
                dot11.if_up (vapInterface, 1)
            else
                dot11.if_up (vapInterface, 0)
            end
        end
    end

end

-------------------------------------------------------------------------------
-- @name dot11.SetVapState
--
-- @description This function sets state of all vap's on given radio
--
-- @param query
--
-- @return true or false
--

function dot11.SetVapState(vapDbString,meshDbString,vapRow)

    local dot11InterfaceRow = db.getRowWhere("dot11Interface", "vapName ='" ..vapRow["vapName"].."'" , false)
    local vapInterface = dot11InterfaceRow["interfaceName"]
    if((util.fileExists("/flash/MESH_ENABLED")) and (vapInterface == "ra0" or vapInterface == "ra1" or vapInterface == "rai0" or vapInterface == "rai1"))then    
        if(vapRow["vapEnabled"] == "1")then
            tcapiSetCmdWrite(vapDbString, "EnableSSID", 1)
            --tcapiSetCmdWrite(vapDbString, "HideSSID", 0)
            tcapiMeshSetCmdWrite(meshDbString,"BackHaul",0)
            tcapiMeshSetCmdWrite(meshDbString,"FrontHaul",1)
            tcapiMeshCommitCmdWrite(meshDbString)
            --tcapiCommitCmdWrite(vapDbString)
        else
            tcapiSetCmdWrite(vapDbString, "EnableSSID", 1)
            tcapiSetCmdWrite(vapDbString, "HideSSID", 1)
            tcapiMeshSetCmdWrite(meshDbString,"BackHaul",0)
            tcapiMeshSetCmdWrite(meshDbString,"FrontHaul",1)
            tcapiMeshCommitCmdWrite(meshDbString)
            --tcapiCommitCmdWrite(vapDbString)
        end
    else
        if(vapRow["vapEnabled"] == "1")then
            tcapiSetCmdWrite(vapDbString, "EnableSSID", 1)
        else
            tcapiSetCmdWrite(vapDbString, "EnableSSID", 0)
        end
        tcapiCommitCmdWrite(vapDbString)
    end
            
    tcapiSaveCmdWrite()
    --apply the VAP setting from here now
    if((util.fileExists("/flash/MESH_ENABLED")) and (vapInterface == "ra0" or vapInterface == "ra1" or vapInterface == "rai0" or vapInterface == "rai1"))then    
        if(vapRow["vapEnabled"] == "1")then
            dot11.if_up (vapInterface, 1)
        else
            dot11.if_up (vapInterface, 1)
        end
    else
        if(vapRow["vapEnabled"] == "1")then
            dot11.if_up (vapInterface, 1)
        else
            dot11.if_up (vapInterface, 0)
        end
    end

end

function dot11.AP_config(rowid, interfaceName, operation)

    --local
    local valid = false
    local dot11VAP = db.getRowWhere("dot11VAP", "_ROWID_ ='" ..rowid.."'" , false)
    local dot11Interfaces = db.getRowsWhere ("dot11Interface", "radioNo = " .. dot11VAP["radioNo"], false) 
    local profileRow = db.getRowWhere("dot11Profile", "_ROWID_ ='" ..rowid.."'" , false)    
    --local dot11Radios = db.getRowsWhere ("dot11Radio", "radioNo = " .. dot11VAP["radioNo"], false) 
    --local radioInterface = dot11Radios[1]["interfaceName"]
    local vapInterface = interfaceName
    local vapDbStringIndex = dot11VAP["radioNo"]
    local vapDbString ="_Entry"
    local meshDbString =" "
    --local radioDbString = "_Common"
    --local radioCommitString = ""
    if(rowid == "1" or rowid == "4") then
        if(tonumber(dot11VAP["radioNo"])==1)then
            vapDbStringIndex = rowid-1
            vapDbString ="_Entry"..vapDbStringIndex
            meshDbString = "_radio2gbssinfo_entry"..vapDbStringIndex
        elseif(tonumber(dot11VAP["radioNo"])==2)then
            --TODO We assume same number of vap's are being created on both
            --radio's. Check when different number of vap's are being created 
            --on radio's
            --radioDbString = "11ac_Common"
            --radioCommitString = "11ac"
            vapDbStringIndex = rowid-#dot11Interfaces-1
            vapDbString ="11ac_Entry"..vapDbStringIndex
            meshDbString = "_radio5glbssinfo_entry"..vapDbStringIndex
        end
    else
        if(tonumber(dot11VAP["radioNo"])==1)then
            vapDbStringIndex = rowid
            vapDbString ="_Entry"..vapDbStringIndex
            meshDbString = "_radio2gbssinfo_entry"..vapDbStringIndex
        elseif(tonumber(dot11VAP["radioNo"])==2)then
            --TODO We assume same number of vap's are being created on both
            --radio's. Check when different number of vap's are being created 
            --on radio's
            --radioDbString = "11ac_Common"
            --radioCommitString = "11ac"
            vapDbStringIndex = rowid-#dot11Interfaces
            vapDbString ="11ac_Entry"..vapDbStringIndex
            meshDbString = "_radio5glbssinfo_entry"..vapDbStringIndex
        end
    end

    if((util.fileExists("/flash/MESH_ENABLED")) and (vapInterface == "ra0" or vapInterface == "ra1" or vapInterface == "rai0" or vapInterface == "rai1"))then    
        if (operation == "enable") then
            valid = db.setAttribute("dot11VAP", "_ROWID_", rowid, "vapEnabled", "1")
            valid = db.setAttribute("dot11Profile", "_ROWID_", rowid, "broadcastSSID", "1")
            tcapiSetCmdWrite(vapDbString, "EnableSSID", 1)
            tcapiSetCmdWrite(vapDbString, "SSID",profileRow["ssid"])
            tcapiSetCmdWrite(vapDbString,"HideSSID","0")
            tcapiMeshSetCmdWrite(meshDbString,"BackHaul",0)
            tcapiMeshSetCmdWrite(meshDbString,"FrontHaul",1)
            tcapiMeshCommitCmdWrite(meshDbString)    
            tcapiSaveCmdWrite()
            dot11.if_up_bootup (vapInterface, 1)
        else
            valid = db.setAttribute("dot11VAP", "_ROWID_", rowid, "vapEnabled","0")
            valid = db.setAttribute("dot11Profile", "_ROWID_", rowid, "broadcastSSID", "0")
            tcapiSetCmdWrite(vapDbString, "EnableSSID", 1)
            tcapiSetCmdWrite(vapDbString, "SSID",profileRow["ssid"])
            tcapiSetCmdWrite(vapDbString,"HideSSID","1")            
		    tcapiMeshSetCmdWrite(meshDbString,"BackHaul",0)
            tcapiMeshSetCmdWrite(meshDbString,"FrontHaul",1)
            tcapiMeshCommitCmdWrite(meshDbString) 
            tcapiSaveCmdWrite()
            dot11.if_up_bootup (vapInterface, 1)
        end
    else
        if (operation == "enable") then
            valid = db.setAttribute("dot11VAP", "_ROWID_", rowid, "vapEnabled", "1")
            tcapiSetCmdWrite(vapDbString, "EnableSSID", 1)
            tcapiCommitCmdWrite(vapDbString)
            tcapiSaveCmdWrite()
            dot11.if_up_bootup (vapInterface, 1)
        else
            valid = db.setAttribute("dot11VAP", "_ROWID_", rowid, "vapEnabled","0")
            tcapiSetCmdWrite(vapDbString, "EnableSSID", 0)
            tcapiCommitCmdWrite(vapDbString)
            tcapiSaveCmdWrite()
            dot11.if_up_bootup (vapInterface, 0)
        end
    end
    --dot11.RadioSetVapState(dot11VAP["radioNo"])
    return valid
end

-------------------------------------------------------------------------------
-- @name dot11.confGet
--
-- @description This function returns dot11 configuration from the database
--
-- @param query
--
-- @return conf or nil
--

function dot11.confGet(dbtable, query)

    local records = {}
    if (query ~= nil) then
        records = db.getRowsWhere (dbtable, query, false)
        if (records == nil) then
            return nil
        end        
    else
        records = db.getTable (dbtable, false)
        if (records == nil) then
            return nil
        end        
    end        
    --retrun
    return records

end

-------------------------------------------------------------------------------
-- @name dot11.confSet
--
-- @description This function returns dot11 configuration from the database
--
-- @param query
--
-- @return conf or nil
--

function dot11.confSet(dbtable, cfg)

    if ((dbtable == nil) or 
        (cfg == nil) or (cfg["_ROWID_"] == nil)) then
        return false, "DOT11_ERR_INVALID_ARG"
    end        

    cfg = util.addPrefix(cfg, dbtable .. ".")
    util.appendDebugOut("dot11If: " .. util.tableToStringRec(cfg))

    local valid, errStr = db.update(dbtable, cfg, cfg["" .. dbtable .. "._ROWID_"])
    --return
    return valid, errStr

end

-------------------------------------------------------------------------------
--@name dot11.if_up_bootup()
--
--@description this function will enable/disable vaps
--
--@return
--
function dot11.if_up_bootup (ifName, enable)
    
    local upstr = " up"
    local bridgeName = db.getAttribute("dot11InterfaceToBridge", "interfaceName", ifName, "bridgeInterface")
    if(bridgeName ~= nil)then
        os.execute("/sbin/ifconfig " ..ifName .. upstr)
        os.execute("echo executing /usr/bin/brctl addif ".. bridgeName .. " "..ifName.. " > /dev/console ")
        os.execute("/usr/bin/brctl addif ".. bridgeName .. " "..ifName)
    end
    if (enable == 0) then
        upstr = " down"
        util.appendDebugOut ("executing ifconfig ".. ifName .. upstr .. " <br>")
        --os.execute("echo executing ifconfig ".. ifName .. upstr .. " > /dev/console ")
        --local status = os.execute ("/sbin/ifconfig " .. ifName .. upstr)
    else
        --upstr = " down"
        --util.appendDebugOut ("executing ifconfig ".. ifName .. upstr .. " <br>")
        --os.execute("echo executing ifconfig ".. ifName .. upstr .. " > /dev/console ")
        --local status = os.execute ("/sbin/ifconfig " .. ifName .. upstr)
        upstr = " up"
        util.appendDebugOut ("executing ifconfig ".. ifName .. upstr .. " <br>")
        ---os.execute("echo executing ifconfig ".. ifName .. upstr .. " > /dev/console ")
        --local status = os.execute ("/sbin/ifconfig " .. ifName .. upstr)
    end

end

-------------------------------------------------------------------------------
--@name dot11.if_up()
--
--@description this function will enable/disable vaps
--
--@return
--
function dot11.if_up (ifName, enable)
    
    local upstr = " up"
    if (enable == 0) then
        upstr = " down"
        util.appendDebugOut ("executing ifconfig ".. ifName .. upstr .. " <br>")
        --os.execute("echo executing ifconfig ".. ifName .. upstr .. " > /dev/console ")
        local cmdStr = "/sbin/ifconfig " .. ifName .. upstr
        util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)
    else
        --upstr = " down"
        --util.appendDebugOut ("executing ifconfig ".. ifName .. upstr .. " <br>")
        --os.execute("echo executing ifconfig ".. ifName .. upstr .. " > /dev/console ")
        --local cmdStr = "/sbin/ifconfig " .. ifName .. upstr
        --util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)
        upstr = " up"
        util.appendDebugOut ("executing ifconfig ".. ifName .. upstr .. " <br>")
        --os.execute("echo executing ifconfig ".. ifName .. upstr .. " > /dev/console ")
        local cmdStr = "/sbin/ifconfig " .. ifName .. upstr
       --util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)
    end

end

--------------------------------------------------------------------------------
-- @name dot11VAP.ifstateConfigure
--
-- @description This function commits the interface state changes to the
-- system and the database
--
-- @param ifTbl list of VAP interfaces
-- @param ifstate 1 for enable else  0
--
-- @return status
-- @return errCode
--

function dot11VAP.ifstateConfigure (ifTbl, ifstate)

    for k,v in pairs(ifTbl) do
        local valid = db.setAttribute("dot11VAP", "vapName", 
                                      v["vapName"], "vapEnabled", ifstate)  
        if (valid) then
            dot11.if_up_bootup (v["interfaceName"], tonumber(ifstate))
        else
            return "ERROR", "DOT11_ERR_VAP_IFSTATE"            
        end    
    end        
    --return
    return "OK", "STATUS_OK"

end  

-------------------------------------------------------------------------------
-- @name dot11VAP.ifstateSet
--
-- @description The function changes the interface state of the given vap.
--
-- @param vapTbl   table of vap interfaces
-- @param ifstate  1 for enable else 0
--
-- @return status
-- @return errCode
--

function dot11VAP.ifstateSet (vapTbl, ifstate)

    local query = nil
    local wherePart = nil
    if (vapTbl == nil) then
        return "ERROR", "DOT11_ERR_INVALID_ARG"
    end
            
    if (ifstate == nil) then
        ifstate = 1
    end        
    
    if (tonumber(ifstate) > 0 ) then
        ifstate =1
    else        
        ifstate =0
    end
    
    for k,v in pairs(vapTbl) do
        wherePart  ="interfaceName='" .. v["ifname"] .. "'"
        if (query == nil) then
            query = wherePart
        else
            query = query .. " or " ..  wherePart .. " "            
        end            
    end

    local ifTbl = dot11.confGet("dot11Interface", query)
    if (ifTbl == nil) then
        return "ERROR",  "NET_ERR_DB_NOENT"
    end        

    status, errCode = dot11VAP.ifstateConfigure (ifTbl, ifstate)
    if (status ~= "OK") then
        return "ERROR", errCode
    end        
    --return
    return "OK", "STATUS_OK"

end

------------------------------------------------------------------------------
-- @name dot11.ProfileGet ()
--
-- @description This function will get the information about one profile based on rowID
-- in system.
--
-- @return 
--
function dot11.ProfileGet(rowid)

    local profileRow = {}
    local v = {}
    profileRow = db.getRow ("dot11Profile","_ROWID_", rowid)
    v["profileName"] = profileRow["dot11Profile.profileName"]
    v["ssid"] = profileRow["dot11Profile.ssid"]
    v["broadcastSSID"] = profileRow["dot11Profile.broadcastSSID"]
    v["security"] = profileRow["dot11Profile.security"]
    v["pairwiseCiphers"] = profileRow["dot11Profile.pairwiseCiphers"]
    v["authMethods"] = profileRow["dot11Profile.authMethods"]
    if (profileRow["dot11Profile.pskPassAscii"] ~= nil) then
        v["pskPassAscii"] = util.mask (profileRow["dot11Profile.pskPassAscii"])
    end
    v["wepAuth"] = profileRow["dot11Profile.wepAuth"]
    v["groupCipher"] = profileRow["dot11Profile.groupCipher"]
    v["pskPassHex"] = profileRow["dot11Profile.pskPassHex"]
    v["wepkeyPassphrase"] = profileRow["dot11Profile.wepkeyPassphrase"]
    v["defWepkeyIdx"] = profileRow["dot11Profile.defWepkeyIdx"]
    v["wepkey0"] = profileRow["dot11Profile.wepkey0"]
    v["wepkey1"] = profileRow["dot11Profile.wepkey1"]
    v["wepkey2"] = profileRow["dot11Profile.wepkey2"]
    v["wepkey3"] = profileRow["dot11Profile.wepkey3"]
    v["editProfileNameStatus"] = "DISABLED"
	
    if (v == nil) then
        return nil, "DB_ERROR_TRY_AGAIN"
    end
    --return
    return v

end

------------------------------------------------------------------------------
-- @name dot11.ProfilesGet ()
--
-- @description This function will get the information about dot11Profiles
-- in system.
--
-- @return 
--
function dot11.ProfilesGet()

    local apInfoTbl = {}
    apInfoTbl = db.getTable ("dot11Profile",false)
    for i,v in pairs(apInfoTbl) do
        if(v["broadcastSSID"] == "1") then
            v["broadcastSSID"] = "Enabled"
        else
            v["broadcastSSID"] = "Disabled"
        end
        if(v["pairwiseCiphers"] == "TKIP+CCMP") then
            v["pairwiseCiphers"] = "TKIP+CCMP"
        elseif(v["pairwiseCiphers"] == "CCMP") then
            v["pairwiseCiphers"] = "CCMP"
        elseif(v["pairwiseCiphers"] == "TKIP") then
            v["pairwiseCiphers"] = "TKIP"
        -- for WEP, encryption value is stored in groupCipher
        elseif(v["security"] == "WEP") then
            v["pairwiseCiphers"] =  v["groupCipher"] .. "-bit"
        elseif(v["pairwiseCiphers"] == "") then
            v["pairwiseCiphers"] = "None"
        end
        -- for WEP, authentication value is stored in wepAuth
        if(v["security"] == "WEP") then
            v["authMethods"] = v["wepAuth"]
        elseif(v["authMethods"] == "") then
            v["authMethods"] = "None"
        end
        if(v["pskPassAscii"] ~= nil ) then
            v["pskPassAscii"] = util.mask (v["pskPassAscii"])
        end
    end
    if (apInfoTbl == nil) then
        return nil, "DB_ERROR_TRY_AGAIN"
    end
    --return
    return apInfoTbl
	
end

------------------------------------------------------------------------------
-- @name dot11.accessPointGet ()
--
-- @description This function will get the information about dot11Profiles
-- in system.
--
-- @return 
--
function dot11.accessPointGet()

    --locals
    local apInfoTbl = {}
    apInfoTbl = db.getTable ("dot11Profile",false)
    local vapInfoTbl = db.getTable ("dot11VAP",false)
    local accessPoint= {}
    local count = 1
    local macAddress = {}

    for i,v in pairs(vapInfoTbl) do
        local dot11InterfaceRow = db.getRow ("dot11Interface", "vapName", v["vapName"])
            accessPoint[count] = {}
            accessPoint[count]["_ROWID_"] = v["_ROWID_"]
            if (dot11InterfaceRow["dot11Interface.radioNo"] == "1") then
                accessPoint[count]["band"] = "2.4 GHz"
            else
                accessPoint[count]["band"] = "5 GHz"
            end
            for ii,vv in pairs (apInfoTbl) do
                if (v["profileName"] == vv["profileName"]) then
                    if (tonumber(v["vapEnabled"]) == 1) then
                        accessPoint[count]["vapEnabled"] = "Enabled"
                    else
                        accessPoint[count]["vapEnabled"] = "Disabled"
                    end
                    if (vv["broadcastSSID"] == "1") then
                        accessPoint[count]["broadcastSSID"] = "Enabled"
                    else
                        accessPoint[count]["broadcastSSID"] = "Disabled"
                    end
                    accessPoint[count]["ssid"] = vv["ssid"]
                    accessPoint[count]["security"] = vv["security"]
                    if(vv["pairwiseCiphers"] == "TKIP+CCMP") then
                        accessPoint[count]["pairwiseCiphers"] = "TKIP+CCMP"
                    elseif(vv["pairwiseCiphers"] == "CCMP") then
                        accessPoint[count]["pairwiseCiphers"] = "CCMP"
                    elseif(vv["pairwiseCiphers"] == "TKIP") then
                        accessPoint[count]["pairwiseCiphers"] = "TKIP"
                        -- for WEP, encryption value is stored in groupCipher
                    elseif(vv["security"] == "WEP") then
                        accessPoint[count]["pairwiseCiphers"] =  vv["groupCipher"] .. "-bit"
                    elseif(vv["pairwiseCiphers"] == "") then
                        accessPoint[count]["pairwiseCiphers"] = "None"
                    end
                    -- for WEP, authentication value is stored in wepAuth
                    if(vv["security"] == "WEP") then
                        accessPoint[count]["authMethods"] = vv["wepAuth"]
                    elseif(vv["authMethods"] == "") then
                        accessPoint[count]["authMethods"] = "None"
                    else
                        accessPoint[count]["authMethods"] = vv["authMethods"]
                    end
                    accessPoint[count]["profileName"] = v["profileName"]
                    accessPoint[count]["vapName"] = v["vapName"]
                end
            end
            count = count+1
    end

    if (accessPoint == nil) then
        return nil, "DB_ERROR_TRY_AGAIN"
    end
    --return
    return accessPoint

end

-------------------------------------------------------------------------------
--@name  dot11.getDefWifiCfg ()
--
--@description The function will get the wireless info from the dot11 table
--
--@return

function dot11.getDefWifiCfg ()

    --locals
    local wirelessTbl = {}
    local query1  = "_ROWID_=1" -- getting the first row
    local vapTbl = {}
    local profileTbl = {}

    -- querying the 1st Row of dot11VAP
    vapTbl = db.getRowWhere("dot11VAP", query1, false)
    local query2 = "profileName='"..vapTbl["profileName"] .. "'"

    -- querying the dot11Profile table 
    profileTbl = db.getRowWhere("dot11Profile", query2, false)
    wirelessTbl["wstatus"] = vapTbl["vapEnabled"]
    wirelessTbl["wname"] =  profileTbl["ssid"]

    if ((profileTbl["security"] == "WPA") or(profileTbl["security"] == "WPA2") or (profileTbl["security"] == "WPA+WPA2")) then
        wirelessTbl["wpassword"] = profileTbl["pskPassAscii"]
    elseif (profileTbl["security"] == "WEP") then
        wirelessTbl["wpassword"] = ""
    end

    -- return
    return wirelessTbl

end

-------------------------------------------------------------------------------
--@name dot11.wifiMacGet()
--
--@description this function will returns the mac address of radio interface.
--
--TODO: Change the query if there are two or more radio interface
--@return

function dot11.wifiMacGet()

    local radioInterfaceName = db.getAttribute("dot11Radio","radioNo","1","interfaceName")
    local cmd = "/sbin/ifconfig "..radioInterfaceName.." | grep 'HWaddr' | cut -d' ' -f 10 > /tmp/wifiMac.txt"
    os.execute(cmd)
    local f = io.open("/tmp/wifiMac.txt","r")
    local macAddr = f:read ("*line")
    f:close()
    if (macAddr) then
        return macAddr
    else
        return ""
    end

end

-------------------------------------------------------------------------------
-- @name dot11Profile.ifNameGet
--
-- @description The function gets the ifname on which the profile is set
--
-- @param profile name of the profile
--
-- @return ifname or nil
--

function dot11Profile.ifNameGet(profileName)

    local vapName = nil
    local query  = nil
    if (profileName == nil) then
        return profileName            
    end
    local vaprows = db.getRowsWithJoin({"dot11Profile:dot11VAP:profileName"}, "dot11Profile.profileName", profileName)
    for k,v in pairs(vaprows) do
        vapName = v["dot11VAP.vapName"]
    end        
    if (vapName == nil) then
        return nil
    end        
    query = "vapName='" .. vapName .. "'"
    local row = db.getRowWhere("dot11Interface", query, false)
    if (row == nil) then
        return nil
    end        
    return row["interfaceName"]

end

function dscpToCosMapping.inputvalidate (inputTable, operation)
    local valid = db.typeAndRangeValidate(util.tableSplit(inputTable, ".", "dscpToCosMapping"))
    if (valid == false) then 
        return false
    end
    return true

end

function dscpToCosMapping.config (inputTable, rowid, operation)
    -- validate
    if (dscpToCosMapping.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("dscpToCosMapping", inputTable)
        elseif (operation == "edit") then
            return db.update("dscpToCosMapping", inputTable, rowid)
       end
    end
    return false
end


--dscpToCosMapping_config
function dot11.dscpToCosMapping_config (inputTable, rowid, operation)

    local valid = true
    valid = dscpToCosMapping.config (inputTable, rowid, operation)


    if (operation == "edit") then
        -- remove exsisting file in flash and create fresh file
        os.remove (DSCP_PBIT_FLASH_FILE)
        dot11.dscpToCosMappingFlashConfigCreate (inputTable)
    end

    if (valid) then
        return "OK", "STATUS_OK"
    else
       return "ERROR", "DSCP_TO_COS_CONFIG_FAILED"
    end
end

function dot11.updateWscConfModeHelper(prefix, entry, value)
    tcapiSetCmdExecute(entry, "WPSConfMode", value)
    tcapiCommitCmdExecute(entry)
    tcapiCommitCmdExecute(prefix)
    tcapiSaveCmdExecute()
end

function dot11.vapItoN(vapName)
    local vapNumber = ""
    local band = ""
    if (vapName == "ap1") then
        vapNumber = "0"
    elseif (vapName == "ap2") then
        vapNumber = "2"
    elseif (vapName == "ap3") then
        vapNumber = "3"
    elseif (vapName == "ap4") then
        vapNumber = "0"
        band = "11ac"
    elseif (vapName == "ap5") then
        vapNumber = "2"
        band = "11ac"
    elseif (vapName == "ap6") then
        vapNumber = "3"
        band = "11ac"
    end
    
    return vapNumber, band
end

function dot11.updateWscConfMode(newVapName, oldVapName, newVapStatus, oldVapStatus)
    local oldPrefix = ""
    local newPrefix = ""
    local newEntryN = ""
    local newEntry = ""
    local oldEntryN = ""
    local oldEntry = ""

    -- check and set prefix if it is 5Ghz AP
    oldEntryN, oldPrefix = dot11.vapItoN(oldVapName)
    newEntryN, newPrefix = dot11.vapItoN(newVapName)

    oldEntry = oldPrefix.."_Entry"..oldEntryN
    newEntry = newPrefix.."_Entry"..newEntryN

    -- All possible the newAP and oldAP WPS cases
    if (tonumber(newVapStatus) == 0) then
        if (tonumber(newVapStatus) == tonumber(oldVapStatus)) then
            if (newVapName == oldVapName) then
                -- set newAP WscConfMode to '0'
                dot11.updateWscConfModeHelper(newPrefix, newEntry, "0")
            else
                -- set oldAP WscConfMode to '4' and set newAP WscConfMode to '0'
                dot11.updateWscConfModeHelper(oldPrefix, oldEntry, "4")
                dot11.updateWscConfModeHelper(newPrefix, newEntry, "0")
            end
        else
            -- set newAP WscConfMode to '0'
            dot11.updateWscConfModeHelper(newPrefix, newEntry, "0")
        end
    else
        if (tonumber(newVapStatus) ~= tonumber(oldVapStatus)) then
            -- set oldAP WscConfMode to '4'
            dot11.updateWscConfModeHelper(oldPrefix, oldEntry, "4")
        end
    end
end
