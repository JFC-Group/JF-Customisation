-- utilties.lua
-- Gaurav Mathur
-- TeamF1
-- www.TeamF1.com

-- Modification History
-- 23dec07,gnm modified utilCLIFactoryReset to prompt for user confirmation
-- 07dec07 gnm written
--
-- Description
-- CLI utility routines

--
-- This routine implements the ping command for the CLI
function utilCLIPing(ipToPing)
    local pingprog = db.getAttribute ("environment", "name", "PING_PROGRAM", 
	  "value")
    local pingfile = db.getAttribute("environment", "name", "PING_FILE_NAME", 
	  "value")
    local x = os.execute (pingprog .. " " .. ipToPing)
    printCLIError (x)
end

--
-- This routine implements the reboot command for the CLI
function utilCLIReboot(args)
    db.setAttribute("reboot", "reboot._ROWID_", "1", "reboot", "1")
    local restartTime = db.getAttribute("environment", "name", "BOOTUP_TIME", "value")
    statusMessage = "Router will be up in " .. restartTime .. " seconds."
    printCLIError (statusMessage)	
end


--
-- This routine implements the CLI command to restore factory default
-- settings on the system.
function utilCLIFactoryReset(args)
    local triesMax = 5 -- hard-coded
    local triesCur = 0
    local confirm = ""
    local message = "Preparing to restore saved settings from user-provided " .. 
		  "file.\nWARNING: Current configuration will be erased.\n"

    printCLIError (message)
    while (confirm ~= "Y" and confirm ~= "N" and triesCur < triesMax) do
	  printCLIError ("Are you sure you want to proceed [Y/N]?")
	  confirm = io.stdin:read'*l'
	  triesCur = triesCur + 1
    end

    if (confirm == "N" or (triesCur == triesMax)) then return end
    	  	  
    local fact_settingsfile = db.getAttribute("environment", "name", 
	  "TEAMF1_CFG_DEFAULTS_ASCII", "value")
    local SETTINGS_FILE = db.getAttribute("environment", "name", 
	  "TEAMF1_CFG_ASCII", "value")

    os.execute("rm -rf" .. " " .. SETTINGS_FILE)
    os.execute("cp" .. " " .. fact_settingsfile .. " " .. SETTINGS_FILE)

    -- copy file to flash
    local writeprog = db.getAttribute("environment", "name", "CFG_WRITE_PROGRAM",
	  	 "value")
    local configpart = db.getAttribute("environment", "name", 
	  "FLASH_CFG_PARTITION", "value")
    os.execute(writeprog .. " " .. configpart .. " " .. SETTINGS_FILE)
    utilCLIReboot()
end
