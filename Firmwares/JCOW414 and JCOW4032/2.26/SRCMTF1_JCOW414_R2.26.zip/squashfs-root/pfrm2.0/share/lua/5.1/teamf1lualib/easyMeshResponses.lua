--[[ easyMeshResponses.lua - Library for easyMesh API Success/Error responses.
--
-- Copyright (c) 2008-2019, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: easyMeshResponses.lua
-- Description: Library for generating Easy Mesh JSON responses.
-- 
-- modification history
-- --------------------
-- 01a, 26Nov19, ar written.
--
--]]

local json = require ("teamf1lualib/json")

resultOK = {
    ["Result"] = "OK"
}

resultError = {
    ["Result"] = "ERROR"
}

result401Error = {
    ["Response_Code"] = "401",
    ["Result"] = "Error-Auth",
    ["Error_Message"] = "Error-Auth"
}

function mesh.responseOK ()
    
    local msg
    
    msg = json.encode(resultOK)
    
    web.sendJSON(msg)

    return
end

function mesh.responseError ()
    
    local msg
    
    msg = json.encode(resultError)
    
    web.sendJSON(msg)

    return
end

function mesh.sendResponse (inputResponse_t)
    
    local msg
    
    msg = json.encode(inputResponse_t)
    
    web.sendJSON(msg)

    return
end

function mesh.tprint (tbl, indent)
  if not indent then indent = 0 end
  local toprint = string.rep(" ", indent) .. "{\r\n"
  indent = indent + 2 
  for k, v in pairs(tbl) do
    toprint = toprint .. string.rep(" ", indent)
    if (type(k) == "number") then
      toprint = toprint .. "[" .. k .. "] = "
    elseif (type(k) == "string") then
      toprint = toprint  .. k ..  "= "   
    end
    if (type(v) == "number") then
      toprint = toprint .. v .. ",\r\n"
    elseif (type(v) == "string") then
      toprint = toprint .. "\"" .. v .. "\",\r\n"
    elseif (type(v) == "table") then
      toprint = toprint .. mesh.tprint(v, indent + 2) .. ",\r\n"
    else
      toprint = toprint .. "\"" .. tostring(v) .. "\",\r\n"
    end
  end
  toprint = toprint .. string.rep(" ", indent-2) .. "}"
  return toprint
end


