--[[
#### File: firmware.lua
#### Description: firmware lua functions
#### Copyright (c) 2017, TeamF1 Networks Pvt. Ltd.
#### (Subsidiary of D-Link India)

#### Copyright (c) 2010, TeamF1, Inc. */

#### Modification history:
01m,31Jul17,swr Changes for SPR 60117
01L,20Apr17,MSV Made changes for DMS support in LANTIQ SPR#60512
01k,25Jan17,MSV Made changes for DMS backup/restore SPR#59380
01j,14Nov15,swr Fix for SPR 57376
01i,01Sep16,MSV Added nil checks for productclass and serial and removal
            of backup ascii file while factory defaulting of device.
01h,03aug16,MSV Made changes for DMS thirdparty framework
01g,23Nov15,swr Fix for SPR 54316
01f,26Oct15,swr Fix for SPR 53763 
01e,22Jan15,tbp modified changes made for config file path for HGW in tr69Restore api
01d,16Jan15,swr commenting out support for UpgradesManaged
01c,31Oct14,swr changes for UpgradesManaged
01b,05oct12,sen removed the call to update version as it is being updated via firmwareInit
01a,02feb10,rks written
]]--

require "firmLib"

firmware = {}
firmware.upgradeStatusFile = "/tmp/upgrade.status"
firmware.versionFile = "/pfrm2.0/firmVersion"
firmware.flashfirmwareVerFile = "/flash/firmwareVersionInfo"
firmware.serialNUMFile = "/tmp/cpe3/dps.serial" 
firmware.flashserialNUMFile = "/flash/serialInfo"
firmware.prodclassFile = "/tmp/cpe3/dps.productclass"
firmware.flashprodclassFile = "/flash/productclassInfo"
firmware.flashKeepAliveEvents = "/flash/keepAliveEvents"
--firmware.flashUpdradesManaged = "/flash/updradesManaged"
firmware.debug = 0
firmware.defRebootTime = 10
firmware.upgradeStatus = {
    FIRMD_STATE_INIT                    = 1,
    FIRMD_STATE_SRV_DISCOVERY           = 2,
    FIRMD_STATE_SRV_FOUND               = 3,
    FIRMD_STATE_DOWNLOADING             = 4,
    FIRMD_STATE_DOWNLOADED              = 5,
    FIRMD_STATE_DOWNLOAD_FAILED         = 6,
    FIRMD_STATE_UPGRADING               = 8,                 
    FIRMD_STATE_IMAGE_VERIFYING         = 9,
    FIRMD_STATE_IMAGE_VERIFIED          = 10,
    FIRMD_STATE_UPGRADE_PREINSTALL      = 11,
    FIRMD_STATE_ERASE_STAGE             = 12,
    FIRMD_STATE_ERASE_KERNEL            = 13,
    FIRMD_STATE_ERASE_FS                = 14,
    FIRMD_STATE_WRITING_KERNEL          = 15,
    FIRMD_STATE_WRITING_FS              = 16,
    FIRMD_STATE_UPGRADE_POSTINSTALL     = 17,
    FIRMD_STATE_UPGRADE_FAILED          = 18,
    FIRMD_STATE_UPGRADE_SUCCESS         = 19,
    FIRMD_STATE_SHUTDOWN                = 20,                 
}

-- see if the file exists
function file_exists(file)
  local f = io.open(file, "rb")
  if f then f:close() end
  return f ~= nil
end

-- get all lines from a file, returns an empty 
-- list/table if the file does not exist
function lines_from(file)
  if not file_exists(file) then return {} end
  lines = {}
  for line in io.lines(file) do 
    lines[#lines + 1] = line
  end
  return lines
end

--[[
*****************************************************************************
- firmware.debugPrint
-
-
- RETURN: 
-]]--

function firmware.debugPrint (str)
    if (tonumber(firmware.debug) == 1) then
        print("FIRMWARE: " .. str)
    end        
end


function firmware.checkUpdate()
    require "lfs"

    local systemConfig =  db.getTable("firmUpdateSystemConfig", false)
    if ((systemConfig == nil) or (systemConfig[1] == nil))  then
        return "FIRMWARE_DB_ERR", nil
    end
            
    if ((systemConfig[1].url == nil) or (strlen(systemConfig[1].url) == 0)) then
        return "FIRMWARE_INFO_DOWNLOAD_FAILED", nil
    end        

    -- download firmare info file
    os.execute ("/pfrm2.0/bin/curl -s " .. systemConfig[1].url .. " -o /tmp/current-firmware.txt");

    local attr = lfs.attributes ("/tmp/current-firmware.txt");

    if (attr == nil or attr.size == 0) then
        return "FIRMWARE_INFO_DOWNLOAD_FAILED", nil;
    end

    local firmInfo = {}

    for line in io.lines ("/tmp/current-firmware.txt") do
        for key,value in string.gfind (line,"(.+)=(.+)") do
            firmInfo [key] = value
        end
    end

    -- verify the mandatory paramters are present
    if (firmInfo.version == nil or firmInfo.url == nil or firmInfo.size == 0) then
        return "FIRMWARE_INFO_DOWNLOAD_CORRUPT", nil 
    end

    local inputTable = {}
    inputTable["firmUpdateStatus.version"] = firmInfo.version
    inputTable["firmUpdateStatus.checked"] = os.date()
    
    local firmStatus = db.getTable ("firmUpdateStatus", false);

    if (#firmStatus == 0) then
        inputTable["firmUpdateStatus.downloaded"] = 0
        db.insert ("firmUpdateStatus", inputTable);
    else 
        if (firmStatus[1].version == firmInfo.version) then
            inputTable["firmUpdateStatus.downloaded"] = firmStatus[1].downloaded
        else 
            inputTable["firmUpdateStatus.downloaded"] = 0
        end
        db.update ("firmUpdateStatus", inputTable, 1);
    end

    return "OK", firmInfo
end

function firmware.download()
    require "lfs"

    local attr = lfs.attributes ("/tmp/current-firmware.txt");

    if (attr == nil) then
        local systemConfig =  db.getTable("firmUpdateSystemConfig", false)
        os.execute ("/pfrm2.0/bin/curl -s " .. systemConfig[1].url .. " -o /tmp/current-firmware.txt");

        attr = lfs.attributes ("/tmp/current-firmware.txt");

        if (attr == nil or attr.size == 0) then
            return "FIRMWARE_INFO_DOWNLOAD_FAILED", nil;
        end
    end

    local firmInfo = {}

    for line in io.lines ("/tmp/current-firmware.txt") do
        for key,value in string.gfind (line,"(.+)=(.+)") do
            firmInfo [key] = value
        end
    end

    -- verify the mandatory paramters are present
    if (firmInfo.version == nil or firmInfo.url == nil or firmInfo.size == 0) then
        return "FIRMWARE_INFO_DOWNLOAD_CORRUPT"
    end

    os.execute ("/pfrm2.0/bin/curl -s " .. firmInfo.url .. " -o /tmp/current-firmware.dat");
    
    local attr = lfs.attributes ("/tmp/current-firmware.dat");

    if (attr == nil or attr.size ~= tonumber(firmInfo.size)) then
        return "FIRMWARE_DOWNLOAD_FAILED"
    end

    local systemConfig =  db.getTable("firmUpdateSystemConfig", false)

    os.execute (systemConfig[1].decryptProgram .. "  /tmp/current-firmware.dat " .. systemConfig[1].downloadPath)

    local inputTable = {}
    inputTable["firmUpdateStatus.version"] = firmInfo.version
    inputTable["firmUpdateStatus.checked"] = os.date()
    inputTable["firmUpdateStatus.downloaded"] = 1

    db.update ("firmUpdateStatus", inputTable, 1);

    return "OK"
end

function firmware.upgradeStatusGet ()
    require "firmLib"

    if (firmLib.isRunning() == 0) then
       firmInstall={}
       firmInstall["md5sum"] = ""
       firmInstall["downloadStatus"] = "--"
       firmInstall["firmwareSize"] = "0"
       firmInstall["status"] = "FIRMD_STATE_STOPPED" 
       firmInstall["completed"] = "0"
    else
        local fileName = firmware.upgradeStatusFile
        if (pcall (loadfile (fileName))) then
            dofile (fileName)
        end
        if (firmInstall == nil) then
            firmInstall={}
            firmInstall["md5sum"] = ""
            firmInstall["downloadStatus"] = "FIRMD_DOWNLOAD_COMPLETE"
            firmInstall["firmwareSize"] = "0"
            firmInstall["status"] = "FIRMD_STATE_INIT" 
            firmInstall["completed"] = "0"
        end
    end
            
    local sysCfg = db.getRowWhere ("firmUpdateSystemConfig", "_ROWID_=1", false)
    if (sysCfg ~= nil) then
        firmInstall["domainName"] = sysCfg["domain"]
        firmInstall["url"] = sysCfg["url"]
        firmInstall["userName"] = sysCfg["userName"]
    end

    if (firmInstall["status"] == "FIRMD_STATE_DOWNLOADING") then
        if (sysCfg["downloadPath"] ~= nil) then
            local fp = io.open(sysCfg["downloadPath"])
            if (fp ~= nil) then
                firmInstall["firmwareSize"] = fp:seek("end")
                fp:close()
            end
        end
    elseif (firmInstall["status"] == "FIRMD_STATE_UPGRADE_POSTINSTALL") then
        firmInstall["completed"] = "80"
    end


    return firmInstall
end

function firmware.upgrade2 (cmdline)
    local upgrade = db.getAttribute("environment", "name", "UPGRADE_PROGRAM", "value")

    if ((cmdline == nil) or (upgrade == nil)) then
        return 1        
    end        

    local cmd = upgrade .. " " .. cmdline

    firmware.debugPrint("EXEC : " .. cmd)
    status = os.execute (cmd)
    firmware.debugPrint("STATUS : " .. status)

    return status;
end

-- Verify downloads
-- status = firmware.upgrade(filename, 0, 0, 0, " -v -c ")
--

-- Upgrade
-- status = firmware.upgrade(filename, 1, 5, 1, " -n ")


function firmware.upgrade (filename, reboot, rebootTime, background, flags,upgradeFlag)
    if (filename == nil) then
        local systemConfig =  db.getTable("firmUpdateSystemConfig", false)
        filename = systemConfig[1].downloadPath
    end

    local upgrade = db.getAttribute("environment", "name", "UPGRADE_PROGRAM", "value")
    local device = db.getAttribute("environment", "name", "DEVICE_NAME", "value")
    local partitionImage1 = db.getAttribute("environment", "name", "FLASH_FIRM_PARTITION", "value")
    local partitionImage2 = db.getAttribute("environment", "name", "FLASH_FIRM_PARTITION_IMAGE2", "value")
    local partition2Image1 = db.getAttribute("environment", "name", "FLASH_FIRM_FS_PARTITION", "value")
    local partition2Image2 = db.getAttribute("environment", "name", "FLASH_FIRM_FS_PARTITION_IMAGE2", "value")
	local firmName = ""



	if (util.fileExists ("/pfrm2.0/FIRMWARE_SIGNING_ENABLED1") == true or util.fileExists ("/pfrm2.0/FIRMWARE_SIGNING_ENABLED2") == true) then


	    -- Check the status returned from firmware integrityCheck scrcipt
	
	    upgradeCmd  = "/pfrm2.0/bin/firmwareVerify.sh " .. filename .. " " .. upgradeFlag .. " >/dev/null"                                               
	    os.execute (upgradeCmd)
	
	    local firmSignCheck = ""
	    f = io.open ("/tmp/firmCheckRes.txt", "r")
	    if(f ~= nil) then
	        firmSignCheck = f:read("*line")
	        f:close()
	    else
	        firmware.debugPrint("Firmware integrity check failed. Aborting upgrade ")
	        return "1"
	    end

        
        if (firmSignCheck ~= nil) then
            if ((string.find (string.lower(firmSignCheck), "error") ~= nil) or (string.find (string.lower(firmSignCheck), "sign or verify one file") ~= nil) or (string.find (string.lower(firmSignCheck), "no signature") ~= nil) or (string.find (string.lower(firmSignCheck), "mac and signing key cannot both") ~= nil) or (string.find (string.lower(firmSignCheck), "unsupported") ~= nil) or (string.find (string.lower(firmSignCheck), "failure") ~= nil)) then

                firmware.debugPrint("Firmware integrity check failed. Aborting upgrade ")
                return "1"
            else
                firmware.debugPrint("Firmware integrity check passed")
            end
        else
            firmware.debugPrint("Firmware integrity check passed")
        end

	    f = io.open ("/tmp/firmName", "r")
	    if(f ~= nil) then
	        firmName = f:read("*line")
	        f:close()
	    else
	        firmware.debugPrint("Firmware integrity check failed. Aborting upgrade ")
	        return "1"
	    end
	end
    if (util.fileExists ("/pfrm2.0/BRCMJCO300") or util.fileExists ("/pfrm2.0/ECONET")) then
        local file = ""
        if (util.fileExists ("/pfrm2.0/HW_FOXCONN_JCO500")) then
            file = "HW_FOXCONN_JCO500"  
        elseif (util.fileExists ("/pfrm2.0/HW_JCO110")) then
            file = "HW_JCO110"  
        elseif( util.fileExists("/pfrm2.0/HW_HG260ES")) then
            file = "HW_HG260ES"  
        elseif( util.fileExists("/pfrm2.0/HW_HG261GU2")) then
            file = "HW_HG261GU2"  
        elseif (util.fileExists("/pfrm2.0/HW_HG260X")) then
            file = "HW_HG260X"  
        elseif(util.fileExists("/pfrm2.0/HW_FIBERHOME_JCO300"))then
            file = "HW_FIBERHOME_JCO300"
        elseif(util.fileExists("/pfrm2.0/HW_JCOW206"))then
            file = "HW_JCOW206"
        elseif(util.fileExists("/pfrm2.0/HW_JCOW401"))then
            file = "HW_JCOW401"
        elseif(util.fileExists("/pfrm2.0/HW_JCOW403"))then
            file = "HW_JCOW403"	
        elseif(util.fileExists("/pfrm2.0/HW_JCOW404"))then
            file = "HW_JCOW404"
        elseif(util.fileExists("/pfrm2.0/HW_JCOW411"))then
            file = "HW_JCOW411"
        elseif(util.fileExists("/pfrm2.0/HW_JCO2031"))then
            file = "JCO2031"	
        elseif(util.fileExists("/pfrm2.0/HW_JCO4031"))then
            file = "JCO4031"
	elseif(util.fileExists("/pfrm2.0/HW_JCOW414"))then
            file = "JCOW414"
        elseif(util.fileExists("/pfrm2.0/HW_JCO4032"))then
            file = "JCO4032"
        elseif(util.fileExists("/pfrm2.0/HW_JCOW407"))then
            file = "JCOW407"
        elseif(util.fileExists("/pfrm2.0/HW_JMA24"))then
            file = "JMA24"
        elseif(util.fileExists("/pfrm2.0/HW_JCOW402"))then
            file = "JCOW402"	
        end

        local firm_check_cmd = ""
        if (file ~= nil) then
	        if (util.fileExists ("/pfrm2.0/FIRMWARE_SIGNING_ENABLED1") == true or util.fileExists ("/pfrm2.0/FIRMWARE_SIGNING_ENABLED2") == true) then
                firm_check_cmd = "strings " .. firmName.. " | grep " ..file.. " > /tmp/firm_check.txt"
            else
                firm_check_cmd = "strings "..filename.." | grep " ..file.. " > /tmp/firm_check.txt"
            end
        end
      
        os.execute(firm_check_cmd)

        local firmCheck = ""
	    fp= io.open ("/tmp/firm_check.txt", "r")
	    if(fp ~= nil) then
	        firmCheck = fp:read("*line")
        end

        if (firmCheck ~= nil) then
            if (string.match(firmCheck,file) == nil) then
                return "2"
            end
        else
            return "2"
        end
    end

    if (util.fileExists("/pfrm2.0/HW_HG260X")) then
          local filename = "/tmp/upgrade/download.dwn"
          local s1 = "strings "..filename.." | grep HG260X_D2.96  > /tmp/dmz6.txt "
          local s2 = "strings "..filename.." | grep HG260X_R2.96  >> /tmp/dmz6.txt "
          local s3 = "strings "..filename.." | grep HG260X_D2.97 >> /tmp/dmz6.txt "
          local s4 = "strings "..filename.." | grep HG260X_R2.97 >> /tmp/dmz6.txt "
          os.execute(s1)
          os.execute(s2)
          os.execute(s3)
          os.execute(s4)
         local contents = ""
         f = io.open ("/tmp/dmz6.txt", "r")
         if(f ~= nil) then
            contents  = f:read("*all")
            f:close()
         else
            f:close()
            return "ERROR"
         end
	
	 if(string.match(contents,"HG260X_D2.96") or string.match(contents,"HG260X_R2.96") or string.match(contents,"HG260X_R2.97") or string.match(contents,"HG260X_D2.97")) then
		local query = "DROP TABLE dmz6"
                local valid = db.execute(query)
                if(valid)then
                  db.save2()
                else
                  db.rollback()
                end

	 end

     end

	local runningFirmware = ""
    f = io.open("/tmp/runningFirmware","r")
    if(f ~= nil) then
        runningFirmware = f:read("*line")
        f:close()
	else
		runningFirmware = "1"
    end

	if (runningFirmware == "1") then
		partition = partitionImage2
		partition2 = partition2Image2
	else
		partition = partitionImage1
		partition2 = partition2Image1		
	end

    -- TODO: local upgradeprep = db.getAttribute("environment", "name", "UPGRADEPREP_PROGRAM", "value")

	if (util.fileExists ("/pfrm2.0/FIRMWARE_SIGNING_ENABLED1") == true or util.fileExists ("/pfrm2.0/FIRMWARE_SIGNING_ENABLED2") == true) then
    cmd = upgrade .. " -f " .. firmName .. " -d " .. device .. "  -p " .. partition
    else
    cmd = upgrade .. " -f " .. filename .. " -d " .. device .. "  -p " .. partition
    end

    if (partition2) then
        cmd = cmd .. " -s " .. partition2 .. " -R " .. partition2
    end

    -- creating files in flash for using them in sending 0BOOTSTRAP event in tr69
    os.execute("touch " ..firmware.flashKeepAliveEvents)
    --os.execute("touch " ..firmware.flashUpdradesManaged)
    if (util.fileExists(firmware.serialNUMFile)) then
	    local serial = util.fileToString(firmware.serialNUMFile)
        if(serial ~= nil) then
            os.execute("/bin/echo " ..serial.. " > " ..firmware.flashserialNUMFile.. " ")
        end
    end
    if (util.fileExists(firmware.prodclassFile)) then
	    local productclass = util.fileToString(firmware.prodclassFile)
        if(productclass ~= nil) then
            os.execute("/bin/echo " ..productclass.. " > " ..firmware.flashprodclassFile.. " " )
        end
    end

    local filep = io.open(firmware.versionFile, "r")
    local swVersion = ""

    if (filep ~= nil) then
        swVersion  = filep:read("*l")
        filep:close()
    end        

    local fp = io.open(firmware.flashfirmwareVerFile,"w")
    if (fp ~= nil) then
        fp:write(swVersion)
        io.close(fp)
    end

    if (tonumber(reboot) ~= 0) then
        cmd = cmd .. " -r " .. rebootTime
    end
	if (flags) then
        cmd = cmd .. " " .. flags .. " "
	end

    if (tonumber(background) == 0) then
        cmd = cmd .. " -F "
    end

	cmd = cmd .. "2> /dev/null" 

    firmware.debugPrint("Exec = " .. cmd)

    status = os.execute (cmd)

    if(util.fileExists("/pfrm2.0/DEVICE_REPEATER"))then
        os.execute("/bin/ledctl1 ALL off;/bin/ledctl1 GREEN slowBlink;")
    end

    firmware.debugPrint("STATUS : " .. status)
        if (status ~= 0) then
        --create a file on Firmware upgrade Failure for DC 
        os.execute ("touch /flash/DC_Firm_Upgrade_Failure") 
        os.execute("rm -rf /flash/DC_Firm_Upgrade_Success")
        else
        --create a file on Firmware upgrade success for DC 
        os.execute ("touch /flash/DC_Firm_Upgrade_Success") 
        os.execute("rm -rf /flash/DC_Firm_Upgrade_Failure")
    	os.execute ("rm -rf /flash/smartcable/iptables.sh")
    	os.execute ("rm -rf /flash/smartcable/ota.zip")
    	os.execute ("rm -rf /flash/smartcable/firmware_file_version.txt")
	os.execute ("/bin/rm -rf /flash/ont_dc.conf")
            if( util.fileExists("/pfrm2.0/HW_HG260ES") or util.fileExists("/pfrm2.0/HW_HG260X")) then
                os.execute("/bin/ledctl WLAN off")
                os.execute("/bin/ledctl WPS off")
            end
	firmware.voipCleanUp()
        end

    return status;
end

function firmware.versionUpdate()

    local filep = io.open(firmware.versionFile, "r")
    if (filep == nil) then
        return "ERROR"
    end        

    local swVersion  = filep:read("*l")
    local valid = db.setAttribute ("system", "_ROWID_", "1", "firmwareVer", swVersion)

    filep:close()

    return "OK", valid
end 

--***************************************************************************************************
	--Firmware function to calculate the firmware checksum
--**************************************************************************************************
--@name firmware.firmMd5sumGet()
--
--@description The function will calculate the firmware checksum
--
--@return
 
function firmware.firmMd5sumGet()
	
	--locals
	local  firmMd5Tbl 
	-- opening the file to read the checksum value
    
    local md5sumFilePath = db.getAttribute("environment", "name", "FIRM_MD5_SUM_VALUE", "value")
    if (md5sumFilePath == nil) then
        return "ERROR", "FILE_NOT_FOUND"
    end

    pMd5File = io.open(md5sumFilePath, "r")
    if(pMd5File ~= nil) then
		firmMd5Tbl = pMd5File:read("*line")
        pMd5File:close()
    end

	--return
	return firmMd5Tbl
end

--***************************************************************************************************
--@name  firmware.firmUgradeGet()
--
--@description The function will get the info required by the upgrade
--
--@return

function firmware.firmUgradeGet()

	-- locals 	
	local firmTbl = {}
	local systemTbl = {}
    local rowid = "1"

	-- getting the system table
	-- getting the firmware version
    local firmVersion = db.getAttribute("system", "_ROWID_", rowid , "firmwareVer")
	firmTbl["firmwareVer"] =  firmVersion

    return firmTbl
	
end

--***************************************************************************************************
--@name  firmware.firmUSBUpgradeGet()
--
--@description The function will get the info required by the upgrade from USB
--
--@return

function firmware.firmUSBUpgradeGet()
    
    -- getting the usb connection status
    local firmTbl = {}
    local pFile1 = io.open("/var/usb_status1.txt", "rb")
    if (pFile1 ~= nil) then
        local readFile = pFile1:read("*all")
        local num = tonumber(readFile)
        if (num == 1) then
            -- "1" => USB Connected
            firmTbl["usb_connection_status"] = "1"
        else 
            -- "0" => USB NOT Connected
            firmTbl["usb_connection_status"] = "0"
        end
    else
            -- "0" => USB NOT Connected
        firmTbl["usb_connection_status"] = "0"
    end

    util.appendDebugOut("usb_connection_status: " .. firmTbl["usb_connection_status"] .. "<br>")
    if(pFile1 ~= nil) then
        io.close(pFile1)
    end
 
    local usb_data = {}
    local pFile2 = io.open("/var/usb_filelist1.txt", "rb")

    if (pFile2 ~= nil) then
        -- Calling table.insert call to fill a lua table with the file content.
        for line in pFile2:lines() do
            table.insert(usb_data, line)
        end
    else
        usb_data = {"","",""}
    end

	firmTbl.usb_data = usb_data

    if(pFile2 ~= nil) then
        io.close(pFile2)
    end

    -- return
	return firmTbl
end

function firmware.voipCleanUp()

     os.execute ("touch /tmp/softRebootTrigger")
     if (util.fileExists ("/pfrm2.0/ECONET")) then
     	os.execute ("killall -19 hgw-voice-app")
     else
        os.execute ("/bin/pidof hgw-voice-app |  awk '{print $NF}' | xargs kill -SIGPWR")
     end


     local voipReboot = 0
     local voipCounter = 0
     
     while ( voipReboot == 0 ) do 
	os.execute ("usleep 1000000")
	if (util.fileExists ("/tmp/softRebootTrigger") ~= true or voipCounter >= 4) then 
		voipReboot = 1
	end
	voipCounter = voipCounter + 1
     end
end

--******************************************************************************
--@name firmware.reboot()
--
--@description The function will reboot the router
--
--@return

function firmware.reboot()

	-- locals
	local statusMsg = nil
	local errMsg = nil
     
     firmware.voipCleanUp()
    
     db.setAttribute ("reboot", "reboot._ROWID_", "1", "rebootTime", "10")
     db.setAttribute ("reboot", "reboot._ROWID_", "1", "reboot", "1")
    if( util.fileExists("/pfrm2.0/HW_HG260ES") or util.fileExists("/pfrm2.0/HW_HG260X")) then
        os.execute("/bin/ledctl WLAN off")
        os.execute("/bin/ledctl WPS off")
    end
   
	-- return
	statusMsg = "STATUS_OK"
	errMsg = "OK" 
	return errMsg, statusMsg 

end

--*******************************************************************************
--@name firmware.USBrestore(inputTable)
--
--@description The function will restore the router to the previous setting with
--the file selected from  USB
--
--@return

function firmware.USBrestore(inputTable)

	-- locals
	local statusMsg = nil
	local errMsg = nil

	util.appendDebugOut(util.tableToStringRec(inputTable))
	local file = inputTable["file"]

    local filename = "/tmp/config.cfg"
    os.execute("cp -rf " .. file .. " " .. filename)

    if (config.verifyChecksum (filename) == "ok") then
		-- remove old configuration
		os.execute("rm -f " .. SETTINGS_FILE .. " ")
           
		-- remove tr69 persistent data
		local cfg = db.getAttribute("environment", "name", "TR69_PERSISTENT_STORE", "value")
    	if (cfg ~= nil) then
			os.execute ("rm -Rf " .. cfg)
		end
        -- copy file to flash
        os.execute("mv" .. " " .. filename .. " " .. SETTINGS_FILE)
        return firmware.reboot()
    else
        os.execute("rm -rf" .. " " .. filename)
        statusMsg = "CONFIG_CHECKSUM_FAILURE"
        errMsg = "ERROR"
        return errMsg, statusMsg
    end
end

--*******************************************************************************
--@name firmware.tr69Restore(inputTable, urlFileName)
--
--@description The function will restore the router to the previous setting
--
--@return

function firmware.tr69Restore(inputTable, urlFileName)

    require "kliteLib"

	-- locals
	local statusMsg = nil
	local errMsg = nil

        -- DMS Config Files
        local CONFIG_FILE_NAME = ""
        local DMS_ACCESSCONF_NAME = ""
        local DMS_DESCRIPTION_NAME = ""
        local DMS_ACCESSCONF_FILE = ""
        local DMS_DESCRIPTION_FILE = ""

    if (util.fileExists ("/pfrm2.0/BRCMJCO300") or util.fileExists ("/pfrm2.0/HW_JCO410") or util.fileExists ("/pfrm2.0/HW_JCE410")) then
        -- DMS Config Files
        CONFIG_FILE_NAME = "local.teamf1.cfg.defaults.ascii"
        DMS_ACCESSCONF_NAME = "access_conf.xml"
        DMS_DESCRIPTION_NAME = "dms_descr.xml"
        DMS_ACCESSCONF_FILE = "/flash/dms_xml/access_conf.xml"
        DMS_DESCRIPTION_FILE = "/flash/dms_xml/dms_descr.xml"
    end

    if (util.fileExists ("/pfrm2.0/ECONET") and (not(util.fileExists ("/pfrm2.0/HW_NO_WIFI")))) then
        CONFIG_FILE_NAME = "local.teamf1.cfg.defaults.ascii"
        SMARTHOME_CONF_NAME = "sc.cnf"
        SMARTHOME_CONF_FILE = "/flash/smartcable/config/sc.cnf"
        DMS_ACCESSCONF_NAME = "access_conf.xml"
        DMS_DESCRIPTION_NAME = "dms_descr.xml"        
        DMS_ACCESSCONF_FILE = "/flash/dms_xml/access_conf.xml"
        DMS_DESCRIPTION_FILE = "/flash/dms_xml/dms_descr.xml"        
    end    

	util.appendDebugOut(util.tableToStringRec(inputTable))
	local filesize = inputTable["file.restore"]["filesize"]
	local filename = inputTable["file.restore"]["filename"]
	local filehandle = inputTable["file.restore"]["file"] 

    local modelName = util.fileToString(firmware.prodclassFile)
    if (string.find (urlFileName, modelName) == nil ) then
        return "ERROR", "INVALID_BACKUP_FILE"
    end

    -- Out file path is changed
    -- If this value is changed then please change in platform.lua api as well
    local UPLOAD_DIR = "/tmp/upload/"

    -- check if file is encrypted
        EncryptEnable = "1"

	-- upload settings
    local outFile = "out.cfg"
    local encKey="/pfrm2.0/etc/server.key"

    -- if file is encrypted then decrypt it.
    if(EncryptEnable == "1") then
        kliteLib.openssl ("enc", "-aes-128-cbc", "-d", "-pass", "file:" .. encKey, "-in", filename, "-out", UPLOAD_DIR .. outFile)
		filename = outFile
	end
   
            local tmpConfigFile = ""
            local tmpDMSAccessFile = ""
            local tmpDMSDescrFile = ""
            local cfgFile = ""
            local dmsConfigFile = ""
            local dmsConfig1File = ""
            local file = ""
			local lines = ""
            local flag = 0
			
	if(not(util.fileExists ("/pfrm2.0/HW_NO_DMS"))) then
    if (util.fileExists ("/pfrm2.0/BRCMJCO300") or util.fileExists ("/pfrm2.0/HW_JCO410") or util.fileExists ("/pfrm2.0/HW_JCE410")) then
            -- separate the config and dms config files

            file = UPLOAD_DIR .. filename
            lines = lines_from(file)

            tmpConfigFile = UPLOAD_DIR .. CONFIG_FILE_NAME
            tmpDMSAccessFile = UPLOAD_DIR .. DMS_ACCESSCONF_NAME
            tmpDMSDescrFile = UPLOAD_DIR .. DMS_DESCRIPTION_NAME
            cfgFile = io.open(tmpConfigFile, "a")
            dmsConfigFile = io.open(tmpDMSAccessFile, "a")
            dmsConfig1File = io.open(tmpDMSDescrFile, "a")
    
        -- print all line numbers and their contents
        for k,v in pairs(lines) do
            if (string.find(v,"config%.")) then
                cfgFile:write(v .. "\n")
            end
        
            if (string.find(v,"<")) then
                -- copy content of the access_conf.xml file
                if (flag == 0) then
                    dmsConfigFile:write(v .. "\n")
                    if (string.find(v,"/accessConfigRoot")) then
                        flag = 1
                    end
                -- copy content of the dms_descr.xml file
                else
                    dmsConfig1File:write(v .. "\n")
                end
            end
        end
        
        cfgFile:close()
        dmsConfigFile:close()
        dmsConfig1File:close()
        
        os.execute("mv" .. " " .. UPLOAD_DIR .. CONFIG_FILE_NAME .. " " .. UPLOAD_DIR .. filename)
    end
	end

    if (util.fileExists ("/pfrm2.0/ECONET") and (not(util.fileExists ("/pfrm2.0/HW_NO_WIFI")))) then
            -- separate the config and dms config files
 
            file = UPLOAD_DIR .. filename
            lines = lines_from(file)

            tmpConfigFile = UPLOAD_DIR .. CONFIG_FILE_NAME
            tmpsmartHomeConfFile = UPLOAD_DIR .. SMARTHOME_CONF_NAME
            cfgFile = io.open(tmpConfigFile, "a")
            smartHomeConfigFile = io.open(tmpsmartHomeConfFile, "a")
            tmpDMSAccessFile = UPLOAD_DIR .. DMS_ACCESSCONF_NAME
            tmpDMSDescrFile = UPLOAD_DIR .. DMS_DESCRIPTION_NAME
            dmsConfigFile = io.open(tmpDMSAccessFile, "a")
            dmsConfig1File = io.open(tmpDMSDescrFile, "a")            
            
            -- print all line numbers and their contents
            for k,v in pairs(lines) do
                if (string.find(v,"config%.")) then
                    cfgFile:write(v .. "\n")
                elseif (string.find(v,"<")) then
                    -- copy content of the access_conf.xml file
                    if (flag == 0) then
                        dmsConfigFile:write(v .. "\n")
                        if (string.find(v,"/accessConfigRoot")) then
                            flag = 1
                        end
                    -- copy content of the dms_descr.xml file
                    else
                        dmsConfig1File:write(v .. "\n")
                    end
                else
                   smartHomeConfigFile:write(v .. "\n")
                end
            end    

            cfgFile:close()
            smartHomeConfigFile:close()
            dmsConfigFile:close()
            dmsConfig1File:close()

            os.execute("mv" .. " " .. UPLOAD_DIR .. CONFIG_FILE_NAME .. " " .. UPLOAD_DIR .. filename)
    end
            

        if (config.verifyChecksum (UPLOAD_DIR .. filename) == "ok") then
            local cfgFile = db.getAttribute("environment", "name", "FLASH_CFG_ASCII", "value")
            if(cfgFile == nil or cfgFile == "") then
                cfgFile = "/flash/teamf1.cfg.ascii"
            end
            
            -- remove old configuration
            os.execute("rm -f " .. cfgFile)
            os.execute("rm -f " .. cfgFile..".bkp")
            
            -- remove tr69 persistent data
			local cfg = db.getAttribute("environment", "name", "TR69_PERSISTENT_STORE", "value")
    		if (cfg ~= nil) then
				os.execute ("rm -Rf " .. cfg)
			end
    
			-- copy file to flash
			os.execute("mv" .. " " .. UPLOAD_DIR .. filename .. " " .. cfgFile)

    if (util.fileExists ("/pfrm2.0/BRCMJCO300") or util.fileExists ("/pfrm2.0/HW_JCO410") or util.fileExists ("/pfrm2.0/HW_JCE410")) then
            -- copy dms file to flash
            if (flag == 1) then
                os.execute("mv" .. " " .. tmpDMSAccessFile .. " " .. DMS_ACCESSCONF_FILE)
                os.execute("mv" .. " " .. tmpDMSDescrFile .. " " .. DMS_DESCRIPTION_FILE)
            else
                os.execute ("rm -rf " .. tmpDMSAccessFile .. " " .. tmpDMSDescrFile)
            end
    end

            if (util.fileExists ("/pfrm2.0/ECONET") and (not(util.fileExists ("/pfrm2.0/HW_NO_WIFI")))) then
                os.execute("mv" .. " " .. tmpsmartHomeConfFile .. " " .. SMARTHOME_CONF_FILE)
                -- copy dms file 
                if (flag == 1) then
                    os.execute("mv" .. " " .. tmpDMSAccessFile .. " " .. DMS_ACCESSCONF_FILE)
                    os.execute("mv" .. " " .. tmpDMSDescrFile .. " " .. DMS_DESCRIPTION_FILE)
                else
                    os.execute ("rm -rf " .. tmpDMSAccessFile .. " " .. tmpDMSDescrFile)
                end                
            end        
            os.execute("rm -rf /tmp/FcDef")
            os.execute("rm -rf /flash/FcDef")

			return firmware.reboot()
    
		else
			os.execute("rm -rf" .. " " .. UPLOAD_DIR .. filename)
			statusMsg = "CONFIG_CHECKSUM_FAILURE"
			errMsg = "ERROR"
			return errMsg, statusMsg
		end

end

--*******************************************************************************
--@name firmware.restore(inputTable)
--
--@description The function will restore the router to the previous setting
--
--@return

function firmware.restore(inputTable)

    require "kliteLib"

	-- locals
	local statusMsg = nil
	local errMsg = nil

        -- DMS Config Files
        local CONFIG_FILE_NAME = ""
        local DMS_ACCESSCONF_NAME = ""
        local DMS_DESCRIPTION_NAME = ""
        local DMS_ACCESSCONF_FILE = ""
        local DMS_DESCRIPTION_FILE = ""

    if (util.fileExists ("/pfrm2.0/BRCMJCO300") or util.fileExists ("/pfrm2.0/HW_JCO410") or util.fileExists ("/pfrm2.0/HW_JCE410")) then
        -- DMS Config Files
        CONFIG_FILE_NAME = "local.teamf1.cfg.defaults.ascii"
        DMS_ACCESSCONF_NAME = "access_conf.xml"
        DMS_DESCRIPTION_NAME = "dms_descr.xml"
        DMS_ACCESSCONF_FILE = "/flash/dms_xml/access_conf.xml"
        DMS_DESCRIPTION_FILE = "/flash/dms_xml/dms_descr.xml"
    end

    if (util.fileExists ("/pfrm2.0/ECONET") and (not(util.fileExists ("/pfrm2.0/HW_NO_WIFI")))) then
       CONFIG_FILE_NAME = "local.teamf1.cfg.defaults.ascii"
        SMARTHOME_CONF_NAME = "sc.cnf"
        SMARTHOME_CONF_FILE = "/flash/smartcable/config/sc.cnf"
        DMS_ACCESSCONF_NAME = "access_conf.xml"
        DMS_DESCRIPTION_NAME = "dms_descr.xml"        
        DMS_ACCESSCONF_FILE = "/flash/dms_xml/access_conf.xml"
        DMS_DESCRIPTION_FILE = "/flash/dms_xml/dms_descr.xml"            
    end
    
	util.appendDebugOut(util.tableToStringRec(inputTable))
	local filesize = inputTable["file.restore"]["filesize"]
	local filename = inputTable["file.restore"]["filename"]
	local filehandle = inputTable["file.restore"]["file"] 

    local modelName = util.fileToString(firmware.prodclassFile)
    if (string.find (filename,modelName) == nil ) then
        return "ERROR", "INVALID_BACKUP_FILE"
    end

    -- check if file is encrypted
    if(string.sub(filename,-3,-1) == "enc") then
        EncryptEnable = "1"
    else
	    return "ERROR", "INVALID_BACKUP_FILE"
	end

	-- upload settings
	local filename = cgilua.cookies.get("TeamF1Login")
    local outFile = "out.cfg"
    local encKey="/pfrm2.0/etc/server.key"

    -- if file is encrypted then decrypt it.
    if(EncryptEnable == "1") then
        kliteLib.openssl ("enc", "-aes-128-cbc", "-d", "-pass", "file:" .. encKey, "-in", UPLOAD_DIR .. filename, "-out", UPLOAD_DIR .. outFile)
		filename = outFile
	end

            local tmpConfigFile = ""
            local tmpDMSAccessFile = ""
            local tmpDMSDescrFile = ""
            local cfgFile = ""
            local dmsConfigFile = ""
            local dmsConfig1File = ""
            local file = ""
			local lines = ""
            local flag = 0

	if(not(util.fileExists ("/pfrm2.0/HW_NO_DMS"))) then
    if (util.fileExists ("/pfrm2.0/BRCMJCO300") or util.fileExists ("/pfrm2.0/HW_JCO410") or util.fileExists ("/pfrm2.0/HW_JCE410")) then
            -- separate the config and dms config files

            file = UPLOAD_DIR .. filename
            lines = lines_from(file)

            tmpConfigFile = UPLOAD_DIR .. CONFIG_FILE_NAME
            tmpDMSAccessFile = UPLOAD_DIR .. DMS_ACCESSCONF_NAME
            tmpDMSDescrFile = UPLOAD_DIR .. DMS_DESCRIPTION_NAME
            cfgFile = io.open(tmpConfigFile, "a")
            dmsConfigFile = io.open(tmpDMSAccessFile, "a")
            dmsConfig1File = io.open(tmpDMSDescrFile, "a")
            
            -- print all line numbers and their contents
            for k,v in pairs(lines) do
                if (string.find(v,"config%.")) then
                    cfgFile:write(v .. "\n")
                end

             if (string.find(v,"<")) then
                -- copy content of the access_conf.xml file
                if (flag == 0) then
                    dmsConfigFile:write(v .. "\n")
                    if (string.find(v,"/accessConfigRoot")) then
                        flag = 1
                    end
                -- copy content of the dms_descr.xml file
                    else
                        dmsConfig1File:write(v .. "\n")
                    end
              end
          end

            cfgFile:close()
            dmsConfigFile:close()
            dmsConfig1File:close()

            os.execute("mv" .. " " .. UPLOAD_DIR .. CONFIG_FILE_NAME .. " " .. UPLOAD_DIR .. filename)
    end
	end

    if (util.fileExists ("/pfrm2.0/ECONET") and (not(util.fileExists ("/pfrm2.0/HW_NO_WIFI")))) then
            -- separate the config and dms config files
 
            file = UPLOAD_DIR .. filename
            lines = lines_from(file)

            tmpConfigFile = UPLOAD_DIR .. CONFIG_FILE_NAME
            tmpsmartHomeConfFile = UPLOAD_DIR .. SMARTHOME_CONF_NAME
            cfgFile = io.open(tmpConfigFile, "a")
            smartHomeConfigFile = io.open(tmpsmartHomeConfFile, "a")
            tmpDMSAccessFile = UPLOAD_DIR .. DMS_ACCESSCONF_NAME
            tmpDMSDescrFile = UPLOAD_DIR .. DMS_DESCRIPTION_NAME
            dmsConfigFile = io.open(tmpDMSAccessFile, "a")
            dmsConfig1File = io.open(tmpDMSDescrFile, "a")            
            
            -- print all line numbers and their contents
            for k,v in pairs(lines) do
                if (string.find(v,"config%.")) then
                    cfgFile:write(v .. "\n")
                elseif (string.find(v,"<")) then
                    -- copy content of the access_conf.xml file
                    if (flag == 0) then
                        dmsConfigFile:write(v .. "\n")
                        if (string.find(v,"/accessConfigRoot")) then
                            flag = 1
                        end
                    -- copy content of the dms_descr.xml file
                    else
                        dmsConfig1File:write(v .. "\n")
                    end
                else
                   smartHomeConfigFile:write(v .. "\n")
                end
            end    

            cfgFile:close()
            smartHomeConfigFile:close()
            dmsConfigFile:close()
            dmsConfig1File:close()

            os.execute("mv" .. " " .. UPLOAD_DIR .. CONFIG_FILE_NAME .. " " .. UPLOAD_DIR .. filename)
    end    
		if (config.verifyChecksum (UPLOAD_DIR .. filename) == "ok") then
			-- remove old configuration
			os.execute("rm -f " .. SETTINGS_FILE .. " ")
			os.execute("rm -f " .. SETTINGS_FILE .. ".bkp")
            
			-- remove tr69 persistent data
			local cfg = db.getAttribute("environment", "name", "TR69_PERSISTENT_STORE", "value")
    		if (cfg ~= nil) then
				os.execute ("rm -Rf " .. cfg)
			end
    
            -- copy file to flash
            os.execute("mv" .. " " .. UPLOAD_DIR .. filename .. " " .. SETTINGS_FILE)
			
    if (util.fileExists ("/pfrm2.0/BRCMJCO300") or util.fileExists ("/pfrm2.0/HW_JCO410") or util.fileExists ("/pfrm2.0/HW_JCE410")) then
            -- copy dms file to flash
            if (flag == 1) then
                os.execute("mv" .. " " .. tmpDMSAccessFile .. " " .. DMS_ACCESSCONF_FILE)
                os.execute("mv" .. " " .. tmpDMSDescrFile .. " " .. DMS_DESCRIPTION_FILE)
            else
                os.execute ("rm -rf " .. tmpDMSAccessFile .. " " .. tmpDMSDescrFile)
            end
    end

            if (util.fileExists ("/pfrm2.0/ECONET") and (not(util.fileExists ("/pfrm2.0/HW_NO_WIFI")))) then
                os.execute("mv" .. " " .. tmpsmartHomeConfFile .. " " .. SMARTHOME_CONF_FILE)
                -- copy dms file 
                if (flag == 1) then
                    os.execute("mv" .. " " .. tmpDMSAccessFile .. " " .. DMS_ACCESSCONF_FILE)
                    os.execute("mv" .. " " .. tmpDMSDescrFile .. " " .. DMS_DESCRIPTION_FILE)
                else
                    os.execute ("rm -rf " .. tmpDMSAccessFile .. " " .. tmpDMSDescrFile)
                end                
            end       

            return firmware.reboot()
        else
            os.execute("rm -rf" .. " " .. UPLOAD_DIR .. filename)
			statusMsg = "CONFIG_CHECKSUM_FAILURE"
			errMsg = "ERROR"
			return errMsg, statusMsg
		end

end

--********************************************************************************
--@name firmware.factoryResetOSGi()
--
--@description The function will remove the jar files 
--
--@return

function firmware.factoryResetOSGi()

    -- include
    require "teamf1lualib/osgi"

    -- remove the jar files.
    local osgiTbl = db.getTable ("osgiApps", false)
    if (osgiTbl == nil) then
        return "ERROR", "OSGI_UNINSTALL_FAILED"
    end
    
    -- uninstall all the application on factory reset.
    for k,v in pairs (osgiTbl) do
        osgi.factoryUninstall (v["appId"]) 
    end

    return "OK", "STATUS_OK"
end
    
--********************************************************************************
--@name firmware.factoryReset()
--
--@description The function will factory reset the router
--
--@return

function firmware.factoryReset(X)
    
    if(X == 1) then
        -- set the red LED to slow blinking
        os.execute ("/bin/sh /pfrm2.0/bin/factoryResetIndicator.sh")
    end
    
    if(util.fileExists("/pfrm2.0/DEVICE_REPEATER"))then
        os.execute("/bin/touch /tmp/factoryResetOn")
    end

    --[[ commenting out following part since OSGi has been exckuded from the
    --builds for now ]]--

    -- remove the jar files.
--    status, errMsg = firmware.factoryResetOSGi ()

	-- remove the flash configuration file
	local cfg = db.getAttribute("environment", "name", "FLASH_CFG_ASCII", "value")
	if (cfg ~= nil) then
		os.execute ("/bin/rm -f " .. cfg)
	end
	-- remove the backup flash configuration file
    local cfgBackup = db.getAttribute("environment", "name", "FLASH_BACKUP_CFG_ASCII", "value")
	if (cfgBackup ~= nil) then
		os.execute ("/bin/rm -f " .. cfgBackup)
	end
	-- remove tr69 persistent data
	local cfg = db.getAttribute("environment", "name", "TR69_PERSISTENT_STORE", "value")
	if (cfg ~= nil) then
		os.execute ("/bin/rm -Rf " .. cfg)
	end
   
    -- remove https certificates
    os.execute ("/bin/rm -Rf /flash/https*")
    os.execute ("/bin/rm -Rf /flash/TLSCERT")

	-- remove omci xml data 
	os.execute ("/bin/rm -rf /flash/omci_xml/xml_params")
	os.execute ("/bin/rm -rf /flash/omci_xml/xml_commands")

    if(util.fileExists("/pfrm2.0/DEVICE_REPEATER")) then
        os.execute ("/bin/rm -rf /flash/JMA24_CAP_MODE")
        os.execute("/bin/touch /flash/JMA24_AGENT_MODE")
    end
	if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then
		-- remove AGENT_CONNECTED file for ont-dc for BRCM new devices
		os.execute ("/bin/rm -rf /flash/AGENT_CONNECTED")
	end

if (util.fileExists ("/pfrm2.0/BRCMJCO300") or util.fileExists ("/pfrm2.0/HW_JCO410") or util.fileExists ("/pfrm2.0/HW_JCE410")) then	
	
    -- remove .dat files for JUICE
	os.execute ("/bin/rm -rf /flash/juice/FixedVoiceCCS.dat")
	os.execute ("/bin/rm -rf /flash/juice/FixedVoiceCcsXML.dat")
	os.execute ("/bin/rm -rf /flash/juice/WhitelistData.dat")
    os.execute ("/bin/rm -rf /flash/juice/PushlistData.dat")
    
    -- remove xml files for DMS
	os.execute ("/bin/rm -rf /flash/dms_xml")
	os.execute ("/bin/rm -rf /flash/ras_xml")		
	os.execute ("/bin/rm -rf /flash/twine")
	
        -- remove config files for JHV
	os.execute ("/bin/rm -rf /flash/hgw-db")	
	os.execute ("/bin/rm -rf /flash/config.xml")	
else
	-- remove sml files for DMS
	os.execute ("/bin/rm -rf /flash/xml")	
end
	os.execute ("/bin/rm -rf /flash/connectionSucceeded")	

    -- remove third party param file
    os.execute("/bin/rm -rf /flash/thirdparty/thirdparty.param")

	-- create file on factory default
	os.execute ("touch /flash/factoryreset.txt")
	os.execute ("touch /flash/factoryreset_ascii.txt")

	-- create file on factory default for GUI redirection
	os.execute ("touch /flash/FcDef")

	firmware.voipCleanUp()
         
    --Mesh as Default Feature in JCO4032
    if (util.fileExists ("/pfrm2.0/MESH_ENABLED")) then
	    os.execute ("touch /flash/MESH_ENABLED")
    end   
    --Mesh as Default Feature in JCOW401
    if (util.fileExists ("/pfrm2.0/BRCM_MESH_ENABLED")) then
	    os.execute ("touch /flash/BRCM_MESH_ENABLED")
    end   
   -- unmount disks
	if(X == 1) then
   		-- send a signal to reboot
    	db.setAttribute ("reboot", "reboot._ROWID_", "1", "rebootTime", "2")
		db.setAttribute ("reboot", "reboot._ROWID_", "1", "reboot", "1")
	else
		return "OK", "STATUS_OK"
	end
    if (util.fileExists ("/pfrm2.0/HW_JCO4032") or util.fileExists ("/pfrm2.0/HW_JCOW407") or util.fileExists ("/pfrm2.0/HW_JCOW402")) then
    -- remove xml files for DMS
	os.execute ("/bin/rm -rf /flash/dms_xml")
	os.execute ("/bin/rm -rf /flash/ras_xml")		
	os.execute ("/bin/rm -rf /flash/twine")
	
    -- remove .dat files for JUICE
	os.execute ("/bin/rm -rf /flash/juice/FixedVoiceCCS.dat")
	os.execute ("/bin/rm -rf /flash/juice/FixedVoiceCcsXML.dat")
	os.execute ("/bin/rm -rf /flash/juice/WhitelistData.dat")
	os.execute ("/bin/rm -rf /flash/juice/PushlistData.dat")
	os.execute ("/bin/rm -rf /flash/juice/FixedVoiceFLN.dat.bkp")
	os.execute ("/bin/rm -rf /flash/juice/FixedVoiceFQDN.dat.bkp")
	os.execute ("/bin/rm -rf /flash/juice/JfvSvcConfig.xml")

	os.execute ("/bin/rm -rf /flash/ont_dc.conf")
	os.execute ("/bin/rm -rf /flash/AGENT_CONNECTED")
	os.execute ("/bin/touch /flash/FactoryResetMeshOn")
    end
    if (util.fileExists ("/pfrm2.0/HW_JCOW401") or util.fileExists ("/pfrm2.0/HW_JCOW403")) then                                       
        -- remove .dat files for JUICE                                                              
        os.execute ("/bin/rm -rf /flash/juice/FixedVoiceCCS.dat")
	os.execute ("/bin/rm -rf /flash/juice/FixedVoiceCcsXML.dat")
	os.execute ("/bin/rm -rf /flash/juice/WhitelistData.dat")
	os.execute ("/bin/rm -rf /flash/juice/PushlistData.dat")
	os.execute ("/bin/rm -rf /flash/juice/FixedVoiceFLN.dat.bkp")
	os.execute ("/bin/rm -rf /flash/juice/FixedVoiceFQDN.dat.bkp")
	os.execute ("/bin/rm -rf /flash/juice/JfvSvcConfig.xml")
    end
    --create file on factory reset for DC
    os.execute ("touch /flash/DC_Factory_Reset") 
    if( util.fileExists("/pfrm2.0/HW_HG260ES") or util.fileExists("/pfrm2.0/HW_HG260X")) then
        os.execute("/bin/ledctl WLAN off")
        os.execute("/bin/ledctl WPS off")
    end
	-- copying ont_dc config files
	os.execute ("/bin/cp -rf /pfrm2.0/etc/ont_dc.conf_default /pfrm2.0/etc/ont_dc.conf")	
	statusMsg = "STATUS_OK"
	errMsg = "OK"

	return errMsg ,statusMsg
end

--********************************************************************************
--@name firmware.scan()
--
-- @description  
--
-- This function will scan the directory for TeamF1 firmware images
-- it expects all the images are in the given directory. Nested directories are
-- not supported by u-boot and hence not scanned here.
--
--@return

function firmware.scan(path)
    require "lfs"
    local index = 1
    local firmTbl = {}

    if (path == nil) then
        return nil        
    end        
        
    for file in lfs.dir(path) do
         if ((file ~= ".") or (file ~= "..")) then
             local f = path..'/'..file
             local attr = lfs.attributes (f)
             if (attr ~= nil) then
                 local hdr = firmLib.hdrGet(f)
                 if (hdr ~= nil) then
                     firmTbl[index] = {}
                     firmTbl[index] = hdr
                     index = index + 1
                 end                 
             end
         end
    end        

    return firmTbl
end

--***************************************************************************************************
	--END
--****************************************************************************************************

function firmware.import (configTable, defaultConfigTable)

    if (configTable == nil) then
        configTable = defaultConfigTable
    end

    local table={}
    table["firmUpdateUserConfig.updateType"] = configTable.updateType
    db.insert ("firmUpdateUserConfig", table)

    local sysCfg = db.getRowWhere("firmUpdateSystemConfig", "_ROWID_=1", true)
    if ((configTable.url ~= nil) and (string.len(configTable.url) > 0)) then
    	sysCfg["firmUpdateSystemConfig.url"] = configTable.url
	    db.update("firmUpdateSystemConfig", sysCfg, sysCfg["firmUpdateSystemConfig._ROWID_"])
    end

    table = util.addPrefix (configTable, "firmUpdateStatus.")
    db.insert ("firmUpdateStatus", table)

    -- firmware version update
	-- removed the call to update version as it is being updated via firmwareInit
    -- firmware.versionUpdate()
end

function firmware.export ()
	local firmCfg = {}

    local userConfig = db.getTable ("firmUpdateUserConfig", false)
	if ((userConfig ~= nil) and (userConfig[1] ~= nil)) then
	    firmCfg.updateType = userConfig[1].updateType
	end

    local statusTbl = db.getTable ("firmUpdateStatus", false)
	if ((statusTbl ~= nil) and (statusTbl[1] ~= nil)) then
		firmCfg.version = statusTbl[1].version
		firmCfg.checkedTime = statusTbl[1].checkedTime
		firmCfg.downloaded = statusTbl[1].downloaded
	end
	
	-- export system configuration
    local sysCfg = db.getTable ("firmUpdateSystemConfig", false)
	if (sysCfg ~= nil) then
		firmCfg.url = sysCfg[1].url
		if (firmCfg.downloaded == "1") then
			-- export downloaded as 0 if downloaded firmware is not persistent.
	        if (sysCfg[1].persist == "0") then
		        firmCfg.downloaded = "0"
			end
	    end
	end

    return firmCfg
end

if (config.register) then
   config.register("firmware", firmware.import, firmware.export, "1")
end
