--[[
#### Su"", Jaya Krishna
#### TeamF1
#### www.TeamF1.com
#### May 22, 2008
#### Saurabh Sen
#### Nov 05, 2008
#### File: validations.lua
#### Description: Functions for validation of values
]]--

--************* Package *************
validations = {}

local domainNameExt = {'.com', '.net', '.aero', '.asia', '.cat', '.jobs', '.org', '.biz', '.coop', '.info', '.museum', '.name', '.pro', '.tel', '.travel', '.edu', '.gov', '.int', '.mil', '.mobi', '.ac', '.ad', '.ae', '.af', '.ag', '.ai', '.al', '.am', '.an', '.ao', '.aq', '.ar', '.as', '.at', '.au', '.aw', '.ax', '.az', '.ba', '.bb', '.bd', '.be', '.bf', '.bg', '.bh', '.bi', '.bj', '.bm', '.bn', '.bo', '.br', '.bs', '.bt', '.bv', '.bw', '.by', '.bz', '.ca', '.cc', '.cd', '.cf', '.cg', '.ch', '.ci', '.ck', '.cl', '.cm', '.cn', '.co', '.cr', '.cu', '.cv', '.cx', '.cy', '.cz', '.de', '.dj', '.dk', '.dm', '.do', '.dz', '.ec', '.ee', '.eg', '.er', '.es', '.et', '.eu', '.fi', '.fj', '.fk', '.fm', '.fo', '.fr', '.ga', '.gb', '.gd', '.ge', '.gf', '.gg', '.gh', '.gi', '.gl', '.gm', '.gn', '.gp', '.gq', '.gr', '.gs', '.gt', '.gu', '.gw', '.gy', '.hk', '.hm', '.hn', '.hr', '.ht', '.hu', '.id', '.ie', '.il', '.im', '.in', '.io', '.iq', '.ir', '.is', '.it', '.je', '.jm', '.jo', '.jp', '.ke', '.kg', '.kh', '.ki', '.km', '.kn', '.kp', '.kr', '.kw', '.ky', '.kz', '.la', '.lb', '.lc', '.li', '.lk', '.lr', '.ls', '.lt', '.lu', '.lv', '.ly', '.ma', '.mc', '.md', '.me', '.mg', '.mh', '.mk', '.ml', '.mm', '.mn', '.mo', '.mp', '.mq', '.mr', '.ms', '.mt', '.mu', '.mv', '.mw', '.mx', '.my', '.mz', '.na', '.nc', '.ne', '.nf', '.ng', '.ni', '.nl', '.no', '.np', '.nr', '.nu', '.nz', '.om', '.pa', '.pe', '.pf', '.pg', '.ph', '.pk', '.pl', '.pm', '.pn', '.pr', '.ps', '.pt', '.pw', '.py', '.qa', '.re', '.ro', '.rw', '.ru', '.sa', '.sb', '.sc', '.sd', '.se', '.sg', '.sh', '.si', '.sj', '.sk', '.sl', '.sm', '.sn', '.so', '.sr', '.st', '.sv', '.sy', '.sz', '.tc', '.td', '.tf', '.tg', '.th', '.tj', '.tk', '.tm', '.tn', '.to', '.tp', '.tr', '.tt', '.tv', '.tw', '.tz', '.ua', '.ug', '.uk', '.um', '.us', '.uy', '.uz', '.va', '.vc', '.ve', '.vg', '.vi', '.vn', '.vu', '.ws', '.wf', '.ye', '.yt', '.yu', '.za', '.zm', '.zw'}

--************* Functions *************


-- Check whether the length of the string lies in range or not
-- args : minvalue, maxvalue & string to be checked, field
-- returns : flag = 0 ( no error ), 1 ( error), error message
function validations.checkStringLength(min,max,value,field)
   min = tonumber(min)
   max = tonumber(max)
   if (value == "") then
       return "ERROR", "ERR_EMPTY_VALUE_ENTERED", field, ""
   end
   if ((string.len(value) >= min) and (string.len(value) <= max)) then
      return "OK","",field,""
   else
      return "ERROR","ERR_STRING_LENGTH", field ,""
   end
end


-- Check whether ip1 is <= ip2
-- args : ipaddress1, ipaddress2, field
-- returns : flag = 0 ( no error ), 1 ( error), error message
function validations.ipRangeValidate(ip1,ip2,field)
    flag ,statusCode = validations.ipAddressValidate(ip1,"",field)
    if(flag == "OK" or flag ==0) then
    	flag,statusCode = validations.ipAddressValidate(ip2,"",field)
    end
    if(flag == "OK" or flag ==0) then
	    ipTable1 = validations.split(ip1,".")
	    ipTable2 = validations.split(ip2,".")
	    local count =0
		for i,j in pairs (ipTable1) do
	       if ((tonumber(ipTable1[i]) == (tonumber(ipTable2[i]))))then
	         count = (count + 1)
	      end
	      if (tonumber(ipTable1[i]) < tonumber(ipTable2[i])) then
	         return 0,"",field,""
	      end
	      if (tonumber(ipTable1[i]) > tonumber(ipTable2[i])) then
	         return 1,"ERR_START_IP_GREATER",field,""
	      end
	   end
	   if (count ==4) then
	      return 0,"",field,""
	   end
	end
	return flag, statusCode, field, ""
end


-- Check whether the passwords are same or not
-- args : the passwords to be checked value1, value2
-- returns : flag = 0 ( no error ), 1 ( error), error message
function validations.passwordMatch(value1,value2,field)
   if ( value1 == "" or value2 == "") then
      return 1,"ERR_PASSWORD_EMPTY" ,field		-- Password field cannot be empty. Enter password"
   end
   if (value1 == value2) then
      return 0,""
   else
      return 1,"ERR_PASSWORD_MISMATCH",field		-- Password fields do not match. Re enter password"
   end
end


-- Split the argument on delimiter = div
-- function already implemented in util.lua
-- returns : array containing values
function validations.split (str, div)
    if (div=='') then return false end
    local pos,arr = 0,{}
    for st,sp in function() return string.find(str,div,pos,true) end do
	    table.insert(arr,string.sub(str,pos,st-1))
	    pos = sp + 1
    end
    table.insert(arr,string.sub(str,pos))
    return arr
end

function validations.split1 (str1, div1)
    if (div1=='') then return false end
    local pos1,arr1 = 0,{}
    for st1,sp1 in function() return string.find(str1,div1,pos1,true) end do
	    table.insert(arr1,string.sub(str1,pos1,st1-1))
	    pos1 = sp1 + 1
    end
    table.insert(arr1,string.sub(str1,pos1))
    return arr1
end


-- To validate a given value in a range
-- args : minimum, maximum , value to be evaluated - value 2 for port validations (eg: value1 < value 2),field
-- returns : flag = 0  (no error), 1 (error), error message , type of error
function validations.rangeValidate(min,max,value1,value2,field)

   local flag = 0
   local errMsg = "OK"
   local val = 0
   if (value1 == nil or value1 == "") then
       return "ERROR", "ERR_EMPTY_VALUE_ENTERED",field
   elseif (validations.hasTypeValidate(value1,"%a%s") == 1) then
       return 1, "INVALID_VALUE_ERR_ALPHABET",field,""
   elseif (validations.hasTypeValidate(value1,"%p") == 1) then
       return "ERROR", "INVALID_VALUE_ERR_SPCLCHAR",field,""
   end

   value1 = tonumber(value1)
   if(value2 ~= "") then
		if (validations.hasTypeValidate(value2,"%a%s") == 1) then
			return "ERROR", "INVALID_VALUE_ERR_ALPHABET",field,""
		elseif (validations.hasTypeValidate(value2,"%p") == 1) then
          return "ERROR", "INVALID_VALUE_ERR_SPCLCHAR",field,""
		end
		value2 = tonumber(value2)
		if ((value1 > max) or (value1 < min)) then
          return 1, "ERR_BOUND_1",field,""
		elseif ((value2 > max) or (value2 < min)) then
          return 1, "ERR_BOUND_2" ,field,""
		elseif ((value1 > value2)) then
          return 1 , "ERR_START_GREATER_THAN_END",field,""
		else
          flag = 0,"","",field,""
       end
   else
		
		if((value1 > max) or (value1 < min)) then
          return "ERROR", "ERR_BOUND_INVALID_RANGE",field,""
		else
          flag = "OK"
          errMsg = "OK"
		end
    end
    return flag, errMsg,field,""
end


-- Pattern Matching with type
-- args : value , type of matchig (eg: %s = space, %a = alphabets, %p = special characters)
-- except = non matching the special character
-- count =  number of times type should be presents
-- returns error flag = 0  (no error), 1 (error)
function validations.hasTypeValidate(value,regexp,except,count)
    local num=0
    local flag = 0
    if (value == nil) then
       return 1, "ERR_EMPTY_VALUE_ENTERED"
    end
    if (except ~= nil) then
       for k,v in string.gfind(value,"["..regexp.."]") do
          if(k~=except) then
            flag = 1
          else
            num = num +1
          end
       end
       if (num ~= count and count ~= nil) then
          flag = 1
       end
    else
       if(string.find(value,"["..regexp.."]")) then
          flag = 1
       else
          flag = 0
       end
    end
    return flag
end


-- determines the class of the IP address
-- args : octet1 of IP Address
-- returns : class = A,B or C, X for not defined
function validations.ipClassType(value,field)
    if (value == nil) then
       return 1, "ERR_EMPTY_VALUE_ENTERED",field
    end
    local class = ""
    if ((value >= 0) and (value <= 127)) then
       class = 'A'
       elseif ((value >=128) and (value <= 191)) then
          class = 'B'
       elseif ((value >= 192) and (value <= 223)) then
          class = 'C'
       elseif ((value >= 224) and (value <= 239)) then
          class = 'D'
       elseif ((value >= 240) and (value <= 255)) then
          class = 'E'
    else
       class = 'X'
    end
    return class
end


-- Checks for the set of values a subnet can hold
-- args : octets
-- returns : flag = 0  (no error), 1 (error), error message
function validations.checkSubnetOctetValues(octet,field)
    local flag = 0
    for i,j in pairs(octet) do
       if (octet[i] == '') then
          return 1,"INVALID_SUBNET_EMPTY_OCTET_"..i,field
       end
       octet[i] = tonumber(octet[i])
       if((octet[i] == 0) or (octet[i] ==  128) or (octet[i] == 192) or (octet[i] == 224) or (octet[i] == 240) or (octet[i] == 248) or (octet[i] == 252) or (octet[i] == 254) or (octet[i] == 255 )) then
          flag = 0
       else
          flag = 1
          return flag,"ERR_INVALIDSUBNET_OCTET_"..i,field
       end
    end
   return 0,"",field
end


-- Compares 2 values
-- args : values to be compared
-- returns : 0 or 1
function validations.isEqual(value1,value2)
    local flag = 0
    if (value1 == value2) then
       return 1
    else
       return 0
    end
end
-- Checks for the suitable values for the subnet based on the IPv4
-- args : octet1 of IP address and the subnet as array
-- returns : flag = 0  (no error), 1 (error), error message
function validations.subnetCheck(value,snet,field)
   for i,j in pairs (snet) do
       snet[i] = tonumber(snet[i])
    end
    if ((snet[1] ~=255)) then
       return 1 , "INVALID_SUBNET_ERR1_OCTET_1",field -- ERR1 = Octet1 should be 255
	else
       class = validations.ipClassType(value,field)
       if (class =='A') then
          if (validations.isEqual(snet[2],255) ~=1) then
                if(validations.isEqual(snet[3],0) ~=1) then
                   return 1 , "INVALID_SUBNET_ERR4_OCTET_3",field -- ERR4 = Octet 3 should be 0
                end
                if(validations.isEqual(snet[4],0) ~=1) then
                   return 1 , "INVALID_SUBNET_ERR5_OCTET_4",field -- ERR5 = Octet 4 should be 0
                end
          else
             if (validations.isEqual(snet[3],255) ~=1) then
                if(validations.isEqual(snet[4],0) ~=1) then
                   return 1 , "INVALID_SUBNET_ERR5_OCTET_4",field -- ERR5 = Octet 4 should be 0
                end
             end
          end

       elseif (class == 'B') then

          if (validations.isEqual(snet[2],255) ~= 1) then
             return 1 , "INVALID_SUBNET_ERR6_OCTET_2",field -- ERR6 = Octet 2 should be 255 for Class B
          end
          if (validations.isEqual(snet[3] ,255) ~= 1) then
             if (validations.isEqual(snet[4],0) ~=1) then
                return 1 , "INVALID_SUBNET_ERR5_OCTET_4",field -- ERR5 = Octet 4 should be 0
             end
          end
       elseif (class == 'C') then
             if (validations.isEqual(snet[2],255) ~= 1) then
                return 1 , "INVALID_SUBNET_ERR7_OCTET_2",field -- ERR7 = Octet 2 should be 255 for Class C
             end
             if (validations.isEqual(snet[3],255) ~= 1) then
                return 1 , "INVALID_SUBNET_ERR8_OCTET_3",field -- ERR8 = Octet 3 should be 255 for Class C
             end
       else
             return 1 , "INVALID_IPCLASS_ERR9",field -- ERR9 = IP Class not valid
       end
    end
    return 0,"",field
end


-- Validates IPv4 & Subnet mask
-- args : ipaddress & subnet mask
-- returns : flag = 0  (no error), 1 (error), error message
function validations.ipAddressValidate(ip,subnet,field,skipVar)

    local statusFlag= 0
    local errMsg = ""
    local num = 0
    --skip validation under two caes.1.no input from page(i.e field is disabled) 2.If input is present but optional(eg. seconadry DNS IP)
    if((ip == ""  and skipVar == "skip") or ip == nil ) then
    	return "OK","OK",field,""
    end
    -- Checking loop back address as invalid 
	 if (ip == "127.0.0.1") then
	    return 1,"IP Address cannot have loop back address",field,""
    end
    ipTable = validations.split(ip,".")
    if( #(ipTable) ~= 4) then
   		return 1,"INVALID_IP_CHECK_NUMBER_OCTETS",field,""
   	end
    if (validations.hasTypeValidate(ip,"%a%s") == 1) then
       return 1, "INVALID_IP_ERR_ALPHABET",field,""
    elseif (validations.hasTypeValidate(ip,"%p",".",3) == 1) then
       return 1, "INVALID_IP_ERR_SPCLCHAR",field,""
    else

       for v,k in pairs(ipTable) do
          if (ipTable[v] == '') then
             return 1,"INVALID_IP_EMPTY_OCTET_"..v,field,""
          elseif (v == 1) then
             statusFlag,errMsg = validations.rangeValidate(1,223,tonumber(ipTable[v]),"")
             if(statusFlag=="ERROR") then
                return statusFlag,"INVALID_IP_OCTET_"..v,field,""
             end
           elseif (v == 4) then
             statusFlag,errMsg = validations.rangeValidate(0,254,tonumber(ipTable[v]),"")
             if(statusFlag=="ERROR") then
                return statusFlag,"INVALID_IP_OCTET_"..v,field,""
             end
          else
             statusFlag,errMsg = validations.rangeValidate(0,255,tonumber(ipTable[v]),"")
             if(statusFlag=="ERROR") then

                return statusFlag,"INVALID_IP_OCTET_"..v,field,""
             end
          end
       end
    end
    if (subnet ~= "" ) then
       if (validations.hasTypeValidate(subnet,"%a%s") == 1) then
          return 1, "INVALID_SUBNET_ERR_ALPHABET",field,""
       elseif (validations.hasTypeValidate(subnet,"%p",".",3) == 1) then
          return 1, "INVALID_SUBNET_ERR_SPCLCHAR",field,""
       else
          subnetTable = validations.split(subnet,".")
          flag,errMsg,field = validations.checkSubnetOctetValues(subnetTable,field)
          if (flag ==1 ) then
             return flag,errMsg,field,""
          end
          flag, errMsg,field= validations.subnetCheck(tonumber(ipTable[1]),subnetTable,field)
          if (flag ==1 ) then
             return flag,errMsg,field,""
          end
       end
    end
    return statusFlag, errMsg,field,""
end


-- validates MAC Address
-- args : macaddress (as string)
-- returns : flag = 0  (no error), 1 (error), error message
function validations.macAddressValidate(mac,field)
    local flag = 0
    local errMsg = ""
    macTable = validations.split(mac,":")
    if( #(macTable) ~= 6 ) then
    	return "ERROR", "ERROR_MAC_NUMBER_OF_OCTETS", field ,""
    end
    flag = validations.hasTypeValidate(mac,"%s%p",":",5)
    if(flag ==1) then
       return 1, "INVALID_MAC_ERR_SPCLCHAR",field, ""
    elseif (flag == 0) then
       
       for k,v in pairs(macTable) do
           if(macTable[k] == nil or macTable[k] == "") then

               return 1, "ERR_MAC_EMPTY_VALUE_OCTET_"..k,field,""

          elseif(string.len(macTable[k]) ~= 2) then
             return 1, "ERR_TWOCHAR_OCTET_"..k,field, ""
          else
             if(validations.hasTypeValidate(macTable[k],"g-z")==1) then
                return 1, "ERR_ONLYHEX_OCTET_"..k,field, ""
             else
                flag = 0
             end
          end
       end
    end
    return flag , errMsg,field,""
end


-- validates lease time
-- args : leaseTime (as string)
-- returns : flag = 0  (no error), 1 (error), error message
function validations.leaseTimeValidate(leaseTime, field) --1, 262800
    local flag = 0
    if(leaseTime == "") then
       return 1, "ERR_LEASETIME_EMPTY_VALUE",field,""
    end
    if (validations.hasTypeValidate(leaseTime,"%a%s") == 1) then
       return 1, "INVALID_LEASETIME_ERR_ALPHA",field,""
    elseif (validations.hasTypeValidate(leaseTime,"%p") == 1) then
       return 1, "INVALID_LEASETIME_ERR_SPCLCHAR",field,""
    else
       leaseTime  = tonumber (leaseTime)
       flag , errMsg = validations.rangeValidate(1,262800,leaseTime,"",field)
       if (flag ==1 or flag == "ERROR") then
          return 1, "ERR_LEASETIME_INVALIDRANGEVALUE",field,""
       end
    end
    return flag, errMsg, field, ""
end


-- validates MTU on wan configuration pages
-- args : mtu,connection type
-- returns : flag = 0  (no error), 1 (error), error message
function validations.mtuValidate(mtu,conType,field)
    local flag = "OK"
    local errMag = ""
    if(mtu == "") then
       return "ERROR", "ERR_MTU_EMPTY_VALUE",field,""
    end
    if (validations.hasTypeValidate(mtu,"%a%s") == 1) then
       return "ERROR", "INVALID_MTUSIZE_ERR_ALPHA",field,""
    elseif (validations.hasTypeValidate(mtu,"%p") == 1) then
       return "ERROR", "INVALID_MTUSIZE_ERR_SPCLCHAR",field,""
    end
    if (conType == "noLogin") then
       flag , errMsg = validations.rangeValidate(1200,1500,tonumber(mtu),"","")
    elseif (conType == "login" ) then
    	flag , errMsg = validations.rangeValidate(1200,1496,tonumber(mtu),"","")
	end
	 if (flag ==1 or flag == "ERROR") then
       return "ERROR", "ERR_MTUSIZE_INVALIDRANGEVALUE",field,""
    end

    return flag, errMsg,field,""
end

-- Join table of parts with divider and return string.
function validations.join (intable, div)
    if (not intable) then return "" end
    local str = {}
    -- make string
    for k, v in pairs (intable) do
    	if (k >= 2) then
			str = str .. div .. v
		else
			str = v
		end
  	end
  	return str
end


-- validates port range
-- args : port 1,  port 2 (as strings)
-- returns : flag = 0  (no error), 1 (error), error message
function validations.portRangeValidate(min,max,port1,port2,field)
    local flag = "OK"
    if(port1 == "") then
       return "ERROR", "ERR_PORT_EMPTY_VALUE",field,""
    end
    if (validations.hasTypeValidate(port1,"%a%s") == 1) then
       return 1, "INVALID_PORT1_ERR_ALPHA",field,""
    elseif (validations.hasTypeValidate(port1,"%p") == 1) then
       return "ERROR", "INVALID_PORT1_ERR_SPCLCHAR",field,""
    end
    if(port2 ~= "") then
    	if (validations.hasTypeValidate(port2,"%a%s") == 1) then
       	    return "ERROR", "INVALID_PORT2_ERR_ALPHA",field,""
        elseif (validations.hasTypeValidate(port2,"%p") == 1) then
            return "ERROR", "INVALID_PORT2_ERR_SPCLCHAR",field,""
	end
    end
    if(port2 ~= "") then
       flag , errMsg = validations.rangeValidate(min,max,tonumber(port1),tonumber( port2))
       if (flag ==1 or flag == "ERROR") then
          if(errMsg == "ERR_START_GREATER_THAN_END") then
             return "ERROR", "ERR_PORT1_GREATERTHAN_PORT2",field,""
          end
          return "ERROR", errMsg,field,""
       end
    else
       flag , errMsg = validations.rangeValidate(min,max,tonumber(port1),"")
       if (flag ==1 or flag == "ERROR") then
          if(errMsg == "ERR_RANGE") then
             return "ERROR", "ERR_PORT1_INVALID",field,""
          end
          return "ERROR", errMsg,field,""
       end
    end
    return flag , errMsg,field,""
end


-- validates numeric or not
-- args : value (as strings)
-- returns : flag = 0  (no error), 1 (error), error message
function validations.numericValidate(value,field)
    if(value == "") then
       return 1, "ERR_EMPTY_VALUE_ENTERED",field
    elseif (validations.hasTypeValidate(value,"%a%s") == 1) then
       return 1, "INVALID_VALUE_ERR_ALPHA",field
    elseif (validations.hasTypeValidate(value,"%p") == 1) then
       return 1, "INVALID_VALUE_ERR_SPCLCHAR",field
    end
    return 0, ""
end


-- validates checkbox as enabled or disabled to given checkValue
-- args : value (as strings), skipValidations (number) to skip the next validations
-- returns : flag = 0  (no error), 1 (error), error message, field name , skipValidations
function validations.checkboxValidate(value,checkValue,skipStep)
    if(value == checkValue) then
		return 0,"","", ""
    else
		return 0,"","",skipStep
    end
end

-- validates checkbox as enabled or disabled to given checkValue
-- args : value (as strings), skipValidations (number) to skip the next validations
-- returns : flag = 0  (no error), 1 (error), error message, field name , skipValidations
function validations.checkboxValidate1(value,checkValue,skipStep)
    if(value ~= checkValue) then
		return 0,"","", ""
    else
		return 0,"","",skipStep
    end
end


--validates idletime setting on wan configuration page ( 5-999 )
--args : idle time
--returns : flag = 0 ( no error ), 1 ( error) error message
function validations.idleTimeChk( idleTime )
	 local flag = 0
	 if(idleTime == "") then
	 	return 1, "ERR_IDLETIME_EMPTY_VALUE"
	 end
	 if (validations.hasTypeValidate(idleTime,"%a%s") == 1) then
	 	return 1, "INVALID_IDLETIME_ERR_ALPHA",field
	 elseif (validations.hasTypeValidate(idleTime,"%p") == 1) then
		 return 1, "INVALID_IDLETIME_ERR_SPCLCHAR",field
	 end
	 flag , errMsg, field = validations.rangeValidate(5,999,tonumber(idleTime),"",field)
	 if (flag ==1) then
	 	return 1, "ERR_IDLETIME_INVALIDRANGEVALUE"
	 else
	 	return flag , errMsg
	 end
end

--validate Advertise Interval on RADVD Page
-- args : advInterval
--returns : flag = 0 ( no error ), 1 ( error) error message
function validations.adInterval(advInterval)
	 local flag = "OK"
	 if(advInterval == "") then
	 	return "ERROR", "ERR_ADV_INV_EMPTY_VALUE"
	 end
	 if (validations.hasTypeValidate(advInterval,"%a%s") == 1) then
	 	return "ERROR", "INVALID_ADV_INV_ERR_ALPHA"
	 elseif (validations.hasTypeValidate(advInterval,"%p") == 1) then
		 return "ERROR", "INVALID_ADVINTERVAL_ERR_SPCLCHAR",field
	 end

	 flag , errMsg, field = validations.rangeValidate(10,1800,tonumber(advInterval),"",field)
	 if (flag ==1 or flag=="ERROR") then
	 	return 1, "ERR_ADV_INV_INVALIDRANGEVALUE"
	 else
	 	return flag , errMsg
	 end	 
end

--validate MTU on RADVD Page
-- args : mtuRadvd
--returns : flag = 0 ( no error ), 1 ( error) error message
function validations.mtuChk( mtuRadvd )
	 local flag = 0
	 if(mtuRadvd == "") then
	 	return 1, "ERR_EMPTY_VALUE_ENTERED"
	 end
	 if (validations.hasTypeValidate(mtuRadvd,"%a%s") == 1) then
	 	return 1, "INVALID_RADVDMTU_ERR_ALPHA",field
	 elseif (validations.hasTypeValidate(mtuRadvd,"%p") == 1) then
		 return 1, "INVALID_RADVDMTU_ERR_SPCLCHAR",field
	 end
	 if (mtuRadvd == "0" or mtuRadvd == 0 ) then
	 	flag = 0;
	 	errMsg = ""
	 else
	 	flag , errMsg, field = validations.rangeValidate(1280,1500,tonumber(mtuRadvd),"",field)
	 end
	 if (flag ==1 or flag=="ERROR") then
	 	return 1, "ERR_RADVDMTU_INVALIDRANGEVALUE"
	 else
	 	return flag , errMsg
	 end
end

--validate Router Lifetime on RADVD Page
-- args : rtrLifeTime
--returns : flag = 0 ( no error ), 1 ( error) error message
function validations.routerLifeTime( rtrLifeTime )
	 local flag = 0
	 if(rtrLifeTime == "") then
	 	return 1, "ERR_EMPTY_VALUE_ENTERED"
	 end
	 if (validations.hasTypeValidate(rtrLifeTime,"%a%s") == 1) then
	 	return 1, "INVALID_ROUTERLIFETIME_ERR_ALPHA",field
	 elseif (validations.hasTypeValidate(rtrLifeTime,"%p") == 1) then
		 return 1, "INVALID_ROUTERLIFETIME_ERR_SPCLCHAR",field
	 end
	 if (rtrLifeTime == "0" ) then
	 	flag = 0;
	 	errMsg = ""
	 else
	 	flag , errMsg, field = validations.rangeValidate(50,9000,tonumber(rtrLifeTime),"",field)
	 end
	 if (flag ==1 or flag=="ERROR") then
	 	return 1, "ERR_ROUTERLIFETIME_INVALIDRANGEVALUE"
	 else
	 	return flag , errMsg
	 end
end

--validate bandWidth rate
-- args : bndWidth
--returns : flag = 0 ( no error ), 1 ( error) error message
function validations.bandWidthRate( bndWidth, field)

	 local flag = 0
	 if(bndWidth == "") then
	 	return 1, "ERR_EMPTY_VALUE_ENTERED",field
	 end
	 if (validations.hasTypeValidate(bndWidth,"%a%s") == 1) then
	 	return 1, "INVALID_BANDWIDTH_ERR_ALPHA",field,""
	 elseif (validations.hasTypeValidate(bndWidth,"%p") == 1) then
		 return 1, "INVALID_BANDWIDTH_ERR_SPCLCHAR",field,""
	 end
	 flag , errMsg, field = validations.rangeValidate(100,1000000,tonumber(bndWidth),"",field)
	 if (flag ==1 or flag == "ERROR") then
	 	return 1, "ERR_BANDWIDTH_INVALIDRANGEVALUE",field,""
	 else
	 	return flag , errMsg, field,""
	 end
end

--validate idle timeout
-- args : idlTmOut
--returns : flag = 0 ( no error ), 1 ( error) error message
function validations.idleTimeOut( idlTmOut )
	 local flag = 0
	 if(idlTmOut == "") then
	 	return 1, "ERR_EMPTY_VALUE_ENTERED"
	 end
	 if (validations.hasTypeValidate(idlTmOut,"%a%s") == 1) then
	 	return 1, "INVALID_IDLETIMEOUT_ERR_ALPHA",field
	 elseif (validations.hasTypeValidate(idlTmOut,"%p") == 1) then
		 return 1, "INVALID_IDLETIMEOUT_ERR_SPCLCHAR",field
	 end
	 flag , errMsg, field = validations.rangeValidate(1,999,tonumber(idlTmOut),"",field)
	 if (flag ==1 or flag =="ERROR") then
	 	return 1, "ERR_IDLETIMEOUT_INVALIDRANGEVALUE"
	 else
	 	return flag , errMsg
	 end
end

--validate preshared key length for VPN Wizard Gateway
-- args : preShareKey
--returns : flag = 0 ( no error ), 1 ( error) error message
function validations.preShrKeyChk(preShareKey, field)
	 local flag = 0
	 if(preShareKey == "") then
	 	return 1, "ERR_PRESHAREKEY_EMPTY_VALUE", field, ""
	 end
	 preShareKeyLen = string.len(preShareKey)
	 flag , errMsg, field = validations.rangeValidate(8,49,tonumber(preShareKeyLen),"",field)
	 if (flag =="ERROR") then
	 	return 1, "ERR_PRESHAREKEY_INVALID_KEY_LEN",field,""
	 else
	 	return flag , "OK", field, ""
	 end
end

--validate Maximum query response time on MLD page
-- args : maxResQurTime
--returns : flag = 0 ( no error ), 1 ( error) error message
function validations.resTime( maxResQurTime,field )
	 local flag = 0
	 if(maxResQurTime == "") then
	 	return 1, "ERR_EMPTY_VALUE_ENTERED",field,""
	 end
	 if (validations.hasTypeValidate(maxResQurTime,"%a%s") == 1) then
	 	return 1, "INVALID_MAXQUERRYTIME_ERR_ALPHA",field,""
	 elseif (validations.hasTypeValidate(maxResQurTime,"%p") == 1) then
		 return 1, "INVALID_MAXQUERRYTIME_ERR_SPCLCHAR",field,""
	 end
	 flag , errMsg, field = validations.rangeValidate(5000,99999999,tonumber(maxResQurTime),"",field)
	 if (flag == "ERROR" or flag == 1 ) then
	 	return 1, "ERR_MAXQUERRYTIME_INVALIDRANGEVALUE",field,""
	 else
	 	return flag , errMsg, field, ""
	 end
end


--validate  Robustness Variable on MLD page
-- args : robVariable
--returns : flag = 0 ( no error ), 1 ( error) error message
function validations.robustness(robVariable,field)
	 local flag = 0
	 if(robVariable == "") then
	 	return 1, "ERR_EMPTY_VALUE_ENTERED",field,""
	 end
	 if (validations.hasTypeValidate(robVariable,"%a%s") == 1) then
	 	return 1, "INVALID_ROBVARIABLE_ERR_ALPHA",field,""
	 elseif (validations.hasTypeValidate(robVariable,"%p") == 1) then
		 return 1, "INVALID_ROBVARIABLE_ERR_SPCLCHAR",field,""
	 end
	 flag , errMsg, field = validations.rangeValidate(2,99,tonumber(robVariable),"",field)
	 if (flag == "ERROR" or flag == 1) then
	 	return 1, "ERR_ROBVARIABLE_INVALIDRANGEVALUE",field,""
	 else
	 	return flag , errMsg, field, ""
	 end
end


--validate  Query interval.on MLD page
-- args : qurInv
--returns : flag = 0 ( no error ), 1 ( error) error message
function validations.qurInterval(qurInv,field)
	 local flag = 0
	 if(qurInv == "") then
	 	return 1, "ERR_EMPTY_VALUE_ENTERED",field,""
	 end
	 if (validations.hasTypeValidate(qurInv,"%a%s") == 1) then
	 	return 1, "INVALID_QUERRYINV_ERR_ALPHA",field,""
	 elseif (validations.hasTypeValidate(qurInv,"%p") == 1) then
		 return 1, "INVALID_QUERRYINV_ERR_SPCLCHAR",field,""
	 end
	 flag , errMsg, field = validations.rangeValidate(100,99999,tonumber(qurInv),"",field)
	 if (flag == "ERROR" or flag ==1) then
	 	return 1, "ERR_QUERRYINV_INVALIDRANGEVALUE",field,""
	 else
	 	return flag , errMsg, field,""
	 end
end

--validate  Detection period for VPN Keep Alive
-- args : detPer
--returns : flag = 0 ( no error ), 1 ( error) error message
function validations.detPeriod(detPer, field)
	 local flag = 0
	 if(detPer == "") then
	 	return 1, "ERR_EMPTY_VALUE_ENTERED", field, ""
	 end
	 if (validations.hasTypeValidate(detPer,"%a%s") == 1) then
	 	return 1, "INVALID_DETPERIOD_ERR_ALPHA",field,""
	 elseif (validations.hasTypeValidate(detPer,"%p") == 1) then
		 return 1, "INVALID_DETPERIOD_ERR_SPCLCHAR",field,""
	 end
	 flag , errMsg, field = validations.rangeValidate(10,999,tonumber(detPer),"",field)
	 if (flag ==1 or flag=="ERROR") then
	 	return 1, "ERR_DETPERIOD_INVALIDRANGEVALUE", field, ""
	 else
	 	return flag , errMsg, field ,""
	 end
end

--validate Reconnect after failure count  for VPN Keep Alive
-- args : reConCnt
--returns : flag = 0 ( no error ), 1 ( error) error message
function validations.reConCount(reConCnt , field)
	 local flag = 0
	 if(reConCnt == "") then
	 	return 1, "ERR_EMPTY_VALUE_ENTERED" , ""
	 end
	 if (validations.hasTypeValidate(reConCnt,"%a%s") == 1) then
	 	return 1, "INVALID_RECONNECT_ERR_ALPHA",field,""
	 elseif (validations.hasTypeValidate(reConCnt,"%p") == 1) then
		 return 1, "INVALID_RECOUNT_ERR_SPCLCHAR",field, ""
	 end
	 flag , errMsg, field = validations.rangeValidate(3,99,tonumber(reConCnt),"",field)
	 if (flag ==1 or flag == "ERROR") then
	 	return 1, "ERR_RECONNECT_INVALIDRANGEVALUE", field, ""
	 else
	 	return flag , errMsg, field , ""
	 end
end


--validate IPV6 address
--args : ipAddr
-- returns : flag = 0 ( no error ), 1 (error) error message
function validations.ipv6AddrValidate( ipAddr, field, skipChk )
	local ipv4Cnt = 0
	local empOct = 0
	local flag = 0
	local errMssg = ""
	if(ipAddr == "" and skipChk == "skip") then
		return "OK","OK",field,""
	end
	if(ipAddr == "") then
	 	return 1, "ERR_IPV6_EMPTY_VALUE",field,""
	end
	addrArr = validations.split( ipAddr, ":")
	addrArrLen = #(addrArr)
	if ( #(addrArr)>8 or addrArrLen == 1 or addrArrLen == 2 ) then  --err1 more that 8 octets
		return 1, "CHECK_NUMBER_OCTETS_IPV6",field,""
	end
	for k,v in pairs(addrArr) do
		if ((k < (addrArrLen - 2) and addrArr[k] == "" and addrArr[k+1] == "" and addrArr[k+2] == "") or ((addrArr[k] == "0" or addrArr[k] == "0000")and (addrArr[k+2] == "0" or addrArr[k+2] == "0000"))) then  --err2 more than 3 colons in a row
			return 1, "CHECK_COLON_POSITION_IPV6",field,""
		end
		if(validations.hasTypeValidate(addrArr[k],"g-z")==1 or validations.hasTypeValidate(addrArr[k],"G-Z")==1) then --err3 only number and hex characters allowed
			return 1, "INVALID_IPV6ADDR_CHAR",field,""
		end
		if (string.len(addrArr[k]) > 4) then
			ipv4Cnt = ipv4Cnt+1
		end
		if (addrArr[k] == "" ) then
			empOct = empOct + 1
		end
	end
	if ( empOct > 2 ) then --err4 more than 2 double colons
		return 1, "INVALID_IPV6ADDR_CHECK_COLONS", field, ""
	end
	if (ipv4Cnt > 1 ) then    --err5 more than 2 ipv4 addresses only 1 allowed
		return 1, "CHECK_OCTET_IPV4_TYPE", field, ""
	end
	if(ipv4Cnt==1) then
		if ( 	string.len(addrArr[addrArrLen]) > 4 ) then
			flag , errMsg = validations.ipAddressValidate(addrArr[addrArrLen],"")
		else
			return 1, "INVALID_IPV4ADRR_NOT_AT_END", field, "" --err6 ipv4 is not at the last position
		end
	end
	if( flag == 1) then 
		return flag,errMsg,field,""
	end
	if(empOct == 1) then
		if ((addrArr[1]=="")  or addrArr[addrArrLen] == "") then --err7 cases like :a:b or a:b: which return mpOct == 1
			return 1, "INVALID_IPV6ADDR_CHECK_OCTECT_POSITION",field,""
		end
	end
	if(ipv4Cnt==1) then
		if( addrArrLen>7 ) then --err8 if ipv4 addrees  is present then max number of octets is 6
			return 1, "INVALID_IPV6ADDR_CHECK_NUMBER_OCTETS",field,""
		end
	end
	if(empOct == 2) then
		if((addrArr[1]=="" and addrArr[2]=="") or (addrArr[addrArrLen-1]=="" and addrArr[addrArrLen]=="")) then
		else
			return 1, "INVALID_IPV6ADDR_CHECK_OCTET",field,""     --err9 when emoOct ==2 only cases allowed is ::a or ::a remove cases like a::a::a
		end
	end
	return flag,"OK",field,""
end


--covert given ipaddress to standard form
-- args : ipAddr
-- returns : ip in standard form
function validations.ipv6Convert( ipAddr )
	if(ipAddr == "") then
	 	return 1, "ERR_EMPTY_VALUE_ENTERED"
	end
	addrArr = {}
	addrArr = validations.split( ipAddr, ":")
	addrArrLen = #(addrArr)
	local stanForm = {}
	local stanFormIp = ""
	local maxLen = 8
	--for i = 1,maxLen do
		--stanForm[i] =" 0"
	--end
	for i = 1,addrArrLen do
		if (addrArr[i] ~= "" ) then
			stanForm[i] = addrArr[i]
		end
		if (addrArr[i] == "" and (i==1)) then  --case ::a..... or ::192.16......
			s = addrArrLen
			while ( addrArr[s] ~= "" ) do
				if (string.len(addrArr[s]) > 4) then
					--return "blabla"
					maxLen = 7;
					stanForm[maxLen] = addrArr[s]
					maxLen = maxLen-1
					s = s-1
				else
	 				stanForm[maxLen] = addrArr[s]
	 				maxLen = maxLen - 1
	 				s = s-1
	 			end
	 		end
	 		for j = maxLen,1,-1 do
	 			stanForm[j] = 0
	 		end
	 		stanFormIp = validations.join(stanForm,":")
	 		return stanFormIp
	 	end
	 	if (addrArr[i] == "" and addrArr[i+1] ~= "") then
	 		s = addrArrLen
			while ( addrArr[s] ~= "" ) do
				if (string.len(addrArr[s]) > 4) then
					maxLen = 7;
					stanForm[maxLen] = addrArr[s]
					maxLen = maxLen-1
					s = s -1
				else
	 				stanForm[maxLen] = addrArr[s]
	 				maxLen = maxLen - 1
	 				s = s-1
	 			end
	 		end
	 		for j = maxLen,i,-1 do
	 			stanForm[j] = 0
	 		end
	 		stanFormIp = validations.join(stanForm,":")
	 		return stanFormIp
	 	end
	 	if ( addrArr[i] == "" and addrArr[i+1] == "" ) then
	 		for j = i,8 do
	 			stanForm[j] = 0;
	 		end
	 		stanFormIp = validations.join(stanForm,":")
	 		return stanFormIp
	 	end

	end
 		stanFormIp = validations.join(stanForm,":")
 		return stanFormIp
end

--compare two ipv6 addresses
-- args: string1,string2 ( the two ip addresses
-- return value 1 if string 1 is greater, returns 0 if string 2 is greater  returns 2 if both are equal
function  validations.ipv6AddrCompare( string1,string2 )
	
	if(string1 == string2 ) then
		return 0
	end
	local eqFlag = 0;
	local string2parts = {}
	string1parts = validations.split(string1,":")
	string2parts = validations.split(string2,":")
	local flag = 1
	for i = 1,8 do
		
		if ( string.len(string1parts[i])> 4 and string.len(string2parts[i])<= 4) then
			ipv4parts = validations.split(string1parts[7],".");
			val1 = tonumber(ipv4parts[1],10)*(tonumber(ipv4parts[2],10));
			v6val1=tonumber(string2parts[7],16);
			if(val1 > v6val1) then
				return 1
			end
			if(val1 < v6val1) then
				return 2
			end
			val2 = tonumber(ipv4parts[3],10)*(tonumber(ipv4parts[4],10));
			v6val2 = tonumber(string2parts[7],16);
			if(val2 > v6val2) then
				return 1
			end
			if(val2 < v6val2) then
				return 2
			end
		elseif( string.len( string2parts[i])> 4 and string.len( string1parts[i])<= 4) then
			ipv4parts = validations.split(string2parts[6],".");
			val1 = tonumber(ipv4parts[0],10)*(tonumber(ipv4parts[1],10));
			v6val1=tonumber(string1parts[6],16);
			if(val1 > v6val1) then
				return 2
			end
			if(val1 < v6val1) then
				return 1
			end
			val2 = tonumber(ipv4parts[2],10)*(tonumber(ipv4parts[3],10));
			v6val2 = tonumber(string1parts[7],16);
			if(val2 > v6val2) then
				return 2
			end
			if(val2 < v6val2) then
				return 1
			end
		elseif ( string.len(string1parts[i]) > 4 and string.len(string2parts[i]) > 4 ) then
			
			v4parts1 = validations.split(string1parts[7],".")
			v4parts2 = validations.split(string2parts[7],".")
			for k = 1,4 do
				if ( tonumber(v4parts1[k]) > tonumber(v4parts2[k])) then
					return 1
				elseif( tonumber(v4parts1[k])< tonumber(v4parts2[k])) then
					return 2
				end
			end
		elseif ( string.len(string1parts[i]) > string.len(string2parts[i]) ) then
			return 1
		elseif ( string.len(string1parts[i]) < string.len(string2parts[i])) then
			return 2
		else
			for j = 1,string.len(string1parts[i]) do
				string1Char = string.sub( string1parts[i], j, j)
				string2Char = string.sub( string2parts[i], j, j)
				if ( string1Char > 	string2Char ) then
					return 1
				elseif ( string1Char <	string2Char ) then
					return 0
				end
			end
		end
	end
	return 3
end


--compare two ipv6 address and report error if 1st IP is smaller that 2nd IP
-- args: ip1,ip2
--flag = 0 ( no error ), 1 (error) error message
function validations.v6AddrCom( ip1, ip2 , field)
	local flag = 0
	errorFlag,statusCode = validations.ipv6AddrValidate(ip1)
	if(errorFlag == 0 or errorFlag == "OK") then
		errorFlag,statusCode = validations.ipv6AddrValidate(ip2)
	end
	if(errorFlag == 0 or errorFlag == "OK") then
		if(ip1 == "" or ip2 == "") then
	       return 1, "ERR_EMPTY_VALUE_ENTERED",field,""
	    end
		check = validations.ipv6AddrCompare( ip1,ip2 )
		if ( check == 1) then
		 	return 1, "FIRST_GREATER_THAN_SECOND_IP_V6",field,""
		elseif( check == 3) then
			return 1, "BOTH_IP_EQUAL_V6",field,""
		end
		return 0,"OK",field,""
	end
	return errorFlag,statusCode,field,""
end

--validate ipv6 prefix length
-- args : preLength
--returns : flag = 0 ( no error ), 1 ( error) error message
function validations.preLenChk(preLength,field)
	 local flag = 0
	 if(preLength == "") then
	 	return 1, "ERR_EMPTY_VALUE_ENTERED",field,""
	 end
	 if (validations.hasTypeValidate(preLength,"%a%s") == 1) then
	 	return 1, "INVALID_PREFIX_LENGTH_ERR_ALPHA",field,""
	 elseif (validations.hasTypeValidate(preLength,"%p") == 1) then
		 return 1, "INVALID_PREFIX_LENGTH_ERR_SPCLCHAR",field,""
	 end
	 flag , errMsg, field = validations.rangeValidate(0,128,tonumber(preLength),"",field)
	 if (flag ==1 or flag=="ERROR") then
	 	return 1, "ERR_PREFIX_LENGTH_INVALIDRANGEVALUE", field, ""
	 else
	 	return flag , errMsg, field,""
	 end
end


--validate ipv6 metric
-- args : v6Metric
--returns : flag = 0 ( no error ), 1 ( error) error message
function validations.v6MetricChk(v6Metric,field)
	 local flag = 0
	 if(v6Metric == "") then
	 	return 1, "ERR_EMPTY_VALUE_ENTERED",field,""
	 end
	 if (validations.hasTypeValidate(v6Metric,"%a%s") == 1) then
	 	return 1, "INVALID_METRIC_ERR_ALPHA",field,""
	 elseif (validations.hasTypeValidate(v6Metric,"%p") == 1) then
		 return 1, "INVALID_METRIC_ERR_SPCLCHAR",field,""
	 end
	 flag, errMsg = validations.rangeValidate(2,15,tonumber(v6Metric),"",field)
	 if (flag ==1 or flag=="ERROR") then
	 	return 1, "ERR_METRIC_INVALIDRANGEVALUE",field,""
	 else
	 	return flag , errMsg, field,""
	 end
end



--validate dhcpv6 rebind/lease time
-- args : v6RbnTime
--returns : flag = 0 ( no error ), 1 ( error) error message
function validations.v6RbnTimeChk(v6RbnTime, field)
	 local flag = 0
	 if(v6RbnTime == "") then
	 	return 1, "ERR_EMPTY_VALUE_ENTERED",field,""
	 end
	 if (validations.hasTypeValidate(v6RbnTime,"%a%s") == 1) then
	 	return 1, "INVALID_REBIND_TIME_ERR_ALPHA",field,""
	 elseif (validations.hasTypeValidate(v6RbnTime,"%p") == 1) then
		 return 1, "INVALID_REBIND_TIME_ERR_SPCLCHAR",field,""
	 end
	 flag , errMsg, field = validations.rangeValidate(0,604800,tonumber(v6RbnTime),"",field)
	 if (flag ==1 or flag=="ERROR") then
	 	return 1, "ERR_BIND_TIME_INVALIDRANGEVALUE",field,""
	 else
	 	return flag , errMsg, field, ""
	 end
end


--validate login ip mask
-- args : logIpMask
--returns : flag = 0 ( no error ), 1 ( error) error message
function validations.logIpMask(logIpMask)
	 local flag = 0
	 if(logIpMask == "") then
	 	return 1, "ERR_EMPTY_VALUE_ENTERED"
	 end
	 if (validations.hasTypeValidate(logIpMask,"%a%s") == 1) then
	 	return 1, "INVALID_LOGIN_MASK_ERR_ALPHA",field
	 elseif (validations.hasTypeValidate(logIpMask,"%p") == 1) then
		 return 1, "INVALID_LOGIN_MASK_ERR_SPCLCHAR",field
	 end
	 flag , errMsg, field = validations.rangeValidate(0,32,tonumber(logIpMask),"",field)
	 if (flag ==1 or flag == "ERROR") then
	 	return 1, "ERR_LOGIN_MASK_INVALIDRANGEVALUE"
	 else
	 	return flag , errMsg
	 end
end


--validate wan failover time
-- args : wanFailTime
--returns : flag = 0 ( no error ), 1 ( error) error message
function validations.wanFailTimeChk(wanFailTime)
	 local flag = 0
	 if(wanFailTime == "") then
	 	return 1, "ERR_EMPTY_VALUE_ENTERED"
	 end
	 if (validations.hasTypeValidate(wanFailTime,"%a%s") == 1) then
	 	return 1, "INVALID_FAILOVER_ERR_ALPHA",field
	 elseif (validations.hasTypeValidate(wanFailTime,"%p") == 1) then
		 return 1, "INVALID_FAILOVER_ERR_SPCLCHAR",field
	 end
	 flag , errMsg, field = validations.rangeValidate(2,999,tonumber(wanFailTime),"",field)
	 if (flag ==1 or flag=="ERROR") then
	 	return 1, "ERR_FAILOVER_INVALIDRANGEVALUE"
	 else
	 	return flag , errMsg
	 end
end

--validate wan retry interval
-- args : wanReInv
--returns : flag = 0 ( no error ), 1 ( error) error message
function validations.wanRetry(wanReInv)
	 local flag = 0
	 if(wanReInv == "") then
	 	return 1, "ERR_EMPTY_VALUE_ENTERED"
	 end
	 if (validations.hasTypeValidate(wanReInv,"%a%s") == 1) then
	 	return 1, "INVALID_RETRY_INV_ERR_ALPHA",field
	 elseif (validations.hasTypeValidate(wanReInv,"%p") == 1) then
		 return 1, "INVALID_RETRY_INV_ERR_SPCLCHAR",field
	 end
	 flag , errMsg, field = validations.rangeValidate(30,999,tonumber(wanReInv),"",field)
	 if (flag ==1 or flag == "ERROR") then
	 	return 1, "ERR_RETRY_INV_INVALIDRANGEVALUE"
	 else
	 	return flag , errMsg
	 end
end


--validate TCP limits
-- args : tcp
--returns : flag = 0 ( no error ), 1 ( error) error message
function validations.tcpCheck(tcp)
	 local flag = 0
	 if(tcp == "") then
	 	return 1, "ERR_EMPTY_VALUE_ENTERED"
	 end
	 if (validations.hasTypeValidate(tcp,"%a%s") == 1) then
	 	return 1, "INVALID_TCP_RANGE_ERR_ALPHA",field
	 elseif (validations.hasTypeValidate(tcp,"%p") == 1) then
		 return 1, "INVALID_TCP_RANGE_ERR_SPCLCHAR",field
	 end
	 flag , errMsg, field = validations.rangeValidate(0,65535,tonumber(tcp),"",field)
	 if (flag ==1 or falg =="ERROR") then
	 	return 1, "ERR_TCP_INVALIDRANGEVALUE"
	 else
	 	return flag , errMsg
	 end
end

--validate time and date settings i.e Hrs and Seconds
-- args : time,unit (seconds or hours )
--returns : flag = 0 ( no error ), 1 ( error) error message
function validations.timeCheck(time, unit, field )

	 local flag = 0
	 if(time == "") then
	 	return 1, "ERR_EMPTY_VALUE_ENTERED",field,""
	 end
	 if (validations.hasTypeValidate(time,"%a%s") == 1) then
	 	return 1, "INVALID_TIME_ERR_ALPHA",field,""
	 elseif (validations.hasTypeValidate(time,"%p") == 1) then
		 return 1, "INVALID_TIME_ERR_SPCLCHAR",field,""
	 end
	 if(unit == "hour" ) then 
	 	flag , errMsg, field = validations.rangeValidate(1,12,tonumber(time),"",field)
	 	if (flag ==1 or flag == "ERROR") then
	 		return 1, "ERR_INVALID_HOUR_SETTING",field,""
	 	end
	 elseif(unit == "minute" ) then 
	 	flag , errMsg, field = validations.rangeValidate(0,59,tonumber(time),"",field)
	 	if (flag ==1 or flag == "ERROR") then
	 		return 1, "ERR_INVALID_MINUTE_SETTING",field,""
	 	end
	 elseif(unit == "month" ) then
	 	flag , errMsg, field = validations.rangeValidate(1,12,tonumber(time),"",field)
	 	if (flag ==1 or flag == "ERROR") then
	 		return 1, "ERR_INVALID_MONTH_SETTING",field,""
	 	end
	 elseif(unit == "date" ) then
	 	flag , errMsg, field = validations.rangeValidate(1,31,tonumber(time),"",field)
	 	if (flag ==1 or flag == "ERROR") then
	 		return 1, "ERR_INVALID_DATE_SETTING",field,""
	 	end
	 elseif(unit == "second" ) then
	 	flag , errMsg, field = validations.rangeValidate(0,59,tonumber(time),"",field)
	 	if (flag ==1 or flag == "ERROR") then
	 		return 1, "ERR_INVALID_SECOND_SETTING",field,""
	 	end
	 end
	 return flag , errMsg,field, ""
end

--validate MD5 Key
-- args : mdKey
--returns : flag = 0 ( no error ), 1 ( error) error message
function validations.mdCheck(mdKey,field)
	 local flag = 0
	 if(mdKey == "") then
	 	return 1, "ERR_EMPTY_VALUE_ENTERED",field,""
	 end
	 if (validations.hasTypeValidate(mdKey,"%a%s") == 1) then
	 	return 1, "INVALID_MD5_KEY_ERR_ALPHA",field,""
	 elseif (validations.hasTypeValidate(mdKey,"%p") == 1) then
		 return 1, "INVALID_MD5_KEY_ERR_SPCLCHAR",field,""
	 end
	 flag , errMsg, field = validations.rangeValidate(1,255,tonumber(mdKey),"",field)
	 if (flag ==1 or flag == "ERROR") then
	 	return 1, "ERR_MD5KEY_INVALIDRANGEVALUE",field,""
	 else
	 	return flag , errMsg, field, ""
	 end
end


-- validate SA-LifeTime on VPN Config Page
--args: limit,lifeTime
--returns : flag = 0 ( no error ), 1 ( error) error message
function validations.vpnSaLifeTime(limit,lifeTime,field)
	 if(lifeTime == "") then
	 	return 1, "ERR_SALIFE_EMPTY_VALUE",field,""
	 end
	 if (validations.hasTypeValidate(lifeTime,"%a%s") == 1) then
	 	return 1, "INVALID_SA_TIME_ERR_ALPHA",field,""
	 elseif (validations.hasTypeValidate(lifeTime,"%p") == 1) then
		 return 1, "INVALID_SA_TIME_ERR_SPCLCHAR",field,""
	 end	 
	if( tonumber(lifeTime) < limit ) then
		return 1,"ERR_SA_LIFE_TIME",field,""
	else 
		return 0,"",field,""
	end
end

-- vallidate key length on VPN Config page
--args: reqLen,Key
--returns : flag = 0 ( no error ), 1 ( error) error message
function validations.vpnKeyVal(reqLen,key,field)
	if(lifeTime == "") then
	 	return 1, "ERR__VPN_KEY_EMPTY_VALUE",field,""
	end
	if (srting.len(key) ~= reqLen) then
		return 1,"VPN_INCORRECT_KEY_LENGTH",field,""
	else
		return 0,"OK",field,""
	end
end

--validate username,first name, last name on ssl user config page
function validations.nameChk(name)
	if(name == "" ) then 
		return 1,"ERROR_NAME_EMPTY"
	end
	nameLen = string.len(name)
	for j = 1,nameLen do
		nameChar = string.sub( name, j, 1)
		if(nameChar == nil or nameChar == "\"") then
			return "ERROR","INAVLID_CHARACTER_IN_NAME"
		end
	end
	return "OK","OK"
end

--validate upnp adv period
function validations.upnpAdvInv(adInv,field)
	 local flag = 0
	 if(adInv == "") then
	 	return 1, "ERR_EMPTY_VALUE_ENTERED",field,""
	 end
	 if (validations.hasTypeValidate(adInv,"%a%s") == 1) then
	 	return 1, "INVALID_UPNP_INV_ERR_ALPHA",field,""
	 elseif (validations.hasTypeValidate(adInv,"%p") == 1) then
		 return 1, "INVALID_UPNP_INV_ERR_SPCLCHAR",field,""
	 end
	 flag , errMsg, field = validations.rangeValidate(1,86400,tonumber(adInv),"",field)
	 if (flag ==1 or flag == "ERROR") then
	 	return 1, "ERR_UPNP_ADV_INV_INVALIDRANGEVALUE", field,""
	 else
	 	return flag , errMsg, field, ""
	 end
end	


--validate upnp ad time to live
function validations.upnpAdvTime(adTime,field)
	 local flag = 0
	 if(adTime == "") then
	 	return 1, "ERR_EMPTY_VALUE_ENTERED",field,""
	 end
	 if (validations.hasTypeValidate(adTime,"%a%s") == 1) then
	 	return 1, "INVALID_AD_TIME_ERR_ALPHA",field,""
	 elseif (validations.hasTypeValidate(adTime,"%p") == 1) then
		 return 1, "INVALID_AD_TIME_ERR_SPCLCHAR",field,""
	 end
	 flag , errMsg, field = validations.rangeValidate(1,255,tonumber(adTime),"",field)
	 if (flag ==1 or flag == "ERROR") then
	 	return 1, "ERR_UPNP_ADV_TIME_INVALIDRANGEVALUE",field,""
	 else
	 	return flag , errMsg, field ,""
	 end
end


--validate fields on advanced profile config page
function validations.wlProfileAdv(var)
	 local flag = 0
	 if(var == "") then
	 	return 1, "ERR_EMPTY_VALUE_ENTERED"
	 end
	 if (validations.hasTypeValidate(var,"%a%s") == 1) then
	 	return 1, "INVALID_PROFILE_ERR_ALPHA",field
	 elseif (validations.hasTypeValidate(var,"%p") == 1) then
		 return 1, "INVALID_PROFILE_ERR_SPCLCHAR",field
	 end
	 flag , errMsg, field = validations.rangeValidate(1,36000,tonumber(var),"",field)
	 if (flag ==1 or flag == "ERROR") then
	 	return 1, "ERR_INVALIDRANGEVALUE_WL"
	 else
	 	return flag , errMsg
	 end
end

--validate fields on radius server config page
function validations.wlRadius(var,field)
	 local flag = 0
	 if(var == "") then
	 	return 1, "ERR_EMPTY_VALUE_ENTERED",field,""
	 end
	 if (validations.hasTypeValidate(var,"%a%s") == 1) then
	 	return 1, "INVALID__RADIUS_ERR_ALPHA",field,""
	 elseif (validations.hasTypeValidate(var,"%p") == 1) then
		 return 1, "INVALID_RADIUS_ERR_SPCLCHAR",field,""
	 end
	 flag , errMsg, field = validations.rangeValidate(1,999,tonumber(var),"",field)
	 if (flag ==1 or flag == "ERROR") then
	 	return 1, "ERR_INVALIDRANGEVALUE_RADIUS",field,""
	 else
	 	return flag , errMsg,field,""
	 end
end

--check if the field is empty
function validations.isEmpty(inField,field)

	if (inField == "") then 
		return "ERROR", "ERR_EMPTY_VALUE_ENTERED", field,""
	else
		return "OK", "OK", field,""
	end
end

-- fqdn check
function validations.is_fqdn_address (fqdn) 

    -- if a bad input value, return error

    if (fqdn == nil) or (type(fqdn) ~= "string") then
        return false
    end


    -- check if the string is in proper IPv4 address pattern
    --

    local fqdnpattern = "^[a-zA-Z0-9_%-%.]+[^.]$";

    if ( string.find (fqdn, fqdnpattern)) then
        return true;
    end

    return false

end

function validations.is_ipv4_address (ip) 

    local ipv4Length = 4
    local ipv4OctetMinVal = 0
    local ipv4OctetMaxVal = 255

    -- if a bad input value, return error

    if (ip == nil) or (type(ip) ~= "string") then
        return false
    end


    -- check if the string is in proper IPv4 address pattern
    --

    local ipv4pattern = "^(%d+)%.(%d+)%.(%d+)%.(%d+)$";
    local digits = {ip:match(ipv4pattern)}

    -- there should be 4 digits, otherwise, its an error
    --
    if (digits == nil) then
        return false
    end

    if (#digits ~= ipv4Length) then
        return false
    end

    -- check each octet for valid numbers

    for _,v in pairs(digits) do

        local d = tonumber(v)

        print(d)

        if (d < ipv4OctetMinVal or d > ipv4OctetMaxVal) then
            return false
        end

    end

    -- no more validations needed.

    return true

end



--[[
--******************************************************************************
-- validations.tf1domainNameValidate  - validate domain name
--
--Returns: OK( no error ), ERROR
]]--
function validations.tf1domainNameValidate(domainName,lastOctateVal)
    local status = "ERROR"
    local node=""
    local addrTbl = {}
    local i = 1
    
    addrTbl = util.split(domainName, ".")
    local j = util.tableSize(addrTbl)
    if (validations.tf1checkDomainExtension(lastOctateVal) ~= "OK") then
        return status
    end

    for i,j in pairs(addrTbl) do
        node = addrTbl[i]
        if (string.len(node) > 63) then
            return status
        end
    end

    if (string.len(domainName) > 253 or string.len(domainName) < 1) then
        return status
    end

    if (validations.tf1checkSpecialChar(domainName)~= "OK") then
        return status
    end

    return "OK"
end

--[[
--******************************************************************************
-- validations.tf1checkDomainExtension  - validate domain name extension
--
--Returns: OK( no error ), ERROR
]]--

function validations.tf1checkDomainExtension(lastOctateVal)
    local ext = "." .. lastOctateVal
    local i=1
    local j=util.tableSize(domainNameExt)
    for i,j in pairs (domainNameExt)do
        if (ext == domainNameExt[i]) then 
            return "OK" 
        end
    end
    return "ERROR"
end

--[[
--******************************************************************************
-- validations.tf1checkSpecialChar  - validate domain name for special characters
--
--Returns: OK( no error ), ERROR
]]--

function validations.tf1checkSpecialChar(domainName)
     local exceptionChars = {'-','.'}
     local idx = 1
     local charCode = "" 
     local addrTbl = {}
     addrTbl = util.split(domainName, ".")
     local v= util.tableSize(addrTbl)
    
   for k,v in pairs(addrTbl) do
        for idx = 1, string.len(addrTbl[k]) do
            charCode = string.sub(addrTbl[k],idx,idx)
            charCode = string.byte(charCode)
            if (not((charCode >= 97 and charCode <= 122) or (charCode >= 65 and charCode <= 90) or (charCode >= 48 and charCode <= 57) or charCode == exceptionChars[1] or charCode == exceptionChars[2])) then
                
                return "ERROR"
            end
        end
   end
    local firstChar = string.sub(domainName,1,1)
    local lastChar = string.sub(domainName,string.len(domainName),string.len(domainName)) 
    if ((firstChar == exceptionChars[1] or firstChar == exceptionChars[2]) or (lastChar == exceptionChars[1] or lastChar == exceptionChars[2])) then
        return "ERROR"
    end
    return "OK"
end


-- check if the ip1 is less than ip2 or not 
-- if it is not less then it will return false
function validations.tf1compareIP(ip1,ip2)
    local lastOctate1 = ""
    local lastOctate2 = ""
    local ipAddTbl1 = {}
    local ipAddTbl2 = {}
    ipAddTbl1 = util.split(ip1, ".")
    ipAddTbl2 = util.split(ip2, ".")
    -- Get the last octet
    if (util.tableSize(ipAddTbl1)) then
        lastOctate1 = ipAddTbl1[util.tableSize(ipAddTbl1)]
    end
    if (util.tableSize(ipAddTbl2)) then
        lastOctate2 = ipAddTbl2[util.tableSize(ipAddTbl2)]
    end
    if (tonumber(lastOctate1) >= tonumber(lastOctate2)) then
        return "ERROR" 
    end
    return "OK"
end

--*************************************************************************************************
--validating ipv6 for linklocal and loopback 
--
function validations.is_ipv6_address (ipAddr)

    if((string.match(ipAddr,'^fe80')) or (string.match(ipAddr,'^FE80'))) then 
	    return false
    elseif(ipAddr == "::1") then
	    return false
    end

    return true
end

