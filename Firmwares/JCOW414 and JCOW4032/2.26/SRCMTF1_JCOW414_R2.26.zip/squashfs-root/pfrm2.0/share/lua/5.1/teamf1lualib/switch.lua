--[[
#### Mohan Kannekanti
#### TeamF1
#### www.TeamF1.com
#### Feb 10, 2012

#### File: swMgr.lua
#### Description: Switch Manager utility functions

#### Revisions:
None
]]--

require "swMgrLib"
require "teamf1lualib/db"
require "teamf1lualib/util"
require "teamf1lualib/swMgr"

switch = {}
switch.pauseFrame = {}
switch.prop = {}
switch.prop.qosEnable   = "qosEnable"
switch.prop.vlanEnable  = "vlanEnable"
switch.prop.pauseFrameEnable = "pauseFrameEnable"
switch.prop.numPorts    = "numPorts"
switch.prop.switchDevice= "switchDevice"
switch.prop.switchName  = "switchName"

--------------------------------------------------------------------------------------
-- Enumeration for switch property
-- @class table
-- @name switch.propType
--
-- @field switch.propType.SWITCH_PROP_8021P_STATUS      0,
-- @field switch.propType.SWITCH_PROP_8021Q_STATUS      1,
--

switch.propType = {
    SWITCH_PROP_8021P_STATUS  =   0,
    SWITCH_PROP_8021Q_STATUS  =   1,  
}

-------------------------------------------------------------------------------
-- @name switch.get 
--
-- @description This function gets the value of the switch property
--
-- @param switchName  switch name. 
-- @param property    property type. see switch.propType
--
-- @return status   - OK or ERROR
-- @return errCode   
-- @return value    - the value of the property
--

function switch.get (switchName, property)
    local status = "ERROR"
    local errCode = "SWMGR_ERR_INVALID_ARG"
    local value = ""

    -- Input validation 
    if (switchName == nil or property == nil) then
        return status, errCode
    end

    property = tonumber (property)

    if (property == switch.propType.SWITCH_PROP_8021P_STATUS) then
        value = db.getAttribute (swMgr.SWITCHTBL, 
                                 switch.prop.switchName,
                                 switchName, switch.prop.qosEnable)
        if (value == nil) then
            errCode = "SWMGR_ERR_8021P_STATUS"
            return status, errCode
        end
        
    elseif (property == switch.propType.SWITCH_PROP_8021Q_STATUS) then
        value = db.getAttribute (swMgr.SWITCHTBL, 
                                 swVlan.prop.switchName,
                                 switchName, swPort.prop.vlanEnable)
        if (value == nil) then
            errCode = "SWMGR_ERR_8021Q_STATUS"
            return status, errCode
        end
    else
        swMgr.dprintf("get: property: " .. property .. " not supported")
    end

    return "OK", "STATUS_OK", value
end

-------------------------------------------------------------------------------
-- @name switch.macVlanTblGet 
--
-- @description This function gets the list of vlans configured on this MAC.
--
-- @param name  interface name of the switch MAC on which the vlans have been created.
--
-- @return status   - OK or ERROR
-- @return errCode   
-- @return value    - vlan table
--

function switch.macVlanTblGet (name)
    local query
    local status = "ERROR"
    local errCode = "SWMGR_ERR_INVALID_ARG"
    local vlanTbl = {}

    if (name == nil) then
        return status, errCode
    end        

    query = "select * from " .. swMgr.SWITCHVLANTBL ..
            " where interfaceName = '" .. name .. "'"

    vlanTbl = db.getTable (swMgr.SWITCHVLANTBL, false, query)
    if (vlanTbl == nil) then 
        errCode = "SWMGR_ERR_VLAN_LIST"
        return status, errCode
    end

    return "OK","STATUS_OK", vlanTbl
end

-------------------------------------------------------------------------------
-- @name switch.macPortTblGet 
--
-- @description This function gets the list of PHY ports associated with this  MAC.
--
-- @param name  interface name of the switch MAC
--
-- @return status   - OK or ERROR
-- @return errCode   
-- @return value    - portTbl table
--

function switch.macPortTblGet (name)
    local query
    local status = "ERROR"
    local errCode = "SWMGR_ERR_INVALID_ARG"
    local portTbl = {}

    if (name == nil) then
        return status, errCode
    end        

    query = "select * from " .. swMgr.SWITCHPORTTBL ..
            " where interfaceName = '" .. name .. "'"

    portTbl = db.getTable (swMgr.SWITCHPORTTBL, false, query)
    if (portTbl == nil) then 
        errCode = "SWMGR_ERR_PORT_LIST"
        return status, errCode
    end

    return "OK","STATUS_OK", portTbl
end

-------------------------------------------------------------------------------
-- @name switch.pauseFrame.get 
--
-- @description This function gets the pause frame status in the switch
--
-- @param  switchName - Switch Name
--
-- @return status - OK on Success, ERROR on Failure
-- @return errCode - Error String
-- @return pauseFrameStatus - Pause Frame Status
--
-- @seealso switch.pauseFrame.set
--

function switch.pauseFrame.get(switchName)
    local pauseFrameStatus
    
    if (switchName == nil) then
        return "ERROR", "SWMGR_ERR_INVALID_ARG"
    end

    pauseFrameStatus = db.getAttribute (swMgr.SWITCHTBL, switch.prop.switchName,
                                        switchName, switch.prop.pauseFrameEnable)

    if (pauseFrameStatus == nil) then
        swMgr.dprintf ("pauseFrame.get: Failed to get the pause frame values")
        return "ERROR", "SWMGR_ERR_PAUSE_FRAME_GET"
    end

    return "OK", "STATUS_OK", tostring(pauseFrameStatus)
end

-------------------------------------------------------------------------------
-- @name switch.pauseFrame.set 
--
-- @description This function enable the pause frame in the switch
--
-- @param  switchName - Switch Name
-- @param  pauseFrameStatus - Pause Frame Status
--
-- @return status - OK on Success, ERROR on Failure
-- @return errCode - Error String
--
-- @seealso switch.pauseFrame.get
--

function switch.pauseFrame.set(switchName, pauseFrameStatus)
    local status
    local errCode

    if (switchName == nil or pauseFrameStatus == nil) then
        return "ERROR", "SWMGR_ERR_INVALID_ARG"
    end

    status, errCode = swMgrLib.pauseFrameSet (switchName, pauseFrameStatus)
    if (status < 0) then
        return "ERROR", errCode
    end

    customQuery = "update swGlobalCfg set pauseFrameEnable = '" .. pauseFrameStatus .. "'"

    db.execute (customQuery)
    
    return "OK", "STATUS_OK"
end
