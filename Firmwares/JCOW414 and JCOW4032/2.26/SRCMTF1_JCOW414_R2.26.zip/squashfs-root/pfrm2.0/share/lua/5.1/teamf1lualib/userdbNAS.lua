-- userdbNAS.lua - contains NAS related operations

-- Copywrite (c) 2010 TeamF1, Inc.

--[[
 * modification history
 * --------------------
 * 01c,21apr10,pnm  added check if configTable in import routine
 * 01b,08apr10,pnm  added export support for groups of users
 * 01a,30mar10,pnm  written.
--]]

--[[
 * DESCRIPTION
 * Describe the routines required by the NAS component
--]]

--************* Requires *************
require "teamf1lualib/userdb"

--*****************************************************************************
--userdb.shareExportUsers - exports users related info
--
--This routine exports users related info
--
--RETURN: Table with users info
function userdb.shareExportUsers (nasShareTbl, groupsTbl)
    -- local declarations
    local where = nil

    -- iterate through share list
    for i,v in ipairs (nasShareTbl) do
        if (v["userOwner"] ~= nil) then
            if (where == nil) then
                where = "username='" .. v ["userOwner"] .. "'"
            else
                where = where .. "OR username='"..v ["userOwner"] .. "'"
            end
        end
    end

    -- Check if the group list is not nil
    if (groupsTbl == nil) then
        return nil
    end

    -- iterate through the group list
    local groupList = nil
    local userTbl = db.getTable ("users", false)
    for i,v in ipairs (groupsTbl) do
        if (groupList == nil) then
            groupList = v["name"]
        else
            groupList = groupList .. "," .. v["name"]
        end
        for j,w in ipairs (userTbl) do
            if (string.find (w["groupname"], v["name"]) ~= nil) then
                if (where == nil) then
                    where = "username='" .. w["username"] .. "'"
                else
                    where = where .. "OR username='" .. w["username"] .. "'"
                end
                if (groupList == nil) then
                    groupList = w["groupname"]
                else
                    groupList = groupList .. "," .. w["groupname"]
                end
            end
        end
    end

    -- Convert the group list from comma separated list to table
    local tbl = {}
    if (where ~= nil) then
        tbl["users"] = db.getRowsWhere ("users", where, false)
    end
    if (groupList ~= nil) then
        
        local finalGroupTbl = util.split (groupList, ",")
        where = nil
        for i,v in pairs (finalGroupTbl) do
            if (where == nil) then
                where = "name='" .. v .. "'"
            else
                where = where .. " OR name='" .. v .. "'"
            end
        end
        if (where ~= nil) then
            tbl["groups"] = db.getRowsWhere ("groups", where, false)
        end
    end
    return tbl
end

--*****************************************************************************
--userdb.shareExportGroups - exports groups related info
--
--This routine exports groups related info
--
--RETURN: Table with groups info
function userdb.shareExportGroups (nasShareTbl)
    -- local declarations
    local where = nil

    -- Iterate through share list
    local groupTbl
    for i,v in ipairs (nasShareTbl) do
        if (v["groupOwner"] ~= nil) then
            groupTbl = util.split (v["groupOwner"], ",")
            for j,w in ipairs (groupTbl) do
                if (where == nil) then
                    where = "name='"..w.."'"
                else
                    where = where .. "OR name='" .. w .. "'"
                end
            end
        end
    end

    -- execute the query and return results
    if (where ~= nil) then
        return db.getRowsWhere ("groups", where, false)
    end
end

--*****************************************************************************
--userdb.shareExport - exports userdb related shares
--
--This routine exports user db related shares given the list of share
--names to export.
--
--RETURNS: table with share info
function  userdb.shareExport (nasShareTbl)
    -- local declarations
    local tbl = {}

    -- Get list of groups
    tbl["groups"] = userdb.shareExportGroups (nasShareTbl)

    -- get the user list
    tbl = userdb.shareExportUsers (nasShareTbl, tbl["groups"])

    return tbl
end

--*****************************************************************************
--userdb.shareImportGroups - imports groups
--
--This routine imports groups.
--
--RETURNS: nothing
function userdb.shareImportGroups (tbl)
     local found

     -- Get list of groups in the DB
     local dbGroupsTbl = db.getTable ("groups", false)
     for j,w in ipairs (tbl) do
         found = false

         -- Iterate through group list provided
         for i,v in ipairs (dbGroupsTbl) do
             if (v["name"] == w["name"]) then
                 found = true
                 break
             end
         end

         -- Check if the group is found in the DB
         if (found == false) then
             w = util.addPrefix (w, "groups.");
             userdb.addGroup (w);
         end
     end

end

--*****************************************************************************
--userdb.shareImportUsers - imports users
--
--This routine imports users.
--
--RETURNS: nothing
function userdb.shareImportUsers (tbl)
     local found

     -- Get list of users in the DB
     local dbUsersTbl = db.getTable ("users", false)
     for j,w in ipairs (tbl) do
         found = false

         -- Iterate through user list provided
         for i,v in ipairs (dbUsersTbl) do
             if (v["username"] == w["username"]) then
                 found = true
                 break
             end
         end

         -- Check if the user is found in the DB
--[[
         if (found == false) then
             w = util.addPrefix (w, "users.");
             -- Avoiding .teamf1MetaData users updation into users table
             status, statusStr = userdb.users_config (w, -1, "add");
             if (status == "ERROR") then
                 return status, statusStr
             end
         end
--]]
     end

end

--*****************************************************************************
--userdb.shareImport - imports userdb related shares
--
--This routine imports user db related shares given the users and group info.
--
--RETURNS: nothing
function userdb.shareImport (configTable)
    local status
    if (configTable == nil) then
        return true
    end
    if (configTable["groups"] ~= nil) then
        status, statusStr = userdb.shareImportGroups (configTable["groups"])
        if (status == "ERROR") then
            return status, statusStr
        end
    end

    if (configTable["users"] ~= nil) then
        status, statusStr = userdb.shareImportUsers (configTable["users"])
        if (status == "ERROR") then
            return status, statusStr
        end

    end
end

--register to partitionMgmt service
if (partitionMgmt and partitionMgmt.shareConfigRegister) then
    partitionMgmt.shareConfigRegister ("userdb", userdb.shareImport,
                    userdb.shareExport)
end

