-- @copyright Copyright (c) 2012, TeamF1, Inc. 

network = {}
network.debug = 0

require "teamf1lualib/networkDefaults"

-------------------------------------------------------------------------------
-- @name network.create
--
-- @description This function creates a new network interface and registers
-- it to the TeamF1 management. <br/>
--
-- @param conf  interface configuration. The conf table has the following fields 
--
-- <ul>
-- <li><i>networkName</i>   Name of this network.
-- <li><i>enable</i>        Enable/disable network after creation
-- <li><i>connectionType</i>          association with other networks.
--    Format: mode:networkName,... where mode=ROUTED/SWITCHED/BRIDGED
-- <li><i>mac</i>    custom mac address for this network
-- <li><i>mtu</i>           custom MTU for this network
-- <li><i>zoneType</i>     LAN/WAN/DMZ or SECURE/INSECURE/PUBLIC
-- <li><i>portTbl</i>      table of network ports that are part of this network. This
--  table contains the following fields
--      <ul>
--      <li><i>name</i>    device name  
--      <li><i>ifname</i>  interface name
--      <li><i>type</i>    device type Ex: switch or radio or ethernet
--      <li><i>port</i>    port number  
--      <li><i>default</i> 1 if this port is the default member else 0
--      </ul>
-- </ul>
--
-- @return  status  OK or ERROR
-- @return  errCode reason for error or STATUS_OK
-- @return  netIf   interface that has been created.
--

function network.create(conf)
    local status="ERROR"
    local errCode=""
    local netIf = nil
    require "teamf1lualib/ifDev"

    gui.dprintf("Creating network with configuration:" ..
                util.tableToStringRec(conf))
    
    -- validate input parameters 
    status, errCode = network.ifParamsValidate(conf)
    if (status == "ERROR") then
        network.dprintf("network create: invalid params " .. errCode)
        errCode = "NET_ERR_INVALID_PARAMS"
        return status, errCode        
    end        

    -- generate a logical interface name for this network
    if (conf["LogicalIfName"] == nil) then
        conf["LogicalIfName"] = ifDev.lNameGen()
    end

    if (conf["networkId"] == nil) then
        conf["networkId"] = string.gsub (conf["LogicalIfName"], "IF", "")
    end                        

    -- generate group and marks for the interface 
    if (platformLib.strcasecmp(conf["zoneType"], "secure") == 0 or 
        platformLib.strcasecmp(conf["zoneType"], "public") == 0) then
        conf["ifGroupId"] = ifDev.ifGroup.IFDEV_GROUPID_SECURE
    else
        conf["ifGroupId"] = ifDev.ifGroup.IFDEV_GROUPID_UNSECURE
    end

    local ifSuffix = string.sub (conf["LogicalIfName"], string.len("IF")+1)
    conf["ifMark"] = math.pow (2, tonumber(ifSuffix)-1)

    if (conf["portTbl"] ~= nil) then
        -- create interface 
        status, errCode, netif = network.ifCreate(conf)
        if (status == "ERROR") then
            network.dprintf("network create: failed to create interface")
            return status, errCode
        end        
    else
        netif = conf
        netif["ifType"] = "bridge"
        netif["interfaceName"] = "dummy"
        netif["enable"] = 0
    end

    -- register the network
    status, errCode = network.register(netif)
    if (status == "ERROR") then
        network.dprintf("network create: failed to register interface")
        return status, errCode
    end        

    -- check if the network has layer 3 connectivity
    if (network.hasL3Object(conf)) then

        -- add ipv4 configuration
        local ipv4Conf = conf["ipv4"]
        if ((ipv4Conf ~= nil) and (nimfConn.IDValidate(ipv4Conf) == "OK")) then
            status, errCode = nimfConn.configure(ipv4Conf)
            if (status ~= "OK") then
                return status, errCode        
            end        
        end
    
        -- add ipv6 configuration
        local ipv6Conf = conf["ipv6"]
        if ((ipv6Conf ~= nil) and (nimfConn.IDValidate(ipv6Conf) == "OK")) then
            status, errCode = nimfConn.configure(ipv6Conf)
            if (status ~= "OK") then
                return status, errCode        
            end        
        end
    end

    return "OK", "STATUS_OK", netIf
end

-------------------------------------------------------------------------------
-- @name network.configure
--
-- @description This function configures the network with the given configuration
--
-- @param name  name of the network to be configured.
-- @param conf  array of network configuration have the following fields
-- <ul>
-- <li><i> AddressFamily</i>     network protocol of the connection
-- <li><i> Enable</i>            enable/disable connection
-- <li><i> ConnectionType</i>    type of the network connection. see nimf.method table   
-- <li><i> StaticIp</i>          static IP address to be configured for this network
-- <li><i> PrefixLength</i>      prefix length if static IP address is an IPv6 address.
-- <li><i> NetMask</i>           netmask if static IP address is an IPv4 address
-- <li><i> Gateway</i>           Gateway router IP address of this network
-- <li><i> PrimaryDns</i>        Primary DNS server IP address of this network
-- <li><i> SecondaryDns</i>      Secondary DNS server IP address of this network
-- <li><i> IdleDisconnectTime</i> Idle Timeout in case of PPP connections   
-- <li><i> Username</i>          username for PPP authentication
-- <li><i> Password</i>          password for PPP authentication
-- <li><i> GetIpFromIsp</i>      1 if this network gets IP parameters from ISP
-- <li><i> GetDnsFromIsp</i>     1 if this network gets DNS from ISP
-- <li><i> AccountName</i>       account name to be used for the PPP connection
-- <li><i> DomainName</i>        domain name to be used for the PPP connection
-- <li><i> AuthOpt</i>           list of authentication protocol to be used for PPP
-- <li><i> MyIPAddress</i>       IP address to be configured for this network for PPTP 
-- <li><i> ServerIP</i>          IP address of the PPTP server
-- <li><i> StatelessMode</i>     DHCPv6 client mode
-- </ul>
--
-- @return  status  OK or ERROR
-- @return  errCode reason for error or STATUS_OK
--

function network.configure (name, conf)
    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"
    local cfg = {}
    require "teamf1lualib/ifDev"

    if ((name == nil) or (conf == nil)) then
        return status, errCode        
    end        

    if (type(conf) ~= "table") then
        return status, errCode        
    end
            
    -- get interface configuration                        
    status, errCode, ifcfg = ifDev.cfgByNameGet(name)
    if (status ~= "OK") then
        return status, errCode        
    end        

    if (conf[1] == nil) then
        cfg[1] = conf
    else
        cfg = conf        
    end        

    for k,v in pairs(cfg) do
        status , errCode = network.cfgHelper(ifcfg, v)
        if (status ~= "OK") then
            return status, errCode        
        end        
    end    
    
    return status, errCode
end

-------------------------------------------------------------------------------
-- @name network.deconfigure
--
-- @description This function de-configures the connections on this network
--
-- @param name  name of the network to be de-configured
-- @param conf  Optional configuration table having the following fields
-- <ul>
-- <li><i> AddressFamily</i>     network protocol of the connection
-- </ul>
--
-- @return  status  OK or ERROR
-- @return  errCode reason for error or STATUS_OK
--

function network.deconfigure (name, conf)
    require "teamf1lualib/nimf"
    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"
    local ifcfg = {}
    local query = nil

    if (conf == nil) then
        conf = {}

        if (name == nil) then
            network.dprintf("network.deconfigure: Invalid argument")
            return status, errCode        
        end        

        -- get interface configuration                        
        status, errCode, ifcfg = ifDev.cfgByNameGet(name)
        if (status ~= "OK") then
            network.dprintf("network.deconfigure:failed to get configuration for:" .. name)
            return status, errCode        
        end        

        conf["LogicalIfName"] = ifcfg["LogicalIfName"]
        conf["AddressFamily"] =  nimf.proto.NIMF_PROTO_TYPE_IPV4
        status, errCode = nimfConn.deconfigure (conf)
        if (status ~= "OK") then
            network.dprintf("network.deconfigure:failed to deconfigure " .. conf["LogicalIfName"])
            return status, errCode        
        end        

        conf["AddressFamily"] =  nimf.proto.NIMF_PROTO_TYPE_IPV6
        status, errCode = nimfConn.deconfigure (conf)
        if (status ~= "OK") then
            network.dprintf("network.deconfigure:failed to deconfigure " .. conf["LogicalIfName"])
            return status, errCode        
        end        
    else

        status, errCode = nimfConn.deconfigure (conf)
        if (status ~= "OK") then
            network.dprintf("network.deconfigure:failed to deconfigure " .. conf["LogicalIfName"])
            return status, errCode        
        end        
    end

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name network.enable
--
-- @description This function brings up the network and starts all
-- protocols configured 
--
-- @param name name of the network to enable
--
-- @return  status  OK or ERROR
-- @return  errCode reason for error or STATUS_OK
--

function network.enable(name)
    local status = "ERROR"
    local errCode = ""
    local ifcfg

    if (name == nil) then
        return status, errCode
    end

    require "teamf1lualib/ifDev"

    -- get interface configuration                        
    status, errCode, ifcfg = network.ifConfGet(name)
    if (status ~= "OK") then
        return status, errCode        
    end        

    -- disable interfaces
    local isABridge = ifDev.isANetworkBridge(name)
    if (isABridge > 0) then
        require "teamf1lualib/bridgeLib"
        local bdgIfName

        -- Network is a bridged with other networks 
        bdgIfName = ifcfg["interfaceName"]
        local bridgedWithNetworks, assoc = 
                        network.hasBridgedAssoc(ifcfg["connectionType"])
        if (bridgedWithNetworks) then                        
            bdgIfName = assoc["interfaceName"]
        end            

        -- Enable its ports
        network.dprintf("Enabling ports: " .. util.tableToStringRec(ifcfg["nativeIfs"]) .. 
                       " on " .. bdgIfName)

        status, errCode = bridge.portEnable(bdgIfName, ifcfg["nativeIfs"])
        if (status ~= "OK") then
            network.dprintf("failed to enable network ports for: " .. name)
            return status, errCode
        end            
    end

    ifDev.set(ifcfg["networkName"], ifDev.propType.IFDEV_PROP_TYPE_STATUS, "1")

    require "teamf1lualib/nimf"
    -- start the network
    status, errCode = nimf.netEnable(ifcfg["LogicalIfName"])
    if (status ~= "OK") then
        return status, errCode        
    end        

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name network.edit
--
-- @description This function edits the network interface. 
--
-- @return  status  OK or ERROR
-- @return  errCode reason for error or STATUS_OK
--

function network.edit (name, newConf)
    require "teamf1lualib/nimf"
    local status = "ERROR"
    local errCode = ""

    if ((name == nil) or (newConf == nil)) then
        return status, errCode        
    end        

    -- validate configuration
    status, errCode = network.ifParamsValidate(newConf)
    if (status ~= "OK") then
        --errCode = "NET_ERR_INVALID_PARAMS"
        return status, errCode        
    end        

    network.dprintf("network.edit: Applying CONF for" .. name .. 
                    ":<br>" .. util.tableToStringRec(newConf))

    -- edit interface
    status, errCode = network.ifEdit(name, newConf)
    if (status ~= "OK") then
        return status, errCode        
    end        

    -- check if the network has layer 3 connectivity
    if (network.hasL3Object(newConf)) then

        -- edit ipv4 configuration
        local ipv4Conf = newConf["ipv4"]
        if ((ipv4Conf ~= nil) and (nimfConn.IDValidate(ipv4Conf) == "OK")) then
            status, errCode = nimfConn.configure(ipv4Conf)
            if (status ~= "OK") then
                return status, errCode        
            end        
        end
    
        -- edit ipv6 configuration
        local ipv6Conf = newConf["ipv6"]
        if ((ipv6Conf ~= nil) and (nimfConn.IDValidate(ipv6Conf) == "OK")) then
            status, errCode = nimfConn.configure(ipv6Conf)
            if (status ~= "OK") then
                return status, errCode        
            end        
        end
    end

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name network.disable
--
-- @description This function disables the network
--
-- @param name name of the network to disable
--
-- @return  status  OK or ERROR
-- @return  errCode reason for error or STATUS_OK
--

function network.disable(name)
    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"
    local ifcfg = {}

    if (name == nil) then
        return status, errCode
    end
            
    require "teamf1lualib/ifDev"
    -- get interface configuration                        
    status, errCode, ifcfg = network.ifConfGet(name)
    if (status ~= "OK") then
        return status, errCode        
    end        
    
    --Check selected network has untagged 
    --association with some port or not,  
    --if exists then return  error
    --
    local untagMap = db.getAttribute("vlanEncapIf", 
                                       "LogicalIfName", ifcfg["LogicalIfName"], "untagMap")
    if(untagMap ~= "") then
	local tbl = network.stringSplitter(',', untagMap)
	local portSwapUntagMap = ""
	for i,v in pairs(tbl) do
		if (tonumber(v) == 1) then
	    		if(portSwapUntagMap == "") then
            			portSwapUntagMap = portSwapUntagMap .. "4"
	    		else
            			portSwapUntagMap = portSwapUntagMap .. ",4"
	    		end
        	elseif (tonumber(v) == 2) then
            		if(portSwapUntagMap == "") then
            			portSwapUntagMap = portSwapUntagMap .. "3"
	    		else
            			portSwapUntagMap = portSwapUntagMap .. ",3"
	    		end
        	elseif (tonumber(v) == 3) then
            		if(portSwapUntagMap == "") then
            			portSwapUntagMap = portSwapUntagMap .. "2"
	    		else
            			portSwapUntagMap = portSwapUntagMap .. ",2"
	    		end
        	elseif (tonumber(v) == 4) then
            		if(portSwapUntagMap == "") then
            			portSwapUntagMap = portSwapUntagMap .. "1"
	    		else
            			portSwapUntagMap = portSwapUntagMap .. ",1"
	    		end
        	elseif (tonumber(v) == 5) then
            		if(portSwapUntagMap == "") then
            			portSwapUntagMap = portSwapUntagMap .. "5"
	    		else
            			portSwapUntagMap = portSwapUntagMap .. ",5"
	    		end
        	end
	end

	if(ifcfg["zoneType"] == "secure") then
    		return "ERROR", "Selected Network can't be disabled as it has default association with Port(s) " .. portSwapUntagMap .. ". Make default association of specified ports with other LAN Network then disable! "
	else
    		return "ERROR", "Selected Network can't be disabled as it has default association with Port " .. portSwapUntagMap .. ". Make default association of specified ports with other WAN Network then disable! "
	end
    end

    -- stop the network
    require "teamf1lualib/nimf"
    status, errCode = nimf.netDisable(ifcfg["LogicalIfName"])
    if (status ~= "OK") then
        return status, errCode        
    end        

    -- disable interfaces
    local isABridge = ifDev.isANetworkBridge(name)
    if (isABridge > 0) then
        require "teamf1lualib/bridgeLib"
        local bdgIfName

        -- Network is a bridged with other networks 
        bdgIfName = ifcfg["interfaceName"]
        local bridgedWithNetworks, assoc = 
                        network.hasBridgedAssoc(ifcfg["connectionType"])
        if (bridgedWithNetworks) then                        
            bdgIfName = assoc["interfaceName"]
        end            

        -- Disable its ports
        status, errCode = bridge.portDisable(bdgIfName, ifcfg["nativeIfs"])
        if (status ~= "OK") then
            network.dprintf("failed to disable network ports for: " .. name)
            return status, errCode
        end            
    end

    ifDev.set(ifcfg["networkName"], ifDev.propType.IFDEV_PROP_TYPE_STATUS, "0")

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name network.stringSplitter
--
-- @description This function separates a given 
-- string into sub strings based on the delimiter
-- then insert the sub strings into a table
--
-- @returns the table after inserting sub strings

function network.stringSplitter(delimiter, inputString)
    local list = {}
    local pos = 1
    while 1 do
        local first, last = string.find(inputString, delimiter, pos)
        if first then
            table.insert(list, string.sub(inputString, pos, first-1))
            pos = last+1
        else
            table.insert(list, string.sub(inputString, pos))
            break
        end
    end
  return list
end

-------------------------------------------------------------------------------
-- @name network.destroy
--
-- @description This function deconfigures the network and deletes the
-- associated network interfaces.
--
-- @param <i>name>/i> name of the network to destroy
--
-- @return  status  OK or ERROR
-- @return  errCode reason for error or STATUS_OK
--

function network.destroy(name)
    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"
    local conf = {}

    if (name == nil) then
        return status, errCode
    end

    -- check if any other networks are associated with this network
    status, errCode, assocList = network.assocNetListGet (name)
    if ((status == "OK") and (util.tableSize(assocList) > 0)) then
        network.dprintf("destroy: other networks are associated with this network")
        return status, "NET_ERR_ASSOCLIST_EXISTS"
    end        

    -- get interface configuration                        
    status, errCode, conf = network.ifConfGet(name)
    if (status ~= "OK") then
        network.dprintf("destroy: failed to get network(" .. name .. ") conf ")
        return status, errCode        
    end        

    -- Check if any network connections are running
    if (tonumber(conf["enable"]) > 0) then
        network.dprintf("destroy: connections for network(" .. name .. ") are running")
        return "ERROR", "NET_ERR_CONN_RUNNING_DISABLE_FIRST"
    end        

    -- deconfigure all L3 connections
    if (network.hasL3Object(conf)) then
        status, errCode = network.deconfigure (name)
        if (status ~= "OK") then
            network.dprintf("destroy: failed to deconfigure network(" .. name .. ") ")
            return status, errCode        
        end        
    end

    require "teamf1lualib/ifDev"

    -- bring down the interface
    status, errCode = ifDev.netDown(name)
    if (status ~= "OK") then
        network.dprintf("destroy: failed to bring down network(" .. name .. ") ")
        return status, errCode        
    end        

    -- destroy the interface
    status, errCode = network.ifDestroy(conf)
    if (status ~= "OK") then
        network.dprintf("destroy: failed to destroy (" .. name .. ") ")
        return status, errCode        
    end        

    -- unregister the network 
    status, errCode = network.unregister(conf)
    if (status == "ERROR") then
        network.dprintf("destroy: failed to unregister (" .. name .. ") ")
        return status, errCode
    end        

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name network.statusGet
--
-- @description This function gets the network configuration, status and
-- statistics.
--
-- @param name name of the network
--
-- @return  status  OK or ERROR
-- @return  errCode reason for error or STATUS_OK
-- @return  statusTbl  table containing the network status 
--

function network.statusGet(name)
    local net = {}
    local status = "ERROR"
    local errCode = ""
    local conf = {}
    local statusTbl = {}
    local connID = {}

    -- get interface configuration
    status, errCode, conf = network.ifConfGet(name)
    if (status ~= "OK") then
        return status, errCode        
    end        

    -- get interface state/statistics
    net = ifDevLib.netIfInfoGet (conf["LogicalIfName"])
    if (net == nil) then
        return status, errCode        
    end        

    -- set interface configuration
    net.ifconf = conf
    
	require ("teamf1lualib/nimf")
    connID["LogicalIfName"] = net["LogicalIfName"]

    -- get IPv4 status
    net.ipv4 = {}
    connID["AddressFamily"] = nimf.proto.NIMF_PROTO_TYPE_IPV4
    status, errCode, conf = nimfConn.confGet (connID)
    if (status == "OK") then
        net.ipv4["conf"] = conf

        status, errCode, statusTbl = nimfConn.statusGet (connID)
        if (status == "OK") then
            net.ipv4["status"] = statusTbl
        end        
    end        

    -- get IPv6 configuration
    net.ipv6 = {}
    connID["AddressFamily"] = nimf.proto.NIMF_PROTO_TYPE_IPV6
    status, errCode, conf = nimfConn.confGet (connID)
    if (status == "OK") then
        net.ipv6["conf"] = conf

        status, errCode, statusTbl = nimfConn.statusGet (connID)
        if (status == "OK") then
            net.ipv6["status"] = statusTbl
        end        
    end        

    return "OK", "STATUS_OK", net
end

--
--
--      INTERNAL FUNCTIONS
--
--

--[[
*******************************************************************************
-- @name network.ifParamsValidate
--
-- @description 
--
-- @param conftable
--
-- @return 
--
--]]

function network.ifParamsValidate (conf)
    local status =  "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"
    require "teamf1lualib/ifDev"

    if (conf == nil) then
        return status, errCode
    end
            
    -- check MAC address 
    if ((conf["MACAddress"] ~= nil) and (string.len(conf["MACAddress"]) > 0))  then
        if (ifDevLib.macAddrCheck (conf["MACAddress"]) == nil) then
            errCode ="NET_ERR_INVALID_MAC_ADDRESS"
            return status, errCode
        end            
    end        

    -- check MTU 
    if ((conf["MTU"] ~= nil) and (tonumber(conf["MTU"]) < 0))  then
        errCode ="NET_ERR_INVALID_MTU"
        return status, errCode
    end        

    -- check ZoneType
    if (ifDev.zoneValidate(conf["zoneType"]) == "ERROR") then
        return "ERROR", "NET_ERR_INVALID_ZONE"
    end        

    -- check connectionType
    if (platformLib.strcasecmp(conf["zoneType"], "secure") == 0) then
        if (ifDev.modeValidate(conf["connectionType"])  == "ERROR") then
            return "ERROR", "NET_ERR_INVALID_MODE"
        end        
    end

    -- validate the port table            
    if (conf.portTbl ~= nil) then
        status, errCode = network.portTblValidate(conf.portTbl) 
        if (status == "ERROR") then
            return status, errCode
        end        
    end
    
    return "OK","STATUS_OK"
end

--[[
*******************************************************************************
-- @name network.portTblValidate
--
-- @description This function checks if all the devices in the port table and 
-- the port number(s) of the corresponding device is valid.
--
-- @param portTbl table of port associations for this network
--
-- @return 
--]]

function network.portTblValidate (portTbl)
    require "teamf1lualib/swPort"
    local status =  "ERROR"
    local errCode = "NET_ERR_INVALID_PORT_ASSOC"

    if (portTbl == nil) then
        return status, errCode        
    end
            
    if (type(portTbl) ~= "table") then
        return status, errCode        
    end                    
                
    for k,v in pairs(portTbl) do
        
        -- get the interface type
        if (v["type"] == "switch") then
            -- check if v.port is valid
            if (swPort.isValid(v["ifname"], v["port"]) == 0) then
                return "ERROR", "NET_ERR_INVALID_PORT"
            end                
        elseif (v["type"] == "radio") then
        end            
    end
                            
    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- @name network.ifDestroy
--
-- @description This function destroys all the interfaces that were part 
-- of the given network.
--
-- @param conf  interface configuration
--
-- @return  status OK or ERROR
-- @return  errCode
--]]

function network.ifDestroy (conf)
    local port = nil
    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"

    if (conf == nil) then
        return status, errCode
    end
            
    local ifTbl = conf["ifTbl"]
    if (ifTbl == nil) then
        network.dprintf("ifDestroy: No interface(s) configured for " ..
                        "network(" .. conf["networkName"] .. ") ")
        return "OK", "STATUS_OK"
    end
            
    -- 
    -- detach the network interface(s) that
    -- belong to this network.
    --
    status, errCode, ifTbl = network.ifDetach(conf)
    if (status ~= "OK") then
        network.dprintf("ifDestroy: failed to detach interfaces for " ..
                        "network(" .. conf["networkName"]  .. ") ")
        return status, errCode        
    end        

    --
    -- Delete all the interfaces.
    --
    if (ifTbl ~= nil) then
        status, errCode = network.ifTypeDelete(ifTbl)
        if (status ~= "OK") then
            network.dprintf("ifDestroy: failed to delete interfaces for " ..
                            "network(" .. conf["networkName"]  .. ") ")
            return status, errCode        
        end        
    end

    if (ifDev.isANetworkBridge(conf) > 0) then
        -- Destroy the bridge.
        local bdgIfName = bridge.ifNameGet(conf["LogicalIfName"])
        network.dprintf("ifDestroy: deleting interface " .. bdgIfName)
        status, errCode = bridge.destroy(bdgIfName)
        if (status ~= "OK") then
            network.dprintf("ifDestroy: failed to destroy network interface for " ..
                            "network(" .. conf["networkName"]  .. ") ")
            return status, errCode
        end                
    end

    return  "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- @name network.switchIfEdit
--
-- @description This function edits the configurtion of the ethernet switch
-- and creates/edits the necessary vlan interfaces.
--
-- @return  status  OK or ERROR
-- @return  errCode reason for error or STATUS_OK
--
--]]

function network.switchIfEdit (newConf, currCfg)
    require "teamf1lualib/swVlan"
    local status="ERROR"
    local errCode="NET_ERR_SWIF_EDIT"

    if (network.hasSwitchPortMapChanged(currCfg["nativePorts"],
                                        newConf["nativePorts"], "vlan") > 0 ) then
        -- 
        -- check if the new configuration has switch ports as members
        --
        if (network.hasSwitchPort(newConf["portTbl"] ~= nil)) then
            -- Edit vlan membership since the port association has changed
            status, errCode = swVlan.mapEdit(newConf["vlanId"] , newConf["portTbl"])
            if (status ~= "OK") then
                network.dprintf("failed to edit vlan for network:" .. newConf["networkName"])
                return status, errCode
            end                
        else            
            --
            -- The new configuration of the network does not have a
            -- switch port. Mark VLAN termination interface (ethX.<ID>) 
            -- for deletion from the current network
            --
            -- TODO: ASSUMES Only one vlan interface is part of the network.
            -- Currently linux bridge does not support VLANs
            --
            local port = network.ifByTypeGet(currCfg["nativeIfs"],"vlan")
            if (port ~= nil) then
                table.insert(newConf["delIfTbl"], port)
            end
        end
    end

    -- The network ID is also the VLAN ID of the network.
    -- if VLAN ID has changed, we need to delete the existing VLAN 
    -- termination interface (ethX.<ID>) and create a new one.
    --
    local oldVlanId = nil
    status, errCode, oldVlanId =  network.vlanIDGet (currCfg)
    if (status ~= "OK") then
        return status, errCode
    end        
    oldVlanId  = tonumber(oldVlanId)

    require "teamf1lualib/swVlan"
    if (newConf["vlanId"] == nil) then
        newConf["vlanId"] = oldVlanId
    else        
        -- check if the new vlanID is valid
        if (swVlan.isValid(newConf["vlanId"]) ~= true) then
            network.dprintf("switchIfEdit: Invalid vlan ID specified")
            return status, errCode
        end        
        newConf["vlanId"] = tonumber(newConf["vlanId"])
    end

    if (newConf["vlanId"] ~= oldVlanId) then

        -- Mark VLAN for deletion 
        if (oldVlanId ~= nil) then
            local port = network.ifByTypeGet(currCfg["nativeIfs"], "vlan")
            if (port ~= nil) then
                table.insert(currCfg["delIfTbl"], port)
            end
        end

        -- create vlan with new configuration
        status, errCode, newIf = network.vlanCreate(newConf)
        if (status ~= "OK") then
            return status, errCode
        end                

        local newPort = {}
        newPort["ifname"] = newIf
        newPort["type"] = "vlan"
        newPort["LogicalIfName"] = currCfg["LogicalIfName"]
        table.insert(newConf["addIfTbl"], newPort)
    end
            
    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- @name network.wirelessIfEdit
--
-- @description 
--
-- @return  status  OK or ERROR
-- @return  errCode reason for error or STATUS_OK
--
--]]

function network.wirelessIfEdit (newConf, currCfg)
    local addedPorts, deletedPorts = 
        network.getChangedPorts(currCfg["nativePorts"], newConf["nativePorts"], "vap")

    if (util.tableSize(addedPorts) > 0) then 
        newConf["addIfTbl"] = util.tableAppend(newConf["addIfTbl"], addedPorts)

        for k,v in pairs(addedPorts) do
            network.dprintf("wirelessIfEdit: add vap:" ..  v["ifname"] .. 
                            " to network:" .. newConf["networkName"])
            local status, errCode = network.vapAdd(v)
            if (status == "ERROR") then
                network.dprintf("wirelessIfEdit: failed to add vap:" ..  v["ifname"] .. 
                                "from network:" .. newConf["networkName"])
                return status, errCode        
            end       
        end        
    end
            
    if (util.tableSize(deletedPorts) > 0) then 
        newConf["delIfTbl"] = util.tableAppend(newConf["delIfTbl"], deletedPorts)

        for k,v in pairs(deletedPorts) do
            network.dprintf("wirelessIfEdit: remove vap:" ..  v["ifname"] .. 
                            " from network:" .. newConf["networkName"])
            local status, errCode = network.vapRemove(v)
            if (status == "ERROR") then
                network.dprintf("wirelessIfEdit: failed to remove vap:" ..  v["ifname"] .. 
                                "from network:" .. newConf["networkName"])
                return status, errCode        
            end       
        end        
    end

    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- @name network.bridgeEdit
--
-- @description 
--
-- @return  status  OK or ERROR
-- @return  errCode reason for error or STATUS_OK
--
--]]

function network.bridgeEdit (newConf, currCfg)
    local status
    local errCode
 
    require "teamf1lualib/bridgeLib"

    status, errCode = bridge.edit(newConf)
    return status, errCode        
end


--[[
*******************************************************************************
-- @name network.modeChange
--
-- @description 
--
-- @return  status  OK or ERROR
-- @return  errCode reason for error or STATUS_OK
--
--]]

function network.modeChange(currCfg, newConf)                                
    local status
    local errCode

    -- stop the network
    require "teamf1lualib/nimf"
    status, errCode = nimf.netDisable(currCfg["LogicalIfName"])
    if (status ~= "OK") then
        return status, errCode        
    end        

    -- Remove all the interfaces
    status, errCode, ifTbl = network.ifDetach(currCfg)
    if (status ~= "OK") then
        return status, errCode        
    end        

    -- Re-add the interfaces in the new mode.
    status, errCode, newConf = network.ifAttach(newConf)
    if (status ~= "OK") then
        return status, errCode        
    end        

    return "OK", "STATUS_OK", newConf
end

--[[
*******************************************************************************
-- @name network.ifEditChangeApply
--
-- @description 
--
-- @return  status  OK or ERROR
-- @return  errCode reason for error or STATUS_OK
--
--]]

function network.ifEditChangeApply (newConf, currCfg)
    local addIfTbl = {}
    local delIfTbl = {}

    addIfTbl = newConf["addIfTbl"]
    delIfTbl = newConf["delIfTbl"]

    newConf["ifTbl"] = currCfg["nativeIfs"]

    -- Add new interfaces to the network
    if (util.tableSize(addIfTbl) > 0) then
        if (ifDev.isANetworkBridge(currCfg)) then
            -- Add new interfaces to the bridge
            status, errCode = network.bridgePortAdd (currCfg, addIfTbl)
            if (status ~= "OK") then
                return status, errCode
            end                
        end

        newConf["ifTbl"] = util.tableAppend(newConf["ifTbl"], addIfTbl)
    end    

    --
    -- Cleanup. Delete interfaces that 
    -- have been marked for deletion 
    --
    if (util.tableSize(delIfTbl) > 0) then

        if (ifDev.isANetworkBridge(currCfg)) then
            -- Delete old interfaces from the bridge
            local bdgIfName = currCfg["interfaceName"]
            status, errCode = network.bridgePortDelete(currCfg, delIfTbl)
            if (status ~= "OK") then
                return status, errCode
            end                
        end
       
        --
        -- delete any interface(s) that were marked for deletion
        --
        status, errCode = network.ifTypeDelete(delIfTbl)
        if (status ~= "OK") then
            return status, errCode        
        end  

        -- remove the interface from the list of interfaces
        for k,v in pairs(newConf["ifTbl"]) do
            for kk,vv in pairs(currCfg["ifTbl"]) do
                if (v["ifname"] == vv["ifname"]) then
                    table.remove(newConf["ifTbl"], k)
                end
            end                
        end            
    end

    -- Edit igmpSnooping if selected network is of type bridge
    if (ifDev.isANetworkBridge(currCfg)) then
    	status, errCode = network.bridgeEdit (newConf, currCfg)
       	return status, errCode
    end
end   

--[[
*******************************************************************************
-- @name network.ifEdit
--
-- @description This function edits the network interface. Currently switch 
-- ports (ethX.Y) and wireless ports (vap) are grouped to form a network
-- on which layer 3 connections are made. 
--
-- The user provides the port association table (newConf["portTbl") 
-- which defines the switch ports and wireless ports that are part of the network
--
-- Based on the port associations provided this function makes a list
-- of interfaces that are to be added/deleted to/from the network.
--
-- @return  status  OK or ERROR
-- @return  errCode reason for error or STATUS_OK
--
--]]

function network.ifEdit(name, newConf)
    require "teamf1lualib/bridgeLib"
    local status = "ERROR"
    local errCode = ""

    -- Get the current configuration
    status, errCode, currCfg =  network.ifConfGet(name)
    if (status ~= "OK")  then
        return status, errCode        
    end        

    -- Edit the network zone
    if (newConf["zoneType"] ~= nil) then
        if (platformLib.strcasecmp(newConf["zoneType"], "secure") == 0 or 
            platformLib.strcasecmp(newConf["zoneType"], "public") == 0) then
            newConf["ifGroupId"] = ifDev.ifGroup.IFDEV_GROUPID_SECURE
        else
            newConf["ifGroupId"] = ifDev.ifGroup.IFDEV_GROUPID_UNSECURE
        end
    end

    --
    -- Copy internal fields which we do not expect to change as is.
    --
    newConf["LogicalIfName"] = currCfg["LogicalIfName"]
    newConf["ifMark"] = currCfg["ifMark"]
    newConf["ifGroupId"] = currCfg["ifGroupId"]

    -- make a list of interfaces/ports to be added to this network
    newConf.addIfTbl = {}
    -- make a list of interfaces/ports to be deleted from this network
    newConf.delIfTbl = {}
    local ifTbl = network.ifTblGet(newConf)
    if (ifTbl ~= nil) then
        newConf["nativeIfs"] = ifTbl
    end        

    local nativePortTbl= network.nativePortTblGet(newConf)
    if (nativePortTbl ~= nil) then
        newConf["nativePorts"] = nativePortTbl
    end        

    -- Edit network switch related configuration of this network
    status, errCode = network.switchIfEdit(newConf, currCfg)
    if (status ~= "OK") then
    end        
    
    -- Edit wireless related configuration of this network
    status, errCode = network.wirelessIfEdit(newConf, currCfg)
    if (status ~= "OK") then
    end        

    -- Apply all the interface changes
    status, errCode = network.ifEditChangeApply (newConf, currCfg)
    if (status ~= "OK") then
        return status, errCode        
    end        

    -- 
    -- if the network mode (ROUTED, BRIDGED..etc) has changed, we need to
    -- delete all the interfaces and re-add them
    -- in new mode.
    --
    -- check if the mode configuration has changed
    if ((network.hasModeChanged(currCfg["connectionType"], 
                               newConf["connectionType"]) > 0)) then
        -- detach from current mode
        status, errCode, newConf = network.modeChange(currCfg, newConf)
        if (status ~= "OK") then
            return status, errCode        
        end        
    end

    -- update registration
    status, errCode = network.register(newConf)
    if (status == "ERROR") then
        return status, errCode
    end        

    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- @name network.ifCreate
--
-- @description This function creates all the interfaces required for this 
-- network. 
-- 
-- The caller passes the list of network ports that are part of this network
-- Currently only wirless and switch ports  have been considered.
-- In future this function needs to be extended to any type of interfaces
-- supported by TeamF1 Router Platform.
-- 
-- A vlan termination interface is created with  all the switch ports 
-- that are part of this network 
--
-- Currently this function expects that the caller creates wifi interface (vap)
-- and before passing it as an entry of the portTbl.
--
-- @param conf
--
-- @return  status OK or ERROR
-- @return  errCode
-- @return  ifTbl  table of interfaces created.
--]]

function network.ifCreate(conf)
    local ifTbl = {}
    local status = "ERROR"
    local errCode = ""

    network.dprintf("Creating network interfaces for " .. conf["networkName"])

    -- if a switch port is part of the network, then
    -- create vlan
    if (network.hasSwitchPort(conf["portTbl"]) ~= nil) then
        local vlanIf
 
        -- create the vlan Interface
        status, errCode, vlanIf  = network.vlanCreate(conf)
        if (status == "ERROR") then
            network.dprintf("failed to create vlan for network:" .. conf["networkName"])
            return status, errCode        
        end       

        if (vlanIf ~= nil) then
            local new = {}
            new["type"] = "vlan"
            new["LogicalIfName"] = conf["LogicalIfName"]
            new["ifname"]  = vlanIf
            table.insert(ifTbl, new)
        end
    end

    --
    -- If wireless is enabled for this network
    --
    for k,v in pairs(conf["portTbl"]) do
        if (network.isAWirelessPort(v) == true) then
            v["LogicalIfName"] = conf["LogicalIfName"]

            local status, errCode = network.vapAdd(v)
            if (status == "ERROR") then
                network.dprintf("failed to add vap to network:" .. conf["networkName"])
                return status, errCode        
            end       

            table.insert(ifTbl, v)
        end            
    end

    conf["ifTbl"] = ifTbl
    conf["nativeIfs"] = nil
    local nativeIfTbl = network.ifTblGet(conf)
    if (nativeIfTbl ~= nil) then
        conf["nativeIfs"] = nativeIfTbl
    end        

    network.dprintf("ifCreate: port MAP:" .. util.tableToStringRec(conf["portTbl"]))

    status, errCode, conf = network.ifAttach(conf)
    if (status ~= "OK") then
        return status, errCode        
    end        
    
    return  "OK", "STATUS_OK", conf
end

--[[
*******************************************************************************
-- @name network.bridgeConfGet
--
-- @description This function gets the configuration of the current interface
--
-- @param name name of the network
--
-- @return  status OK or ERROR
-- @return  errCode
-- @return  port membership table
-- @return  interface table
--
--]]

function network.bridgeConfGet (iface)
    require "teamf1lualib/bridgeLib"
    require "teamf1lualib/ifDev"
    local status = "ERROR"
    local errCode = "NET_ERR_BRIDGE_CONF"
    local bdgPortTbl = {}
    local portTbl = {}
    local ifTbl = {}
    local bdgIf = {}
    local ifname

    local LogicalIfName = iface["LogicalIfName"]

    for kk,vv in pairs(network.supportedTypes) do
        local status, errCode, netIf = network.portTblGet(LogicalIfName, vv)
        if (status == "OK") then
            -- add to port membership list
            if (netIf["portTbl"] ~= nil) then
                for k,v in pairs(netIf["portTbl"]) do 
                    table.insert (portTbl, v)
                end
            end       

            -- add to interface list
            if (netIf["ifTbl"] ~= nil) then
                for k,v in pairs(netIf["ifTbl"]) do 
                    table.insert (ifTbl, v)
                end
            end       
        end
    end
            
    --[[            
    --
    -- If this network is in bridged mode then
    --
    ifname = iface["interfaceName"]

    -- if this is a bridge, then get all the bridge ports
    status, errCode, bdgPortTbl = bridge.portTblGet(ifname)
    if ((status ~= "OK") or (bdgPortTbl == nil)) then
        return status, errCode            
    end            

    for k,v in pairs(bdgPortTbl) do
        local status, errCode, netIf = network.portTblGet(v["ifname"], v["type"])
        if (status == "OK") then
            -- add to port membership list
            if (netIf["portTbl"] ~= nil) then
                for k,v in pairs(netIf["portTbl"]) do 
                    table.insert (portTbl, v)
                end
            end       

            -- add to interface list
            if (netIf["ifTbl"] ~= nil) then
                for k,v in pairs(netIf["ifTbl"]) do 
                    table.insert (ifTbl, v)
                end
            end       
        end
    end        
    ]]--

    bdgIf["portTbl"] =  portTbl
    bdgIf["ifTbl"] = ifTbl
   
    return "OK","STATUS_OK", bdgIf
end

--[[
*******************************************************************************
-- @name network.ifConfGet
--
-- @description This function gets the configuration of the current interface
--
-- @param name name of the network
--
-- @return  status OK or ERROR
-- @return  errCode
-- @return  interface configuration
--
--]]

function network.ifConfGet(name)
    local status  = "ERROR"
    local errCode = ""
    local portTbl = {}
    local ifTbl = {}

    -- get the network
    require "teamf1lualib/ifDev"
    status, errCode, iface = ifDev.cfgByNameGet(name)
    if (status ~= "OK") then
        return status, errCode
    end        

    status, errCode, portTbl, ifTbl =  network.portConfGet(iface)
    if (status ~= "OK") then
        return status, errCode
    end            

    iface["portTbl"] = portTbl
    iface["ifTbl"] =  ifTbl

    -- Get the list of interfaces that belong to this network
    -- NOTE: If the network is bridged with other networks
    -- then all ports in currCfg["ifTbl"] might not belong to
    -- the current network.
    --
    local nativeIfTbl = network.ifTblGet(iface)
    if (nativeIfTbl ~= nil) then
        iface["nativeIfs"] = nativeIfTbl
    end        

    local nativePortTbl= network.nativePortTblGet(iface)
    if (nativePortTbl ~= nil) then
        iface["nativePorts"] = nativePortTbl
    end        

    return "OK","STATUS_OK", iface
end

--[[
*******************************************************************************
-- @name network.isASwitchPort
--
-- @description This function checks if the port is a switch port
--
-- @param port
--
-- @return true if it is a switch port else false 
--]]

function network.isASwitchPort(port)
    require "platformLib"

    if ((platformLib.strcasecmp(port["type"], "switch") == 0) or
        (platformLib.strcasecmp(port["type"], "vlan") == 0)) then
        return true
    end            

    return false
end

--[[
*******************************************************************************
-- @name network.isAWirelessPort
--
-- @description This function checks if the port is a wireless port
--
-- @param port
--
-- @return true if it is a switch port else false 
--]]

function network.isAWirelessPort(port)
    require "platformLib"

    if ((platformLib.strcasecmp(port["type"], "wireless") == 0) or
        (platformLib.strcasecmp(port["type"], "radio") == 0) or
        (platformLib.strcasecmp(port["type"], "vap") == 0)) then
        return true
    end            

    return false
end

--[[
*******************************************************************************
-- @name network.hasSwitchPort
--
-- @description This function checks if the port table has a switch port
-- association
--
-- @param portTbl
--
-- @return  port if the table has a switch port else nil
--]]

function network.hasSwitchPort(portTbl)

    if (portTbl == nil) then
        return nil
    end        

    if (type(portTbl) ~= "table") then
        return nil
    end

    for k,v in pairs(portTbl) do
        if (network.isASwitchPort(v) == true) then
            return v
        end            
    end        

    return nil
end

--[[
*******************************************************************************
-- @name network.routedModeConnect
--
-- @description This function connects the network ports of the given network
-- in rotuted mode with other networks in the system.
--
-- @param conf
-- @param mode
--
-- @return  
--]]

function network.routedModeConnect (conf, assocNetworkName)
    require "teamf1lualib/ifDev"
    local status = "ERROR"
    local errCode = ""

    -- get all the native interfaces of the current network
    local ifTbl = network.ifTblGet(conf)
    if (ifTbl ~= nil) then
        conf["nativeIfs"] = ifTbl
    end        

    -- get the name of the bridge
    local bdgIfName = bridge.ifNameGet(conf["LogicalIfName"])
    if (bdgIfName == nil) then
        network.dprintf("routedModeConnect: failed to get bridge interface name for:" ..
                        conf["LogicalIfName"])
        return "ERROR", "NET_ERR_BDG_NOT_FOUND"
    end        

    conf["interfaceName"] = bdgIfName
    conf["ifType"] = "bridge"

    -- add it to its bridge
    if (util.tableSize(ifTbl) > 0) then
        status, errCode = network.bridgePortAdd (conf, ifTbl)
        if (status ~= "OK") then
            network.dprintf("routedModeConnect: Adding ports to network bridge failed")
            return status, errCode
        end                
    end

    conf["connectionType"] = network.assocStrGet(ifDev.mode.IFDEV_MODE_ROUTED, assocNetworkName)
    network.dprintf("routedModeConnect: setting connection mode: " .. conf["connectionType"])

    return "OK", "STATUS_OK", conf
end

--[[
*******************************************************************************
-- @name network.bridgeModeConnect
--
-- @description This function bridges the current network with <assocNetworkName>
--
-- @param conf configuration of the current network
-- @param mode mode configuration 
--
-- @return  status
-- @return  errCode
-- @return  conf
--]]

function network.bridgeModeConnect (conf, assocNetworkName)
    local status = "ERROR"
    local errCode = "NET_ERR_BDG_CONNECT"
    local assocNet = {}

    if (assocNetworkName == nil) then
        return  "OK","STATUS_OK", conf
    end
            
    network.dprintf("Connecting in bridged mode with " .. assocNetworkName)

    -- get the interface configuration of the associated network.
    status, errCode, assocNet = network.ifConfGet(assocNetworkName)
    if (status ~= "OK") then
        network.dprintf("failed to get configuration of : " .. assocNetworkName)
        return status, errCode
    end                

    local mode = ifDev.modeGet(assocNet["connectionType"]) 
    if (mode ~= nil) then
        for k,v in pairs(mode) do
            if (v["networkName"] ~= nil) then
                require "platformLib"
                -- 
                -- check if we are already associated with this network
                --
                if (platformLib.strcasecmp(v["networkName"], 
                                        conf["networkName"]) == 0) then
                    --
                    -- If we are already bridged with this network, then return
                    --
                    if (v["mode"] == ifDev.mode.IFDEV_MODE_BRIDGED) then
                        return "OK","STATUS_OK", conf
                    end
                end                    
            end
        end            
    end        

    -- add all interfaces into one table
    local ifTbl = conf["nativeIfs"]
    if (ifTbl == nil) then
        ifTbl = network.ifTblGet(conf)
        conf["nativeIfs"] = ifTbl
    end

    if (ifDev.isANetworkBridge(assocNet) > 0) then
        network.dprintf ("Adding ports of " .. conf["networkName"] ..  "  " ..
                         "to network: " .. assocNetworkName)
                
        -- Attach both networks into a single bridge
        status, errCode, bdgIfName = network.bridgePortAdd(assocNet, ifTbl)                 
        if (status ~= "OK") then
            network.dprintf("Adding port to network: " .. assocNetworkName .. " failed")
            return status, errCode
        end                
    end            

    --
    -- Set the connection type
    -- 
    conf["connectionType"] = network.assocStrGet(ifDev.mode.IFDEV_MODE_BRIDGED, assocNetworkName)
    network.dprintf("bridgeModeConnect: setting connection mode: " .. conf["connectionType"])

    --
    -- update configuration
    --
    -- TODO: While connecting in bridge mode with other networks, we 
    -- need to delete the current network's layer2 object.
    --
    -- FOR now we are keeping it unchanged.
    --
    -- conf["interfaceName"] = bdgIfName
    -- conf["ifType"] = "bridge"

    return  "OK","STATUS_OK", conf
end        

--[[
*******************************************************************************
-- @name network.hasWirelessPort
--
-- @description  This function checks if the network has wireless enabled.
--
-- @param conf
--
-- @return  port if the table has a wireless port else nil
--]]

function network.hasWirelessPort(conf)
   
    if (conf == nil) then
        return nil
    end        
    
    if (conf["nativeIfs"] == nil) then
        local ifTbl = {}
        ifTbl = network.ifTblGet(conf)
        if (ifTbl == nil) then
            return nil
        end
        conf["nativeIfs"] = ifTbl
    end

    for k,v in pairs(conf["nativeIfs"]) do
        if (network.isAWirelessPort(v) == true) then
            return v
        end            
    end        

    return nil
end

--[[
*******************************************************************************
-- @name network.ifAttach
--
-- @description  
--
-- @param conf
--
-- @return  status OK or ERROR
-- @return  errCode
--]]

function network.ifAttach (conf)
    require "teamf1lualib/bridgeLib"
    local bdgIfName = nil
    local assocNetworkName = nil
    local assocType
    local ifTbl = {}
   
    local name = conf["LogicalIfName"]
    local status, errCode, iface = ifDev.cfgByNameGet(name)
    if (iface == nil) then

        --
        -- NOTE: If there are more than one interface, only then there is a need
        -- to create a bridge.For now we are creating a bridge for all cases
        --
        network.dprintf ("Creating network bridge for " .. conf["networkName"])

        --
        -- Do not add ports into bridge yet. The addition of ports
        -- will be done based on connection mode below
        --
        ifTbl = conf["ifTbl"]
        conf.ifTbl = nil

        -- create the bridge
        status, errCode, bdgIfName = bridge.create(conf)
        if (status ~= "OK") then
            return status, errCode
        end                
            
        conf["interfaceName"] = bdgIfName
        conf["ifType"] = "bridge"
        conf["ifTbl"] = ifTbl
    end        

    -- Get the connection mode of this network
    local mode = ifDev.modeGet(conf["connectionType"])
    if ((mode ~= nil) and (mode[1] ~= nil)) then
        assocType = tonumber(mode[1]["mode"])
        assocNetworkName = mode[1]["networkName"]
    else
        assocType = ifDev.mode.IFDEV_MODE_ROUTED
    end
            
    -- This network is associated with other network in bridged mode
    if (assocType == ifDev.mode.IFDEV_MODE_BRIDGED)  then    
        status, errCode, conf = network.bridgeModeConnect(conf, assocNetworkName)
        if (status ~= "OK") then
            return status, errCode
        end                
    else
        -- This network is associated with other network in routed mode
        status, errCode, conf = network.routedModeConnect(conf, assocNetworkName)
        if (status ~= "OK") then
            return status, errCode
        end                
    end

    return "OK", "STATUS_OK", conf
end

--[[
*******************************************************************************
-- @name network.ifDetach
--
-- @description  
--
-- @param conf
--
-- @return  status OK or ERROR
-- @return  errCode
--]]

function network.ifDetach (conf)
    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"
    local ifTbl = {}

    network.dprintf ("ifDetach: Detaching all interfaces from network: " .. 
                     conf["networkName"])

    ifTbl = conf["nativeIfs"] 
    if (ifTbl == nil) then
        ifTbl = network.ifTblGet(conf)
        conf["nativeIfs"] = ifTbl
    end

    -- if the interface type is a bridge, then delete ports 
    -- belonging to the given network.
    --
    if (ifDev.isANetworkBridge(conf) > 0)  then
        status, errrCode = network.bridgePortDelete(conf, ifTbl)
        if (status ~= "OK") then
            network.dprintf("ifDetach: failed to delete bridge ports for " ..
                            "network(" .. conf["networkName"]  .. ") ")
            return status, errCode
        end                
    end        

    -- 
    -- Iterate all networks and 
    -- delete associations with this network
    --
    network.assocDelete(conf)

    return "OK","STATUS_OK", ifTbl
end

-------------------------------------------------------------------------------
-- @name network.assocStrGet
--
-- @description The function encodes the network connection mode and 
-- network into a string
--
-- @param mode
-- @param networkName
--
-- @return assocStr
--

function network.assocStrGet(networkMode, assocNetworkName)
    local assocTbl = {}
    local status
    local errCode
    local assocStr = ""

    if (assocNetworkName == nil) then
        assocStr = ''
        return assocStr
    end        

    assocTbl[1]  = {}
    assocTbl[1]["mode"] = networkMode
    assocTbl[1]["networkName"] = assocNetworkName
    status, errCode,  assocStr = ifDev.modeStrGet(assocTbl) 
    if (status == "ERROR") then
        network.dprintf("Failed to get mode string for:" .. util.tableToStringRec(assocTbl))
        assocStr = ''
    end            

    return assocStr 
end

--[[
*******************************************************************************
-- @name 
--
-- @description  
--
-- @param 
--
-- @return  status OK or ERROR
-- @return  errCode
--]]

function network.assocAdd(iface, mode, assocNetworkName)
    local status = "ERROR"
    local errCode = ""

    if (iface == nil) then
        return status, errCode        
    end
            
    if (type(iface) ~= "table") then
        status, errCode, iface = ifDev.cfgByNameGet(name)
        if (status ~= "OK") then
            return "ERROR", errCode
        end            
    end        
    
    iface["connectionType"] = network.assocStrGet(mode, assocNetworkName)

    --
    -- update the interface mode in the database.
    --              
    ifDev.set(iface["networkName"], ifDev.propType.IFDEV_PROP_TYPE_IFMODE, 
              iface["connectionType"])
    
    return "OK", "STATUS_OK", iface
end

--[[
*******************************************************************************
-- @name network.bridgePortAdd
--
-- @description  This function adds the given ports from the network
--
-- @param conf  network configuration
-- @param ifTbl list of ports
--
-- @return  status OK or ERROR
-- @return  errCode
-- @return  bdgIfName name of the bridge
--]]

function network.bridgePortAdd (conf, ifTbl)
    require "teamf1lualib/bridgeLib"
    local mode = {}
    local status = "ERROR"
    local errCode ="NET_ERR_BDG_PORT_ADD"
    
    local bdgIfName =  conf["interfaceName"]


    -- add ports to the existing bridge
    if (ifTbl ~= nil) then

        network.dprintf("bridgePortAdd: Adding bridge ports " .. 
                        util.tableToStringRec(ifTbl) .. " to " .. bdgIfName)

        status, errCode = bridge.portAdd(bdgIfName, ifTbl)
        if (status ~= "OK") then
            network.dprintf("bridgePortAdd: Adding ports to network bridge failed")
            return status, errCode
        end                
    end
                 
    return "OK", "STATUS_OK", bdgIfName
end

--[[
*******************************************************************************
-- @name network.bridgePortDelete
--
-- @description  This function deletes the given ports from the network
--
-- @param conf  network configuration
-- @param ifTbl list of ports
--
-- @return  status OK or ERROR
-- @return  errCode
--]]

function network.bridgePortDelete(conf, ifTbl)
    require "teamf1lualib/bridgeLib"
    local status = "ERROR"
    local errCode = "NET_ERR_BDG_NET_DELETE"

    -- delete the ports from the bridge
    local bdgIfName =  conf["interfaceName"]

    --
    -- if this network is in bridged mode, then get the 
    -- correct name of the bridge
    --
    local bridged, cfg = network.hasBridgedAssoc (conf["connectionType"])
    if (bridged) then
        bdgIfName = cfg["interfaceName"]
    end        
    
    network.dprintf("bridgePortDelete: Deleting bridge ports " .. 
                    util.tableToStringRec(ifTbl) .. " from " .. bdgIfName)

    status, errCode = bridge.portDelete(bdgIfName, ifTbl)
    if (status ~= "OK") then
       network.dprintf("bridgePortDelete: Ports: " .. util.tableToStringRec(ifTbl))
       network.dprintf("bridgePortDelete: failed to delete bridge ports in " ..
                       "network(" .. conf["networkName"]  .. ")")
       return status, errCode
    end                

    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- @name network.unregister
-
-- @description  This function deletes the interface with the given
-- configuration and unregisters it from the TeamF1 management framework
--
-- @param conf interface configuration
--
-- @return  status OK or ERROR
-- @return  errCode
--]]

function network.unregister(conf)
    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_CONF"

    if (conf == nil) then
        return status, errCode        
    end        

    -- unregister interface
    status, errCode = ifDev.unregister(conf) 
    if (status ~= "OK") then
        return status, errCode        
    end        

    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- @name network.register
--
-- @description  This function configures the network interfaces in the given
-- mode. The conf["connectionType"] string lists the networks with which this network
-- has to be bridged/routed.
--
-- @param conf   network configuration
--
-- @return  status OK or ERROR
-- @return  errCode
-- @return  netIf  interface name of the network
--]]

function network.register (conf)
    local netIf = nil
    local iface = {}
    local status = "ERROR"
    local errCode = ""

    if (conf == nil)then
        return status, errCode        
    end        

    -- register the interface with the TeamF1 mgmt
    iface["interfaceName"] = conf["interfaceName"]
    iface["ifType"] = conf["ifType"] 
    iface["LogicalIfName"] = conf["LogicalIfName"]
    iface["networkName"] =  conf["networkName"]
    iface["networkId"] = conf["networkId"]
    iface["enable"] = conf["enable"]
    iface["mtu"] = conf ["mtu"]
    iface["mac"] = conf ["mac"]
    iface["connectionType"] = conf["connectionType"]
    iface["zoneType"] = conf["zoneType"]
    iface["ifMark"] = conf["ifMark"]
    iface["ifGroupId"] = conf["ifGroupId"]

    network.dprintf("Registering network: " .. util.tableToStringRec(iface))
    status, errCode, iface = ifDev.register(iface)
    if (status ~= "OK") then
        return status, errCode
    end        

    return "OK", "STATUS_OK", iface
end

--[[
*******************************************************************************
-- @name network.vlanCreate
--
-- @description  This function creates a VLAN with the given configuration.
--
-- @param  conf interface configuration
--
-- @return  status OK or ERROR
-- @return  errCode error string
--
--]]

function network.vlanCreate (conf)
    require "teamf1lualib/swVlan"
    local status="ERROR"
    local errCode="NET_ERR_VLAN_CREATE"
    local ID
    local mapTbl = {}
    local index = 1
    local portTbl = nil

    if (conf == nil) then
        network.dprintf("vlanCreate: invalid input(conf)")
        return status, errCode
    end

    ID = conf["vlanId"]
    if (ID == nil) then
        network.dprintf("vlanCreate: Invalid vlanId")
        return status, errCode
    end        

    ID = tonumber(ID)

    -- check if the new vlanID is valid
    if (swVlan.isValid(ID) ~= true) then
       network.dprintf("vlanCreate: Invalid vlan ID " .. ID .. " specified")
       return status, errCode
    end        

    portTbl = conf["portTbl"]
    if (portTbl == nil) then 
        network.dprintf("vlanCreate: Invalid porttable")
        return status, errCode
    end

    -- filter out other entries.
    if (portTbl ~= nil) then 
        for k,v in pairs(portTbl) do 
            if ((platformLib.strcasecmp(v["type"], "vlan") == 0) or 
                (platformLib.strcasecmp(v["type"], "switch") == 0) or
                (platformLib.strcasecmp(v["type"], "switch port") == 0)) then
                mapTbl[index] = {}
                mapTbl[index] = v
                index = index + 1
            end 
        end        
    end

   if (platformLib.strcasecmp (conf["zoneType"], "bridge") == 0) then
       mapTbl["inSwitchOnly"] = 1
   end

   network.dprintf("vlanCreate: Creating VLAN for network:" .. conf["networkName"] .. "ID: " .. ID)
   network.dprintf("vlanCreate: port MAP:" .. util.tableToStringRec(portTbl))

    -- create vlan
    status, errCode, newIf = swVlan.create(conf["LogicalIfName"], ID, mapTbl)
    if (status ~= "OK") then
        network.dprintf("vlanCreate: failed to create a vlan interface")
        return status, errCode        
    end        

    return "OK","STATUS_OK", newIf
end

--[[
*******************************************************************************
-- @name network.vlanDestroy
--
-- @description This function destroys the VLAN with the given configuration
--
-- @param  conf interface configuration
--
-- @return  status OK or ERROR
-- @return  errCode error string
--]]

function network.vlanDestroy (vlanIf)
    require "teamf1lualib/swVlan"
    local status="ERROR"
    local errCode="NET_ERR_VLAN_DESTROY"

    -- destroy vlan
    status, errCode = swVlan.destroy(vlanIf)
    if (status ~= "OK") then
        return status, errCode        
    end        

    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- @name network.cfgHelper
--
-- @description  This is a helper routine which configures network connections
-- for a given network.
--
-- @param  ifcfg interface configuration
-- @param  conf  network configuration
--
-- @return  status OK or ERROR
-- @return  errCode error string
--]]

function network.cfgHelper(ifcfg, conf)
   require "platformLib"
   local AddressFamily
   local status = "ERROR"
   local errCode = ""
                        
    if ((ifcfg == nil) or (conf == nil)) then
        return status, errCode
    end        
                                
   conf["NetworkName"] = ifcfg["networkName"]
   conf["LogicalIfName"] = ifcfg["LogicalIfName"]

    -- mandatory arguments
    if ((conf["ConnectionType"] == nil) or (conf["AddressFamily"] == nil)) then
        return status, errCode        
    end        

    -- NO network connections in bridge mode
    local mode = ifDev.modeGet(ifcfg["connectionType"])
    if (mode ~= nil) then
        if (mode[1]["mode"] == ifDev.mode.IFDEV_MODE_BRIDGED) then
            return status, "NET_ERR_NO_NET_CONN_IN_BDG_MODE"
        end            
    end        

    AddressFamily = conf["AddressFamily"]

    require "teamf1lualib/nimf"
    if ((platformLib.strcasecmp(AddressFamily, "ipv4") == 0 ) or
        (tonumber(AddressFamily) == nimf.proto.NIMF_PROTO_TYPE_IPV4)) then
        conf["AddressFamily"] = nimf.proto.NIMF_PROTO_TYPE_IPV4
    elseif ((platformLib.strcasecmp(AddressFamily, "ipv6") == 0) or        
        (tonumber(AddressFamily) == nimf.proto.NIMF_PROTO_TYPE_IPV6)) then
        conf["AddressFamily"] = nimf.proto.NIMF_PROTO_TYPE_IPV6
    else
        status = "ERROR"
        errCode = "NET_ERR_INVALID_PROTO_TYPE"        
        return status, errCode
    end        

    require "teamf1lualib/nimfConn"
    status, errCode = nimfConn.configure(conf)
    if (status ~= "OK") then
        network.dprintf("network.cfgHelper: connection configuration failed")
        return status, errCode
    end        

            
    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- @name network.hasSwitchPortMapChanged
--
-- @description This function checks if the port membership of the network 
-- has changed. This function is specific to a ethernet switch based
-- networks.
--
-- The port membership of the network changes if 
--  a) the default PVID of the switch port that belongs to the network changes.
--     The "default" field in the table represents the default PVID
--  b) a new port was added to the network
--  c) a port was deleted fromt he network.
--
--
-- @param oldMap  old port membership table
-- @param newMap  new port membership table
--
-- @return 1 if changed else 0. < 0 for error.
--]]

function network.hasSwitchPortMapChanged (oldMap, newMap)
    local defaultPVIDChanged = 0
    local found = 0

    if ((oldMap == nil) or (newMap == nil)) then
        return -1
    end        

    if (type(oldMap) ~= "table") then
        return -1
    end        

    if (type(newMap) ~= "table") then
        return -1
    end        

    --[[
    network.dprintf("oldMap: " .. util.tableToStringRec(oldMap))
    network.dprintf("newMap: " .. util.tableToStringRec(newMap))
    ]]--

    -- check if the default PVID has changed
    for k,v in pairs(oldMap) do
        if (v["type"] == "vlan") then
            for kk,vv in pairs(newMap) do
                if ((tonumber(v["port"]) == tonumber(vv["port"])) and
                    (tonumber(v["default"]) ~= tonumber(vv["default"])) and
                    (vv["type"] == "vlan")) then
                    defaultPVIDChanged = 1
                    network.dprintf("Default PVID of port: " .. v["port"] .. " has changed")
                end                
            end
        end
    end        

    local addedPorts, deletedPorts = network.getChangedPorts(oldMap, newMap, "vlan")
    if ((util.tableSize(addedPorts) > 0) or (util.tableSize(deletedPorts) > 0) or 
        (defaultPVIDChanged ~= 0)) then
        return 1
    end
            
    return 0
end


--[[
*******************************************************************************
-- @name network.ifByTypeGet
--
-- @description This function gets the interface of a given type from the
-- configuration's interface table
--
-- @param conf interface configuration
-- @param ifType port type
--
-- @return interface or nil
--]]

function network.ifByTypeGet(ifTbl, ifType)

    if (ifTbl == nil) then
        return nil
    end        

    for k,v in pairs(ifTbl) do
        if (platformLib.strcasecmp(v["type"], ifType) == 0) then
            return v
        end            
    end        

    return nil
end

--[[
*******************************************************************************
-- @name  network.assocDelete
--
-- @description This function deletes the association of this network with
-- all the other networks.
--
-- @param iface network interface configuration
--
-- @return 
--]]

function network.assocDelete(iface)
    local mode = {}

    mode = ifDev.modeGet(iface["connectionType"])
    if (mode == nil) then
        return
    end        

    local name = mode[1]["networkName"]
    local status, errCode, iface = ifDev.cfgByNameGet(name)
    if (status ~= "OK") then
        return status, errCode
    end        

    local newMode = ifDev.modeDelete(iface["connectionType"], iface["networkName"]) 
    if (newMode ~= nil) then
        v["connectionType"] = newMode
        ifDev.set(iface["networkName"], ifDev.propType.IFDEV_PROP_TYPE_IFMODE, newMode)
    end

    return             
end

--[[
*******************************************************************************
-- @name  network.ifTblGet
--
-- @description This function returns a table of interfaces that belong 
-- this given network
--
-- @param conf network interface configuration
--
-- @return  interface table or nil
--]]

function network.ifTblGet (conf)
    local nativeIfs = {}

    if (conf == nil) then
        return nil            
    end
            
    if (conf.ifTbl == nil) then
        return nil
    end
                        
    if (conf["nativeIfs"] ~= nil) then
        return conf["nativeIfs"]
    end        
                                 
    -- assemble all interfaces that belong to this network
    for k,v in pairs(conf.ifTbl) do
        if (platformLib.strcasecmp(conf["LogicalIfName"], 
                                   v["LogicalIfName"]) == 0)  then
            table.insert(nativeIfs, v)                                   
        end            
    end        

    return nativeIfs
end

--[[
*******************************************************************************
-- @name  network.nativePortTblGet
--
-- @description This function returns a table of ports that belong 
-- this given network
--
-- @param conf network interface configuration
--
-- @return  interface table or nil
--]]

function network.nativePortTblGet(conf)
    local nativePorts = {}

    if (conf == nil) then
        return nil            
    end
            
    if (conf.portTbl == nil) then
        return nil
    end
                        
    -- assemble all interfaces that belong to this network
    for k,v in pairs(conf.portTbl) do
        if (platformLib.strcasecmp(conf["LogicalIfName"], 
                                   v["LogicalIfName"]) == 0)  then
            table.insert(nativePorts, v)                                   
        end            
    end        

    return nativePorts
end

--[[
*******************************************************************************
-- @name  network.hasModeChanged
--
-- @description This function checks if the network mode has changed.
-- The network mode has the following format
--  <mode>:<networkName>,...
--
-- @param currMode current network mode
-- @param newMode  new network mode
--
-- @return 0 if the mode has not changed else 1
--]]

function network.hasModeChanged(currMode, newMode) 
    local newmode = ifDev.modeGet(newMode) 
    local curmode = ifDev.modeGet(currMode)

    if ((newmode == nil) and (curmode == nil)) then
        return 0
    end        

    if ((newmode ~= nil) and (curmode == nil)) then
        return 1
    end        
    
    if ((newmode == nil) and (curmode ~= nil)) then
        return 1
    end        

    for k,v in pairs (newmode) do
        for kk,vv in pairs(curmode) do
            if ((v["networkName"] == vv["networkName"]) and 
                (v["mode"] == vv["mode"])) then
                    return 0
            end                
        end            
   end        

   return 1
end

--[[
*******************************************************************************
-- @name  network.ifTypeDelete
--
-- @description This function deletes the list of all the interfaces provided.
--
-- @param ifTbl list of interface to delete.
--
-- @return status
-- @return errCode
--]]

function network.ifTypeDelete (ifTbl)
    local port

    for k,v in pairs(ifTbl) do

        if (network.isASwitchPort(v) == true) then            
            --
            -- Delete a switch port
            -- 
            status, errCode = network.vlanDestroy(v)
            if (status == "ERROR") then
                return status, errCode        
            end        
        end

        if (network.isAWirelessPort(v) == true) then
            -- 
            -- remove wireless port from the network
            -- 
            network.vapRemove(v)
        end        
    end

    return  "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- @name  network.dprintf
--
-- @description 
--
-- @param msg
--
-- @return N/A
--]]

function network.dprintf (msg)
    
    if (msg == nil) then
        return
    end
            
    local blob = "NETWORK:" .. msg .. " <br>"

    if ((gui ~= nil) and (gui.debug == 1)) then
        util.appendDebugOut(blob)
    end        

    if ((network.debug == 1) or ((gui ~= nil) and (gui.console_debug == 1))) then
        print(blob)
    end
            
    return
end

--[[
*******************************************************************************
-- @name 
--
-- @description 
--
-- @param 
--
-- @return status
-- @return errCode
--]]

function  network.vapPortTblGet (LogicalIfName)
    require "teamf1lualib/dot11"
    local netIf = {}
    local vapPortList = {}
    local vapIfList = {}
    local vapIfTbl
    local vapPortTbl = {}
    local query = "LogicalIfName='" .. LogicalIfName .. "'"

    vapIfTbl = dot11.confGet("dot11Interface", query)
    if (vapIfTbl == nil) then
        return nil        
    end        
        
    for k,v in pairs(vapIfTbl) do        
        netIf = network.vapPortInit(v["interfaceName"], LogicalIfName)
        table.insert(vapPortList, netIf["portTbl"][1])
        table.insert(vapIfList, netIf["ifTbl"][1])
    end        

    vapPortTbl["portTbl"] = vapPortList
    vapPortTbl["ifTbl"] = vapIfList

    return vapPortTbl
end

--[[
*******************************************************************************
-- @name 
--
-- @description 
--
-- @param 
--
-- @return status
-- @return errCode
--]]

function network.ethPortTblGet(ifname)
    require "teamf1lualib/ethernet"
    local eth = {}
    local ifTbl = {}    

    ethernetIf =  ethernet.confGet(ifname)
    if (ethernetIf == nil) then
        return nil, "NET_ERR_ETHERNET_PORT"
    end                    

    ifTbl[1] = {}
    ifTbl[1]["ifname"] = ifname
    ifTbl[1]["type"] =  "ethernet"
    ifTbl[1]["LogicalIfName"] =  ethernetIf["LogicalIfName"]

    eth["ifTbl"] = ifTbl

    return eth
end    

--[[
*******************************************************************************
-- @name 
--
-- @description 
--
-- @param 
--
-- @return status
-- @return errCode
--]]

function network.vlanPortTblGet (LogicalIfName)
    --require "teamf1lualib/swVlan"
    local status = "ERROR"
    local errCode = ""
    local index = 1
    local portTbl = {}
    local ifTbl = {}
--[[
    -- get the port membership info for this vlan
    status, errCode, vlanIf =  swVlan.confGet(LogicalIfName)
    if (status ~= "OK") then
        return  nil, "NET_ERR_INVALID_VLAN"
    end                    

    local mapTbl = vlanIf["map"] 
    for kk,vv in pairs(mapTbl) do
        portTbl[index] = {}
        portTbl[index]["name"] =  vv["name"]
        portTbl[index]["port"] = vv["port"]
        portTbl[index]["default"] = vv["default"]
        portTbl[index]["type"] =  "vlan"
        portTbl[index]["LogicalIfName"] = vlanIf["LogicalIfName"]
        index = index + 1
    end

    ifTbl[1] = {}
    ifTbl[1]["ifname"] = vlanIf["interfaceName"] .. "." .. vlanIf["vlanId"] 
    ifTbl[1]["type"] =  "vlan"
    ifTbl[1]["vlanId"] = vlanIf["vlanId"]
    ifTbl[1]["LogicalIfName"] =  vlanIf["LogicalIfName"]

    local netIf = {}
    netIf["ifTbl"] = ifTbl
    netIf["portTbl"] = portTbl
]]--
    return netIf
end

--[[
*******************************************************************************
-- @name 
--
-- @description 
--
-- @param 
--
-- @return status
-- @return errCode
--]]

function network.portConfGet (iface)
    require "teamf1lualib/ifDev"
    local status = "ERROR"
    local errCode = ""
    local portTbl = {}
    local ifTbl = {}
    local netIf = {}

    local isABridge, conf = ifDev.isANetworkBridge(iface)
    if (isABridge < 0) then
        return "ERROR","NET_ERR_NOENT"            
    end
            
    if (isABridge > 0) then
        status, errCode, netIf = network.bridgeConfGet (iface)
    else
        status, errCode, netIf = network.portTblGet(iface["LogicalIfName"],
                                                    iface["ifType"])
    end                

    if (status ~= "OK") then
        return "ERROR","NET_ERR_PORT_TBL"            
    end            

    portTbl = netIf["portTbl"]
    ifTbl = netIf["ifTbl"]

    return "OK", "STATUS_OK", portTbl, ifTbl
end

--[[
*******************************************************************************
-- @name 
--
-- @description 
--
-- @param 
--
-- @return status
-- @return errCode
--]]

function network.portTblGet(LogicalIfName, ifType)
    local netIf = {}
    require "platformLib"

    if (platformLib.strcasecmp(ifType, "vap") == 0) then
        netIf = network.vapPortTblGet(LogicalIfName)
        if (netIf == nil) then
            return "ERROR", "NET_ERR_VAP_PORT"
        end            
    end                
            
    if (platformLib.strcasecmp(ifType, "vlan") == 0) then
        netIf = network.vlanPortTblGet(LogicalIfName)
        if (netIf == nil) then
            return "ERROR", "NET_ERR_VLAN_PORT"
        end            
    end

    if (platformLib.strcasecmp(ifType, "ethernet") == 0) then
        netIf = network.ethPortTblGet(LogicalIfName)
        if (netIf == nil) then
            return "ERROR", "NET_ERR_ETH_PORT"
        end            
    end
    
    return "OK", "STATUS_OK", netIf
end

--[[
*******************************************************************************
-- @name network.vapPortInit
--
-- @description 
--
-- @param 
--
-- @return 
--]]

function network.vapPortInit(ifname, LogicalIfName)                
    local portTbl = {}
    local ifTbl = {}
    local netIf = {}

    portTbl[1] = {}
    portTbl[1]["name"] = "Wireless"
    portTbl[1]["port"] = string.gsub (ifname, "vap", "")
    portTbl[1]["default"] = 1
    portTbl[1]["type"] =  "vap"
    portTbl[1]["LogicalIfName"] = LogicalIfName
    portTbl[1]["ifname"] = ifname

    ifTbl[1] = {}
    ifTbl[1]["ifname"] = ifname
    ifTbl[1]["vlanId"] = ""
    ifTbl[1]["type"] =  "vap"
    ifTbl[1]["LogicalIfName"] =  LogicalIfName

    netIf["ifTbl"] = ifTbl
    netIf["portTbl"] = portTbl

    return netIf
end

-------------------------------------------------------------------------------
-- @name network.wirelessPortListGet
--
-- @description This function gets the list of all the wireless ports that 
-- are part of the given network. If no network is given then it will
-- list all the available wireless ports in the system.
--
-- @param name  - LogicalIfName or interfaceName or networkName
--
-- @return  portTbl or nil
--

function network.wirelessPortListGet(conf)
    require "teamf1lualib/dot11"
    local name=nil
    local wPortList = {}
    local query = nil
    local portTbl = {}
    local ifTbl = {}

    if (conf ~= nil) then
        if (type(conf) == "table") then
            name = conf["LogicalIfName"] or conf["interfaceName"] or conf["networkName"]
        elseif (type(conf) == "string") then
            name = conf       
        end        

        -- get interface configuration and construct query
        if (name ~= nil) then
            local status, errCode, ifcfg = ifDev.cfgByNameGet(name)
            if (status ~= "OK") then
                return  nil, "NET_ERR_DB_NOENT"
            end        

            query = "LogicalIfName='" .. ifcfg["LogicalIfName"] .. "'"
        end
    end        

    local wPortList = dot11.confGet("dot11Interface", query)
    if (wPortList == nil) then
        return nil,  "NET_ERR_DB_NOENT"
    end        
    
    for k,v in pairs(wPortList) do
        local netIf = {}
        netIf = network.vapPortInit(v["interfaceName"], v["LogicalIfName"])                
        table.insert(portTbl, netIf["portTbl"][1])
        table.insert(ifTbl, netIf["ifTbl"][1])
    end                

    return portTbl, ifTbl
end

-------------------------------------------------------------------------------
-- @name network.wirelessDisable
--
-- @description This function disables the wireless connectivity of this
-- network
--
-- @param name name of the network
--
-- @return  OK or ERROR
--

function network.wirelessDisable (name)
    require "teamf1lualib/bridgeLib"

    -- Make a list of all the wireless ports of this network
    portTbl = network.wirelessPortListGet(name)
    if (portTbl == nil) then
        return "ERROR", "NET_ERR_NOTWIRELESS"
    end        

    -- if the network is a bridge then        
    -- remove the wireless ports from its bridge
    --
    local isABridge, netIf = ifDev.isANetworkBridge(name)
    if (isABridge > 0 ) then
        local bdgIfName = netIf["interfaceName"]
        local ifTbl = {}
        local index = 1
        for k,v in pairs(portTbl) do
            ifTbl[index] = {}
            ifTbl[index]["ifname"] =  v["ifname"]
            index = index + 1
        end

        if (network.bridgePortDelete(netIf, ifTbl) ~= "OK") then
            return "ERROR", "NET_ERR_BDG_PORT_DEL"
        end            
    end
    
    -- disable all the vaps
    dot11VAP.ifstateSet (ifTbl, 0)

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name network.isInZone
--
-- @description  This function checks if the given network is in the given
-- zone.
--
-- @param name      : name of the network (LogicalIfName, Network Name or interfaceName)
-- @param zoneType  : type of the zone (secure, insecure or public)
--
-- @return  true or false
--

function network.isInZone(name, zoneType)

    if ((name == nil) or (zoneType == nil)) then
        return false
    end        

    local status, errCode, ifcfg = ifDev.cfgByNameGet(name)
    if (status ~= "OK") then
        return false, errCode
    end        

    if (platformLib.strcasecmp(zoneType, ifcfg["zoneType"]) == 0) then
        return true
    end

    return false
end

-------------------------------------------------------------------------------
-- @name network.hasL3Object
--
-- @description  This function checks if the given network has layer 3
-- connectivity to the system
--
-- @param name      : name of the network (LogicalIfName, Network Name or interfaceName)
--
-- @return  true if routed or else false
--

function network.hasL3Object(name)
    require "teamf1lualib/ifDev"
    local errCode = "NET_ERR_IFCFG_NOT_FOUND"
    local status
    local ifcfg
    local connectionType

    if (name == nil) then
        return false
    end        

    connectionType = name["connectionType"]
    if (connectionType == nil) then
        status, errCode, ifcfg = ifDev.cfgByNameGet(name)
        if (status ~= "OK") then
            network.dprintf("hasL3Object: failed to get interface configuration")
            return false, errCode
        end        
        connectionType = ifcfg["connectionType"]
    end

    mode = ifDev.modeGet(connectionType)
    if (mode == nil) then
        network.dprintf("hasL3Object: failed to determin network association. default is routed")
        return true, errCode
    end
            
    for k,v in pairs (mode) do
        if (v["mode"] == ifDev.mode.IFDEV_MODE_ROUTED) then
            return true
        end
    end    

    --nimfConn.cfgValidate(conf)

    return false
end

-------------------------------------------------------------------------------
-- @name network.ifEqualPorts
--
-- @description  This function checks if both the ports are equal.
--
-- @param portA   : 
-- @param portB   : 
--
-- @return  true if both ports are equal else false
--

function network.ifEqualPorts(portA, portB)

    -- Do they belong to the same network
    if ((portA["LogicalIfName"] ~= nil) and (portB["LogicalIfName"] ~= nil)) then
        if (platformLib.strcasecmp(portA["LogicalIfName"], 
                                   portB["LogicalIfName"]) ~= 0)  then
            return false            
        end        
    end

    -- Are they of the same type
    if (platformLib.strcasecmp(portA["type"], portB["type"]) ~= 0)  then
        return false            
    end        

    -- check for port number
    local portType = string.lower(portA["type"])
    if ((portType == "vlan") or 
        (portType == "switch")) then
        if (tonumber(portA["port"]) ~= tonumber(portB["port"])) then
            return false
        end            
    elseif ((portType == "wireless") or 
            (portType == "vap"))  then
        if (portA["ifname"] ~= portB["ifname"]) then
            return false
        end            
    else
       return false
    end       
                
    return true
end

-------------------------------------------------------------------------------
-- @name network.getChangedPorts
--
-- @description  This function checks if the port map has changed
--
-- @param oldMap      : portMap of network
-- @param newMode     : portMap of network
-- @param portType    : vlan, vap .. etc
--
-- @return  true if routed or else false
--

function network.getChangedPorts(oldMap, newMap, portType)
    local addedPorts = {}
    local deletedPorts = {}
    local found

    -- check if a port has been removed from the network
    for k,v in pairs(oldMap) do
        found = 0

        if (portType == v["type"]) then
            for kk,vv in pairs(newMap) do
                if (network.ifEqualPorts(v, vv) == true) then                    
                    found = 1
                    break
                end                
            end

            if (found == 0) then
                network.dprintf("Port association for portType:" .. v["type"] .. 
                                " portNum:" .. (v["port"] or v["ifname"]) .. 
                                " has been removed")
                table.insert(deletedPorts, v)
            end            
        end
    end        

    -- check if a port has been added to the network
    for k,v in pairs(newMap) do
        found = 0
        if (portType == v["type"]) then

            for kk,vv in pairs(oldMap) do
                if (network.ifEqualPorts(v, vv) == true) then                    
                   found = 1
                   break
                end                
            end

            if (found == 0) then
                newPortAdded = 1
                network.dprintf("Port association for portType:" .. v["type"] .. 
                                " portNum:" .. (v["port"] or v["ifname"]) .. 
                                " has been added")
                table.insert(addedPorts, v)
            end            
        end
    end        

    return addedPorts, deletedPorts
end

-------------------------------------------------------------------------------
-- @name network.vapAdd
--
-- @description  This function adds the vap to the network
--
-- @param vapInfo      : details of the vap
--
-- @return status
-- @return errCode
--

function network.vapAdd (vapInfo)
    require "teamf1lualib/dot11"
    local query

    -- check if the vap already exists
    query = "interfaceName='" .. vapInfo["ifname"] .. "'"
    local vapCfg = dot11.confGet("dot11Interface", query)
    if (vapCfg == nil) then
        return "ERROR", "NET_ERR_VAP_NOENT"
    end        

    vapCfg = vapCfg[1]

    -- check if the vap belongs to the same network
    if (vapCfg["LogicalIfName"] == vapInfo["LogicalIfName"]) then
        return "OK", "STATUS_OK"
    end        

    vapCfg["LogicalIfName"] = vapInfo["LogicalIfName"]

    -- Change the network to which the vap belongs
    local valid, errStr = dot11.confSet("dot11Interface", vapCfg)
    if (not valid) then
        return "ERROR", errStr
    end
            
    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name network.vapRemove
--
-- @description  This function adds the vap to the network
--
-- @param vapInfo     :  details of the vap
--
-- @return status
-- @return errCode
--

function network.vapRemove (vapInfo)
    require "teamf1lualib/dot11"

    -- check if the vap exists
    query = "interfaceName='" .. vapInfo["ifname"] .. "'"
    local vapCfg = dot11.confGet("dot11Interface", query)
    if (vapCfg == nil) then
        return "ERROR", "NET_ERR_VAP_NOENT"
    end        

    -- check if the vap belongs to the same network
    vapCfg = vapCfg[1]

    if (vapCfg["LogicalIfName"] ~= vapInfo["LogicalIfName"]) then
        return "OK", "STATUS_OK"
    end        

    vapCfg["LogicalIfName"] = ""

    -- Change the network to which the vap belongs
    local valid, errStr = dot11.confSet("dot11Interface", vapCfg)
    if (not valid) then
        return "ERROR", errStr
    end
            
    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name network.vlanIDGet
--
-- @description  This function gets the vlanId from the network's interface
-- table. The interface table is the list of interfaces that are part
-- of the network. The interface table of the network can be retrieved using
-- network.ifConfGet().
--
-- @param conf  interface configuration returned by  network.ifConfGet()
--
-- @return status
-- @return errCode
-- @return vlanId or -1 if there are no vlans
--

function network.vlanIDGet (conf)
   local status = "ERROR"
   local errCode = "NET_ERR_IFTBL_ERR"
   local vlanId  = -1
   local ifTbl = {}
   
    if (conf == nil) then
        return status, errCode
    end        
    
    if (type(conf) ~= "table")  then
        return status, errCode
    end

    ifTbl = conf["nativeIfs"]
    if (ifTbl == nil) then
        status, errCode, conf = network.ifConfGet(conf)
        if (status ~= "OK") then
            return status, errCode
        end            

        ifTbl = conf["nativeIfs"]
    end

    for k,v in pairs(ifTbl) do
        if (network.isASwitchPort(v) == true) then
            vlanId = tonumber(v["vlanId"])
            status = "OK"
            errCode = "STATUS_OK"
        end            
    end                        

    return status, errCode, vlanId
end

-------------------------------------------------------------------------------
-- @name network.hasBridgedAssoc
--
-- @description This function checks if the given connection type has a
-- bridged association with any network. If the connection type represents
-- a bridged association then we need to return the configuration of the 
-- associated network.
--
-- @param connectionType
--
-- @return true or false
-- @return conf configuration of the associated network bridge
--

function network.hasBridgedAssoc (connectionType)
    require "teamf1lualib/ifDev"
    local conf
    local networkName = nil

    local mode = ifDev.modeGet(connectionType)
    if ((mode ~= nil) and (mode[1] ~= nil)) then
        if (mode[1]["mode"] ~= ifDev.mode.IFDEV_MODE_BRIDGED) then
            return false, nil            
        end            

    networkName = mode[1]["networkName"]        
    end        

    if (networkName == nil) then
        return false, nil            
    end
            
    status, errCode, conf = ifDev.cfgByNameGet(networkName)
    if (status ~= "OK") then
        network.dprintf("failed to get network configuration for: " .. networkName)
        return true, nil        
    end        

    return true, conf
end    

-------------------------------------------------------------------------------
-- @name network.assocNetListGet
--
-- @description This function gets the list of networks associated with the
-- the given network.
--
-- @param conf network configuration
--
-- @return status
-- @return errCode
-- @return list of networks associated with the given network
--

function network.assocNetListGet (conf)
    local status = "ERROR"
    local errCode = ""
    local ifCfg = {}
    local assocList = {}

    status, errCode, ifCfg = ifDev.cfgByNameGet(conf)
    if (status ~= "OK") then
        return status, errCode
    end        

    status, errCode, ifList = ifDev.cfgByNameGet()
    if (status ~= "OK") then
        return status, errCode
    end                
               
    for k,v in pairs(ifList) do
        local mode = {}

        if (platformLib.strcasecmp(v["networkName"], ifCfg["networkName"]) ~= 0) then

            mode = ifDev.modeGet(v["connectionType"])
            if ((mode ~= nil) and (mode[1] ~= nil)) then

                if (platformLib.strcasecmp(mode[1]["networkName"], 
                                           ifCfg["networkName"]) == 0) then
                    table.insert(assocList, v)
                end            
            end
        end            
    end                       

    return "OK", "STATUS_OK", assocList
end

-------------------------------------------------------------------------------
-- @name network.portAdd
--
-- @description This function adds the given ports to the network
--
-- @param name   name of the network
-- @param netIf["portTbl"] - list of ports to add
-- @param netIf["ifTbl"] - list of interfaces to add
--
-- @return status
-- @return errCode
-- @return network configuration
--

function network.portAdd (name, netIf)
    local conf= {}
    local status = "ERROR"
    local errCode = ""
    local ifTbl = {}
    local portTbl = {}

    -- Get the interface configuration
    status, errCode, conf = network.ifConfGet(name)
    if (status ~= "OK") then
        return status, errCode
    end

    portTbl = netIf["portTbl"]
    ifTbl = netIf["ifTbl"]
    
    -- remove common ports        
    for kk,vv in pairs(conf["portTbl"]) do
        for k,v in pairs(portTbl) do
            v["LogicalIfName"] = conf["LogicalIfName"]
            if (network.ifEqualPorts(v, vv) == true) then
                table.remove(portTbl, k)
            end                
        end            
    end        

    -- remove common interfaces
    for kk,vv in pairs(conf["ifTbl"]) do
        for k,v in pairs(ifTbl) do
            v["LogicalIfName"] = conf["LogicalIfName"]
            if (platformLib.strcasecmp(vv["ifname"], v["ifname"]) == 0) then
                table.remove(ifTbl, k)
            end                
        end            
    end        

    for k,v in pairs(portTbl) do
        v["LogicalIfName"] = conf["LogicalIfName"]
        table.insert(conf["portTbl"], v)         
    end
            
    for k,v in pairs(ifTbl) do
        v["LogicalIfName"] = conf["LogicalIfName"]
        table.insert(conf["ifTbl"], v)         
    end        

    status, errCode = network.edit(conf["networkName"], conf)
    if (status ~= "OK") then
        return status, errCode
    end

    return "OK", "STATUS_OK", conf
end

-------------------------------------------------------------------------------
-- @name network.portRemove
--
-- @description This function removes the given ports from the network
--
-- @param name   name of the network
-- @param netIf["portTbl"] - list of ports to remove
-- @param netIf["ifTbl"] - list of interfaces to remove
--
-- @return status
-- @return errCode
--

function network.portRemove (name, netIf)
    local conf= {}
    local status = "ERROR"
    local errCode = ""
    local ifTbl = {}
    local portTbl = {}

    -- Get the interface configuration
    status, errCode, conf = network.ifConfGet(name)
    if (status ~= "OK") then
        return status, errCode
    end

    portTbl = netIf["portTbl"]
    ifTbl = netIf["ifTbl"]
    
    -- remove common ports        
    for kk,vv in pairs(conf["portTbl"]) do
        for k,v in pairs(portTbl) do
            if (network.ifEqualPorts(v, vv) == true) then
                table.remove(conf["portTbl"], kk)
            end                
        end            
    end        

    -- remove common interfaces
    for kk,vv in pairs(conf["ifTbl"]) do
        for k,v in pairs(ifTbl) do
            if (platformLib.strcasecmp(vv["ifname"], v["ifname"]) == 0) then
                table.remove(conf["ifTbl"], kk)
            end                
        end            
    end        

    status, errCode = network.edit(conf["networkName"], conf)
    if (status ~= "OK") then
        return status, errCode
    end

    return "OK", "STATUS_OK", conf
end

-------------------------------------------------------------------------------
-- @name network.nameGet
--
-- @description This function gets the network name from the LogicalIfName
--
-- @param LogicalIfName Logical interface name of the given network.
--
-- @return networkName or nil
--

function network.nameGet(LogicalIfName)
    require "teamf1lualib/ifDev"
    local status
    local errCode
    local cfg = {}

    status, errCode, cfg = ifDev.cfgByNameGet(LogicalIfName)
    if (status ~= "OK") then
        return nil
    end        

    return cfg["networkName"]
end

-------------------------------------------------------------------------------
-- @name network.logicalIfNameGet
--
-- @description This function gets the LogicalIfName from the network name
--
-- @param networkName 
--
-- @return LogicalIfName or nil
--

function network.logicalIfNameGet(networkName)
    require "teamf1lualib/ifDev"
    local status
    local errCode
    local cfg = {}

    status, errCode, cfg = ifDev.cfgByNameGet(networkName)
    if (status ~= "OK") then
        return nil
    end        

    return cfg["LogicalIfName"]
end

-------------------------------------------------------------------------------
-- @name network.phyIfNameGet
--
-- @description This function gets the physical interface name from the 
-- LogicalIfName
--
-- @param LogicalIfName  Logical interface name of the network
--
-- @return physical interface name or nil
--

function network.phyIfNameGet(LogicalIfName)
    require "teamf1lualib/ifDev"
    local status
    local errCode
    local cfg = {}

    status, errCode, cfg = ifDev.cfgByNameGet(LogicalIfName)
    if (status ~= "OK") then
        return nil
    end        

    return cfg["interfaceName"]
end

-------------------------------------------------------------------------------
-- @name network.isWAN
--
-- @description This function checks if the given network is a WAN
--
-- @param LogicalIfName             
--
-- @return true or false
--

function network.isWAN(LogicalIfName)
    require "teamf1lualib/ifDev"

    local zone = ifDev.zoneGet(LogicalIfName)
    if (zone == ifDev.ifZone.IFDEV_ZONE_TYPE_INSECURE) then
        return true
    end        

    return false
end

-------------------------------------------------------------------------------
-- @name network.isLAN
--
-- @description This function checks if the given network is a LAN
--
-- @param LogicalIfName             
--
-- @return true or false
--

function network.isLAN(LogicalIfName)
    require "teamf1lualib/ifDev"

    local zone = ifDev.zoneGet(LogicalIfName)
    if (zone == ifDev.ifZone.IFDEV_ZONE_TYPE_SECURE) then
        return true
    end        

    return false
end

-------------------------------------------------------------------------------
-- @name network.isRoutedLAN
--
-- @description This function checks if the given network is a LAN in ROUTED mode
--
-- @param LogicalIfName             
--
-- @return true or false
--

function network.isRoutedLAN(LogicalIfName)
    require "teamf1lualib/ifDev"
    local status
    local errCode
    local cfg = {}

    if (LogicalIfName == nil) then
        return false
    end

    status, errCode, cfg = ifDev.cfgByNameGet(LogicalIfName)
    if (status ~= "OK") then
        return false
    end        

    local isRouted = ifDev.isRouted(cfg["connectionType"])
    local zone = ifDev.zoneNumGet(cfg["zoneType"])

    if (isRouted and (zone == ifDev.ifZone.IFDEV_ZONE_TYPE_SECURE)) then
        return true
    end        

    return false
end

-------------------------------------------------------------------------------
-- @name network.isUp
--
-- @description This function checks if the network is UP
--
-- @param LogicalIfName             
--
-- @return true or false
--

function network.isUp(LogicalIfName)

    if (network.hasL3Object(LogicalIfName)) then
	    require ("teamf1lualib/nimf")
        local status = nimfLib.isNetworkUp(LogicalIfName)
        if (status < 0) then
            return false
        end        
    else
	    require ("teamf1lualib/ifDev")
        local info = ifDevLib.netIfInfoGet(LogicalIfName)
        if (info.state == ifDev.netstate.IFDEV_NET_DOWN) then
            return false
        end                        
    end        

    return true
end
