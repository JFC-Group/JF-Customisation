-- timeCLI.lua
-- Gaurav Mathur
-- TeamF1
-- www.TeamF1.com

-- Modification History
-- 28jan08,gnm modified error message text in input validation routines.
-- 28nov07 gnm written
--
-- Description
-- CLISH time LUA routines

-- load required library
require "teamf1lualib/time"

--
-- This routine save user password configuration information
function timeConfigInputVal (configRow)

    if configRow["ntp.useDefServers"] == "0" then
       if configRow["ntp.server1"] == nil then
	  printCLIError ("Invalid time-server name or IP address for server1")
          return FALSE			
       end
    end

    return TRUE
end

--
-- This routine save user password configuration information
function timeConfigSave (configRow)
    local errorFlag = "ERROR"
    local statusCode = ""
    local statusMessage = ""

    -- Write configuration to database
    errorFlag, statusCode = time.ntp_config (configRow, 
	       configRow["ntp._ROWID_"], "edit")
	       
    statusMessage = db.getAttribute("stringsMap", "stringId", statusCode, LANGUAGE)
    return errorFlag, statusMessage
end

--
-- This routine takes in one argument that is the value of the
-- primary key for the object table.
function timeConfigInit (args)
    local configRow = {}
    local rowId = 1 -- NTP table only only one row

    configRow = db.getRow("ntp", "ntp._ROWID_", rowId)
    -- clear fields we do not want with current values in database 
    return rowId, configRow
end