--[[ easyMeshTopology.lua - Handler for Easy Mesh Topology (WiFiSON) request
--
-- Copyright (c) 2008-2019, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: easyMeshTopology.lua
-- Description: Handler for Easy Mesh Topology (WiFiSON) request
-- 
-- modification history
-- --------------------
-- 01a, 18Dec19, ar written.
--
--]]

require "easyMeshLib"
require "teamf1lualib/easyMeshTopologyLib"

-- WiFiSON Object as defined by Customer Specification.
local WiFiSonRequestObj = {
    ["WiFiSON"]      = {}
}

-- List of WiFiSon Tags as defined by Customer Specification.
local WiFiSonObj = {
    ["Result"] = "Result"
}

-- Initialise the WiFiSonResponse_t Lua Table which will be coverted as JSON Object
local WiFiSonResponse_t = {
    ["Result"] = "ERROR",
    ["Response_Code"] = "400",
    ["Error_Message"] = "Failed to get WiFiSON"
}

-- Supported Return Codes for "LoginResponse"
local WiFiSonResponse_ReturnCodes = {
    ["OK"] = "OK",
    ["ERROR"] = "ERROR",
    ["SUCCESS"] = "Success",
    ["FAILED"]  = "Failed",
}

if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then
	TOPOLOGY_DUMP_GENERATE_CMD = "/bin/sh /pfrm2.0/bin/brcmGenerateDump.sh"
else
	TOPOLOGY_DUMP_GENERATE_CMD = "/userfs/bin/mapd_cli /tmp/mapd_ctrl dump_topology_v1"
end
TOPOLOGY_DUMP_FILE = "/tmp/dump.txt"
INTERNET_FILE_CHECK = "/tmp/gponFailed"


----------------------------------------------------------------------------------
-- @name getEasyMeshTopologyHandler
--
-- @description This function Handles EasyMesh Topology (WiFiSON) Request Method.
--
-- @return JSON response to EasyMesh Topology request
--
function getEasyMeshTopologyHandler(methodObj, meshRequestMethod)
   
    local status
    local WiFiSonObj    = methodObj["WiFiSON"]
    local topology_t

    if ((WiFiSonObj == nil) or (type(WiFiSonObj) ~= "table")) then
        WiFiSonResponse_t["Result"] = WiFiSonResponse_ReturnCodes["FAILED"]
        WiFiSonResponse_t["Response_Code"] = "400"
        WiFiSonResponse_t["Error_Message"] = "Bad Request"
        --mesh.sendResponse (WiFiSonResponse_t) 
        return "ERROR", "INVALID_METHOD",WiFiSonResponse_t
    end

    -- generate topology dump.txt by executing below command.
    util.runShellCmd(TOPOLOGY_DUMP_GENERATE_CMD, "/dev/null")

    if (not (util.fileExists (TOPOLOGY_DUMP_FILE))) then
        WiFiSonResponse_t["Result"] = WiFiSonResponse_ReturnCodes["FAILED"]
        WiFiSonResponse_t["Response_Code"] = "501"
        WiFiSonResponse_t["Error_Message"] = "No Data Available"
        --mesh.sendResponse (WiFiSonResponse_t) 
        return "ERROR", "INVALID_METHOD",WiFiSonResponse_t
    end

    -- convert the generated topology dump.txt file to a Lua Table
    topology_t = json.decode(util.fileToString (TOPOLOGY_DUMP_FILE))

    if (topology_t == nil) then
        WiFiSonResponse_t["Result"] = WiFiSonResponse_ReturnCodes["FAILED"]
        WiFiSonResponse_t["Response_Code"] = "501"
        WiFiSonResponse_t["Error_Message"] = "No Data Available"
        --mesh.sendResponse (WiFiSonResponse_t) 
        return "ERROR", "INVALID_METHOD",WiFiSonResponse_t
    end

    status, WiFiSonResponse_t = easyMeshTopologyLib.getMeshTopologyNodes(topology_t)
    if (status ~= "OK") then
        WiFiSonResponse_t["Result"] = WiFiSonResponse_ReturnCodes["FAILED"]
        WiFiSonResponse_t["Response_Code"] = "501"
        WiFiSonResponse_t["Error_Message"] = "No Data Available"
        --mesh.sendResponse (WiFiSonResponse_t) 
        return "ERROR", "INVALID_METHOD",WiFiSonResponse_t
    end

    WiFiSonResponse_t[WIFISON_NUMBER] = #WiFiSonResponse_t[WIFISON_NODE]

    if (util.fileExists (INTERNET_FILE_CHECK)) then
        WiFiSonResponse_t[WIFISON_INTERNET] = "0"
    else
        WiFiSonResponse_t[WIFISON_INTERNET] = "1"
    end
    WiFiSonResponse_t["Result"] = WiFiSonResponse_ReturnCodes["OK"]
    WiFiSonResponse_t["Response_Code"] = "200"
    WiFiSonResponse_t["Error_Message"] = nil
    
    --mesh.sendResponse (WiFiSonResponse_t) 
    return "OK", "SUCCESS",WiFiSonResponse_t
end

meshRequestMethodsList["WiFiSON"]["methodHandler"] = getEasyMeshTopologyHandler

