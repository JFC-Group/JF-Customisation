--[[
#### Abhay Kumar
#### TeamF1
#### www.TeamF1.com
#### March 07, 2019
#### Copyright (c) 2007 - 2010, TeamF1, Inc.

#### File: passwordStrengthChecker.lua
#### Description: password strength checker

#### Revisions:
01a,07mar2018,abh created
]]--


require "teamf1lualib/frequencyList"


passwdStrChk = {}
Common_Words = {}
Frequency_Table = {}

-- The frequency thing is a bit more interesting, but still not too complex.
-- Each three letters are base-95 encoded number representing the chance that
-- this combination comes next.  Subtract the value of ' ' from each of the
-- three, then ((((first_value * 95) + second_value) * 95) + third_value) will
-- give you the odds that this pair is grouped together.  The first is "  "
-- (non-alpha chars), then " a", " b", etc. " y", " z", "a ", "aa", "ab", and
-- so on.  If you decrypt the table successfully, you should see a really large
-- number for "qu"
function passwdStrChk.Parse_Frequency_Token()
    local c

    c = string.byte(Frequency_List,1) - string.byte(' ')
    c = c / 95
    c = c + string.byte(Frequency_List,2) - string.byte(' ')
    c = c / 95
    c = c + string.byte(Frequency_List,3) - string.byte(' ')
    c = c / 95
    
    Frequency_List = string.sub(Frequency_List, 4, #Frequency_List)
    Frequency_Table[#Frequency_Table+1] = c
end

function passwdStrChk.Parse_Frequency()
    local i = 1
    while (i <= 100 and #Frequency_List > 0) do
        passwdStrChk.Parse_Frequency_Token()
        i = i+1
    end
    if #Frequency_List > 0 then
        passwdStrChk.Parse_Frequency()
    end
end

function passwdStrChk.Get_Index(c)
    c = tonumber(string.byte(string.lower(c), 1))
    a = string.byte('a', 1)
    z = string.byte('z', 1)
    if (c < a or c > z) then
        return 0
    end
    return c - a + 1
end

function passwdStrChk.Get_Charset_Size(passwd)
    local a, u, n, ns, sp, s, chars = 0, 0, 0, 0, 0, 0, 0
    local an = 0
    spAscLower = string.byte(' ')
    spAscUpper = string.byte('~')
    for i = 1, #passwd, 1 do
        c = string.sub(passwd, i, i)
        if (a == 0 and string.find(c ,"%l") ~= nil) then
            chars = chars + 26
            a = 1
            an = an + 1
        end
        if (u == 0 and string.find(c,"%u") ~= nil) then
            chars = chars + 26
            u = 1
            an = an + 1
        end
        if (n == 0 and string.find(c,"%d") ~= nil) then
            chars = chars + 10
            n = 1
            an = an + 1
        end
        if (ns == 0 and string.find(c,"%p") ~= nil) then
            chars = chars + 10
            ns = 1
            an = an + 1
        end
        if (sp == 0 and c == ' ') then
            chars = chars + 1
            sp = 1
        end
        if (s == 0 and (string.byte(c) < spAscLower or 
        string.byte(c) > spAscUpper)) then
            chars = chars + 32 + 128
            s = 1
        end
    end

    if (an < 4) then
        chars = an 
    end

    return chars
end

function passwdStrChk.passwd_Status(passwd)

    local plower
    local rTxt = ""
    local dict_size = #Common_Words
    local CharSet

    if (passwd == nil or #passwd == 0) then
        rTxt = rTxt .. "Please Enter the password! "
        return rTxt
    end

    plower = string.lower(passwd)

    -- check the environment initializers
    if (dict_size == 0 or #Frequency_Table == 0) then
        passwdStrChk.setEnv()
        dict_size = #Common_Words
    end

    if (#passwd <= 4) then
        rTxt = rTxt .. "Very short password! "
        return rTxt
    elseif (#passwd < 8) then
        rTxt = rTxt .. "Short password! "
        return rTxt
    end

    -- check for common password in WordList
    for i = 1, dict_size, 1 do
        if Common_Words[i] == plower then
            i = dict_size 
            rTxt = rTxt .. "COMMON PASSWORD NOT ALLOWED "
            return rTxt
        end
    end

    CharSet = passwdStrChk.Get_Charset_Size(passwd)
    if (CharSet < 4) then
        rTxt = rTxt .. "Password must contain Uppercase, Lowercase, Number and Special Character"
        return rTxt
    end

    -- Calculate frequency chance
    if (#passwd > 1) then
        local aidx=0
        local bits=0
        local c, charSet
        charSet = math.log(passwdStrChk.Get_Charset_Size(passwd)) / math.log(2)
        aidx = passwdStrChk.Get_Index(string.sub(plower, 1, 1))
        -- print(plower, #plower)
        for idx = 2, #plower, 1 do
            bidx = passwdStrChk.Get_Index(string.sub(plower, idx, idx))
            fIdx = aidx * 27 + bidx + 1
            c = 1 - Frequency_Table[fIdx]
            bits = bits + charSet * c * c
            -- print("aidx, bidx, c", aidx, bidx, c)
            aidx = bidx
        end
        
        if (bits < 28) then
            rTxt = rTxt .. "VERY WEAK PASSWORD: "
            rTxt = rTxt .. "Try making your password longer "
        elseif (bits < 36) then
            rTxt = rTxt .. "WEAK PASSWORD: "
            rTxt = rTxt .. "Try making your password longer "
        elseif (bits < 60) then
            rTxt = rTxt .. "REASONABLE PASSWORD: "
            rTxt = rTxt .. "Password is fairly secure but not enough "
        elseif (bits < 128) then
            rTxt = rTxt .. "STRONG PASSWORD: "
            rTxt = rTxt .. "Typically good enough. "
        else
            rTxt = rTxt .. "VERY STRONG PASSWORD: "
            rTxt = rTxt .. "This level of security is overkill. "
        end

        return rTxt

    end
end


function passwdStrChk.setEnv()
    local file = io.open("/pfrm2.0/etc/udict", "r");
    if (file ~= nil) then
        for line in file:lines() do
            table.insert (Common_Words, line);
        end
    end
    passwdStrChk.Parse_Frequency()
end

