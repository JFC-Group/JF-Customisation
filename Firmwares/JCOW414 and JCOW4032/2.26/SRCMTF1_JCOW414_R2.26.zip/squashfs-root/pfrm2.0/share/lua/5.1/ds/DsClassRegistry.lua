--[[
    Copyright (c) 2010, TeamF1, Inc. All rights reserved.
]]--


DsClassRegistry = {}

local dsClassTable = {
   -- classId        -- Lua class     list view             detail view
}

function DsClassRegistry.getDsClassTbl()
   LOG:info("getting ds class table")
   return dsClassTable
end

return DsClassRegistry 
--[[ $Id: DsClassRegistry.lua 664 2010-04-08 03:17:04Z prasanna@hrefmed.com $ ]]--
