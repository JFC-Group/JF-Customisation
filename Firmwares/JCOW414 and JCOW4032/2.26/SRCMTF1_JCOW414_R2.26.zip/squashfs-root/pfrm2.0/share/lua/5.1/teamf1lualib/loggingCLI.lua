-- loggingCLI.lua
-- Gaurav Mathur
-- TeamF1
-- www.TeamF1.com

-- Modification History
-- 28jan08,gnm modified error message text in input validation routines.
-- 06nov07,gnm written
--
-- Description
-- CLI logging get and set routines

require "teamf1lualib/logging"

--
--
function syslogCfgInputVal(configRow)
    if (configRow["emailLogs.logId"] == nil) then
        printCLIError ("Invalid log identifier.")
        return false
    end

    -- We need to do this to handle a problem with the routine
    -- logging.emailLogs_config(). That routine fails if there's no if
    -- the emailLogs table does not have any row. Therefore, we add a
    -- check here to see if the field emailLogs.mailLogs is present in
    -- the config object first.  If the emailLogs did not have any row
    -- this field value would be nil and we can avoid updating
    -- emailLogs.mailLogs.        
    if (configRow ["emailLogs.mailLogs"] ~= nil or	
       configRow ["emailLogs.mailLogs"] == "1") then
	configRow ["emailLogs.mailLogs"] = configRow ["emailLogsEnable"]
    end
    configRow ["emailLogsEnable"] = nil       

    if (configRow ["crontabunit"] ~= nil) then
	configRow ["crontab.unit"] = configRow ["crontabunit"]
    end
    configRow ["crontabunit"] = nil -- remove this field
    
    if (configRow["emailLogs.mailLogs"] == "1") then
    
        if (configRow["smtpServer.emailServer"] == nil or
	   configRow["smtpServer.emailServer"] == "") then
            printCLIError ("Invalid email server address.")
            return false
        end

	if (configRow["smtpServer.fromAddr"] == nil or
	   configRow["smtpServer.fromAddr"] == "") then
	    printCLIError ("Invalid return email address.")
            return false
        end

	if (configRow["smtpServer.toAddr"] == nil or
	   configRow["smtpServer.toAddr"] == "") then
	    printCLIError ("Invalid email address to send the logs to.")
	    return false
        end

	if (configRow["smtpServer.auth"] == nil) then
	   printCLIError ("Invalid SMTP authentication mechanism.")
	   return false
        elseif (configRow["smtpServer.auth"] ~= "-1") then
	    if (configRow["smtpServer.userName"] == nil or
	       configRow["smtpServer.userName"] == "") then
		printCLIError ("Invalid SMTP server login user name.")
		return false
            end
	    if (configRow["smtpServer.passWord"] == nil or
	       configRow["smtpServer.passWord"] == "") then
	        printCLIError ("Invalid SMTP server login password.")
		return false
            end
        end
	
	if (configRow["crontab.unit"] == "2" or 
	   configRow["crontab.unit"] == "3") then
	   if (configRow["crontab.hour"] == nil or
	    -- why these values come to be -1 is a mystery but we'll
	    -- handle it for now.
	      configRow["crontab.hour"] == "-1") then
	      configRow["crontab.hour"] = "0" -- set default
           end
	   if (configRow["crontab.meridiem"] == nil) then
	      configRow["crontab.meridiem"] = "0" -- set default
           end
        end

	if (configRow["crontab.unit"] == "3" and
	   (configRow["crontab.dayOfWeek"] == nil or
	    -- again, why this values can be -1 is a mystery but we'll
	    -- handle it for now.
	   configRow["crontab.dayOfWeek"] == "-1")) then
	   configRow["crontab.dayOfWeek"] = "0" -- set default
        end
    end

    return true
end

--
-- This routines save the modified syslog configuration.
function syslogCfgSave(configRow)
    local errorFlag = "ERROR"
    local statusCode = ""
    local statusMessage = ""

    errorFlag, statusCode = logging.emailLogs_config (configRow)
    if (errorFlag == "OK") then db.save() end
    statusMessage = db.getAttribute("stringsMap", "stringId", statusCode, LANGUAGE)

    return errorFlag, statusMessage
end

--
-- This routine retrieves the current syslog configuration information 
-- from the system.
function syslogCfgInit(args)
    local primKey = args[1] -- Profile name
    local rowId = -1

    configRow = logging.emailLogs_getInfo()
    if configRow == nil then
       configRow = {} 
       return rowId, configRow       
    end
    return rowId, configRow       
end


--
-- This routine validates the logging information. 
-- Note: Always returns true
function loggingCfgInputVal(configRow)
    return true
end

--
-- This routine save the modified logging information.
function loggingCfgSave(configRow)
    local errorFlag = "ERROR"
    local statusCode = ""
    local statusMessage = ""
    local cur = nil
    local errstr = nil

    if (configRow["sysLogInfo.serverName"] ~= nil) then
        if (db.existsRow ("sysLogInfo", "_ROWID_", 1)) then
            cur,errstr = db.update ("sysLogInfo", configRow, 1)
        else
            cur,errstr = db.insert ("sysLogInfo", configRow)
        end

        if (errstr == "") then 
            db.save() 
        else
	    statusCode = "LOGGING_SYSLOG_CONFIG_FAILED"
	    statusMessage = db.getAttribute("stringsMap", "stringId", statusCode, LANGUAGE)
	    return errorFlag, statusMessage
        end
	configRow["sysLogInfo.serverName"] = nil
    end
    
    configRow["logConfig.emergency"] = util.joinBitFields(configRow,
				     "logConfig", "emergency", ".", 4, true)
    configRow["logConfig.alert"] = util.joinBitFields(configRow, 
				 "logConfig", "alert", ".", 4, true)
    configRow["logConfig.critical"] = util.joinBitFields(configRow, 
				    "logConfig", "critical", ".", 4, true)
    configRow["logConfig.error"] = util.joinBitFields(configRow, "logConfig", 
				 "error", ".", 4, true)
    configRow["logConfig.warning"] = util.joinBitFields(configRow, "logConfig", 
				   "warning", ".", 4, true)
    configRow["logConfig.notice"] = util.joinBitFields(configRow, "logConfig", 
				  "notice", ".", 4, true)
    configRow["logConfig.information"] = util.joinBitFields(configRow, 
				       "logConfig", "information", ".", 4, true)
    configRow["logConfig.debug"] = util.joinBitFields(configRow, "logConfig", 
				 "debug", ".", 4, true)

    errorFlag, statusCode = logging.logConfig_config(configRow, 
	       configRow["logConfig._ROWID_"], "edit")
    -- save db if no error
    if (errorFlag == "OK") then db.save() end
    statusMessage = db.getAttribute("stringsMap", "stringId", statusCode, LANGUAGE)
    return errorFlag, statusMessage
end

--
--
function loggingCfgInit(args)
    local primKey = args[1] -- Profile name
    local rowId = -1

    configRow = db.getRow("logConfig", "logConfig.facility", primKey) --set configRow
    if configRow == nil then
       configRow = {} 
       return rowId, configRow       
    end

    local emergencyChoices = util.integerToBits(configRow["logConfig.emergency"])
    local alertChoices = util.integerToBits(configRow["logConfig.alert"])
    local criticalChoices = util.integerToBits(configRow["logConfig.critical"])
    local errorChoices = util.integerToBits(configRow["logConfig.error"])
    local warningChoices = util.integerToBits(configRow["logConfig.warning"])
    local noticeChoices = util.integerToBits(configRow["logConfig.notice"])
    local informationChoices = util.integerToBits(configRow["logConfig.information"])
    local debugChoices = util.integerToBits(configRow["logConfig.debug"])

    local fld;
    for idx = 1, 4 do
	    fld = "logConfig.emergency" .. idx
	    configRow[fld] = emergencyChoices[idx] or 0
	    fld = "logConfig.alert" .. idx
	    configRow[fld] = alertChoices[idx] or 0
	    fld = "logConfig.critical" .. idx
	    configRow[fld] = criticalChoices[idx] or 0
	    fld = "logConfig.error" .. idx
	    configRow[fld] = errorChoices[idx] or 0
	    fld = "logConfig.warning" .. idx
	    configRow[fld] = warningChoices[idx] or 0
	    fld = "logConfig.notice" .. idx
	    configRow[fld] = noticeChoices[idx] or 0
	    fld = "logConfig.information" .. idx
	    configRow[fld] = informationChoices[idx] or 0
	    fld = "logConfig.debug" .. idx
	    configRow[fld] = debugChoices[idx] or 0
    end
    rowId = configRow["logConfig._ROW_ID_"]
    return rowId, configRow
end
