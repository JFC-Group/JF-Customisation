-- @copyright Copyright (c) 2012, TeamF1, Inc. 

service = {}

require "appLib"

-------------------------------------------------------------------------------
-- @name service.start
--
-- @description  This function starts the service with the given name
-- 
-- @param  name name of the service
--
-- @return  0 for success, -1 for error
--

function service.start(name, instanceId)
    local status

    if (name == nil) then
        return -1
    end
            
    status = appLib.start(name, instanceId)
    if (status < 0) then
        return status
    end        
                    
    return 0
end

-------------------------------------------------------------------------------
-- @name service.stop
--
-- @description  This function stops the service with the given name
-- 
-- @param  name name of the service
--
-- @return  0 for success, -1 for error
--

function service.stop(name, instanceId)
    local status

    if (name == nil) then
        return -1
    end
            
    status = appLib.stop(name, instanceId)
    if (status < 0) then
        return status
    end        
                    
    return 0
end

-------------------------------------------------------------------------------
-- @name service.restart
--
-- @description  This function restarts the given service
-- 
-- @param  name name of the service
--
-- @return  0 for success, -1 for error
--

function service.restart(name, instanceId)
    local status

    if (name == nil) then
        return -1
    end
            
    status = appLib.restart(name, instanceId)
    if (status < 0) then
        return status
    end        
                    
    return 0
end

-------------------------------------------------------------------------------
-- @name service.status
--
-- @description  This function gets the status of the given service
--  
-- @param  name name of the service
--
-- @return  -1 for error, 1 = running, 0 = not running.
--

function service.status(name, instanceId)
    local status

    if (name == nil) then
        return -1
    end
            
    status = appLib.status(name, instanceId)
    if (status < 0) then
        return status
    end        
                    
    return status
end
