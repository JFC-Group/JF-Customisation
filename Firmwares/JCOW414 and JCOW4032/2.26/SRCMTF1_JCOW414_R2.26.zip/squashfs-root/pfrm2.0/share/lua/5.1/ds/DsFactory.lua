--[[
		Copyright(c) 2008, 2009 - TeamF1, Inc.
		All rights reserved.

DsFactory.lua -- This class implements a factory to fetch the class
	      --objects corresponding to a class. It typically
	      --implements a switch statement and returns the class
	      --object corresponding to a class name.

 $Id: DsFactory.lua 2156 2011-05-24 12:35:02Z prasanna@teamf1.com $ 
]]--

require("ds/Ds")
require("oo/OoUtil")

require("ds/DsClassRegistry")
require("lualogging/lsyslog")
pcall(require, "teamf1luaUiLib/I18N")

local isInitialized = false
local THE_FACTORY = nil
local dsClassTable = {}
local tf1debug = logging.syslog("DS")

DsFactory = OoUtil.inheritsFrom(nil)

-- Init factory. Creates a new instance of DsFactory if it hasnt been
-- created already.
function DsFactory.init() 
   if (not isInitialized) then
      THE_FACTORY = DsFactory:new()
      THE_FACTORY:registerClassTbl(DsClassRegistry.getDsClassTbl())
      isInitialized = true
   end
end

-- Returns the singleton factory
function DsFactory.getFactory()
   if (not isInitialized) then 
      DsFactory.init() 
   end
   return THE_FACTORY
end

function DsFactory:new()
   if (self == DsFactory) then
       self = DsFactory.create()
   end

   self._classTbl = {}
   self.classLoader = nil

   return self
end

function DsFactory:setClassLoader(loader) 
   self.classLoader = loader    --function
end

function DsFactory:load(classId, instanceId, options)
   --if (classId == nil) then
   --   require("debugger");pause()
   --end
   assert(classId and instanceId, 
          "DsFactory:load() - classId and instanceId are required. " ..
          "Args given: ("..tostring(classId)..","..tostring(instanceId)..")")
   local dsDummy,err = self:newObject(classId, instanceId, options)
   if (dsDummy == nil) then
	   return "ERROR", "Interal error: " .. tostring(err or "-"), obj
   end
   local stat, errCode, msg, obj = 
        pcall(dsDummy.load, dsDummy, classId, instanceId, options)
   if (stat == false or errCode == "ERROR" or obj == nil) then
      tf1debug:error("Unable to load DS of type: ".. tostring(classId) .. ", " .. 
                     "#: ".. tostring(instanceId)  .. " error: ".. tostring(errCode))
	  return "ERROR", msg, obj
   end
   return "OK", msg, obj
end

function DsFactory:newObject(classId, instanceId, props)
   local classObj,errorStr = self:getClass(classId)
   assert(classObj ~= nil, "Unknown Ds class: ".. classId)
   if (classObj == nil and errorStr ~= nil) then
       return nil, errorStr
   end
   local stat, obj = pcall(classObj.new, classObj, classId, instanceId, props)

   if (not stat) then
      tf1debug:error("Unable to create DS of type: ".. 
	     classId .. ", #: ".. instanceId)
	  return nil, obj  -- obj here contains the error string
   end
   return obj
end

function DsFactory:query(classId, filter, options) 
   local dsClassObj = self:getClass(classId)
   assert(dsClassObj ~= nil, "Unknown Ds class: ".. classId)
   local dsDummy = dsClassObj:new(classId, 0)
   local errCode, msg, dsList = dsDummy:query(filter, options)
   return errCode, msg, dsList
end


function DsFactory:register(classId, classMetaInfo)
   self._classTbl[classId] = classMetaInfo
end


function DsFactory:registerClassTbl(dsClassTable)
   local classId, dsClassName

   for classId, registryEntry in pairs(dsClassTable) do
      local dsClassName = registryEntry.dsClass
      if (dsClassName ~= nil) then
          local stat, dsClassObj = pcall(require,"ds/"..dsClassName)
          if (stat) then
    	     registryEntry.classObj = dsClassObj
        	 self:register(classId, registryEntry)
          end
      end
   end
end


function DsFactory:getClass(classId)
   local classObj = nil
   -- External loader. If set, use it otherwise use the default
   -- loading mechanism
   if (self.classLoader ~= nil) then
      classObj = self.classLoader.load(classId)
      if (classObj) then 
         return classObj 
      end
   end
   local meta = self._classTbl[classId]
   if (meta and meta.classObj) then
      return meta.classObj
   end
   -- try to guess the class 
   local guessClassList = {classId .."Ds"}
   local guessPkgList = {'', 'ds/'} --should end in '/' for non-blank pkg name

   local i, i, pkgName, className
   for i, pkgName in ipairs(guessPkgList) do
      for j, className in ipairs(guessClassList) do
         local fullClassName = pkgName .. className
         -- print("Full class name:", fullClassName)
         local function myRequire()
            -- print("require ", fullClassName)
            return require(fullClassName)
         end
         local function errFunc(err)
            -- print('error:', err)
            return true
         end 
         
         local stat, classObj = xpcall(myRequire, errFunc)
         if (stat) then
            -- print ("classObj:",classObj)
            return classObj
         end
      end
   end
   return nil
end

function DsFactory:DBG_DUMP()
   table.foreach(self._classTbl, print)
end

function DsFactory:getDsClassName(classId)
   local meta = self._classTbl[classId]
   if (not meta) then
      return nil
   end
   return meta.dsClass
end

function DsFactory:getPage(classId, instanceId, viewType)
   local registryEntry = self._classTbl[classId]
   if (not registryEntry) then
      return nil
   end
   if (viewType == nil) then
      if (instanceId == nil or instanceId==0) then
	 viewType = "list"
      else
	 viewType = "edit"
      end
   end
   if (viewType == nil) then 
      viewType = "list" -- default
   end
   return registryEntry[viewType]
end

-- Save an existing object or create a new one 
function DsFactory:save(classId, instanceId, input)
   local dsObj = nil
   local errCode, msg, results = "OK", nil, nil
   if (instanceId ~= nil and instanceId ~= -1) then
      -- load
      errCode, msg, dsObj = self:load(classId, instanceId)
   else
      -- create
      dsObj = self:newObject(classId, instanceId, {})
   end
   errCode, msg = dsObj:setProps(input)
   errCode, msg, results = dsObj:save()
   return errCode, msg, results
end

-- Generic/custom operation implemented by a data source. This method
-- allows user to invoke any generic operation from a client, provided
-- its defined on the Ds class.
--
function DsFactory:op(classId, instanceId, input)
   local dsObj = nil
   local errCode, msg, results = "OK", nil, nil
   local op = input.operation or input.o
   if (instanceId ~= nil and instanceId ~= -1) then
      -- Load
      errCode, msg, dsObj = self:load(classId, instanceId)
   else
      -- create
      dsObj = self:newObject(classId, instanceId, {})
   end

   if (op == nil or dsObj[op] == nil) then
      errCode = "ERROR"
      msg = string.format([[Unknown Operation "%s" for class: "%s"]],
			   tostring(op), classId)
   else
      pstat, errCode, msg, results = pcall(dsObj[op], dsObj, input)
   end
   if (not pstat) then
      tf1debug:error(errCode)
      errCode, msg = "ERROR", "Internal Error: " .. tostring(errCode)
   end
   return errCode, msg, results
end

-- Load the relevant class by class name, get actions from a dummy
-- instance of that class and return the list
function DsFactory:getListActions(classId) 
   local dsClass = self:getClass(classId)
   assert(dsClass ~= nil, "Unknown Ds class: "..classId)
   local actionList = {}
   if (not dsClass) then return actionList end
   local stat, dummyInstance = pcall(dsClass.new, dsClass, classId, -1)
   if (not stat) then
      return actionList
   end
   actionList = dummyInstance:getListActions(classId)
   return actionList or {}
end

function DsFactory:getTranslatedListActions(classId)
   local actions = self:getListActions(classId)
   for i, action in ipairs(actions) do
      action.label = I18N.tr(action.label)
   end
   return actions
end

return DsFactory
