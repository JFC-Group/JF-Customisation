-- gui.voip.lua - lua wrapper calls for voip for the Main Firmware

-- Copywrite (c) 2013 TeamF1, Inc.

--
-- modification history
-- --------------------
-- 01a, 12Mar13, sen dervied from reference solution. for RIL.
--

---------------------------------------------------------------------------------
--  The routines in this lua wrapper are called by htm(user interface) layer to 
--  get & set the information for Download & Upgrade
---------------------------------------------------------------------------------

--[[Get and Set Functions]]--
gui.voipSettings = {}

gui.voipSettings.voipConfiguration = {}
-------------------------------------------------------------------------------
-- @name gui.voip.get 
--
-- @description This function gets the voip information for a particular profile
-- 
-- @return 
--

function gui.voipSettings.voipConfiguration.profileGet (voipLine)

       -- include
       require "teamf1lualib/voip"

       -- locals
       local voipTbl = {}
       local localTbl = {}
       local err, status = "ERROR" ,"DB_ERROR_TRY_AGAIN"
    
       -- getting the voip table
       voipTbl = voip.voipProfileConfGet(voipLine)
       if (voipTbl == nil) then
            return err, status, localTbl
       end

       -- return success
       err = "OK"
       status = "SUCCESS"
       
       return err, status, voipTbl 
end

-------------------------------------------------------------------------------
-- @name gui.voipSettings.voipConfiguration.profileSet
--
-- @description This function sets the voip information for a particular profile
-- 
-- @return 
--
function gui.voipSettings.voipConfiguration.profileSet (cfgTbl)
        
       -- include
       require "teamf1lualib/voip"

       --local
       local err, status = "ERROR" ,"DB_ERROR_TRY_AGAIN"

       -- setting the values inside the voip related tables
       err, status = voip.voipProfileEditSet(cfgTbl)

       -- return
       return err, status
end

-------------------------------------------------------------------------------
-- @name gui.voipSettings.voipConfiguration.lineGet
--
-- @description This function gets the voip information for a particular line
-- 
-- @return 
--
function gui.voipSettings.voipConfiguration.lineGet (voipLine)

       -- include
       require "teamf1lualib/voip"

       -- locals
       local voipTbl = {}
       local localTbl = {}
       local err, status = "ERROR" ,"DB_ERROR_TRY_AGAIN"
    
       -- getting the voip table
       voipTbl = voip.voipLineSettingsGet(voipLine)
       if (voipTbl == nil) then
            return err, status, localTbl
       end

       -- return success
       err = "OK"
       status = "SUCCESS"
       
       return err, status, voipTbl 
end

-------------------------------------------------------------------------------
-- @name gui.voipSettings.voipConfiguration.lineSet
--
-- @description This function sets the voip information for a particular line
-- 
-- @return 
--

function gui.voipSettings.voipConfiguration.lineSet (cfgTbl,tab)
        
       -- include
       require "teamf1lualib/voip"

       --local
       local err, status = "ERROR" ,"DB_ERROR_TRY_AGAIN"

       -- setting the values inside the voip related tables
       err, status = voip.voipLineSettingsEditSet(cfgTbl,tab)

       -- return
       return err, status

end

-------------------------------------------------------------------------------
-- @name gui.voipSettings.voipConfiguration.voipTLSCertSet
--
-- @description This function sets the voip TLS certificates accordingly
-- 
-- @return 
--

function gui.voipSettings.voipConfiguration.voipTLSCertSet (cfgTbl, Id)
        
       -- include
       require "teamf1lualib/voip"

       --local
       local err, status = "ERROR" ,"DB_ERROR_TRY_AGAIN"

       -- setting the values inside the voip related tables
       err, status = voip.voipProfileTLSCertSet (cfgTbl,Id)

       -- return
       return err, status

end

-------------------------------------------------------------------------------
-- @name gui.voipSettings.voipConfiguration.voipTLSCertDel
--
-- @description This function deletes the voip TLS certificates accordingly
-- 
-- @return 
--

function gui.voipSettings.voipConfiguration.voipTLSCertDel (uniqueId, rowId)
        
       -- include
       require "teamf1lualib/voip"

       --local
       local err, status = "ERROR" ,"DB_ERROR_TRY_AGAIN"

       -- setting the values inside the voip related tables
       err, status = voip.voipProfileTLSCertDelete (uniqueId, rowId)

       -- return
       return err, status

end








