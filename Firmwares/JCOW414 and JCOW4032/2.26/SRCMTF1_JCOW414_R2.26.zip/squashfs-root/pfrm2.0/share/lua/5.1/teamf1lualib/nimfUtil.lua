

--[[
*******************************************************************************
-- @name nimf.dprintf
--
-- @description 
--
-- @param 
--
-- @return 
--
--]]

function nimf.dprintf(str)
    if (str == nil) then
        return
    end

    if (nimf.debug == 1) then
        print ("NIMF: " .. str)
        return
    end        

    if ((gui ~= nil) and (gui.debug == 1)) then
        util.appendDebugOut ("NIMF: "  .. str .. "<br>")
    end        

    return 
end

--[[
*******************************************************************************
-- @name nimf.config
--
-- @description 
--
-- @param conf
-- @param rowid
-- @param operation
--
-- @return 
--]]

function nimf.config (conf, rowid, operation)
    if (operation == "add") then
        return db.insert("NimfConf", conf)
    elseif (operation == "edit") then
        return db.update("NimfConf", conf, rowid)
    elseif (operation == "delete") then
		return db.delete("NimfConf", conf)
    end
end

--[[
*******************************************************************************
-- @name nimf.connStrGet
--
-- @description 
--
-- @param conftable
--
-- @return 
--
--]]

function nimf.connStrGet(conf)
    local LogicalIfName = conf["LogicalIfName"]
    local AddressFamily = conf["AddressFamily"]
    local ConnectionKey = conf["ConnectionKey"]
    local str = ""

    if ((LogicalIfName ~= nil) and (AddressFamily ~= nil) and (ConnectionKey ~= nil)) then
        str = "(" .. LogicalIfName .. "," .. AddressFamily .. "," 
                  .. ConnectionKey .. ")"
    elseif ((LogicalIfName ~= nil) and (AddressFamily ~= nil)) then
        str = "(" .. LogicalIfName .. "," .. AddressFamily .. ")" 
    elseif ((LogicalIfName ~= nil)) then
        str = "(" .. LogicalIfName .. ")" 
    end                  
    
    return str
end

--[[
*******************************************************************************
-- @name nimf.protocolValidate 
--
-- @description The function checks if the given protocol is supported
--
-- @param AddressFamily  protocol family
--
-- @return  0 for success else -1
--]]

function nimf.protocolValidate (AddressFamily)

    if (AddressFamily == nil) then
        nimf.dprintf("AddressFamily is mandatory")
        return -1
    end
    if (platformLib.strcasecmp(AddressFamily, "ipv4") == 0) then
        AddressFamily = nimf.proto.NIMF_PROTO_TYPE_IPV4
    end        

    if (platformLib.strcasecmp(AddressFamily, "ipv6") == 0) then
        AddressFamily = nimf.proto.NIMF_PROTO_TYPE_IPV6
    end        
            
    if ((tonumber(AddressFamily) ~= nimf.proto.NIMF_PROTO_TYPE_IPV4)  and
        (tonumber(AddressFamily) ~= nimf.proto.NIMF_PROTO_TYPE_IPV6)) then
        nimf.dprintf("Network protocol(" .. AddressFamily .. ") not supported")
        return -1
    end        

    return 0
end

--[[
*******************************************************************************
-- @name nimf.LogicalNameValidate - validate network ID
--
-- @description 
--
-- @param 
--
-- @return  0 for success else -1
--]]

function nimf.LogicalNameValidate (LogicalIfName)

    if (LogicalIfName == nil) then
        nimf.dprintf("Network name is mandatory")
        return -1
    end       
        
    if (string.len(LogicalIfName) >  nimf.limits.NIMF_NET_NAME_SZ) then
        nimf.dprintf("Network name length exceeds size. Must be less than "
                     .. nimf.NIMF_NET_NAME_SZ)
        return -1
    end

    return 0
end

--[[
*******************************************************************************
-- @name nimf.hasTableChanged - 
--
-- @description 
--
-- @param 
--
-- @return  true for success else  false
--]]

function nimf.hasTableChanged(tablename, tableInput, rowId)
	local allKeys = db.getColNames(tablename)
    local fieldsSetString  = ""

	-- make strings
	for k, v in pairs(tableInput) do
		-- if the column actually exists
		if (util.keyTableValueExists(allKeys, k) ~= nil) then
			local field = k
            if (v ~= nil) then
    			if (db.getAttribute(tablename, "_ROWID_", rowId, field) == v) then
	        	    util.appendOut("field " .. field .. " hasnt changed<br>")
		        else
			        fieldsSetString = fieldsSetString .. field .. " = \'" .. v .. "\', "
        		end
            end
        end
	end

	-- execute it if any updates
	if (fieldsSetString ~= "") then
        return true
	else
		return false
	end
end
