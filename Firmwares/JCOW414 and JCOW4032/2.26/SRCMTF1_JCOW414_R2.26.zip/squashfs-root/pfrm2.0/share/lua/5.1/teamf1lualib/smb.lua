--[[
#### Hussain Vali.
#### TeamF1
#### Copyright (c) 2008 - 2010 TeamF1, Inc.
#### Oct 22, 2008
#### File: smb.lua
#### Description: Samba Server Configurations
#### Revisions:
01a,07oct10,pnm  adding import/export/register
None.
]]--


--************* Requires *************

--************* Initial Code *************
--package
smb = {}
--************* Functions *************
local DBTable = ""

function smb.config (inputTable, rowid, operation)
    if (operation == "add") then
        return db.insert(DBTable,inputTable)
    elseif (operation == "edit") then
        return db.update(DBTable,inputTable,rowid)
    elseif (operation == "delete") then
        return db.delete(DBTable,inputTable)
    end
end

function smb.smbConfig (inputTable, rowid, operation,dbFlag)

    if (dbFlag == 1 ) then
	    db.beginTransaction() --begin transaction
    end
    local valid = false
	
    valid = smb.config (inputTable, rowid, operation)
	
	-- return
	if (valid) then
        if (dbFlag == 1 ) then
		    db.commitTransaction(true)
        end
        return "OK", "STATUS_OK"
	else
        if (dbFlag == 1 ) then
		    db.rollback()
        end
		return "ERROR", "NAS_SMB_CONFIG_FAILED"
	end
end

function smb.import (inputTable, defaultCfg, remCfg)

    if (inputTable == nil) then
        inputTable = defaultCfg
    end

    if (dbFlag == nil) then
        dbFlag = 1
    end

    -- initializing a temp table
    local configTable = inputTable

    -- configTable = config.update (inputTable, defaultCfg, remCfg)
   
    if (configTable ~= nil) then
        local configTable = util.addPrefix (configTable["global"], "smbGlobalConfig.");
        DBTable = "smbGlobalConfig"
        return smb.smbConfig (configTable, -1, "add",dbFlag)
    end
end

--[[
--*****************************************************************************
--smb.confGet - 
--
--
--RETURN: status - OK or ERROR and status str
]]--

function smb.confGet()
    local conf = {}
    local query = "_ROWID_=1"

    conf = db.getRowWhere("smbGlobalConfig", query, false)

    return "OK", "STATUS_OK", conf
end

--[[
--*****************************************************************************
--smb.confSet - 
--
--
--RETURN: status - OK or ERROR and status str
]]--

function smb.confSet(conf, dbFlag)
    local row = {}
    local query = "_ROWID_=1"

    row = db.getRowWhere("smbGlobalConfig", query, false)
    if (row == nil) then
        return "ERROR", "MEDIA_SERVER_ERR_DB_QUERY_FAILED"
    end    

    if (conf.LogicalIfName ~= nil) then
        row.LogicalIfName = conf.LogicalIfName
    end
            
    if (conf.serverEnable ~= nil) then
        row.serverEnable = conf.serverEnable
    end

    row = util.addPrefix(row, "smbGlobalConfig.")
    DBTable= "smbGlobalConfig"
    local status, errCode = smb.smbConfig(row, row["smbGlobalConfig._ROWID_"], "edit", dbFlag)

    return status, errCode
end

function smb.export ()
    local configTable = {}
    configTable["global"] = db.getTable ("smbGlobalConfig", false)[1]
    return configTable
end

if (config.register) then
    config.register("smbServer", smb.import, smb.export, "2")
end
