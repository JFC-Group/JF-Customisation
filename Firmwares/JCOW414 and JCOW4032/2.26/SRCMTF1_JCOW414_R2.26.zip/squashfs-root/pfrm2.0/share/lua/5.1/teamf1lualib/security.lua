-- security.lua - lua wrapper calls for APIs related to security feautres
--
--Copyright (c) 2017, TeamF1 Networks Pvt. Ltd.
--(Subsidiary of D-Link India)
--
-- modification history
-- --------------------
-- 01k,23Nov17,swr changes for spr 62635(XSS vulnerability) and 61441
-- 01j,21Apr17,MSV Made changes for seperate Enable/Disable options for DOS
--                 Attacks checks SPR#60505
-- 01i,31mar15,mmk Added one to one inbound firewall mapping support.
-- 01h,10dec14,mmk Added UNIT Checks for ICSA support. 
-- 01g,02dec14,mmk Added IPv6 Firewall support.
-- 01f,11oct14,mmk Added changes for icmp and l2tp ALG's support
-- 01e,24sep14,mmk Added fwRuleScript.lua to manage firewall rules
-- 01d,23dec13.ash changes for wan ping support
-- 01c,10sep13.drk changes for P2P session limit support
-- 01b,10aug13,ash changes for bandwidth monitoring.
-- 01a,01mar13,lnv written.
--

-- include
require "teamf1lualib/firewall"

-------------------------------------------------------------------------------
-- the routines in this lua layer are called from webpages(gui) to get/set
-- security related features on device
-------------------------------------------------------------------------------
gui.security = {}
gui.security.helpers = {}

-- Default policy configuration
gui.security.defaultPolicyConfig = {}
gui.security.defaultL2PolicyConfig = {}

-- Connection Entry Flush configuration
gui.security.connectionEntryFlushConfig = {}

-- Routing mode configuration
gui.security.routingMode = {}

-- SIP ALG
gui.security.sipConfig = {}

-- ALGs
gui.security.algConfig = {}

-- VPN Passthrough
gui.security.vpnpassthrough = {}

-- Attack Checks
gui.security.attChk = {}
gui.security.attChk.specific = {}
gui.security.attChk.dos = {}
gui.security.attChk.p2pSessionLimit = {}

-- Allot
gui.security.allot = {}

-- Drop Invalid connections
gui.security.dropInvalid = {}
gui.security.dropInvalid.connections = {}

-- Custom rules
gui.security.fwRules = {}
-- IPv4 firewall rules
gui.security.fwRules.ipv4 = {}
gui.security.fwRules.ipv4.add = {}
gui.security.fwRules.ipv4.edit = {}

-- IPv6 firewall rules
gui.security.fwRules.ipv6 = {}
gui.security.fwRules.ipv6.add = {}
gui.security.fwRules.ipv6.edit = {}

-- L2 firewall rules
gui.security.fwRules.l2 = {}
gui.security.fwRules.l2.add = {}
gui.security.fwRules.l2.edit = {}

-- Custom services
gui.security.customSvc = {}
gui.security.customSvc.add = {}
gui.security.customSvc.edit = {}

-- Port Forwarding
gui.security.portFwd = {}
gui.security.portFwd.add = {}
gui.security.portFwd.edit = {}

-- Device Access
gui.security.deviceAccess = {}
gui.security.deviceAccess.add = {}


-- MAC filtering
gui.security.macFilterConfig = {}
gui.security.macFilterRules = {}
gui.security.macFilterRules.add = {}
gui.security.macFilterRules.edit = {}

-- Client MAC Config
gui.security.clientMacConfig = {}

-- Content filtering
gui.security.contentFilteringConfig = {}
gui.security.trustedDomains = {}
gui.security.trustedDomains.add = {}
gui.security.trustedDomains.edit = {}
gui.security.blockSites = {}
gui.security.blockSites.add = {}
gui.security.blockSites.edit = {}

-- Bandwidth accounting configuration
gui.security.account = {}
gui.security.customAccount = {}
gui.security.customAccount.add = {}
gui.security.customAccount.edit = {}

-- unauthorized usage prevention configuration
gui.security.unauthorizedUsage = {}

gui.security.pktCount = {}
--
-- Default Policy
--
-- IPsecVpn
gui.security.ipsecVpn = {}
-- IPv4 IPsec policies
gui.security.ipsecVpn.ipv4 = {}
gui.security.ipsecVpn.ipv4.add = {}
gui.security.ipsecVpn.ipv4.edit = {}
gui.security.ipsecVpn.ipv4.delete = {}
local fwRulesScript = "/pfrm2.0/etc/fwRuleScript.lua"
local fwRulesCmd = "/pfrm2.0/bin/lua " .. fwRulesScript
-------------------------------------------------------------------------------
-- @name : gui.security.ipsecVpn.ipv4.delete
--
-- @description : This function will delete existing ipv4 ipsec policies rule(s) in
-- device.
--
-- @param : rowid(s) for which ipsec policy  deleted.
--
-- @return : status, errMsg
--
function gui.security.ipsecVpn.ipv4.delete (rowIds)
    --include
    require "teamf1lualib/firewall"

    -- Sanity for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg
    require "teamf1lualib/vpn"
    -- delete each rule
    for k,v in pairs(rowIds) do
        local inTable = {}
        inTable["IPSecPolicies._ROWID_"] = v;
        status, errMsg = vpn.vpnPoliciesDelete(inTable)
        if (not status) then
            break
        end
    end

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end
-------------------------------------------------------------------------------
-- @name : gui.security.ipsecVpn.ipv4.get
--
-- @description : This function gets the list of available ipv4 outbound rules
--
-- @return : LUA table containing ipv4 outbound rules
--
function gui.security.ipsecVpn.ipv4.get ()
    --locals
    local vpnIpv4PoliciesTbl = {}
    local page = {}
    page.IPSecPolicies = {}
    require "teamf1lualib/vpn"
    --getting policies from 'IPSecPolicies' table
    vpnIpv4PoliciesTbl = vpn.vpnPoliciesGet()
    if (vpnIpv4PoliciesTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    for i,v in ipairs (vpnIpv4PoliciesTbl) do
        page.IPSecPolicies[i] = {}
       
        page.IPSecPolicies[i].localSubnet = v["localSubnet"]
        page.IPSecPolicies[i].localEndpoint = v["localEndpoint"]
        page.IPSecPolicies[i].remoteSubnet = v["remoteSubnet"]
        page.IPSecPolicies[i].remoteEndpoint = v["remoteEndpoint"]
        page.IPSecPolicies[i].localStartIP = v["localStartIP"]
        page.IPSecPolicies[i].remoteStartIP = v["remoteStartIP"]

        page.IPSecPolicies[i]._ROWID_ = v["_ROWID_"]
    end

    --return
    return "OK", "STATUS_OK", page
end
-------------------------------------------------------------------------------
-- @name : gui.security.ipsecVpn.ipv4.add.set
--
-- @description : This function will add an ipv4 ipsec policy in device.
--
-- @param : lua table containing ipv4 ipsec config  details
--
-- @return : status, errorMsg
--
function gui.security.ipsecVpn.ipv4.add.set (ipv4ipsecVpnCfg)
    -- Sanity for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
    local status, errMsg 

    --[[for k,v in pairs(ipv4ipsecVpnCfg) do                                                                                                  
        os.execute("echo  "..k.. " == " ..v.. " > /dev/console ")                                                              
    end]]--
    if ( ipv4ipsecVpnCfg["ikeIdentifierType"] == "2" and ipv4ipsecVpnCfg["exchangeType"] == "1") then
        return "ERROR", "FQDN_ONLY_FOR_AGGRESSIVE"
    end


    require "teamf1lualib/vpn"
    --setting the new policies
    status, errMsg = vpn.ipsecVpnIPv4AddSet(ipv4ipsecVpnCfg)

    if (status == "OK") then
        db.save2()
    end
    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.ipsecVpn.ipv4.add.get
--
-- @description : This function gets defaults to add an ipv4 ipsec policy
--
-- @return : LUA table containing default values
--
function gui.security.ipsecVpn.ipv4.add.get ()
    --locals
    local vpnIpv4policyTbl = {}
    require "teamf1lualib/vpn"
    --fetching the table
    vpnIpv4PolicyTbl = vpn.ipsecVpnIPv4AddGet()
    if (vpnIpv4PolicyTbl == nil) then
        return "ERROR", "VPN_POLICIES_ADD_GET_FAILED"
    end
    --return
    return "OK", "STATUS_OK", vpnIPv4PolicyTbl
end
-------------------------------------------------------------------------------
-- @name : gui.security.ipsecVpn.ipv4.edit.get
--
-- @description : This function gets ipv4 firewall rule details available in
-- device.
--
-- @param : rowid for which firewall rule has to be queried.
--
-- @return : lua table containing current rule details
--
function gui.security.ipsecVpn.ipv4.edit.get (rowid)
    --locals
    local vpnIpv4PoliciesTbl = {}

   require "teamf1lualib/vpn"
    --getting the drop-downs
    vpnIpv4PoliciesTbl = vpn.vpnPoliciesEditGet(rowid)
    if (vpnIpv4PoliciesTbl == nil) then
        return "ERROR", "VPN_POLICIES_ADD_GET_FAILED"
    end

    --return
    --debug.Debugger(util.tableToString (vpnIpv4PoliciesTbl))
    return "OK", "STATUS_OK", vpnIpv4PoliciesTbl
end

-------------------------------------------------------------------------------
-- @name gui.security.fwRules.ipv4.edit.set
--
-- @description : This function will modify an ipv4 firewall rule in device.
--
-- @param : lua table containing ipv4 rule details
--
-- @return : status, errMsg
--
function gui.security.ipsecVpn.ipv4.edit.set (ipv4PolicyCfg)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end 
    if ( ipv4PolicyCfg["ikeIdentifierType"] == "2" and ipv4PolicyCfg["exchangeType"] == "1") then
        return "ERROR", "FQDN_ONLY_FOR_AGGRESSIVE"
    end
    require "teamf1lualib/vpn"
    --editing the selected row and updating it with new values
    status, errMsg = vpn.vpnPoliciesEditSet(ipv4PolicyCfg)

    if (status == "OK") then
        db.save2()
    end

    --returning
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.defaultPolicyConfig.get
--
-- @description : This function fetches default policy configuration
--
-- @return : status, errMsg, configTbl
--
function gui.security.defaultPolicyConfig.get ()
    --locals
    local configTbl = {}

	if (util.fileExists ("/pfrm2.0/DEVICE_REPEATER")) then
	-- no firewall policy  in  repeater devices like JMA24
	return "ERROR", "DB_ERROR_TRY_AGAIN"
	
	end

    --getting the values from 'defaultPolicy' table
    configTbl = firewall.defaultPolicyConfigGet()
    if(configTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    --return
    return "OK", "STATUS_OK", configTbl
end

-------------------------------------------------------------------------------
-- @name : gui.security.defaultPolicyConfig.set
--
-- @description : This function sets default policy configuration
--
-- @param : lua table containing default policy configuraion set in webpage
--
-- @return : status, errMsg
--
function gui.security.defaultPolicyConfig.set (InputTableCfg)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    --setting the new configuration in the table
    status, errMsg = firewall.defaultPolicyConfigSet(InputTableCfg)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.defaultL2PolicyConfig.get
--
-- @description : This function fetches L2 default policy configuration
--
-- @return : status, errMsg, configTbl
--
function gui.security.defaultL2PolicyConfig.get ()
    --locals
    local configTbl = {}

    --getting the values from 'L2FirewallDefaultPolicy' table
    configTbl = firewall.defaultL2PolicyConfigGet()
    if(configTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    --return
    return "OK", "STATUS_OK", configTbl
end

-------------------------------------------------------------------------------
-- @name : gui.security.defaultL2PolicyConfig.set
--
-- @description : This function sets L2 default policy configuration
--
-- @param : lua table containing L2 default policy configuraion set in webpage
--
-- @return : status, errMsg
--
function gui.security.defaultL2PolicyConfig.set (InputTableCfg)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    --setting the new configuration in the table
    status, errMsg = firewall.defaultL2PolicyConfigSet(InputTableCfg)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.connectionEntryFlushConfig.get
--
-- @description : This function fetches conntrack action configuration
--
-- @return : status, errMsg, configTbl
--
function gui.security.connectionEntryFlushConfig.get ()
    --locals
    local configTbl = {}

    --getting the values from 'conntrackAction' table
    configTbl = firewall.connectionEntryFlushConfigGet()
    if(configTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    --return
    return "OK", "STATUS_OK", configTbl
end

-------------------------------------------------------------------------------
-- @name : gui.security.connectionEntryFlushConfig.set
--
-- @description : This function sets conntrack action configuration
--
-- @param : lua table containing default policy configuraion set in webpage
--
-- @return : status, errMsg
--
function gui.security.connectionEntryFlushConfig.set (InputTableCfg)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    --setting the new configuration in the table
    status, errMsg = firewall.connectionEntryFlushConfigSet(InputTableCfg)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

--
-- Routing Mode
--

-------------------------------------------------------------------------------
-- @name : gui.security.routingMode.get
--
-- @description : This function fetches routing mode configuration
--
-- @return : status, errMsg, configTbl
--
function gui.security.routingMode.get ()
    --locals
    local configTbl = {}

	if (util.fileExists ("/pfrm2.0/DEVICE_REPEATER")) then
	-- no routing mode  in  repeater devices like JMA24
	return "ERROR", "DB_ERROR_TRY_AGAIN"
	
	end

    --getting the values from 'routingMode' table
    configTbl = firewall.routingModeConfigGet()
    if(configTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    --return
    return "OK", "STATUS_OK", configTbl
end

-------------------------------------------------------------------------------
-- @name : gui.security.routingMode.set
--
-- @description : This function sets routing mode configuration
--
-- @param : lua table containing routing mode configuraion set in webpage
--
-- @return : status, errMsg
--
function gui.security.routingMode.set (InputTableCfg)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    --setting the new configuration in the table
    status, errMsg = firewall.routingModeConfigSet(InputTableCfg)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

--
-- SIP ALG
--

----------------------------------------------------------------------------------
-- @name gui.security.sipConfig.get
--
-- @description This function gets the sip configuration
--
-- @return
--
function gui.security.sipConfig.get ()
    -- include
    require "teamf1lualib/sip"
    
    --locals 
    local configTbl = {}

    --getting the values from 'SipStatusCtrl' table
    configTbl = sip.configGet()
    if(configTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    -- return
    return "OK", "STATUS_OK", configTbl
end

----------------------------------------------------------------------------------
-- @name gui.security.sipConfig.set
--
-- @description This function sets the sip configuration
--
-- @return
--
function gui.security.sipConfig.set (sipCfg)
    -- require
    require "teamf1lualib/sip"

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    --setting the new configuration in the table
    status, errMsg = sip.configSet(sipCfg)

    if (status == "OK") then
        db.save2()
    end
    
    --return
    return status, errMsg
end

--
-- ALGs
--

--------------------------------------------------------------------------------
-- @name gui.security.algConfig.get
--
-- @description This function gets the alg configuration
--
-- @return status, errMsg, lua table containing alg configuration in the device
--
function gui.security.algConfig.get()
    --include
    require "teamf1lualib/firewall"
    require "teamf1lualib/sip"

   --locals
    local sipConfigRow = {}
    local algConfigROw = {}
    local configTbl = {}

    --get values from 'AlgConf' table
    algConfigRow = firewall.algConfigGet()
    if(algConfigRow == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    configTbl["FtpStatus"]  = algConfigRow["FtpStatus"]
    configTbl["H323Status"] = algConfigRow["H323Status"]
    configTbl["RtspStatus"] = algConfigRow["RtspStatus"]
    configTbl["TftpStatus"] = algConfigRow["TftpStatus"]
    configTbl["L2tpStatus"] = algConfigRow["L2tpStatus"]
    configTbl["IcmpStatus"] = algConfigRow["IcmpStatus"]

    --get values from 'SipStatusCtrl' table
    sipConfigRow = sip.configGet()
    if(sipConfigRow == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end
    configTbl["SipStatus"] = sipConfigRow["SipStatus"]

    --return
    return "OK", "STATUS_OK", configTbl
end

--------------------------------------------------------------------------------
-- @name gui.security.algConfig.set()
--
-- @description This function sets the alg configuration
--
-- @return status, errMsg
--
function gui.security.algConfig.set(inCfg)
    -- require
    require "teamf1lualib/firewall"
    require "teamf1lualib/sip"

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg
    local algConfigRow = {}
    local sipConfigRow = {}

    --setting the values in 'AlgConf' table
    algConfigRow["FtpStatus"]  = inCfg["FtpStatus"]
    algConfigRow["H323Status"] = inCfg["H323Status"]
    algConfigRow["RtspStatus"] = inCfg["RtspStatus"]
    algConfigRow["TftpStatus"] = inCfg["TftpStatus"]
    algConfigRow["L2tpStatus"] = inCfg["L2tpStatus"]
    algConfigRow["IcmpStatus"] = inCfg["IcmpStatus"]
    status, errMsg = firewall.algConfigSet(algConfigRow)

    --setting the values in 'SipStatusCtrl' table
    sipConfigRow["SipStatus"] = inCfg["SipStatus"]
    if(status == "OK") then
        status, errMsg = sip.configSet(sipConfigRow)
    end

    if (status == "OK") then
        db.save2()
    end
    
    --return
    return status, errMsg
end

--
-- VPN Passthrough
--

--------------------------------------------------------------------------------
-- @name gui.security.vpnpassthrough.get
--
-- @description This function gets the vpn passthrough configuration
--
-- @return status, errMsg, lua table containing vpn passthrough configuration
--
function gui.security.vpnpassthrough.get()
    --include
    require "teamf1lualib/firewall"

   --locals
    local passthroughConfigRow = {}
    local configTbl = {}

    --get values from 'AlgConf' table
    passthroughConfigRow = firewall.algConfigGet()
    if(passthroughConfigRow == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end
    configTbl["IpsecPtStatus"] = passthroughConfigRow["IpsecPtStatus"]

    --return
    return "OK", "STATUS_OK", configTbl
end

--------------------------------------------------------------------------------
-- @name gui.security.vpnpassthrough.set()
--
-- @description This function sets the vpn passthrough configuration
--
-- @return status, errMsg
--
function gui.security.vpnpassthrough.set(inCfg)
    -- require
    require "teamf1lualib/firewall"

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg
    local passthroughConfigRow = {}

    --setting the values in 'AlgConf' table
    passthroughConfigRow["IpsecPtStatus"] = inCfg["IpsecPtStatus"]
    status, errMsg = firewall.algConfigSet(passthroughConfigRow)

    if (status == "OK") then
        db.save2()
    end
    
    --return
    return status, errMsg
end

--
-- Attack Checks
--

--------------------------------------------------------------------------------
-- @name gui.security.attChk.specific.get()
--
-- @description This function gets the specific attack checks configuration
--
-- @return status, errMsg, lua table containing specific checks configuration
--
function gui.security.attChk.specific.get()
    --include
    require "teamf1lualib/firewall"

    --locals
    local specAttChkRow = {}
    local configTbl = {}

    --get values from 'AlgConf' table
    specAttChkRow = firewall.specAttChkConfigGet()
    if(specAttChkRow == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end
    configTbl["SmurfAttack"] = specAttChkRow["SmurfAttack"]
    configTbl["PodAttack"] = specAttChkRow["PodAttack"]
    configTbl["FraggleAttack"] = specAttChkRow["FraggleAttack"]
    configTbl["DnsAmpAttack"] = specAttChkRow["DnsAmpAttack"]
    configTbl["ExternalPing"] = specAttChkRow["ExternalPing"]

    --return
    return "OK", "STATUS_OK", configTbl
end

--------------------------------------------------------------------------------
-- @name gui.security.attChk.specific.set()
--
-- @description This function sets the specific attack check configuration
--
-- @return status, errMsg
--
function gui.security.attChk.specific.set(inCfg)
    -- require
    require "teamf1lualib/firewall"

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg
    local specAttChkRow = {}

    --setting the values in 'SpecificAttackChecks' table
    specAttChkRow["SmurfAttack"] = inCfg["SmurfAttack"]
    specAttChkRow["PodAttack"] = inCfg["PodAttack"]
    specAttChkRow["FraggleAttack"] = inCfg["FraggleAttack"]
    specAttChkRow["DnsAmpAttack"] = inCfg["DnsAmpAttack"]
    specAttChkRow["ExternalPing"] = inCfg["ExternalPing"]
    status, errMsg = firewall.specAttChkConfigSet(specAttChkRow)

    if (status == "OK") then
        db.save2()
    end
    
    --return
    return status, errMsg
end


--------------------------------------------------------------------------------
-- @name gui.security.dropInvalid.connections.set()
--
-- @description This function sets the Drop invalid connections configuration
--
-- @return status, errMsg
--
function gui.security.dropInvalid.connections.set(inCfg)
    -- require
    require "teamf1lualib/firewall"

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg
    local specAttChkRow = {}

    --setting the values in 'SpecificAttackChecks' table
    specAttChkRow["DropConnections"] = inCfg["DropConnections"]
    status, errMsg = firewall.specAttChkConfigSet(specAttChkRow)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end


--------------------------------------------------------------------------------
-- @name  gui.security.dropInvalid.connections.get()
--
-- @description This function gets Drop invalid connections configuration
--
-- @return status, errMsg, lua table containing specific checks configuration
--
function gui.security.dropInvalid.connections.get()
    --include
    require "teamf1lualib/firewall"

    --locals
    local specAttChkRow = {}
    local configTbl = {}

    --get values from 'AlgConf' table
    specAttChkRow = firewall.specAttChkConfigGet()
    if(specAttChkRow == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end
    configTbl["DropConnections"] = specAttChkRow["DropConnections"]

    --return
    return "OK", "STATUS_OK", configTbl
end


--------------------------------------------------------------------------------
-- @name gui.security.attChk.dos.get()
--
-- @description This function gets the dos/ddos attack checks configuration
--
-- @return status, errMsg, lua table containing dos/ddos checks configuration
--
function gui.security.attChk.dos.get()
    --include
    require "teamf1lualib/firewall"

    --locals
    local dosAttChkRow = {}
	local iscaSettingRow = {}
    local configTbl = {}

    --get values from 'DosAttackChecks' table
    dosAttChkRow = firewall.dosAttChkConfigGet()
    
    if (UNIT_INFO ~= "ODU") then
	iscaSettingRow = firewall.iscaSettingConfigGet()
    end

    if(dosAttChkRow == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end
    configTbl["DosCheckStatus"] = dosAttChkRow["DosCheckStatus"]
    configTbl["UseDefSettings"] = dosAttChkRow["UseDefSettings"]
    configTbl["TcpSynFlood"] = util.filterXSSChars (dosAttChkRow["TcpSynFlood"])
    configTbl["TcpSynFloodEnable"] = dosAttChkRow["TcpSynFloodEnable"]
    configTbl["UdpFlood"] = util.filterXSSChars (dosAttChkRow["UdpFlood"])
    configTbl["UdpFloodEnable"] = dosAttChkRow["UdpFloodEnable"]
    configTbl["IcmpEchoFlood"] = util.filterXSSChars (dosAttChkRow["IcmpEchoFlood"])
    configTbl["IcmpEchoFloodEnable"] = dosAttChkRow["IcmpEchoFloodEnable"]
    configTbl["IcmpNotificationFlood"] = util.filterXSSChars (dosAttChkRow["IcmpNotificationFlood"])
    configTbl["IcmpNotificationFloodEnable"] = dosAttChkRow["IcmpNotificationFloodEnable"]
	configTbl["StealthMode"] = dosAttChkRow["StealthMode"]
	configTbl["PingReplyOnLan"] = dosAttChkRow["PingReplyOnLan"]
    configTbl["BlockSpoof"] = dosAttChkRow["BlockSpoof"]
	configTbl["TcpFilterCheck"] = dosAttChkRow["TcpFilterCheck"]
    
    if (UNIT_INFO ~= "ODU") then
    configTbl["BlockFragPkts"] = iscaSettingRow["BlockFragPkts"]
    configTbl["BlockMulticastPkts"] = iscaSettingRow["BlockMulticastPkts"]
	configTbl["BlockTcpRST"] = iscaSettingRow["BlockTcpRST"]
	configTbl["BlockFtpBounceAttack"] = iscaSettingRow["BlockFtpBounceAttack"]
    end
    --return
    return "OK", "STATUS_OK", configTbl
end

--------------------------------------------------------------------------------
-- @name gui.security.attChk.dos.set()
--
-- @description This function sets the dos/ddos attack check configuration
--
-- @return status, errMsg
--
function gui.security.attChk.dos.set(inCfg)
    -- require
    require "teamf1lualib/firewall"

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg
    local dosAttChkRow = {}
	local iscaSettingRow = {}

    --setting the values in 'DosAttackChecks' table
    dosAttChkRow = db.getRowWhere ("DosAttackChecks", "_ROWID_=1", false)
    dosAttChkRow["UseDefSettings"] = inCfg["UseDefSettings"]

    if((tonumber(inCfg["TcpSynFloodEnable"]) == 1) or (tonumber(inCfg["UdpFloodEnable"]) == 1) or
        (tonumber(inCfg["IcmpEchoFloodEnable"]) == 1) or (tonumber(inCfg["IcmpNotificationFloodEnable"]) == 1)) then
        dosAttChkRow["DosCheckStatus"] = "1"
    else
        dosAttChkRow["DosCheckStatus"] = "0"
    end

    if(inCfg["TcpSynFlood"] ~= nil) then
        dosAttChkRow["TcpSynFlood"] = inCfg["TcpSynFlood"]
    end
    if(inCfg["UdpFlood"] ~= nil) then
        dosAttChkRow["UdpFlood"] = inCfg["UdpFlood"]
    end
    if(inCfg["IcmpEchoFlood"] ~= nil) then
        dosAttChkRow["IcmpEchoFlood"] = inCfg["IcmpEchoFlood"]
    end
    if(inCfg["IcmpEchoFloodEnable"] ~= nil) then
        dosAttChkRow["IcmpNotificationFlood"] = inCfg["IcmpNotificationFlood"]
    end
    dosAttChkRow["TcpSynFloodEnable"] = inCfg["TcpSynFloodEnable"]
    dosAttChkRow["UdpFloodEnable"] = inCfg["UdpFloodEnable"]
    dosAttChkRow["IcmpEchoFloodEnable"] = inCfg["IcmpEchoFloodEnable"]
    dosAttChkRow["IcmpNotificationFloodEnable"] = inCfg["IcmpNotificationFloodEnable"]
    dosAttChkRow["StealthMode"] = inCfg["StealthMode"]
    dosAttChkRow["PingReplyOnLan"] = inCfg["PingReplyOnLan"]
    dosAttChkRow["BlockSpoof"] = inCfg["BlockSpoof"]
    dosAttChkRow["TcpFilterCheck"] = inCfg["TcpFilterCheck"]
    
        if (UNIT_INFO ~= "ODU") then
        iscaSettingRow["BlockFragPkts"] = inCfg["BlockFragPkts"]
        iscaSettingRow["BlockMulticastPkts"] = inCfg["BlockMulticastPkts"]
		iscaSettingRow["BlockTcpRST"] = inCfg["BlockTcpRST"]
		iscaSettingRow["BlockFtpBounceAttack"] = inCfg["BlockFtpBounceAttack"]
        end

    status, errMsg = firewall.dosAttChkConfigSet(dosAttChkRow)
	
	if ((status == "OK") and (UNIT_INFO ~= "ODU")) then
    status, errMsg = firewall.iscaSettingConfigSet(iscaSettingRow)
    end

    if (status == "OK") then
        db.save2()
    end
    
    --return
    return status, errMsg
end

--------------------------------------------------------------------------------
-- @name gui.security.attChk.p2pSessionLimit.get()
--
-- @description This function gets the P2P session limit configuration
--
-- @return status, errMsg, lua table containing P2P session limit configuration
--
function gui.security.attChk.p2pSessionLimit.get()
    --include
    require "teamf1lualib/firewall"

    --locals
    local p2pSessionLimitRow = {}
    local configTbl = {}

    util.appendDebugOut ("\n\nIn Security.lua \n\n")
    --get values from 'p2pSessionLimit' table
    p2pSessionLimitRow = firewall.p2pSessionLimitConfigGet()
    if(p2pSessionLimitRow == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end
    util.appendDebugOut ("Table GET: " .. util.tableToStringRec (p2pSessionLimitRow))
    configTbl["enable"] = p2pSessionLimitRow["p2pSessionLimit.p2pSessionLimitStatus"]
    configTbl["p2pSessionLimit"] = util.filterXSSChars(p2pSessionLimitRow["p2pSessionLimit.p2pSessionLimit"])

    --return
    return "OK", "STATUS_OK", configTbl
end

--------------------------------------------------------------------------------
-- @name gui.security.attChk.p2pSessionLimit.set()
--
-- @description This function sets the P2P Session Limit configuration
--
-- @return status, errMsg
--
function gui.security.attChk.p2pSessionLimit.set(inCfg)
    -- require
    require "teamf1lualib/firewall"

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg
    local p2pSessionLimitRow = {}

    --setting the values in 'p2pSessionLimit' table
    p2pSessionLimitRow["p2pSessionLimitStatus"] = inCfg["enable"]
    p2pSessionLimitRow["p2pSessionLimit"] = inCfg["p2pSessionLimit"]

    status, errMsg = firewall.p2pSessionLimitConfigSet(p2pSessionLimitRow)

    if (status == "OK") then
        util.appendDebugOut ("STATUS OK.......SAVING TO DB\n")
        db.save2()
        os.execute(fwRulesCmd)
    end
    
    --return
    return status, errMsg
end

--
-- IPv4 firewall rules
--

-------------------------------------------------------------------------------
-- @name : gui.security.fwRules.ipv4.get
--
-- @description : This function gets the list of available ipv4 outbound rules
--
-- @return : LUA table containing ipv4 outbound rules
--
function gui.security.fwRules.ipv4.get ()
    --locals
    local fwIpv4RulesTbl = {}
    local page = {}
    page.FirewallRules = {}

    --getting outbound rules from 'FirewallRules' table
    fwIpv4RulesTbl = firewall.fwRulesGet()
    if (fwIpv4RulesTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    for i,v in ipairs (fwIpv4RulesTbl) do
        page.FirewallRules[i] = {}
        --[[
        if (v["Status"] == "1") then
            page.FirewallRules[i].Status = "Enabled"
        else
            page.FirewallRules[i].Status = "Disabled"
        end
        ]]--
        page.FirewallRules[i].Status = v["Status"]

        page.FirewallRules[i].ServiceName = util.filterXSSChars(v["ServiceName"])
        if (v["ScheduleName"] == "-") then
            page.FirewallRules[i].ScheduleName = "No Schedule"
        else
            page.FirewallRules[i].ScheduleName = util.filterXSSChars(v["ScheduleName"])
        end

        if (v["Action"] == "ACCEPT") then
            page.FirewallRules[i].Action = "Allow Always"
        elseif (v["Action"] == "DROP") then
            page.FirewallRules[i].Action = "Block Always"
        elseif (v["Action"] == "ACCEPT_BY_SCH") then
            page.FirewallRules[i].Action = "Allow by Schedule"
        elseif (v["Action"] == "DROP_BY_SCH") then
            page.FirewallRules[i].Action = "Block by Schedule"
        end

        if (v["SourceAddressType"] == "0") then
            page.FirewallRules[i].SourceAddressType = "ANY"
        elseif (v["SourceAddressType"] == "1") then
            page.FirewallRules[i].SourceAddressType = util.filterXSSChars(v["SourceAddressStart"])
        elseif (v["SourceAddressType"] == "2") then
            page.FirewallRules[i].SourceAddressType = util.filterXSSChars(v["SourceAddressStart"]) .. "-" .. util.filterXSSChars(v["SourceAddressEnd"])
        end

        if (v["DestinationAddressType"] == "0") then
            page.FirewallRules[i].DestinationAddressType = "ANY"
        elseif (v["DestinationAddressType"] == "1") then
            page.FirewallRules[i].DestinationAddressType = util.filterXSSChars(v["DestinationAddressStart"])
        elseif (v["DestinationAddressType"] == "2") then
            page.FirewallRules[i].DestinationAddressType = util.filterXSSChars(v["DestinationAddressStart"]) .. "-" .. util.filterXSSChars(v["DestinationAddressEnd"])
        end

        page.FirewallRules[i]._ROWID_ = v["_ROWID_"]
    end

    --return
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name : gui.security.fwRules.ipv4.add.get
--
-- @description : This function gets defaults to add an ipv4 firewall rule
--
-- @return : LUA table containing default values
--
function gui.security.fwRules.ipv4.add.get ()
    --locals
    local fwIpv4RulesTbl = {}
    local schTbl = {}
    local page = {}
    local i
    page.Services = {}
    page.Schedules = {}

    --fetching the table
    fwIpv4RulesTbl = firewall.fwRulesAddGet()
    if (fwIpv4RulesTbl == nil) then
        return "ERROR", "FIREWALL_RULES_ADD_GET_FAILED"
    end

    for k,v in pairs (fwIpv4RulesTbl.Services) do
        page.Services[k] = {}
        page.Services[k].ServiceName = util.filterXSSChars(v["Services.ServiceName"])
    end

    schTbl = firewall.fwSchedGet()
    for k,v in pairs(schTbl) do
        page.Schedules[k] = {}
        page.Schedules[k].ScheduleName = util.filterXSSChars(v["ScheduleName"])
    end
    page.Schedules["None"] = {}
    page.Schedules["None"].ScheduleName = "No Schedule"

    --return
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name : gui.security.fwRules.ipv4.add.set
--
-- @description : This function will add an ipv4 firewall rule in device.
--
-- @param : lua table containing ipv4 rule details
--
-- @return : status, errorMsg
--
function gui.security.fwRules.ipv4.add.set (ipv4RuleCfg)
    -- Sanity for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    if(db.getAttribute ("dmz", "LogicalIfName", "IF1", "enableDmz") == "1") then
       local dmz_ipaddress = db.getAttribute ("dmz", "LogicalIfName", "IF1", "ipAddr")
       if(ipv4RuleCfg["SourceAddressType"] == "1" and 
         ipv4RuleCfg["SourceAddressStart"] == dmz_ipaddress) then
         return "ERROR","NO_DMZ_HOST_IP_FOR_FIREWALL_OUTBOUND_RULE"
       end
    end
   
    if (ipv4RuleCfg["ScheduleName"] == "No Schedule" or
        ipv4RuleCfg["ScheduleName"] == "" or
        ipv4RuleCfg["ScheduleName"] == nil) then
        ipv4RuleCfg["ScheduleName"] = "-"
    end

    --setting the new rules
    status, errMsg = firewall.fwRulesAddSet(ipv4RuleCfg)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.fwRules.ipv4.edit.get
--
-- @description : This function gets ipv4 firewall rule details available in
-- device.
--
-- @param : rowid for which firewall rule has to be queried.
--
-- @return : lua table containing current rule details
--
function gui.security.fwRules.ipv4.edit.get (rowid)
    --locals
    local fwIpv4RulesTbl = {}
    local schTbl = {}
    local page = {}
    local DBrow

    page.Services = {}
    page.Schedules= {}

    --getting the drop-downs
    fwIpv4RulesTbl = firewall.fwRulesEditGet()
    if (fwIpv4RulesTbl == nil) then
        return "ERROR", "FIREWALL_RULES_ADD_GET_FAILED"
    end

    for k,v in pairs (fwIpv4RulesTbl.Services) do
        page.Services[k] = {}
        page.Services[k].ServiceName = util.filterXSSChars(v["Services.ServiceName"])
    end

    schTbl = firewall.fwSchedGet()
    for k,v in pairs(schTbl) do
        page.Schedules[k] = {}
        page.Schedules[k].ScheduleName = util.filterXSSChars(v["ScheduleName"])
    end
    page.Schedules["None"] = {}
    page.Schedules["None"].ScheduleName = "No Schedule"

    DBrow = db.getRow ("FirewallRules", "_ROWID_", rowid)

    --debug.Debugger(util.tableToString (DBrow))
    page.ServiceName = util.filterXSSChars(DBrow["FirewallRules.ServiceName"])
    if (DBrow["FirewallRules.ScheduleName"] == "-") then
        page.ScheduleName = "No Schedule"
    else
        page.ScheduleName = util.filterXSSChars(DBrow["FirewallRules.ScheduleName"])
    end
    page.Action = util.filterXSSChars(DBrow["FirewallRules.Action"])
    
    page.SourceAddressType = DBrow["FirewallRules.SourceAddressType"]
    page.SourceAddressStart = util.filterXSSChars(DBrow["FirewallRules.SourceAddressStart"]) or ''
    page.SourceAddressEnd = util.filterXSSChars(DBrow["FirewallRules.SourceAddressEnd"]) or ''

    page.DestinationAddressType = DBrow["FirewallRules.DestinationAddressType"]
    page.DestinationAddressStart = util.filterXSSChars(DBrow["FirewallRules.DestinationAddressStart"]) or ''
    page.DestinationAddressEnd = util.filterXSSChars(DBrow["FirewallRules.DestinationAddressEnd"]) or ''
    page.LogLevel = DBrow["FirewallRules.LogLevel"] or ''

    --return
    --debug.Debugger(util.tableToString (page))
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name gui.security.fwRules.ipv4.edit.set
--
-- @description : This function will modify an ipv4 firewall rule in device.
--
-- @param : lua table containing ipv4 rule details
--
-- @return : status, errMsg
--
function gui.security.fwRules.ipv4.edit.set (ipv4RuleCfg)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if(db.getAttribute ("dmz", "LogicalIfName", "IF1", "enableDmz") == "1") then
       local dmz_ipaddress = db.getAttribute ("dmz", "LogicalIfName", "IF1", "ipAddr")
       if(ipv4RuleCfg["SourceAddressType"] == "1" and 
         ipv4RuleCfg["SourceAddressStart"] == dmz_ipaddress) then
         return "ERROR","NO_DMZ_HOST_IP_FOR_FIREWALL_OUTBOUND_RULE"
       end
    end

    --locals
    local status, errMsg

    if (ipv4RuleCfg["ScheduleName"] == "No Schedule" or
        ipv4RuleCfg["ScheduleName"] == "" or
        ipv4RuleCfg["ScheduleName"] == nil) then
        ipv4RuleCfg["ScheduleName"] = "-"
    end
    
    --editing the selected row and updating it with new values
    status, errMsg = firewall.fwRulesEditSet(ipv4RuleCfg)

    if (status == "OK") then
        db.save2()
    end

    --returning
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.fwRules.ipv4.enable
--
-- @description : This function will enable an existing ipv4 firewall rule in
-- device.
--
-- @param : rowid(s) for which firewall rule has to be queried and enabled.
--
-- @return : status, errMsg
--
function gui.security.fwRules.ipv4.enable (rowids)
    --include
    require "teamf1lualib/firewall"

    -- Sanity for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    for k,v in pairs (rowids) do
        --enabling the selected rule
        status, errMsg = firewall.fwRulesEnable(v)
    end

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.fwRules.ipv4.disable
--
-- @description : This function will disable an existing ipv4 firewall rule in
-- device.
--
-- @param : rowid(s) for which firewall rule has to be queried and disabled.
--
-- @return : status, errMsg
--
function gui.security.fwRules.ipv4.disable (rowids)
    --include
    require "teamf1lualib/firewall"

    -- Sanity for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    for k,v in pairs (rowids) do
        --disabling the selected rule
        status, errMsg = firewall.fwRulesDisable(v)
    end

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.fwRules.ipv4.delete
--
-- @description : This function will delete existing ipv4 firewall rule(s) in
-- device.
--
-- @param : rowid(s) for which firewall rule deleted.
--
-- @return : status, errMsg
--
function gui.security.fwRules.ipv4.delete (rowIds)
    --include
    require "teamf1lualib/firewall"

    -- Sanity for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    -- delete each rule
    for k,v in pairs(rowIds) do
        local inTable = {}
        inTable["FirewallRules._ROWID_"] = v;
        status, errMsg = firewall.fwRulesDelete (inTable)
        if (not status) then
            break
        end
    end

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.fwRules.ipv6.get
--
-- @description : This function gets the list of available ipv6 outbound rules
--
-- @return : LUA table containing ipv6 outbound rules
--
function gui.security.fwRules.ipv6.get ()
    --locals
    local fwIpv6RulesTbl = {}
    local page = {}
    page.FirewallRules6 = {}

    --getting outbound rules from 'FirewallRules' table
    fwIpv6RulesTbl = firewall.fwRules6Get()
    if (fwIpv6RulesTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    for i,v in ipairs (fwIpv6RulesTbl) do
        page.FirewallRules6[i] = {}
        --[[
        if (v["Status"] == "1") then
            page.FirewallRules[i].Status = "Enabled"
        else
            page.FirewallRules[i].Status = "Disabled"
        end
        ]]--
        page.FirewallRules6[i].Status = v["Status"]
       
        if (v["FromZoneType"] == "SECURE") then
            page.FirewallRules6[i].Direction = "Outbound"
        else
            page.FirewallRules6[i].Direction = "Inbound"
        end
        page.FirewallRules6[i].Status = v["Status"]

        page.FirewallRules6[i].ServiceName = util.filterXSSChars(v["ServiceName"])
        if (v["ScheduleName"] == "-") then
            page.FirewallRules6[i].ScheduleName = "No Schedule"
        else
            page.FirewallRules6[i].ScheduleName = util.filterXSSChars(v["ScheduleName"])
        end

        if (v["Action"] == "ACCEPT") then
            page.FirewallRules6[i].Action = "Allow Always"
        elseif (v["Action"] == "DROP") then
            page.FirewallRules6[i].Action = "Block Always"
        elseif (v["Action"] == "ACCEPT_BY_SCH") then
            page.FirewallRules6[i].Action = "Allow by Schedule"
        elseif (v["Action"] == "DROP_BY_SCH") then
            page.FirewallRules6[i].Action = "Block by Schedule"
        end

        if (v["SourceAddressType"] == "0") then
            page.FirewallRules6[i].SourceAddressType = "ANY"
        elseif (v["SourceAddressType"] == "1") then
            page.FirewallRules6[i].SourceAddressType = util.filterXSSChars(v["SourceAddressStart"])
        elseif (v["SourceAddressType"] == "2") then
            page.FirewallRules6[i].SourceAddressType = util.filterXSSChars(v["SourceAddressStart"]) .. "-" .. util.filterXSSChars(v["SourceAddressEnd"])
        end

        if (v["DestinationAddressType"] == "0") then
            page.FirewallRules6[i].DestinationAddressType = "ANY"
        elseif (v["DestinationAddressType"] == "1") then
            page.FirewallRules6[i].DestinationAddressType = util.filterXSSChars(v["DestinationAddressStart"])
        elseif (v["DestinationAddressType"] == "2") then
            page.FirewallRules6[i].DestinationAddressType = util.filterXSSChars(v["DestinationAddressStart"]) .. "-" .. util.filterXSSChars(v["DestinationAddressEnd"])
        end

        page.FirewallRules6[i]._ROWID_ = v["_ROWID_"]
    end

    --return
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name : gui.security.fwRules.ipv6.add.get
--
-- @description : This function gets defaults to add an ipv6 firewall rule
--
-- @return : LUA table containing default values
--
function gui.security.fwRules.ipv6.add.get ()
    --locals
    local fwIpv6RulesTbl = {}
    local schTbl = {}
    local page = {}
    local i
    page.Services = {}
    page.Schedules = {}

    --fetching the table
    fwIpv6RulesTbl = firewall.fwRules6AddGet()
    if (fwIpv6RulesTbl == nil) then
        return "ERROR", "FIREWALL_RULES_ADD_GET_FAILED"
    end

    for k,v in pairs (fwIpv6RulesTbl.Services) do
        page.Services[k] = {}
        page.Services[k].ServiceName = util.filterXSSChars(v["Services.ServiceName"])
    end

    schTbl = firewall.fwSchedGet()
    for k,v in pairs(schTbl) do
        page.Schedules[k] = {}
        page.Schedules[k].ScheduleName = util.filterXSSChars(v["ScheduleName"])
    end
    page.Schedules["None"] = {}
    page.Schedules["None"].ScheduleName = "No Schedule"

    --return
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name : gui.security.fwRules.ipv6.add.set
--
-- @description : This function will add an ipv6 firewall rule in device.
--
-- @param : lua table containing ipv6 rule details
--
-- @return : status, errorMsg
--
function gui.security.fwRules.ipv6.add.set (ipv6RuleCfg)
    -- Sanity for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

	if(db.getAttribute ("dmz6", "LogicalIfName", "IF1", "enableDmz") == "1" and ipv6RuleCfg["SourceAddressType"] == "1") then
        local dmz_ipaddress = db.getAttribute ("dmz6", "LogicalIfName", "IF1", "ipAddr")
        dmz_ipaddress = validations.ipv6Convert(dmz_ipaddress)
        dmz_ipaddress = string.gsub (dmz_ipaddress,"0000","0")
        dmz_ipaddress = string.gsub (dmz_ipaddress,"000","0")
        dmz_ipaddress = string.gsub (dmz_ipaddress,"00","0")
        local source_address = validations.ipv6Convert ( ipv6RuleCfg["SourceAddressStart"] )
        source_address = string.gsub (source_address ,"0000","0")
        source_address = string.gsub (source_address ,"000","0")
        source_address = string.gsub (source_address ,"00","0")
        if( source_address == dmz_ipaddress) then
            return "ERROR","NO_DMZ_HOST_IP_FOR_FIREWALL_OUTBOUND_RULE"
        end
    end

    if (ipv6RuleCfg["ScheduleName"] == "No Schedule" or
        ipv6RuleCfg["ScheduleName"] == "" or
        ipv6RuleCfg["ScheduleName"] == nil) then
        ipv6RuleCfg["ScheduleName"] = "-"
    end

    --setting the new rules
    status, errMsg = firewall.fwRules6AddSet(ipv6RuleCfg)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.fwRules.ipv6.edit.get
--
-- @description : This function gets ipv6 firewall rule details available in
-- device.
--
-- @param : rowid for which firewall rule has to be queried.
--
-- @return : lua table containing current rule details
--
function gui.security.fwRules.ipv6.edit.get (rowid)
    --locals
    local fwIpv6RulesTbl = {}
    local schTbl = {}
    local page = {}
    local DBrow

    page.Services = {}
    page.Schedules= {}

    --getting the drop-downs
    fwIpv6RulesTbl = firewall.fwRules6EditGet()
    if (fwIpv6RulesTbl == nil) then
        return "ERROR", "FIREWALL_RULES_ADD_GET_FAILED"
    end

    for k,v in pairs (fwIpv6RulesTbl.Services) do
        page.Services[k] = {}
        page.Services[k].ServiceName = util.filterXSSChars(v["Services.ServiceName"])
    end

    schTbl = firewall.fwSchedGet()
    for k,v in pairs(schTbl) do
        page.Schedules[k] = {}
        page.Schedules[k].ScheduleName = util.filterXSSChars(v["ScheduleName"])
    end
    page.Schedules["None"] = {}
    page.Schedules["None"].ScheduleName = "No Schedule"

    DBrow = db.getRow ("FirewallRules6", "_ROWID_", rowid)

    if (DBrow["FirewallRules6.FromZoneType"] == "SECURE") then
        page.Direction = "Outbound"
    else
        page.Direction = "Inbound"
    end

    --debug.Debugger(util.tableToString (DBrow))
    page.ServiceName = util.filterXSSChars(DBrow["FirewallRules6.ServiceName"])
    if (DBrow["FirewallRules6.ScheduleName"] == "-") then
        page.ScheduleName = "No Schedule"
    else
        page.ScheduleName = util.filterXSSChars(DBrow["FirewallRules6.ScheduleName"])
    end
    page.Action = util.filterXSSChars(DBrow["FirewallRules6.Action"])
    
    page.SourceAddressType = DBrow["FirewallRules6.SourceAddressType"]
    page.SourceAddressStart = util.filterXSSChars(DBrow["FirewallRules6.SourceAddressStart"]) or ''
    page.SourceAddressEnd = util.filterXSSChars(DBrow["FirewallRules6.SourceAddressEnd"]) or ''

    page.DestinationAddressType = DBrow["FirewallRules6.DestinationAddressType"]
    page.DestinationAddressStart = util.filterXSSChars(DBrow["FirewallRules6.DestinationAddressStart"]) or ''
    page.DestinationAddressEnd = util.filterXSSChars(DBrow["FirewallRules6.DestinationAddressEnd"]) or ''
    page.LogLevel = DBrow["FirewallRules6.LogLevel"] or ''

    --return
    --debug.Debugger(util.tableToString (page))
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name gui.security.fwRules.ipv6.edit.set
--
-- @description : This function will modify an ipv6 firewall rule in device.
--
-- @param : lua table containing ipv6 rule details
--
-- @return : status, errMsg
--
function gui.security.fwRules.ipv6.edit.set (ipv6RuleCfg)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

     if(db.getAttribute ("dmz6", "LogicalIfName", "IF1", "enableDmz") == "1" and ipv6RuleCfg["SourceAddressType"] == "1") then
        local dmz_ipaddress = db.getAttribute ("dmz6", "LogicalIfName", "IF1", "ipAddr")
        dmz_ipaddress = validations.ipv6Convert(dmz_ipaddress)
        dmz_ipaddress = string.gsub (dmz_ipaddress,"0000","0")
        dmz_ipaddress = string.gsub (dmz_ipaddress,"000","0")
        dmz_ipaddress = string.gsub (dmz_ipaddress,"00","0")
        local source_address = validations.ipv6Convert ( ipv6RuleCfg["SourceAddressStart"] )
        source_address = string.gsub (source_address ,"0000","0")
        source_address = string.gsub (source_address ,"000","0")
        source_address = string.gsub (source_address ,"00","0")
        if( source_address == dmz_ipaddress ) then
           return "ERROR","NO_DMZ_HOST_IP_FOR_FIREWALL_OUTBOUND_RULE"
        end
     end

    if (ipv6RuleCfg["ScheduleName"] == "No Schedule" or
        ipv6RuleCfg["ScheduleName"] == "" or
        ipv6RuleCfg["ScheduleName"] == nil) then
        ipv6RuleCfg["ScheduleName"] = "-"
    end
    
    --editing the selected row and updating it with new values
    status, errMsg = firewall.fwRules6EditSet(ipv6RuleCfg)

    if (status == "OK") then
        db.save2()
    end

    --returning
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.fwRules.ipv6.enable
--
-- @description : This function will enable an existing ipv6 firewall rule in
-- device.
--
-- @param : rowid(s) for which firewall rule has to be queried and enabled.
--
-- @return : status, errMsg
--
function gui.security.fwRules.ipv6.enable (rowids)
    --include
    require "teamf1lualib/firewall"

    -- Sanity for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    for k,v in pairs (rowids) do
        --enabling the selected rule
        status, errMsg = firewall.fwRules6Enable(v)
    end

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.fwRules.ipv6.disable
--
-- @description : This function will disable an existing ipv6 firewall rule in
-- device.
--
-- @param : rowid(s) for which firewall rule has to be queried and disabled.
--
-- @return : status, errMsg
--
function gui.security.fwRules.ipv6.disable (rowids)
    --include
    require "teamf1lualib/firewall"

    -- Sanity for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    for k,v in pairs (rowids) do
        --disabling the selected rule
        status, errMsg = firewall.fwRules6Disable(v)
    end

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.fwRules.ipv6.delete
--
-- @description : This function will delete existing ipv6 firewall rule(s) in
-- device.
--
-- @param : rowid(s) for which firewall rule deleted.
--
-- @return : status, errMsg
--
function gui.security.fwRules.ipv6.delete (rowIds)
    --include
    require "teamf1lualib/firewall"

    -- Sanity for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    -- delete each rule
    for k,v in pairs(rowIds) do
        local inTable = {}
        inTable["FirewallRules6._ROWID_"] = v;
        status, errMsg = firewall.fwRules6Delete (inTable)
        if (not status) then
            break
        end
    end

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

--
-- Custom services
--

-------------------------------------------------------------------------------
-- @name : gui.security.customSvc.get
--
-- @description : fetches all custom services in the device
--
-- @return : lua table containing all custom services
--
function gui.security.customSvc.get()
    --locals
    local customSvcTbl = {}
    local page = {} --getting the Services table
    page.CustomService = {}

    customSvcTbl = firewall.fwCustomSvcGet()
    if (customSvcTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    for i,v in ipairs (customSvcTbl) do
        page.CustomService[i] = {}
        page.CustomService[i].Name = util.filterXSSChars(v["ServiceName"])

        if (v["Protocol"] == "6") then
            page.CustomService[i].Type = "TCP"
        elseif (v["Protocol"] == "17") then
            page.CustomService[i].Type = "UDP"
        elseif (v["Protocol"] == "1") then
            page.CustomService[i].Type = "ICMP"
        end

        page.CustomService[i]._ROWID_ = v["_ROWID_"]

        if (v["Protocol"] == "1") then 
            page.CustomService[i].PortRange = util.filterXSSChars(v["DestinationPortStart"])
        else
            if (v["PortType"] == "2") then --MultiPort
                page.CustomService[i].PortRange = util.filterXSSChars(v["MultiPort"])
            else
                if (v["DestinationPortEnd"] == "0") then
                    page.CustomService[i].PortRange = util.filterXSSChars(v["DestinationPortStart"])
                else
                    page.CustomService[i].PortRange = util.filterXSSChars(v["DestinationPortStart"]) .. "-" .. util.filterXSSChars(v["DestinationPortEnd"])
                end
            end
        end
    end

    -- return
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name : gui.security.customSvc.add.get
--
-- @description : This function gets defaults to add a custom service
--
-- @return : lua table containing default values
--
function gui.security.customSvc.add.get ()
    --locals
    local page = {}

    --return
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name : gui.security.customSvc.add.set
--
-- @description : This function will add new custom service
--
-- @param : lua table containing custom service configuration
--
-- @return : status, errorMsg
--
function gui.security.customSvc.add.set (customSvcCfg)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --local
    local status, errMsg
--[[
    customSvcCfg.ServiceName = customSvcCfg.ServiceName
    customSvcCfg.Protocol = customSvcCfg.Protocol


    if(customSvcCfg.PortType == "2") then
        customSvcCfg.MultiPort = customSvcCfg.MultiPort
    else
        customSvcCfg.DestinationPortStart = customSvcCfg.DestinationPortStart
        customSvcCfg.DestinationPortEnd = customSvcCfg.DestinationPortEnd
    end
]]--

    --setting the rules
    status, errMsg = firewall.fwCustomSvcAddSet (customSvcCfg)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.customSvc.edit.get
--
-- @description : fetches current custom service configuration being edited
--
-- @param : rowid for which custom service to be fetched
--
-- @return : lua table containing current configuration
--
function gui.security.customSvc.edit.get (rowId)
    --locals
    local fwCustomSvcTbl = {}
    local page = {}

    --getting the row with rowid from the services table
    fwCustomSvcTbl = firewall.fwCustomSvcEditGet(rowId)

    if (fwCustomSvcTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    page.ServiceName = util.filterXSSChars(fwCustomSvcTbl["ServiceName"])
    page.Protocol = util.filterXSSChars(fwCustomSvcTbl["Protocol"])
    page.PortType = util.filterXSSChars(fwCustomSvcTbl["PortType"])
    page.MultiPort = util.filterXSSChars(fwCustomSvcTbl["MultiPort"])
    page.DestinationPortStart = util.filterXSSChars(fwCustomSvcTbl["DestinationPortStart"])
    page.DestinationPortEnd = util.filterXSSChars(fwCustomSvcTbl["DestinationPortEnd"])


    --return
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name : gui.security.customSvc.edit.set
--
-- @description : This function will modify a custom service in device.
--
-- @param : lua table containing custom service details
--
-- @return : status, errMsg
--
function gui.security.customSvc.edit.set (customSvcCfg)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg
--[[
    customSvcCfg.ServiceName = customSvcCfg.OLDSERVICENAME
    customSvcCfg.Protocol = customSvcCfg.serviceType

    if (customSvcCfg.Protocol == "6" or customSvcCfg.Protocol == "17") then
        customSvcCfg.DestinationPortStart = customSvcCfg.startPort
        customSvcCfg.DestinationPortEnd = customSvcCfg.finishPort
    else
        customSvcCfg.DestinationPortStart = customSvcCfg.icmpType
        customSvcCfg.DestinationPortEnd = "0"
    end
]]--
    --editing the selected row and updating it with new values
    status, errMsg = firewall.fwCustomSvcEditSet(customSvcCfg)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.customSvc.delete
--
-- @description : This function will delete existing custom services
--
-- @param : rowid(s) of custom services to be deleted
--
-- @return : status, errMsg
--
function gui.security.customSvc.delete (rowIds)
    -- check for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg
    local svcName
    local isFwRuleExist, isFwRule6Exist
    local ruleInUse, ruleInUse6
    local svcFwRulesRows = {}
    local svcFwRulesRows6 = {}
    local query
    local isTrafficSelectorExist

    db.beginTransaction() --begin transactions

    -- delete each service
    for k,v in pairs(rowIds) do
        local inTable = {}
        inTable["Services._ROWID_"] = v

        svcName = db.getAttribute ("Services", "_ROWID_", v, "ServiceName")
        if(svcName == nil or svcName == "") then
            db.rollback()
            return "ERROR", "CUSTOM_SERVICE_DELETE_FAILED"
        end
        query = "ServiceName = '" .. svcName .."'"

        -- check if the service is being used in an IPv4 Firewall Rule
        isFwRuleExist = db.existsRowWhere("FirewallRules", "ServiceName = '" .. svcName .. "'")
        if (isFwRuleExist) then
            db.rollback()
            return "ERROR", "Service " .. svcName .. " is in use. Delete associated IPv4 Port Forwarding/Firewall Rule(s) first."
        end

        -- check if the service is being used in an Traffic selector
        isTrafficSelectorExist = db.existsRowWhere("qosClassification", "Service = '" .. svcName .. "'")
        if (isTrafficSelectorExist) then
            db.rollback()
            return "ERROR", "Service " .. svcName .. " is in use. Delete associated Traffic selector first."
        end
        

        status, errMsg = firewall.fwCustomSvcDelete (inTable)
        if (not status) then
            db.rollback()
            return status, errMsg
        end
    end

    if (status == "OK") then
        db.commitTransaction(true)
        db.save2()
    else
        db.rollback()
    end

    --return
    return status, errMsg
end

--
-- Port Forwarding
--
-------------------------------------------------------------------------------
-- @name : gui.security.portFwd.get
--
-- @description : This function gets the list of available port forwarding rules
--
-- @return : LUA table containing port forwarding rules
--
function gui.security.portFwd.get ()
    --locals
    local portForwardingTbl = {}
    local page = {}
    page.portForwardingTbl = {}

    --getting the inbound rules from FirewallRules table
    fwPortFwdRules = firewall.portFwdRulesGet()
    if (fwPortFwdRules == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    for i,v in ipairs (fwPortFwdRules) do
        page.portForwardingTbl[i] = {}

        if (v["Action"] == "ACCEPT") then
            page.portForwardingTbl[i].Action = "Allow Always"
        else
            page.portForwardingTbl[i].Action = "Block Always"
        end

        page.portForwardingTbl[i].ServiceName = util.filterXSSChars (v["ServiceName"])
        page.portForwardingTbl[i].Status = v["Status"]

        if (v["SourceAddressType"] == "0") then
            page.portForwardingTbl[i].SourceAddressType = "ANY"
        elseif (v["SourceAddressType"] == "1") then
            page.portForwardingTbl[i].SourceAddressType = util.filterXSSChars (v["SourceAddressStart"])
        elseif (v["SourceAddressType"] == "2") then
            page.portForwardingTbl[i].SourceAddressType = util.filterXSSChars (v["SourceAddressStart"]) .. "-" .. util.filterXSSChars (v["SourceAddressEnd"])
        end

        --if (v["DNATPortEnable"] == "1") then
            -- user configured port
        page.portForwardingTbl[i].DNATAddress = util.filterXSSChars (v["DNATAddress"])
        page.portForwardingTbl[i].DNATPort = util.filterXSSChars (v["DNATPort"])
	if (UNIT_INFO ~= "ODU") then
        	page.portForwardingTbl[i].DestinationAddressType = v["DestinationAddressType"]
        	page.portForwardingTbl[i].DnatPortRangeLength = util.filterXSSChars (v["DestinationAddressInvert"])
	end
        --[[            
            --Split this into two DNATAddress and DNATPort fields
        else
            -- get from services table
            local svcRow = {}
            local dstPorts
            svcRow = db.getRowWhere ("Services", "ServiceName = '" .. v["ServiceName"] .. "'", false)

            if (svcRow["DestinationPortStart"] == svcRow["DestinationPortEnd"] or
                svcRow["DestinationPortEnd"] == "0" or svcRow["DestinationPortEnd"] == nil) then
                -- service runs on single port
                dstPorts = svcRow["DestinationPortStart"]
            else
                -- service runs on multiple ports
                dstPorts = svcRow["DestinationPortStart"] .. "-" .. svcRow["DestinationPortEnd"]
            end

            page.portForwardingTbl[i].dnatAddrPort = v["DNATAddress"] .. " : " .. dstPorts
        end
        ]]--
        page.portForwardingTbl[i]._ROWID_ = v["_ROWID_"]
    end

    --return
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name : gui.security.portFwd.add.get
--
-- @description : This function gets defaults while adding a port Fwd rule
--
-- @return : LUA table containing default values
--
function gui.security.portFwd.add.get ()
    --locals
    local portFwdRulesTbl = {}
    local page = {}

    page.Services = {}
    page.wanNetworks = {}

    --getting the table
    portFwdRulesTbl = firewall.portFwdRulesAddGet()
    if (portFwdRulesTbl == nil) then
        return "ERROR", "FIREWALL_RULES_ADD_GET_FAILED"
    end

    for k,v in pairs (portFwdRulesTbl.Services) do
        if(v["Services.Protocol"] == "6" or v["Services.Protocol"] == "17") then
            page.Services[k] = {}
            page.Services[k].ServiceName = util.filterXSSChars(v["Services.ServiceName"])
        end
    end

    --return
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name : gui.security.portFwd.add.set
--
-- @description : This function will add a port forward firewall rule in device.
--
-- @param : lua table containing port forward rule details
--
-- @return : status, errorMsg
--
function gui.security.portFwd.add.set (ipv4RuleCfg)
    -- Sanity for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    --[[
    local errPort = "0"
    -- Adding check for the ports which are opened
    if (ipv4RuleCfg["DNATPort"] ~= nil) then
        errPort = fwPortTriggerLuaLib.isIPv4PortOpen (ipv4RuleCfg["DNATPort"])
        if (tonumber(errPort) == 1) then
            status = "ERROR"
            errMsg = "PORT_ALREADY_OPEN"
            return status, errMsg
        end
    end
    ]]--

    --setting the new rules
    status, errMsg = firewall.portFwdRulesAddSet(ipv4RuleCfg)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.deviceAccess.get
--
-- @description : This function will get details of device access.
--
-- @return : status, errorMsg
--

function gui.security.deviceAccess.get ()
    
    -- Sanity for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    local DeviceAccessInfo = {}
    --locals
    local status, errMsg

    --setting the new rules
    DeviceAccessInfo = firewall.deviceAccessAddGet()


    errMsg = "OK"
    statusMsg = "STATUS_OK"

 -- return
 return errMsg, statusMsg, DeviceAccessInfo

end



-------------------------------------------------------------------------------
-- @name : gui.security.deviceAccess.set
--
-- @description : This function will add a debugging rule in device.
--
--
-- @return : status, errorMsg
--
function gui.security.deviceAccess.set (inputTable)
    -- Sanity for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    --setting the new rules
    status, errMsg = firewall.deviceAccessAddSet(inputTable)

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.portFwd.edit.get
--
-- @description : This function gets port forward rule details available in
-- device.
--
-- @param : rowid for which firewall rule has to be queried.
--
-- @return : lua table containing current rule details
--
function gui.security.portFwd.edit.get (rowid)
    --locals
    local portFwdRulesTbl = {}
    local page = {}
    local DBrow

    page.Services = {}
    page.lanNetworks = {}
    page.wanNetworks = {}

    --getting the drop-downs
    portFwdRulesTbl = firewall.portFwdRulesEditGet()
    if (portFwdRulesTbl == nil) then
        return "ERROR", "FIREWALL_RULES_ADD_GET_FAILED"
    end

    for k,v in pairs (portFwdRulesTbl.Services) do
        if(v["Services.Protocol"] == "6" or v["Services.Protocol"] == "17") then
            page.Services[k] = {}
            page.Services[k].ServiceName = util.filterXSSChars (v["Services.ServiceName"])
        end
    end

    DBrow = db.getRow ("FirewallRules", "_ROWID_", rowid)

    page.Action = util.filterXSSChars (DBrow["FirewallRules.Action"])
    page.ServiceName = util.filterXSSChars (DBrow["FirewallRules.ServiceName"])
    page.SourceAddressType = DBrow["FirewallRules.SourceAddressType"]
    page.SourceAddressStart = util.filterXSSChars (DBrow["FirewallRules.SourceAddressStart"])
    page.SourceAddressEnd = util.filterXSSChars (DBrow["FirewallRules.SourceAddressEnd"])
    page.DNATPortEnable = DBrow["FirewallRules.DNATPortEnable"]
    page.DNATAddress = util.filterXSSChars (DBrow["FirewallRules.DNATAddress"])
    page.DNATPort = util.filterXSSChars (DBrow["FirewallRules.DNATPort"])
    page.LogLevel = DBrow["FirewallRules.LogLevel"]
    if (UNIT_INFO ~= "ODU") then
    	page.DestinationAddressType = DBrow["FirewallRules.DestinationAddressType"]
    	page.DnatPortRangeLength = util.filterXSSChars (DBrow["FirewallRules.DestinationAddressInvert"])
    end

    --return
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name : gui.security.portFwd.edit.set
--
-- @description : This function will modify a port forward rule in device.
--
-- @param : lua table containing ipv4 rule details
--
-- @return : status, errMsg
--
function gui.security.portFwd.edit.set (portFwdRuleCfg)
    -- Sanity for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    --[[
    -- Adding error checks for the port which are opened
    if (portFwdRuleCfg["DNATPort"] ~= nil) then
        local errPort = fwPortTriggerLuaLib.isIPv4PortOpen (portFwdRuleCfg["DNATPort"])
        if (tonumber(errPort) == 1) then
            status = "ERROR"
            errMsg = "PORT_ALREADY_OPEN"
            return status, errMsg
        end
    end
    ]]--

    --editing the selected row and updating it with new values
    status, errMsg = firewall.portFwdRulesEditSet(portFwdRuleCfg)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.portFwd.delete
--
-- @description : This function will delete existing ipv4 port forwarding rules
-- in device.
--
-- @param : rowid(s) for which port forwarding rule deleted.
--
-- @return : status, errMsg
--
function gui.security.portFwd.delete (rowIds)
    --include
    require "teamf1lualib/firewall"

    -- Sanity for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    -- delete each rule
    for k,v in pairs(rowIds) do
        local inTable = {}
        inTable["FirewallRules._ROWID_"] = v;
        status, errMsg = firewall.portFwdRulesDelete (inTable)
        if (not status) then
            break
        end
    end

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.portFwd.enable
--
-- @description : This function will enable an existing port forwarding rule in
-- device.
--
-- @param : rowid(s) for which port forwarding rule has to be queried and enabled.
--
-- @return : status, errMsg
--
function gui.security.portFwd.enable (rowids)
    --include
    require "teamf1lualib/firewall"

    -- Sanity for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    for k,v in pairs (rowids) do
        --enabling the selected rule
        status, errMsg = firewall.portFwdRulesEnable(v)
    end

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.portFwd.disable
--
-- @description : This function will disable an existing port forwarding rule in
-- device.
--
-- @param : rowid(s) for which port forwarding rule has to be queried and disabled.
--
-- @return : status, errMsg
--
function gui.security.portFwd.disable (rowids)
    --include
    require "teamf1lualib/firewall"

    -- Sanity for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    for k,v in pairs (rowids) do
        --disabling the selected rule
        status, errMsg = firewall.portFwdRulesDisable(v)
    end

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end


--
-- MAC filtering
--

-------------------------------------------------------------------------------
-- @name : gui.security.macFilterConfig.get
--
-- @description : This function fetches MAC filtering configuration
--
-- @return : status, errMsg, configTbl
--
function gui.security.macFilterConfig.get ()
    --locals
    local configTbl = {}

    --getting the values from 'macFilterConfig' table
    configTbl = firewall.macFilterConfigGet()
    if(configTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    --return
    return "OK", "STATUS_OK", configTbl
end

-------------------------------------------------------------------------------
-- @name : gui.security.macFilterConfig.set
--
-- @description : This function sets MAC filtering configuration
--
-- @param : lua table containing MAC filter configuration set in webpage
--
-- @return : status, errMsg
--
function gui.security.macFilterConfig.set (InputTableCfg)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    --setting the new configuration in the table
    status, errMsg = firewall.macFilterConfigSet(InputTableCfg)

    if (status == "OK") then
        db.save2()
        os.execute(fwRulesCmd)
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.macFilterRules.get
--
-- @description : This function fetches all MAC filter rules in the device
--
-- @return : lua table containing all MAC filter rules
--
function gui.security.macFilterRules.get ()
    --locals
    local macFilterRulesTbl = {}
    local page = {}
    page.macFilterRules = {}

    --getting the MAC filter rules from 'macFilterRules' table
    macFilterRulesTbl = firewall.macRulesGet()
    if (macFilterRulesTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    for i,v in pairs (macFilterRulesTbl) do
        page.macFilterRules[i] = {}
        page.macFilterRules[i].sourceMacAddr = v["sourceMacAddr"]
        page.macFilterRules[i].decription = v["decription"]
        page.macFilterRules[i]._ROWID_ = v["_ROWID_"]
    end

    --return
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name : gui.security.macFilterRules.add.get
--
function gui.security.macFilterRules.add.get ()
    local configTbl = {}

    return "OK", "STATUS_OK", configTbl
end

-------------------------------------------------------------------------------
-- @name : gui.security.macFilterRules.add.set
--
-- @description : This function adds a MAC filter rule
--
-- @param : lua table containing MAC filter rule configured in webpage
--
-- @return : status, errMsg
--
function gui.security.macFilterRules.add.set (macFilterRuleCfg)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    --setting the new configuration in the table
    status, errMsg = firewall.macRulesAddSet(macFilterRuleCfg)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.macFilterRules.edit.get
--
-- @description : This function gets MAC filter rule being edited
--
-- @param : ROWID of the rule being edited
--
-- @return : lua table containg current configuration of the rule being edited
--
function gui.security.macFilterRules.edit.get (rowId)
    --locals
    local macFilterRule = {}
    local page = {}

    --fetch the row with corresponding rowId from 'macFilterRules' table
    macFilterRule = firewall.macRulesEditGet(rowId)
    if (macFilterRule == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    page.sourceMacAddr = macFilterRule["sourceMacAddr"]
    page.decription = macFilterRule["decription"]

    --return
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name : gui.security.macFilterRules.edit.set
--
-- @description : This function sets MAC filter rule being edited
--
-- @param : lua table containing new configuration of the rule being edited
--
-- @return : status, errMsg
--
function gui.security.macFilterRules.edit.set (macFilterRuleCfg)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    --setting the new configuration in the table
    status, errMsg = firewall.macRulesEditSet(macFilterRuleCfg)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.macFilterRules.delete
--
-- @description : This function deletes MAC filter rules
--
-- @param : ROWIDs of rules to be deleted
--
-- @return : status, errMsg
--
function gui.security.macFilterRules.delete (rowIds)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg


    --delete each MAC filter rule
    for k,v in pairs(rowIds) do
        local deleteRule = {}
        deleteRule["_ROWID_"] = v

        status, errMsg = firewall.macRulesDelete(deleteRule)
        if (status ~= "OK") then
            break
        end
    end

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

--
-- Content filtering
--

-------------------------------------------------------------------------------
-- @name : gui.security.contentFilteringConfig.get
--
-- @description : This function fetches Content filtering configuration
--
-- @return : status, errMsg, configTbl
--
function gui.security.contentFilteringConfig.get ()
    --locals
    local configTbl = {}

    --getting the values from 'ContentFiltering' table
    configTbl = firewall.contentFilteringConfigGet()
    if(configTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    --return
    return "OK", "STATUS_OK", configTbl
end

-------------------------------------------------------------------------------
-- @name : gui.security.contentFilteringConfig.set
--
-- @description : This function sets Content filtering configuration
--
-- @param : lua table containing Content filtering configuration set in webpage
--
-- @return : status, errMsg
--
function gui.security.contentFilteringConfig.set (InputTableCfg)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    --setting the new configuration in 'ContentFiltering' table
    status, errMsg = firewall.contentFilteringConfigSet(InputTableCfg)

    if (status == "OK") then
        db.save2()
        os.execute(fwRulesCmd)
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.trustedDomains.get
--
-- @description : This function fetches all trusted domains added in the device
--
-- @return : lua table containing all trusted domains
--
function gui.security.trustedDomains.get ()
    --locals
    local trustedDomainsTbl = {}
    local page = {}
    page.trustedDomains = {}

    --getting the trusted domains from 'TrustedDomains' table
    trustedDomainsTbl = firewall.trustedDomainsGet()
    if (trustedDomainsTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    for i,v in pairs (trustedDomainsTbl) do
        page.trustedDomains[i] = {}
        page.trustedDomains[i].KeywordToAllow = util.filterXSSChars(v["KeywordToAllow"])
        if (v["ScheduleName"] == "-") then
            page.trustedDomains[i].ScheduleName = "No Schedule"
        else
            page.trustedDomains[i].ScheduleName = util.filterXSSChars(v["ScheduleName"])
        end
        page.trustedDomains[i]._ROWID_ = v["_ROWID_"]
    end

    --return
    return status, errMsg, page
end

-------------------------------------------------------------------------------
-- @name : gui.security.trustedDomains.import
--
-- @description : This function imports trusted domains from a csv file
--
--  @param : filepath of the csv file
--
-- @return : status, errMsg
--
function gui.security.trustedDomains.import (filename)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status = nil
    local errMsg = nil

    status, errMsg = firewall.importCSV("TrustedDomains", filename)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.trustedDomains.add.get
--
-- @description : This function gets defaults to add a trusted domain
--
-- @return : lua table containing default values
--
function gui.security.trustedDomains.add.get ()
    local schTbl = {}
    local page = {}
    page.Schedules = {}

    schTbl = firewall.fwSchedGet()

    for k,v in pairs(schTbl) do
        page.Schedules[k] = {}
        page.Schedules[k].ScheduleName = util.filterXSSChars(v["ScheduleName"])
    end
    page.Schedules["None"] = {}
    page.Schedules["None"].ScheduleName = "No Schedule"

    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name : gui.security.trustedDomains.add.set
--
-- @description : This function adds a trusted domain
--
-- @param : lua table containing trusted domain configured in webpage
--
-- @return : status, errMsg
--
function gui.security.trustedDomains.add.set (trustedDomainCfg)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    if (trustedDomainCfg["ScheduleName"] == "No Schedule" or
        trustedDomainCfg["ScheduleName"] == "" or
        trustedDomainCfg["ScheduleName"] == nil) then
        trustedDomainCfg["ScheduleName"] = "-"
    end

    --setting the new configuration in the table
    status, errMsg = firewall.trustedDomainsAddSet(trustedDomainCfg)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.trustedDomains.edit.get
--
-- @description : This function gets trusted domain being edited
--
-- @param : ROWID of the rule being edited
--
-- @return : lua table containg current configuration of the rule being edited
--
function gui.security.trustedDomains.edit.get (rowId)
    --locals
    local trustedDomain = {}
    local page = {}
    local schTbl = {}

    --fetch the row with corresponding rowId from 'TrustedDomains' table
    trustedDomain = firewall.trustedDomainsEditGet(rowId)
    if (trustedDomain == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    page.KeywordToAllow = util.filterXSSChars(trustedDomain["KeywordToAllow"])

    page.Schedules = {}
    schTbl = firewall.fwSchedGet()
    for k,v in pairs(schTbl) do
        page.Schedules[k] = {}
        page.Schedules[k].ScheduleName = util.filterXSSChars(v["ScheduleName"])
    end
    page.Schedules["None"] = {}
    page.Schedules["None"].ScheduleName = "No Schedule"

    if (trustedDomain["ScheduleName"] == "-") then
        page.ScheduleName = "No Schedule"
    else
        page.ScheduleName = util.filterXSSChars(trustedDomain["ScheduleName"])
    end

    --return
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name : gui.security.trustedDomains.edit.set
--
-- @description : This function sets trusted domain being edited
--
-- @param : lua table containing new configuration of the rule being edited
--
-- @return : status, errMsg
--
function gui.security.trustedDomains.edit.set (trustedDomainCfg)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    if (trustedDomainCfg["ScheduleName"] == "No Schedule" or
        trustedDomainCfg["ScheduleName"] == "" or
        trustedDomainCfg["ScheduleName"] == nil) then
        trustedDomainCfg["ScheduleName"] = "-"
    end

    --setting the new configuration in the table
    status, errMsg = firewall.trustedDomainsEditSet(trustedDomainCfg)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.trustedDomains.delete
--
-- @description : This function deletes trusted domains
--
-- @param : ROWIDs of rules to be deleted
--
-- @return : status, errMsg
--
function gui.security.trustedDomains.delete (rowIds)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    --delete each trusted domain
    for k,v in pairs(rowIds) do
        local deleteTrustedDomain = {}
        deleteTrustedDomain["_ROWID_"] = v

        status, errMsg = firewall.trustedDomainsDelete(deleteTrustedDomain)
        if (status ~= "OK") then
            break
        end
    end

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.blockSites.get
--
-- @description : This function fetches all blocked sites added in the device
--
-- @return : lua table containing all blocked sites
--
function gui.security.blockSites.get ()
    --locals
    local blockSitesTbl = {}
    local page = {}
    page.blockSites = {}

    --getting blocked sites from 'BlockSites' table
    blockSitesTbl = firewall.blockSitesGet()
    --debug.Debugger( (inputTable))
    if (blockSitesTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    for i,v in pairs (blockSitesTbl) do
        page.blockSites[i] = {}
        -- debug.Debugger(v["KeywordToBlock"])
        page.blockSites[i].KeywordToBlock = v["KeywordToBlock"]
        page.blockSites[i].KeywordToBlock = util.filterXSSChars (page.blockSites[i].KeywordToBlock)
        page.blockSites[i].Status = v["Status"]
        if (v["ScheduleName"] == "-") then
            page.blockSites[i].ScheduleName = "No Schedule"
        else
            page.blockSites[i].ScheduleName = util.filterXSSChars(v["ScheduleName"])
        end
        page.blockSites[i]._ROWID_ = v["_ROWID_"]
    end

    --return
    return status, errMsg, page
end

-------------------------------------------------------------------------------
-- @name : gui.security.blockSites.import
--
-- @description : This function imports blocked sites from a csv file
--
--  @param : filepath of the csv file
--
-- @return : status, errMsg
--
function gui.security.blockSites.import (filename)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status = nil
    local errMsg = nil

    --local filename
    --filename = "/tmp/" .. cgilua.cookies.get("TeamF1Login")
    --setting the new configuration in the table
    status, errMsg = firewall.importCSV("BlockSites", filename)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.blockSites.add.get
--
function gui.security.blockSites.add.get()
    local configTbl = {}
    local schTbl = {}
    configTbl.Schedules = {}

    schTbl = firewall.fwSchedGet()
    for k,v in pairs(schTbl) do
        configTbl.Schedules[k] = {}
        configTbl.Schedules[k].ScheduleName = util.filterXSSChars(v["ScheduleName"])
    end
    configTbl.Schedules["None"] = {}
    configTbl.Schedules["None"].ScheduleName = "No Schedule"

    return "OK", "STATUS_OK", configTbl
end

-------------------------------------------------------------------------------
-- @name : gui.security.blockSites.add.set
--
-- @description : This function adds a blocked site
--
-- @param : lua table containing blocked site configured in webpage
--
-- @return : status, errMsg
--
function gui.security.blockSites.add.set (blockSitesCfg)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    if (blockSitesCfg["ScheduleName"] == "No Schedule" or
        blockSitesCfg["ScheduleName"] == "" or
        blockSitesCfg["ScheduleName"] == nil) then
        blockSitesCfg["ScheduleName"] = "-"
    end
    
    --setting the new configuration in the table
    status, errMsg = firewall.blockSitesAddSet(blockSitesCfg)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.blockSites.edit.get
--
-- @description : This function gets blocked site being edited
--
-- @param : ROWID of the rule being edited
--
-- @return : lua table containing current configuration of the rule being edited
--
function gui.security.blockSites.edit.get (rowId)
    --locals
    local blockSite = {}
    local page = {}
    local schTbl = {}

    --fetch the row with corresponding rowId from 'BlockSites' table
    blockSite = firewall.blockSitesEditGet(rowId)
    if (blockSite == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    page.KeywordToBlock = blockSite["KeywordToBlock"]
    page.KeywordToBlock = util.filterXSSChars (page.KeywordToBlock)

    page.Schedules = {}
    schTbl = firewall.fwSchedGet()
    for k,v in pairs(schTbl) do
        page.Schedules[k] = {}
        page.Schedules[k].ScheduleName = util.filterXSSChars (v["ScheduleName"])
    end
    page.Schedules["None"] = {}
    page.Schedules["None"].ScheduleName = "No Schedule"

    if (blockSite["ScheduleName"] == "-") then
        page.ScheduleName = "No Schedule"
    else
        page.ScheduleName = util.filterXSSChars (blockSite["ScheduleName"])
    end

    --return
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name : gui.security.blockSites.edit.set
--
-- @description : This function sets blocked site being edited
--
-- @param : lua table containing new configuration of the rule being edited
--
-- @return : status, errMsg
--
function gui.security.blockSites.edit.set (blockSiteCfg)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    if (blockSiteCfg["ScheduleName"] == "No Schedule" or
        blockSiteCfg["ScheduleName"] == "" or
        blockSiteCfg["ScheduleName"] == nil) then
        blockSiteCfg["ScheduleName"] = "-"
    end
    
    --setting the new configuration in the table
    status, errMsg = firewall.blockSitesEditSet(blockSiteCfg)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.blockSites.delete
--
-- @description : This function deletes blocked sites
--
-- @param : ROWIDs of rules to be deleted
--
-- @return : status, errMsg
--
function gui.security.blockSites.delete (rowIds)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    --delete each blocked site
    for k,v in pairs(rowIds) do
        local deleteBlockSites = {}
        deleteBlockSites["_ROWID_"] = v

        status, errMsg = firewall.blockSitesDelete(deleteBlockSites)
        if (status ~= "OK") then
            break
        end
    end

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.blockSites.enable
--
-- @description : This function enables blocked site(s)
--
-- @param : ROWID(s) of blocked site(s) to be enabled
--
-- @return : status, errMsg
--
function gui.security.blockSites.enable(rowids)
    -- Sanity for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    for k,v in pairs (rowids) do
        --enabling the selected blocked sites
        status, errMsg = firewall.blockSitesEnable(v)
    end

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.blockSites.disable
--
-- @description : This function disable blocked site(s)
--
-- @param : ROWID(s) of blocked site(s) to be disabled
--
-- @return : status, errMsg
--
function gui.security.blockSites.disable(rowids)
    -- Sanity for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    for k,v in pairs (rowids) do
        --disabling the selected blocked sites
        status, errMsg = firewall.blockSitesDisable(v)
    end

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.account.get
--
-- @description : This function fetches Bandwidth Monitoring configuration
--
-- @return : status, errMsg, configTbl
--
function gui.security.account.get ()
    --locals
    local configTbl = {}

    --getting the values from 'BwMon' table
    configTbl = firewall.bwMonGet()
    if(configTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    --return
    return "OK", "STATUS_OK", configTbl
end

-------------------------------------------------------------------------------
-- @name : gui.security.pktCount.get
--
-- @description : This function fetches tr-69 pkt count configuration
--
-- @return : status, errMsg, configTbl
--
function gui.security.pktCount.get ()
    --locals
    local configTbl = {}

    --getting the values from 'PktCountEnable' table
    configTbl = firewall.pktCountGet()
    if(configTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    --return
    return "OK", "STATUS_OK", configTbl
end

-------------------------------------------------------------------------------
-- @name : gui.security.account.set
--
-- @description : This function sets  bandwidth monitoring configuration
--
-- @param : lua table containing bandwidth monitoring configuraion set in webpage
--
-- @return : status, errMsg
--
function gui.security.account.set (InputTableCfg)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    db.beginTransaction()
    --setting the new configuration in the table
    status, errMsg = firewall.bwMonSet(InputTableCfg)

    if (status == "OK") then
        --setting the new configuration in the table
        status, errMsg = firewall.pktCountSet(InputTableCfg)
        if (status == "OK") then
        db.commitTransaction(true)
        os.execute("/pfrm2.0/bin/fwRulesScript.sh 0 &")
        db.save2()
        os.execute(fwRulesCmd)
    end
    else
        db.rollback()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------
-- @name gui.security.customAccount.edit.get
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--
function gui.security.customAccount.edit.get (rowid)
    local configRow = {} 

    configRow = firewall.bwMonCustomEditGet(rowid)
   
    if (configRow == nil) then
        return "ERROR", "BW_CUSTOM_ACC_GET_FAILED"
    end

    configRow["ipAddr"] = util.filterXSSChars(configRow["ipAddr"])
    configRow["macAddr"] = util.filterXSSChars(configRow["macAddr"])

    return "OK", "OK", configRow
end

-------------------------------------------------------------------------
-- @name gui.security.customAccount.edit.set
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--
function gui.security.customAccount.edit.set (conf)
	--locals
	local status, err

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    db.beginTransaction() --begin transactions
    
    -- configure isatap
    status, errCode = firewall.bwMonCustomEditSet (conf)
    if (status ~= "OK") then
        db.rollback()
        return status, errCode
    end

    db.commitTransaction(true)
    db.save2()

    return "OK","STATUS_OK"
 
end

-------------------------------------------------------------------------
-- @name gui.security.customAccount.add.get
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--
function gui.security.customAccount.add.get ()
   
    local configTbl = {}

    return "OK", "STATUS_OK", configTbl
 
end

-------------------------------------------------------------------------
-- @name gui.security.customAccount.add.set
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--
function gui.security.customAccount.add.set (conf)

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
    --locals
    local status, errMsg

    db.beginTransaction() --begin transactions

    status, errMsg = firewall.bwMonCustomAddSet(conf)

    if (status ~= "OK") then
        db.rollback()
        return status, errMsg
    end

    db.commitTransaction(true)
    db.save2()

    --return
    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name gui.security.customAccount.get
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--
function gui.security.customAccount.get ()
   
    --locals
    local page = {}
    page = firewall.bwMonCustomGet() 

    for i,v in ipairs (page) do
        page[i] = {}
        page[i] = v
        page[i].ipAddr = util.filterXSSChars(v["ipAddr"])
        page[i].macAddr = util.filterXSSChars(v["macAddr"])
    end

    --return
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------
-- @name gui.security.customAccount.delete
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--
function gui.security.customAccount.delete (rowIds)

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    db.beginTransaction() --begin transactions

    for k,v in pairs(rowIds) do
        local inTable = {}
        inTable["_ROWID_"] = v

        status, errMsg = firewall.bwMonCustomDelete(inTable)
        if (status ~= "OK") then
            break
        end
    end

    if (status ~= "OK") then
        db.rollback()
        return status, errMsg
    end

    db.commitTransaction(true)
    db.save2()

    --return
    return "OK", "STATUS_OK"

end

-------------------------------------------------------------------------
-- @name gui.security.unauthorizedUsage.get
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--
function gui.security.unauthorizedUsage.get ()

	require "teamf1lualib/platform" 

    --locals
    local page = {}
    page = platform.unAuthorizedUsageGet() 
    --return
	if (page == nil) then
		return "ERROR","ERROR", nil
	else
		return "OK", "STATUS_OK", page
	end

end


-------------------------------------------------------------------------
-- @name gui.security.unauthorizedUsage.se
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--
function gui.security.unauthorizedUsage.set (conf)

	require "teamf1lualib/platform"

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
    --locals
    local status, errMsg

    db.beginTransaction() --begin transactions

    status, errMsg = platform.unAuthorizedUsageSet(conf)

    if (status ~= "OK") then
        db.rollback()
        return status, errMsg
    end

    db.commitTransaction(true)
    db.save2()

    --return
    return "OK", "STATUS_OK"
end 

--
-- Client MAC Config
--

-------------------------------------------------------------------------------
-- @name : gui.security.clientMacConfig.get
--
-- @description : This function fetches MAC filtering configuration
--
-- @return : status, errMsg, configTbl
--
function gui.security.clientMacConfig.get ()
    --locals
    local macTable = {}
    local configTbl = {}
    local macConfigTbl = {}
    local size = 0
    -- locals for single get 
    macTable.configTbl = {}
    macTable.macConfigTbl = {}

    --getting the values from 'clientMacConfig' table
    configTbl = firewall.clientMacConfigGet()
    if (configTbl ~= nil) then
        size = #configTbl
    end
    if(configTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    macConfigTbl = db.getRowWhere("macFilterConfig", "_ROWID_=1", false)
    if(macConfigTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end
    macTable.configTbl = configTbl
    macTable.macConfigTbl = macConfigTbl

    for i,v in ipairs (macTable.configTbl) do
        macTable.configTbl[i] = {}
        macTable.configTbl[i] = v
        macTable.configTbl[i].alias = util.filterXSSChars(v["alias"])
        macTable.configTbl[i].sourceMacAddr = util.filterXSSChars(v["sourceMacAddr"])
        macTable.configTbl[i].decription = util.filterXSSChars(v["decription"])
    end

    if(size >= 250) then
        return "ERROR", "MAX CLIENT LIMIT REACHED", macTable
    else
        return "OK", "STATUS_OK", macTable
    end
end

--
-- Client MAC Config
--

-------------------------------------------------------------------------------
-- @name : gui.security.clientMacConfig.editGet
--
-- @description : This function fetches MAC filtering configuration
--
-- @return : status, errMsg, configTbl
--
function gui.security.clientMacConfig.editGet (rowId)
    --locals
    local macTable = {}
    local configTbl = {}
    local macConfigTbl = {}
    local size = 0

    --getting the values from 'clientMacConfig' table
    configTbl = firewall.clientMacConfigEditGet(rowId)
    util.appendDebugOut ("Row to Edit: " .. util.tableToStringRec(configTbl))
    configTbl["descr"] = configTbl ["decription"]

    if(configTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    return "ERROR", "MAX CLIENT LIMIT REACHED", configTbl
end

-------------------------------------------------------------------------------
-- @name : gui.security.clientMacConfig.set
--
-- @description : This function sets MAC filtering configuration
--
-- @param : lua table containing MAC filter configuration set in webpage
--
-- @return : status, errMsg
--
function gui.security.clientMacConfig.set (InputTableCfg, action)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    --setting the new configuration in the table
    status, errMsg = firewall.clientMacConfigSet(InputTableCfg, action)

    if (status == "OK") then
        db.save2()
        os.execute(fwRulesCmd)
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.clientMacConfig.set
--
-- @description : This function sets MAC filtering configuration
--
-- @param : lua table containing MAC filter configuration set in webpage
--
-- @return : status, errMsg
--
function gui.security.clientMacConfig.editSet (InputTableCfg, action)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    --setting the new configuration in the table
    util.appendDebugOut ("clientmacTable Edit Set: " .. util.tableToStringRec(InputTableCfg))
    status, errMsg = firewall.clientMacConfigEditSet(InputTableCfg, InputTableCfg["_ROWID_"])

    if (status == "OK") then
        db.save2()
        os.execute(fwRulesCmd)
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.clientMacConfig.delete
--
-- @description : This function deleted the MAC address
--
-- @param : lua table containing MAC filter configuration set in webpage
--
-- @return : status, errMsg
--
function gui.security.clientMacConfig.delete(rows)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
    local MacTbl = {}
    local count = 1
    for i, v in pairs (rows) do
        MacTbl[count] = v
        count = count + 1
    end
    --locals
    local status, errMsg

    --setting the new configuration in the table
    status, errMsg = firewall.clientMacConfigDelete(MacTbl)

    if (status == "OK") then
        db.save2()
        os.execute(fwRulesCmd)
    end

    --return
    return status, errMsg
end

function gui.security.clientMacConfig.save(inputTable)
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
    --locals
    local status, errMsg
    --setting the new configuration in the table
    status, errMsg = firewall.clientMacConfigSave(inputTable)

    if (status == "OK") then
        db.save2()
        os.execute(fwRulesCmd)
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.fwRules.l2.get
--
-- @description : This function gets the list of available l2 outbound rules
--
-- @return : LUA table containing l2 outbound rules
--
function gui.security.fwRules.l2.get ()
    --locals
    local fwL2RulesTbl = {}
    local page = {}
    page.L2FirewallRules = {}

    --getting outbound rules from 'L2FirewallRules' table
    fwL2RulesTbl = firewall.fwRulesL2Get()
    if (fwL2RulesTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    for i,v in ipairs (fwL2RulesTbl) do
        page.L2FirewallRules[i] = {}
        --[[
        if (v["Status"] == "1") then
            page.FirewallRules[i].Status = "Enabled"
        else
            page.FirewallRules[i].Status = "Disabled"
        end
        ]]--
        page.L2FirewallRules[i].Status = v["Status"]
       
        if (v["RuleType"] == "SECURE_INSECURE") then
            page.L2FirewallRules[i].Direction = "Outbound"
        else
            page.L2FirewallRules[i].Direction = "Inbound"
        end
        page.L2FirewallRules[i].Status = v["Status"]

        page.L2FirewallRules[i].ServiceName = v["ServiceName"]
        if (v["ScheduleName"] == "-") then
            page.L2FirewallRules[i].ScheduleName = "No Schedule"
        else
            page.L2FirewallRules[i].ScheduleName = v["ScheduleName"]
        end

        if (v["Action"] == "ACCEPT") then
            page.L2FirewallRules[i].Action = "Allow Always"
        elseif (v["Action"] == "DROP") then
            page.L2FirewallRules[i].Action = "Block Always"
        elseif (v["Action"] == "ACCEPT_BY_SCH") then
            page.L2FirewallRules[i].Action = "Allow by Schedule"
        elseif (v["Action"] == "DROP_BY_SCH") then
            page.L2FirewallRules[i].Action = "Block by Schedule"
        end

        if (v["SourceAddressType"] == "0") then
            page.L2FirewallRules[i].SourceAddressType = "ANY"
        elseif (v["SourceAddressType"] == "1") then
            page.L2FirewallRules[i].SourceAddressType = v["SourceAddressStart"]
        elseif (v["SourceAddressType"] == "2") then
            page.L2FirewallRules[i].SourceAddressType = v["SourceAddressStart"] .. "-" .. v["SourceAddressEnd"]
        end

        if (v["DestinationAddressType"] == "0") then
            page.L2FirewallRules[i].DestinationAddressType = "ANY"
        elseif (v["DestinationAddressType"] == "1") then
            page.L2FirewallRules[i].DestinationAddressType = v["DestinationAddressStart"]
        elseif (v["DestinationAddressType"] == "2") then
            page.L2FirewallRules[i].DestinationAddressType = v["DestinationAddressStart"] .. "-" .. v["DestinationAddressEnd"]
        end

        if (v["SourceMACAddressType"] == "0") then
            page.L2FirewallRules[i].SourceMACAddressType = "ANY"
        elseif (v["SourceMACAddressType"] == "1") then
            page.L2FirewallRules[i].SourceMACAddressType = v["SourceMACAddressStart"]
        elseif (v["SourceMACAddressType"] == "2") then
            page.L2FirewallRules[i].SourceMACAddressType = v["SourceMACAddressStart"] .. "-" .. v["SourceMACAddressEnd"]
        end

        if (v["DestinationMACAddressType"] == "0") then
            page.L2FirewallRules[i].DestinationMACAddressType = "ANY"
        elseif (v["DestinationMACAddressType"] == "1") then
            page.L2FirewallRules[i].DestinationMACAddressType = v["DestinationMACAddressStart"]
        elseif (v["DestinationMACAddressType"] == "2") then
            page.L2FirewallRules[i].DestinationMACAddressType = v["DestinationMACAddressStart"] .. "-" .. v["DestinationMACAddressEnd"]
        end

        page.L2FirewallRules[i]._ROWID_ = v["_ROWID_"]
    end

    --return
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name : gui.security.fwRules.l2.add.get
--
-- @description : This function gets defaults to add an l2 firewall rule
--
-- @return : LUA table containing default values
--
function gui.security.fwRules.l2.add.get ()
    --locals
    local fwL2RulesTbl = {}
    local schTbl = {}
    local page = {}
    local i
    page.Services = {}
    page.Schedules = {}

    --fetching the table
    fwL2RulesTbl = firewall.fwRulesL2AddGet()
    if (fwL2RulesTbl == nil) then
        return "ERROR", "FIREWALL_RULES_ADD_GET_FAILED"
    end

    for k,v in pairs (fwL2RulesTbl.Services) do
        page.Services[k] = {}
        page.Services[k].ServiceName = v["Services.ServiceName"]
    end

    schTbl = firewall.fwSchedGet()
    for k,v in pairs(schTbl) do
        page.Schedules[k] = {}
        page.Schedules[k].ScheduleName = v["ScheduleName"]
    end
    page.Schedules["None"] = {}
    page.Schedules["None"].ScheduleName = "No Schedule"

    --return
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name : gui.security.fwRules.l2.add.set
--
-- @description : This function will add an l2 firewall rule in device.
--
-- @param : lua table containing l2 rule details
--
-- @return : status, errorMsg
--
function gui.security.fwRules.l2.add.set (l2RuleCfg)
    -- Sanity for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    if (l2RuleCfg["ScheduleName"] == "No Schedule" or
        l2RuleCfg["ScheduleName"] == "" or
        l2RuleCfg["ScheduleName"] == nil) then
        l2RuleCfg["ScheduleName"] = "-"
    end

    --setting the new rules
    status, errMsg = firewall.fwRulesL2AddSet(l2RuleCfg)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.fwRules.l2.edit.get
--
-- @description : This function gets l2 firewall rule details available in
-- device.
--
-- @param : rowid for which firewall rule has to be queried.
--
-- @return : lua table containing current rule details
--
function gui.security.fwRules.l2.edit.get (rowid)
    --locals
    local fwL2RulesTbl = {}
    local schTbl = {}
    local page = {}
    local DBrow

    page.Services = {}
    page.Schedules= {}

    --getting the drop-downs
    fwL2RulesTbl = firewall.fwRulesL2EditGet()
    if (fwL2RulesTbl == nil) then
        return "ERROR", "FIREWALL_RULES_ADD_GET_FAILED"
    end

    for k,v in pairs (fwL2RulesTbl.Services) do
        page.Services[k] = {}
        page.Services[k].ServiceName = v["Services.ServiceName"]
    end

    schTbl = firewall.fwSchedGet()
    for k,v in pairs(schTbl) do
        page.Schedules[k] = {}
        page.Schedules[k].ScheduleName = v["ScheduleName"]
    end
    page.Schedules["None"] = {}
    page.Schedules["None"].ScheduleName = "No Schedule"

    DBrow = db.getRow ("L2FirewallRules", "_ROWID_", rowid)

    if (DBrow["L2FirewallRules.RuleType"] == "SECURE_INSECURE") then
        page.Direction = "Outbound"
    else
        page.Direction = "Inbound"
    end

    --debug.Debugger(util.tableToString (DBrow))
    page.ServiceName = DBrow["L2FirewallRules.ServiceName"]
    if (DBrow["L2FirewallRules.ScheduleName"] == "-") then
        page.ScheduleName = "No Schedule"
    else
        page.ScheduleName = DBrow["L2FirewallRules.ScheduleName"]
    end
    page.Action = DBrow["L2FirewallRules.Action"]
    
    page.SourceAddressType = DBrow["L2FirewallRules.SourceAddressType"]
    page.SourceAddressStart = DBrow["L2FirewallRules.SourceAddressStart"] or ''
    page.SourceAddressEnd = DBrow["L2FirewallRules.SourceAddressEnd"] or ''

    page.DestinationAddressType = DBrow["L2FirewallRules.DestinationAddressType"]
    page.DestinationAddressStart = DBrow["L2FirewallRules.DestinationAddressStart"] or ''
    page.DestinationAddressEnd = DBrow["L2FirewallRules.DestinationAddressEnd"] or ''
    page.LogLevel = DBrow["L2FirewallRules.LogLevel"] or ''

    page.SourceMACAddressType = DBrow["L2FirewallRules.SourceMACAddressType"]
    page.SourceMACAddressStart = DBrow["L2FirewallRules.SourceMACAddressStart"] or ''
    page.SourceMACAddressEnd = DBrow["L2FirewallRules.SourceMACAddressEnd"] or ''

    page.DestinationMACAddressType = DBrow["L2FirewallRules.DestinationMACAddressType"]
    page.DestinationMACAddressStart = DBrow["L2FirewallRules.DestinationMACAddressStart"] or ''
    page.DestinationMACAddressEnd = DBrow["L2FirewallRules.DestinationMACAddressEnd"] or ''
    --return
    --debug.Debugger(util.tableToString (page))
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name gui.security.fwRules.l2.edit.set
--
-- @description : This function will modify an ipv6 firewall rule in device.
--
-- @param : lua table containing l2 rule details
--
-- @return : status, errMsg
--
function gui.security.fwRules.l2.edit.set (l2RuleCfg)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    if (l2RuleCfg["ScheduleName"] == "No Schedule" or
        l2RuleCfg["ScheduleName"] == "" or
        l2RuleCfg["ScheduleName"] == nil) then
        l2RuleCfg["ScheduleName"] = "-"
    end
    
    --editing the selected row and updating it with new values
    status, errMsg = firewall.fwRulesL2EditSet(l2RuleCfg)

    if (status == "OK") then
        db.save2()
    end

    --returning
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.fwRules.l2.enable
--
-- @description : This function will enable an existing l2 firewall rule in
-- device.
--
-- @param : rowid(s) for which firewall rule has to be queried and enabled.
--
-- @return : status, errMsg
--
function gui.security.fwRules.l2.enable (rowids)
    --include
    require "teamf1lualib/firewall"

    -- Sanity for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    for k,v in pairs (rowids) do
        --enabling the selected rule
        status, errMsg = firewall.fwRulesL2Enable(v)
    end

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.fwRules.l2.disable
--
-- @description : This function will disable an existing l2 firewall rule in
-- device.
--
-- @param : rowid(s) for which firewall rule has to be queried and disabled.
--
-- @return : status, errMsg
--
function gui.security.fwRules.l2.disable (rowids)
    --include
    require "teamf1lualib/firewall"

    -- Sanity for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    for k,v in pairs (rowids) do
        --disabling the selected rule
        status, errMsg = firewall.fwRulesL2Disable(v)
    end

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.security.fwRules.l2.delete
--
-- @description : This function will delete existing ipv6 firewall rule(s) in
-- device.
--
-- @param : rowid(s) for which firewall rule deleted.
--
-- @return : status, errMsg
--
function gui.security.fwRules.l2.delete (rowIds)
    --include
    require "teamf1lualib/firewall"

    -- Sanity for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    -- delete each rule
    for k,v in pairs(rowIds) do
        local inTable = {}
        inTable["L2FirewallRules._ROWID_"] = v;
        status, errMsg = firewall.fwRulesL2Delete (inTable)
        if (not status) then
            break
        end
    end

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end


--------------------------------------------------------------------------------
-- @name gui.security.allot.get()
--
-- @description This function gets the allot configuration
--
-- @return status, errMsg, lua table containing allot configuration
--
function gui.security.allot.get()
    --include
    require "teamf1lualib/firewall"

    --locals
    local allotRow = {}
    local configTbl = {}

    --get values from 'allot' table
    allotRow = db.getRow ("Allot", "_ROWID_", "1")
    if(allotRow == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end
    configTbl["Enable"] = allotRow["Allot.Enable"]

    --return
    return "OK", "STATUS_OK", configTbl
end

--------------------------------------------------------------------------------
-- @name gui.security.allot.set()
--
-- @description This function sets the allot configuration
--
-- @return status, errMsg
--
function gui.security.allot.set(inCfg)

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status="STATUS_OK"
    local errMsg
    local allotRow = {}

    --setting the values in 'allot' table
    allotRow["Enable"] = inCfg["Enable"]
    if( allotRow["Enable"] == "1") then        
        os.execute("/pfrm2.0/etc/cyberInit > /dev/null")
	os.execute("touch /tmp/AllotEnable")
    elseif( allotRow["Enable"] == "0") then
        os.execute("ps  | grep cyberiot_bkg_init.sh |grep -v grep| awk '{print $1}' | xargs kill -9")
        os.execute("ps  | grep nget2 |grep -v grep| awk '{print $1}' | xargs kill -9")
	os.execute("rm -rf /tmp/AllotEnable")
    end
            
    allotRow = util.addPrefix (allotRow,"Allot.")
    local valid, errMsg = db.update("Allot", allotRow, "1")
    if (not valid) then
        status = "ERROR"
       return status, errMsg;
    end

 
    if (status == "STATUS_OK") then
        db.save2()
    end
    
    --return
    return status, errMsg
end

