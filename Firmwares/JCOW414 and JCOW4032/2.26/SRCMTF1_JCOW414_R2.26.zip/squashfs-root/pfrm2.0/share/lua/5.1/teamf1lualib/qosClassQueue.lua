--[[
#### Copyright (c) 2010, TeamF1, Inc.
#### Oct 12, 2010
#### Copyright (c) 2016, TeamF1 Networks Pvt. Ltd.
####  (Subsidiary of D-Link India)
#### File: qosClassQueue.lua
#### Description: QoS 
#### Revisions:
01b,12jul16,ash changes for FAPI QOS.
01a 12Oct10, sam written
]]--

--************* Requires *************
-- XXX: qos.lua includes this file

--************* Initial Code *************

--************* Global Variables *************

qos.classQueue = {}
qos.classQueue.rateType =  {
    QOS_RATE_TYPE_KBPS      =   1,
    QOS_RATE_TYPE_PERCENT   =   2,
}
    
-------------------------------------------------------------------------------
-- @name  qos.classQueue.add 
--
-- @param 
--
-- @description This function adds a class queue. The argument to this function is
-- a LUA table having the schema described by qosClassQueue. The LUA table must 
-- have the ProfileKey initialized.
--
-- @return 0 for success, < 0 for error
--

function qos.classQueue.add (queue)
	local ret = -1
	local errCode
	local QueueKey

	if (queue == nil) then
		return -1, "QOS_INVALID_ARG"
	end	

	local ProfileKey = queue["ProfileKey"]
	if (ProfileKey == nil) then
		return -1, "QOS_INVALID_ARG"
	end
	
    if (not util.fileExists(fapiQos)) then
        if ((queue["QueueId"] == nil) or (string.len(queue["QueueId"]) == 0)) then
		    return -1, "QOS_INVALID_ARG"
        end        

        if ((queue["ParentId"] == nil) or (string.len(queue["ParentId"]) == 0)) then
		    return -1, "QOS_INVALID_ARG"
        end        
    end

	ret, errCode  = qos.classQueue.getByName(queue["QueueName"])
	if (ret ~= nil) then
        return -1,"QOS_QUEUE_EXISTS"
	end

	QueueKey, errCode = qosLib.queueAdd(ProfileKey, queue)
	if (QueueKey <= 0) then
		return -1, errCode
	end

	queue["QueueKey"] = QueueKey
    if (util.fileExists(fapiQos)) then
        qId = tonumber (QueueKey % 8 ) - 2
        queue["FAPIpri"] = qId 
        queue["FAPImap"] = qId
    end

	queue = util.addPrefix(queue, "qosClassQueue.")

	-- update the database
	ret, errCode = db.insert("qosClassQueue", queue)
	if (ret) then
	   return 0, "STATUS_OK"
	else
	   return -1, errCode
	end
end

-------------------------------------------------------------------------------
-- @name  qos.classQueue.edit - edit a class queue
--
-- @param
--
-- @description This function edits a class queue. The argument to this 
-- function is a LUA table having the schema described by qosClassQueue. The 
-- LUA table must have the ProfileKey and _ROWID_ initialized.
--
-- @return 0 for success, < 0 for error
--

function qos.classQueue.edit (queue)
	local ret
	local errCode

	if (queue == nil) then
		return -1, "QOS_INVALID_ARG"
	end	

    qos.dprintf("classQueue.edit: Editing Queue: " .. 
                util.tableToStringRec(queue))

	-- check if the queue exits in the database
	local row = qos.classQueue.getById(queue["QueueKey"])
	if (row == nil) then
		return -1, "QUEUE_NOT_FOUND"
	end

    if (not util.fileExists(fapiQos)) then
        if ((queue["QueueId"] == nil) or (string.len(queue["QueueId"]) == 0)) then
		    return -1, "QOS_INVALID_ARG"
        end        

        if ((queue["ParentId"] == nil) or (string.len(queue["ParentId"]) == 0)) then
		    return -1, "QOS_INVALID_ARG"
        end       
    end

    --
    -- If the profile has changed and the class queue is in
    -- use, then return an error
    --
	local ProfileKey = row["ProfileKey"]
    if (tonumber(ProfileKey) ~= tonumber(queue["ProfileKey"])) then
        if (qos.classQueue.inUse(queue["QueueKey"]) == true) then
    		return -1, "QOS_CLASSQUEUE_IN_USE"
        end            
    end        

	ret, errCode = qosLib.queueEdit(ProfileKey, queue)
	if (ret < 0) then
		return ret, errCode
	end

	queue["_ROWID_"] = row["_ROWID_"]
	queue = util.addPrefix(queue, "qosClassQueue.")

	-- update the database
	ret, errCode = db.update("qosClassQueue", queue,  row["_ROWID_"])
	if (ret) then
		return 0, "STATUS_OK"
	else
	    return -1, errCode
	end
end
	
-------------------------------------------------------------------------------
-- @name  qos.classQueue.getByName 
--
-- @param 
--
-- @description This function gets a class queue by name.
--
-- @return class queue or nil

function qos.classQueue.getByName (QueueName)
	local ret
	local errCode

	if (QueueName == nil) then
		return -1,"QOS_INVALID_ARG"
	end

	query = "QueueName='" ..  QueueName .."' and configDefault = 0"
	local queue = db.getRowWhere("qosClassQueue", query, false)
	if (queue == nil) then
		return nil,"QOS_QUEUE_NOT_FOUND"
	end
	
	return queue
end

-------------------------------------------------------------------------------
-- @name qos.classQueue.getById 
--
-- @param 
--
-- @description This function gets a class queue by QueueKey
--
-- @return class queue or nil
--

function qos.classQueue.getById (QueueKey)
	local ret
	local errCode

	if (QueueKey == nil) then
		return -1,"QOS_INVALID_ARG"
	end

	query = "QueueKey=" ..  QueueKey
	queue = db.getRowWhere("qosClassQueue", query, false)
	if (queue == nil) then
		return nil,"QOS_QUEUE_NOT_FOUND"
	end
	
	return queue
end

-------------------------------------------------------------------------------
-- @name  qos.classQueue.delete 
--
-- @param 
--
-- @description This function deletes a class queue with given QueueKey.
--
-- @return 0 for success, < 0 for error
--

function qos.classQueue.delete (QueueKey)
	local ret
	local queue
	local errCode

	if (QueueKey == nil) then
		return -1,"QOS_INVALID_ARG"
	end

	-- get the queue to be deleted
	local query = "QueueKey="..  QueueKey 
	queue = db.getRowWhere("qosClassQueue", query, false)
    if (queue == nil) then
        query = "QueueName='" .. QueueKey .. "'"
	    queue = db.getRowWhere("qosClassQueue", query, false)
    	if (queue == nil) then
            qos.dprintf("classQueue.delete: failed to get queue. Query=" .. query)
		    return -1, "QOS_QUEUE_NOT_FOUND"
    	end
    end        

    -- check if it is being used by any classification rule
	local query = "QueueKey="..  QueueKey 
    status, errCode, rule = qos.rule.cfgByQueryGet(query)
    if (rule ~= nil) then
	    return -1, "QOS_QUEUE_IN_USE"
    end        
            
	local ProfileKey = queue["ProfileKey"]
    QueueKey = queue["QueueKey"]

	-- delete the queue
	ret, errCode = qosLib.queueDel(ProfileKey, QueueKey)
	if (ret < 0) then
        qos.dprintf("classQueue.delete: failed to delete class queue(" .. QueueKey .. 
                    ") ProfileKey=" .. ProfileKey)
	end		

	-- update the database
	query = "_ROWID_=" .. queue["_ROWID_"]
	ret, errCode = db.deleteRowWhere("qosClassQueue", query)
	if (ret) then
	    return 0, "STATUS_OK"
	else
	    return -1, errCode
	end
end

-------------------------------------------------------------------------------
-- @name  qos.classQueue.tableGet
--
-- @param 
--
-- @description This function gets the configuration of the class queue based on
-- the given query. The result is returned in the form of a LUA table.
--
-- @return OK or ERROR
-- @return errCode 
-- @return queue table
--

function qos.classQueue.tableGet (query)
    local queueTbl = nil

    if (query == nil) then
        queueTbl = db.getTable("qosClassQueue", false)
    else
        queueTbl = db.getRowsWhere("qosClassQueue", query, false)
    end        

    if (queueTbl == nil) then
        return "ERROR", "QOS_CQUEUE_ERR_ENOENT"
    end
            
    return "OK","STATUS_OK", queueTbl            
end

-------------------------------------------------------------------------------
-- @name  qos.classQueue.cfgByQueryGet
--
-- @param 
--
-- @description This function gets the configuration of the class queue based on
-- the given query. 
--
-- @return OK or ERROR
-- @return errCode 
-- @return queue 
--

function qos.classQueue.cfgByQueryGet(query)
    local queue = nil

    if (query == nil) then
        return "ERROR", "QOS_CQUEUE_ERR_INVALID_ARG"
    end        

    queue = db.getRowWhere("qosClassQueue", query, false)
    if (queue == nil) then
        return "ERROR", "QOS_CQUEUE_ERR_ENOENT"
    end        
                
    return "OK","STATUS_OK", queue
end

-------------------------------------------------------------------------------
-- @name  qos.classQueue.get
--
-- @param 
--
-- @description This function gets the configuration of the class queue with
-- the given ID. The ID can be QueueKey or QueueName
--
-- @return queue or nil
--

function qos.classQueue.get(ID)
    local queue = nil
    local query = nil
    local status = "ERROR"
    local errCode = ""

    if (ID == nil) then
        return nil
    end
            
    query = "QueueKey='" .. ID .. "' or " ..
            "QueueName='" .. ID .. "'"

    status, errCode, queue = qos.classQueue.cfgByQueryGet(query)
    if (status ~= "OK") then
        return nil
    end

    return queue                
end

-------------------------------------------------------------------------------
-- @name  qos.classQueue.maxIDGet
--
-- @param 
--
-- @description This function gets the max class queue key
--
-- @return queue or nil
--

function qos.classQueue.maxIDGet()
    local QueueKey =  db.getMaxVal("qosClassQueue", "QueueKey")
    return QueueKey
end    

-------------------------------------------------------------------------------
-- @name  qos.classQueue.inUse
--
-- @param QueueKey queue ID
--
-- @description This function checks if a given class queue is in use
--
-- @return true if in use else false

function qos.classQueue.inUse (QueueKey)
    local ruleTbl = nil
    local query = "QueueKey=" .. QueueKey

    local status, errCode, ruleTbl = qos.rule.tableGet(query)
    if (#ruleTbl == 0) then
        return false
    end        
    
    return true
end
