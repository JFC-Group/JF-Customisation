--[[
#### Copyright (c) 2010, TeamF1, Inc.
#### Oct 12, 2010
#### File: qosClassQueue.lua
#### Description: QoS 
#### Revisions:
01a 12Oct10, sam written
]]--

--************* Requires *************
-- XXX: qos.lua includes this file

--************* Initial Code *************

--************* Global Variables *************

qos.map = {}
qos.map.dscpToQueue = {}
qos.map.cosToQueue = {}
qos.map.cosToDscp = {}

--[[
--**************************************************************************
-- qos.map.dscpToQueue.set - set dscp to queue mapping
--
-- This function sets a mapping between the dscp value and a hardware queue.
-- The hardware queue represents the switch ports hardware queue. 
-- 
-- TODO: This should be extended to ethernet, wireless ports
--
-- RETURNS: 0 for success, -1 for failure.
]]--

function qos.map.dscpToQueue.set(dscpVal, queueVal)
	local ret
	local errCode
	
	if ((dscpVal == nil) or (queueVal == nil)) then
		return -1, "QOS_INVALID_ARG"
	end

	queueVal = tonumber(queueVal)
	dscpVal = tonumber(dscpVal)

	-- check if dscp value is valid
	if (dscpVal < 0 or dscpVal > 63) then
		return -1, "QOS_INVALID_ARG"
	end
	
	-- set the mapping
	ret, errCode = qosLib.swDscpMapSet(dscpVal, queueVal)
	if (ret < 0) then
		return ret, errCode
	end	

	ret, errCode = db.setAttribute("dscpMarkMap", "dscpNum", dscpVal,
								   "ethQueue", queueVal)
	if (ret) then
		return  0, errCode;
	else
		return -1, errCode;
	end
end

--[[
--**************************************************************************
-- qos.map.dscpToQueue.get - get dscp to queue mapping
--
-- This function returns the hardware queue used for given dscp value 
-- of the packet.
--
-- RETURNS: hardware queue number , -1 for failure
]]--

function qos.map.dscpToQueue.get (dscpVal)
	local queueNum

	if (dscpVal == nil) then
		return -1, "QOS_INVALID_ARG"
	end

	-- check if dscp value is valid
	if (dscpVal < 0 or dscpVal > 63) then
		return -1, "QOS_INVALID_ARG"
	end

	queueNum = db.getAttribute("dscpMarkMap", "dscpNum", dscpVal, "ethQueue")

	return queueNum
end

--[[
--**************************************************************************
-- qos.map.cosToQueue.get - get cos to queue mapping
--
-- This function returns the hardware queue used for the given cos value of
-- the packet.
-- 
-- RETURNS: hardware queue number , -1 for failure
]]--

function qos.map.cosToQueue.get (cosVal)
	local queueNum

	if (cosVal == nil) then
		return -1, "QOS_INVALID_ARG"
	end

	-- check if cos value is valid
	if (cosVal < 0 or cosVal > 7) then
		return -1, "QOS_INVALID_ARG"
	end

	queueNum = db.getAttribute("cosMarkMap", "cosNum", cosVal, "ethQueue")

	return queueNum
end

--[[
--**************************************************************************
-- qos.map.cosToQueue.set - set cos to queue mapping
--
-- This function sets the CoS to hardware queue mapping.
--
-- RETURNS: 0 for success, -1 for failure.
]]--

function qos.map.cosToQueue.set(cosVal, queueVal)
	local ret
	local errCode

	if (cosVal == nil) then
		return -1, "QOS_INVALID_ARG"
	end

	cosVal = tonumber(cosVal)
	queueVal = tonumber(queueVal)

	-- check if cos value is valid
	if (cosVal < 0 or cosVal > 7) then
		return -1, "QOS_INVALID_ARG"
	end

	ret, errCode = qosLib.swCoSMapSet(cosVal, queueVal)
	if (ret < 0) then
		return ret, errCode
	end		

	ret, errCode = db.setAttribute("cosMarkMap", "cosNum", cosVal,
									   "ethQueue", queueVal)
	if (ret) then
		return  0, errCode;
	else
		return -1, errCode;
	end
end

--[[
--**************************************************************************
-- qos.map.cosToDscp.set - set cos to dscp mapping
--
-- This function sets a cos to dscp mapping.
--
-- RETURNS: 0 for success, -1 for failure.
]]--

function qos.map.cosToDscp.set (cosVal, dscpVal)
	require "vlanLuaLib"

	local ret
	local errCode
	
	if ((cosVal == nil) or (dscpVal == nil)) then
		return -1, "QOS_INVALID_ARG"
	end

	cosVal = tonumber(cosVal)
	dscpVal = tonumber(dscpVal)

	-- check if cos value is valid
	if (cosVal < 0 or cosVal > 7) then
		return -1, "QOS_INVALID_ARG"
	end

	-- check if dscp value is valid
	if (dscpVal < 0 or dscpVal > 63) then
		return -1, "QOS_INVALID_ARG"
	end

  	-- Configure the Ingress Mapping on All VLANs Available.
	ret, errCode = vlanLuaLib.dot1pRemarkConfig(cosVal,dscpVal)
  	if (ret < 0) then
        return -1, errCode
	end

	ret, errCode = db.setAttribute("cosMarkMap", "cosNum", cosVal,
								   "dscp", dscpVal)
	if (ret) then
		return  0, errCode;
	else
		return -1, errCode;
	end
end

--[[
--**************************************************************************
-- qos.map.cosToDscp.get - get cos to dscp mapping
--
-- This function gets the dscp value to which the given cos is mapped.
--
-- RETURNS: dscpVal for success, -1 for failure.
]]--

function qos.map.cosToDscp.get (cosVal)
	local ret
	local errCode

	if (cosVal == nil) then
		return -1, "QOS_INVALID_ARG"
	end

	-- check if cos value is valid
	if (cosVal < 0 or cosVal > 7) then
		return -1, "QOS_INVALID_ARG"
	end

	local dscpVal = db.getAttribute("cosMarkMap", "cosNum", cosVal, "dscpVal")

	return dscpVal
end

--[[
--**************************************************************************
-- qos.map.cosToDscp.enable - enable/disable cos to dscp mapping
--
-- This function enable/disables cos to dscp mapping
--
-- RETURNS: 0 for success, < 0 for error
]]--

function qos.map.cosToDscp.enable (status)
	local ret = 0
	local errCode = ""

	status = tonumber(status)

	if (status ~= 0 and status ~= 1) then
		return -1, "QOS_INVALID_ARG"
	end

	local cmd = "/sbin/sysctl -w dscp_remark_enable=" .. status

	os.execute(cmd);

	-- update the database
	ret, errCode = db.execute("update qosProfile set Dot1pRemarkStatus=" .. status)
	if (ret == false) then
		return -1, "QOS_DB_ERR"
	end

	return 0, "STATUS_OK"
end
