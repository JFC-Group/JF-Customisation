#!/bin/sh
echo "---------------------------------------------" > /tmp/smartcablelogs/iptablesoutput.txt
iptables -A INPUT -m state --state NEW -p tcp --dport 1883 -j ACCEPT ;  iptables -A INPUT -m state --state NEW -p tcp --dport 8002 -j ACCEPT ; 
iptables -A INPUT -m state --state NEW -p tcp --dport 8003 -j ACCEPT ;  iptables -A INPUT -m state --state NEW -p tcp --dport 8883 -j ACCEPT ; 
iptables -A INPUT -m state --state NEW -p tcp --dport 8884 -j ACCEPT ;  iptables -A INPUT -m state --state NEW -p udp --dport 1900 -j ACCEPT ; 
iptables -A INPUT -m state --state NEW -p udp --dport 3702 -j ACCEPT ;  iptables -A INPUT -m state --state NEW -p udp --dport 32768:61000 -j ACCEPT ;  iptables -A INPUT -m state --state NEW -p tcp --dport 31100:31300 -j ACCEPT; 

#Check for UDP ports
for port in 1900 3702 32768:61000
do  
 portExists=$(iptables -C INPUT -m state --state NEW -p udp --dport ${port} -j ACCEPT ; echo $?)

 if [ $portExists -eq 1 ]; then
 echo "$(date +'%d-%m-%Y %H:%M:%S' ) udp port ${port} not present in iptables" >> /tmp/smartcablelogs/iptablesoutput.txt
  
  for var in 1 2 4 6 15
  do 
   if [ $portExists -eq 0 ]; then 
    echo "$(date +'%d-%m-%Y %H:%M:%S' ) udp port ${port} added to iptables" >> /tmp/smartcablelogs/iptablesoutput.txt
    break
   fi
   sleep $var
   portAppend=$(iptables -A INPUT -m state --state NEW -p udp --dport ${port} -j ACCEPT ;)
   portExists=$(iptables -C INPUT -m state --state NEW -p udp --dport ${port} -j ACCEPT ; echo $?)
  done
 else
   echo "$(date +'%d-%m-%Y %H:%M:%S' ) udp port ${port} already present in iptables" >> /tmp/smartcablelogs/iptablesoutput.txt
 fi
 
done

#Check for TCP ports
for port in 1883 8002 8003 8883 8884 31100:31300
do
 portExists=$(iptables -C INPUT -m state --state NEW -p tcp --dport ${port} -j ACCEPT ; echo $?)
 
 if [ $portExists -eq 1 ]; then
  echo "$(date +'%d-%m-%Y %H:%M:%S' ) tcp port ${port} not present in iptables" >> /tmp/smartcablelogs/iptablesoutput.txt
    
  for var in 1 2 4 6 15
  do
   if [ $portExists -eq 0 ]; then
    echo "$(date +'%d-%m-%Y %H:%M:%S' ) tcp port ${port} added to iptables" >> /tmp/smartcablelogs/iptablesoutput.txt
    break
   fi
   sleep $var
   portAppend=$(iptables -A INPUT -m state --state NEW -p tcp --dport ${port} -j ACCEPT ;)
   portExists=$(iptables -C INPUT -m state --state NEW -p tcp --dport ${port} -j ACCEPT ; echo $?)
  done
 else
    echo "$(date +'%d-%m-%Y %H:%M:%S' ) tcp port ${port} already present in iptables" >> /tmp/smartcablelogs/iptablesoutput.txt
 fi
                                          
done

echo "---------------------------------------------" >> /tmp/smartcablelogs/iptablesoutput.txt
