/* SQL init */

/* alarm controller */
INSERT OR REPLACE INTO Objects VALUES(45,"controller","AlarmController");
INSERT OR REPLACE INTO Services (ObjID, Name, Type) VALUES(45,"AlarmControllerService","AlarmControllerService");
INSERT OR REPLACE INTO Properties (ServiceID, Name, Value) SELECT Service.ID, "Notifications" , "true" FROM Services Service WHERE ObjID = 45 AND Name = "AlarmControllerService";
