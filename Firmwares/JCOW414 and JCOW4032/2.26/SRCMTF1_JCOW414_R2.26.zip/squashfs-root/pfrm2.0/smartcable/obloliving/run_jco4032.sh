#!/bin/sh
if [ $(dirname $0) = '.' ]; then CURRENT_SPATH=$(pwd); else CURRENT_SPATH=$(dirname $0); fi
chmod +x $CURRENT_SPATH/copyData.sh
$CURRENT_SPATH/copyData.sh

case "$1" in
start)
  #chmod +x /flash/obloliving/bin/*
  echo -n "Start service...\n"
  #export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/flash/obloliving/OBLO_LIBS
  export PATH=$CURRENT_SPATH/bin:$PATH
  export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$CURRENT_SPATH/OBLO_LIBS



  #/flash/obloliving/bin/systemManager
  systemManager
  sleep 2

  ps | /bin/grep -v grep | /bin/grep systemManager > /dev/null 2>&1
  _procesCheckStarted=$?
  if [ ${_procesCheckStarted} -eq 0 ]; then
    echo -n "Already running systemManager\n"
    exit
  fi
  # start process check loop in background
  (
    while true; do
      ps | /bin/grep -v grep | /bin/grep systemManager > /dev/null 2>&1
      _result=$?
      if [ ${_result} -ne 0 ]; then
        echo -n "Detected systemManager invalid stop. Restarting application\n"
        killall -9 smartcableONTApp
	killall -9 oblomb
        _omb_result=$?
        if [ ${_omb_result} -ne 0 ]; then
          killall -9 oblomb
        fi

        killall -9 oblomanager
        _ohm_result=$?
        if [ ${_ohm_result} -ne 0 ]; then
          killall -9 oblomanager
        fi
        #/flash/obloliving/bin/systemManager
	systemManager
      fi
      sleep 2
    done
  ) &
;;
stop)
  echo -n "Stop service\n"
  killall -9 systemManager
  killall -9 oblomb
  killall -9 oblomanager
;;
restart)
  $0 stop
  sleep 2
  $0 start
;;
*)
echo "Usage: $0 {start|stop|restart}"
exit 1
;;
esac
