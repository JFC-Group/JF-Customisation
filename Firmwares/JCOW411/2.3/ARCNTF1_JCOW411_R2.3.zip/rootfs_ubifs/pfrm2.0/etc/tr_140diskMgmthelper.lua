--[[
#### 
#### File: tr_140diskMgmthelper.lua
#### Description: 
#### TR-140 handlers for remove/store disk folders Info Parameter.
####
]]--

 -- require
    require "teamf1lualib/util"
    require "teamf1lualib/db"

-- This function store / remove the folders info of the partition.
function storeFolderInfo (sharePath,vfsPath,pUserName,shareName,flag)
   
    -- db conect
    db.connect ("/tmp/system.db")


    if (flag == "0") then
        -- delete case
        db.deleteRow("diskMgmtFolderInfo", "diskName", shareName)
    else
        -- add case
        local tmpSharePath = {}
        local partId = ''
        local diskId = ''

        -- get the partId and diskId
        tmpSharePath = util.split(sharePath,'/')

        for k,v in pairs (tmpSharePath) do
            if(k == 4) then
                partId = "/dev/" .. v
                diskId = "/dev/" .. string.sub(v,0,3)
            end
        end

        -- get the folder Info
        local pathCmd = vfsPath .."/" .. pUserName .. "/" .. shareName
        local lsCmd = "ls -p ".. pathCmd .. " |grep '/$'"

        local pipe = io.popen(lsCmd) 
        local folderInfo = nil
        folderInfo = pipe:read("*all")
        pipe:close()
        
        -- get the folder name
        local folderName = {}
        folderName = util.split(folderInfo,'\n')
        for k,v in pairs (folderName) do
            v = string.gsub (v,"/", "")
            if (v == "" or v == nil) then
            else
                -- construct the input table
                local folderInfoTbl = {}
                folderInfoTbl["diskMgmtFolderInfo.partId"] = partId
                folderInfoTbl["diskMgmtFolderInfo.diskId"] = diskId
                folderInfoTbl["diskMgmtFolderInfo.diskName"] = shareName
                folderInfoTbl["diskMgmtFolderInfo.folderPath"] = pathCmd .. "/" .. v
                folderInfoTbl["diskMgmtFolderInfo.folderEnable"] = 1
                folderInfoTbl["diskMgmtFolderInfo.UserAccess"] = 11
             
                -- insert into database
                db.insert ("diskMgmtFolderInfo",folderInfoTbl)
             end
         end
     end

     --return value
     return 1
end

if (util.fileExists ("/pfrm2.0/BRCMJCO300") == true or util.fileExists ("/pfrm2.0/HW_JCO4032") or util.fileExists ("/pfrm2.0/HW_JCOW407")  or util.fileExists ("/pfrm2.0/HW_JCOW402") == true) then
    --Calling this function by passing arguments.
    storeFolderInfo (arg[1], arg[2], arg[3] , arg[4], arg[5])
end
