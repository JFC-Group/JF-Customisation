BEGIN;
create table dbUpdateRegisterTbl (
    compName text NOT NULL,
    stopIfError integer NOT NULL,
    waitForMe   integer NOT NULL,
    tableName text NOT NULL,
    rowIndex  integer,
    onUpdate integer NOT NULL,
    onAdd   integer NOT NULL,
    onDelete integer NOT NULL
); 

-- table used by evtDsptch to make sure all writes are done before
-- notifying backend components
-- a write to this table causes sqlite to complete the earlier write

create table sqliteLock
(
lock integer
);

create table ifDevEventTbl   
(
   ifName text NOT NULL,        -- LogicalIfName or Physical Interface name. 'ALL' for wildcard
   event    integer NOT NULL,   -- event type
   compName text NOT NULL,      -- Listening component ID
   userArg text NOT NULL,       -- Callback binary and args ..
   userId  text NOT NULL,         
   PRIMARY KEY(userId, event)                                                
);
CREATE TABLE tableValidation
(
	tableName  text NOT NULL,
	function  text NOT NULL,
	 PRIMARY KEY (tableName)
)
;



CREATE TABLE tableDefaults
(
	tableName  text NOT NULL,
	columnName  text NOT NULL,
	defValue  text ,
	minValue  text ,
	maxValue  text ,
	PRIMARY KEY (tableName,columnName)
)
;

CREATE TABLE system
(
	name  text NOT NULL,
    domain text,
	description text,
	firmwareVer  text,
	firmwarePri  text,
	firmwareSec  text,
	vendor		 text,
    sysContact text,
    sysLoc  text,
	PRIMARY KEY (name)
)
;
create TABLE systemConfig
(
    configMajorVer  integer,
    configMinorVer  integer,
    checksum        integer
);

create table dbUpdateRegisterProgram
(
    progName text NOT NULL,
    stopIfError integer NOT NULL,
    waitForMe   integer NOT NULL,
    tableName text NOT NULL,
    rowIndex  integer,
    onUpdate integer NOT NULL,
    onAdd   integer NOT NULL,
    onDelete integer NOT NULL
);

CREATE TABLE saveTables
(
	tableName  text NOT NULL,
	PRIMARY KEY (tableName)
)
;

CREATE TABLE environment
(
	name  text NOT NULL,
	value  text,
	PRIMARY KEY (name)
)
;

CREATE TABLE tableMaxRecords
    (
    tableName text PRIMARY KEY,
    maxRecords integer NOT NULL
    );

CREATE TABLE stringsMap
(
    stringId  text NOT NULL,
    en_US     text NOT NULL,
    PRIMARY KEY (stringId)
)
;

CREATE TABLE serviceRegistry
(
    service         text NOT NULL,
    restartProg     text,
    startProg       text,
    stopProg        text,
    PRIMARY KEY (service)
);

CREATE TABLE oidRecord
    (
    OID             integer,    -- next instance id to be used
    tableName       text        -- table name
    
    );

CREATE TABLE unauthorizedUsage
	(
	status			boolean
	);

create table LanReservedSubnets
   (
   IPRouter      text      -- IP address, subnet mask is 255.255.255.0
   );

CREATE TABLE voipSetting
    (
	DialingTimeout integer, 
	WatchDogEnable boolean,
	LogLevel integer,
	WirelessLogs integer, 
	WirelessEvtLogs integer, 
	VoipVdspLogs integer,
	VoipFxsLogs integer,
	VoipLecLogs integer,
	VoipAdamGdiLogs integer
    );

insert into oidRecord values (1, "route");

insert into stringsMap values ("NONE","");
insert into stringsMap values ("STATUS_OK","Operation succeeded");
insert into stringsMap values ("ADMIN_REQD","Administrator privileges are required");
insert into stringsMap values ("PASSWORD_CHANGED","User credentials are updated successfully. <br> Please re-login!");
insert into stringsMap values ("ERR_EMPTY_VALUE_ENTERED","Field cannot be left blank");
insert into stringsMap values ("ERR_STRING_LENGTH","Length of the string entered is incorrect");
insert into stringsMap values ("ERR_START_IP_GREATER","Start IP cannot be greater than end IP");
insert into stringsMap values ("ERR_PASSWORD_EMPTY","Password field cannot be left empty");
insert into stringsMap values ("ERR_PASSWORD_MISMATCH","Passwords entered do not match");
insert into stringsMap values ("INVALID_VALUE_ERR_ALPHABET","Only Numbers allowed for the field");
insert into stringsMap values ("INVALID_VALUE_ERR_SPCLCHAR","Special Characters not allowed for the field");
insert into stringsMap values ("ERR_START_GREATER_THAN_END","Start value cannot be greater than end value");
insert into stringsMap values ("ERR_BOUND_INVALID_RANGE","Value entered does not fall in allowed range");
insert into stringsMap values ("INVALID_SUBNET_EMPTY_OCTET_1","Octet 1 of subnet field cannot be left blank");
insert into stringsMap values ("INVALID_SUBNET_EMPTY_OCTET_2","Octet 2 of subnet field cannot be left blank");
insert into stringsMap values ("INVALID_SUBNET_EMPTY_OCTET_3","Octet 3 of subnet field cannot be left blank");
insert into stringsMap values ("INVALID_SUBNET_EMPTY_OCTET_4","Octet 4 of subnet field cannot be left blank");
insert into stringsMap values ("ERR_INVALIDSUBNET_OCTET_1","Invalid value entered for subnet octet 1");
insert into stringsMap values ("ERR_INVALIDSUBNET_OCTET_2","Invalid value entered for subnet octet 2");
insert into stringsMap values ("ERR_INVALIDSUBNET_OCTET_3","Invalid value entered for subnet octet 3");
insert into stringsMap values ("ERR_INVALIDSUBNET_OCTET_4","Invalid value entered for subnet octet 4");
insert into stringsMap values ("INVALID_SUBNET_ERR1_OCTET_1","Subnet Octet1 should be 255");
insert into stringsMap values ("INVALID_SUBNET_ERR2_OCTET_4","Subnet Octet4 should not be 254");
insert into stringsMap values ("INVALID_SUBNET_ERR3_OCTET_4","Subnet Octet4 should not be 255");
insert into stringsMap values ("INVALID_SUBNET_ERR4_OCTET_3","Subnet Octet 3 should be 0");
insert into stringsMap values ("INVALID_SUBNET_ERR5_OCTET_4","Subnet Octet 4 should be 0");
insert into stringsMap values ("INVALID_SUBNET_ERR6_OCTET_2","Subnet Octet 2 should be 255 for class B");
insert into stringsMap values ("INVALID_SUBNET_ERR7_OCTET_2","Subnet Octet 2 should be 255 for class C");
insert into stringsMap values ("INVALID_SUBNET_ERR8_OCTET_3","Subnet Octet 3 should be 255 for class C");
insert into stringsMap values ("INVALID_IPCLASS_ERR9","IP Class not valid");
insert into stringsMap values ("INVALID_IP_CHECK_NUMBER_OCTETS","Number of octets in a IPv4 address should be 4");
insert into stringsMap values ("INVALID_IP_EMPTY_OCTET_1","Octet 1 of IP address cannot be left blank");
insert into stringsMap values ("INVALID_IP_EMPTY_OCTET_2","Octet 2 of IP address cannot be left blank");
insert into stringsMap values ("INVALID_IP_EMPTY_OCTET_3","Octet 3 of IP address cannot be left blank");
insert into stringsMap values ("INVALID_IP_EMPTY_OCTET_4","Octet 4 of IP address cannot be left blank");
insert into stringsMap values ("INVALID_IP_OCTET_1","Enter a value between 1 to 223 for octet 1");
insert into stringsMap values ("INVALID_IP_OCTET_2","Enter a value between 1 to 255 for octet 2");
insert into stringsMap values ("INVALID_IP_OCTET_3","Enter a value between 1 to 255 for octet 3");
insert into stringsMap values ("INVALID_IP_OCTET_4","Enter a value between 1 to 254 for octet 4");
insert into stringsMap values ("INVALID_MAC_ERR_SPCLCHAR","Special Characters are not allowed in MAC field");
insert into stringsMap values ("ERR_MAC_EMPTY_VALUE_OCTET_1","Octet 1 of MAC field cannot be left empty");
insert into stringsMap values ("ERR_MAC_EMPTY_VALUE_OCTET_2","Octet 2 of MAC field cannot be left empty");
insert into stringsMap values ("ERR_MAC_EMPTY_VALUE_OCTET_3","Octet 3 of MAC field cannot be left empty");
insert into stringsMap values ("ERR_MAC_EMPTY_VALUE_OCTET_4","Octet 4 of MAC field cannot be left empty");
insert into stringsMap values ("ERR_MAC_EMPTY_VALUE_OCTET_5","Octet 5 of MAC field cannot be left empty");
insert into stringsMap values ("ERR_MAC_EMPTY_VALUE_OCTET_6","Octet 6 of MAC field cannot be left empty");
insert into stringsMap values ("ERR_TWOCHAR_OCTET_1","Only 2 characters allowed in octet 1");
insert into stringsMap values ("ERR_TWOCHAR_OCTET_2","Only 2 characters allowed in octet 2");
insert into stringsMap values ("ERR_TWOCHAR_OCTET_3","Only 2 characters allowed in octet 3");
insert into stringsMap values ("ERR_TWOCHAR_OCTET_4","Only 2 characters allowed in octet 4");
insert into stringsMap values ("ERR_TWOCHAR_OCTET_5","Only 2 characters allowed in octet 5");
insert into stringsMap values ("ERR_TWOCHAR_OCTET_6","Only 2 characters allowed in octet 6");
insert into stringsMap values ("ERR_ONLYHEX_OCTET_1","Only a-f and 0-9 allowed in octet 1");
insert into stringsMap values ("ERR_ONLYHEX_OCTET_2","Only a-f and 0-9 allowed in octet 2");
insert into stringsMap values ("ERR_ONLYHEX_OCTET_3","Only a-f and 0-9 allowed in octet 3");
insert into stringsMap values ("ERR_ONLYHEX_OCTET_4","Only a-f and 0-9 allowed in octet 4");
insert into stringsMap values ("ERR_ONLYHEX_OCTET_5","Only a-f and 0-9 allowed in octet 5");
insert into stringsMap values ("ERR_ONLYHEX_OCTET_6","Only a-f and 0-9 allowed in octet 6");
insert into stringsMap values ("ERR_LEASETIME_EMPTY_VALUE","Lease Time field cannot be left empty");
insert into stringsMap values ("INVALID_LEASETIME_ERR_SPCLCHAR","Special chracter not allowed in lease time field");
insert into stringsMap values ("INVALID_LEASETIME_ERR_ALPHA","Alphabet not allowed in Lease time field");
insert into stringsMap values ("ERR_LEASETIME_INVALIDRANGEVALUE","Lease time entered is outside allowed range");
insert into stringsMap values ("ERR_MTU_EMPTY_VALUE","MTU field cannot be left empty");
insert into stringsMap values ("INVALID_MTUSIZE_ERR_ALPHA","Alphabet not allowed in MTU field");
insert into stringsMap values ("INVALID_MTUSIZE_ERR_SPCLCHAR","Special chracter not allowed in MTU field");
insert into stringsMap values ("ERR_MTUSIZE_INVALIDRANGEVALUE","MTU value entered falls outside allowed range");
insert into stringsMap values ("ERR_PORT_EMPTY_VALUE","Port field cannot be left empty");
insert into stringsMap values ("INVALID_PORT1_ERR_ALPHA","Alphabet not allowed in port field");
insert into stringsMap values ("INVALID_PORT1_ERR_SPCLCHAR","Special character not allowed in port1 field");
insert into stringsMap values ("INVALID_PORT2_ERR_ALPHA","Alphabet not allowed in port2 field");
insert into stringsMap values ("INVALID_PORT2_ERR_SPCLCHAR","Special character not allowed in port2 field");
insert into stringsMap values ("ERR_PORT1_GREATERTHAN_PORT2","Port1 entered is greater than Port2");
insert into stringsMap values ("ERR_IDLETIME_EMPTY_VALUE","Idle time field cannot be left empty");
insert into stringsMap values ("INVALID_IDLETIME_ERR_ALPHA","Alphabet not allowed in idle time field");
insert into stringsMap values ("INVALID_IDLETIME_ERR_SPCLCHAR","Special character not allowed in idle time field");
insert into stringsMap values ("ERR_IDLETIME_INVALIDRANGEVALUE","Idle time entered is outside allowed limits");
insert into stringsMap values ("ERR_ADV_INV_EMPTY_VALUE","Empty field not allowed");
insert into stringsMap values ("INVALID_ADV_INV_ERR_ALPHA","Alphabet not allowed");
insert into stringsMap values ("INVALID_ADVINTERVAL_ERR_SPCLCHAR","Special character not allowed");
insert into stringsMap values ("ERR_ADV_INV_INVALIDRANGEVALUE","Advertisement interval entered falls ouside alowed range");
insert into stringsMap values ("INVALID_ROUTERLIFETIME_ERR_ALPHA","Alphabet not allowed in lifetime field");
insert into stringsMap values ("INVALID_ROUTERLIFETIME_ERR_SPCLCHAR","Special character not allowed in life time field");
insert into stringsMap values ("ERR_ROUTERLIFETIME_INVALIDRANGEVALUE","Life time entered falls ouside alowed range");
insert into stringsMap values ("INVALID_IDLETIMEOUT_ERR_ALPHA","Alphabet not allowed in idle time out field");
insert into stringsMap values ("INVALID_IDLETIMEOUT_ERR_SPCLCHAR","Special character not allowed in idle timeout field");
insert into stringsMap values ("ERR_PRESHAREKEY_EMPTY_VALUE","Pre-Shared field cannot be left empty"); 
insert into stringsMap values ("ERR_PRESHAREKEY_INVALID_KEY_LEN","Please enter key with length 8-49 characters");
insert into stringsMap values ("INVALID_MAXQUERRYTIME_ERR_ALPHA","Alphabets not allowed in querry time field"); 
insert into stringsMap values ("INVALID_MAXQUERRYTIME_ERR_SPCLCHAR","Special Character not allowed in querry time field");
insert into stringsMap values ("ERR_MAXQUERRYTIME_INVALIDRANGEVALUE","Query time entered falls outside range");
insert into stringsMap values ("INVALID_ROBVARIABLE_ERR_ALPHA","Alphabets not allowed in robustness field"); 
insert into stringsMap values ("INVALID_ROBVARIABLE_ERR_SPCLCHAR","Special character not allowed in robustness field");
insert into stringsMap values ("ERR_ROBVARIABLE_INVALIDRANGEVALUE","Enter a value between 2 to 99 for robustness field");
insert into stringsMap values ("INVALID_QUERRYINV_ERR_ALPHA","Alphabets not allowed in querry interval field");
insert into stringsMap values ("INVALID_QUERRYINV_ERR_SPCLCHAR","Special character not allowed in querry interval field");
insert into stringsMap values ("ERR_QUERRYINV_INVALIDRANGEVALUE","enter a value between 100-99999 for query interval");
insert into stringsMap values ("INVALID_DETPERIOD_ERR_ALPHA","Alphabet not allowed in detection period field"); 
insert into stringsMap values ("INVALID_DETPERIOD_ERR_SPCLCHAR","Special character not allowed in detection period field");
insert into stringsMap values ("ERR_DETPERIOD_INVALIDRANGEVALUE","enter value between 10-999 for detection period");
insert into stringsMap values ("INVALID_RECONNECT_ERR_ALPHA","Alphabet not allowed in reconnect field");
insert into stringsMap values ("INVALID_RECONNECT_ERR_SPCLCHAR","Special characeter not allowed in re-connect field");
insert into stringsMap values ("CHECK_NUMBER_OCTETS_IPV6","Check the number of octect in ipV6 address field");
insert into stringsMap values ("CHECK_COLON_POSITION_IPV6","Check colon position in ipv6 address"); 
insert into stringsMap values ("INVALID_IPV6ADDR_CHAR","Only hex character allowed in ipv6 address");
insert into stringsMap values ("INVALID_IPV6ADDR_CHECK_COLONS","Check colon position in ipv6 address");
insert into stringsMap values ("CHECK_OCTET_IPV4_TYPE","IPV4 address string can occur only once");
insert into stringsMap values ("INVALID_IPV4ADRR_NOT_AT_END","IPV4 string can be present only at the end");
insert into stringsMap values ("INVALID_IPV6ADDR_CHECK_OCTECT_POSITION","Ckeck octet position");
insert into stringsMap values ("INVALID_IPV6ADDR_CHECK_NUMBER_OCTETS","Check the number of octets present");
insert into stringsMap values ("INVALID_IPV6ADDR_CHECK_OCTET","Check the octet positons");
insert into stringsMap values ("FIRST_GREATER_THAN_SECOND_IP_V6","ipv6 start address greater than end address");
insert into stringsMap values ("BOTH_IP_EQUAL_V6","Error, both ipv6 address are equal");
insert into stringsMap values ("INVALID_PREFIX_LENGTH_ERR_ALPHA","Alphabet not allowed in prefix length field");
insert into stringsMap values ("INVALID_PREFIX_LENGTH_ERR_SPCLCHAR","Special character not allowed in prefix length field");
insert into stringsMap values ("ERR_PREFIX_LENGTH_INVALIDRANGEVALUE","Enter value between 1-127 for prefix length");
insert into stringsMap values ("INVALID_METRIC_ERR_ALPHA","Alphabet not allowed for metric field");
insert into stringsMap values ("INVALID_METRIC_ERR_SPCLCHAR","Special character not allowed in metric field"); 
insert into stringsMap values ("ERR_METRIC_INVALIDRANGEVALUE","enter value between 2-15 for metric field");
insert into stringsMap values ("INVALID_REBIND_TIME_ERR_ALPHA","Alphabet not allowed in rebind time field");
insert into stringsMap values ("INVALID_REBIND_TIME_ERR_SPCLCHAR","Special character not allowed in rebind time field");
insert into stringsMap values ("ERR_BIND_TIME_INVALIDRANGEVALUE","enter value between 0-604800 for rebind time");
insert into stringsMap values ("INVALID_FAILOVER_ERR_ALPHA","Alphabet not allowed in failover field");
insert into stringsMap values ("INVALID_FAILOVER_ERR_SPCLCHAR","Special character not allowed in failover field"); 
insert into stringsMap values ("ERR_FAILOVER_INVALIDRANGEVALUE","enter a value between 2-999 for failover"); 
insert into stringsMap values ("INVALID_RETRY_INV_ERR_ALPHA","Alphabet not allowed in retyr interval field");
insert into stringsMap values ("INVALID_RETRY_INV_ERR_SPCLCHAR","Special character not allowed in retrt interval field");
insert into stringsMap values ("ERR_RETRY_INV_INVALIDRANGEVALUE","enter a value between 30-999 for retry interval");
insert into stringsMap values ("INVALID_TIME_ERR_ALPHA","Alphabet not allowed in time field");
insert into stringsMap values ("INVALID_TIME_ERR_SPCLCHAR","Special character not allowed in time field");
insert into stringsMap values ("ERR_INVALID_HOUR_SETTING","enter value between 1-12 for hour field");
insert into stringsMap values ("ERR_INVALID_MINUTE_SETTING","enter value between 1-59 for minute field");
insert into stringsMap values ("ERR_INVALID_MONTH_SETTING","enter value between 1-12 for month field");
insert into stringsMap values ("ERR_INVALID_DATE_SETTING","enter value between 1-31 for cate field");
insert into stringsMap values ("ERR_INVALID_SECOND_SETTING","enter value between 1-59 for second field");
insert into stringsMap values ("INVALID_MD5_KEY_ERR_ALPHA","alphabet not allowed in MD5 key field");
insert into stringsMap values ("INVALID_MD5_KEY_ERR_SPCLCHAR","special characters not allowed in md5 key field");
insert into stringsMap values ("ERR_MD5KEY_INVALIDRANGEVALUE","enter value between 1-255 for md5 key field");
insert into stringsMap values ("ERR_SALIFE_EMPTY_VALUE","SA-LifeTime field empty");
insert into stringsMap values ("INVALID_SA_TIME_ERR_ALPHA","alphabet not allowed in sa-lifetime field");
insert into stringsMap values ("INVALID_SA_TIME_ERR_SPCLCHAR","Special character not allowed in sa-liftime field");
insert into stringsMap values ("ERR_SA_LIFE_TIME","SA-Lifteime value entered is out of range");
insert into stringsMap values ("ERR__VPN_KEY_EMPTY_VALUE","vpn key field cannot be empty");
insert into stringsMap values ("VPN_INCORRECT_KEY_LENGTH","VPN key length entered is out of range");
insert into stringsMap values ("INVALID_UPNP_INV_ERR_ALPHA","Alphabet not allowed in upnp interval field"); 
insert into stringsMap values ("INVALID_UPNP_INV_ERR_SPCLCHAR","Special character not allowed in interval field");
insert into stringsMap values ("ERR_UPNP_ADV_INV_INVALIDRANGEVALUE","enter value between 1-86400");
insert into stringsMap values ("INVALID_AD_TIME_ERR_ALPHA","Alphabet not allowed in Adv time field");
insert into stringsMap values ("INVALID_AD_TIME_ERR_SPCLCHAR","Special character not allowed in adv time field");
insert into stringsMap values ("ERR_UPNP_ADV_TIME_INVALIDRANGEVALUE","enter a value between 1-255 for avd time field");
insert into stringsMap values ("INVALID_PROFILE_ERR_ALPHA","alphabet not allowed for field in profile page");
insert into stringsMap values ("INVALID_PROFILE_ERR_SPCLCHAR"," Special characters not allowed for field in profile page");
insert into stringsMap values ("ERR_INVALIDRANGEVALUE_WL","enter a value between 1-36000 for the field");
insert into stringsMap values ("INVALID_RADIUS_ERR_ALPHA","alphabet not allowed in radius field");
insert into stringsMap values ("INVALID_RADIUS_ERR_SPCLCHAR","special characters not allowed in radius field");
insert into stringsMap values ("ERR_INVALIDRANGEVALUE_RADIUS","enter a value between 1-999 for radius fields");
insert into stringsMap values ("ROW_ALREADY_EXSTS","The configuration entered already exists.");
insert into dbUpdateRegisterTbl values ("UMI_COMP_LOGGING",0,0,"logging", 0, 1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_LOGGING",0,0,"logConfig", 0, 1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_LOGGING",0,0,"compFacilityMap", 0, 1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_LOGGING",0,0,"sysLogInfo", 0, 1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_LOGGING",0,0,"logEventEmailConfig", 0, 1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_LOGGING",0,0,"emailLogs", 0, 1,1,1);

CREATE TABLE logging
(
    maxEventLogRows  integer NOT NULL,
    saveLogs    integer NOT NULL
);


CREATE TABLE logConfig
(
	facility  text NOT NULL,
    facilityId integer NOT NULL,
	emergency  integer NOT NULL,
	alert  integer NOT NULL,
	critical  integer NOT NULL,
	error  integer NOT NULL,
	warning  integer NOT NULL,
	notice  integer NOT NULL,
	information  integer NOT NULL,
	debug  integer NOT NULL,
	PRIMARY KEY (facility)
)
;

CREATE TABLE logEventEmailConfig
(
	facility  text NOT NULL,
    facilityId integer NOT NULL,
	emergency  integer NOT NULL,
	alert  integer NOT NULL,
	critical  integer NOT NULL,
	error  integer NOT NULL,
	warning  integer NOT NULL,
	notice  integer NOT NULL,
	information  integer NOT NULL,
	debug  integer NOT NULL,
	PRIMARY KEY (facilityId)
)
;

CREATE TABLE compFacilityMap
(
	component  text NOT NULL,
	facilityId  integer NOT NULL,
	PRIMARY KEY (component ,facilityId )
)
;


CREATE TABLE sysLogInfo
(
	serverName      text NOT NULL,      -- servername or ip
	serverPort      integer DEFAULT 514,
    facilityId      integer,            --Ex: kernel 0
    severity        integer,            --Ex: emergency 1
    Enable          integer,            -- 1- enable , 0- disable
    serverId        integer,             -- i th syslog server (0 to 7)
    uniqueID        text,
    LogicalIfName   text,
    selFacilityId   integer,
    selSeverity     text
)
;

CREATE TABLE VendorLogFile
(
	Name            text NOT NULL,      -- Name of the log file.
	MaximumSize     integer,            -- The maximum size of the log file in bytes
    Persistent      boolean             -- preserved across a device reboot.
)
;

CREATE TABLE VendorConfigFile
(
    Name                    text,       -- Name of the ascii file
    Version                 text,       -- Version of ascii file
    Description             text,       -- desciption
    UseForBackupRestore     boolean     -- used for backup and restore
)
;

insert into tableDefaults values("sysLogInfo","serverPort","514","","");
insert into tableDefaults values("sysLogInfo","facilityId","255","","");
insert into tableDefaults values("sysLogInfo","severity","0","","");
insert into tableDefaults values("sysLogInfo","Enable","1","0","1");
insert into tableDefaults values("sysLogInfo","serverId","0","0","7");

--local0 facility (wireless)
insert into compFacilityMap values ("UMI_COMP_UDOT11", 16);
insert into compFacilityMap values ("UMI_COMP_KDOT11", 16);
insert into compFacilityMap values ("UMI_COMP_PNAC", 16);
insert into compFacilityMap values ("UMI_COMP_PNAC_USR", 16);
insert into compFacilityMap values ("UMI_COMP_RAD", 16);
insert into compFacilityMap values ("UMI_COMP_EAP_RAD", 16);
insert into compFacilityMap values ("UMI_COMP_EAPAUTH", 16);
--local1 facility (UTM)
insert into compFacilityMap values ("UMI_COMP_IPS", 17);
insert into compFacilityMap values ("UMI_COMP_URLFILTER", 17);
insert into compFacilityMap values ("UMI_COMP_TM_PROTECTLINK", 17);
-- system facility
insert into compFacilityMap values ("UMI_COMP_LOGGING", 3);
insert into compFacilityMap values ("UMI_COMP_EVTDSPTCH", 3);
insert into compFacilityMap values ("UMI_COMP_PLATFORM", 3);
insert into compFacilityMap values ("UMI_COMP_REBOOT", 3);
insert into compFacilityMap values ("UMI_COMP_BRIDGE", 3);
insert into compFacilityMap values ("UMI_COMP_8021W_USR", 3);
-- kernel facility
insert into compFacilityMap values ("UMI_COMP_KERNEL", 0);

CREATE TABLE emailLogs
(
    mailLogs integer,
    entryName text NOT NULL,
    logId   text
)
;

insert into ifDevEventTbl values ("ALL", 10, "UMI_COMP_LOGGING", "NULL", "logging");
insert into ifDevEventTbl values ("ALL", 11, "UMI_COMP_LOGGING", "NULL", "logging");

insert into tableDefaults values("emailLogs","entryName","LOGGING","","");

insert into stringsMap values ("LOGGING_SYSLOG_CONFIG_FAILED","Syslog configuration failed");
insert into stringsMap values ("LOGGING_CONFIG_FAILED","Logging configuration failed");
insert into stringsMap values ("VENDOR_LOG_FILE_CONFIG_FAILED","Vendor Log file configuration failed");
insert into stringsMap values ("LOGGING_EMAILLOGS_CONFIG_FAILED","Email logs configuration failed");
insert into stringsMap values ("LOGGING_SMTP_CONFIG_FAILED","SMTP server configuration Failed");
insert into stringsMap values ("LOGGING_CRONTAB_CONFIG_FAILED","CRONTAB configuration failed");
insert into stringsMap values ("LOGGING_EMAIL_PASSED","Mail sent and logs cleared");
insert into stringsMap values ("LOGGING_EMAIL_FAILED","Unable to send mail");
insert into stringsMap values ("LOGGING_EMAIL_DISABLED","Email logs currently disabled. Please enable and try again.");
CREATE TABLE networkInterface
    (
    interfaceName   text    NOT NULL,
    LogicalIfName   text    NOT NULL,
    networkName     text            ,   -- Network Name
    networkId       integer         ,   -- Network ID (Integer suffix of the LogicalIfName. This is not the vlan ID)
    enable          integer         , 
    ifType          text            ,   -- (bridge, vlan, switch, ethernet, radio, vap, usb, )
    mtu             integer         ,
    mac             text            ,
    ifGroupId       integer         ,
    ifMark          integer         ,
    connectionType  text            ,  --  (routed/bridged/switched/unconfigured)
    zoneType        text            ,  --  (secure/insecure/public or lan/wan/dmz)
    PRIMARY KEY (LogicalIfName)
    );

CREATE TABLE interfaceStatsParams
    (
    ifType  text NOT NULL,
    refreshInterval integer NOT NULL,
    autoRefreshFlag integer NOT NULL
    );

CREATE TABLE  ipConf 
(
IPv4Capable  integer  NOT NULL,
IPv4Enable    integer  NOT NULL,
IPv6Capable  integer  NOT NULL,
IPv6Enable    integer  NOT NULL 
);

insert into dbUpdateRegisterTbl values ("UMI_COMP_IFDEV", 0, 0, "networkInterface", 0, 1, 1, 1);

insert into ifDevEventTbl values ("ALL", 0, "UMI_COMP_IFDEV", "NULL", "ifdev");
insert into ifDevEventTbl values ("ALL", 1, "UMI_COMP_IFDEV", "NULL", "ifdev");
insert into ifDevEventTbl values ("ALL", 2, "UMI_COMP_IFDEV", "NULL", "ifdev");
insert into ifDevEventTbl values ("ALL", 3, "UMI_COMP_IFDEV", "NULL", "ifdev");
insert into ifDevEventTbl values ("ALL", 4, "UMI_COMP_IFDEV", "NULL", "ifdev");
insert into ifDevEventTbl values ("ALL", 14, "UMI_COMP_IFDEV", "NULL", "ifdev");

insert into tableDefaults values ("ifUsageReportConfig","maxSnaps","24","1","99");
insert into stringsMap values ("IFDEV_CONFIG_FAILED","Interface configuration failed");
insert into stringsMap values ("IFDEV_USAGE_CONFIG_FAILED","Usage reports configuration failed");
insert into stringsMap values ("IFDEV_RESET_STATS_FAILED","Reset of interface statistics failed");
insert into stringsMap values ("IP_ADDRESS_IN_USE","IP Address already in use");
insert into stringsMap values ("IP_MODE_SET_FAILED","IP Mode Configuration Failed");
insert into stringsMap values ("AUTOREFRESH_CONFIG_FAILED","Auto refresh Configuration Failed");
insert into stringsMap values ("NET_ERR_CONN_RUNNING_DISABLE_FIRST","Network is enabled so disable it first and then delete");
insert into stringsMap values ("RESERVED_IPV6_ADDRESS1","Cannot configure Reserved IPv6 Address");
insert into stringsMap values ("MULTICAST_IPV6_ADDRESS","Cannot configure Multicast IPv6 Address");
insert into stringsMap values ("IFDEV_ERR_QUERY_FAILED","Query for the configured network failed.");
create table NimfConf
    (
    OID                      integer          , -- OID
    LogicalIfName            text     NOT NULL, -- Network Logical Name
    AddressFamily            integer  NOT NULL, -- address family 
    ConnectionKey            integer  NOT NULL, -- connection ID. Identify multiple IP connections for a network.
                                                -- Example: IPv4 Aliases, Multiple PPPoE Sessions, Multiple IPv6 Addresses.
    Enable                   integer  NOT NULL, -- connection status like enable(1)/disable(0)
    ConnectionType           text     NOT NULL, -- connection type like dhcp,pppoe
	WarnDisconnectDelay		 integer 		  , -- Time in seconds the Status remains in the pending
												-- disconnect state before transitioning to
												-- disconnecting state to drop the connection.
    ConfigureDNS             integer          ,                                       
    ConfigureRoute           integer          ,
    DefaultConnection        integer          ,  
    PRIMARY KEY(LogicalIfName, AddressFamily, ConnectionKey)                                                
    );


create table ipAddressTable
(
    LogicalIfName text NOT NULL,        -- hardware interface name
    addressFamily integer NOT NULL,     -- Address family
    ConnectionKey integer NOT NULL,     -- Connection Key
    isStatic boolean,                   -- static assigned or dynamic
    ipAddress text,                     -- IP address
    ipDstAddres text,                   -- End point for P-to-P
    ipv6PrefixLen integer,              -- IPv6 prefix length
    subnetMask text,                    -- subnet mask
    FOREIGN KEY (LogicalIfName) REFERENCES networkInterface(LogicalIfName)
);

create table ipv6PrefixTable
(
    LogicalIfName           text        ,        -- hardware interface name
    addressFamily           integer     ,        -- Address family
    ConnectionKey           integer     ,        -- Connection Key
    isStatic                boolean     ,        -- static assigned or dynamic
    ipAddress               text        ,        -- IP address
    ipDstAddres             text        ,        -- End point for P-to-P
    ipv6PrefixLen           integer     ,        -- IPv6 prefix length
    subnetMask              text        ,        -- subnet mask
    hostDuid                text        ,        -- IAPD client identifier
    delegationPrefix        text        ,        -- IAPD prefix address 
    delegationPrefixLen     text        ,        -- IAPD prefix length
    startAddress            text        ,        -- IANA Address Pool start address
    endAddress              text        ,        -- IANA Address Pool end address   
    prefixLength            integer     ,        -- IANA prefix length   
    prefixType              text                 -- prefix type
);

create table resolverConfig
(
    LogicalIfName    text    NOT NULL,  -- WAN1, WAN2, LAN
    addressFamily    integer NOT NULL,  -- Address family
    ConnectionKey    integer NOT NULL,  -- Connection Key
    nameserver1      text            ,  -- DNS nameserver 1 
    nameserver2      text            ,  -- DNS nameserver 2 
    PRIMARY KEY (LogicalIfName, addressFamily, ConnectionKey),
    FOREIGN KEY (LogicalIfName) REFERENCES networkInterface(LogicalIfName)
);

create table  defaultRouters
(
  LogicalIfName    text    NOT NULL,    -- WAN1, WAN2, LAN  
  addressFamily    integer NOT NULL,    -- Address family   
  ConnectionKey    integer NOT NULL,    -- Connection Key
  RouteTbl         integer         ,    -- route table
  nextHopGateway   text            ,    -- Next hop gateway
  interfaceName    text            ,    -- for interface route
  PRIMARY KEY (LogicalIfName, addressFamily, ConnectionKey),
  FOREIGN KEY (LogicalIfName) REFERENCES networkInterface(LogicalIfName)
);

-- WanMode - table for storing WAN mode configuration.
create table WanMode
(
    OID                      integer,           -- OID
    Wanmode                  integer  NOT NULL, -- wan mode (dedicated, autorollover or load balancing)
    AddressFamily            integer  NOT NULL, -- address family
    DedicatedLogicalIfName   text     NOT NULL, -- nimf id of dedicated WAN
    FailoverPriLogicalIfName text     NOT NULL, -- from where to fail over
    FailoverSecLogicalIfName text     NOT NULL, -- where to fail over
    FailureDetectionMeth     integer  NOT NULL, -- detection method
    RetryTime                integer  NOT NULL, -- time to retry
    RetryAttempts            integer  NOT NULL, -- number of attempts to retry
    -- add newer entries here

    FOREIGN KEY (DedicatedLogicalIfName) REFERENCES networkInterface (LogicalIfName),
    FOREIGN KEY (FailoverPriLogicalIfName) REFERENCES networkInterface (LogicalIfName),
    FOREIGN KEY (FailoverSecLogicalIfName) REFERENCES networkInterface (LogicalIfName)
    );

-- table for storing gpon info
create table gpon
(
	status	boolean,
	trEnable	boolean,
	vlanStatus	boolean,
	vlanID	integer, 
	vlanPriority	integer
);

insert into dbUpdateRegisterTbl values ("UMI_COMP_NIMF", 0, 0, "NimfConf", 0, 1, 1, 1);

insert into ifDevEventTbl values ("ALL", 15, "UMI_COMP_NIMF", "NULL", "nimf");
insert into ifDevEventTbl values ("ALL", 16, "UMI_COMP_NIMF", "NULL", "nimf");

insert into stringsMap values ("NIMF_CONN_STATE_INIT","Initialising connection");
insert into stringsMap values ("NIMF_CONN_STATE_SETUP","Setting up connection");
insert into stringsMap values ("NIMF_CONN_STATE_CONNECTED","Connected");
insert into stringsMap values ("NIMF_CONN_STATE_TEARDOWN","Stopping connection");
insert into stringsMap values ("NIMF_CONN_STATE_STOPPED","Connection stopped");
insert into stringsMap values ("NIMF_CONN_STATE_STANDBY","Connection not ready");
insert into stringsMap values ("NIMF_CONN_STATE_FAIL","Connection failed");
insert into stringsMap values ("NIMF_CONN_STATE_WAIT","Connection stopped");

-- DB table for Device.DNS.Client.Server TR mapping
create table dnsClientServer 
(
    LogicalIfName    text    NOT NULL,  -- WAN1, WAN2, LAN
    addressFamily    integer NOT NULL   -- Address family
);
-- SQL table for ifStatic back-end component.

-- ifStatic table
CREATE TABLE ifStatic
    (
    OID                      integer,           -- OID
    LogicalIfName            text     NOT NULL, -- interface names like 'lan1', 'wan2', etc.
    AddressFamily            integer  NOT NULL,  -- address family.
    ConnectionKey            integer  NOT NULL,
    StaticIp                 text     NOT NULL, -- ip which we want to assign
    NetMask                  text     NOT NULL, -- net mask for the above IP
    PrefixLength             integer          , -- address family.
    Gateway                  text     NOT NULL, -- gateway address
    PrimaryDns               text,              -- if we want to specify our DNS
    SecondaryDns             text,              -- if we want to specify our DNS

    PRIMARY KEY (LogicalIfName, AddressFamily, ConnectionKey)
    );

create table hostTbl
    (
    IpAddr      text NOT NULL,      -- IP Address
    Cname       text NOT NULL,      -- Canonical Host Name
    PRIMARY KEY (Cname)
    );

insert into stringsMap values ("IP_SUBNET_INVALID", "Invalid IP Subnet");
insert into stringsMap values ("IP_ADDRESS_INVALID", "Invalid IP Address");
insert into stringsMap values ("IP_ADDRESS_CONFLICT", "IP Address conflict in the system");
insert into stringsMap values ("IPADDR_NOT_IN_LAN_SUBNET", "IP Address is not in Lan subnet");
insert into stringsMap values ("HOST_WITH_SAME_IP_ALREADY_EXIST", "Same ip Address host already exists");
CREATE TABLE LanHosts
    (
    LogicalIfName           text, 
	IPAddress				text,
	IPv6Address				text,
	AddressSource			text,
	IPv6AddressSource		text,
    LeaseStarts             text,    
    LeaseEnds               text,
	MACAddress				text NOT NULL,
	Layer2Interface			text,
	HostName				text,
	InterfaceType			text,
	Active					text
	);

insert into ifDevEventTbl values ("ALL", 15, "UMI_COMP_NSCAND", "NULL", "nscand");
insert into ifDevEventTbl values ("ALL", 16, "UMI_COMP_NSCAND", "NULL", "nscand");    
CREATE TABLE cert
(
    name text,                 -- user identifier
	subjectName  text NOT NULL,
	issuerName   text NOT NULL,
	expiryTime   text NOT NULL,	
	serialNumber text NOT NULL,-- The cert serial number	
	format	     text,         -- the format of the certificate data; 
                               -- for future use	
	certType     text NOT NULL,-- cert type: "ca" = root/CA certificate, 
                               --            "self"=self certificate
	certData     text NOT NULL,-- Certificate data
    PRIMARY KEY (subjectName)
)
;

insert into dbUpdateRegisterTbl values ("UMI_COMP_PLATFORM",1,1,"cert", 
                                         0, 1,1,1);
CREATE TABLE x509SelfCertReq
(
    requestName text NOT NULL,
    subjectName text NOT NULL,
    hashAlgo integer,
    signatureAlgo integer,
    signatureKeyLength integer,
    ipAddress text,
    domainName text,
    emailAddress text,
    selfCertData text,
    selfKeyData text,
    appType text,
    requestStatus integer,
    PRIMARY KEY (requestName)
);

CREATE TABLE x509DbUpdateFlag
(
    dbUpdateFlag integer
);

insert into dbUpdateRegisterTbl values ("UMI_COMP_PLATFORM",1,1, 
                                        "x509SelfCertReq", 0, 1,1,1);

insert into stringsMap values ("X509_INVALID_CA","Can't Upload Invalid Trusted Certificate"); 
insert into stringsMap values ("X509_CA_ADD_SUCCESS","Added Trusted Certificate"); 
insert into stringsMap values ("X509_CA_ADD_FAILURE","Cannot Add Trusted Certificate"); 
insert into stringsMap values ("X509_CA_DEL_SUCCESS","Selected Trusted CAs Deleted"); 
insert into stringsMap values ("X509_CA_DEL_FAILURE","Cannot Delete Trusted CAs"); 
insert into stringsMap values ("X509_SELF_GEN_FAILURE","Generate Self Certificate Request Failed");
insert into stringsMap values ("X509_SELF_DEL_SUCCESS","Selected Self Certificates Deleted");
insert into stringsMap values ("X509_SELF_DEL_FAILURE","Cannot Delete Self Certificates");
insert into stringsMap values ("X509_SELF_ADD_SUCCESS","Added Active Self Certificate");
insert into stringsMap values ("X509_SELF_ADD_FAILURE","Cannot Add Active Self Certificate");
insert into stringsMap values ("X509_INVALID_SELF","Can't Upload Invalid Self Certificate"); 

CREATE TABLE ntp
(
   timezone  integer NOT NULL,
   enabled  integer NOT NULL,
   autoDaylight  integer NOT NULL,
   useDefServers  integer NOT NULL,
   server1  text NOT NULL,
   server2  text NOT NULL,
   dhcpNtpServer1  text NOT NULL,
   dhcpNtpServer2  text NOT NULL,
   reSyncNtpVal integer NOT NULL,
   networkMode integer	NOT NULL,		
   LogicalIfName text	NOT NULL		
)
;

CREATE TABLE ntpDefServers
    (
    serverName text NOT NULL
    )
;

insert into dbUpdateRegisterTbl values ("UMI_COMP_NTP",1,1,"ntp", 0, 1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_NTP",1,1,"ntpDefServers", 0, 1,1,1);

insert into stringsMap values ("TIME_STATUS_NTP_FAILED","NTP configuration failed");
insert into stringsMap values ("TIME_STATUS_TIMEDATE_FAILED","Time/Date configuration Failed");
CREATE TABLE tr69Config
    (
	tr69Status	integer,
	URL			text,
	Username	text,	
	Password	text,
    serialUsername text,
    serialPassword text,
    ACSPasswordGeneration boolean,
        PeriodicInformEnable   boolean, 
	STUNEnable	text,
	STUNServerAddress	text,
	STUNUsername	text,
	STUNPassword	text,
	ConnectionRequestUsername	text,	
	ConnectionRequestPassword	text,
	CACertPath		text,
	ClientCertPath	text,
	Passphrase		text,
	ProvisioningCode text,
	PortBase		 integer,
    LogicalIfName    text,
    InformInterval   integer,
    PeriodicInformTime   integer,
    DefaultActiveNotificationThrottle   integer,
    CWMPRetryMinimumWaitInterval   integer,
    CWMPRetryIntervalMultiplier   integer,
	STUNServerPort   integer,
    STUNMaximumKeepAlivePeriod   integer,
    STUNMinimumKeepAlivePeriod   integer,    
    UpgradesManaged     boolean,
    CRSURLList     text,
    TableUpdate   integer -- 1 - username update
                          -- 2 - password update
                          -- 0  - no update
	);
CREATE TABLE fdmEventsTbl
    (
     TargetFileName text,
     Version text,
     Description text,
     DateApplied text,
    PRIMARY KEY (TargetFileName)
    );

CREATE TABLE ACSAlarmsFaults
    (
        Alarms                 boolean,
        Faults                 boolean,
        NumberInternetRetries  integer,
        uplinkDataRate         integer,
        downlinkDataRate       integer
    );

CREATE TABLE AlarmsFaultsEvents
    (
        AlarmList              text,
        FaultList              text
    );

CREATE TABLE ACSAlarms
    (
        Enable                  boolean,    -- if enabled, will set/reset alarm
        AlarmEnable             boolean,    -- will create Instance for the row only if AlarmEnable is enabled
        AlarmFile               text,       -- creates file with AlarmFile name if Enable=1
        UpperLimit              text,       -- upper limit for the alarm
        UpperLimitFile          text,       -- creates file with UpperLimit value
        LowerLimit              text,       -- lower limit for the alarm
        LowerLimitFile          text        -- creates file with LowerLimit value
    );

CREATE TABLE ACSFaults
    (
        Enable                  boolean,    -- if enabled, will set/reset fault
        FaultEnable             boolean,    -- will create Instance for the row only if FaultEnable is enabled
        FaultFile               text,       -- creates file with FaultFile name if Enable=1
        UpperLimit              text,       -- upper limit for the fault
        UpperLimitFile          text,       -- creates file with UpperLimit value
        LowerLimit              text,       -- lower limit for the fault
        LowerLimitFile          text        -- creates file with LowerLimit value
    );

insert into stringsMap values ("TR69_INVALID_ACS_URL","Invalid ACS URL");
insert into stringsMap values ("TR69_CONFIG_FAILED","TR-069 configuration failed");

insert into tableDefaults values ("tr69Config","serialUsername"," "," "," ");
insert into tableDefaults values ("tr69Config","serialPassword"," "," "," ");
insert into tableDefaults values ("tr69Config","ACSPasswordGeneration","1","1","1");
CREATE TABLE FirewallRules6
(
  _metadata text,                       -- metadata for internal use 
  OID integer NULL,
  RuleType text NOT NULL,               -- GUI (HIDDEN): SECURE_INSECURE
  Status integer NOT NULL,              -- GUI (HIDDEN)
  ServiceName text NULL,                -- GUI: Service
  Action text NULL,                     -- GUI: Action
  ScheduleName text NULL,               -- GUI: Select Schedule
  SourceAddressType integer NULL,       -- GUI: Src Users
  SourceAddressStart text NULL,         -- GUI: Start (Src Users)
  SourceAddressEnd text NULL,           -- GUI: Finish (Src Users)
  SourceAddressPrefixLength text NULL,  -- GUI: Prefix Length (Src Users)
  DestinationAddressType integer NULL,  -- GUI: Dest. Users
  DestinationAddressStart text NULL,    -- GUI: Start (Dest. Users)
  DestinationAddressEnd text NULL,      -- GUI: Finish (Dest. Users)
  DestinationAddressPrefixLength text NULL,  -- GUI: Prefix Length (Dest. Users)
  LogLevel integer NULL,                -- GUI: Log
  --Ipv6HeaderType  text NULL,
  --LogPrefix text NULL,     
  FromZoneType text NULL,
  ToZoneType text NULL,
  --ConnectionState text NULL,
  Protocol integer NULL,
  DestinationPortStart integer NULL,
  DestinationPortEnd integer NULL,
  --MultiPort text NULL,
  FromZoneNetwork text NULL,
  ToZoneNetwork text NULL,
  FOREIGN KEY (ScheduleName) REFERENCES Schedules (ScheduleName),
  FOREIGN KEY (ServiceName) REFERENCES Services (ServiceName)
)
;

CREATE TABLE firewallStatus
(
Status integer NOT NULL              -- GUI (HIDDEN)
)
;

CREATE TABLE FirewallRules
(
  _metadata text,                       -- metadata for internal use 
  OID integer NULL,
  RuleType text NOT NULL,               -- GUI (HIDDEN): SECURE_INSECURE
  Status integer NOT NULL,              -- GUI (HIDDEN)
  Description text,               

  ServiceName text NULL,                -- GUI: Service
  Protocol integer NULL,
  DestinationPortStart integer NULL,
  DestinationPortEnd integer NULL,
  TypeOfService integer NULL,           -- GUI: Qos. 


  Action text NULL,                     -- GUI: Action
  ScheduleName text NULL,               -- GUI: Select Schedule

  SourceAddressInvert integer NULL,
  SourceAddressType integer NULL,       -- GUI: LAN/DMZ Users
  SourceAddressStart text NULL,         -- GUI: Start (LAN/DMZ Users)
  SourceAddressEnd text NULL,           -- GUI: Finish (LAN/DMZ Users)

  DestinationAddressType integer NULL,  -- GUI: WAN/DMZ Users
  DestinationAddressInvert integer NULL,
  DestinationAddressStart text NULL,    -- GUI: Start (WAN/DMZ Users)
  DestinationAddressEnd text NULL,      -- GUI: Finish (WAN/DMZ Users)
  DestinationPublicInterface text NULL, -- GUI: WAN Destination IP Address
  DestinationPublicAddress text NULL,   -- GUI: WAN Destination IP Address


  SNATAddressType integer NULL,         -- GUI: NAT IP
  SNATAddress text NULL,                -- GUI: NAT IP Address
  SNATInterface text NULL,              -- GUI: NAT Single IP Is On
                                        -- this value is 'OTHER' for public ipAddr
  DNATAddress text NULL,                -- GUI: Send to LAN/DMZ Server
  DNATPortEnable integer NULL,          -- GUI: Translate to Port Number
  DNATPort integer NULL,                -- GUI: Translate to Port Number

  InputInterface text NULL,
  OutputInterface text NULL,
  FromZoneType text NULL,
  ToZoneType text NULL,
  FromZoneNetwork text NULL,
  ToZoneNetwork text NULL,

  MarkMatch integer NULL,
  LogLevel integer NULL,                -- GUI: Log

  FOREIGN KEY (ScheduleName) REFERENCES Schedules (ScheduleName),
  FOREIGN KEY (ServiceName) REFERENCES Services (ServiceName),
  FOREIGN KEY (DestinationPublicInterface) REFERENCES Zones (ZoneLogicalIfName),
  FOREIGN KEY (SNATInterface) REFERENCES Zones (ZoneLogicalIfName)
)
;
CREATE TABLE L2FirewallRules
(
    OID                        integer,
    --RuleName                   text,
    RuleType                   text NOT NULL,
    Status                     boolean NOT NULL,
    L2ServiceName              text NOT NULL,
    ServiceName                text,
    Action text NULL,                     -- GUI: Action
    ScheduleName               text,
    SourceAddressType          integer,       -- GUI: Src Users
    SourceAddressStart         text,         -- GUI: Start (Src Users)
    SourceAddressEnd           text,           -- GUI: Finish (Src. Users)
    DestinationAddressType     integer NULL,  -- GUI: Dest. Users
    DestinationAddressStart    text,    -- GUI: Start (Dest. Users)
    DestinationAddressEnd      text,      -- GUI: Finish (Dest. Users)
    SourceMACAddressType       integer,       -- GUI: Src Users
    SourceMACAddressStart      text,         -- GUI: Start (Src MACs)
    SourceMACAddressEnd        text,           -- GUI: Finish (Src. MACs)
    DestinationMACAddressType  integer NULL,  -- GUI: Dest. MACs
    DestinationMACAddressStart text,    -- GUI: Start (Dest. MACs)
    DestinationMACAddressEnd   text,      -- GUI: Finish (Dest. MACs)
    vlanId                     integer,
    dscp                       integer,
    classId                    text
    -- PRIMARY KEY (RuleName)
);

CREATE TABLE L2FirewallDefaultPolicy
(
    OID                        integer,
    defaultOutboundPolicy      boolean NOT NULL,
    defaultInboundPolicy       boolean NOT NULL
);  


insert into tableDefaults values ("FirewallRules","Status","1","0","2");
insert into tableDefaults values ("FirewallRules6","Status","1","0","1");
insert into tableDefaults values ("FirewallRules","ScheduleName","-","-","-");
insert into dbUpdateRegisterTbl values ('UMI_COMP_FIREWALL',1,1,'FirewallRules',0,1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_FIREWALL',1,1,'FirewallRules6',0,1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_FIREWALL',1,1,'L2FirewallRules',0,1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_FIREWALL',1,1,'L2FirewallDefaultPolicy',0,1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_FIREWALL',1,1,'firewallStatus',0,1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_FIREWALL',0,0,'ACSAlarmsFaults',0,0,1,0);
insert into dbUpdateRegisterTbl values ('UMI_COMP_FIREWALL',0,0,'ACSAlarms',0,0,1,0);
insert into dbUpdateRegisterTbl values ('UMI_COMP_FIREWALL',0,0,'ACSFaults',0,0,1,0);
insert into dbUpdateRegisterTbl values ('UMI_COMP_FIREWALL',0,0,'dot11InterfaceToBridge',0,0,1,0);
--insert into dbUpdateRegisterTbl values ('UMI_COMP_FIREWALL',1,1,'FullConeNat',0,1,1,1);
insert into stringsMap values ("FW_CONFIG_FAILED","Firewall Configuration Failed");
insert into stringsMap values ("CS_CONFIG_FAILED","Custom Service Configuration Failed");
insert into stringsMap values ("CF_CONFIG_FAILED","Content Filtering Configuration Failed");
insert into stringsMap values ("FW_DEFAULT_CONFIG_FAILED","Default Outbound Policy Configuration Failed");
insert into stringsMap values ("FW_RULES_ENABLED_FAILED","Selected Firewall Rule(s) Enabling Failed");
insert into stringsMap values ("FW_RULES_SERVICE_NOT_FOUND","Selected Firewall Rule(s) Service Not Avaialble");
insert into stringsMap values ("FW_RULES_ENABLED","Selected Firewall Rule(s) Enabled Successfully");
insert into stringsMap values ("FW_RULES_DISABLED_FAILED","Selected Firewall Rule(s) Disabling Failed");
insert into stringsMap values ("FW_RULES_DISABLED","Selected Firewall Rule(s) Disabled Successfully");
insert into stringsMap values ("FW_RULES_DELETE_FAILED","Selected Firewall Rule(s) Delete Failed");
insert into stringsMap values ("FW_RULES_DELETED","Selected Firewall Rule(s) Deleted Successfully");
insert into stringsMap values ("FW_IN_RULE_CONFIG_FAILED","Firewall LAN WAN Inbound Rule Configuration Failed");
insert into stringsMap values ("FW_OUT_RULE_CONFIG_FAILED","Firewall LAN WAN Outbound Rule Configuration Failed");
insert into stringsMap values ("CUSTOM_ACCOUNT_ALREADY_EXIST","Custom Account Already Exists");
insert into stringsMap values ("KEYWORD_ALREADY_EXIST","URL/Keyword Already Exists");
insert into stringsMap values ("INTERNAL_PORT_TYPE_AS_SINGLE","Please Select Internal Port Type As Single In Case Of Default And Multiport Service");
insert into stringsMap values ("INTERNAL_PORT_LENGTH_AND_CUSTOM_PORT_RANGE_DIFF_SHOULD_SAME","Internal Port Length And Custom Port Range Difference Should Be Same");
insert into stringsMap values ("HTTP_HTTPS_NOT_ALLOWED","HTTP and HTTPS are not allowed to be configured as keywords");
insert into stringsMap values ("INTERNAL_PORT_LENGTH_SHOULD_LESS_THAN_TEN","Internal Port Length should be configured less than ten");

CREATE TABLE Services
(
  OID integer NULL,
  ServiceName text NOT NULL,    -- name of the service
  Protocol integer NOT NULL,    -- TCP/UDP/ICMP 
  PortType integer NOT NULL,    -- 1 - Port Range/Single Port, 2 - Mutiple Ports
  MultiPort text NULL,          --for multiple ports option
  DestinationPortStart integer NULL,    -- first TCP/UDP port or ICMP type
  DestinationPortEnd integer NULL,      -- last TCP/UDP port
  TypeOfService integer NULL,           -- type of service
  IsDefault boolean NOT NULL,
  PRIMARY KEY (ServiceName)
)
;
insert into tableDefaults values ("Services","TypeOfService","0","0","16");
insert into stringsMap values ("SERVICE_IN_USE","Service Is In Use, Disable/Delete Firewall Rule First ");
insert into stringsMap values ("SERVICE_IN_USE_DEL_RULE","Service Is In Use, Delete Firewall Rule First ");
insert into stringsMap values ("SERVICE_DELETE_FAILED","Service(s) Delete Failed");
insert into stringsMap values ("SERVICE_DELETE_OK","Selected Service(s) Deleted Successfully");
insert into stringsMap values ("SERVICE_CONFIG_FAILED","Service Configuration Failed");

CREATE TABLE Schedules
(
  OID 		integer NULL,
  ScheduleName  text NOT NULL,
  DaysType	integer NULL,
  Days 		integer NULL,
  TimeType	integer NULL,	
  StartTimeHours integer NULL,
  StartTimeMins  integer NULL,
  StartTimeMeridian integer NULL,
  EndTimeHours 	integer NULL,
  EndTimeMins 	integer NULL,
  EndTimeMeridian integer NULL,
  PRIMARY KEY (ScheduleName)
)
;
insert into stringsMap values ("SCHEDULE_IN_USE","Schedule Is In Use, Delete dependent configuration first ");
insert into stringsMap values ("SCHEDULE_DELETE_FAILED","Schedule(s) Delete Failed");
insert into stringsMap values ("SCHEDULE_DELETE_OK","Selected Schedule(s) Deleted Successfully");
insert into stringsMap values ("SCHEDULE_CONFIG_FAILED","Schedule Configuration Failed");
insert into stringsMap values ("SCHEDULE_ALREADY_EXISTS", "Schedule with the same name already exists");
insert into stringsMap values ("SCHEDULE_TIME_OF_DAY_SET_ERROR", "Error setting time of day");
insert into stringsMap values ("SCHEDULE_DAY_OF_WEEK_SET_ERROR", "Error setting day of week");

CREATE TABLE AlgConf
    (
    OID   Integer     NULL, -- OID
    FtpStatus   Boolean, -- FTP ALG
    H323Status  Boolean NOT NULL, -- H323 ALG
    RtspStatus  Boolean NOT NULL, -- RTSP ALG
    TftpStatus  Boolean NOT NULL, -- TFTP ALG
    L2tpStatus  Boolean, -- L2TP ALG
    IcmpStatus  Boolean, -- ICMP ALG
    IpsecPtStatus Boolean NOT NULL -- IPsec Passthrough
    );
insert into dbUpdateRegisterTbl values ('UMI_COMP_FIREWALL',0,1,'AlgConf',0,1,1,1);

CREATE TABLE FullConeNat
(
    OID                integer NULL,
    localNetworkName   text    NOT NULL,
    addressType        integer NOT NULL, -- 0 - IP Address; 1 - MAC Address; 2 - Entire Network
    LanServerIp        text NULL,  
    LanServerMac       text NULL,  
    PRIMARY KEY (LanServerIp, LanServerMac)
)
;

insert into stringsMap values ("FULL_CONE_IP_NOT_IN_CONFIGURED_RANGE","Configured IP Address does not belong to the selected network");

insert into ifDevEventTbl values ('ALL',8, "UMI_COMP_FIREWALL" ,"NULL", "firewall");
insert into ifDevEventTbl values ('ALL',9, "UMI_COMP_FIREWALL" ,"NULL", "firewall");
insert into ifDevEventTbl values ('ALL',10, "UMI_COMP_FIREWALL","NULL", "firewall");
insert into ifDevEventTbl values ('ALL',11, "UMI_COMP_FIREWALL","NULL", "firewall");
insert into ifDevEventTbl values ('ALL',15, "UMI_COMP_FIREWALL","NULL", "firewall");
insert into ifDevEventTbl values ('ALL',16, "UMI_COMP_FIREWALL","NULL", "firewall");
insert into ifDevEventTbl values ('ALL',17, "UMI_COMP_FIREWALL","NULL", "firewall");

CREATE TABLE dmz
(
    OID                integer NULL,
    enableDmz          integer NOT NULL, 
    LogicalIfName      text NULL,  
    ipAddr             text NULL        -- DMZ Host IP 
)
;
insert into tableDefaults values ("dmz","enableDmz","0","0","1");
insert into dbUpdateRegisterTbl values ('UMI_COMP_FIREWALL',1,1,'dmz',0,1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_FIREWALL',1,1,'sshd',0,1,1,1);

CREATE TABLE dmz6
(
    OID                integer NULL,
    enableDmz          integer NOT NULL, 
    LogicalIfName      text NULL,  
    ipAddr             text NULL        -- DMZ Host IP 
)
;
insert into tableDefaults values ("dmz6","enableDmz","0","0","1");
insert into dbUpdateRegisterTbl values ('UMI_COMP_FIREWALL',1,1,'dmz6',0,1,1,1);

CREATE TABLE SecurityConfig
(
    OID             integer NULL,
    securityLevel 	integer NOT NULL, -- 0: max security
                                      -- 1: typical security
    LogicalIfName   text NULL,
    PRIMARY KEY (LogicalIfName)       -- primary key
)
;
--insert into dbUpdateRegisterTbl values ('UMI_COMP_FIREWALL',1,1,'SecurityConfig',0,1,1,1);

CREATE TABLE PortTriggering
(
  OID                integer NULL,
  RuleName           text NOT NULL,                 -- port triggering rule name
  Status         integer NOT NULL,                  -- enable/disable port trigger
  NetworkName        text    NOT NULL,              -- rules for specific LAN network
  Protocol           integer NOT NULL,              -- protocol name 1-tcp,2-udp
  OutgoingPortStart  integer NOT NULL,              -- outgoing start port
  OutgoingPortEnd    integer NOT NULL,              -- outgoing end port
  IncomingPortStart  integer NOT NULL,              -- incoming start port
  IncomingPortEnd    integer NOT NULL,              -- incoming end port  
  PRIMARY KEY (RuleName)                            -- primary key
)
;
--insert into dbUpdateRegisterTbl values ('UMI_COMP_FIREWALL',1,1,'PortTriggering',0,1,1,1);
insert into stringsMap values ("FW_PORT_TRG_CONFIG_FAILED","Port Triggering Rule Configuration Failed");
insert into stringsMap values ("FW_PORT_TRG_RULES_DELETED","Selected Rule(s) Deleted Successfully");
insert into stringsMap values ("FW_PORT_TRG_RULES_DELETE_FAILED","Rule(s) Delete Failed");

CREATE TABLE PortTriggerStatus
(
OID  integer NULL,
NetworkName text NOT NULL,                          -- LAN network 
IpAddr text NOT NULL,                               -- LAN host IP
OpenPortRangeStart integer NOT NULL,                -- incoming port : start
OpenPortRangeEnd integer NOT NULL,                  -- incoming port : end
TimeRemaining integer NOT NULL                      -- time remaining
)
;

CREATE TABLE SpecificAttackChecks
(
OID integer NULL,
SmurfAttack boolean NOT NULL,
PodAttack boolean NOT NULL,
FraggleAttack boolean NOT NULL,
DnsAmpAttack boolean NOT NULL,
ExternalPing boolean NOT NULL,
DropConnections boolean NOT NULL
)
;
insert into dbUpdateRegisterTbl values ('UMI_COMP_FIREWALL',1,1,'SpecificAttackChecks',0,1,1,1);

CREATE TABLE DosAttackChecks
(
OID integer NULL,
DosCheckStatus boolean NOT NULL,
UseDefSettings boolean NOT NULL,
TcpSynFloodEnable boolean NOT NULL,
TcpSynFlood integer NOT NULL,
UdpFloodEnable boolean NOT NULL,
UdpFlood integer NOT NULL,
IcmpEchoFloodEnable boolean NOT NULL,
IcmpEchoFlood integer NOT NULL,
IcmpNotificationFloodEnable boolean NOT NULL,
IcmpNotificationFlood integer NOT NULL,
StealthMode boolean NULL,
PingReplyOnLan boolean NULL,
BlockSpoof boolean NULL,
TcpFilterCheck boolean NULL
)
;
insert into dbUpdateRegisterTbl values ('UMI_COMP_FIREWALL',1,1,'DosAttackChecks',0,1,1,1);

CREATE TABLE IcsaSettings               --table for ICSA settings
(
 OID integer,
 BlockFragPkts         boolean,
 BlockMulticastPkts    boolean,
 BlockTcpRST           boolean,
 BlockFtpBounceAttack  boolean
)
;
insert into dbUpdateRegisterTbl values ("UMI_COMP_FIREWALL",0,1,"IcsaSettings",0,1,1,1);

insert into stringsMap values ("RESERVED_SRC_START_IPV6_ADDRESS","From address of Source Hosts is a reserved address");
insert into stringsMap values ("RESERVED_SRC_END_IPV6_ADDRESS","To address of Source Hosts is a reserved address");
insert into stringsMap values ("RESERVED_DST_START_IPV6_ADDRESS","From address of Destination Hosts is a reserved address");
insert into stringsMap values ("RESERVED_DST_END_IPV6_ADDRESS","To address of Destination Hosts is a reserved address");
insert into stringsMap values ("SRC_START_ADDR_NOT_IN_SUBNET_OF_FROM_NETWORK","From address of Source Hosts is not in the subnet of selected From Network.");
insert into stringsMap values ("SRC_END_ADDR_NOT_IN_SUBNET_OF_FROM_NETWORK","To address of Source Hosts is not in the subnet of selected From Network.");
insert into stringsMap values ("DST_START_ADDR_NOT_IN_SUBNET_OF_TO_NETWORK","From address of Destination Hosts is not in the subnet of selected To Network.");
insert into stringsMap values ("DST_END_ADDR_NOT_IN_SUBNET_OF_TO_NETWORK","To address of Destination Hosts is not in the subnet of selected To Network.");

CREATE TABLE routingMode    --table for Routing Mode configuration
(
 OID integer NULL,
 natSetting integer         --NAT setting
)
;
insert into dbUpdateRegisterTbl values ('UMI_COMP_FIREWALL',0,0,'routingMode',0,1,1,1);

CREATE TABLE macFilterConfig      --table for MAC filtering configuration
(
 OID integer NULL,               
 MACFilteringStatus boolean,    --MAC filtering status
 MACFilteringPolicy integer     --MAC filtering policy 
)
;
insert into dbUpdateRegisterTbl values ('UMI_COMP_FIREWALL',0,0,'macFilterConfig',0,1,1,1);

CREATE TABLE macFilterRules       --table for MAC filtering rules
(
 OID integer NULL,
 sourceMacAddr text NOT NULL,   --source MAC address to be filtered based on policy
 decription text NOT NULL,      --Rule or device description
 PRIMARY KEY (sourceMacAddr)
)
;
insert into dbUpdateRegisterTbl values ('UMI_COMP_FIREWALL',1,1,'macFilterRules',0,1,1,1);

CREATE TABLE clientMacConfig       --table for Client MAC filtering rules
(
 OID integer NULL,
 sourceMacAddr text NOT NULL,   --client source MAC address
 MACFilteringPolicy boolean,     --MAC filtering policy
 alias text,                    -- Alias for the host
 decription text,      --Rule or device description
 Deleted boolean,      --To identify DB add or delete event
 Notification integer, --To identify if 4 VALUE CHANGE event needs to be sent by CPE 
 LatestConnectedTimeStamp integer, 
 PRIMARY KEY (sourceMacAddr)
)
;
insert into tableDefaults values ("clientMacConfig","LatestConnectedTimeStamp","0","","");
insert into dbUpdateRegisterTbl values ('UMI_COMP_FIREWALL',0,0,'clientMacConfig',0,1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_FIREWALL',1,1,'LanHosts',0,1,1,1);
CREATE TABLE macDel       --table for Client MAC filtering rules
(
 OID integer NULL,
 sourceMacAddr text NOT NULL,   --client source MAC address
 PRIMARY KEY (sourceMacAddr)
)
;
CREATE TABLE casNotification
(
 OID integer NULL,
 sourceMacAddr text NOT NULL,   --client source MAC address
 Notification integer,          --to identify if 4 VALUE CHANGE event needs to be sent by CPE 
 PRIMARY KEY (sourceMacAddr)
)
;
CREATE TABLE ContentFiltering       --table for content filtering configuration
(
  OID    integer NULL,
  Status boolean NOT NULL
)
;
insert into dbUpdateRegisterTbl values ("UMI_COMP_FIREWALL",1,1,"ContentFiltering",0,1,1,1);

CREATE TABLE TrustedDomains         --table for approved Urls configuration
(
  OID    integer NULL, 
  KeywordToAllow  text NOT NULL,
  ScheduleName text NULL,
  PRIMARY KEY (KeywordToAllow)
)
;
insert into tableDefaults values ("TrustedDomains","ScheduleName","-","-","-");
insert into dbUpdateRegisterTbl values ("UMI_COMP_FIREWALL",1,1,"TrustedDomains",0,1,1,1);

CREATE TABLE BlockSites             --table for blocked sites/keyword configuration
(
  OID           integer NULL,
  KeywordToBlock    text NOT NULL,
  Status boolean NOT NULL,
  ScheduleName text NULL,
  PRIMARY KEY (KeywordToBlock)
)
;
insert into tableDefaults values ("BlockSites","ScheduleName","-","-","-");
insert into dbUpdateRegisterTbl values ("UMI_COMP_FIREWALL",1,1,"BlockSites",0,1,1,1);

CREATE TABLE defaultPolicy          --table for Default policy configuration
(
 OID integer NULL,               
 defaultIpv4FwPolicy boolean NOT NULL   --Default IPv4 firewall policy 
)
;
insert into dbUpdateRegisterTbl values ("UMI_COMP_FIREWALL",1,1,"defaultPolicy",0,1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_FIREWALL",1,1,"CaptivePortalSession",0,1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_FIREWALL",1,1,"CaptivePortal",0,1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_FIREWALL",1,1,"CaptivePortalVlan",0,1,1,1);

CREATE TABLE conntrackAction          --table for Default policy configuration
(
 OID integer NULL,               
 flushConntrack boolean NOT NULL   -- 1: flush the conntrack table 0: no action required
)
;
insert into dbUpdateRegisterTbl values ("UMI_COMP_FIREWALL",1,1,"conntrackAction",0,1,1,1);

-- BWMon table
CREATE TABLE BwMon          
(
 OID integer NULL,               
 enable boolean NOT NULL    
);

-- BWMonStat table
CREATE TABLE BwMonStat
(
    OID   Integer     NULL, -- OID
    LogicalIfName     text NOT NULL,
    AccName              text NOT NULL,
    AppName              text NOT NULL,
    Counter              text NOT NULL,    
    PRIMARY KEY (LogicalIfName, AppName, AccName)
);

-- BWMonCustom table
CREATE TABLE BwMonCustom
(
    OID   Integer     NULL, -- OID
    LogicalIfName     text NOT NULL,
    AccName              text NOT NULL,
    accType              integer,
    ipAddr               text NULL,
    macAddr              text NULL,    
    PRIMARY KEY (LogicalIfName, AccName)
);

CREATE TABLE p2pSessionLimit
(
OID                     integer,
p2pSessionLimitStatus   boolean,
p2pSessionLimit         integer
);
insert into dbUpdateRegisterTbl values ("UMI_COMP_FIREWALL",1,1,"BwMon",0,1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_FIREWALL",1,1,"BwMonCustom",0,1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_FIREWALL",0,1,"p2pSessionLimit",0,1,1,1);

CREATE TABLE WebAccessCtrl
(
    OID     Integer     NULL, -- OID
    enable  boolean     NOT NULL
);
insert into dbUpdateRegisterTbl values ("UMI_COMP_FIREWALL",1,1,"WebAccessCtrl",0,1,1,1);

CREATE TABLE PktCountEnable
(
     OID     Integer     NULL, -- OID
    enable  boolean     NOT NULL
);
insert into dbUpdateRegisterTbl values ("UMI_COMP_FIREWALL",1,1,"PktCountEnable",0,1,1,1);

CREATE TABLE InterfaceInfo
(
    OID     Integer     NULL, -- OID
    interfaceName   text    NOT NULL,
    LogicalIfName   text    NOT NULL,
    networkName     text      -- Network Name
);
insert into dbUpdateRegisterTbl values ("UMI_COMP_FIREWALL",1,1,"InterfaceInfo",0,1,1,1);

CREATE TABLE FirewallLogs
(
OID                            integer NULL,
LANToWANAccept                 boolean NOT NULL,   --LAN to WAN Accept packets logs
LANToWANDrop                   boolean NOT NULL,   --LAN to WAN Drop packets logs
WANToLANAccept                 boolean NOT NULL,   --WAN to LAN accept packets logs		 
WANToLANDrop                   boolean NOT NULL,   --WAN to LAN Drop packets logs	 
UnicastTraffic                 boolean NOT NULL,   --All unicast traffic logs	 
BroadCastORMulticastTraffic    boolean NOT NULL,   --All Broadcast/mulitcast traffic logs
FtpLogs                        boolean NOT NULL,    --FTP Data logs
IcmpRedirectedLogs             boolean NOT NULL,
logInvalidPacket               boolean NOT NULL
)
;
insert into dbUpdateRegisterTbl values ("UMI_COMP_FIREWALL",0,1,"FirewallLogs",0,1,1,1);

CREATE TABLE FirewallLogs6
(
OID                            integer NULL,
LANToWANAccept                 boolean NOT NULL,   --LAN to WAN Accept packets logs
LANToWANDrop                   boolean NOT NULL,   --LAN to WAN Drop packets logs
WANToLANAccept                 boolean NOT NULL,   --WAN to LAN accept packets logs		 
WANToLANDrop                   boolean NOT NULL    --WAN to LAN Drop packets logs	 
)
;

insert into dbUpdateRegisterTbl values ("UMI_COMP_FIREWALL",0,1,"FirewallLogs6",0,1,1,1);

CREATE TABLE Eogre
(
jioPrivateNet integer NOT NULL,                -- Enable 
Enable integer NOT NULL,                -- Enable 
ipType integer NOT NULL,                -- IPv4 == 0 or IPv6 == 1 
TunnelKey   text    NOT NULL,           -- Tunnel Key
RemoteIP   text    NOT NULL,            -- RemoteIp of Other device
RemoteIP6   text    ,                   -- RemoteIpv6 of Other device
ModeOfOperation integer NOT NULL,       -- Mode of Operation (BridgeMode == 1 or WlanGateway == 2) 
vlanId integer                   ,      -- Vlan Id to be added on the packets passing through tunnel
dataRate integer ,                      -- The max accumulated data rate. By default we have no limit. 
EnableOffloadFallBack integer NOT NULL,  -- Enable Offload FallBack 
FallBackTime integer NOT NULL,           -- FallBack Time from second to primary in seconds
secEnable integer NOT NULL,                -- Enable 
secRemoteIP   text,            -- RemoteIp of Other device
secRemoteIP6   text            -- RemoteIp of Other device
)
;
insert into dbUpdateRegisterTbl values ("UMI_COMP_FIREWALL",0,1,"Eogre",0,1,1,1);

CREATE TABLE dot11ProfileDef
(
        profileName  text NOT NULL,
        ssid  text NOT NULL,
        broadcastSSID  integer NOT NULL,
        pskPassAscii  text ,
        pairwiseCiphers  text ,
        authMethods  text ,
        security  text NOT NULL
)
;
insert into dbUpdateRegisterTbl values ("UMI_COMP_FIREWALL",0,1,"dot11ProfileDef",0,1,1,1);

create table MacRuleBytes (
    mac text UNIQUE,
    ipv4Bytes integer,
    ipv6Bytes integer
);

CREATE table IpBasedQOS (
    ipAddr text UNIQUE
);

CREATE table DeviceAccess (
    Status boolean NOT NULL,
    MACAddress      text
);

insert into tableDefaults values ("DeviceAccess","Status","0","","");

insert into dbUpdateRegisterTbl values ("UMI_COMP_FIREWALL",0,1,"IpBasedQOS",0,1,1,1);

CREATE TABLE SystemStatistics
(
        OID integer ,

        CpuUsed 	integer NOT NULL,  /* CPU Total Usage */
        CpuIdle 	integer NOT NULL,  /* CPU idle */
        CpuUsedByUser 	integer NOT NULL,  /* CPU taken by user process */
        CpuUsedByKernel integer NOT NULL,  /* CPU taken by kernel process */
        CpuWaitingForIO integer NOT NULL,  /* Process waiting for IO operations*/

        MemoryFree  	integer NOT NULL,  /* Free Memory in the system */
        MemoryTotal 	integer NOT NULL,  /* Total memory of the system */
        MemoryUsed  	integer NOT NULL,  /* Used memory in the system */ 
        MemoryCached  	integer NOT NULL,  /* cached memory in the system */
        MemoryBuffers  	integer NOT NULL,   /* buffered memory */
		CpuTemp		 	text 	NOT NULL,   /*cpu temperature*/
		EnclosureTemp	integer NOT NULL    /*enclosure Temperature*/
)
;

create TABLE reboot 
(
    reboot integer NOT NULL, 
    rebootTime integer NOT NULL
);

create TABLE compDeinitHdlr
(
    compName    text,
    callback    text,
    stopIfError integer,
    waitForMe   integer
);

insert into reboot values (0,5);

insert into dbUpdateRegisterTbl values ("UMI_COMP_REBOOT",1,1,"reboot", 0, 1,1,1);
CREATE TABLE loginSession
(
	username  text NOT NULL,
	ipaddr  text NOT NULL,
	cookie  text NOT NULL,
	loginTime  text NOT NULL,
	lastAccessTime  text NOT NULL,
	loginState  text NOT NULL,
	loginMessage  text,
	PRIMARY KEY (ipaddr,cookie),
    FOREIGN KEY (username) REFERENCES users(username)
)
;

CREATE TABLE redirectPageInfo
	(
	    username     text NULL,
	    ipaddress    text NULL,
	    redirectpage text NULL 
	); 

insert into stringsMap values ("LOGIN_INVALID_PASSWORD","Invalid username or password");
insert into stringsMap values ("LOGIN_PERMISSION_DENIED","Login Permission Denied.");
insert into stringsMap values ("LOGIN_SESSION_EXPIRED","You have been logged out as a result of being inactive for 30 minutes.<br> Use the fields to login.");
insert into stringsMap values ("LOGIN_SESSION_TERMINATED","Your session has been terminated.");
insert into stringsMap values ("LOGIN_USER_ALREADY_LOGGED_IN","An Active Session already exists for the User");
insert into stringsMap values ("EXT_RADIUS_AUTH_FAILED","External radius authentication failed");
insert into stringsMap values ("LOGIN_INVALID_CREDENTIALS","Invalid credentials.");
insert into stringsMap values ("RADIUS_SERVER_CONF_FAILED","Radius sever configuration failed");
CREATE TABLE bridgePorts
(
	interfaceName   text NOT NULL,
    portEnabled     integer NOT NULL,
	bridgeInterface text NOT NULL,
    vlanEnabled     integer NOT NULL,
    vlanId          integer,
    trunk           integer,
    qosEnabled      integer,  -- if disabled : traffic gets mapped to 0 CoS
    qosIpAddrExt    integer,  -- ip-address based CoS mapping enable/disable
    portType        text,     -- Eg: vlan, vap, ethernet .. etc  
    PRIMARY KEY (interfaceName)
)
;

CREATE TABLE bridgeDscpTo8021pMapping
(
	interfaceName   text NOT NULL,
    defaultCos      integer,  
    dscp8021pMap0     integer,  -- if -1, indicates defaultCoS is to be used
    dscp8021pMap1     integer,  --    "" 
    dscp8021pMap2     integer,  --    "" 
    dscp8021pMap3     integer,  --    "" 
    dscp8021pMap4     integer,  --    "" 
    dscp8021pMap5     integer,  --    "" 
    dscp8021pMap6     integer,  --    "" 
    dscp8021pMap7     integer,  --    "" 
    dscp8021pMap8     integer,  --    "" 
    dscp8021pMap9     integer,  --    "" 
    dscp8021pMap10    integer,  --    "" 
    dscp8021pMap11    integer,  --    "" 
    dscp8021pMap12    integer,  --    "" 
    dscp8021pMap13    integer,  --    "" 
    dscp8021pMap14    integer,  --    "" 
    dscp8021pMap15    integer,  --    "" 
    dscp8021pMap16    integer,  --    "" 
    dscp8021pMap17    integer,  --    "" 
    dscp8021pMap18    integer,  --    "" 
    dscp8021pMap19    integer,  --    "" 
    dscp8021pMap20    integer,  --    "" 
    dscp8021pMap21    integer,  --    "" 
    dscp8021pMap22    integer,  --    "" 
    dscp8021pMap23    integer,  --    "" 
    dscp8021pMap24    integer,  --    "" 
    dscp8021pMap25    integer,  --    "" 
    dscp8021pMap26    integer,  --    "" 
    dscp8021pMap27    integer,  --    "" 
    dscp8021pMap28    integer,  --    "" 
    dscp8021pMap29    integer,  --    "" 
    dscp8021pMap30    integer,  --    "" 
    dscp8021pMap31    integer,  --    "" 
    dscp8021pMap32    integer,  --    "" 
    dscp8021pMap33    integer,  --    "" 
    dscp8021pMap34    integer,  --    "" 
    dscp8021pMap35    integer,  --    "" 
    dscp8021pMap36    integer,  --    "" 
    dscp8021pMap37    integer,  --    "" 
    dscp8021pMap38    integer,  --    "" 
    dscp8021pMap39    integer,  --    "" 
    dscp8021pMap40    integer,  --    "" 
    dscp8021pMap41    integer,  --    "" 
    dscp8021pMap42    integer,  --    "" 
    dscp8021pMap43    integer,  --    "" 
    dscp8021pMap44    integer,  --    "" 
    dscp8021pMap45    integer,  --    "" 
    dscp8021pMap46    integer,  --    "" 
    dscp8021pMap47    integer,  --    "" 
    dscp8021pMap48    integer,  --    "" 
    dscp8021pMap49    integer,  --    "" 
    dscp8021pMap50    integer,  --    "" 
    dscp8021pMap51    integer,  --    "" 
    dscp8021pMap52    integer,  --    "" 
    dscp8021pMap53    integer,  --    "" 
    dscp8021pMap54    integer,  --    "" 
    dscp8021pMap55    integer,  --    "" 
    dscp8021pMap56    integer,  --    "" 
    dscp8021pMap57    integer,  --    "" 
    dscp8021pMap58    integer,  --    "" 
    dscp8021pMap59    integer,  --    "" 
    dscp8021pMap60    integer,  --    "" 
    dscp8021pMap61    integer,  --    "" 
    dscp8021pMap62    integer,  --    "" 
    dscp8021pMap63    integer,  --    "" 
    PRIMARY KEY (interfaceName)
);

CREATE TABLE bridgeTable
(
	interfaceName   text NOT NULL,
	macAddress      text,    -- NOT USED
    LogicalIfName   text,
    igmpSnooping     integer,
    acsDisplayEnable integer,
    PRIMARY KEY (interfaceName)
)
;

CREATE TABLE bridgeModePorts
(
    Enable integer,
    InterfaceName text
)
;

-- bridgeIpAddrMgmt table
--
-- This table will hold all IP-Address specific vlan/CoS information.
--
-- Backend Values:
-- Field            GUI          Backend Value
-- IpProtocol      (n/a)         0/1/2/3 (TCP/UDP/ICMP/IGMP)

--
-- Cases to be considered:
-- 1) Ip-Address mapping will be applicable to ports which have the ip Address
--    based extension turned on.
-- 2) The entries will be sorted internally starting from the lowest range 
--    irrespective of the order specified in the table
-- 3) CoS mapping is applicaption specific and can be interpreted differently
--    based on the API that receives the packet.
--

CREATE TABLE bridgeIpAddrMgmt
(
    OID               integer   NULL,
    IpAddress         text      NOT NULL,      --  ipv4 address
    SubnetMask        text      NOT NULL,      --  subnet range to apply mapping
    IpProtocol        integer   NOT NULL,      --  map specific proto packets
    IpPortNumber      integer   NOT NULL,      --  TCP/UDP port number
    vlanId            integer   NOT NULL,      --  vlan id to map the subnet to 
    CoS               integer   NOT NULL,      --  class of service to apply
    PRIMARY KEY (IpAddress, SubnetMask, IpProtocol, IpPortNumber)
)
;

CREATE TABLE bridgeMode
(
	OID               integer   NULL,
	status            boolean   NOT NULL,
	portNumber        integer	NOT NULL,
	vlanID            integer	NOT NULL,
	lanIface          text      NOT NULL,
	wanIface          text      NOT NULL
)
;

CREATE TABLE bridgeModeVlan
(
	Enable            boolean    NOT NULL,
	vlanID            integer    NOT NULL,
	Name              text       NOT NULL
)
;

insert into stringsMap values ("BRIDGE_PORT_MAPPING_FAILED","Failed to configure Port Mapping");
insert into stringsMap values ("BRIDGE_PORT_MAPPING_VLAN_DISABLED","Failed to configure as requested VLAN is unavailable");
insert into stringsMap values ("BRIDGE_QOS_CONFIG_FAILED","Failed to configure QoS settings");

-- use defaultCos setting for dscp map if map is not available
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap0","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap1","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap2","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap3","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap4","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap5","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap6","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap7","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap8","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap9","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap10","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap11","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap12","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap13","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap14","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap15","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap16","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap17","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap18","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap19","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap20","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap21","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap22","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap23","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap24","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap25","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap26","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap27","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap28","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap29","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap30","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap31","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap32","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap33","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap34","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap35","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap36","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap37","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap38","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap39","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap40","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap41","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap42","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap43","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap44","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap45","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap46","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap47","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap48","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap49","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap50","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap51","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap52","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap53","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap54","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap55","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap56","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap57","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap58","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap59","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap60","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap61","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap62","-1","","");
insert into tableDefaults values ("bridgeDscpTo8021pMapping","dscp8021pMap63","-1","","");

insert into stringsMap values ("MCAST_DYN_SUBCR_NOT_SUPP","Deletion of dynamic multicast memberships not supported");
insert into stringsMap values ("CONFIGURED_PORT_PRESENT_IN_FWD_MAP","Selected port is associated with VLAN on LAN. Disable port membership to vlan on LAN");
insert into stringsMap values ("SELECTED_VLAN_ID_PRESENT_ON_LAN","Selected VLAN ID is already configured on LAN.");
insert into stringsMap values ("SELECTED_VLAN_ID_PRESENT_ON_WAN","Selected VLAN ID is already configured on WAN.");
insert into stringsMap values ("BRIDGE_MODE_CONFIG_FAILED","Bridge Mode configuration failed");
insert into stringsMap values ("DUPLICATE_VLAN_ID","Duplicate VLAN IDs are not allowed.");

CREATE TABLE DhcpServerPools
(
	Enable 					boolean NOT NULL,
	PoolID					integer NOT NULL,
	PoolOrder				integer,
	LogicalIfName 			text 	NOT NULL,

	VendorClassID			text,
	VendorClassIDExclude 	boolean,	
	VendorClassIDMode	 	text,
	VendorClassMatchOff		integer,
	VendorClassMatchLen		integer,

	ClientID				text,
	ClientIDExclude			boolean,

	UserClassID				text,
	UserClassIDExclude		boolean,

	Chaddr					text,
	ChaddrMask				text,
	ChaddrExclude			boolean,

	MinAddress				text NOT NULL,
	MaxAddress				text NOT NULL,

    DNSServers 				integer,
	DNSServer1				text,			
	DNSServer2				text,			
	DNSServer3				text,			

    ReservedIpAddr          text,
    ReservedMacAddr         text,

	DomainName				text,
	IPRouters				text,
	DHCPLeaseTime			float,

	DefaultPool				boolen NOT NULL,	-- default pool for this interface 

    PRIMARY KEY   (PoolID),
    FOREIGN KEY   (DomainName) REFERENCES system (domain)
    FOREIGN KEY   (LogicalIfName) REFERENCES networkInterface (LogicalIfName)
);

CREATE TABLE DhcpOption
(
	PoolID	integer NOT NULL,
	Enable 		boolean NOT NULL,
	OptionScope integer NOT NULL,
	OptionCode 	integer NOT NULL,
	value1		text,
	value2		text,
	value3		text,
    FOREIGN KEY (PoolID) REFERENCES DhcpServerPools (PoolID)
);

CREATE TABLE DhcpLeasedClients
(
   OID           integer,
   LogicalIfName text  NOT NULL,
   IPAddr        text,
   MacAddr       text NOT NULL,
   Starts        text,
   Ends          text,
   State         text,
   HostName		 text,	
   PRIMARY KEY   (IPAddr)
);

CREATE TABLE DhcpfixedIpAddress
(
    OID           integer,
	PoolID	  integer NOT NULL,
    IpAddr        text,
    MacAddr       text NOT NULL,
    Cname         text NOT NULL,
    PRIMARY KEY   (IpAddr,MacAddr,Cname)
    FOREIGN KEY (PoolID) REFERENCES DhcpServerPools (PoolID)
)
;

-- Dhcpc table
CREATE TABLE Dhcpc
    (
    OID                      integer,           -- OID
    LogicalIfName            text     NOT NULL, -- Interface/Network Name
    IspName                  integer,           -- name of the service provider
    ReleaseLease             boolean  NOT NULL, -- lease release flag
    PrimaryDns               text,              -- DNS1
    SecondaryDns             text,              -- DNS2
    PRIMARY KEY (LogicalIfName),                -- primary key
    FOREIGN KEY (LogicalIfName) REFERENCES networkInterface (LogicalIfName)
    );

CREATE TABLE DhcpcOptions
    (
    LogicalIfName            text     NOT NULL, -- Interface/Network Name
    Enable                   integer  NOT NULL,  
    OptionNumber             integer  NOT NULL,
    OptionMode               integer  NOT NULL,
    Value                    text             ,     
    DefaultOption            integer 
    ); 

-- DhcpStatus - table for storing Dhcp related status information.
create table DhcpStatus
    (
    OID                      integer,           -- OID
    LogicalIfName            text     NOT NULL, -- interface names like 'lan1', 'wan2', etc.
    DhcpServerIp             text     NOT NULL, -- dhcp server identity.
    LeaseTime                text     NOT NULL, -- lease time of dhcp configured ip. 
    LeaseObtained            text     NOT NULL, -- time when dhcp server assgined ip to dhclient. 
    -- add newer entries here

    PRIMARY KEY (LogicalIfName),                -- primary key
    FOREIGN KEY (LogicalIfName) REFERENCES networkInterface (LogicalIfName)
    );

CREATE TABLE dhcpv6c
    (
    LogicalIfName          text  NOT NULL   , -- interface on which to run
    connectionKey                 integer   ,
    isEnabled                     integer   , -- is enabled  
    statelessMode                 integer   , -- 1 = stateless mode 
    requestPreferredAddress       integer   , -- 
    preferredAddress              text      , -- IPv6 addres
    preferredAddressPrefixLength  integer   , -- IPv6 prefix length  
    requestDNS                    integer   , -- request DNS  
    requestDNSSearchList          integer   , -- request DNS Search List
    prefixDelegation              integer   , -- prefix delegation  
    requestPreferredPrefix        integer   , -- 1 = request Preferred Prefix 
    preferredPrefix               text      , -- IPv6 addres
    preferredPrefixPrefixLength   integer   , -- IPv6 prefix length      
    renewTime                     integer   , -- leaseTime
    sendRapidCommit               integer   , -- rapid commit  
    maptParams                    integer   , -- get maptParams  
    PRIMARY KEY (LogicalIfName)             , -- primary key
    FOREIGN KEY (LogicalIfName) REFERENCES networkInterface (LogicalIfName)
    );

CREATE TABLE dhcpv6s
    (
    LogicalIfName     text  NOT NULL        ,--  Logical Interface name   
    isEnabled           integer             ,--  DHCPv6 server enabled   
    statelessMode       integer             ,--  stateless/stateful mode   
    serverPreference    integer             ,--  server preference
    domainName          text                ,--  domain name   
    useDNSServersFrom   integer             ,--  use DNS servers from
    sipServerType       integer             ,--  0: None 1:Domain Name 2:IP Address
    sipServer           text                ,
    primaryDNSServer    text                ,--  primary DNS server
    secondaryDNSServer  text                ,--  secondary DNS server
    leaseTime           integer             ,--  lease time.
    prefixDelegation    boolean             ,--  enable prefix Delegation    
    PRIMARY KEY (LogicalIfName)             ,-- primary key
    FOREIGN KEY (LogicalIfName) REFERENCES networkInterface (LogicalIfName)
    );

CREATE TABLE dhcpv6sLANAddrPool
    (
    startAddress        text        ,    --  Address Pool start address
    endAddress          text        ,    --  Address Pool end address   
    prefixLength        integer     ,    --  prefix length   
    delegateEnabled     integer     ,    --  prefix delegation enabled   
    delegationPrefix    text        ,    --  prefix to be delegated   
    delegationPrefixLen integer     ,    --  delegation Prefix length
    LogicalIfName       text        ,    --  Logical Interface name   
    PRIMARY KEY (startAddress, endAddress)  
    );

CREATE TABLE dhcpv6sLANPrefixPool
    (
    hostDuid            text  NOT NULL      ,--client identifier
    delegationPrefix    text  NOT NULL      ,--prefix address 
    delegationPrefixLen text  NOT NULL      ,--prefix length
    PRIMARY KEY (delegationPrefix)
    );

CREATE TABLE dhcpv6ServerPools
    (
    addrPoolAddress     text            ,
    IANAManualPrefixes  text            ,
    IANAPrefixes        text            ,
    DUID                text            ,
    prefixPoolAddress   text            ,
    IAPDManualPrefixes  text            ,
    IAPDPrefixes        text            ,
    IAPDAddLength       integer         ,
    prefix              text            ,
    LogicalIfName       text            ,
    serverPoolType      text            
    );

    -- dhcpv6 relay schema

CREATE TABLE dhcpv6Relay
(
    logicalIfName      text        NOT NULL,  -- logical ifname like IF1 IF2 etc
    dhcpv6RelayStatus  boolean     NOT NULL,  -- Status -> 0 Disable 1 Enable
    relayGateway       text        NOT NULL,  -- Relay gateway ip address
    interfaceID        text,                  -- interfaceId 
    -- primary keys
    PRIMARY KEY  (logicalIfName)
);

CREATE TABLE Dhcpv6LeasedClients
(
   Enable        boolean,
   Alias         text,
   LogicalIfName text  NOT NULL,
   DUID          text NOT NULL,
   Statefull     boolean,
   PrefixDelegation boolean,
   IPAddr        text,
   RapidCommit   boolean,	
   PRIMARY KEY   (DUID)
);

insert into tableDefaults values ("dhcpv6s", "LogicalIfName", "IF2", "", "");
insert into stringsMap values ("IPV6_LAN_CONFIG_FAILED", "IPV6 Lan Configuration Failed");    
insert into stringsMap values ("IPV6_LAN_POOL_DELETE_SUCCESS", "IPV6 Lan Pool(s) Deleted Successfully");
insert into stringsMap values ("IPV6_LAN_POOL_DELETE_FAILED", "IPV6 Lan Pool(s) Deletion Failed");
insert into stringsMap values ("IPV6_LAN_POOL_CONFIG_FAILED", "IPV6 Lan Pool Configuration Failed");    
insert into stringsMap values ("DHCPV6_SERVER_POOL_ERR_WRONG_PREFIX","Please re-configure  DHCPv6 Server with correct LAN Prefix");
insert into stringsMap values("DHCP_CONFIG_FAILED","DHCP Configuration Failed");
insert into stringsMap values("IPADDRESS_NOT_IN_NETWORK_SUBNET","IPAddress is not in the subnet of this LAN Network.");
insert into stringsMap values("RESERVED_DEVICE_IP","IPAddress has already configured for the router.");
insert into stringsMap values("IP_ADDRESS_IN_RANGE","Configured IPAdress fall inside the DHCP server pools.");
insert into stringsMap values("DHCPV6D_INVALID_RANGE","Configured IPv6 Address not in same range.");
insert into stringsMap values("DHCPV6D_PREFIX_ALREADY_EXISTS","Configured IPv6 Prefix already exists.");
insert into stringsMap values("DHCPV6D_PREFIX_UPDATE_FAILED","Prefix update failed.");
insert into stringsMap values("DHCPD_INVALID_MAC_ADDRESS","Please provide a valid mac entry.");
insert into stringsMap values ("IPV6_LAN_PREFIX_DELETE_SUCCESS", "IPV6 Lan Prefix(es) Deleted Successfully");
insert into stringsMap values ("IPV6_LAN_PREFIX_DELETE_FAILED", "IPV6 Lan Prefix(es) Deletion Failed");
insert into stringsMap values ("IPV6_LAN_PREFIX_CONFIG_FAILED", "IPV6 Lan Prefix Configuration Failed");
insert into stringsMap values ("DHCPV6D_ADD_FAILED", "Failed to add prefix configuration");
insert into tableDefaults values ('dhcp','dhcpEnabled','1','','');
insert into tableDefaults values ('dhcp','leaseTime','24','','');
insert into tableDefaults values ('dhcp','enableDnsProxy','1','','');
insert into tableDefaults values ("dhcp", "domainName", "Pingcom", "", "");
insert into tableDefaults values ("dhcp", "primaryDnsServer", "", "", ""); 
insert into tableDefaults values ("dhcp", "secondaryDnsServer", "", "", ""); 
insert into tableDefaults values ("dhcp", "primaryTftpServer", "", "", ""); 
insert into tableDefaults values ("dhcp", "secondaryTftpServer", "", "", ""); 
insert into tableDefaults values ("dhcp", "winsServer", "", "", "");
CREATE TABLE ethernet
(
	interfaceName  text NOT NULL,
    LogicalIfName  text NOT NULL,
    MaxBitRate     text, 
	poe  integer NOT NULL,
	duplex  text NOT NULL,
	vlanId  integer NOT NULL,
	vlanEnabled integer NOT NULL,
	trunkPort integer NOT NULL,
	macAddress  text,
    edgePortStatus  bool,
    ethernetEdgePortCost  integer,
	PRIMARY KEY (interfaceName),
	FOREIGN KEY (vlanId) REFERENCES vlan(vlanId),
    FOREIGN KEY (LogicalIfName) REFERENCES networkInterface(LogicalIfName)
)
;

CREATE TABLE ethernetVLAN
(
	LogicalIfName text NOT NULL,
	vlanId  integer NOT NULL,
	PRIMARY KEY(LogicalIfName, vlanId)
);

insert into tableDefaults values ("ethernet","vlanEnabled","0","","");
insert into tableDefaults values ("ethernet","trunkPort","0","","");

insert into stringsMap values ("ETHERNET_PORT_CONFIG_FAILED","Ethernet port configuration failed");
insert into stringsMap values ("ETHERNET_STAT_CONFIG_FAILED","Ethernet statistics refresh configuration failed");
insert into stringsMap values ("ETHERNET_VLAN_CONFIG_FAILED","VLAN configuration failed");
-- table for organization unit name:
create table unitName (
unitName text NOT NULL
);
create table webBrandingTags
(
companyName text NOT NULL,
copyright text NOT NULL,
webAddress text NOT NULL,
supportLink text NOT NULL,
unitName text NULL,
tradeMark text NULL,
prodFamily text NULL,
appName text NULL,
wizardName text NULL,
Version text NULL
);

create table configFileTbl
    (
	Name			text,			-- Name of the vendor configuration file
	Version			text,			-- config file version number
	DateApplied		text,			-- Date and time when this configuration was applied
	Description		text,			-- Description	
	Status			integer,		-- 1 = system is running this configuration	
    PRIMARY KEY (Name)     
    );

insert into stringsMap values ("CONFIG_CHECKSUM_FAILURE","Failed to update configuration (checksum error)");

create table runLevelStatus
    (
	runLevel		integer			-- current system run level 
	);
CREATE TABLE slaac
    (
    LogicalIfName          text  NOT NULL   , -- interface on which to run
    ConnectionKey                 integer   ,
    isEnabled                     integer   ,
    GetIpFromIsp                  integer   , 
    GetDnsFromIsp                 integer   ,
    ConfigureDNS                  integer   ,
    nameserver1            text             ,
    nameserver2            text             ,
    nameserver3            text             ,
    GetRouteFromIsp               integer   ,
    GetDNSSLFromIsp               integer   ,
    PRIMARY KEY (LogicalIfName)             , -- primary key
    FOREIGN KEY (LogicalIfName) REFERENCES networkInterface (LogicalIfName)
    );

insert into dbUpdateRegisterTbl values ("UMI_COMP_SLAACD", 0, 0, "slaac", 0, 1, 1, 1);
-- userdb.sql - sql file for userdb component
--
-- Copyright (c) 2010, TeamF1, Inc.
--
-- modification history
-- --------------------
-- 01a,19feb10,pnm  adding groups table
--
-- DESCRIPTION
--
-- This file contains SQL table for userdb component plus any SQL insert
-- statements that are used by userdb component

CREATE TABLE users
(
	username  text NOT NULL,
	password  text NOT NULL,
	groupname  text NOT NULL,
	loginTimeout  integer NOT NULL,
	enableAccess  integer NOT NULL,
    descr text,                     -- brief description about the user
	 PRIMARY KEY (username)
)
;

insert into tableDefaults values ("users","loginTimeout","5", "1", "999");

insert into stringsMap values ("USERDB_CONFIG_FAILED","User configuration failed");
insert into stringsMap values ("INVALID_OLD_PASSWORD","Old Password is incorrect");
insert into stringsMap values ("USERDB_MAX_ERROR","Maximum users reached");
insert into stringsMap values ("USERDB_DUPLICATE_NAME","Duplicate user name");
insert into stringsMap values ("USERDB_DEFAULT_USER","Default user cannot be deleted");
insert into stringsMap values ("USERDB_DEFAULT_GROUP","Default Group cannot be changed");
insert into stringsMap values ("USERDB_INVALID_PASSWORD_LENGTH","Invalid Password length");
insert into stringsMap values ("USERDB_VALID_NAME","Valid Name");
insert into stringsMap values ("USERDB_USER_LOGGED_IN","User is logged in");

CREATE TABLE passwordComplixity
(
	OID	integer NULL,
	PasswordLength	integer NOT NULL,
	EnforcePwdComplexity	BOOLEAN NOT NULL
)
;

insert into tableDefaults values ("passwordComplixity","PasswordLength","8","","");
insert into tableDefaults values ("passwordComplixity","EnforcePwdComplexity","1","","");

CREATE TABLE groups
(
    name text unique,               -- group name
    descr text,                     -- brief description about the group
    accessLevel integer NOT NULL,    -- 0 - for readonly, 1 - for read/write
    capabilities		      text	NULL -- 3 - for Admin
                                         -- 4 - for Guest
                                         -- 9 - for Local
                                         -- 10 - for RunTimeAuth
);
create table firmUpdateUserConfig 
    (
    updateType  integer  -- 1 = disabled, 2 = check only, 3 = download, 4 = auto install, 5 = manual
    );

create table firmUpdateSystemConfig
    (
    url             text,       -- URL name of the firmware image
    urlType         integer,    -- 1 = absolute, 2 = URL description file
    domain          text,       -- domain name of the server
    filename        text,       -- file name on the server
    username        text,       -- user name 
    password        text,       -- password
    downloadPath    text,
    persist         boolean,
    decryptProgram  text
    );

create table firmUpdateStatus
    (
    version     text,
    checkedTime text,
    downloaded  integer,
    status      integer
    );

insert into dbUpdateRegisterTbl values ("UMI_COMP_FIRMD", 0, 0, "firmUpdateSystemConfig", 0, 1, 1, 1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_FIRMD", 0, 0, "firmUpdateUserConfig", 0, 1, 1, 1);

insert into stringsMap values ("FIRMWARE_INVALID_FILE","Firmware file is invalid or corrupted");
insert into stringsMap values ("FIRMWARE_BOOTLOADER_VARIABLES_ERROR","Unable to get the binaries to update the bootloader");
insert into stringsMap values ("FIRMWARE_BOOTLOADER_UPDATE_ERROR","Unable to update the bootloader variables");

insert into stringsMap values ("FIRMWARE_INFO_DOWNLOAD_FAILED","Failed to download firmware info file");
insert into stringsMap values ("FIRMWARE_INFO_DOWNLOAD_CORRUPT","Downloaded firmware info file is corrupt");
insert into stringsMap values ("FIRMWARE_DOWNLOAD_FAILED","Downloading of the firmware failed");

insert into stringsMap values ("UPGRADE_STATUS_NO_ERROR","Upgrade completed");
insert into stringsMap values ("UPGRADE_STATUS_WRITING","Writing firmware");
insert into stringsMap values ("UPGRADE_STATUS_ERROR","Upgrade failed");
insert into stringsMap values ("UPGRADE_STATUS_VERIFYING","Verifying firmware");
insert into stringsMap values ("UPGRADE_STATUS_UPGRADE_PREP","Preparing upgrade");
insert into stringsMap values ("UPGRADE_STATUS_ERASE_KERNEL","Erasing kernel partition");
insert into stringsMap values ("UPGRADE_STATUS_ERASE_FS","Erasing filesystem");

insert into stringsMap values ("FIRMD_STATE_INIT","Preparing for firmware upgrade.");
insert into stringsMap values ("FIRMD_STATE_SRV_DISCOVERY","Looking up firmware server.");
insert into stringsMap values ("FIRMD_STATE_SRV_FOUND","Firmware server found.");
insert into stringsMap values ("FIRMD_STATE_DOWNLOADING","Starting firmware download.");
insert into stringsMap values ("FIRMD_STATE_DOWNLOAD_FAILED","Firmware download failed.");
insert into stringsMap values ("FIRMD_STATE_DOWNLOADED","Firmware downloaded successfully.");
insert into stringsMap values ("FIRMD_STATE_UPGRADING","Starting firmware upgrade.");
insert into stringsMap values ("FIRMD_STATE_UPGRADE_PREINSTALL","Executing pre-install scripts.");
insert into stringsMap values ("FIRMD_STATE_ERASE_STAGE","Erasing flash.");
insert into stringsMap values ("FIRMD_STATE_ERASE_KERNEL","Erasing kernel partition.");
insert into stringsMap values ("FIRMD_STATE_ERASE_FS","Erasing filesystem partition.");
insert into stringsMap values ("FIRMD_STATE_WRITING_KERNEL","Writing kernel.");
insert into stringsMap values ("FIRMD_STATE_WRITING_FS","Writing filesystem.");
insert into stringsMap values ("FIRMD_STATE_UPGRADE_POSTINSTALL","Executing post-install scripts.");
insert into stringsMap values ("FIRMD_STATE_UPGRADE_FAILED","Firmware upgrade failed.");
insert into stringsMap values ("FIRMD_STATE_UPGRADE_SUCCESS","Firmware upgraded successfully.");
insert into stringsMap values ("FIRMD_STATE_IMAGE_VERIFYING","Verifying firmware image.");
insert into stringsMap values ("FIRMD_STATE_IMAGE_VERIFIED","Firmware image verified successfully.");
insert into stringsMap values ("FIRMD_STATE_SHUTDOWN","Shutting down...");

insert into stringsMap values ("FIRMD_DOWNLOAD_NOT_STARTED","Download has not started.");
insert into stringsMap values ("FIRMD_DOWNLOAD_IN_PROGRESS","Download in progress.");
insert into stringsMap values ("FIRMD_DOWNLOAD_COMPLETE","Download complete.");
insert into stringsMap values ("FIRMD_DOWNLOAD_FAILED","Download failed.");
insert into stringsMap values ("WRONG_FIRMWARE_UPGRADE","Invalid Image Selected. Please provide a Valid Image.");
insert into stringsMap values ("FILE_DOSENT_EXITS","Invalid Image Selected. Please provide a Valid Image.");
insert into stringsMap values ("INVALID_FILE_UPGRADE","Invalid Image Selected. Please provide a Valid Image.");
insert into stringsMap values ("INVALID_BACKUP_FILE","Invalid File Selected. Please provide a Valid File.");
CREATE TABLE dot11Card
(
	cardNo  integer NOT NULL,
	cardName  text NOT NULL,
    txEnabled integer NOT NULL,
    rxEnabled integer NOT NULL,
    agcEnabled integer NOT NULL,
    txCancellation integer NOT NULL,
    rxMaxGain integer NOT NULL,
    txLO integer NOT NULL,
    rxLO integer NOT NULL,
	 PRIMARY KEY (cardNo)
)
;



CREATE TABLE dot11Radio
(
	interfaceName  text NOT NULL,
	radioNo  integer NOT NULL,
	cardNo  integer NOT NULL,
	band  text NOT NULL,
	currentChannel  integer NOT NULL,
	configuredChannel  text NOT NULL,
	radioenabled  integer NOT NULL,
	minTxPower  integer,
	maxTxPower  integer,
	txPower  integer NOT NULL,
	path  integer NOT NULL,
	rogueAPEnabled  integer NOT NULL,
	rxDiversity  integer NOT NULL,
    dothEnabled integer NOT NULL,
    dothMaxPower integer NOT NULL,
    dothMarkDfs integer NOT NULL,
    opMode  text NOT NULL,
	beaconInterval  integer NOT NULL,
	dtimInterval  integer NOT NULL,
	rtsThreshold  integer NOT NULL,
	fragThreshold  integer NOT NULL,
	preambleMode  text NOT NULL,
	rtsCtsProtect  integer NOT NULL,
	shortRetry  integer NOT NULL,
	longRetry  integer NOT NULL,
	uapsd  integer NOT NULL,
    chanWidth integer NOT NULL,
    sideBand integer,                       -- 0 (below)/ 1 (above)
    puren integer NOT NULL,                 -- 0 (Disable)/ 1 (Enable)
    mimoPreamble  integer NOT NULL,         -- 0 (for MM) / 1 (for GF)
    rxAntennas  integer,                    -- 0 for auto, 1,2,3
    txAntennas  integer,                    -- 0 for auto, 1,2,3
    radarDetected text,
    subband_515_525   integer,
    subband_525_535   integer,
    subband_547_572   integer,
    subband_572_586   integer,
    ackTimeoutDefault integer,
    ackTimeout        integer,
    radioCost        integer,
    enableAMSDU      integer,
    maxClientsPerRadio  integer,
    txRate  integer,
    radioCountry text,			    --Country Abbreviation(For India IN) 
    radioCountryRev  integer,               --Country Revision
	PRIMARY KEY (radioNo),
    FOREIGN KEY (cardNo) REFERENCES dot11Card(cardNo)
)
;
insert into tableDefaults values ("dot11Radio","chanWidth","1","","");

CREATE TABLE dot11Interface
(
	interfaceName  text NOT NULL,
    LogicalIfName  text NOT NULL, 
	radioNo  integer NOT NULL,
	vapName  text NOT NULL,
	macAddress  text NOT NULL,
    defaultLANSubnet integer NOT NULL,
	PRIMARY KEY (interfaceName),
    FOREIGN KEY (radioNo) REFERENCES dot11Radio(radioNo)
)
;



CREATE TABLE dot11ACL
(
	hostName	text,
	macAddress  text NOT NULL,
    vapName  text NOT NULL,
    PRIMARY KEY (vapName, macAddress),
    FOREIGN KEY (vapName) REFERENCES dot11VAP(vapName)
)
;


CREATE TABLE dot11VAP
(
	vapName  text NOT NULL,
	vapEnabled  integer NOT NULL,
	profileName  text ,
	beaconInterval  integer ,
	dtimInterval  integer ,
	maxClients  integer ,
	rtsThreshold  integer ,
	fragThreshold  integer ,
	preambleMode  text ,
	rtsCtsProtect  integer ,
	shortRetry  integer ,
	longRetry  integer ,
	txPower  integer ,
	dot11Mode  text NOT NULL,
	apIsolation  integer ,
    defACLPolicy  text ,
    iappEnabled  integer ,
    uapsd  integer ,
    ucastRate text,
    mcastRate text,
    radioList text, -- we use this only to trigger updates,
                    -- in case radio selection has changed
    PRIMARY KEY (vapName),
    FOREIGN KEY (profileName) REFERENCES dot11Profile(profileName)
)
;

insert into tableDefaults values ("dot11VAP","vapEnabled","1","","");
insert into tableDefaults values ("dot11VAP","trunkPort","0","","");
insert into tableDefaults values ("dot11VAP","beaconInterval","100", "20", "1000");
insert into tableDefaults values ("dot11VAP","dtimInterval","1","1","255");
insert into tableDefaults values ("dot11VAP","rtsThreshold","2346","256","2346");
insert into tableDefaults values ("dot11VAP","fragThreshold","2346","257","2346");
insert into tableDefaults values ("dot11VAP","preambleMode","Long","","");
insert into tableDefaults values ("dot11VAP","rtsCtsProtect","0","","");
insert into tableDefaults values ("dot11VAP","shortRetry","16","0","128");
insert into tableDefaults values ("dot11VAP","longRetry","16","0","128");
insert into tableDefaults values ("dot11VAP","txPower","31","1","31");
insert into tableDefaults values ("dot11VAP","dot11Mode","AP","","");
insert into tableDefaults values ("dot11VAP","opMode","b and g","","");
insert into tableDefaults values ("dot11VAP","defACLPolicy","Open","","");
insert into tableDefaults values ("dot11VAP","iappEnabled","0","","");
insert into tableDefaults values ("dot11VAP","bssidSecret","","","");
insert into tableDefaults values ("dot11VAP","radioList","","","");
insert into tableDefaults values ("dot11VAP", "maxClients","8","","");
insert into tableDefaults values ("dot11VAP","uapsd","0","","");
insert into tableDefaults values ("dot11VAP","RadioCost","0","","");

CREATE TABLE dot11VAPStats
(
	interfaceName  text NOT NULL,
	is_rx_badversion  integer NOT NULL,
	is_rx_tooshort  integer NOT NULL,
	is_rx_wrongbss  integer NOT NULL,
	is_rx_dup  integer NOT NULL,
	is_rx_wrongdir  integer NOT NULL,
	is_rx_mcastecho  integer NOT NULL,
	is_rx_notassoc  integer NOT NULL,
	is_rx_noprivacy  integer NOT NULL,
	is_rx_unencrypted  integer NOT NULL,
	is_rx_wepfail  integer NOT NULL,
	is_rx_decap  integer NOT NULL,
	is_rx_mgtdiscard  integer NOT NULL,
	is_rx_ctl  integer NOT NULL,
	is_rx_beacon  integer NOT NULL,
	is_rx_rstoobig  integer NOT NULL,
	is_rx_elem_missing  integer NOT NULL,
	is_rx_elem_toobig  integer NOT NULL,
	is_rx_elem_toosmall  integer NOT NULL,
	is_rx_elem_unknown  integer NOT NULL,
	is_rx_badchan  integer NOT NULL,
	is_rx_chanmismatch  integer NOT NULL,
	is_rx_nodealloc  integer NOT NULL,
	is_rx_ssidmismatch  integer NOT NULL,
	is_rx_auth_unsupported  integer NOT NULL,
	is_rx_auth_fail  integer NOT NULL,
	is_rx_auth_countermeasures  integer NOT NULL,
	is_rx_assoc_bss  integer NOT NULL,
	is_rx_assoc_notauth  integer NOT NULL,
	is_rx_assoc_capmismatch  integer NOT NULL,
	is_rx_assoc_norate  integer NOT NULL,
	is_rx_assoc_badwpaie  integer NOT NULL,
	is_rx_deauth  integer NOT NULL,
	is_rx_disassoc  integer NOT NULL,
	is_rx_badsubtype  integer NOT NULL,
	is_rx_nobuf  integer NOT NULL,
	is_rx_decryptcrc  integer NOT NULL,
	is_rx_ahdemo_mgt  integer NOT NULL,
	is_rx_bad_auth  integer NOT NULL,
	is_rx_unauth  integer NOT NULL,
	is_rx_badkeyid  integer NOT NULL,
	is_rx_ccmpreplay  integer NOT NULL,
	is_rx_ccmpformat  integer NOT NULL,
	is_rx_ccmpmic  integer NOT NULL,
	is_rx_tkipreplay  integer NOT NULL,
	is_rx_tkipformat  integer NOT NULL,
	is_rx_tkipmic  integer NOT NULL,
	is_rx_tkipicv  integer NOT NULL,
	is_rx_badcipher  integer NOT NULL,
	is_rx_nocipherctx  integer NOT NULL,
	is_rx_acl  integer NOT NULL,
	is_rx_ffcnt  integer NOT NULL,
	is_rx_badathtnl  integer NOT NULL,
	is_tx_nobuf  integer NOT NULL,
	is_tx_nonode  integer NOT NULL,
	is_tx_unknownmgt  integer NOT NULL,
	is_tx_badcipher  integer NOT NULL,
	is_tx_nodefkey  integer NOT NULL,
	is_tx_noheadroom  integer NOT NULL,
	is_tx_ffokcnt  integer NOT NULL,
	is_tx_fferrcnt  integer NOT NULL,
	is_scan_active  integer NOT NULL,
	is_scan_passive  integer NOT NULL,
	is_node_timeout  integer NOT NULL,
	is_crypto_nomem  integer NOT NULL,
	is_crypto_tkip  integer NOT NULL,    
	is_crypto_tkipenmic  integer NOT NULL,
	is_crypto_tkipdemic  integer NOT NULL,
	is_crypto_tkipcm  integer NOT NULL,
	is_crypto_ccmp  integer NOT NULL,
	is_crypto_wep  integer NOT NULL,
	is_crypto_setkey_cipher  integer NOT NULL,
	is_crypto_setkey_nokey  integer NOT NULL,
	is_crypto_delkey  integer NOT NULL,
	is_crypto_badcipher  integer NOT NULL,
	is_crypto_nocipher  integer NOT NULL,
	is_crypto_attachfail  integer NOT NULL,
	is_crypto_swfallback  integer NOT NULL,
	is_crypto_keyfail  integer NOT NULL,
	is_crypto_enmicfail  integer NOT NULL,
	is_ibss_capmismatch  integer NOT NULL,
	is_ibss_norate  integer NOT NULL,
	is_ps_unassoc  integer NOT NULL,
	is_ps_badaid  integer NOT NULL,
	is_ps_qempty  integer NOT NULL,
	 PRIMARY KEY (interfaceName),
    FOREIGN KEY (interfaceName) REFERENCES dot11Interface(interfaceName)
)
;



CREATE TABLE dot11STA
(
	interfaceName  text NOT NULL,
	macAddress  text NOT NULL,
	security  text NOT NULL,
	authentication  text NOT NULL,
	cipher  text NOT NULL,
	timeConnected  text NOT NULL,
    clientType  integer NOT NULL,
	 PRIMARY KEY (macAddress, interfaceName),
    FOREIGN KEY (interfaceName) REFERENCES dot11Interface(interfaceName)
)
;



CREATE TABLE dot11NodeStats
(
	interfaceName  text NOT NULL,
	macAddress  text NOT NULL,
	ns_rx_data  integer NOT NULL,
	ns_rx_mgmt  integer NOT NULL,
	ns_rx_ctrl  integer NOT NULL,
	ns_rx_ucast  integer NOT NULL,
	ns_rx_mcast  integer NOT NULL,
	ns_rx_bytes  integer NOT NULL,
	ns_rx_beacons  integer NOT NULL,
	ns_rx_proberesp  integer NOT NULL,
	ns_rx_dup  integer NOT NULL,
	ns_rx_noprivacy  integer NOT NULL,
	ns_rx_wepfail  integer NOT NULL,
	ns_rx_demicfail  integer NOT NULL,
	ns_rx_decap  integer NOT NULL,
	ns_rx_defrag  integer NOT NULL,
	ns_rx_disassoc  integer NOT NULL,
	ns_rx_deauth  integer NOT NULL,
	ns_rx_decryptcrc  integer NOT NULL,
	ns_rx_unauth  integer NOT NULL,
	ns_rx_unencrypted  integer NOT NULL,
	ns_tx_data  integer NOT NULL,
	ns_tx_mgmt  integer NOT NULL,
	ns_tx_ucast  integer NOT NULL,
	ns_tx_mcast  integer NOT NULL,
	ns_tx_bytes  integer NOT NULL,
	ns_tx_probereq  integer NOT NULL,
	ns_tx_uapsd  integer NOT NULL,
	ns_tx_novlantag  integer NOT NULL,
	ns_tx_vlanmismatch  integer NOT NULL,
	ns_tx_eosplost  integer NOT NULL,
	ns_ps_discard  integer NOT NULL,
	ns_uapsd_triggers  integer NOT NULL,
	ns_tx_assoc  integer NOT NULL,
	ns_tx_assoc_fail  integer NOT NULL,
	ns_tx_auth  integer NOT NULL,
	ns_tx_auth_fail  integer NOT NULL,
	ns_tx_deauth  integer NOT NULL,
	ns_tx_deauth_code  integer NOT NULL,
	ns_tx_disassoc  integer NOT NULL,
	ns_tx_disassoc_code  integer NOT NULL,
	ns_psq_drops  integer NOT NULL,
	 PRIMARY KEY (macAddress),
    FOREIGN KEY (macAddress) REFERENCES dot11STA(macAddress),
    FOREIGN KEY (interfaceName) REFERENCES dot11Interface(interfaceName)
)
;


CREATE TABLE dot11RogueAP
(
	macAddress  text NOT NULL,
	SSID  text NOT NULL,
	security  text NOT NULL,
	pairwiseCiphers  text NOT NULL,
	authMethods  text NOT NULL,
	channelNumber integer NOT NULL,
	apmode  text NOT NULL,
	timeLastSeen  integer,
	 PRIMARY KEY (macAddress, SSID, security, pairwiseCiphers, authMethods, channelNumber, apmode)
)
;


CREATE TABLE dot11AuthorizedAP
(
	macAddress  text NOT NULL,
	SSID  text NOT NULL,
	security  text NOT NULL,
	pairwiseCiphers text NOT NULL,
	authMethods text NOT NULL,
	channelNumber integer NOT NULL,
	apmode  text NOT NULL,
	 PRIMARY KEY (macAddress, SSID, security, pairwiseCiphers, authMethods, channelNumber, apmode)
)
;

CREATE TABLE dot11Profile
(
	profileName  text NOT NULL,
	ssid  text NOT NULL,
	authserver  text ,
	broadcastSSID  integer NOT NULL,
	pskPassAscii  text ,
	pskPassHex  text ,
	wepkeyPassphrase text,
	wepkey0  text ,
	wepkey1  text ,
	wepkey2  text ,
	wepkey3  text ,
	defWepkeyIdx  integer ,
	groupCipher  text ,
	pairwiseCiphers  text ,
	authMethods  text ,
	security  text NOT NULL,
	authTimeout  integer ,
	assocTimeout  integer ,
	groupKeyUpdateInterval  integer ,
	pmksaLifetime  integer ,
	dot1xReauthInterval  integer ,
	wepAuth  text ,
    preAuthStatus integer NOT NULL,
    qosEnable integer NOT NULL,
    defaultCos text NOT NULL,
    dscpCosMap0 text  NOT NULL,
    dscpCosMap1 text  NOT NULL,
    dscpCosMap2 text  NOT NULL,
    dscpCosMap3 text  NOT NULL,
    dscpCosMap4 text  NOT NULL,
    dscpCosMap5 text  NOT NULL,
    dscpCosMap6 text  NOT NULL,
    dscpCosMap7 text  NOT NULL,
    dscpCosMap8 text  NOT NULL,
    dscpCosMap9 text  NOT NULL,
    dscpCosMap10 text  NOT NULL,
    dscpCosMap11 text  NOT NULL,
    dscpCosMap12 text  NOT NULL,
    dscpCosMap13 text  NOT NULL,
    dscpCosMap14 text  NOT NULL,
    dscpCosMap15 text  NOT NULL,
    dscpCosMap16 text  NOT NULL,
    dscpCosMap17 text  NOT NULL,
    dscpCosMap18 text  NOT NULL,
    dscpCosMap19 text  NOT NULL,
    dscpCosMap20 text  NOT NULL,
    dscpCosMap21 text  NOT NULL,
    dscpCosMap22 text  NOT NULL,
    dscpCosMap23 text  NOT NULL,
    dscpCosMap24 text  NOT NULL,
    dscpCosMap25 text  NOT NULL,
    dscpCosMap26 text  NOT NULL,
    dscpCosMap27 text  NOT NULL,
    dscpCosMap28 text  NOT NULL,
    dscpCosMap29 text  NOT NULL,
    dscpCosMap30 text  NOT NULL,
    dscpCosMap31 text  NOT NULL,
    dscpCosMap32 text  NOT NULL,
    dscpCosMap33 text  NOT NULL,
    dscpCosMap34 text  NOT NULL,
    dscpCosMap35 text  NOT NULL,
    dscpCosMap36 text  NOT NULL,
    dscpCosMap37 text  NOT NULL,
    dscpCosMap38 text  NOT NULL,
    dscpCosMap39 text  NOT NULL,
    dscpCosMap40 text  NOT NULL,
    dscpCosMap41 text  NOT NULL,
    dscpCosMap42 text  NOT NULL,
    dscpCosMap43 text  NOT NULL,
    dscpCosMap44 text  NOT NULL,
    dscpCosMap45 text  NOT NULL,
    dscpCosMap46 text  NOT NULL,
    dscpCosMap47 text  NOT NULL,
    dscpCosMap48 text  NOT NULL,
    dscpCosMap49 text  NOT NULL,
    dscpCosMap50 text  NOT NULL,
    dscpCosMap51 text  NOT NULL,
    dscpCosMap52 text  NOT NULL,
    dscpCosMap53 text  NOT NULL,
    dscpCosMap54 text  NOT NULL,
    dscpCosMap55 text  NOT NULL,
    dscpCosMap56 text  NOT NULL,
    dscpCosMap57 text  NOT NULL,
    dscpCosMap58 text  NOT NULL,
    dscpCosMap59 text  NOT NULL,
    dscpCosMap60 text  NOT NULL,
    dscpCosMap61 text  NOT NULL,
    dscpCosMap62 text  NOT NULL,
    dscpCosMap63 text  NOT NULL,
	 PRIMARY KEY (profileName),
    FOREIGN KEY (authserver) REFERENCES radiusClient(authserver)
)
;

create table dot11Countries
(
    country text,
    countrycode int
);

create table dot11CountriesRegDmnMapping
(
    country text,
    regDomain5Ghz  text,
    regDomain2Ghz text,
    allow11g int,
    allow11na40 int,
    allow11ng40 int
);

create table dot11RegDmnChannelMapping 
(
    regDomain text,
    channelNo int,
    frequency int,
    chan11a   int,
    chan11na int,
    chan11b   int,
    chan11g   int,
    chan11ng int,
    ht40 int -- 40Ghz channel width
); 

create table dot11GlobalConfig
(
    country text,
    countrycode int,
    iappBssidSecret text
);

create table apGroupName
(
    apGroupName       text -- apGroup name
);

create table dot11WPS
(
    vapName       text, -- ap name
    wpsEnabled    int NOT NULL,  -- wps enabled/disabled
    PRIMARY KEY (vapName)
);

create table dot11WPSSessStatus
(
    sessionMsg    text, -- wps session status messages
    sessionStatus int NOT NULL  -- wps session status
);

create table dot11Schedule
(
    scheduleName  text,
    scheduleStatus text,
    startHour text,
    startMinute text,
    startMeridian text,
    stopHour text,
    stopMinute text,
    stopMeridian text,
    associatedSSID text
);


insert into dot11WPSSessStatus values ("","0");

insert into stringsMap values ("NO_WPA_VAP_ERROR","Please Enable WPA/WPA2 for the SSID");
insert into stringsMap values ("WPS_CONFIG_FAILED","WPS Configuration Failed.");
insert into stringsMap values ("WPS_CONFIG_PBC_FALIED","Error Configuring WPS through PIN. Please wait for some time and try again");
insert into stringsMap values ("WPS_CONFIG_PIN_FALIED","Error Configuring WPS through PCB. Please wait for some time and try again");
insert into stringsMap values ("DOT11_DUPLICATE_SSID","SSID Already exists, please enter different SSID.");
insert into stringsMap values ("WPS_QUERRY_INPROCESS","WPS Station Adding in Process. Please try after some time to add new Station");
insert into stringsMap values ("AP_DISABLED_ERROR","Enable AP to add WPS Stations");
insert into stringsMap values ("WPA_VAP_USE_ERROR","Please disable WPS on AP using this profile");
insert into stringsMap values ("WPS_VAP_USE_ERROR","Please disable WPS on selected VAP");
insert into stringsMap values ("WLAN_SCHEDULE_NOT_FOUND","Wireless schedule not found");
insert into stringsMap values ("WLAN_CRON_START_ENTRY_ERROR","Please enter valid start time");
insert into stringsMap values ("WLAN_CRON_STOP_ENTRY_ERROR","Please enter valid stop time");
insert into stringsMap values ("WLAN_DUPLICATE_SCHEDULE","Please provide another schedule name, since a schedule name with this already present");
insert into stringsMap values ("WLAN_SCHEDULE_IN_USE","Schedule rule selected to delete is in use");
insert into stringsMap values ("INVALID_ACL_MAC","Please provide a valid mac entry");
insert into stringsMap values ("DOT11_WPS_CONFIG_FAILED","WPS configuration failed");

insert into dot11CountriesRegDmnMapping values ("USA", "FCC3","FCCA", 1, 1, 1);
insert into dot11CountriesRegDmnMapping values ("INDIA", "APL6","WORLD", 1, 0, 1);
insert into dot11CountriesRegDmnMapping values ("CANADA", "FCC2","FCCA", 1, 1, 1);
--insert into dot11CountriesRegDmnMapping values ("KOREA", "--","--", 1, 1, 1);
--insert into dot11CountriesRegDmnMapping values ("JAPAN", "--","--", 1, 1, 1);
insert into dot11CountriesRegDmnMapping values ("HONG KONG", "FCC2","WORLD", 1, 1, 1);
insert into dot11CountriesRegDmnMapping values ("CHINA", "APL1","WORLD", 1, 1, 1);
insert into dot11CountriesRegDmnMapping values ("AUSTRALIA", "FCC2","WORLD", 1, 1, 1);
insert into dot11CountriesRegDmnMapping values ("SINGAPORE", "APL6","WORLD", 1, 1, 1);
insert into dot11CountriesRegDmnMapping values ("THAILAND", "NULL1","WORLD", 1, 0, 1);
insert into dot11CountriesRegDmnMapping values ("BRUNEI DARUSSALAM", "APL1","WORLD", 1, 1, 1);
insert into dot11CountriesRegDmnMapping values ("INDONESIA", "APL1","WORLD", 1, 0, 1);
insert into dot11CountriesRegDmnMapping values ("NEW ZEALAND", "FCC2","ETSIC", 1, 0, 1);
insert into dot11CountriesRegDmnMapping values ("PHILIPPINES", "APL1","WORLD", 1, 1, 1);
insert into dot11CountriesRegDmnMapping values ("VIETNAM", "NULL1","WORLD", 1, 0, 1);

insert into dot11RegDmnChannelMapping values ("FCCA",  1,2412, 0, 0,1, 1, 1, 0);
insert into dot11RegDmnChannelMapping values ("FCCA",  2,2417, 0, 0,1, 1, 1, 0);
insert into dot11RegDmnChannelMapping values ("FCCA",  3,2422, 0, 0,1, 1, 1, 1);
insert into dot11RegDmnChannelMapping values ("FCCA",  4,2427, 0, 0,1, 1, 1, 1);
insert into dot11RegDmnChannelMapping values ("FCCA",  5,2432, 0, 0,1, 1, 1, 1);
insert into dot11RegDmnChannelMapping values ("FCCA",  6,2437, 0, 0,1, 1, 1, 1);
insert into dot11RegDmnChannelMapping values ("FCCA",  7,2442, 0, 0,1, 1, 1, 1);
insert into dot11RegDmnChannelMapping values ("FCCA",  8,2447, 0, 0,1, 1, 1, 1);
insert into dot11RegDmnChannelMapping values ("FCCA",  9,2452, 0, 0,1, 1, 1, 1);
insert into dot11RegDmnChannelMapping values ("FCCA", 10,2457, 0, 0,1, 1, 1, 0);
insert into dot11RegDmnChannelMapping values ("FCCA", 11,2462, 0, 0,1, 1, 1, 0);
insert into dot11RegDmnChannelMapping values ("FCCA", 12,2467, 0, 0,0, 0, 1, 0);
insert into dot11RegDmnChannelMapping values ("FCCA", 13,2472, 0, 0,0, 0, 1, 0);

insert into dot11RegDmnChannelMapping values ("FCC2", 36, 5180, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("FCC2", 38, 5190, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC2", 40, 5200, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC2", 44, 5220, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC2", 46, 5230, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC2", 48, 5240, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("FCC2", 52, 5260, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("FCC2", 54, 5270, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC2", 56, 5280, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC2", 60, 5300, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC2", 62, 5310, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC2", 64, 5320, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("FCC2", 149, 5745, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("FCC2", 153, 5765, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("FCC2", 157, 5785, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("FCC2", 159, 5795, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC2", 161, 5805, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("FCC2", 165, 5825, 1, 0,0,0,0,0);

insert into dot11RegDmnChannelMapping values ("FCC3", 36, 5180, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("FCC3", 38, 5190, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC3", 40, 5200, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC3", 44, 5220, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC3", 46, 5230, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC3", 48, 5240, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("FCC3", 52, 5260, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("FCC3", 54, 5270, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC3", 56, 5280, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC3", 60, 5300, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC3", 62, 5310, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC3", 64, 5320, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("FCC3", 100, 5500, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("FCC3", 104, 5520, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC3", 108, 5540, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC3", 112, 5560, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC3", 116, 5580, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC3", 120, 5600, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC3", 124, 5620, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC3", 128, 5640, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC3", 132, 5660, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC3", 136, 5680, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("FCC3", 140, 5700, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("FCC3", 149, 5745, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("FCC3", 153, 5765, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("FCC3", 157, 5785, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("FCC3", 159, 5795, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("FCC3", 161, 5805, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("FCC3", 165, 5825, 1, 0,0,0,0,0);

insert into dot11RegDmnChannelMapping values ("APL1", 149, 5745, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("APL1", 151, 5755, 0, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("APL1", 153, 5765, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("APL1", 157, 5785, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("APL1", 159, 5795, 0, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("APL1", 161, 5805, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("APL1", 165, 5825, 1, 0,0,0,0,0);

insert into dot11RegDmnChannelMapping values ("APL6", 36, 5180, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("APL6", 38, 5190, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("APL6", 40, 5200, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("APL6", 44, 5220, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("APL6", 46, 5230, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("APL6", 48, 5240, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("APL6", 52, 5260, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("APL6", 54, 5270, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("APL6", 56, 5280, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("APL6", 60, 5300, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("APL6", 62, 5310, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("APL6", 64, 5320, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("APL6", 149, 5745, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("APL6", 153, 5765, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("APL6", 157, 5785, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("APL6", 159, 5795, 1, 1,0,0,0,1);
insert into dot11RegDmnChannelMapping values ("APL6", 161, 5805, 1, 0,0,0,0,0);
insert into dot11RegDmnChannelMapping values ("APL6", 165, 5825, 1, 0,0,0,0,0);

insert into dot11RegDmnChannelMapping values ("ETSIC",  1,2412, 0, 0,1, 1, 1, 0);
insert into dot11RegDmnChannelMapping values ("ETSIC",  2,2417, 0, 0,1, 1, 1, 0);
insert into dot11RegDmnChannelMapping values ("ETSIC",  3,2422, 0, 0,1, 1, 1, 1);
insert into dot11RegDmnChannelMapping values ("ETSIC",  4,2427, 0, 0,1, 1, 1, 1);
insert into dot11RegDmnChannelMapping values ("ETSIC",  5,2432, 0, 0,1, 1, 1, 1);
insert into dot11RegDmnChannelMapping values ("ETSIC",  6,2437, 0, 0,1, 1, 1, 1);
insert into dot11RegDmnChannelMapping values ("ETSIC",  7,2442, 0, 0,1, 1, 1, 1);
insert into dot11RegDmnChannelMapping values ("ETSIC",  8,2447, 0, 0,1, 1, 1, 1);
insert into dot11RegDmnChannelMapping values ("ETSIC",  9,2452, 0, 0,1, 1, 1, 1);
insert into dot11RegDmnChannelMapping values ("ETSIC", 10,2457, 0, 0,1, 1, 1, 1);
insert into dot11RegDmnChannelMapping values ("ETSIC", 11,2462, 0, 0,1, 1, 1, 1);
insert into dot11RegDmnChannelMapping values ("ETSIC", 12,2467, 0, 0,1, 1, 1, 0);
insert into dot11RegDmnChannelMapping values ("ETSIC", 13,2472, 0, 0,1, 1, 1, 0);

insert into dot11RegDmnChannelMapping values ("WORLD", 1,2412, 0, 0,1, 1, 1, 0);
insert into dot11RegDmnChannelMapping values ("WORLD", 2,2417, 0, 0,1, 1, 1, 0);
insert into dot11RegDmnChannelMapping values ("WORLD", 3,2422, 0, 0,1, 1, 1, 1);
insert into dot11RegDmnChannelMapping values ("WORLD", 4,2427, 0, 0,1, 1, 1, 1);
insert into dot11RegDmnChannelMapping values ("WORLD", 5,2432, 0, 0,1, 1, 1, 1);
insert into dot11RegDmnChannelMapping values ("WORLD", 6,2437, 0, 0,1, 1, 1, 1);
insert into dot11RegDmnChannelMapping values ("WORLD", 7,2442, 0, 0,1, 1, 1, 1);
insert into dot11RegDmnChannelMapping values ("WORLD", 8,2447, 0, 0,1, 1, 1, 1);
insert into dot11RegDmnChannelMapping values ("WORLD", 9,2452, 0, 0,1, 1, 1, 1);
insert into dot11RegDmnChannelMapping values ("WORLD", 10,2457, 0, 0,1, 1, 1, 0);
insert into dot11RegDmnChannelMapping values ("WORLD", 11,2462, 0, 0,1, 1, 1, 0);
insert into dot11RegDmnChannelMapping values ("WORLD", 12,2467, 0, 0,1, 1, 1, 0);
insert into dot11RegDmnChannelMapping values ("WORLD", 13,2472, 0, 0,1, 1, 1, 0);

CREATE TABLE dot11IAPPRemoteAP
(
    bssid  text NOT NULL,
    ipAddr  text,
    bssidSecret text,
    vlanId integer,
    neighbor text,
    PRIMARY KEY (bssid)
)
;

insert into tableDefaults values ("dot11IAPPRemoteAP", "bssid","","","");
insert into tableDefaults values ("dot11IAPPRemoteAP", "ipAddr","","","");
insert into tableDefaults values ("dot11IAPPRemoteAP", "bssidSecret","","","");
insert into tableDefaults values ("dot11IAPPRemoteAP", "vlanId","","1","4095");
insert into tableDefaults values ("dot11IAPPRemoteAP", "neighbor","","","");

insert into tableDefaults values ("dot11Profile", "authTimeout","10","1","3600");
insert into tableDefaults values ("dot11Profile", "assocTimeout","10","1","3600");
insert into tableDefaults values ("dot11Profile", "groupKeyUpdateInterval","3600","1","36000");
insert into tableDefaults values ("dot11Profile", "pmksaLifetime","3600","1","36000");
insert into tableDefaults values ("dot11Profile", "dot1xReauthInterval","3600","1","36000");
insert into tableDefaults values ("dot11Profile", "preAuthStatus","0","","");
insert into tableDefaults values ("dot11Profile","qosEnable","0","","");
insert into tableDefaults values ("dot11Profile","defaultCos","Background","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap0","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap1","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap2","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap3","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap4","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap5","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap6","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap7","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap8","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap9","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap10","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap11","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap12","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap13","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap14","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap15","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap16","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap17","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap18","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap19","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap20","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap21","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap22","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap23","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap24","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap25","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap26","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap27","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap28","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap29","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap30","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap31","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap32","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap33","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap34","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap35","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap36","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap37","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap38","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap39","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap40","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap41","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap42","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap43","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap44","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap45","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap46","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap47","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap48","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap49","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap50","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap51","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap52","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap53","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap54","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap55","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap56","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap57","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap58","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap59","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap60","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap61","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap62","Default","","");
insert into tableDefaults values ("dot11Profile","dscpCosMap63","Default","","");

insert into tableDefaults values ("dot11WPS", "vapName","","","");
insert into tableDefaults values ("dot11WPS", "wpsEnabled","0","","");

insert into tableDefaults values ("dot11WPSSessStatus", "sessionMsg","","","");
insert into tableDefaults values ("dot11WPSSessStatus", "sessionStatus","0","","");

insert into dbUpdateRegisterTbl values ("UMI_COMP_UDOT11",1,1,"dot11AuthorizedAP", 0, 1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_UDOT11",1,1,"dot11RogueAP", 0, 0,0,1);

insert into stringsMap values ("DOT11_STAT_CONFIG_FAILED","Wireless statistics refresh configuration failed");
insert into stringsMap values ("DOT11_AP_STAT_CONFIG_FAILED","AP statistics refresh configuration failed");
insert into stringsMap values ("DOT11_ROGUE_AP_MOVE_FAILED","Unable to move rogue AP");
insert into stringsMap values ("DOT11_AUTH_AP_CONFIG_FAILED","Authorized AP configuration failed");
insert into stringsMap values ("DOT11_PROFILE_CONFIG_FAILED","Profile configuration failed");
insert into stringsMap values ("DOT11_ADV_PROFILE_CONFIG_FAILED","Advanced profile configuration failed");
insert into stringsMap values ("DOT11_QOS_CONFIG_FAILED","QoS configuration failed");
insert into stringsMap values ("DOT11_AP_DEL_FAILED","Unable to delete AP");
insert into stringsMap values ("DOT11_AP_ENABLE_FAILED","Enabling of AP failed");
insert into stringsMap values ("DOT11_AP_DISABLE_FAILED","Disabling of AP failed");
insert into stringsMap values ("DOT11_AP_CONFIG_FAILED","AP configuration failed");
insert into stringsMap values ("DOT11_ADV_AP_CONFIG_FAILED","Advanced AP configuration failed");
insert into stringsMap values ("DOT11_ACL_CONFIG_FAILED","ACL configuration failed");
insert into stringsMap values ("DOT11_RADIO_CONFIG_FAILED","Radio configuration failed");
insert into stringsMap values ("DOT11_CARD_CONFIG_FAILED","Card configuration failed");
insert into stringsMap values ("DOT11_IAPP_CONFIG_FAILED_BSSID","IAPP configuration failed (BSSID Secret)");
insert into stringsMap values ("DOT11_IAPP_ENABLE_FAILED","IAPP enable failed");
insert into stringsMap values ("DOT11_IAPP_DISABLE_FAILED","IAPP disable failed");
insert into stringsMap values ("DOT11_IAPP_CONFIG_FAILED_REMOTE","IAPP configuration failed (Remote AP)");
insert into stringsMap values ("DOT11_WDS_CONFIG_FAILED","Failed to configure WDS (Radio is in use by other APs)");
insert into stringsMap values ("DOT11_RADIO_CHAN_MUTEX_FAILURE","Channel configuration failed (Same channel already configured on a different radio)");
insert into stringsMap values ("DOT11_RADIO_CHAN_DWIDTH_FAILURE","Warning : Channel falls within 25Mhz range of channel configured on another radio (This might affect normal operation)");
insert into stringsMap values ("MAX_CLIENT_ERROR","Configuration Failed.Max Clients configured exceeds total number of clients allowed for the radio");
insert into stringsMap values ("AP_USING_PROFILE","Selected profile(s) for deletion is/are being used by active AP(s)");
insert into stringsMap values ("DOT11_WPS_PIN_INVALID","Invalid Pin Value");

CREATE TABLE dscpToQueueMapping
(
    dscpCosMap0 text  NOT NULL,
    dscpCosMap1 text  NOT NULL,
    dscpCosMap2 text  NOT NULL,
    dscpCosMap3 text  NOT NULL,
    dscpCosMap4 text  NOT NULL,
    dscpCosMap5 text  NOT NULL,
    dscpCosMap6 text  NOT NULL,
    dscpCosMap7 text  NOT NULL,
    dscpCosMap8 text  NOT NULL,
    dscpCosMap9 text  NOT NULL,
    dscpCosMap10 text  NOT NULL,
    dscpCosMap11 text  NOT NULL,
    dscpCosMap12 text  NOT NULL,
    dscpCosMap13 text  NOT NULL,
    dscpCosMap14 text  NOT NULL,
    dscpCosMap15 text  NOT NULL,
    dscpCosMap16 text  NOT NULL,
    dscpCosMap17 text  NOT NULL,
    dscpCosMap18 text  NOT NULL,
    dscpCosMap19 text  NOT NULL,
    dscpCosMap20 text  NOT NULL,
    dscpCosMap21 text  NOT NULL,
    dscpCosMap22 text  NOT NULL,
    dscpCosMap23 text  NOT NULL,
    dscpCosMap24 text  NOT NULL,
    dscpCosMap25 text  NOT NULL,
    dscpCosMap26 text  NOT NULL,
    dscpCosMap27 text  NOT NULL,
    dscpCosMap28 text  NOT NULL,
    dscpCosMap29 text  NOT NULL,
    dscpCosMap30 text  NOT NULL,
    dscpCosMap31 text  NOT NULL,
    dscpCosMap32 text  NOT NULL,
    dscpCosMap33 text  NOT NULL,
    dscpCosMap34 text  NOT NULL,
    dscpCosMap35 text  NOT NULL,
    dscpCosMap36 text  NOT NULL,
    dscpCosMap37 text  NOT NULL,
    dscpCosMap38 text  NOT NULL,
    dscpCosMap39 text  NOT NULL,
    dscpCosMap40 text  NOT NULL,
    dscpCosMap41 text  NOT NULL,
    dscpCosMap42 text  NOT NULL,
    dscpCosMap43 text  NOT NULL,
    dscpCosMap44 text  NOT NULL,
    dscpCosMap45 text  NOT NULL,
    dscpCosMap46 text  NOT NULL,
    dscpCosMap47 text  NOT NULL,
    dscpCosMap48 text  NOT NULL,
    dscpCosMap49 text  NOT NULL,
    dscpCosMap50 text  NOT NULL,
    dscpCosMap51 text  NOT NULL,
    dscpCosMap52 text  NOT NULL,
    dscpCosMap53 text  NOT NULL,
    dscpCosMap54 text  NOT NULL,
    dscpCosMap55 text  NOT NULL,
    dscpCosMap56 text  NOT NULL,
    dscpCosMap57 text  NOT NULL,
    dscpCosMap58 text  NOT NULL,
    dscpCosMap59 text  NOT NULL,
    dscpCosMap60 text  NOT NULL,
    dscpCosMap61 text  NOT NULL,
    dscpCosMap62 text  NOT NULL,
    dscpCosMap63 text  NOT NULL
);

CREATE TABLE dscpToCosMapping
(
   dscpCosMap0 text  NOT NULL,
    dscpCosMap1 text  NOT NULL,
    dscpCosMap2 text  NOT NULL,
    dscpCosMap3 text  NOT NULL,
    dscpCosMap4 text  NOT NULL,
    dscpCosMap5 text  NOT NULL,
    dscpCosMap6 text  NOT NULL,
    dscpCosMap7 text  NOT NULL,
    dscpCosMap8 text  NOT NULL,
    dscpCosMap9 text  NOT NULL,
    dscpCosMap10 text  NOT NULL,
    dscpCosMap11 text  NOT NULL,
    dscpCosMap12 text  NOT NULL,
    dscpCosMap13 text  NOT NULL,
    dscpCosMap14 text  NOT NULL,
    dscpCosMap15 text  NOT NULL,
    dscpCosMap16 text  NOT NULL,
    dscpCosMap17 text  NOT NULL,
    dscpCosMap18 text  NOT NULL,
    dscpCosMap19 text  NOT NULL,
    dscpCosMap20 text  NOT NULL,
    dscpCosMap21 text  NOT NULL,
    dscpCosMap22 text  NOT NULL,
    dscpCosMap23 text  NOT NULL,
    dscpCosMap24 text  NOT NULL,
    dscpCosMap25 text  NOT NULL,
    dscpCosMap26 text  NOT NULL,
    dscpCosMap27 text  NOT NULL,
    dscpCosMap28 text  NOT NULL,
    dscpCosMap29 text  NOT NULL,
    dscpCosMap30 text  NOT NULL,
    dscpCosMap31 text  NOT NULL,
    dscpCosMap32 text  NOT NULL,
    dscpCosMap33 text  NOT NULL,
    dscpCosMap34 text  NOT NULL,
    dscpCosMap35 text  NOT NULL,
    dscpCosMap36 text  NOT NULL,
    dscpCosMap37 text  NOT NULL,
    dscpCosMap38 text  NOT NULL,
    dscpCosMap39 text  NOT NULL,
    dscpCosMap40 text  NOT NULL,
    dscpCosMap41 text  NOT NULL,
    dscpCosMap42 text  NOT NULL,
    dscpCosMap43 text  NOT NULL,
    dscpCosMap44 text  NOT NULL,
    dscpCosMap45 text  NOT NULL,
    dscpCosMap46 text  NOT NULL,
    dscpCosMap47 text  NOT NULL,
    dscpCosMap48 text  NOT NULL,
    dscpCosMap49 text  NOT NULL,
    dscpCosMap50 text  NOT NULL,
    dscpCosMap51 text  NOT NULL,
    dscpCosMap52 text  NOT NULL,
    dscpCosMap53 text  NOT NULL,
    dscpCosMap54 text  NOT NULL,
    dscpCosMap55 text  NOT NULL,
    dscpCosMap56 text  NOT NULL,
    dscpCosMap57 text  NOT NULL,
    dscpCosMap58 text  NOT NULL,
    dscpCosMap59 text  NOT NULL,
    dscpCosMap60 text  NOT NULL,
    dscpCosMap61 text  NOT NULL,
    dscpCosMap62 text  NOT NULL,
    dscpCosMap63 text  NOT NULL
);

CREATE TABLE cosToQueueMapping
(
    cosMap0 text  NOT NULL,
    cosMap1 text  NOT NULL,
    cosMap2 text  NOT NULL,
    cosMap3 text  NOT NULL,
    cosMap4 text  NOT NULL,
    cosMap5 text  NOT NULL,
    cosMap6 text  NOT NULL,
    cosMap7 text  NOT NULL
);

CREATE TABLE dot11lantiqDeviceInfo
(
    manufacturer text NOT NULL,
    model_name text NOT NULL,
    device_name text NOT NULL,
    model_number text NOT NULL,
    serial_number text NOT NULL,
    fw_logger_severity text NOT NULL
);

CREATE TABLE dot11pmf
(
    profileName text NOT NULL,
    vapName      text NOT NULL,
    pmfEnable  integer NOT NULL,
    pmfRequire  integer NOT NULL
);

-- dot11Interface to bridge Mapping.
CREATE TABLE dot11InterfaceToBridge
(
    interfaceName text NOT NULL,
    bridgeInterface      text NOT NULL
);

--wifionoff table
CREATE TABLE dot11Wifi
(
    wifiOn integer NOT NULL
);

INSERT INTO "tableDefaults" VALUES('dot11Wifi','wifiOn','1','','');

CREATE TABLE sixToFourTunnel
    (
    tunnelStatus        integer NOT NULL,    -- enabled or disabled    
    LogicalIfName       text NOT NULL,       -- IPv4 interface to use
    interfaceName       text NOT NULL,       -- 6to4 interface name 
    localAddr           text NOT NULL,       -- local tunnel end-point   
    destAddr            text,                -- destination tunnel end-point
    PRIMARY KEY (LogicalIfName),
    FOREIGN KEY (LogicalIfName) REFERENCES networkInterface(LogicalIfName)
    );
insert into tableDefaults values ("sixToFourTunnel", "tunnelStatus", "1", "", "");
insert into tableDefaults values ("sixToFourTunnel", "LogicalIfName", "IF1", "", "");
insert into tableDefaults values ("sixToFourTunnel", "interfaceName", "bdg1", "", "");
insert into tableDefaults values ("sixToFourTunnel", "localAddr", "192.168.5.10", "", "");
insert into stringsMap values ("6TO4_TUNNEL_CONFIG_FAILED", "6 to 4 Tunnel Configuration Failed");    
--This table is not used anywhere
--CREATE TABLE sip
--(
--interfaceName text,
--ipaddr  text ,
--subnetmask  text ,
--PRIMARY KEY(interfaceName),
--FOREIGN KEY (interfaceName) REFERENCES networkInterface(interfaceName), 
--FOREIGN KEY (ipaddr) REFERENCES networkInterface(ipaddr), 
--FOREIGN KEY (subnetmask) REFERENCES networkInterface(subnetmask) 
--)
--;

CREATE TABLE SipStatusCtrl
(
    SipStatus boolean  NOT NULL, 
    PRIMARY KEY (SipStatus)
);

insert into dbUpdateRegisterTbl values ("UMI_COMP_PLATFORM",1,1,"SipStatusCtrl", 0, 1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_PLATFORM",0,0,"ifStatic", 0, 1,1,1);
insert into dbUpdateRegisterProgram values ("/pfrm2.0/bin/sipConfig",0,1,"SipStatusCtrl", 0, 1,1,0);
insert into dbUpdateRegisterProgram values ("/pfrm2.0/bin/sipConfig",0,1,"ifStatic", 0, 1,1,0);
insert into stringsMap values ("SIP_CONFIG_FAILED","SIP ALG Configuration failed");
CREATE TABLE isatapTunnel
    (
    isatapTunnelStatus  integer NOT NULL,
    isatapPrefix        text,    -- 64 bit ISATAP prefix
    useLanAddress       integer NOT NULL, -- use LAN address.
    localIPv4Address    text,    -- The IPV4 address to use as local endpoint
    isIsatapRouter      integer, -- Is this a ISATAP Router
    preferredRouter     text,    -- Preferred Router if this is a ISATAP host
    interfaceName       text,    -- tunnel interface name
    transportIfName     text NOT NULL, -- transport interface      
    PRIMARY KEY (isatapPrefix)
    );
insert into tableDefaults values ("isatapTunnel", "isatapTunnelStatus", "1", "", "");
insert into tableDefaults values ("isatapTunnel", "useLanAddress", "1", "", "");
insert into stringsMap values ("ISATAP_TUNNEL_DELETE_SUCCESS", "ISATAP Tunnel(s) Deleted Successfully");
insert into stringsMap values ("ISATAP_TUNNEL_DELETE_FAILED", "ISATAP Tunnel(s) Deletion Failed");
insert into stringsMap values ("ISATAP_TUNNEL_CONFIG_FAILED", "ISATAP Tunnel Configuration Failed");    
insert into stringsMap values ("ISATAP_TUNNEL_NET_ERROR", "ISATAP Tunnel Configuration not found");    
insert into stringsMap values ("ISATAP_TUNNEL_ERR_INVALID_PARAMS", "ISATAP Tunnel invalid parameters");    
insert into stringsMap values ("ISATAP_TUNNEL_CONN_ADD_FAILED", "ISATAP Tunnel connection add failed");    
insert into stringsMap values ("ISATAP_TUNNEL_ERR_DEL_PARAMS", "ISATAP Tunnel Delete failed");    
insert into stringsMap values ("ISATAP_TUNNEL_NET_DEL_FAILED", "ISATAP Tunnel network Delete failed");    
insert into stringsMap values ("ISATAP_TUNNEL_IP_DEL_FAILED", "ISATAP Tunnel IP Delete failed");    
insert into stringsMap values ("ISATAP_TUNNEL_CONN_ERROR", "ISATAP Tunnel Connection not found ");    
insert into stringsMap values ("ISATAP_TUNNEL_CONN_DEL_FAILED", "ISATAP Tunnel Connection Delete failed ");    
insert into stringsMap values ("ISATAP_ERR_QUERY_FAILED", "ISATAP Tunnels failed ");    
insert into stringsMap values ("ISATAP_TUNNEL_NET_ADD_FAILED", "ISATAP Tunnel Network Add failed ");    
create table eapAuthProfile
(
    profileName     text NOT NULL,
    outerEAP        integer NOT NULL,
    anonymousID     text,
    innerAuth       integer,
    userName        text,
    password        text,
    serverName      text
);

insert into stringsMap values ("EAPAUTH_CONFIG_FAILED","EAP Auth Configuration Failed");    
CREATE TABLE radiusClient
(
	authserver  text NOT NULL,
	authserverIP6  text,
	authport  integer NOT NULL,
	authsecret  text NOT NULL,
	authtimeout  integer NOT NULL,
	authretries  integer NOT NULL,
	acctserver  text ,
	acctserverIP6  text ,
	acctport  integer ,
	acctsecret  text ,
	secauthserver  text ,
	secauthserverIP6  text ,
	secauthport  integer ,
	secauthsecret  text ,
	secacctserver  text ,
	secacctserverIP6  text ,
	secacctport  integer ,
	secacctsecret  text ,
	ipType  integer NOT NULL,
        serverinuse integer,
    	authType integer,
    	radAccntEnable boolean,
    	interimUpdateInterval integer,
    	retryInterval integer,
	PRIMARY KEY (authserver)
)
;

CREATE TABLE radiusDas
(
	dasClient  text NOT NULL,
	dasServerPort  integer NOT NULL,
	dasSecret  text NOT NULL,
	dasTimeWindow  integer NOT NULL,
	dasRequireTimeStamp  integer NOT NULL,
    	dasRequireMsgAuth integer NOT NULL,
	PRIMARY KEY (dasClient)
)
;

CREATE TABLE radiusAttributes
(
    nasIdentifier text NOT NULL
)
;

insert into dbUpdateRegisterTbl values ("UMI_COMP_PLATFORM",0,1,"radiusClient", 0, 1,1,1);
insert into dbUpdateRegisterProgram values ("/pfrm2.0/bin/radiusConfig",0,1,"radiusClient", 0, 1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_EAP_RAD",1,1,"radiusClient", 0, 1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_FIREWALL",0,1,"radiusClient",0,1,1,1);

insert into stringsMap values ("RADIUS_CONFIG_FAILED","RADIUS configuration failed");

-- 
-- NAS component schema
--

--
-- This table holds information on all the NAS shares.
--
CREATE TABLE nasShare
(
	--objId integer primary key autoincrement,
	--objRevId integer NOT NULL,
	partitionId text NOT NULL,	
	name text UNIQUE NOT NULL,
    path text NOT NULL,
	description text,
	userOwner text,
	groupOwner text
	--FOREIGN KEY (partitionId) REFERENCES nasPartition(objId)
);

--
-- This table holds all possible protocols a NAS share is accessable
-- over. 
--
CREATE TABLE nasProtocol
(
	--objId integer primary key autoincrement,
	--objRevId integer NOT NULL,
	protocol text NOT NULL
);

insert into nasProtocol values ("ftp");
insert into nasProtocol values ("sftp");
insert into nasProtocol values ("nfs");
insert into nasProtocol values ("smb");
insert into nasProtocol values ("http");
insert into nasProtocol values ("afs");

--
-- This table holds a mapping between a NAS shares (many) and NAS
-- partitions (many).
--
CREATE TABLE nasShareProtocol
(
	protocol text NOT NULL,
	shareId text NOT NULL,
	FOREIGN KEY (protocol) REFERENCES nasProtocol(protocol),
	FOREIGN KEY (shareId) REFERENCES nasShare(name)
);

-- Maps the protocol and the binary
CREATE TABLE nasShareProtoBinMap
(
	protocol text NOT NULL,
	protoProgName text NOT NULL
);

-- Add NAS componet to dbUpdateRegisterTbl
insert into dbUpdateRegisterTbl values ("UMI_COMP_PLATFORM",1,1,"nasShare", 0, 1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_PLATFORM",1,1,"nasShareProtocol", 0, 1,1,1);

CREATE TABLE diskMgmtFolderInfo
(
        partId text NOT NULL,        -- device id such as sda1, sda2, etc.
        diskId text NOT NULL,        -- disk id to which this part belongs to.
        diskName text NOT NULL,      -- disk name
        folderPath text NOT NULL,    -- folder path
        folderEnable integer,         
        UserAccess integer NOT NULL  
);
--
-- diskMgmt component schema
--

--
-- This table holds volume information. If there is no RAID there
-- is a 1-1 mapping between a volume and a disk.
--

CREATE TABLE diskMgmtVolume
(
	uuid	 text,
	deviceId text unique,	-- device id such as sda, sbd, sdc, etc.
	--objId integer NOT NULL, 
	--objRevId integer NOT NULL,
	name text NOT NULL,	-- name consists of model and vendor name
	type text NOT NULL,	-- consists of usb, scsi, ide, etc.
	size text NOT NULL	-- size of disk
);

--
-- This table holds all possible format types for NAS device
-- partitions.
--
CREATE TABLE diskMgmtPartitionFSFormat
(
	fsFormat text unique	-- disk format
);

insert into diskMgmtPartitionFSFormat values ("ext2");
insert into diskMgmtPartitionFSFormat values ("ext4");
insert into diskMgmtPartitionFSFormat values ("ext3");
insert into diskMgmtPartitionFSFormat values ("fat16");
insert into diskMgmtPartitionFSFormat values ("fat32");
insert into diskMgmtPartitionFSFormat values ("ntfs");
insert into diskMgmtPartitionFSFormat values ("hfsplus");
insert into diskMgmtPartitionFSFormat values ("hfs+");
insert into diskMgmtPartitionFSFormat values ("hfsx");
insert into diskMgmtPartitionFSFormat values ("vfat");
insert into diskMgmtPartitionFSFormat values ("exfat");

--
-- This table holds configuration information for all the
-- partitions.
CREATE TABLE diskMgmtPartition
(
	partId text primary key,	-- device id such as sda1, sda2, etc.
    diskId text NOT NULL,       -- disk id to which this part belongs to.
	--objId integer NOT NULL,
	--objRevId integer NOT NULL,
	name text NOT NULL,		    -- Human readable name
	partFSFormat text NOT NULL,	-- file system format.
	--size integer NOT NULL,
	status integer,
	mntDir text NOT NULL,		-- mount dir for partition
    timeStamp text,             -- used to indicate when a particular device
                                -- use this partition info.
	FOREIGN KEY (partFSFormat) REFERENCES diskMgmtPartitionFSFormat(fsFormat)
);


CREATE TABLE diskMgmtQuotas
(
	username	text NOT NULL,
	userType	integer,
	diskLimit	integer,
	FOREIGN KEY (username) REFERENCES users(username)
);
-- smbMgmt.sql - contains sql table and query for smb protocol

-- Copyright (c) 2008, TeamF1, Inc.

-- modification history
-- --------------------
-- 01b,07oct10,pnm  removed insert into the global table.
-- 01a,22sep08,pnm  written.

-- DESCRIPTION


-- INCLUDES

--
-- Global SAMBA configuration. This table holds SAMBA configuration
-- information that is applicable to the entire system. This table
-- should have only one row.
--
CREATE TABLE smbGlobalConfig
(
	--objId integer primary key autoincrement,
	--objRevId integer NOT NULL,
	serverName          text    NOT NULL,
	domainOrWorkgroup   text    NOT NULL,
    serverEnable        integer         ,
    LogicalIfName       text
);

--
-- Share-specific SAMBA config. This table holds SAMBA configuation
-- information that is in addition to the SAMBA configuration that can
-- be derived from the share configuration itself.
--
--CREATE TABLE nasShareSMBConfig
--(
--	objId integer primary key autoincrement,
--	objRevId integer NOT NULL,
--	shareId integer NOT NULL,
--	forceCreateMode integer,
--	forceDirectoryMode integer,
--	FOREIGN KEY (shareId) REFERENCES nasShare(objId)
--);

-- Add smb componet to dbUpdateRegisterTbl
insert into dbUpdateRegisterTbl values ("UMI_COMP_PLATFORM",1,1,"smbGlobalConfig", 0, 1,1,1);
/* mediaServerMgmt.sql - contains SQL statements for media server */

/* Copyright (c) 2010, TeamF1 Inc. */

/* modification history
 * --------------------
 * 01a,08mar10,pnm  written.
 */

/* DESCRIPTION
 * This file contains SQL statements for running media server.
 */

-- Table Create
-- This table contains global information for the media server. This table
-- will have entry in the default configuration file. The only operation taken
-- on this table is update.
CREATE TABLE mediaServerGlobalCfg
(
    serverEnable    BOOL NOT NULL,     -- True - enable, false - disable
    allMediaType    BOOL NOT NULL,      -- True - create config for all media type
                                    -- False - specify media type
    dbDir           text,
    friendlyName            TEXT NOT NULL,    
    LogicalIfName   text
);

-- This table contains information about the media server shares. A share here
-- can be deleted, created, or updated. A share must have at least one of the
-- share type (pictures, music or video) selected.
CREATE TABLE mediaServerShares
(
    shareName TEXT NOT NULL UNIQUE, -- Share name
    pictures BOOL NOT NULL,         -- share pictures on this share
    video BOOL NOT NULL,            -- share videos on this share
    music BOOL NOT NULL             -- share music on this share
);
CREATE TABLE CaptivePortalSession
(
    UserName                text            NOT NULL,     
    ipAddr                  text            NULL,
    macAddr                 text            NULL,
    idleTimeout             integer         NULL,
    ifName                  text            NOT NULL,   -- FALSE-Singlelogin TRUE-multilogin
    PRIMARY KEY (UserName,macAddr)
    UNIQUE (ipAddr)
);

CREATE TABLE captivePortalCookie
 (
    cookie                  text            NULL,
    UserName                text            NULL
 )
 ;

CREATE TABLE CaptivePortal
(
    enable 	Boolean NOT NULL 
);

CREATE TABLE CaptivePortalVlan
(
    vlanId            integer   NOT NULL,
    ifName	      text      NOT NULL,
    accessType	      integer   NOT NULL, --1=SLA 2=Permanent 3=Temporary
    authServerId      integer   NULL,
    profileId         integer   NULL,     -- Login Profile Id
    redirectType      integer   NOT NULL
);

CREATE TABLE authServers
(
    authServerId            integer   NOT NULL,
    authServerName	    text      NOT NULL
);

-- Header background image table
CREATE TABLE ImageDetails
(
    name     text NOT NULL,
    value    Boolean NOT NULL
);

-- This is a page backgroud image table.
CREATE TABLE pageBackgroundImage
(
            imageName     text NOT NULL,
            enableStatus  Boolean NOT NULL
        );

CREATE TABLE CaptivePortalPageDetails
(
    profileId                  integer    PRIMARY KEY AUTOINCREMENT, -- Login Profile Id
    configurationName          text       NULL,
    title                      text       NULL,
    BackGroundColor            text       NULL,
    CustomColor                text       NULL,
    headerImage                text       NULL, -- header background image.
    pageBackgroundImgConfigRow integer    NULL, -- page background image.
    pageBackgroundStyleSelector integer   NULL, -- page background style selector image/user color.
    headerBackground           text       NULL,
    headerBackColor            text       NULL,
    headerCustomColor          text       NULL,
    headerFont                 text       NULL,
    headerFontSize             integer    NULL,
    headerCaption              text       NULL,
    headerFontColor            text       NULL,
    LoginBoxTitle              text       NULL,
    welcomeMessage             text       NULL,
    errorMessage               text       NULL,
    messagesFontColor          text       NULL, 
    AdEnable                   text       NULL,
    AdContent                  text       NULL,
    AdPlace                    text       NULL,
    AdFont                     text       NULL,    
    AdFontSize                 integer    NULL,
    AdFontColor                text       NULL,
    FooterEnable               text       NULL,
    FooterContent              text       NULL,
    FooterFontColor            text       NULL
);


Create table tempCPUserProfiles
(
ProfileId		Integer NOT NULL PRIMARY KEY AUTOINCREMENT, -- Billing ProfileId
ProfileName		text	NOT NULL ,
ProfileDesc		text    NOT NULL,
MultiLogin		Boolean	NOT NULL,
ModifyAccount		Boolean NOT NULL,
BatchGen		Boolean NOT NULL,
IdleTimeout 		Integer NOT NULL, -- Minutes
ShowAlert		Boolean NOT NULL, -- 0=No Alert 1=Show Alert
AlertType		Integer NOT NULL, -- 0=Hour, 1=Day, 2=MB, 3=GB
AlertValue		Integer NULL,	  -- may be Hours/Days/MB/GB depending on AlertType
ValidDurationCheck	Boolean NOT NULL, 
ModifyDuration		Boolean NULL,	  -- 1=Modify on frontdesk
DurationType		Integer NULL,     -- 0=Account Created, 1=Account Login, 2=Begin From
StartTimeType		Boolean NULL,	  -- 0=Hours, 1=Days
StartTimeValue		Integer	NULL,     -- Hours (field will be nill for DurationType=2)
BeginDate		text	NULL,    -- format "YYYY/MM/DD@HH:MM" (field will be nill for ValidBegin=0 & 1)
ModifyUsage		Boolean NULL,	 -- 1=Modify on frontdesk
MaxUsageTimeCheck	Boolean NOT NULL, 
MaxUsageTimeType	Boolean NULL,     -- 0=Hours, 1=Days
MaxUsageTimeValue	Integer	NULL,     -- in Hours EDITABLE
MaxUsageTrafficCheck	Boolean NOT NULL,
MaxUsageTrafficType	Boolean NULL,	  -- 0=MB, 1=GB 
MaxUsageTrafficValue	Integer NULL,      -- in MB EDITABLE
UNIQUE (ProfileName)
);


CREATE TABLE CPAccConf(
	UserName text NOT NULL,
	BeginEndTimeCheck integer NOT NULL,
	SessionIdealTimeout integer NOT NULL,
	StartTime text NOT NULL, --YYYY/MM/DD@HH:MM 
	EndTime   text NOT NULL, --YYYY/MM/DD@HH:MM
	LoginCheck integer NOT NULL,
	MaxUsageTime integer NOT NULL,
	MaxUsageTraffic text NOT NULL
);

CREATE TABLE CPAccUserAccountExtend(
	UserName text NOT NULL,
	extendTimeUsage integer NOT NULL,
	extendTrafficUsage text NOT NULL,
	extendEndTime text NOT NULL
);

insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM', 0, 1, 'CPAccConf', 0, 0, 1, 1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM', 0, 0, 'CaptivePortalSession', 0, 0, 1, 1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM', 0, 0, 'CPAccUserAccountExtend', 0, 1, 1, 0);
insert into dbUpdateRegisterProgram values ('/pfrm2.0/bin/captivePortalAcc', 0, 1, 'CPAccConf', 0, 0, 1, 1);
--insert into dbUpdateRegisterProgram values ('/pfrm2.0/bin/CPAccSessionUpdate', 0, 0, 'CaptivePortalSession', 0, 0, 1, 1);
--insert into dbUpdateRegisterProgram values ('/pfrm2.0/bin/CPAccSessionExtend', 0, 0, 'CPAccUserAccountExtend', 0, 1, 1, 0);
insert INTO dbUpdateRegisterTbl VALUES ("UMI_COMP_PLATFORM", 0, 1, "CaptivePortal", 0, 1, 1, 0);
insert into dbUpdateRegisterTbl values ("UMI_COMP_CAPTIVEPORTAL", 0, 0, "CaptivePortalSession", 0, 1, 1, 1);
insert into tableDefaults values ("CaptivePortalPageDetails", "LoginBoxTitle", "CAPTIVE PORTAL LOGIN", "", "");
insert into tableDefaults values ("CaptivePortalPageDetails", "welcomeMessage", "Please Login!", "", "");
insert into tableDefaults values ("CaptivePortalPageDetails", "errorMessage", "Invalid UserName/Password", "", "");
insert into tableDefaults values ("CaptivePortalVlan", "redirectType", "2", "", "");
insert into tableDefaults values ("tempCPUserProfiles", "AlertValue", "0", "", "");
insert into tableDefaults values ("tempCPUserProfiles", "IdleTimeout", "10", "", "");
insert into tableDefaults values ("tempCPUserProfiles", "DurationType", "0", "", "");
insert into stringsMap values ("CAPTIVE_PORTAL_CONF_ERROR", "Portal Configuration not found.");    
insert into stringsMap values ("CAPTIVE_PORTAL_CONF_FAILED", "Portal Configuration failed");    
insert into stringsMap values ("SESSION_IN_PROGRESS", "Portal Session in progress");    
insert into stringsMap values ("LOGGED_IN_SUCCESS", "Portal Login Successfully ");    
insert into stringsMap values ("AUTH_METHOD_NOT_SUPPORTED", "Authentication Method not supported");    
insert into stringsMap values ("USER_ACESS_NOT_SPPORTED", "User Access not supported");    
insert into stringsMap values ("CAPTIVE_PROFILE_ADD_FAILED", "Portal Profile Add failed");    
insert into stringsMap values ("DEFAULT_CAPTIVE_PORTAL_PROFILE_CAN_NOT_EDIT", "Default portal profile can not be edited");    
insert into stringsMap values ("CAPTIVE_PROFILE_EDIT_FAILED", "Portal profile Edit failed");    
insert into stringsMap values ("CAPTIVE_PORTAL_CONF_NOT_EXIST", "Portal profile configuration not found");    
insert into stringsMap values ("CAPTIVE_PORTAL_PROFILE_DEL_FAILED", "Portal Profile Delete failed");    
insert into stringsMap values ("DEFAULT_CAPTIVE_PORTAL_PROFILE_CAN_NOT_DELETE", "Default Profile cannot be deleted");    
insert into stringsMap values ("CAPTIVE_PORTAL_PROFILE_IN_USE", "Portal Profile in use");    
insert into stringsMap values ("CAPTIVE_PORTAL_PROFILE_GET_FAILED", "Portal Profile get failed");    
insert into stringsMap values ("CAPTIVE_PORTAL_CONF_GET_FAILED", "Portal configuration get failed");
insert into stringsMap values ("CAPTIVE_PROFILE_WITH_SAME_NAME_EXIST", "Profile with same name exists");
CREATE TABLE qosProfile
	(
	ProfileKey					integer NOT NULL,
	ProfileName					text    NOT NULL,
	BandwidthProfileStatus		integer         ,
	
	PRIMARY KEY(ProfileKey)
	);

-- This table defines the per interface global configuration.
-- This will be part of the networInterface table in future
-- 
CREATE TABLE qosQueueManagement
	(
	InterfaceName			    text NOT NULL,  -- LogicalIfName
	Enable                      integer,
	ProfileKey				    integer,
    MeasureBandwidth            integer,        --  0 = dynamic measurement disable
                                                --      use statically configured 
                                                --      values
                                                --  1 = dynamic measurement enable
	UpstreamBandwidth		    integer,        -- upstream bandwidth in kbps
	DownstreamBandwidth		    integer,        -- downstream bandwidth in kbps
    

	-- Add interface defaults here..

	PRIMARY KEY(InterfaceName)
	);

-- This table defines CoS -> XXX mappingCREATE table cosMarkMap
CREATE TABLE cosMarkMap
	(
    cosNum      integer NOT NULL,	-- CoS value, -1 indicates wildcard.
    cos         integer,
    ethQueue    integer,
    dscp        integer,
    wmm         integer,
    PRIMARY KEY (cosNum)
    );

-- This table defines DSCP -> XXX mapping
CREATE TABLE dscpMarkMap
    (
    dscpNum     integer NOT NULL,	-- DSCP value, -1 indicates wildcard
    dscp        integer,
    wmm         integer,
    ethQueue    integer,
    cos         integer,
    PRIMARY KEY (dscpNum)
    );

-- This table defines WMM -> XXX mapping
CREATE TABLE wmmMarkMap
    (
    wmmNum      integer NOT NULL,	 -- WMM
    dscp        integer,
    wmm         integer,
    ethQueue    integer,
    cos         integer,
    PRIMARY KEY (wmmNum)
    );

-- This table represents all the classification rules that can
-- be added
CREATE TABLE qosClassification	
	(
	ClassificationKey	integer NOT NULL,	
	ClassificationEnable 	boolean,
	ClassificationOrder  	integer,
	ProfileKey				integer,
	ClassInterface       	text,	 -- egress interface
	DestIP               	text,	
	DestIPRangeMax			text,
	DestMask         	text,
	DestIPExclude   	boolean,
	SourceIP       		text,
	SourceIPRangeMax	text,
	SourceMask     		text,
	SourceIPExclude		boolean,
	Protocol      		integer,
	ProtocolExclude		boolean,
	DestPort      		integer,
	DestPortRangeMax 	integer,
	DestPortExclude 	boolean,
	SourcePort     		integer,
	SourcePortRangeMax	integer,
	SourcePortExclude	boolean,
	SourceMACAddress	text,
	SourceMACExclude	boolean,
	DestMACAddress 		text,
	DestMACExclude		boolean,
	DSCPCheck    		integer,
	DSCPExclude 		boolean,
	DSCPMark   		integer, -- DSCP to mark traffic with that falls into this
					 -- classification entry. A value of -1 indicates no change from the
					 -- incoming packet.  A value of -2 indicates automatic marking of DSCP
					 -- based upon the EthernetPriority value of the incoming packet 
	EthernetPriorityCheck 	integer,
	EthernetPriorityExclude	boolean,
	EthernetPriorityMark  	integer, -- Ethernet priority code (as defined in 802.1D) to
					 -- mark traffic with that falls into this classification
					 -- entry. A value of -1 indicates no change from the
					 -- incoming packet. A value of -2 indicates automatic marking of
					 -- EthernetPriority based upon the DSCP value of the
					 --  incoming packet
	VLANIDCheck          	integer,
	VLANIDExclude       	boolean,

	ForwardingPolicy   	integer,   -- -1 to disable fast forwarding
	OutOfBandInfo		integer, 	-- Allows traffic to be distinguished based on out-of-
					-- band information such as physical port or
					-- application ID. Primarily intended for, but not
					-- restricted to, locally sourced traffic
	QueueKey		integer, -- QueueKey in qosClassQueue table
	Service 		text,  -- firewall service name this rule uses	
    IngressInterface    text,
    L3Protocol      integer,    -- 0=All, 1 = IPv4, 2 = IPv6,
	ConfigDefault		text, -- = 1 , then this is configuration default
	PRIMARY KEY(ClassificationKey)
	);

-- This table represents qdiscs and class 
-- configuration. For each tc rule that we
-- generate we will have one row in this table.
CREATE TABLE qosClassQueue
	(
	QueueKey			integer	 NOT NULL,
	QueueName			text,
	ProfileKey			integer,

	ParentId			text,  --  parent
	QueueId				text,  --  handle/classId or queueId
	QueueLevel			integer,
	QueueEnabled		integer,
	ConfigDefault		text, -- = 1 , then this is configuration default
	
	QosEleType			integer	 NOT NULL,

	QosClassType		integer,

    RateUnitType        integer,   -- 1=kbps 2=percentage

	-- HTB Class params
	HTBClassPrecedence	integer,
    HTBShapingRate		integer,
    HTBShapingRateMax	integer,
	HTBShapingBurstSize	integer,
	
	QosQdiscType		integer,

	-- SFQ Qdisc params
	SFQQuantum			integer,
	SFQPerturb			integer,

	-- FIFO Qdisc params
	FIFOLimit			integer,

	-- HTB Qdisc params
	HTBDefaultClass		integer,

	-- RED Qdisc params
    REDmin				integer,
    REDmax				integer,
	REDprobability		integer,
	REDlimit			integer,
	REDburst			integer,
	REDavpkt			integer,
	REDbandwidth		integer,
	REDlatency			integer,

	PRIMARY KEY(QueueKey)
	);

CREATE TABLE qosGlobalCfg
	(
	Dot1pRemarkStatus			integer , 
    MeasureBwOnStart            integer , 
    MaxUpstreamBwPercentage     integer    -- Max upstream bandwidth %
	);

CREATE TABLE qosBwMtrConf
    (
    TestUrl                     text     ,
    Username                    text     ,
    Password                    text     ,
    TmpDir                      text     ,       
    Testfile                    text     , -- abs path of the test file on the device
    Testfilesize                integer  ,
    Remotefile                  text     , -- file name of the remote file on the server
    TestType                    integer  , -- 1 = upload,2 = download,3 = both
    InitScr                     text     , -- initialization script
    DeinitScr                   text     , -- de-initialisation script
    LogicalIfName               text     ,    
    MeasureBandwidth            integer    --  0 = dynamic measurement disable
    );

insert into compFacilityMap values ("UMI_COMP_QOS", 20);

insert into dbUpdateRegisterTbl values ("UMI_COMP_QOS", 0, 0, "qosBwMtrConf", 0, 1, 0, 0);
insert into dbUpdateRegisterTbl values ("UMI_COMP_QOS", 0, 0, "qosGlobalCfg", 0, 1, 1, 1);

-- Listen for network  going up/down
insert into ifDevEventTbl values ("ALL",  8, "UMI_COMP_QOS", "NULL", "qos");
insert into ifDevEventTbl values ("ALL",  9, "UMI_COMP_QOS", "NULL", "qos");
insert into ifDevEventTbl values ("ALL",  10, "UMI_COMP_QOS", "NULL", "qos");
insert into ifDevEventTbl values ("ALL",  11, "UMI_COMP_QOS", "NULL", "qos");

-- Stringmap entries
insert into stringsMap values ("BWPROF_PROFILE_EXISTS","Configured Bandwidth Profile already exists.");
insert into stringsMap values ("BWPROF_IN_USE","Selected Bandwidth Profile is in use.");
insert into stringsMap values ("BWPROF_IF_DISABLE_FAILED","Bandwidth Profile Failed");
insert into stringsMap values ("BWPROF_INPUT_INVALID","Invalid Input for Bandwidth Profile ");
insert into stringsMap values ("BWPROF_ERR_DB_BUSY","Bandwidth Profile Database Busy.");
insert into stringsMap values ("BWPROF_CLASSID_CREATE_FAILED","ClassId creation for Bandwidth Profile failed.");
insert into stringsMap values ("BWPROF_ID_INVALID","Id of Bandwidth Profile is invalid.");
insert into stringsMap values ("BWPROF_NOT_FOUND","Bandwidth Profile Not found.");
insert into stringsMap values ("BWPROF_ERR_IFNAME_NOT_FOUND","Interface Name not found");
insert into stringsMap values ("BWPROF_PROFILE_IN_USE","Selected Bandwidth Profile is in use.");
insert into stringsMap values ("TRAF_SEL_INVALID_INPUT","Invalid Input For Traffic Selector.");
insert into stringsMap values ("QOS_ERR_RATE_LIMIT_SET_INVALID_ARGS","Rate Limit invalid Arguments.");
insert into stringsMap values ("QOS_ERR_GLOBAL_CFG_GET","Global Configuration Get failed.");
CREATE TABLE swGlobalCfg
	(
	switchName					text,
	switchDevice				text,
	qosEnable					integer,
    vlanEnable                  integer,
    pauseFrameEnable            integer,
    igmpSnoopingEnable          integer,
    mldSnoopingEnable           integer,
    numPorts					integer,
    switchLevel                 integer
	);

CREATE TABLE swPortConfig
    (
    switchName         text    NOT NULL,  
    portNumber         integer NOT NULL,
    PVID               integer NOT NULL,
    portStatus         integer NOT NULL, -- (enable/disable)
    portType           integer NOT NULL, -- (phy or mac)
    portMode           integer NOT NULL,
    interfaceName      text, 
    mirroring          integer ,
    trustMode          integer ,
    phyDevice          text ,  -- comma separate list of phy <switchname:portnumber>
    rateLimit          integer,
    schedMode          integer,
    numQueues          integer,
    queue1Weight       integer, 
    queue2Weight       integer, 
    queue3Weight       integer, 
    queue4Weight       integer, 
    PRIMARY KEY (switchName, portNumber),
    FOREIGN KEY (switchName) REFERENCES swGlobalCfg(switchName)
    );

CREATE TABLE vlanEncapIf
    (
    vlanId          integer   NOT NULL,   --  vlanID (Range: 1-4094)
    vlanName        text      NOT NULL,   --  vlan Name 
    interfaceName   text      NOT NULL,   --  underlying interface  
	ingressMap		text			  ,   --  inbound packets qos map				
	egressMap		text			  ,   --  outbound packets qos map
    fwdMap          text              ,   -- (comma separated list of port members of the underlying interface)
    untagMap        text              ,   -- (comma separated list of port members of the underlying interface)
    inSwitchOnly    integer           ,   -- to create vlan only in switch.
    LogicalIfName   text      NOT NULL,   -- Logical Network to which interface belongs
    PRIMARY KEY (vlanId, interfaceName)
    );

create table vlanMembershipPort
(
    PortEnable integer
);

--TODO: 
--=====
-- - igmp/mld snooping, set/unset pause frames, switch port statistics, port speed, duplex settings
-- - How do we represent QoS policies that we want configuring in the switch (e.g marking 802.1p, 
-- - Is scheduling per port ?
-- - Are hardware queues per port ?
-- - Is it appropriate to have a filtering/marking table per switch to define artibtrary rules ?
-- switchdevice Table
--

CREATE TABLE SwitchDevice
(
    OID               integer   NULL,
    SwitchDeviceName  text      NOT NULL,
	PRIMARY KEY (SwitchDeviceName)
)
;

CREATE TABLE portStats
(
OID integer NULL,
portId  integer,
TxBytes NUMERIC DEFULT ZERO,
TxDropPkts NUMERIC DEFULT ZERO,
TxFrames NUMERIC DEFULT ZERO,
RxBytes NUMERIC DEFULT ZERO,
RxDropPkts NUMERIC DEFULT ZERO,
RxFrames NUMERIC DEFULT ZERO,
PRIMARY KEY(portId)
)
;

-- PowerModeConf - table for power mode configuration
CREATE TABLE PowerModeConf
    (
    PowerMode  Boolean NOT NULL,         -- triggers the backend, set power mode
    LengthMode Boolean NOT NULL         -- triggers the backend, set length mode
    );

--table for jumbo frames
create table jumbo
(
status boolean
);

INSERT INTO dbUpdateRegisterTbl VALUES ("UMI_COMP_PLATFORM", 0, 1, "PowerModeConf", 0, 1, 1, 0);
INSERT INTO dbUpdateRegisterTbl VALUES ("UMI_COMP_PLATFORM", 0, 1, "jumbo", 0, 1, 1, 0);
INSERT INTO dbUpdateRegisterProgram VALUES ("/pfrm2.0/bin/powerModeConfig", 1, 1, "PowerModeConf", 0, 1, 1, 0);
INSERT INTO dbUpdateRegisterProgram VALUES ("/pfrm2.0/bin/jumboFramesConfig", 1, 1, "jumbo", 0, 1, 1, 0);



CREATE TABLE crontab
(
    unit        integer NOT NULL,
    interval    integer,
    minute      integer,
    hour        integer,
    dayOfMonth  integer,
    month       integer,
    dayOfWeek   integer,
    command     text
);
insert into tableDefaults values ("crontab","unit","0","","");
insert into tableDefaults values ("crontab","interval","0","","");
insert into tableDefaults values ("crontab","minute","0","0","59");
insert into tableDefaults values ("crontab","hour","-1","","");
insert into tableDefaults values ("crontab","dayOfMonth","-1","","");
insert into tableDefaults values ("crontab","month","-1","","");
insert into tableDefaults values ("crontab","dayOfWeek","-1","","");
insert into dbUpdateRegisterTbl values ("UMI_COMP_CRON",1,1,"crontab", 0,1,1,1);

insert into stringsMap values ("CRONTAB_CONFIG_FAILED","Crontab configuration failed");

--
-- This file includes IPv6 Rip component related Tables like -
--
--  1. Ripng

CREATE TABLE Ripng
(

	RipngEnable 	integer	NOT NULL  -- 0(Disabled), 1(Enabled)
                                                 
)
;


insert into stringsMap values ("RIPNG_CONFIG_FAILED","RIPNG Configuration Failed");	
insert into tableDefaults values ("RIPNG", "RipngEnable", "0", "", "");
CREATE TABLE easyMesh
(
    meshEnable integer NOT NULL,
    meshInterfacename text  NULL,
    wifiOn integer NOT NULL
)
;

CREATE TABLE easyMeshDevices
(
    macAddr 	text NOT NULL,
    deviceName 	text NULL,
    PRIMARY KEY (macAddr)
)
;

CREATE TABLE easyMeshBhInfo
(
    parenrtApMacAddr 	text,
    deviceName 	        text,
    deviceRole          integer NOT NULL,
    bhConnectionState   integer NOT NULL,
    uplinkType          text,
    rssi                integer
)
;
CREATE TABLE tcpdump
(
    interfaceName text NOT NULL,
    tcpdumpEnabled  boolean NOT NULL,
    phyInterface  text NOT NULL,
    FOREIGN KEY (interfaceName) REFERENCES networkInterface(interfaceName)
)
;

insert into tableDefaults values ("tcpdump","tcpdumpEnabled","0","0","1");
insert into dbUpdateRegisterTbl values ("UMI_COMP_PLATFORM",1,1,"tcpdump", 0, 1,1,0);
insert into stringsMap values("TCPDUMP_CONFIG_FAILED","TCPDUMP Configuration Failed");
insert into stringsMap values("TCPDUMP_IFACE_DOWN","The interface selected is down");
CREATE TABLE radvd
    (
    isEnabled            bool            , --  radvd enabled
    useDHCP6sPrefixes    bool            , --  use prefixes from upstream   
    UnicastOnly          integer         , --  unicast only !
    MaxRtrAdvInterval    integer         , --  router advertisement interval   
    MinRtrAdvInterval    integer         , --  router advertisement min interval
    AdvReachableTime     integer         , --  router advertisement reachable time
    AdvRetransTimer      integer         , --  router advertisement retrasmission timer
    AdvCurHopLimit       integer         , --  router advertisement hop limit
    AdvMobileAgentFlag   bool            , --  router advertisement mobile agent flag
    AdvLinkMTU           integer         , --  Link MTU
    AdvManagedFlag       integer         , --  Use stateful protocol for 
                                           --  address assignment.
    AdvOtherConfigFlag   integer         , --  Other configuration flag
    AdvDefaultLifetime   integer         , --  default router lifetime
    AdvDefaultPreference integer         , --  router preference  
    LogicalIfName        text            , --  interface on which to run.
    FOREIGN KEY (LogicalIfName) REFERENCES networkInterface (LogicalIfName)    
    );

CREATE TABLE radvdLANPrefixPool
    (
    LogicalIfName           text        ,
    Enable                  boolean     ,
    radvdPrefixType         integer     ,  --  6to4 or Others    
    Base6to4Interface       text        ,  --  6to4 Interface name.    
    SLAIdentifier           text        ,  --  SLA Identifier. 
    radvdAdvPrefix          text        ,  --  radvd advertisement prefix
    radvdAdvPrefixLength    integer     ,  --  radvd prefix length   
    radvdAdvPrefixLifetime  integer        --  radvd prefix lifetime   
    );

insert into tableDefaults values ("radvdLANPrefixPool", "Enable", "1", "", "");

insert into stringsMap values ("RADVD_CONFIG_FAILED", "RADVD Configuration Failed");
insert into stringsMap values ("RADVD_PREFIX_CONFIG_FAILED", "RADVD Prefix Configuration Failed");
insert into stringsMap values ("RADVD_PREFIX_DELETE_FAILED", "RADVD Prefix Deletion Failed");    
insert into stringsMap values ("RADVD_PREFIX_EXISTS", "Configured Prefix/SLA ID already exists");    
CREATE TABLE httpsMgmt
(
    httpsMgmtEnable  integer NOT NULL,
    httpsMgmtPort integer NOT NULL,
    httpsMgmtIP1  text,
    httpsMgmtIP2  text,
    httpsMgmtAccessType integer NOT NULL,
    certEvent integer
);
insert into dbUpdateRegisterTbl values ("UMI_COMP_PLATFORM",1,1,"httpsMgmt", 0, 1,1,1);
insert into dbUpdateRegisterProgram values ("/pfrm2.0/bin/httpsConfig",0,1,"httpsMgmt", 0, 1,1,1);
--
-- This file includes Rip component related Tables like -
--
--  1. Rip

CREATE TABLE Rip
(
	Direction	    		  integer	NOT NULL, -- 0(none), 1(In only), 2(Out only),
                                                  -- 3(Both)

	Version			    	  integer	NOT NULL, -- 0(Disabled), 1(Rip1), 
                                                  -- 2(Rip2B(Broadcast)), 
                                                  -- 3(Rip2M(Multicast))
        interfaceObject                   text,
    AuthenticationType		  integer	NOT NULL, -- 0(No), 1(Yes)
	FirstKeyId			      integer	NULL,     -- MD5 first Key ID		
	FirstAuthenticationKeyId  text 		NULL,	  -- Password
	FirstKeyFrom			  text		NULL,	  -- Starting Date		
	FirstKeyTo			      text		NULL,	  -- Ending Date
	SecondKeyId			      integer	NULL,     -- MD5 second Key ID		
	SecondAuthenticationKeyId text 		NULL,     -- Password
	SecondKeyFrom			  text		NULL,	  -- Starting Date	
	SecondKeyTo			      text		NULL	  -- Ending Date
)
;


insert into stringsMap values ("RIP_CONFIG_FAILED","RIP Configuration Failed");	
insert into tableDefaults values ("RIP", "Direction", "0", "", "");
insert into tableDefaults values ("RIP", "Version", "0", "", "");
insert into tableDefaults values ("RIP", "AuthenticationType", "0", "", "");
CREATE TABLE ndppd
    (
    ndppdStatus            bool             --  ndppd status
    );
-- SQL table for PPTP back-end component.

-- Pptp table
CREATE TABLE Pptp
    (
    OID                      integer,           -- OID
    LogicalIfName            text     NOT NULL, -- interface names like 'lan1', 'wan2', etc.
    IspName                  integer,           -- name of the service provider
    UserName                 text     NOT NULL, -- user name
    Password                 text     NOT NULL, -- password
    GetIpFromIsp             boolean  NOT NULL, -- will ISP give IP ?
    GetDnsFromIsp            boolean  NOT NULL, -- do we need DNS from ISP ?
    MyIp                     text,              -- local IP of the wan interface
    ServerIp                 text     NOT NULL, -- PPTP server's IP
    StaticIp                 text,              -- ip which we want to assign or negotiate
    NetMask                  text,              -- net mask for the above IP
    Gateway                  text,              -- Gateway to reach the PPTP Server
    PrimaryDns               text,              -- if we want to specify our DNS
    SecondaryDns             text,              -- if we want to specify our DNS
    IdleTimeOutFlag          boolean  NOT NULL, -- do we require idle timeout ?
    IdleTimeOutValue         integer  NOT NULL, -- idle timeout value
    MppeEncryptSupport       boolean  NOT NULL, -- Mppe encryption support
    SplitTunnel              boolean  NOT NULL, -- Split tunnel option
    DualAccess               boolean  NOT NULL, -- PPTP or Dual Access PPTP
    Mtu                      integer,    
    -- add your new entries here

    PRIMARY KEY (LogicalIfName),                -- primary key
    FOREIGN KEY (LogicalIfName) REFERENCES networkInterface (LogicalIfName)
    );


-- SQL table for pptp vpn client back-end component.

-- pptpClient table
CREATE TABLE pptpClient
(
    OID                 	integer,             -- OID
    pptpClientEnable   		boolean    NOT NULL, -- enable/disable pptp vpn client
    ServerIp        		text       NOT NULL, -- PPTP server's IP
    RemoteNetwork       	text       NOT NULL, -- Network Address of network remote to pptp vpn client
    RemoteNetmask        	integer    NOT NULL, -- Subnet Mask of network remote to pptp vpn client
    UserName      		    text       NOT NULL, -- username allocated to client
    Password       		    text       NOT NULL, -- password allocated to client
    MppeEncryptionEnable	boolean	   NOT NULL, -- to enable mppe encryption
    IdleTimeOut      		integer    NOT NULL, -- time out value
    ClientIp                text        
    -- add your new entries here	
); 


-- SQL table for pptp vpn client connection status.

-- pptpClientConnectionStatus table
CREATE TABLE pptpClientConnectionStatus
(
    OID                     integer,              -- OID  
    connectionStatus        integer     NOT NULL, -- show status of connection
    actionStatus            boolean     NOT NULL, -- action allowed or not
    action                  boolean     NOT NULL  -- action (connect/drop)
    -- add your new entries here	
);
-- SQL table for PPPoE back-end component.

-- Pppoe table
CREATE TABLE Pppoe
    (
    OID                      integer,           -- OID
    LogicalIfName            text     NOT NULL, -- interface names like 'lan1', 'wan2', etc.
    IspName                  integer,           -- name of the service provider
    UserName                 text     NOT NULL, -- user name
    Password                 text     NOT NULL, -- password
    AccountName              text,              -- account name used in PPPoE
    DomainName               text,              -- domain name used in PPPoE
    GetIpFromIsp             boolean  NOT NULL, -- will ISP give IP ?
    GetDnsFromIsp            boolean  NOT NULL, -- do we need DNS from ISP ?
    StaticIp                 text,              -- ip which we want to assign or negotiate
    NetMask                  text,              -- net mask for the above IP
    PrimaryDns               text,              -- if we want to specify our DNS
    SecondaryDns             text,              -- if we want to specify our DNS
    IdleTimeOutFlag          boolean  NOT NULL, -- do we require idle timeout ?
    IdleTimeOutValue         integer  NOT NULL, -- idle timeout value
    ProfileName              text,    
    ServiceName              text,    
    -- add your new entries here
    AuthOpt                  integer  NOT NULL, -- can be NO-AUTH,PAP,CHAP,MS-CHAP,MS-CHAPV2    
    Mtu                      integer,

    PRIMARY KEY (LogicalIfName),                -- primary key
    FOREIGN KEY (ProfileName) REFERENCES PppoeProfile (ProfileName),
    FOREIGN KEY (LogicalIfName) REFERENCES networkInterface (LogicalIfName)
    );


CREATE TABLE PppoeProfile
    (
    ProfileName              text     NOT NULL, -- Name of the profile
    Status                   boolean  NOT NULL, -- enable/disable the profile.
    AuthOpt                  integer  NOT NULL, -- can be NO-AUTH,PAP,CHAP,MS-CHAP,MS-CHAPV2    
    UserName                 text     NOT NULL, -- user name
    Password                 text     NOT NULL, -- password
    IdleTimeOutFlag          boolean  NOT NULL, -- do we require idle timeout ?
    IdleTimeOutValue         integer          , -- idle timeout value
    -- add your new entries here

    PRIMARY KEY (ProfileName)                      -- primary key
    );


-- table defaults
insert into tableDefaults values ("Pppoe", "LogicalIfName", "wan1", "", "");
insert into tableDefaults values ("Pppoe", "UseDefaultMtu", "0", "0", "1");
insert into tableDefaults values ("Pppoe", "MtuSize", "1492", "10", "1492");
insert into tableDefaults values ("Pppoe", "IdleTimeOutFlag", "0", "0", "1");
insert into tableDefaults values ("Pppoe", "IdleTimeOutValue", "5", "5", "999");

insert into stringsMap values ("PPPOE_PROFILE_CONFIG_FAILED", "PPPoE Profile Configuration Failed");

CREATE TABLE PingDiagnostics 
(
	DiagnosticsState		text	  ,			 -- DiagnosticsState 	
    Interface               text      ,          -- WAN or LAN IP-layer interface name
	InterfaceObject			text	  ,			 -- 	
    Host                    text      ,  		 -- Host name or address of the host to ping.    
    NumberOfRepetitions     integer   ,          -- Number of repetitions of the ping test to perform before reporting the results.
    Timeout                 integer   ,          -- Timeout in milliseconds for the ping test.
    DataBlockSize           integer   ,          -- Size of the data block in bytes to be sent for each ping.
    DSCP                    integer   ,          -- DiffServ codepoint to be used for the test packets.
    SuccessCount            integer   ,          -- Result parameter indicating the number of successful pings
    FailureCount            integer   ,          -- Result parameter indicating the number of failed pings in the most recent ping test.
    AverageResponseTime     integer   ,          -- Result parameter indicating the average response time  
    MinimumResponseTime     integer   ,          -- Result parameter indicating the minimum response time
    MaximumResponseTime     integer              -- Result parameter indicating the maximum response time  
);

CREATE TABLE NSLookupDiagnostics
(
    DiagnosticsState	      text      ,	   -- DiagnosticsState 	
    Interface                 text      ,          -- WAN or LAN IP-layer interface name
    InterfaceObject	      text	,	   --
    HostName                  text      ,  	   -- Specifies the Host Name that NS Lookup is to look for.    
    DNSServer                 integer   ,          -- Specifies the DNS Server name or IP address that NS Lookup is to use for the lookup.
    Timeout                   integer   ,          -- Timeout in milliseconds that indicates that a request has failed.
    NumberOfRepetitions       integer   ,          -- The number of times the device SHOULD repeat the execution of the NSLookup.
    SuccessCount              integer              -- Number of successfully executed repetitions.
);

CREATE TABLE Result
(
    Status                    text      ,          -- Result Parameter to represent whether the NS Lookup was successful or not.
    AnswerType                text      ,          -- Result parameter to represent whether the answer is Authoritative or not.
    HostNameReturned          text      ,          -- Result parameter to represent the fully qualified name for the Host Name in the calling parameter.
    IPAddresses               text      ,          -- Comma-separated list (up to 10 items) of IPAddresses.
    DNSServerIP               text      ,          -- Result parameter to represent the actual DNS Server IP address that the NS Lookup used.
    ResponseTime              integer              -- Response time (for the first response packet) in milliseconds.
);

CREATE TABLE TraceRouteDiagnostics 
(
	DiagnosticsState		text	  ,			 -- DiagnosticsState 	
    Interface               text      ,          -- WAN or LAN IP-layer interface name
	InterfaceObject			text	  ,			 -- 	
    Host                    text      ,  		 -- Host name or address of the host to ping.    
    NumberOfTries           integer   ,          -- Number of tries of the traceroute test to perform before reporting the results.
    Timeout                 integer   ,          -- Timeout in milliseconds for the ping test.
    DataBlockSize           integer   ,          -- Size of the data block in bytes to be sent for each ping.
    DSCP                    integer   ,          -- DiffServ codepoint to be used for the test packets.
    MaxHopCount             integer   ,          -- The maximum number of hop used in outgoing probe packets  
    ResponseTime            integer              -- Result parameter indicating the response time in milliseconds the most recent trace route test
);

CREATE TABLE RouteHops 
(
	Enable            		boolean	  ,			 -- Enable  	
	Host            		text	  ,			 -- Host Name  	
    HostAddress             text      ,          -- contain the IP address of the host
	ErrorCode			    integer	  ,			 -- ICMP CODE field	
    RTTimes                 integer     		 -- round trip times    
);

CREATE TABLE route
(
routeName       text ,
dstIpAddr       text NOT NULL,
ipSNetMask      text,
gwIpAddr        text,
interfaceName   text ,
interfaceObject text ,
metric          integer,
active          boolean NOT NULL,
private         boolean,
srcIpAddr       text,
srcNetMask      text,
routeType       integer -- 0 static route
                        -- 1 dynamic route 
                        -- 2 default route

--_ROWID_         integer NOT NULL,  -- SAM: Causing problems with db.update
									 -- when rowid != _ROWID_

-- UNIQUE      (_ROWID_)
);


CREATE TABLE route6
(
routeName text NOT NULL,
dstIpAddr text NOT NULL,
prefix text,
gwIpAddr text NOT NULL,
interfaceName text NOT NULL,
interfaceObject text ,
metric integer,
active boolean NOT NULL,
routeType       integer, -- 0 static route
                        -- 1 dynamic route 
                        -- 2 default route
PRIMARY KEY (routeName,gwIpAddr) 
);

insert into stringsMap values ("ROUTE_ADD_FAILED","Route Add Failed");
insert into stringsMap values ("ROUTE_ALREADY_EXISTS","Route Already Exists");
insert into stringsMap values ("ROUTE_EDIT_FAILED","Route Edit Failed");
insert into stringsMap values ("ROUTE_DELETE_FAILED","Route Delete Failed");
insert into stringsMap values ("RESERVED_IPV6_ADDRESS2","Cannot configure Reserved IPv6 Address");
insert into stringsMap values ("RESERVED_IPV6_ADDRESS","Cannot configure Reserved IPv6 Address");
insert into stringsMap values ("GATEWAYIP_NOT_IN_SUBNET_OF_INTERFACE","GatewayIP not in the subnet as the Interface.");
insert into stringsMap values ("ROUTE_ERR_GATEWAY_NOT_IN_SUBNET","GatewayIP not in the subnet as the Interface.");
insert into stringsMap values ("IP_CONFIGURED_ON_SYSTEM","IP already configured on system.");
CREATE TABLE upnp
(
        upnpEnable boolean NOT NULL,
        advPeriod integer ,
        advTimeToLive integer,
        LogicalIfName text 
)
;
insert into tableDefaults values ("upnp","upnpEnable","0","0","1");
CREATE TABLE upnpPortMap
(
        active text ,
        protocol text ,
        intPort integer ,
        extPort integer ,
        ipAddr text
)
;
-- dhcp relay schema

CREATE TABLE dhcpRelay
(
    logicalIfName      text        NOT NULL,  -- logical ifname like IF1 IF2 etc
    dhcpRelayStatus    boolean     NOT NULL,  -- Status -> 0 Disable 1 Enable
    relayGateway       text        NOT NULL,  -- Relay gateway ip address
    option82           boolean     NOT NULL,  -- Status -> 0 Disable 1 Enable
    action82           text,                  -- action to be performed on dhcp packet
    circuitAgentID     text,                  -- circuitId to be appended in dhcp packet
    remoteAgentID      text,                  -- remoteId to be appended in dhcp packet
    -- primary keys
    PRIMARY KEY  (logicalIfName)
);

CREATE TABLE Igmp
(
OID         integer,
IgmpEnable  integer NOT NULL,
allowUpstreamNetworks integer NOT NULL,
upstreamInterface text NOT NULL,
downstreamInterface text NOT NULL
);

CREATE TABLE allowedNets
(
networkAddr text NOT NULL,
maskLength integer NOT NULL
);


insert into tableDefaults values ("Igmp","IgmpEnable","0","0","1");
insert into tableDefaults values ("Igmp","upstreamInterface","IF1","0","1");
insert into tableDefaults values ("Igmp","downstreamInterface","IF2","0","1");
insert into tableDefaults values ("Igmp","allowUpstreamNetworks","2","0","1");
insert into stringsMap values ("IGMP_CONFIG_FAILED", "IGMP Proxy Configuration Failed");
insert into stringsMap values ("IGMP_NETWORK_DELETE_FAILED", "IGMP Allowed Networks delete failed");
insert into stringsMap values ("ALLOWED_NETWORK_CONFIG_FAILED", "Allowed Netwroks configuration failed");

CREATE TABLE mldproxy
    (
    isEnabled               integer  NOT NULL,
    LogicalIfName           text     NOT NULL,
    maxQueryResponseTime    integer          ,
    queryTimeout            integer          ,
    queryInterval           integer          ,
    PRIMARY KEY (LogicalIfName),
    FOREIGN KEY (LogicalIfName) REFERENCES networkInterface(LogicalIfName)    
    );

insert into tableDefaults values ("mldproxy", "isEnabled", "0", "", "");
insert into tableDefaults values ("mldproxy", "maxQueryResponseTime", "10", "", "");
insert into tableDefaults values ("mldproxy", "queryTimeout", "30", "", "");
insert into tableDefaults values ("mldproxy", "queryInterval", "20", "", "");
insert into stringsMap values ("IPV6_MLD_CONFIG_FAILED", "IPV6 MLD Configuration Failed");
-- maptConfig schema
CREATE table maptConfig
(
enable boolean NOT NULL,       -- mapt status (Enable/Disable)
ipv4Interface text,            -- ipv4 interface
ipv4Prefix text,               -- ipv4 prefix
ipv4PrefixLen integer,         -- ipv4 prefix length
ipv6Interface text,            -- ipv6 interface
ipv6Prefix text,               -- ipv6 prefix
ipv6PrefixLen integer,         -- ipv6 prefix length
brIpv6Prefix text,             -- border relay ipv6 prefix
brIpv6PrefixLen integer,       -- border relay ipv6 prefix length
eabitsVal integer,             -- embedded address bits value
eaLength integer,              -- embedded address bits length
offset integer,                -- offset bits 
maptMode integer               -- mapt mode (T/E)
);

CREATE table maptPortStats
(
portNumber integer NOT NULL,
inUse boolean NOT NULL,
count integer NOT NULL,
timeStart integer ,
timeEnd integer ,
totalTime integer ,
protocol  integer,
averageUsage integer NOT NULL,
UNIQUE (portNumber)
);
-- Registaration for mapt
insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM',0,1,'maptConfig',0,1,1,1);
insert into dbUpdateRegisterProgram values ('/pfrm2.0/bin/maptConfig',0,1,'maptConfig',0,1,1,1);
insert into dbUpdateRegisterProgram values ('/pfrm2.0/bin/maptConfig',0,1,'ipAddressTable',0,1,1,1);
insert into compFacilityMap values ("UMI_COMP_MAPT", 3);

-- SQL table for L2TP back-end component.

-- L2tp table
CREATE TABLE L2tp
    (
    OID                      integer,           -- OID
    LogicalIfName            text     NOT NULL, -- interface names like 'lan1', 'wan2', etc.
    IspName                  integer,           -- name of the service provider
    UserName                 text     NOT NULL, -- user name
    Password                 text     NOT NULL, -- password
    AccountName              text,              -- account name used in l2tp
    DomainName               text,              -- domain name used in l2tp
    Secret                   text,              -- secret to authenticate client
    GetIpFromIsp             boolean  NOT NULL, -- will ISP give IP ?
    GetDnsFromIsp            boolean  NOT NULL, -- do we need DNS from ISP ?
    MyIp                     text,              -- local IP of the wan interface
    ServerIp                 text     NOT NULL, -- l2tp server's IP
    StaticIp                 text,              -- ip which we want to assign or negotiate
    Gateway                  text,              -- Gateway to reach the L2TP Server
    NetMask                  text,              -- net mask for the above IP
    PrimaryDns               text,              -- if we want to specify our DNS
    SecondaryDns             text,              -- if we want to specify our DNS
    IdleTimeOutFlag          boolean  NOT NULL, -- do we require idle timeout ?
    IdleTimeOutValue         integer  NOT NULL, -- idle timeout value
    SplitTunnel              boolean  NOT NULL, -- split tunnel ?
    DualAccess               boolean  NOT NULL, -- L2TP or Dual Access L2TP
    -- add your new entries here

    PRIMARY KEY (LogicalIfName),                -- primary key
    FOREIGN KEY (LogicalIfName) REFERENCES networkInterface (LogicalIfName)
    );

CREATE TABLE ftpd
(
enable boolean NOT NULL,
maxNumUsers integer,
idleTime integer,
portNumber integer,
interfaceName text NOT NULL
);

CREATE TABLE ftpUsers
(
userName text NOT NULL,
permission integer -- 1 Read only
                   -- 2 For Read/Write
);

insert into stringsMap values ("VSFTPD_CONFIG_FAILED","FTP Server Configuration Failed");
/* user.sql - solution specific sql statements */

/* Copyright (c) 2013 TeamF1, Inc. */

/*
Copyright (c) 2014, TeamF1 Networks Pvt. Ltd.
(Subsidiary of D-Link India)
*/

/* modification history
 * --------------------
 * 01u,18Sep18,swr  Changes for SPR 63317(vlan membership conf support)
 * 01t,17Oct17,swr  Changes for SPR 62308
 * 01s,31Jul17,swr  Changes for SPR 60117
 * 01r,12Apr17,MSV  Registered ndppdConfig with ipAddressTable.
 * 01q,10May17,aks  changes for SPR 56429
 * 01p,21Apr17,swr  changes for SPR 60242
 * 01o,19Jan17,MSV  Added crontab entry invoking activeClientsTimeStampUpdate.lua SPR#59302
 * 01n,11Jan17,swr  Changes for SPR 58560
 * 01m,21Dec16,MSV  Added crontab entry for SaveDB for every 24 hours (CAS Requirement).
 * 01l,02Sep16,swr  Changes for SPR 56532(FCAPS) and unreigistered tables to
 * UMI_COMP_TR69 which are not required.
 * 01k,08Jun16,swr  Changes for SPR 56383.
 * 01j,26Feb16,swr  Changes for SPR 54979.
 * 01i,02Feb16,swr  Changes for SPR 54833.
 * 01h,11Dec15,swr  Changes for SPR 53601.
 * 01g,02Nov15,swr  Changes for SPR 53930.
 * 01f,31Nov14,mmk  unreigistered TrustedDomains and BlockSites to
 * UMI_COMP_HTTPSFILTER
 * 01e,31Oct14,swr  changes for UpgradesManaged
 * 01d,17oct14,swr  registered AlgConf to UMI_COMP_TR69.
 * 01c,10oct14,swr  registered captivePortal to UMI_COMP_TR69.
 * 01b,30sep14,mmk  registering TrustedDomains and BlockSites to UMI_COMP_HTTPSFILTER.
 * 01a,17jan13,sen  written.
 */

/*
 * DESCRIPTION
 * This solution specific files include SQL statements for this solution. Any
 * database insert operation or table specific to solution goes here.
 */

-- dbUpdateRegisterTbl
-- #### dbUpdateRegisterTbl START ####

-- ## Platform
insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM',0,1,'bridgeTable', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM',0,1,'ipAddressTable', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM',0,1,'bridgePorts', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM',0,1,'bridgeMode', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_PLATFORM",0,1,"system",0,1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM',0,1,'groups',0,1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM',0,1,'users',0,1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_PLATFORM",0,1,"route", 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM',0,1,'route6',0,1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_PLATFORM",0,1,"dot11VAP",0,0,1,0);
insert into dbUpdateRegisterTbl values ("UMI_COMP_PLATFORM",0,1,"radvdLANPrefixPool",0,1,1,1);

-- ## TR-069
insert into ifDevEventTbl values ('ALL',8,'UMI_COMP_TR69','NULL','tr69');
insert into ifDevEventTbl values ('ALL',9,'UMI_COMP_TR69','NULL','tr69');
insert into ifDevEventTbl values ('ALL',10,'UMI_COMP_TR69','NULL','tr69');
insert into ifDevEventTbl values ('ALL',11,'UMI_COMP_TR69','NULL','tr69');
-- ## TR69
--insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'configFileTbl', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'ntp', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'networkInterface', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'bridgeTable', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'DhcpServerPools', 0, 1,1,1);
--insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'ifStatic', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'DhcpfixedIpAddress', 0, 1,1,1);
--insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'dhcpv6s', 0, 1,1,1);
--insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'dhcpv6ServerPools', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'ethernet', 0, 1,1,1);
--insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'PingDiagnostics', 0, 1,1,1);
--insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'TraceRouteDiagnostics', 0, 1,1,1);
--insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'RouteHops', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'NSLookupDiagnostics', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'Result', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'ipAddressTable', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'ipv6PrefixTable', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'NimfConf', 0, 1,1,1);
--insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'defaultRouters', 0, 1,1,1);
--insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'resolverConfig', 0, 1,1,1);
--insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'NimfStatus', 0, 1,1,1);
--insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'Pppoe', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'tr69Config', 0, 1,1,1);
--insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'accessMgmt', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'maptConfig', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'dot11Radio', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'dot11Profile', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'dot11VAP', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'radiusClient', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'dot11WPS', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'dot11STA', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'apGroupName', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'dot11Wifi', 0, 1,1,1);
--insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'qosClassQueue', 0, 1,1,1);
--insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'qosClassification', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'defaultPolicy', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'FirewallRules', 0, 1,1,1);
--insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'pkgInstalledSystemDB', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'diskMgmtPartition', 0, 1,1,1);
--insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'smbGlobalConfig', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'gpon', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'diskMgmtFolderInfo', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'routingMode', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'radvd', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'radvdLANPrefixPool', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'VendorLogFile', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'VendorConfigFile', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'bridgeMode', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'vlanEncapIf', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'route', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'route6', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'Rip', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'ipConf', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'resolverConfig', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'CaptivePortal', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'AlgConf', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'macFilterConfig', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'clientMacConfig', 0, 0,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'ACSAlarmsFaults', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'ACSAlarms', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'ACSFaults', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'LanHosts', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'Eogre', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'bridgeModeVlan', 0, 1,1,1);
--insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'macDel', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'dnsClientServer', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'DhcpcOptions', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'vlanMembershipPort', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_NSCAND',0,1,'hostTbl',0,1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_NSCAND',0,1,'DhcpLeasedClients',0,1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'users', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'miscSetting', 0, 1,1,1);

CREATE TABLE ThirdParty
    (
    Enable      boolean NOT NULL,                -- Enable 
    Name        text    NOT NULL,                -- Name of the third party
    Vendor      text    NOT NULL                 -- Vendor of the third party
    );

CREATE TABLE miscSetting
    (
    LogLevel integer	NOT NULL,                -- LogLevel
    WatchDogEnable boolean
    );

insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'ThirdParty', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'tcpdump', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'Igmp', 0, 1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'IPSecPolicies', 0, 1,1,1);
-- #### dbUpdateRegisterTbl END ####

-- dbUpdateRegisterProgram
-- This table is used to map the binary with SQL table. When a database
-- operation takes place (add, delete, update), the registered binary will be
-- involved to handle the database operation. Add statements that apply to a
-- solution.
-- #### dbUpdateRegisterProgram START ####

insert into dbUpdateRegisterProgram values ("/pfrm2.0/bin/bridgeDBConfig",0,1,"bridgeTable", 0, 1,1,1);
insert into dbUpdateRegisterProgram values ("/pfrm2.0/bin/bridgeDBConfig",0,1,"bridgePorts", 0, 1,1,1);
insert into dbUpdateRegisterProgram values ("/pfrm2.0/bin/bridgeDBConfig",0,1,"bridgeMode", 0, 1,1,1);
insert into dbUpdateRegisterProgram values ("/pfrm2.0/bin/userdbConfig",0,1,"groups",0,1,1,1);
-- Added in NAS section
--insert into dbUpdateRegisterProgram values ("/pfrm2.0/bin/userdbConfig",0,1,"users",0,1,1,1);
insert into dbUpdateRegisterProgram values ("ifStaticHostTblManage",0,1,"hostTbl",0,1,1,1);
insert into dbUpdateRegisterProgram values ("ifStaticSystemNameUpdate",0,1,"system",0,1,0,0);

-- Registering for route6
insert into dbUpdateRegisterProgram values ("/pfrm2.0/bin/iprouteConfig",0,1,"route",0,1,1,1);
insert into dbUpdateRegisterProgram values ('/pfrm2.0/bin/iprouteConfig',0,1,'route6',0,1,1,1);

insert into dbUpdateRegisterProgram values ("/pfrm2.0/bin/radvdLANPrefixPoolConfig",0,1,"radvdLANPrefixPool", 0, 1,1,1);
-- #### dbUpdateRegisterProgram END ####

-- environment table
-- #### ENVIRONMENT TABLE START ####

insert into environment (name, value) values("DEVICE_NAME", "Reliance");
-- list of variables for configuration file
insert into environment (name, value) values("TEAMF1_CFG_ASCII", "/flash/teamf1.cfg.ascii");
insert into environment (name, value) values("FLASH_CFG_ASCII", "/flash/teamf1.cfg.ascii");
insert into environment (name, value) values("FLASH_BACKUP_CFG_ASCII", "/flash/teamf1.cfg.ascii.bkp");
insert into environment (name, value) values("TR69_PERSISTENT_STORE", "/flash/tr69");
insert into environment (name, value) values("PING_FILE_NAME", "/tmp/ping.output");
insert into environment (name, value) values("PING_PROGRAM", "/bin/ping -4 -c 5");
insert into environment (name, value) values("PING6_PROGRAM", "/bin/ping6 -c 5");
insert into environment (name, value) values("TRACEROUTE_PROGRAM", "/usr/bin/traceroute -w 1");
insert into environment (name, value) values("TRACEROUTE6_PROGRAM", "/usr/bin/traceroute -6 -w 1");
insert into environment (name, value) values("TRACE_ROUTE_FILE_NAME", "/tmp/traceroute.output");
insert into environment (name, value) values("TRACE_ROUTE6_FILE_NAME", "/tmp/traceroute6.output");
insert into environment (name, value) values("TEAMF1_CFG_DEFAULTS_ASCII", "/var/teamf1.cfg.defaults.ascii");
insert into environment (name, value) values("MAX_GROUPS", "8");
insert into environment (name, value) values("MAX_USERS", "16");
insert into environment (name, value) values("BOOTUP_TIME", "110");
insert into environment (name, value) values("DEFAULT_PASSWORD", "password");
insert into environment (name, value) values("DDNS_VIEW", "/pfrm2.0/bin/ddnsView");
insert INTO environment (name, value) values('RADIUS_DICTIONARY','/pfrm2.0/etc/radius.dict');

insert into environment (name, value) values("IPV6_GW_UPDATE","iprouteIPv6GwAdd");

-- Route program for diagnostics
insert into environment (name, value) values("ROUTE_PROGRAM",  "/sbin/route");
insert into environment (name, value) values("ROUTE6_PROGRAM",  "/pfrm2.0/bin/ip -6 route show table main");

-- The value of the field is comma separated list. Note, this field cannot
-- have invalid user list. If it does, the check will fail the default users
-- list will not be protected.
insert into environment (name, value) values("DEFAULT_USERS", "admin,guest");
-- The value of the field is comma separated list. Note, this field cannot
-- have invalid user list. If it does, the check will fail the default users
-- list will not be protected.
insert into environment (name, value) values("DEFAULT_GROUPS", "admin,guest");
insert into environment (name, value) values("DEFAULT_USER_SHELL","/bin/sh");

-- list of variables for firmware upgrade, reboot, factory reset,
-- configuration management.
insert into environment (name, value) values("UPGRADE_PROGRAM", "/pfrm2.0/bin/firmd");
--insert into environment (name, value) values("UPGRADEPREP_PROGRAM", "/pfrm2.0/bin/upgradePrep.sh");
insert into environment (name, value) values("CFG_WRITE_PROGRAM", ". /pfrm2.0/bin/writecfg.sh");
--insert into environment (name, value) values("FACTORY_RESET_SCRIPT", "/pfrm2.0/bin/factoryReset.sh");

-- Flash partition related variables
--insert into environment (name, value) values("CURRENT_FIRM_PARTITION", "/dev/mtd6");
insert into environment (name, value) values("FLASH_FIRM_FS_PARTITION", "/dev/mtd2");
insert into environment (name, value) values("FLASH_FIRM_FS_PARTITION_IMAGE2", "/dev/mtd4");
insert into environment (name, value) values("FLASH_FIRM_PARTITION", "/dev/mtd1");
insert into environment (name, value) values("FLASH_FIRM_PARTITION_IMAGE2", "/dev/mtd3");
insert into environment (name, value) values("PRE_UPGRADE_SCRIPT", "/pfrm2.0/bin/preUpgrade.sh");
insert into environment (name, value) values("POST_UPGRADE_SCRIPT", "/pfrm2.0/bin/postUpgrade.sh");
insert into environment (name, value) values("FLASH_CFG_PARTITION", "/flash");
insert into environment (name, value) values('PFRM_BIN_PATH','/pfrm2.0/bin/');
insert into environment (name, value) values("ROUTE_SCRIPT", "/pfrm2.0/bin/routeTable.sh");
insert into environment (name, value) values("ROUTE_FILE_NAME", "/tmp/route4.txt");
insert into environment (name, value) values("ROUTE6_SCRIPT", "/pfrm2.0/bin/route6Table.sh");
insert into environment (name, value) values("ROUTE6_FILE_NAME", "/tmp/route6.txt");
insert into environment (name, value) values("STAGING_MTD_PARTITION", "/dev/mtd8");
insert into environment (name, value) values("RGW_PRIM_MTD_PARTITION", "/dev/mtd6");
insert into environment (name, value) values("RGW_SEC_MTD_PARTITION", "/dev/mtd9");
insert into environment (name, value) values("sw_version", "1.0.0");
insert into environment (name, value) values("NSLOOKUP_PROGRAM", "/pfrm2.0/bin/nslookup");
insert into environment (name, value) values("NSLOOKUP_FILE_NAME", "/tmp/nslookup.output");
insert into environment (name, value) values("FIRM_MD5_SUM_VALUE", "/flash/firmMd5sum");
insert into environment (name, value) values("BOOTSTRAP", "0");
-- Resource Untilization 
insert into environment (name, value) values("RESOURCE_UTILITY_PROGRAM", "/pfrm2.0/bin/cpuMemUsage");
insert into environment (name, value) values("GET_BOOT_ENV", "/bin/fw_printenv");
insert into environment (name, value) values("SET_BOOT_ENV", "/bin/fw_setenv");
insert into environment (name, value) values("WPS_PIN_PROGRAM", "/pfrm2.0/bin/dot11WpsConfigPin");
insert into environment (name, value) values("WPS_PBC_PROGRAM", "/pfrm2.0/bin/dot11WpsConfigPbc");
insert into environment (name, value) values("WPS_PROGRAM", "/bin/wsccmd");
-- NTP default servers..
insert into environment (name, value) values("NTP_CUSTOM_SERVER1", "acs.oss.jio.com");
insert into environment (name, value) values("NTP_CUSTOM_SERVER2", "in.pool.ntp.org");

insert into environment (name, value) values("NVRAM_DHCPV6C_DUID","/flash/tmp/dhcp6c_duid");
insert into environment (name, value) values("NVRAM_DHCPV6S_LEASES_FILE","/flash/tmp/server6.leases");
insert into environment (name, value) values("NVRAM_DHCPV6S_FLASH_STORE_DIR","/flash/tmp/");
insert into environment (name, value) values("NVRAM_DHCPV6S_DUID","/flash/tmp/dhcp6s_duid");
insert into environment (name, value) values("NVRAM_DHCPV6C_FLASH_STORE_DIR", "/flash/tmp/");
insert into environment (name, value) values("UPNP_REFRESH_PROGRAM",  "/pfrm2.0/bin/upnpShowConfig");
insert into environment (name, value) values("SNMP_SYSOBJID", "1.3.6.1.4.1.39948");
--System Default user as a global variable, make sure that this field is updated accordingly
insert into environment (name, value) values("DEFAULT_SYSTEM_USER", "admin");
insert into environment (name, value) values("IANA_ENTERPRISE_NUMBER","39948");
insert into environment (name, value) values("OSGI_PARTITION", "/opt");
insert into environment (name, value) values("MAX_CLIENTS_PER_RADIO", "24");
--insert into environment (name, value) values("JIO_PRIVATE_NET", "1");

-- #### ENVIRONMENT TABLE END ####

insert into webBrandingTags values ("Jio Centrum Home Gateway","&#169; 2021 TeamF1, Inc. All Rights Reserved.","www.ril.com","www.ril.com","RIL","Reliance Jio","RIL","RIL","RIL Wizard","1");

--SystemStatics Table for the cpuUsage 
insert into SystemStatistics values (0,0,0,0,0,0,0,0,0,0,0,0,0); 
insert into logging values (4096, 0);
insert into compFacilityMap values ("UMI_COMP_NTP", 12);

insert into compFacilityMap values ("UMI_COMP_FIREWALL", 10);
insert into compFacilityMap values ("UMI_COMP_USERDB", 10);
insert into compFacilityMap values ("UMI_COMP_LOGIN", 10);

insert into compFacilityMap values ("UMI_COMP_IFDEV", 3);
insert into compFacilityMap values ("UMI_COMP_DHCPC", 3);
insert into compFacilityMap values ("UMI_COMP_NIMF", 3);
insert into compFacilityMap values ("UMI_COMP_WAND", 3);
insert into compFacilityMap values ("UMI_COMP_UPNP", 3);
insert into compFacilityMap values ("UMI_COMP_DDNS", 3);
insert into compFacilityMap values ("UMI_COMP_SSHD", 3);
insert into compFacilityMap values ("UMI_COMP_WATCHDOG", 3);
insert into compFacilityMap values ("UMI_COMP_SNMP", 3);
insert into compFacilityMap values ("UMI_COMP_SNMP_TRAP", 3);
insert into compFacilityMap values ("UMI_COMP_SWMGR", 3);
insert into compFacilityMap values ("UMI_COMP_APPD", 3);
insert into compFacilityMap values ("UMI_COMP_SLAACD", 3);

insert into compFacilityMap values ("UMI_COMP_TR69", 18);
insert into compFacilityMap values ("UMI_COMP_IGMP", 20);
insert into compFacilityMap values ("UMI_COMP_FIRMD", 22);
insert into compFacilityMap values ("UMI_COMP_OSGI", 3);
insert into compFacilityMap values ("UMI_COMP_CAPTIVEPORTAL", 3);
insert into compFacilityMap values ("UMI_COMP_LOGIN", 3);

-- TODO This has to be loaded as part of configInit 
insert into configFileTbl values ("teamf1.cfg.ascii","1.0","","Device Configuration File", 1);
insert into runLevelStatus values ("2");

insert into firmUpdateSystemConfig values("", "1","","","","","/tmp/current-fw.dat",0,"mv");


INSERT INTO ifDevEventTbl VALUES('ALL',10,'UMI_COMP_PLATFORM','iprouteManageRoutes /tmp/system.db','route');
INSERT INTO ifDevEventTbl VALUES('sit0',2,'UMI_COMP_PLATFORM','iprouteManageRoutes /tmp/system.db','route');


insert into serviceRegistry values ("loggingd",  'loggingdRestart', '', '');
insert into serviceRegistry values ("nimfd",  'nimfd /tmp/system.db', '', '');
insert into serviceRegistry values ("ifDevd",  'ifDevd /tmp/system.db', '', '');
insert into serviceRegistry values ("appd",  'appd /tmp/system.db', '', '');
insert into serviceRegistry values ("slaacd",  'slaacd', '', '');
insert into serviceRegistry values ("dhcpd",  'dhcpdRestart', '', '');

insert into PingDiagnostics values ("None", "IF1","Device.IP.Interface.1", "192.168.176.100",3,2,1200,0,0,0,0,0,0);

insert into TraceRouteDiagnostics values ("None", "IF1","Device.IP.Interface.1.IPv4Address.1.", "192.168.29.100",3,5000,38,0,30,0);
insert into NSLookupDiagnostics values ("None", "IF1","Device.IP.Interface.1.", "192.168.176.100",'',2000,3,0);

insert into environment (name, value) values("BONJOUR_DEFAULT_SERVICE_NAME", "https");

insert into crontab values(1,0,0,12,-1,-1,-1,"/pfrm2.0/bin/lua /pfrm2.0/bin/activeClientsTimeStampUpdate.lua");

insert into AlarmsFaultsEvents values ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX", "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");

CREATE TABLE chipsetInfo
    (
    Chipset text
    );
insert into chipsetInfo values ("Broadcom");

CREATE TABLE tcpdumpUpload
    (
    Status text
    );

insert into stringsMap values ("NET_ERR_MODE_CHANGE_WITH_NET_ENABLE","To change network mode, Please disable network first.");
insert into stringsMap values ("DEFUALT_NETWORK_CONFIGURATION_NOT_ALLOWED","Cannot enable/disable default networks.");
insert into stringsMap values ("NET_ERR_MAX_NETWORKS_LIMIT_REACHED","Cannot create more than 16 networks");
insert into stringsMap values ("NET_ERR_NETWORK_ALREADY_EXISTS","Network with the same name or VLAN ID exists.");
insert into stringsMap values ("NET_ERR_ASSOCLIST_EXISTS","Cannot delete since other networks are associated(bridged/routed) with the given network");
insert into stringsMap values ("NET_ERR_VLANBRIDGE_STATUS_NOTSUPP","Getting status of VLANBridge network is not supported");
insert into stringsMap values ("SEL_NW_IS_DOWN","Selected Network is Down");
insert into stringsMap values ("NO_LAN_NET","Wireless is not enabled on any LAN network.Enable wireless on LAN network.");
insert into stringsMap values ("SQL_INVALID_INPUT","Single Quote(') , Pipe (|) and Semi-Colon (;) are not allowed for user input field");
insert into stringsMap values ("DHCPD_OPTION_EXISTS","Pool Already exists with the same name");
insert into stringsMap values ("DHCPD_INVALID_NUM_DEVICES","Enter the Pool IP in the same subnet of the network");
insert into stringsMap values ("DHCPD_POOL_RANGE_CONFLICT","Pool IP cannot be configured in DHCP Server address range pool.Please configure different IP");
insert into stringsMap values ("USB_NOT_MOUNTED_PROPERLY","USB is not connected to device properly. Please reinsert again.");
insert into stringsMap values ("SYS_NAME_CONFIG_FAILED","Failed to configure System Name");
insert into stringsMap values ("DB_ERROR_TRY_AGAIN","Database is locked.Please try again");
insert into stringsMap values ("REPO_SOURCE_CONF_FAILED","Repository url configuration failed");
insert into stringsMap values ("PKG_INSTALL_FAILED","Extension install failed");
insert into stringsMap values ("PKG_REMOVE_FAILED","Extension remove failed");
insert into stringsMap values ("PKG_UPDATE_FAILED","Extension update failed");
insert into stringsMap values ("PKG_CLEAR_HISTORY_FAILED","Extension install history clear failed");
insert into stringsMap values ("STATUS_ERROR","Operation failed");
insert into stringsMap values ("NO_VAP_SELECTED_TO_ENABLE_WPS","No Access Point has been selected to enable WPS");
insert into stringsMap values ("PORT_ALREADY_IN_USE","Port number is already in use");
insert into stringsMap values ("RESERVED_PORT_CANNOT_USE","Port number configured is Reserved");
insert into stringsMap values ("OPEN_PORT_CANNOT_USE","Port number configured is open port");
insert into stringsMap values ("DISK_ALREADY_REMOVED","The disk is already removed ");
insert into stringsMap values ("SELECTED_VLAN_ID_PRESENT_ON_GPON","Selected VLAN ID is already configured on WAN");
insert into stringsMap values ("SELECTED_VLAN_ID_PRESENT_ON_BRIDGE","Selected VLAN ID is already configured for Bridge mode");
insert into stringsMap values ("UPGRADE_ONLY_VIA_ACS","Firmware upgrade managed only via ACS");
insert into stringsMap values ("ACS_PWD_GENERATION_ENABLED","Username and Password cannot be changed when ACS Password Generation is Enabled");
insert into stringsMap values ("FAILED_TO_EDIT_WIRELESS_PROFILE","Failed to edit wireless profile");
insert into stringsMap values ("FAILED_TO_EDIT_WIRELESS_ACCESSPOINT","Failed to edit wireless accesspoint");
insert into stringsMap values ("PLEASE_TURN_OFF_GoGRE","Please turn off EoGRE to Edit");
insert into stringsMap values ("SAME_IPMODE","IP Mode selected same as current IP Mode");
insert into stringsMap values ("LAN_IP_IN_DHCP_RANGE","LAN IP cannot be same or within dhcp server pool");
insert into stringsMap values ("DISK_NOT_READY_YET","Disk not ready yet, Please wait!!");
insert into stringsMap values ("LOW_MEMORY","Device low on free memory . Please try after sometime");



insert into ifDevEventTbl values ("ALL", 26, "UMI_COMP_PLATFORM", "ifBwChange", "qos");
insert into ifDevEventTbl values ("ALL", 15, "UMI_COMP_PLATFORM", "bwDefProfile", "qosdef");
insert into ifDevEventTbl values ("ALL", 16, "UMI_COMP_PLATFORM", "bwDefProfile", "qosdef");

insert into ifDevEventTbl values ("ALL", 5, "UMI_COMP_APPD", "NULL", "appd");
insert into ifDevEventTbl values ("ALL", 8, "UMI_COMP_APPD", "NULL", "appd");
insert into ifDevEventTbl values ("ALL", 9, "UMI_COMP_APPD", "NULL", "appd");
insert into ifDevEventTbl values ("ALL", 10, "UMI_COMP_APPD", "NULL", "appd");
insert into ifDevEventTbl values ("ALL", 11, "UMI_COMP_APPD", "NULL", "appd");
insert into ifDevEventTbl values ("ALL", 15, "UMI_COMP_APPD", "NULL", "appd");
insert into ifDevEventTbl values ("ALL", 16, "UMI_COMP_APPD", "NULL", "appd");

insert into dbUpdateRegisterTbl values ('UMI_COMP_APPD',0,0,'radvd', 0, 1,0,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_APPD',0,0,'accessMgmt', 0, 1,0,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_APPD",0,0,"Ripng", 0, 1, 0, 1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_APPD",0,0,"Rip", 0, 1, 1, 1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_APPD",0,0,"upnp", 0, 1,0,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_APPD",0,0,"Igmp", 0, 1,0,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_APPD",0,0,"sshd", 0, 1,0,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_APPD',0,0,'ddns',0,1,0,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_APPD',0,0,'igmp',0,1,0,1);

insert into dbUpdateRegisterTbl values ("UMI_COMP_APPD",0,0,"snmpAccessControl",0,1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_APPD",0,0,"snmpv3Users",0,1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_APPD",0,0,"snmp",0,1,0,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_APPD",0,0,"snmpTrap", 0, 1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_APPD",0,0,"system", 0, 1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_APPD",0,0,"dhcpRelay", 0, 1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_APPD",0,0,"DhcpServerPools", 0, 1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_APPD",0,0,"dhcpv6s", 0, 1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_APPD",0,0,"dhcpv6Relay", 0, 1,1,1);


-- NAS
insert into compFacilityMap values ("UMI_COMP_DISK_MGMT", 17);
insert into compFacilityMap values ("UMI_COMP_PARTITIONMGMT", 17);
insert into compFacilityMap values ("UMI_COMP_NAS", 17);
insert into compFacilityMap values ("UMI_COMP_SMB", 17);

insert into environment (name, value) values("MAX_SHARES", "16");
insert into environment (name, value) values("MAX_PARTITIONS", "4");

insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM',0,1,'groups',0,1,1,1);
insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM',0,1,'diskMgmtPartition',0,1,1,1);

-- Partition mgmt related event. This will come from Udev binary
insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM',0,1,'diskMountHelper',0,1,1,1);
insert into dbUpdateRegisterProgram values ("/pfrm2.0/etc/udev/disk_mountHelper",1,1,"diskMountHelper",0,0,1,0);

-- In case of add, the user need to be added to backend system first
insert into dbUpdateRegisterProgram values ("userdbConfig",0,1,"users",0,1,1,0);
insert into dbUpdateRegisterProgram values ("smbMgmtConfig",0,1,"users",0,1,1,0);

-- In case of delete, the user need to be deleted from smb first
insert into dbUpdateRegisterProgram values ("smbMgmtConfig",0,1,"users",0,0,0,1);
insert into dbUpdateRegisterProgram values ("smbMgmtConfig",0,1,"smbGlobalConfig",0,1,1,1);
insert into dbUpdateRegisterProgram values ("userdbConfig",0,1,"users",0,0,0,1);

insert into dbUpdateRegisterProgram values ("/pfrm2.0/bin/sharePartition", 0,1,"diskMgmtPartition",0,1,1,1);

insert into dbUpdateRegisterProgram values ("nasConfig",1,1,"nasShare",0,1,1,1);
insert into dbUpdateRegisterProgram values ("nasConfig",1,1,"nasShareProtocol",0,0,1,1);
insert into dbUpdateRegisterProgram values ("nasConfig",1,1,"groups",0,1,0,0);

insert into dbUpdateRegisterTbl values ("UMI_COMP_APPD",0,0,"mediaServerShares", 0, 1,1,1);
insert into dbUpdateRegisterProgram values ("/pfrm2.0/bin/mediaServerMgmtConfig",0,0,"mediaServerShares", 0, 1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_PLATFORM",0,0,"mediaServerShares", 0, 1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_APPD",0,0,"mediaServerGlobalCfg", 0, 1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_PLATFORM",0,0,"dmsServerSettings", 0, 1,1,1);
insert into dbUpdateRegisterProgram values ("/pfrm2.0/bin/mediaServerMgmtConfig",0,0,"dmsServerSettings", 0, 1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_APPD",0,0,"smbMgmtConfig", 0, 1,1,1);
insert into dbUpdateRegisterTbl values ("UMI_COMP_PLATFORM",0,0,"dmsServerConfig", 0, 1,1,1);
insert into dbUpdateRegisterProgram values ("/pfrm2.0/bin/mediaServerMgmtConfig",0,0,"dmsServerConfig", 0, 1,1,1);

-- NAS Share related inserts
insert into nasShareProtoBinMap values("smb", "smbMgmtShareConfig");

insert into compDeinitHdlr values ("disks", "/pfrm2.0/bin/diskMgmtUnmountAll", 0, 1);
-- END NAS

-- Registaration for sixToFourTunnel
--insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM',0,1,'sixToFourTunnel',0,1,1,1);
--insert into dbUpdateRegisterProgram values ('/pfrm2.0/bin/6to4Config',0,1,'sixToFourTunnel',0,1,1,1);
--insert into dbUpdateRegisterProgram values ('/pfrm2.0/bin/6to4Restart',0,1,'ipAddressTable',0,1,1,1);

-- Registration for isatapTunnel
-- Registaration for isatapTunnel
insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM',0,1,'isatapTunnel',0,1,1,1);
insert into dbUpdateRegisterProgram values ('/pfrm2.0/bin/isatapConfig',0,1,'isatapTunnel',0,1,1,1);
insert into dbUpdateRegisterProgram values ('/pfrm2.0/bin/radvdIsatapPrefixConfig',0,1,'isatapTunnel',0,1,1,1);

-- Registration for ipConf
insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM',0,1,'ipConf',0,1,1,1);
insert into dbUpdateRegisterProgram values ("/pfrm2.0/bin/ipModeConfig",0,1,"ipConf", 0, 1,1,1);

-- Registration for tcpdump
insert into dbUpdateRegisterProgram values ("/pfrm2.0/bin/tcpdumpConfig",0,1,"tcpdump", 0, 1,1,1);

--EasyMesh
insert into dbUpdateRegisterTbl values ('UMI_COMP_TR69',0,0,'easyMesh', 0, 1,1,1);

-- Registaration for mldproxy
insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM',0,1,'mldproxy',0,1,1,1);
insert into dbUpdateRegisterProgram values ('/pfrm2.0/bin/mldproxyConfig',0,1,'mldproxy',0,1,1,1);

-- ## Switch Manager Tables ##
INSERT into dbUpdateRegisterTbl values ('UMI_COMP_SWMGR',0,0,'swGlobalCfg', 0, 0,1,0);
INSERT into dbUpdateRegisterTbl values ('UMI_COMP_SWMGR',0,0,'swPortConfig', 0, 1,1,0);
INSERT into dbUpdateRegisterTbl values ('UMI_COMP_SWMGR',0,0,'vlanEncapIf', 0, 1,1,1);
INSERT INTO ifDevEventTbl VALUES('ALL',22,'UMI_COMP_SWMGR','NULL','swMgr');
INSERT INTO ifDevEventTbl VALUES('ALL',25,'UMI_COMP_SWMGR','NULL','swMgr');

-- Registration for ppp1 interface after idle timeout. 
INSERT INTO ifDevEventTbl VALUES('ppp1',1,'UMI_COMP_PLATFORM','/pfrm2.0/bin/l2tpIfDevEventHandle /tmp/system.db 2','l2tp');

-- Registaration for vsftpd
insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM',0,1,'ftpd',0,1,1,1);
insert into dbUpdateRegisterProgram values ('/pfrm2.0/bin/vsftpdConfig',0,1,'ftpd',0,1,1,1);

-- Registaration for TraceRouteDiagnostics
insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM',0,1,'TraceRouteDiagnostics',0,1,0,0);
insert into dbUpdateRegisterProgram values ('/pfrm2.0/bin/iputilsConfig',0,1,'TraceRouteDiagnostics',0,1,0,0);

--Registration for ndppd
insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM',0,1,'ndppd',0,1,1,1);
insert into dbUpdateRegisterProgram values ('/pfrm2.0/bin/ndppdConfig',0,1,'ipAddressTable',0,1,1,1);
insert into dbUpdateRegisterProgram values ('/pfrm2.0/bin/ndppdStatusConfig',0,1,'ndppd',0,1,1,1);

-- Registaration for NSLookupDiagnostics
-- insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM',0,1,'NSLookupDiagnostics',0,1,0,0);
-- insert into dbUpdateRegisterProgram values ('/pfrm2.0/bin/iputilsConfig',0,1,'NSLookupDiagnostics',0,1,0,0);

-- insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM',0,0,'DhcpLeasedClients',0,1,1,1);
-- insert into dbUpdateRegisterProgram values ('/pfrm2.0/bin/telnet.sh',0,0,'DhcpLeasedClients',0,1,1,1);

-- default entires for dnsClientServer
insert into dnsClientServer values ('IF1','2');
insert into dnsClientServer values ('IF1','2');
insert into dnsClientServer values ('IF1','10');
insert into dnsClientServer values ('IF1','10');

insert into tcpdumpUpload values (' ');

--  Mesh related stringsMap
insert into stringsMap values ("DOT11_FH_5_0_PROFILE_CONFIG_NOT_ALLOWED","5 GHz primary AP not allowed to edit when  Mesh is enabled");
insert into stringsMap values ("DOT11_BH_PROFILE_CONFIG_NOT_ALLOWED","Backhaul AP not allowed to edit");
insert into stringsMap values ("DOT11_2_4_PROFILE_CONFIG_NOT_ALLOWED","2.4/5 GHz primary AP cannot be OPEN/Radius when Mesh is enabled");
insert into stringsMap values ("VAP_STATUS_EDIT_NOT_ALLOWED__MESH_AP","Selected AP cannot be disabled when Mesh is enabled");
insert into stringsMap values ("VAP_EDIT_NOT_ALLOWED__MESH_AP","Selected AP cannot be edited when Mesh is enabled");
insert into dbUpdateRegisterTbl values ('UMI_COMP_PLATFORM',0,0,'DhcpLeasedClients',0,1,1,1);
insert into dbUpdateRegisterProgram values ('/pfrm2.0/bin/telnet.sh',0,0,'DhcpLeasedClients',0,1,1,1);
COMMIT;
