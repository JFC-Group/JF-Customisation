--[[
#### Copyright (c) 2010-2014, TeamF1 Networks Pvt. Ltd.
#### (Subsidiary of D-Link India)
#### 
#### File: tr181_dot11TrExtn.lua
#### Description: 
#### TR-181 handlers for dot11. This file is included from
#### tr69Glue code.
####
--
--#### Revisions:
--02c, 12Mar19, vin  Changes for SPR 65767
--02b, 25Sep18, abh  Changes for SPR 64726
--02a, 23Jul18, swr  Changes for SPR 64363
--01z, 20Apr18, swr  Changes for SPR 63448
--01y, 13Apr18, swr  Changes for SPR 63702
--01x, 06Mar18, sjr  Fix for #63271
--01w, 10Oct17, swr  Changes for SPR 61673
--01v, 31Jul17, swr  Changes for SPR 60117 
--01u, 30May17, swr  Changes for SPR 61006
--01t, 03May17, sjr  Added changes for the JCE410 device
--01s, 25Apr17, swr  Changes for SPR 56728
--01r, 24Apr17, swr  Changes for SPR 60265
--01q, 19Apr17, swr  Changes for SPR 59793 and 60267
--01p, 30Mar17, swr  Changes for SPR 60265
--01o, 06Feb17, swr  Changes for SPR 59162
--01n, 27Jan17, swr  Changes for SPR 59096
--01m, 05Jan17, swr  Changes for SPR 59133
--01l, 27Dec16, swr  Changes for SPR 57405
--01k, 25Nov16, swr  Changes for SPR 58175
--01j, 04Nov16, sda  Changes for SPR 57849 
--01i, 26Sep16, swr  Changes for SPR 57416 and 56934
--01h, 09Jun16, swr  Changes for SPR 56032
--01g, 26Apr16, swr  Changes for SPR 55903
--01f, 09Jan16, swr  Changes for SPR 54832
--01e, 27Aug15, swr  Changes for SPR 52764 and 53057
--01d, 11Aug15, swr  Changes for SPR 51312 
--01c, 23Jul15, swr  Fix for SPR 50189
--01b, 06mar15, swr  Changes for SPR 49978
--01a, 27oct14, swr  changes for Wifi uplink and Downlink Throughput
]]--

dot11Tr = {}

-- locals
local LED_CMD = "/bin/ledctl"
local WIREESS_LED = "WLAN"
local WPS_LED = "WPS" 
local OP_ON = "on"
local OP_OFF = "off"
local NVRAM_CMD_BINARY = "/bin/nvram"
local WL_CMD_BINARY = "/bin/wl"
local NVRAM_CMD_COMMIT = "/bin/nvram commit"
local RADIO_2_4GHz  = "2.4GHz"
local RADIO_5GHz    = "5GHz"
local CURRENT_CHAN_FILE = "/tmp/currentChannel.txt"
local AUTO_CHAN_REFRESH_FILE = "/tmp/autoChanRefVal"
local dbFlag = 0

-- includes
require "teamf1lualib/dot11"

-- Operational Data Transmit Rates for 2.4GHz radio
--
--Rates for "g and b" mode.
gbRates = {
    {val=27,label=1},
    {val=26,label=2},
    {val=25,label=5.5},
    {val=11,label=6},
    {val=15,label=9},
    {val=22,label=11},
    {val=10,label=12},
    {val=14,label=18},
    {val=9,label=24},
    {val=13,label=36},
    {val=8,label=48},
    {val=12,label=54}
}

--Rates for "g only" mode.
gOnlyRates = {
    {val=27,label=1},
    {val=26,label=2},
    {val=25,label=5.5},
    {val=11,label=6},
    {val=15,label=9},
    {val=22,label=11},
    {val=10,label=12},
    {val=14,label=18},
    {val=9,label=24},
    {val=13,label=36},
    {val=8,label=48},
    {val=12,label=54}
}

--Rates for "ng" mode.
ngRates = {
    {val=27,label=1},
    {val=26,label=2},
    {val=25,label=5.5},
    {val=11,label=6},
    {val=15,label=9},
    {val=22,label=11},
    {val=10,label=12},
    {val=14,label=18},
    {val=9,label=24},
    {val=13,label=36},
    {val=8,label=48},
    {val=12,label=54},
    {val=128,label="MCS0"},
    {val=129,label="MCS1"},
    {val=130,label="MCS2"},
    {val=131,label="MCS3"},
    {val=132,label="MCS4"},
    {val=133,label="MCS5"},
    {val=134,label="MCS6"},
    {val=135,label="MCS7"},
    {val=136,label="MCS8"},
    {val=137,label="MCS9"},
    {val=138,label="MCS10"},
    {val=139,label="MCS11"},
    {val=140,label="MCS12"},
    {val=141,label="MCS13"},
    {val=142,label="MCS14"},
    {val=143,label="MCS15"},
    {val=144,label="MCS16"},
    {val=145,label="MCS17"},
    {val=146,label="MCS18"},
    {val=147,label="MCS19"},
    {val=148,label="MCS20"},
    {val=149,label="MCS21"},
    {val=150,label="MCS22"},
    {val=151,label="MCS23"}
}

--Rates for "n only" mode.
nOnlyRates = {
    {val=27,label=1},
    {val=26,label=2},
    {val=25,label=5.5},
    {val=22,label=11},
    {val=128,label="MCS0"},
    {val=129,label="MCS1"},
    {val=130,label="MCS2"},
    {val=131,label="MCS3"},
    {val=132,label="MCS4"},
    {val=133,label="MCS5"},
    {val=134,label="MCS6"},
    {val=135,label="MCS7"},
    {val=136,label="MCS8"},
    {val=137,label="MCS9"},
    {val=138,label="MCS10"},
    {val=139,label="MCS11"},
    {val=140,label="MCS12"},
    {val=141,label="MCS13"},
    {val=142,label="MCS14"},
    {val=143,label="MCS15"},
    {val=144,label="MCS16"},
    {val=145,label="MCS17"},
    {val=146,label="MCS18"},
    {val=147,label="MCS19"},
    {val=148,label="MCS20"},
    {val=149,label="MCS21"},
    {val=150,label="MCS22"},
    {val=151,label="MCS23"}
}

-- Operational Data Transmit Rates for 5GHz radio
--
-- Rates for "a only" mode
aOnlyRates = {
    {val=11,label=6},
    {val=15,label=9},
    {val=10,label=12},
    {val=14,label=18},
    {val=9,label=24},
    {val=13,label=36},
    {val=8,label=48},
    {val=12,label=54}
}

-- Rates for "a/n/ac 20/40 and 20MHz" mode
anacRates      = {
    {val=11,label=6},
    {val=15,label=9},
    {val=10,label=12},
    {val=14,label=18},
    {val=9,label=24},
    {val=13,label=36},
    {val=8,label=48},
    {val=12,label=54},
    {val=128,label="MCS0"},
    {val=129,label="MCS1"},
    {val=130,label="MCS2"},
    {val=131,label="MCS3"},
    {val=132,label="MCS4"},
    {val=133,label="MCS5"},
    {val=134,label="MCS6"},
    {val=135,label="MCS7"},
    {val=136,label="MCS8"},
    {val=137,label="MCS9"},
    {val=138,label="MCS10"},
    {val=139,label="MCS11"},
    {val=140,label="MCS12"},
    {val=141,label="MCS13"},
    {val=142,label="MCS14"},
    {val=143,label="MCS15"},
    {val=144,label="MCS16"},
    {val=145,label="MCS17"},
    {val=146,label="MCS18"},
    {val=147,label="MCS19"},
    {val=148,label="MCS20"},
    {val=149,label="MCS21"},
    {val=150,label="MCS22"},
    {val=151,label="MCS23"},
    {val=152,label="VHT0"},
    {val=153,label="VHT1"},
    {val=154,label="VHT2"},
    {val=155,label="VHT3"},
    {val=156,label="VHT4"},
    {val=157,label="VHT5"},
    {val=158,label="VHT6"},
    {val=159,label="VHT7"},
    {val=160,label="VHT8"},
    {val=161,label="VHT9"}
}

-- Rates for "a/n/ac 80MHz" mode
anac80Rates      = {
    {val=11,label=6},
    {val=15,label=9},
    {val=10,label=12},
    {val=14,label=18},
    {val=9,label=24},
    {val=13,label=36},
    {val=8,label=48},
    {val=12,label=54},
    {val=128,label="MCS0"},
    {val=129,label="MCS1"},
    {val=130,label="MCS2"},
    {val=131,label="MCS3"},
    {val=132,label="MCS4"},
    {val=133,label="MCS5"},
    {val=134,label="MCS6"},
    {val=135,label="MCS7"},
    {val=136,label="MCS8"},
    {val=137,label="MCS9"},
    {val=138,label="MCS10"},
    {val=139,label="MCS11"},
    {val=140,label="MCS12"},
    {val=141,label="MCS13"},
    {val=142,label="MCS14"},
    {val=143,label="MCS15"},
    {val=152,label="VHT0"},
    {val=153,label="VHT1"},
    {val=154,label="VHT2"},
    {val=155,label="VHT3"},
    {val=156,label="VHT4"},
    {val=157,label="VHT5"},
    {val=158,label="VHT6"},
    {val=159,label="VHT7"},
    {val=160,label="VHT8"},
    {val=161,label="VHT9"}
}

-- Rates for "ac Only" mode
acOnlyRates       = {
    {val=11,label=6},
    {val=10,label=12},
    {val=9,label=24},
    {val=152,label="VHT0"},
    {val=153,label="VHT1"},
    {val=154,label="VHT2"},
    {val=155,label="VHT3"},
    {val=156,label="VHT4"},
    {val=157,label="VHT5"},
    {val=158,label="VHT6"},
    {val=159,label="VHT7"},
    {val=160,label="VHT8"},
    {val=161,label="VHT9"}
}

--Rates for "ng" mode.
ngRatesLantiq    =  {
    {val=27,label=1},
    {val=26,label=2},
    {val=25,label=5.5},
    {val=11,label=6},
    {val=15,label=9},
    {val=22,label=11},
    {val=10,label=12},
    {val=14,label=18},
    {val=9,label=24},
    {val=13,label=36},
    {val=8,label=48},
    {val=12,label=54},
    {val=256,label="MCS0"},
    {val=257,label="MCS1"},
    {val=258,label="MCS2"},
    {val=259,label="MCS3"},
    {val=260,label="MCS4"},
    {val=261,label="MCS5"},
    {val=262,label="MCS6"},
    {val=263,label="MCS7"},
    {val=264,label="MCS8"},
    {val=265,label="MCS9"},
    {val=266,label="MCS10"},
    {val=267,label="MCS11"},
    {val=268,label="MCS12"},
    {val=269,label="MCS13"},
    {val=270,label="MCS14"},
    {val=271,label="MCS15"}
}

--[[
--*****************************************************************************
-- dot11Tr.getOperatingStd - gets the opMode value based on band 
-- 
-- Returns: value
]]--
function dot11Tr.getOperatingStd(band, opMode, chanWidth, puren)
    local operatingStd = nil

    if(band == "a") then
        if (opMode == "1") then -- a only
            operatingStd = "a"
        elseif(opMode == "2") then -- a/n/ac
            operatingStd = "a,n,ac"
        elseif(opMode == "3") then -- ac only
            operatingStd = "ac"
        end
    elseif(band == "b") then
        if(opMode == "1" or opMode == "b and g") then -- g and b
            operatingStd = "b,g"
        elseif(opMode == "6" or opMode == "g only") then -- g only
            operatingStd = "g"
        elseif (opMode == "5" or (opMode == "ng" and puren == "0")) then -- ng
            operatingStd = "n,g"
        elseif(opMode == "4" or (opMode == "ng" and puren == "1")) then -- n only
            operatingStd = "n"
        end
    end

    return operatingStd 
end

--[[
--*****************************************************************************
-- dot11Tr.getOpModeDBVal - gets the opMode value based on band 
-- 
-- Returns: value
]]--
function dot11Tr.getOpModeDBVal(chipset, band, opMode)
    local opModeDBVal = ""
    local puren = "0"

    if(band == "a") then
        if (opMode == "65536") then -- a only
            opModeDBVal = "1"
        elseif(opMode == "983040") then -- a/n/ac
            opModeDBVal = "2"
        elseif(opMode == "983041") then -- ac only
            opModeDBVal = "3"
        end
    elseif(band == "b") then
        if(chipset == "Broadcom") then
            if(opMode == "212992" ) then -- g and b
                opModeDBVal = "1"
            elseif(opMode == "196608") then -- g only
                opModeDBVal = "6"
            elseif (opMode == "475136") then -- ng
                opModeDBVal = "5"
            elseif(opMode == "131072") then -- n only
                opModeDBVal = "4"
            end
        else
            if(opMode == "212992" ) then -- g and b
                opModeDBVal = "b and g"
            elseif(opMode == "196608") then -- g only
                opModeDBVal = "g only"
            elseif (opMode == "475136") then -- ng
                opModeDBVal = "ng"
                puren = "0"
            elseif(opMode == "131072" ) then -- n only
                opModeDBVal = "ng"
                puren = "1"
            end
        end
    end

    return opModeDBVal, puren 
end

--[[
--*****************************************************************************
-- dot11Tr.getRadioMaxBitRate - gets the operating std and max bit rate values
-- 
-- Returns: value
]]--
function dot11Tr.getRadioMaxBitRate(band, opMode, chanWidth, puren)
    local maxBitRate = nil

    if(band == "b") then
        if(util.fileExists("/pfrm2.0/HW_JCO110") or util.fileExists("/pfrm2.0/HW_JCO410") or util.fileExists("/pfrm2.0/HW_JCE410")) then
            if(opMode == "1" or opMode == "b and g" or opMode == "6" or opMode == "g only") then --g and b/g only
                maxBitRate = "54"
            elseif (opMode == "5" or opMode == "4" or opMode == "ng") then --ng/n only
                if (chanWidth == "20") then
                    maxBitRate = "144"
                elseif (chanWidth == "2040" or chanWidth == "40") then
                    maxBitRate = "300"
                end
            end
        else
            if(opMode == "1") then -- g and b
                maxBitRate = "54"
            elseif(opMode == "6") then -- g only
                maxBitRate = "50"
            elseif (opMode == "5" or opMode == "4") then -- ng or n only
                if (chanWidth == "20") then
                    maxBitRate = "216"
                elseif (chanWidth == "2040") then
                    maxBitRate = "450"
                end
            end
        end
    elseif(band == "a") then
        if (opMode == "1") then -- a only
            maxBitRate = "54"
        elseif(opMode == "2") then -- a/n/ac
            if(chanWidth == "20") then 
                maxBitRate = "216"
            elseif(chanWidth == "2040") then
                maxBitRate = "450"
            elseif(chanWidth == "80") then
                maxBitRate = "1300"
            end
        elseif(opMode == "3") then -- ac only
            if(chanWidth == "20") then 
                maxBitRate = "216"
            elseif(chanWidth == "2040") then
                maxBitRate = "450"
            elseif(chanWidth == "80") then
                maxBitRate = "1300"
            end
        end
    end

    return maxBitRate 
end

--[[
--*****************************************************************************
-- dot11Tr.getRadioRates - gets the Operational Data Transmit Rates of Radio
-- 
-- Returns: value
]]--
function dot11Tr.getRadioRates (radioBand, radioOpMode, radioChanWidth, puren)
    local rates = {}
    local rateCommaList = ""

    local chipsetRow = db.getRowWhere("chipsetInfo", "_ROWID_=1", false)
    if(chipsetRow["Chipset"] == "Broadcom") then
        if (radioBand == "b") then
            if (radioOpMode == "1") then -- "g and b" Mode
                rates = gbRates
            elseif (radioOpMode == "6") then -- "g Only" mode
                rates = gOnlyRates
            elseif (radioOpMode == "5") then -- "ng" mode
                rates = ngRates
            elseif (radioOpMode == "4") then -- "n Only" mode
                rates = nOnlyRates
            end
        elseif( radioBand == "a") then
            if (radioOpMode == "1") then -- "a Only" Mode
                rates = aOnlyRates
            elseif (radioOpMode == "2" and (radioChanWidth == "20" or radioChanWidth == "2040")) then -- "a/na/ac 20/40 and 20" Mode
                rates = anacRates
            elseif (radioOpMode == "2" and radioChanWidth == "80") then -- "a/na/ac 80" Mode
                rates = anac80Rates
            elseif (radioOpMode == "3") then -- "ac Only" Mode
                rates = acOnlyRates
            end
        end
    else
        if (radioBand == "b") then
            if (radioOpMode == "b and g") then -- "g and b" Mode
                rates = gbRates
            elseif (radioOpMode == "g only") then -- "g Only" mode
                rates = gOnlyRates
            elseif (radioOpMode == "ng") then -- "ng" and "n only" mode
                rates = ngRatesLantiq
            end
        end
    end
    
    for k,v in pairs(rates) do
        if (rateCommaList ~= "") then
            rateCommaList = rateCommaList .. ", " 
        end
        rateCommaList = rateCommaList .. tostring(v["label"])
    end
    
    return rateCommaList
end

--[[
--*****************************************************************************
-- dot11Tr.getRadioBasicRates - gets the Basic Data Transmit Rates of Radio
-- 
-- Returns: value
]]--
function dot11Tr.getRadioBasicRates(radioTbl)
    local cmd = ""
    local list = ""
    local commaList = nil
    local rateTable = {}

    local chipsetRow = db.getRowWhere("chipsetInfo", "_ROWID_=1", false)
    if(chipsetRow["Chipset"] == "Broadcom") then
        cmd = "echo -n `/bin/wl -i " .. radioTbl["interfaceName"] .. " rateset | grep  \"\(b\)\" |sed 's/ /\\n/g'|grep -i \"b\"|sed 's/(b)//g'` > /tmp/basicRates.txt"
        os.execute (cmd)
        list = util.fileToString ("/tmp/basicRates.txt")
   
        if(list) then
            rateTable = util.split(list, " ")
            commaList = table.concat(rateTable,", ")
        end
        os.remove("/tmp/basicRates.txt")
    else
        commaList = "1, 2, 5.5, 11"
    end

    return commaList
end

--[[
--*****************************************************************************
-- dot11Tr.getSignalNoise - gets the Basic Data Transmit Rates of Radio
-- 
-- Returns: value
]]--
function dot11Tr.getSignalNoise(staTbl, grepVal, chipSet)
    local value = nil
    local tmpValue = nil
    local cmd = ""
    local t1 = {}
    local t2 = {}
    local file 

    if(chipSet == "Broadcom") then
        cmd = "/bin/wl -i "..staTbl["interfaceName"].. " sta_info " .. staTbl["macAddress"] .. " |grep '"..grepVal.."' |cut -d ':' -f 2 > /tmp/value"
        os.execute(cmd)

        tmpValue = util.fileToString("/tmp/value")
        if(tmpValue ~= nil) then
            t1 = util.split(tmpValue, " ")
            if(t1[2] ~= nil and t1[3] ~= nil and t1[4] ~= nil) then
                value = (t1[2] + t1[3] + t1[4])/3
            end
        end
    else
        cmd = "mtdump "..staTbl["interfaceName"].. " PeerFlowStatus " .. staTbl["macAddress"] .. " > /tmp/value"
        os.execute(cmd)

        file = io.open("/tmp/value","r")
        if(file ~= nil) then
            local i = 1
            for line in io.lines("/tmp/value") do
                if(string.find(line, "%[") and i == 1 or i == 2 ) then
                    t1 = util.split(line, ":")
                    t2[i] = tonumber(t1[1])
                    i = i + 1
                end
            end
        end
        if(t2[1] ~= nil and t2[2] ~= nil) then
            value = (t2[1] + t2[2])/2
        end
    end

    os.remove("/tmp/value")
    return value
end

--[[
--*****************************************************************************
--@name dot11Tr.checkForSpace
--
--@description this function checks the max clients per radio 
--
--@return status, errCode
--
]]--
function dot11Tr.checkForSpace (ssid)
    local len = 0
    local cnt = 0

    len = string.len(ssid)
    for w in string.gmatch(ssid, " ") do
        cnt = cnt + 1
    end

    if (cnt == len) then
        return 1
    end

    return 0
end

function dot11Tr.getCurrentChannel(configuredChannel, Chipset, radioNo, interfaceName)

    local currentChannel = nil
    --Always get the channel value from backend instead of DB
    if(Chipset == "Broadcom") then
        local firstEnabledVapRow = {}
        local radioInterfaceName = ""
        local vapInterfaceName = ""
        local channel = configuredChannel --put channel as 0
        firstEnabledVapRow = db.getRowWhere("dot11VAP", "radioList='"..radioNo.."' and vapEnabled='1'", false)
        radioInterfaceName = interfaceName
        if(firstEnabledVapRow ~= nil)then
            vapInterfaceName = db.getAttribute("dot11Interface", "vapName", firstEnabledVapRow["vapName"], "interfaceName")
os.execute ("/bin/echo -n `/bin/wl -i " .. vapInterfaceName .. " status |grep Channel | awk '{print$13}'| cut -d'l' -f 1 | cut -d / -f 1` > "..CURRENT_CHAN_FILE)
        else
os.execute ("/bin/echo -n `/bin/wl -i " .. radioInterfaceName .. " status |grep Channel | awk '{print$13}'|cut -d'l' -f 1 | cut -d / -f 1` > "..CURRENT_CHAN_FILE)
        end
        channel = util.fileToString(CURRENT_CHAN_FILE)
        if (channel ~= nil) then
            currentChannel = channel
        end
    else
        local ifname = db.getAttribute("dot11Interface", "_ROWID_", "1", "interfaceName")
        local cmd = "iwlist " ..ifname.." ch | awk '/Current/ {print $2}' | cut -d \"=\" -f 2 > "..CURRENT_CHAN_FILE
        os.execute(cmd)
        local file = io.open(CURRENT_CHAN_FILE, "r")
        if(file ~= nil) then
            channel = file:read("*line")
            if (channel ~= nil) then
                currentChannel = channel
            end 
        end
    end
    
    os.remove(CURRENT_CHAN_FILE)
    if(currentChannel == nil)then
        currentChannel = configuredChannel
    end

    return currentChannel
end

--[[
--*****************************************************************************
-- dot11Tr.radioParamsGet- get wlan radio configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.WiFi.Radio.0.
--
-- Enable
-- Status
-- Name
-- MaxBitRate
-- OperatingFrequencyBand
-- OperatingStandards 
-- ChannelsInUse 
-- Channel
-- AutoChannelEnable
-- AutoChannelRefreshPeriod
-- TransmitPower
-- BasicDataTransmitRates
-- OperationalDataTransmitRates
-- 
-- Returns: status, value
]]--
function dot11Tr.radioParamsGet (input)
    local status = "0"
    local value = "0"
    local row = {}
    local query = nil
    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --read the rowId mapping to dot11Radio
    rowId = instanceMap[param]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from dot11Radio
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("dot11Radio", query, false)
    if (row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    local chipsetRow = db.getRowWhere("chipsetInfo", "_ROWID_=1", false)

    --find & return parameter values
    if(string.find(input["param"], "Status")) then
        -- Status
        value="Up"
    elseif(string.find(input["param"], "Name")) then
        -- Name
        value = row["interfaceName"]
    elseif(string.find(input["param"], "MaxBitRate")) then
        -- MaxBitRate
        maxBitRate = dot11Tr.getRadioMaxBitRate(row["band"], row["opMode"], row["chanWidth"], row["puren"])
        if(maxBitRate == nil) then
            return "1", "DB_ERROR_TRY_AGAIN"
        end
        value = maxBitRate
    elseif(string.find(input["param"], "OperatingFrequencyBand")) then
        -- OperatingFrequencyBand
        if(row["band"] == "a") then
            value = RADIO_5GHz
        elseif(row["band"] == "b") then
            value = RADIO_2_4GHz
        end
    elseif(string.find(input["param"], "OperatingStandards")) then
        -- OperatingStandards
        operatingStd = dot11Tr.getOperatingStd(row["band"], row["opMode"], row["chanWidth"], row["puren"])
        if(operatingStd == nil) then
            return "1", "DB_ERROR_TRY_AGAIN"
        end
        value = operatingStd
    elseif(string.find(input["param"], "TransmitPower")) then
        ifName = row["interfaceName"]
        if(chipsetRow["Chipset"] == "Broadcom") then
            os.execute ("/bin/wl -i " .. ifName .. " txpwr1 |cut -d ' ' -f 7 > /tmp/power")
            power = util.fileToString("/tmp/power")
            os.remove("/tmp/power")
            if (power ~= nil) then
                value = power
                value = (power/1259)*100
            end
        end
    elseif(string.find(input["param"], "AutoChannelEnable")) then
        -- AutoChannelEnable
        if (row["configuredChannel"] == "0") then
            value="1"
        else
            value="0"
        end
    elseif(string.find(input["param"], "AutoChannelRefreshPeriod")) then
        -- AutoChannelRefreshPeriod
        if(chipsetRow["Chipset"] == "Broadcom") then
            local autoChanRefCmd = "nvram get "..row["interfaceName"].."_acs_cs_scan_timer > "..AUTO_CHAN_REFRESH_FILE
            os.execute(autoChanRefCmd)
            local file = io.open(AUTO_CHAN_REFRESH_FILE,"r")
            if(file ~= nil) then
                autoChanRefVal = file:read("*line")
                if (autoChanRefVal ~= nil) then
                    value = autoChanRefVal
                else
                    file:close()
                    return "1", "DB_ERROR_TRY_AGAIN"
                end
                file:close()
            end
        end
    elseif(string.find(input["param"], "X_RJIL_COM_EnableChannel_12_13")) then
        -- radioCountry Rev 991 will have channel 12 & 13..
        if(row["band"] == "a")then 
            value = "0"
        else
            if(tonumber(row["radioCountryRev"]) == 991)then
                value = "1"
            else
                value = "0"
            end
        end
    elseif(string.find(input["param"], "Enable")) then
        -- Enable
        value = "1"
    elseif(string.find(input["param"], "ChannelsInUse")) then
        -- ChannelsInUse
        chnTbl = dot11Tr.getChannelList(chipsetRow["Chipset"], row["band"], row["interfaceName"], row["opMode"], row["sideBand"], row["chanWidth"], row["puren"])
        for k,v in pairs(chnTbl) do
            if(k == 1) then
                value = v
            else
                value = value..", "..v
            end
        end
    elseif(string.find(input["param"], "BasicDataTransmitRates")) then
        -- BasicDataTransmitRates 
        value = dot11Tr.getRadioBasicRates(row)
        if(value == nil) then
            return "1", "DB_ERROR_TRY_AGAIN"
        end
    elseif(string.find(input["param"], "OperationalDataTransmitRates")) then
        -- OperationalDataTransmitRate
        value = dot11Tr.getRadioRates(row["band"], row["opMode"], row["chanWidth"], row["puren"])
        if(value == nil) then
            return "1", "DB_ERROR_TRY_AGAIN"
        end
    elseif(string.find(input["param"], "Channel")) then
        -- Channel
        value = dot11Tr.getCurrentChannel(row["configuredChannel"], chipsetRow["Chipset"], row["radioNo"], row["interfaceName"])
        if(value == nil) then
            return "1", "DB_ERROR_TRY_AGAIN"
        end
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- dot11Tr.radioParamsSet- set wlan radio configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.WiFi.Radio.0.
--
-- OperatingStandards
-- Channel
-- AutoChannelEnable
-- AutoChannelRefreshPeriod
-- TransmitPower
-- 
-- Returns: status
]]--
function dot11Tr.radioParamsSet(input, rowids, actionType, tr69Param)
    require "teamf1lualib/gui"

    --Configuring any of these values is currently not supported in this device
    local status = OK
    local inRow = {}
    inRow = input["dot11Radio"]
    local newStandardVal = "" --OperatingStandards
    local newAutoChanVal = "0"--AutoChannelEnable
    local row = {}
    local query = nil
    local faultTbl = {}
    local index = 0
    local channelStatus
    local channel = nil
    local opModeVal = ""
    local purenVal = ""
    local sideBandVal = ""

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    --read the rowId mapping to dot11Radio
    rowId = instanceMap[tr69Param]
    if (rowId == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    --get corresponding db entry from dot11Radio
    query = "_ROWID_=" ..rowId
    row = db.getRowWhere ("dot11Radio", query, false)
    if (row == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end
    
    local chipsetRow = db.getRowWhere("chipsetInfo", "_ROWID_=1", false)

    radioRow = row

    --set def value for AutoChannelEnable based on configuredChannel
    if (row["configuredChannel"] == "0") then
        newAutoChanVal = "1"
    else
        newAutoChanVal = "0"
    end
      
    -- if configuredChannel is configured from ACS, disable AutoChannelEnable
    if(inRow["dot11Radio.configuredChannel"] ~= nil and inRow["dot11Radio.configuredChannel"] ~= "") then
        newAutoChanVal = "0"
    end

    --OperatingStandards => dot11Radio.opMode
    if(inRow["dot11Radio.opMode"] ~= nil and inRow["dot11Radio.opMode"] ~= "") then
        if(row["band"] == "a") then
            if(inRow["dot11Radio.opMode"] == "a") then
                newStandardVal = "65536"
                radioRow["chanWidth"] = "20"
            elseif(inRow["dot11Radio.opMode"] == "a,n,ac" or inRow["dot11Radio.opMode"] == "a,ac,n" or 
                   inRow["dot11Radio.opMode"] == "n,a,ac" or inRow["dot11Radio.opMode"] == "n,ac,a" or 
                   inRow["dot11Radio.opMode"] == "ac,a,n" or inRow["dot11Radio.opMode"] == "ac,n,a") then
                newStandardVal = "983040"
                radioRow["chanWidth"] = "2040"
                radioRow["contSideBand"] = "Lower"
                sideBandVal = "1"
            elseif(inRow["dot11Radio.opMode"] == "ac") then
                newStandardVal = "983041"
                radioRow["chanWidth"] = "2040"
                radioRow["contSideBand"] = "Lower"
                sideBandVal = "1"
            else
                tr69Glue.tf1Dbg("OperatingStandards value -- " .. inRow["dot11Radio.opMode"] .. " is not valid")
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."OperatingStandards", error_code.INVALID_PARAM_VALUE)
            end
        elseif(row["band"] == "b") then
            if(inRow["dot11Radio.opMode"] == "b,g" or inRow["dot11Radio.opMode"] == "g,b") then
                newStandardVal = "212992"
                radioRow["chanWidth"] = "20"
            elseif(inRow["dot11Radio.opMode"] == "g") then
                newStandardVal = "196608"
                radioRow["chanWidth"] = "20"
            elseif(inRow["dot11Radio.opMode"] == "n,g" or inRow["dot11Radio.opMode"] == "g,n") then
                --check if any profile is configured with security mode WEP or WPA, if exists
                --then changing to 802.11n mode is not allowed
                local conflictingProfiles = db.existsRowWhere("dot11Profile", "security='WEP' or security='WPA'")
                if (conflictingProfiles) then
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."OperatingStandards", error_code.REQUEST_DENIED)
                end
                newStandardVal = "475136"
                radioRow["chanWidth"] = "2040"
                radioRow["contSideBand"] = "Lower"
                sideBandVal = "1"
            elseif(inRow["dot11Radio.opMode"] == "n") then
                newStandardVal = "131072"
                radioRow["chanWidth"] = "2040"
                radioRow["contSideBand"] = "Lower"
                sideBandVal = "1"
            else
                tr69Glue.tf1Dbg("OperatingStandards value -- " .. inRow["dot11Radio.opMode"] .. " is not valid")
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."OperatingStandards", error_code.INVALID_PARAM_VALUE)
            end
        end
        radioRow["opMode"] = newStandardVal
        opModeVal, purenVal = dot11Tr.getOpModeDBVal(chipsetRow["Chipset"], row["band"], newStandardVal)
        newAutoChanVal = "1" --enable auto channel mode
    else
        --get def values for opMode, puren, sideband
        opModeVal = row["opMode"]
        purenVal = row["puren"]
        sideBandVal = row["sideBand"]
        if(chipsetRow["Chipset"] == "Broadcom") then
            if(row["sideBand"] == "0") then
                radioRow["contSideBand"] = "Upper"
            else
                radioRow["contSideBand"] = "Lower"
            end
        else
            if(row["sideBand"] == "1") then
                radioRow["contSideBand"] = "Upper"
            else
                radioRow["contSideBand"] = "Lower"
            end
        end

        if(row["band"] == "a")then
            if(row["opMode"] == "2")then
                radioRow["opMode"] = "983040"
            elseif(row["opMode"] == "1")then
                radioRow["opMode"] = "65536"
            elseif(row["opMode"] == "3")then
                radioRow["opMode"] = "983041"
            end
        elseif (row["band"] == "b")then
            if(row["opMode"] == "5" or row["opMode"] == "ng")then
                if(row["puren"] == "1")then
                    radioRow["opMode"] = "131072"
                else
                    radioRow["opMode"] = "475136"
                end
            elseif(row["opMode"] == "1" or row["opMode"] == "b and g")then
                radioRow["opMode"] = "212992"
            elseif(row["opMode"] == "4")then
                radioRow["opMode"] = "131072"
            elseif(row["opMode"] == "6" or row["opMode"] == "g only")then
                radioRow["opMode"] = "196608"
            end
        end
    end
                
    --TransmitPower => dot11Radio.txPower
    if(inRow["dot11Radio.txPower"] ~= nil and inRow["dot11Radio.txPower"] ~= "") then
        if(tonumber(inRow["dot11Radio.txPower"]) >= 1 and tonumber(inRow["dot11Radio.txPower"]) <= 100) then
            ifName = radioRow["interfaceName"]

            -- set mW value
            powerPercentage = inRow["dot11Radio.txPower"]
            mWValue = (powerPercentage*1259)/100 

            cmd = "/bin/wl -i " ..ifName.. " txpwr1 -m "..mWValue..""
            os.execute (cmd)

            -- get dbm value
            cmd = "/bin/wl -i " .. ifName .. " txpwr1 |cut -d ' ' -f 5 > /tmp/txPower"
            os.execute (cmd)

            txPower = util.fileToString("/tmp/txPower")
            os.remove("/tmp/txPower")
            if (txPower ~= nil) then
                txPower = math.floor(txPower)
                radioRow["txPower"] = txPower
            end
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."TransmitPower", error_code.INVALID_PARAM_VALUE)
        end
    end

    --AutoChannelEnable
    if(inRow["dot11Radio.AutoChannelEnable"] ~= nil and inRow["dot11Radio.AutoChannelEnable"] ~= "") then
        if(inRow["dot11Radio.AutoChannelEnable"] == "1") then
            newAutoChanVal = "1"
        else
            newAutoChanVal = "0"
        end
    end

    --Enable Channel 12 13
    if(inRow["dot11Radio.radioCountryRev"] ~= nil and inRow["dot11Radio.radioCountryRev"] ~= "") then
        if(row["band"] == "b")then
            if(inRow["dot11Radio.radioCountryRev"] == "1") then
                radioRow["radioCountryRev"] = 991
            else
                if(inRow["dot11Radio.configuredChannel"] ~= nil and inRow["dot11Radio.configuredChannel"] ~= "")then
                    if(tonumber(inRow["dot11Radio.configuredChannel"]) == 12 or tonumber(inRow["dot11Radio.configuredChannel"]) == 13)then
                        status = ERROR
                        index = index + 1
                        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.REQUEST_DENIED)
                    else
                        radioRow["radioCountryRev"] = 987
                    end
                else
                    radioRow["radioCountryRev"] = 987
                end
            end
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.REQUEST_DENIED)
        end
    end

    --Channel => dot11Radio.configuredChannel
    if(newAutoChanVal == "0") then
        if(inRow["dot11Radio.configuredChannel"] ~= nil and inRow["dot11Radio.configuredChannel"] ~= "") then
            channel = inRow["dot11Radio.configuredChannel"]
        else
            -- set current channel if Channel is not set from ACS
            currentChannel = dot11Tr.getCurrentChannel(row["configuredChannel"], chipsetRow["Chipset"], row["radioNo"], row["interfaceName"])
            if(currentChannel ~= nil) then
                channel = currentChannel
            else
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            end
        end
        
        -- validate channel    
        channelStatus = dot11Tr.validateChannel(chipsetRow["Chipset"], channel, row["band"], row["interfaceName"], opModeVal, sideBandVal, radioRow["chanWidth"], purenVal)
        
        if(channelStatus == "0") then
            radioRow["configuredChannel"] = channel
        else
            if(inRow["dot11Radio.configuredChannel"] ~= nil and inRow["dot11Radio.configuredChannel"] ~= "") then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Channel", error_code.INVALID_PARAM_VALUE)
            elseif(inRow["dot11Radio.AutoChannelEnable"] ~= nil and inRow["dot11Radio.AutoChannelEnable"] ~= "") then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."AutoChannelEnable", error_code.REQUEST_DENIED)
            end
        end
    else
        -- set configuredChannel to 0, if AutoChannelEnable=1
        radioRow["configuredChannel"] = "0"
    end

    if (status ~= OK) then
        return status, faultTbl
    end

    --apply radio settings
    errorCode, statusMsg = gui.wireless.radio.set(radioRow, dbFlag)
    if(errorCode ~= "OK") then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        tr69Glue.tf1Dbg("Radio config failed, statusMsg = "..statusMsg)
        return status, faultTbl
    end
        
    -- AutoChannelRefreshPeriod
    if(inRow["dot11Radio.AutoChannelRefreshPeriod"] ~= nil and inRow["dot11Radio.AutoChannelRefreshPeriod"] ~= "") then
        if(chipsetRow["Chipset"] == "Broadcom") then
            local autoChanRefSetCmd = "nvram set "..row["interfaceName"].."_acs_cs_scan_timer='" .. inRow["dot11Radio.AutoChannelRefreshPeriod"] .. "'"
            tr69Glue.tf1Dbg("autoChanRefSetCmd = " .. autoChanRefSetCmd)
            os.execute(autoChanRefSetCmd)
            os.execute("nvram commit")
        end
    end
    
    os.execute("/bin/touch /tmp/dot11RadioChange.txt")

    db.save()
  
    return status, faultTbl
end

--[[
--*****************************************************************************
-- dot11Tr.radioStatsGet- get radio stats
-- 
-- This function is called to get the following parameters in
-- Device.WiFi.Radio.0.Stats.
--
-- BytesSent
-- BytesReceived
-- PacketsSent
-- PacketsReceived
-- ErrorsSent
-- ErrorsReceived
-- X_M_RetransCount
-- 
-- Returns: status, value
]]--
function dot11Tr.radioStatsGet (input)
    -- require
    require "teamf1lualib/ifDev"

    local status = "0"
    local value = 0
    local rowId
    local parentObjInstance = ""
    local row = {}
    local apCfgRow = {}
    local query = nil
    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "Radio.")
    parentObjInstance = string.sub(param, 1, endIdx+2)
    
    --read the rowId mapping to dot11Radio
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get correspnding db entry from dot11Radio 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("dot11Radio", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    query = "radioNo='" .. row["radioNo"] .. "'"
    dot11IFRows = db.getRowsWhere("dot11Interface", query, false)
            
    local radioStatsTbl = {}
    if(dot11IFRows ~= nil) then
        for k,v in pairs(dot11IFRows) do
            --get stats for this radio interface
            radioStatsTbl[k] = {}
            radioStatsTbl[k] = ifDevLib.interfaceStatsGet(v["interfaceName"])
        end
    end

    if(radioStatsTbl == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    local chipsetRow = db.getRowWhere("chipsetInfo", "_ROWID_=1", false)

    --find & return parameter values
    if(string.find(input["param"], "BytesSent")) then
        -- BytesSent
        value = 0
        for k,v in pairs(radioStatsTbl) do
            value = value + v["tx_bytes"]
        end
    elseif(string.find(input["param"], "BytesReceived")) then
        -- BytesReceived
        value = 0
        for k,v in pairs(radioStatsTbl) do
            value = value + v["rx_bytes"]
        end
    elseif(string.find(input["param"], "PacketsSent")) then
        -- PacketsSent
        value = 0
        for k,v in pairs(radioStatsTbl) do
            value = value + v["tx_packets"]
        end
    elseif(string.find(input["param"], "PacketsReceived")) then
        -- PacketsReceived
        value = 0
        for k,v in pairs(radioStatsTbl) do
            value = value + v["rx_packets"]
        end
    elseif(string.find(input["param"], "ErrorsSent")) then
        -- ErrorsSent
        value = 0
        for k,v in pairs(radioStatsTbl) do
            value = value + v["tx_errors"]
        end
    elseif(string.find(input["param"], "ErrorsReceived")) then
        -- ErrorsReceived
        value = 0
        for k,v in pairs(radioStatsTbl) do
            value = value + v["rx_errors"]
        end
    elseif(string.find(input["param"], "X_M_RetransCount")) then
        -- X_M_RetransCount
        if(chipsetRow["Chipset"] == "Broadcom") then
            cmd = "echo -n `/bin/wl -i " .. row["interfaceName"] .. " counters |grep trans|cut -d ' ' -f 6` > /tmp/retransCount"
            os.execute(cmd)
            retransCount = util.fileToString("/tmp/retransCount")
            os.remove("/tmp/retransCount")
            if (retransCount ~= nil) then
                value = retransCount
            else
                return "1", "DB_ERROR_TRY_AGAIN"
            end
        end
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- dot11Tr.radioModeParamsGet- get wlan radio mode configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.WiFi.Radio.0.
--
-- OperatingStandards
-- OperatingChannelBandwidth
-- ExtensionChannel
-- PossibleChannels
-- AutoChannelSupported
-- AutoChannelEnable
-- Channel
--
-- Returns: status, value
]]--
function dot11Tr.radioModeParamsGet (input)
    local status = "0"
    local value = "0"
    local row = {}
    local query = nil
    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --read the rowId mapping to dot11Profile
    rowId = instanceMap[param]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from dot11Profile 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("dot11Radio", query, false)
    if (row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    local chipsetRow = db.getRowWhere("chipsetInfo", "_ROWID_=1", false)

    --find & return parameter values
    if(string.find(input["param"], "OperatingStandards")) then
        -- OperatingStandards
        if (string.find(row["opMode"], "ng")) then
            value = "n,g"
        elseif(string.find(row["opMode"], "g only")) then
            value = "g"
        elseif(string.find(row["opMode"], "b and g")) then
            value = "b,g"
        else
            return "1", "DB_ERROR_TRY_AGAIN"
        end
    elseif(string.find(input["param"], "OperatingChannelBandwidth")) then
        -- OperatingChannelBandwidth
        if (row["chanWidth"] == "20") then
            value = "20MHz"
        elseif (row["chanWidth"] == "2040") then
            value = "Auto"
        elseif (row["chanWidth"] == "40") then
            value = "40MHz"
        else
            return "1", "DB_ERROR_TRY_AGAIN"
        end
    elseif(string.find(input["param"], "ExtensionChannel")) then
        -- ExtensionChannel
        --In gui radio configuration page,
        --Extension Sub-Channel=Lower is dot11Radio.opMode=ng40+
        --Extension Sub-Channel=Upper is dot11Radio.opMode=ng40-
        if (string.find(row["opMode"], "+")) then
            value = "BelowControlChannel"
        elseif (string.find(row["opMode"], "-")) then
            value = "AboveControlChannel"
        else
            value = "Auto"
        end
    elseif(string.find(input["param"], "PossibleChannels")) then
        -- PossibleChannels
        if (string.find(row["opMode"], "ng")) then
            if(string.find(row["chanWidth"], "40")) then
                --In gui radio configuration page,
                --Extension Sub-Channel=Lower is dot11Radio.opMode=ng40+
                --Extension Sub-Channel=Upper is dot11Radio.opMode=ng40-
                if(string.find(row["opMode"], "+")) then
                    value = "0,5-11"
                elseif(string.find(row["opMode"], "-")) then
                    value = "0-9"
                else
                    return "1", "DB_ERROR_TRY_AGAIN"
                end
            else
                value = "0-11"
            end
        else
            value = "0-11"
        end
    elseif(string.find(input["param"], "AutoChannelSupported")) then
        -- AutoChannelSupported
		value="1"
    elseif(string.find(input["param"], "AutoChannelEnable")) then
        -- AutoChannelEnable
        if (row["configuredChannel"] == "0") then
            value="1"
        else
            value="0"
        end
    elseif(string.find(input["param"], "Channel")) then
        if(row["configuredChannel"] == "0") then
            --we should get the channel from interface which is up and running instead of radio interface.
            if(chipsetRow["Chipset"] == "Broadcom") then
                local firstEnabledVapRow = {}
                local radioInterfaceName = ""
                local channel = row["configuredChannel"] --put channel as 0
                firstEnabledVapRow = db.getRowWhere("dot11VAP","radioList='"..row["radioNo"].."' and vapEnabled='1'",false)
                radioInterfaceName = row["interfaceName"]
                if(firstEnabledVapRow ~= nil)then
                    local vapInterfaceName = db.getAttribute("dot11Interface","vapName",firstEnabledVapRow["vapName"],"interfaceName")
                    os.execute ("/bin/echo -n `/bin/wl -i " .. vapInterfaceName .. " status |grep Primary|cut -d ':' -f 2 ` > /tmp/channel1")
                else
                    os.execute ("/bin/echo -n `/bin/wl -i " .. radioInterfaceName .. " status |grep Primary|cut -d ':' -f 2 ` > /tmp/channel1")
                end
                channel = util.fileToString("/tmp/channel1")
                if (channel ~= nil) then
                    value = channel
                else
                    return "1", "DB_ERROR_TRY_AGAIN"
                end
            else
                local ifname = db.getAttribute("dot11Interface", "_ROWID_", "1", "interfaceName")
                local cmd = "iwlist " ..ifname.." ch | awk '/Current/ {print $2}' | cut -d \"=\" -f 2 > /tmp/currentChannel.txt"
                os.execute(cmd)
                local file = io.open("/tmp/currentChannel.txt","r")
                channel = file:read("*line")
                if (channel ~= nil) then
                    value = channel
                else
                    return "1", "DB_ERROR_TRY_AGAIN"
                end 
            end
        else
		    value = row["configuredChannel"]
        end
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- dot11Tr.radioModeParamsSet- set wlan radio mode configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.WiFi.Radio.0.
--
-- OperatingStandards
-- OperatingChannelBandwidth
-- ExtensionChannel
-- AutoChannelEnable
-- Channel
--
-- Returns: status
]]--
function dot11Tr.radioModeParamsSet(input, rowids, actionType, tr69Param)
    --Configuring any of these values is currently not supported in this device
    local status = "0"
    local inRow = {}
    local k,v

    inRow = input["dot11Radio"]

    local newStandardVal --OperatingStandards
    local newOcbVal      --OperatingChannelBandwidth
    local newExtChanVal  --ExtensionChannel
    local newAutoChanVal --AutoChannelEnable
    local newChanVal     --Channel
    local row = {}
    local query = nil
    local nModeFlag = "0"
    local wideModeFlag = "0"

    --get corresponding db entry from dot11Radio
    query = "_ROWID_=1"
    row = db.getRowWhere ("dot11Radio", query, false)
    if (row == nil) then
        status = "1"
        return status
    end

    --OperatingStandards => dot11Radio.opMode
    if(inRow["dot11Radio.opMode"] ~= nil and inRow["dot11Radio.opMode"] ~= "") then
        if(inRow["dot11Radio.opMode"] == "b,g" or inRow["dot11Radio.opMode"] == "g,b") then
            newStandardVal = "b and g"
        elseif(inRow["dot11Radio.opMode"] == "g") then
            newStandardVal = "g only"
        elseif(inRow["dot11Radio.opMode"] == "n,g" or inRow["dot11Radio.opMode"] == "g,n") then
            --check if any profile is configured with security mode WEP or WPA, if exists
            --then changing to 802.11n mode is not allowed
            local conflictingProfiles = db.existsRowWhere("dot11Profile", "security='WEP' or security='WPA'")
            if (conflictingProfiles) then
                tr69Glue.tf1Dbg("there are profile having security mode set as WEP/WPA, can't set opMode to n..")
                status = "1"
                return 1;
            end
            newStandardVal = "ng"
        else
            tr69Glue.tf1Dbg("OperatingStandards value -- " .. inRow["dot11Radio.opMode"] .. " is not valid")
            status = "1"
            return status
        end
    else
        newStandardVal = row["opMode"]
    end

    if(string.find(newStandardVal, "ng")) then
        nModeFlag = "1"
    end

    --OperatingChannelBandwidth => dot11Radio.chanWidth
    if(inRow["dot11Radio.chanWidth"] ~= nil and inRow["dot11Radio.chanWidth"] ~= "") then
        if(inRow["dot11Radio.chanWidth"] == "20MHz") then
            newOcbVal = "20"
        elseif(inRow["dot11Radio.chanWidth"] == "Auto") then
            newOcbVal = "2040"
        elseif(inRow["dot11Radio.chanWidth"] == "40MHz") then
            newOcbVal = "40"
        else
            tr69Glue.tf1Dbg("OCB value -- " .. inRow["dot11Radio.chanWidth"] .. " is not valid")
            status = "1"
            return status
        end
    else
        newOcbVal = row["chanWidth"]
    end

    if(string.find(newOcbVal, "40")) then
        wideModeFlag = "1"
    end

    --ExtensionChannel => dot11Radio.opMode(+/-)
    local extChanSign = "none"
    if(inRow["dot11Radio.sideBand"] ~= nil and inRow["dot11Radio.sideBand"] ~= "") then
        if(inRow["dot11Radio.sideBand"] == "BelowControlChannel") then
            extChanSign = "+"
        elseif(inRow["dot11Radio.sideBand"] == "AboveControlChannel") then
            extChanSign = "-"
        else
            extChanSign = "none"
        end
    end

    --AutoChannelEnable 
    newAutoChanVal = "0"
    if(inRow["dot11Radio.ROWID"] ~= nil and inRow["dot11Radio.ROWID"] ~= "") then
        if(inRow["dot11Radio.ROWID"] == "1") then
            newAutoChanVal = "1"
        else
            newAutoChanVal = "0"
        end
    end

    --Channel => dot11Radio.configuredChannel
    if(newAutoChanVal == "1") then
        newChanVal = "0"
    else
        if(inRow["dot11Radio.configuredChannel"] ~= nil and 
           inRow["dot11Radio.configuredChannel"] ~= "") then
            newChanVal = inRow["dot11Radio.configuredChannel"]
        else
            newChanVal = row["configuredChannel"]
        end
    end

    if(tonumber(newChanVal) < 0 or tonumber(newChanVal) > 13) then
        tr69Glue.tf1Dbg("Channel value -- " .. tonumber(newChanVal) .. " is invalid")
        status = "1"
        return status
    end

    --populate the row to be updated into the table
    local radioRow = {}
    radioRow = row
    if(nModeFlag == "1") then 
        radioRow["chanWidth"] = newOcbVal
    else
        radioRow["chanWidth"] = "20"
    end

    if(nModeFlag == "1" and wideModeFlag == "1") then
        if(extChanSign == "+") then
            radioRow["opMode"] = "ng40+"
        elseif(extChanSign == "-") then
            radioRow["opMode"] = "ng40-"
        else
            --default ExtensionChannel is lower
            radioRow["opMode"] = "ng40+"
        end
    else
        radioRow["opMode"] = newStandardVal
    end

    if(newChanVal == "0") then
        radioRow["configuredChannel"] = "0"
    else
        if(radioRow["opMode"] == "ng40+") then
            --allowed values are 0 and 5-11
            if(tonumber(newChanVal) < 5 or tonumber(newChanVal) > 13) then
                tr69Glue.tf1Dbg("Channel value+ -- " .. tonumber(newChanVal) .. " is invalid")
                status = "1"
                return status
            end
            radioRow["configuredChannel"] = newChanVal
        elseif(radioRow["opMode"] == "ng40-") then
            --allowed values are 0 and 1-9
            if(tonumber(newChanVal) < 1 or tonumber(newChanVal) > 9) then
                tr69Glue.tf1Dbg("Channel value- -- " .. tonumber(newChanVal) .. "is invalid")
                status = "1"
                return status
            end
            radioRow["configuredChannel"] = newChanVal
        else
            radioRow["configuredChannel"] = newChanVal
        end
    end

    --apply radio settings
    local errorCode,statusMsg
    radioRow = util.addPrefix(radioRow, "dot11Radio.")
    errorCode,statusMsg = dot11.radio_config(radioRow, radioRow["dot11Radio._ROWID_"] , "edit")
    db.save()
    if(util.fileExists("/pfrm2.0/BRCMJCO300"))then
        os.execute("sleep 3")
    end
  
    return 0;
end

function dot11Tr.getChannelList(chipset, band, interface, opMode, sideband, chanWidth, puren)
    local CHANNELPATH = "/tmp/channelList"
    local chnListTbl = {}
    local cmd = ""

    if(chipset == "Broadcom") then
        if(band == "b") then
            if((opMode == "4" and chanWidth == "2040") or (opMode == "5" and chanWidth == "2040" )) then
                if(sideband == "0") then
                    cmd = " wl -i "..interface.. " chanspecs | cut -d' ' -f 1 | grep l | cut -d'l' -f 1 > " .. CHANNELPATH
                elseif(sideband == "1") then
                    cmd = " wl -i "..interface.. " chanspecs | cut -d' ' -f 1 | grep u | cut -d'u' -f 1 > " .. CHANNELPATH
                end
            elseif(opMode == "1" or (opMode == "4" and chanWidth == "20") or (opMode == "5" and chanWidth == "20") or opMode == "6") then
                cmd = "wl -i " .. interface .. " chan_info |awk '{print($2)}' > " .. CHANNELPATH
            end
        elseif(band == "a") then
            if((opMode == "2" and chanWidth == "2040") or (opMode == "3" and chanWidth == "2040")) then
                if(sideband == "0") then
                    cmd = " wl -i "..interface.. " chanspecs | cut -d' ' -f 1 | grep l | cut -d'l' -f 1 > " .. CHANNELPATH
                elseif(sideband == "1") then
                    cmd = " wl -i "..interface.. " chanspecs | cut -d' ' -f 1 | grep u | cut -d'u' -f 1 > " .. CHANNELPATH
                end
            elseif(opMode == "1" or (opMode == "2" and chanWidth == "20") or (opMode == "3" and chanWidth == "20")) then
                cmd = "wl -i " .. interface .. " chan_info |awk '{print($2)}' > " .. CHANNELPATH
            elseif((opMode == "2" and chanWidth == "80") or (opMode == "3" and chanWidth == "80")) then
                cmd = "wl -i " .. interface .. " chanspecs | grep / | cut -d'/' -f 1 > "  .. CHANNELPATH
            end
        end

        tr69Glue.tf1Dbg("cmd : " .. cmd)
        os.execute(cmd)
        local file = io.open(CHANNELPATH,"r")
        if(file ~= nil) then
            local i = 1
            for line in io.lines(CHANNELPATH) do
                chnListTbl[i] = line
                i = i+1
            end
        file:close()
        end
        os.remove(CHANNELPATH)
    else
        if(band == "b") then
            if((opMode == "b and g" and chanWidth == "20") or (opMode == "g only" and chanWidth == "20") or (opMode == "ng" and puren == "0" and chanWidth == "20") or (opMode == "ng" and puren == "1" and chanWidth == "20")) then
                for i=1,13 do
                    chnListTbl[i] = i
                end
            elseif((opMode == "ng" and puren == "0" and chanWidth == "2040") or (opMode == "ng" and puren == "1" and chanWidth == "2040") or (opMode == "ng" and puren == "0" and chanWidth == "40") or (opMode == "ng" and puren == "1" and chanWidth == "40")) then
                if(sideband == "0") then
                    k = 5
                    for i=1,9 do
                        chnListTbl[i] = k
                        k = k + 1
                    end
                elseif(sideband == "1") then
                    for i=1,9 do
                        chnListTbl[i] = i
                    end
                end
            end
        end
    end
    
    return chnListTbl
end

function dot11Tr.validateChannel(chipset, channel, band, radioInterface, opMode, sideband, chanWidth, puren)
    local status = "1"
    local chnTbl = {}

    chnTbl = dot11Tr.getChannelList(chipset, band, radioInterface, opMode, sideband, chanWidth, puren)

    for key,value in pairs(chnTbl) do
        if(tonumber(value) == tonumber(channel)) then
            status = "0"
            return status
        end
    end
        
    return status
end

function dot11Tr.validateChannelList(channel, band, radioInterface, opMode, sideband, chanWidth, puren)
    local status = "0"
    local chnTbl = {}

    if(band == "b") then
        if((opMode == "b and g" and chanWidth == "20") or (opMode == "g only" and chanWidth == "20") or (opMode == "ng" and puren == "0" and chanWidth == "20") or (opMode == "ng" and puren == "1" and chanWidth == "20")) then
            if(tonumber(channel) < 1 or tonumber(channel) > 13) then
                status = "1"
                return status
            end
        elseif((opMode == "ng" and puren == "0" and chanWidth == "2040") or (opMode == "ng" and puren == "1" and chanWidth == "2040") or (opMode == "ng" and puren == "0" and chanWidth == "40") or (opMode == "ng" and puren == "1" and chanWidth == "40")) then
            if(sideband == "0") then
                if(tonumber(channel) < 5 or tonumber(channel) > 13) then
                    status = "1"
                    return status
                end
            elseif(sideband == "1") then
                if(tonumber(channel) < 1 or tonumber(channel) > 9) then
                    status = "1"
                    return status
                end
            end
        end
    end

    return status
end

--[[
--*****************************************************************************
-- dot11Tr.radioChannelSet- set wlan radio mode configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.WiFi.Radio.0.
--
-- Channel
--
-- Returns: status
]]--
function dot11Tr.radioChannelSet(input, rowids, actionType, tr69Param)
    --Configuring any of these values is currently not supported in this device
    local status = OK
    local inRow = {}
    local radioRow = {}
    local faultTbl = {}
    local index = 0

    inRow = input["dot11Radio"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    --read the rowId mapping to bridgeTable
    rowId = instanceMap[tr69Param]
    if (rowId == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    --get corresponding db entry from dot11Radio
    query = "_ROWID_=" ..rowId
    row = db.getRowWhere ("dot11Radio", query, false)
    if (row == nil) then
        status = "1"
        return status
    end
    
    radioRow = row

    local channelStatus

    local chipsetRow = db.getRowWhere("chipsetInfo", "_ROWID_=1", false)
    if(inRow["dot11Radio.configuredChannel"] ~= nil and inRow["dot11Radio.configuredChannel"] ~= "") then
        if(chipsetRow["Chipset"] == "Broadcom") then
            channelStatus = dot11Tr.validateChannel(inRow["dot11Radio.configuredChannel"], row["band"], row["interfaceName"], row["opMode"], row["sideBand"], row["chanWidth"])
        else
            channelStatus = dot11Tr.validateChannelList(inRow["dot11Radio.configuredChannel"], row["band"], row["interfaceName"], row["opMode"], row["sideBand"], row["chanWidth"], row["puren"])
        end

        if(channelStatus == "0") then
            radioRow["configuredChannel"] = inRow["dot11Radio.configuredChannel"]
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Channel", error_code.INVALID_PARAM_VALUE)
            return status, faultTbl
        end
    end

    -- apply radio settings
    local errorCode,statusMsg
    radioRow = util.addPrefix(radioRow, "dot11Radio.")
    errorCode,statusMsg = dot11.radio_config(radioRow, radioRow["dot11Radio._ROWID_"] , "edit")
    if(util.fileExists("/pfrm2.0/BRCMJCO300"))then
        os.execute("sleep 3")
    end
  
    db.save()
    return 0;
end

--[[
--*****************************************************************************
-- dot11Tr.profileToAPCfgGet - get AP configuration mapped to the given profile
-- 
-- This function fetches following AP related information,
--
-- interfaceName
-- macaddr
--
-- Returns: lua tbl containing AP configuration
]]--
function dot11Tr.profileToAPCfgGet(profileName)
    local apCfgTbl = {}
    local query = ""
    local vapRow = {}
    local ifaceRow = {}

    apCfgTbl["macaddr"] = "00:00:00:00:00:00"

    --get correspnding db entry from dot11VAP
    query = "profileName='" .. profileName .. "'"
    vapRow = db.getRowWhere ("dot11VAP", query, false)
    if(vapRow == nil) then
        tr69Glue.tf1Dbg("Couldn't find an AP in dot11VAPmapping to profileName:" .. profileName)
        return apCfgTbl
    end

    --get correspnding db entry from dot11Interface
    query = "vapName='" .. vapRow["vapName"] .. "'"
    ifaceRow = db.getRowWhere ("dot11Interface", query, false)
    if(ifaceRow == nil) then
        tr69Glue.tf1Dbg("Couldn't find an iface having this vapName:" .. vapRow["vapName"])
        return apCfgTbl
    end

    apCfgTbl["interfaceName"] = ifaceRow["interfaceName"]
    apCfgTbl["macaddr"] = ifDevLib.getMac (ifaceRow["interfaceName"])
    
    return apCfgTbl
end

--[[
--*****************************************************************************
-- dot11Tr.ssidCfgGet- get wlan ssid profile configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.WiFi.SSID.0.
--
-- Enable
-- Status
-- Name
-- LowerLayers
-- BSSID
-- MACAddress
-- SSID
-- 
-- Returns: status, value
]]--
function dot11Tr.ssidCfgGet (input)
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local row = {}
    local dot11VAPRow = {}
    local dot11InterfaceRow = {}
    local apCfgRow = {}
    local query = nil
    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "SSID.")
    parentObjInstance = string.sub(param, 1, endIdx+2)
    
    --read the rowId mapping to dot11Profile
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from dot11Profile 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("dot11Profile", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    query = "profileName='" .. row["profileName"] .. "'"
    dot11VAPRow = db.getRowWhere ("dot11VAP", query, false)
    if(dot11VAPRow == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    query = "vapName='" .. dot11VAPRow["vapName"] .. "'"
    dot11InterfaceRow = db.getRowWhere ("dot11Interface", query, false)
    if(dot11InterfaceRow == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = dot11VAPRow["vapEnabled"]
    elseif(string.find(input["param"], "Status")) then 
        -- Status
        if(dot11VAPRow["vapEnabled"] == "1") then
            value = "up"
        else
            value = "Down"
        end
    elseif(string.find(input["param"], "Name")) then
        -- Name
        value = row["profileName"]
    elseif(string.find(input["param"], "LowerLayers")) then
        -- LowerLayers 
        if(dot11VAPRow["vapEnabled"] == "1") then
            value = "Device.WiFi.Radio." ..dot11InterfaceRow["radioNo"].. "."
        else
            value = ""
        end
    elseif(string.find(input["param"], "BSSID")) then
        -- BSSID
        apCfgRow = dot11Tr.profileToAPCfgGet(row["profileName"])
        value = apCfgRow["macaddr"]
    elseif(string.find(input["param"], "MACAddress")) then
        -- MACAddress
        apCfgRow = dot11Tr.profileToAPCfgGet(row["profileName"])
        value = apCfgRow["macaddr"]
    elseif(string.find(input["param"], "SSID")) then
        -- SSID
        value = row["ssid"]
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- dot11Tr.ssidCfgSet- set the wlan parameters
-- 
-- This funtion is used to below set the params in
-- Device.WiFi.SSID.0.Enable
--
-- Enable
-- SSID
--
-- Returns: status
]]--
function dot11Tr.ssidCfgSet(input, rowids, actionType, tr69Param)
    require "teamf1lualib/gui"
    require "teamf1lualib/dot11_ul"

    local status = OK
    local rowId
    local query = nil
    local row = {}
    local apConfTbl = {}
    local profileCfgTbl = {}
    local dot11InterfaceRow = {}
    local faultTbl = {}
    local index = 0
    local apStatusFlag = 0
    local profileCfgFlag = 0

    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        tr69Glue.tf1Dbg("instanceMapLoad failed..")
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl 
    end

    rowId = instanceMap[tr69Param]
    if (rowId == nil) then
        tr69Glue.tf1Dbg("No instance found for -- " .. tr69Param)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl 
    end
   
    local rows = {}
    rows["1"] = rowId

    --get correspnding db entry from dot11Profile 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("dot11Profile", query)
    if(row == nil) then
        tr69Glue.tf1Dbg("No entry in dot11Profile with rowId -- " .. rowId)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl 
    end

    --get correspnding db entry from dot11VAP 
    query = "profileName='" .. row["dot11Profile.profileName"] .. "'"
    dot11VAPRow = db.getRowWhere ("dot11VAP", query, false)
    if(dot11VAPRow == nil) then
        tr69Glue.tf1Dbg("No entry in dot11VAP with profileName -- " .. row["dot11Profile.profileName"] )
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    --get correspnding db entry from dot11Interface 
    query = "vapName='" .. dot11VAPRow["vapName"] .. "'"
    dot11InterfaceRow = db.getRowWhere ("dot11Interface", query, false)
    if(dot11InterfaceRow == nil) then
        tr69Glue.tf1Dbg("No entry in dot11Interface with vapName -- " .. dot11VAPRow["vapName"])
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    profileCfgTbl = row
    profileCfgTbl["_ROWID_"] = rowId

    apConfTbl = dot11VAPRow

    --Enable
    if(input["dot11Profile"]["dot11Profile.Enable"] ~= nil) then 
        apConfTbl["vapEnabled"] = input["dot11Profile"]["dot11Profile.Enable"]

        --EoGRE Check
        statusCode, errMsg = eogreAPcheck (rows)
        if (statusCode == "ERROR")then
            tr69Glue.tf1Dbg("Eogre is enabled, errMsg : "..errMsg)
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Enable", error_code.REQUEST_DENIED)
        end
        apStatusFlag = 1
    end
        
    --SSID
    if (input["dot11Profile"]["dot11Profile.ssid"] ~= nil) then
        profileCfgTbl["dot11Profile.ssid"] = input["dot11Profile"]["dot11Profile.ssid"]

        -- EoGRE checking
        statusCode, errMsg = eogrecheck (profileCfgTbl)
        if (statusCode == "ERROR")then
            tr69Glue.tf1Dbg("Eogre is enabled, errMsg : "..errMsg)
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Enable", error_code.REQUEST_DENIED)
        elseif((tr69Glue.tf1ValidateStringLength(SSID_MIN_LEN, SSID_MAX_LEN, profileCfgTbl["dot11Profile.ssid"], "") ~= "OK") or (dot11Tr.checkForSpace(profileCfgTbl["dot11Profile.ssid"]) == 1) or (string.find(profileCfgTbl["dot11Profile.ssid"], '"'))) then
            tr69Glue.tf1Dbg("SSID length is invalid or SSID has all spaces or found double quote..")
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."SSID", error_code.INVALID_PARAM_VALUE)
        elseif (string.match (profileCfgTbl["dot11Profile.ssid"], "[^\001-\127]") ~= nil) then
            tr69Glue.tf1Dbg("SSID contain non ASCII Charaters..")
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."SSID", error_code.INVALID_PARAM_VALUE)             
        else
            statusCode, errMsg = duplicateSSIDcheck(profileCfgTbl)
            if (statusCode == "ERROR") then
                tr69Glue.tf1Dbg("error msg: ".. errMsg)
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."SSID", error_code.REQUEST_DENIED)
            end
        end
        profileCfgFlag = 1
    end

    if(status ~= OK) then
        return status, faultTbl
    end

    --apply ap enable/disable settings
    if(apStatusFlag == 1) then
        if(apConfTbl["vapEnabled"] == "1") then
            operation = "enable"
        else
            operation = "disable"
        end

        errorCode, statusMsg = gui.wireless.apProfileInfo.status (rows, operation, dbFlag)
        if(errorCode ~= "OK") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            tr69Glue.tf1Dbg("AP config failed, statusMsg = "..statusMsg)
            return status, faultTbl
        end 
        os.execute("/bin/touch /tmp/APStatusChange.txt")
    end

    --apply profile settings
    if(profileCfgFlag == 1) then
        errorCode, statusMsg = gui.wireless.profileInfo.set (profileCfgTbl, "edit", dbFlag)
        if(errorCode ~= "OK") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            tr69Glue.tf1Dbg("Profile config failed, statusMsg = "..statusMsg)
            return status, faultTbl
        end
        os.execute("/bin/touch /tmp/APProfileChange.txt")
    end

    db.save()

    return status, faultTbl
end

--[[
--*****************************************************************************
-- dot11Tr.ssidProfileGet- get wlan ssid profile configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.WiFi.SSID.0.
--
-- Enable
-- Status
-- Name
-- BSSID
-- MACAddress
-- SSID
--
-- Returns: status, value
]]--
function dot11Tr.ssidProfileGet (input)
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local row = {}
    local apCfgRow = {}
    local query = nil
    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "SSID.")
    parentObjInstance = string.sub(param, 1, endIdx+2)
    
    --read the rowId mapping to dot11Profile
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from dot11Profile 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("dot11Profile", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = "1"
    elseif(string.find(input["param"], "Status")) then
        -- Status
		value = "Up"
    elseif(string.find(input["param"], "Name")) then
        -- Name
		value = row["profileName"]
    elseif(string.find(input["param"], "LowerLayers")) then
        -- LowerLayers 
        query = "profileName='" .. row["profileName"] .. "'"
        local vapRow = db.getRowWhere ("dot11VAP", query, false)

        query = "vapName='" .. vapRow["vapName"] .. "'"
        local dot11InterfaceRow = db.getRowWhere ("dot11Interface", query, false)

        if(vapRow["vapEnabled"] == "1") then
            value = "Device.WiFi.Radio." ..dot11InterfaceRow["radioNo"].. "."
        else
            value = ""
        end
    elseif(string.find(input["param"], "BSSID")) then
        -- BSSID
        apCfgRow = dot11Tr.profileToAPCfgGet(row["profileName"])
        value = apCfgRow["macaddr"]
    elseif(string.find(input["param"], "MACAddress")) then
        -- MACAddress
        apCfgRow = dot11Tr.profileToAPCfgGet(row["profileName"])
        value = apCfgRow["macaddr"]
    elseif(string.find(input["param"], "SSID")) then
        -- SSID
		value = row["ssid"]
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end



--[[
--*****************************************************************************
-- dot11Tr.singleLedCtl
-- 
-- This function controlls the LEDs based on the AP enable/disable for single
-- led devices
]]--
function dot11Tr.singleLedCtl()
    -- Wireless LED section. If any one of the AP is enabled,
    -- enable wireless LED, else disable wireless led. 
    local vapEnabled = {}
    vapEnabled = db.getRows ("dot11VAP", "vapEnabled", "1")

    --to check if internet is up, check if /tmp/internetUp exists
    local internetUP = util.fileExists("/tmp/internetUp")
    local wpsON = util.fileExists ("/tmp/wpsON")
    local radioInterface = db.getAttribute ("dot11Radio", "radioNo", "1", "interfaceName")

    if not (wpsON) then
        local gponExistsCheck = util.fileExists ("/tmp/gponFailed")
        local acsFileExistsCheck = util.fileExists ("/tmp/acsFailed")
        local internetConnCheck = util.fileExists ("/tmp/internetConnDown")
        if not (gponExistsCheck) then
            if (internetUP) then
                os.execute("/bin/ledctl1 ALL off") 
                if (acsFileExistsCheck) then
                    os.execute("/bin/ledctl1 RED fastBlink;") 
                else
                    if ((vapEnabled == nil) or (#vapEnabled == 0)) then
                        os.execute("/sbin/ifconfig "..radioInterface.." down")
                        os.execute("/bin/ledctl1 BLUE on;") 
                    else
                        os.execute("/bin/ledctl1 GREEN on;")
                    end
                end
            else
                if (internetConnCheck) then
                    os.execute("/bin/ledctl1 ALL off") 
                    os.execute("/bin/ledctl1 RED fastBlink;")
                else
                    os.execute("/bin/ledctl1 ALL off") 
                    if ((vapEnabled == nil) or (#vapEnabled == 0)) then
                        os.execute("/sbin/ifconfig "..radioInterface.." down")
                        os.execute("/bin/ledctl1 BLUE fastBlink;")
                    else
                        os.execute("/bin/ledctl1 GREEN fastBlink;")
                    end
                end
            end
        else
            os.execute("/bin/ledctl1 ALL off")
            os.execute("/bin/ledctl1 RED fastBlink;")
        end
    end
end

--[[
--*****************************************************************************
-- dot11Tr.multiLedCtl
-- 
-- This function controlls the LEDs based on the AP/WPS enable/disable for multi
-- led devices
]]--
function dot11Tr.multiLedCtl()
    -- Wireless LED section . If any one of the AP is enabled , enable wireless LED , else disable wireless led. 
    local vapEnabled = {}
    vapEnabled = db.getRows ("dot11VAP", "vapEnabled", "1")
    if ((vapEnabled == nil) or (#vapEnabled == 0)) then
	    os.execute(LED_CMD.. " " ..WIREESS_LED.." "..OP_OFF)
    else
	    os.execute(LED_CMD.. " " ..WIREESS_LED.." "..OP_ON)
    end

    --WPS LED
    local wpsEnabled = "0"
    wpsEnabled = db.getAttribute ("dot11WPS", "_ROWID_", "1" ,"wpsEnabled")
    if (wpsEnabled == "1") then
	    os.execute(LED_CMD.. " " ..WPS_LED.." "..OP_ON)
    else
	    os.execute(LED_CMD.. " " ..WPS_LED.." "..OP_OFF)
    end 
end

--[[
--*****************************************************************************
-- dot11Tr.ssidEnableSet- set the wlan enable parameter related to ssid
-- 
-- This funtion is userd to enable or disable the ssid
-- Device.WiFi.SSID.0.Enable
--
-- Returns: status
]]--
function dot11Tr.ssidEnableSet(input, rowids, actionType, tr69Param)
    local status = OK
    local row = {}
    local rowId
    local query = nil
    local apConfTbl = {}
    local valid
    local faultTbl = {}
    local index = 0

    local instanceMap = tr69Glue.instanceMapLoad()
  
    if (instanceMap == nil) then
        tr69Glue.tf1Dbg("instanceMapLoad failed..")
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl 
    end

    rowId = instanceMap[tr69Param]
    if (rowId == nil) then
        tr69Glue.tf1Dbg("No instance found for -- " .. tr69Param)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl 
    end
    
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("dot11Profile", query, false)

    if(row == nil) then
        tr69Glue.tf1Dbg("No entry in dot11Profile with rowId -- " .. rowId)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl 
    end

    query = "profileName='" .. row["profileName"] .. "'"
    Row = db.getRowWhere ("dot11VAP", query, false)
    
    if(Row == nil) then
        tr69Glue.tf1Dbg("No entry in dot11VAP with profileName -- " .. row["profileName"] )
	    tr69Glue.tf1Dbg("The profile " .. row["profileName"] .. " is not being used by any access point")
        return "0";
    end

     apConfTbl = Row
    
    local dot11InterfaceRow = {}
    query = "vapName='" .. apConfTbl["vapName"] .. "'"
    dot11InterfaceRow = db.getRowWhere ("dot11Interface", query, false)

    if(input["dot11Profile"]["dot11Profile.ROWID"] ~= nil) then 
        local rowEogre = db.getRowWhere ("Eogre", "_ROWID_=1", false) 
        if(rowEogre["Enable"] == "1" and rowEogre["ModeOfOperation"] == "1" and (Row["profileName"] == "Jio_2" or Row["profileName"] == "Jio_5")) then
            tr69Glue.tf1Dbg("Eogre is enabled .. ")
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Enable", error_code.REQUEST_DENIED)
                return status, faultTbl 
	    end

        apConfTbl["vapEnabled"] = input["dot11Profile"]["dot11Profile.ROWID"]

        query = "vapName='" .. dot11InterfaceRow["interfaceName"] .. "'"
        local dot11WpsRow = db.getRowWhere ("dot11WPS", query, false) 

        --[[
        if(dot11WpsRow ~= nil) then
            if(input["dot11Profile"]["dot11Profile.ROWID"] == "0") then
                if(dot11WpsRow["wpsEnabled"] == "1") then
                    tr69Glue.tf1Dbg("Disabling WPS for ap"..rowId)
                    local wpsTable = {}
                    wpsTable["dot11WPS.vapName"] = dot11WpsRow["vapName"]
                    wpsTable["dot11WPS.wpsEnabled"] = "0"
                    local errorCode, statusMsg = dot11.WPS_config(wpsTable, dot11WpsRow["_ROWID_"], "edit")
                    if(errorCode ~= "OK") then
                        status = ERROR
                        index = index + 1
                        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Enable", error_code.INTERNAL_ERROR)
                        tr69Glue.tf1Dbg("error while saving the configuration - "..statusMsg)
                        return status, faultTbl 
                    end
                end
            end 
        end
        ]]--
    end

    --apply ap settings
    apConfTbl = util.addPrefix(apConfTbl, "dot11VAP.")
    if(util.fileExists ("/pfrm2.0/HW_JCO410") or util.fileExists ("/pfrm2.0/HW_JCE410")) then
        local errorCode, statusMsg = dot11.VAP_config(apConfTbl, apConfTbl["dot11VAP._ROWID_"], "edit")
        local vaprows = db.getRowsWithJoin({"dot11VAP:dot11Interface:vapName"}, "dot11VAP.vapName",apConfTbl["dot11VAP.vapName"])
        if (apConfTbl["dot11VAP.vapEnabled"] == "1") then
            status = true
        else
            status = false
        end
        for k,v in pairs(vaprows) do
            -- apply the settings on vap
            config.recOp(dot11.VAP_start, apConfTbl["dot11VAP.vapName"], status)
            config.recOp(dot11.if_up ,v["dot11Interface.interfaceName"], tonumber(apConfTbl["dot11VAP.vapEnabled"]))
        end
    else
        valid = db.setAttribute("dot11VAP", "_ROWID_", rowId, "vapEnabled", apConfTbl["dot11VAP.vapEnabled"]) 

        if(not valid) then
            tr69Glue.tf1Dbg("error while saving the configuration..")
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl
        end

        local radioInterfaceName= db.getAttribute("dot11Radio","radioNo",dot11InterfaceRow["radioNo"],"interfaceName")
  
        os.execute("/bin/wlconf " ..radioInterfaceName.. " down")
        local cmdStr = NVRAM_CMD_BINARY .. " set "..dot11InterfaceRow["interfaceName"].."_bss_enabled='"..apConfTbl["dot11VAP.vapEnabled"].."'"
        os.execute(cmdStr)
        os.execute(NVRAM_CMD_COMMIT)
        cmdStr = WL_CMD_BINARY.. " -i " ..dot11InterfaceRow["interfaceName"].. " ssid '"..row["ssid"].."'"
        os.execute(cmdStr)
        if tonumber(apConfTbl["dot11VAP.vapEnabled"]) == 1 then
            cmdStr = WL_CMD_BINARY.. " -i " ..dot11InterfaceRow["interfaceName"].. " bss up"
            os.execute(cmdStr)
            os.execute ("/sbin/ifconfig " .. dot11InterfaceRow["interfaceName"] .. " up")
        else
            cmdStr = WL_CMD_BINARY.. " -i " ..dot11InterfaceRow["interfaceName"].. " bss down"
            os.execute(cmdStr)
            os.execute ("/sbin/ifconfig " .. dot11InterfaceRow["interfaceName"] .. " down")
        end
        os.execute("/bin/wlconf " ..radioInterfaceName.. " up")
        dot11.ServiceStopStart2 (false)
        dot11.ServiceStopStart2 (true)
        os.execute("/bin/wlconf " ..radioInterfaceName.. " start")
        if ((util.fileExists("/pfrm2.0/HW_JCO110"))) then
            os.execute("/bin/wl -i " ..radioInterfaceName.." phy_ed_thresh -30")
        else
            os.execute("/bin/wl -i " ..radioInterfaceName.." phy_ed_thresh -50")
        end
    end

    if(util.fileExists("/pfrm2.0/BRCMJCO300"))then
        os.execute("sleep 3")
    end
    
    db.save()

    -- update the led status based on APs are enabled or disabled
    if ((util.fileExists ("/pfrm2.0/HW_FOXCONN_JCO500")) or (util.fileExists ("/pfrm2.0/HW_FOXCONN")) or (util.fileExists ("/pfrm2.0/HW_JCO110")) or (util.fileExists("/pfrm2.0/HW_FIBERHOME_JCO300")) or (util.fileExists ("/pfrm2.0/HW_JCO410"))or (util.fileExists ("/pfrm2.0/HW_JCE410"))) then 
        dot11Tr.singleLedCtl()
    else
        dot11Tr.multiLedCtl()
    end 
    return 0;
end

--[[
--*****************************************************************************
-- dot11Tr.ssidProfileSet- set wlan ssid profile configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.WiFi.SSID.0.
--
-- Enable
-- SSID
--
-- Returns: status
]]--
function dot11Tr.ssidProfileSet(input, rowids, actionType, tr69Param)
    local status = "0"
    local row = {}
    local rowId
    local query = nil
    local ssidProfileConfTbl = {}
	local profile_2_4_end=3
    local faultTbl = {}
    local index = 0

    --Skip if this fn has been called for Device.WiFi.SSID.0.Enable
    if(input["dot11Profile"]["dot11Profile.ssid"] == nil) then
        tr69Glue.tf1Dbg("ssid hasn't changed, just return..")
        return 0;
    end

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        tr69Glue.tf1Dbg("instanceMapLoad failed..")
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --find the immediate parent object with instance number or
    --extract the Device.WiFi.SSID.0. part from tr69Param
    local startIdx, endIdx
    local parentObjInstance
    startIdx, endIdx = string.find(tr69Param, "SSID.")
    parentObjInstance = string.sub(tr69Param, 1, endIdx+2)
    
    --read the rowId mapping to dot11Profile
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        tr69Glue.tf1Dbg("No instance found for -- " .. parentObjInstance)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get correspnding db entry from dot11Profile 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("dot11Profile", query, false)
    if(row == nil) then
        tr69Glue.tf1Dbg("No entry in dot11Profile with rowId -- " .. rowId)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    ssidProfileConfTbl = row

    if (input["dot11Profile"]["dot11Profile.ssid"] ~= nil) then
        local rowEogre = db.getRowWhere ("Eogre", "_ROWID_=1", false) 
        if(rowEogre["Enable"] == "1" and rowEogre["ModeOfOperation"] == "1" and (row["profileName"] == "Jio_2" or row["profileName"] == "Jio_5")) then
            tr69Glue.tf1Dbg("Eogre is enabled .. ")
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."SSID", error_code.REQUEST_DENIED)
            return status, faultTbl
        end
        if (tr69Glue.tf1ValidateStringLength(SSID_MIN_LEN,SSID_MAX_LEN,input["dot11Profile"]["dot11Profile.ssid"],"dot11Profile.ssid") ~= "OK") then
        -- SSID exceeds range (1-32) characters. 
        -- setting INVALID_PARAM_VALUE error code
           status = ERROR
           index = index + 1
           faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."SSID", error_code.INVALID_PARAM_VALUE)
           return status, faultTbl
        end

	local dot11Profiles = db.getRowsWhere ("dot11Profile", "ssid='".. input["dot11Profile"]["dot11Profile.ssid"].."' and _ROWID_!='"..rowId.."'", false)
    if (dot11Profiles ~= nil ) then
		for k,v in pairs (dot11Profiles) do
			if (tonumber(v["_ROWID_"]) <= profile_2_4_end and  tonumber(rowId) <= profile_2_4_end) then
                tr69Glue.tf1Dbg("Duplicate SSID request denied")
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."SSID", error_code.INVALID_PARAM_VALUE)
                return status, faultTbl
			end
			if (tonumber(v["_ROWID_"]) > profile_2_4_end and  tonumber(rowId) > profile_2_4_end) then
                tr69Glue.tf1Dbg("Duplicate SSID request denied")
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."SSID", error_code.INVALID_PARAM_VALUE)
                return status, faultTbl
			end 	
		end
    end
        ssidProfileConfTbl["ssid"] = input["dot11Profile"]["dot11Profile.ssid"]
    end

    --apply ssid profile settings
    local errorCode,statusMsg
    ssidProfileConfTbl = util.addPrefix(ssidProfileConfTbl, "dot11Profile.")
    errorCode,statusMsg = dot11.profile_config (ssidProfileConfTbl, ssidProfileConfTbl["dot11Profile._ROWID_"], "edit") 
    if(util.fileExists("/pfrm2.0/BRCMJCO300"))then
        os.execute("sleep 3")
    end
  
    db.save()
    return 0;
end

--[[
--*****************************************************************************
-- dot11Tr.ssidProfileStatsGet- get wlan ssid profile stats
-- 
-- This function is called to get the following parameters in
-- Device.WiFi.SSID.0.Stats.
--
-- BytesSent
-- BytesReceived
-- PacketsSent
-- PacketsReceived
--
-- Returns: status, value
]]--
function dot11Tr.ssidProfileStatsGet (input)
    -- require
    require "teamf1lualib/ifDev"

    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local row = {}
    local apCfgRow = {}
    local query = nil
    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "SSID.")
    parentObjInstance = string.sub(param, 1, endIdx+2)
    
    --read the rowId mapping to dot11Profile
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get correspnding db entry from dot11Profile 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("dot11Profile", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get vap interface name
    apCfgRow = dot11Tr.profileToAPCfgGet(row["profileName"])
    if(apCfgRow == nil or apCfgRow == "") then
        return status, value
    end

    --get stats for this vap interface
    local vapStatsTbl = {}
    vapStatsTbl = ifDevLib.interfaceStatsGet(apCfgRow["interfaceName"])

    --find & return parameter values
    if(string.find(input["param"], "BytesSent")) then
        -- BytesSent
        value = vapStatsTbl["tx_bytes"]
    elseif(string.find(input["param"], "BytesReceived")) then
        -- BytesReceived
		value = vapStatsTbl["rx_bytes"]
    elseif(string.find(input["param"], "PacketsSent")) then
        -- PacketsSent
		value = vapStatsTbl["tx_packets"]
    elseif(string.find(input["param"], "PacketsReceived")) then
        -- PacketsReceived
		value = vapStatsTbl["rx_packets"]
    elseif(string.find(input["param"], "ErrorsSent")) then
        -- ErrorsSent
		value = vapStatsTbl["tx_errors"]
    elseif(string.find(input["param"], "ErrorsReceived")) then
        -- ErrorsReceived
		value = vapStatsTbl["rx_errors"]
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- dot11Tr.getSSSIDObjFromProfileName - get ssid object instance name from
--                                      profileName
-- 
-- Returns: ssidObjInstanceName or nil
]]--
function dot11Tr.getSSSIDObjFromProfileName(profileName)
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return
    end
    local ssidObj = "Device.WiFi.SSID."

    --get correspnding db entry from dot11Profile 
    local ssidProfileRow = {}
    local query = nil
    query = "profileName='" .. profileName .. "'"
    ssidProfileRow = db.getRowWhere ("dot11Profile", query, false)
    if(ssidProfileRow == nil) then
        return 
    end

    local i
    for i=1,8,1 do
        if(instanceMap[ssidObj .. i .. "."] == nil) then 
            return
        end

        if(instanceMap[ssidObj .. i .. "."] == ssidProfileRow["_ROWID_"]) then 
            return(ssidObj .. i .. ".")
        end
    end

end

--[[
--*****************************************************************************
-- dot11Tr.apCfgGet- get wlan AP configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.WiFi.AccessPoint.0.
--
-- Enable
-- Status
-- SSIDReference
-- MaxAssociatedDevices
-- SSIDAdvertisementEnabled
-- WMMCapability
-- WMMEnable
-- X_RJIL_COM_UsePrimarySubnet
--
-- Returns: status, value
]]--
function dot11Tr.apCfgGet (input)
    require "teamf1lualib/firewall"
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local row = {}
    local profileRow = {} --dot11Profile entry
    local apCfgRow = {}
    local query = nil
    local profileQry = nil
    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "AccessPoint.")
    parentObjInstance = string.sub(param, 1, endIdx+2)
    
    --read the rowId mapping to dot11VAP
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from dot11VAP
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("dot11VAP", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from dot11profile
    profileQry = "profileName='" .. row["profileName"] .. "'"
    profileRow = db.getRowWhere ("dot11Profile", profileQry, false)
    if(profileRow == nil) then
        tr69Glue.tf1Dbg("No entry in dot11profile with profileName -- " .. row["profileName"])
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from dot11Interface
    interfaceQry = "vapName='" .. row["vapName"] .. "'"
    interfaceRow = db.getRowWhere ("dot11Interface", interfaceQry, false)
    if(interfaceRow == nil) then
        tr69Glue.tf1Dbg("No entry in dot11Interface with vapName -- " .. row["vapName"])
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    
    --get corresponding db entry from EOGRE
    eogreRow = firewall.eogreGet()

    local t = {
    vapEnabled = row["vapEnabled"],
    Status = function() return (row["vapEnabled"] == "1") and "Enabled" or "Disabled" end,
    profileName = function() 
                      local ssidRefObj = ""
                      ssidRefObj = dot11Tr.getSSSIDObjFromProfileName(row["profileName"])
                      value = ssidRefObj
                      if(value == nil or value == "") then
                          return "1", "DB_ERROR_TRY_AGAIN"
                      end
                      return value
                  end,
    maxClients = row["maxClients"],
    broadcastSSID = profileRow["broadcastSSID"],
    WMMCapability = "1",
    qosEnable = profileRow["qosEnable"],
    defaultLANSubnet = interfaceRow["defaultLANSubnet"],
    eogreEnable = function() 
                        if(interfaceRow["vapName"] == "ap3" or interfaceRow["vapName"] == "ap6") then
                            value = eogreRow[1]["Enable"] or eogreRow[2]["Enable"]
                        else
                            value = "0"
                        end
                        return value 
                    end
    }

    for k,v in pairs(input) do
        if(v == input["field"]) then
            value = type(t[v]) == "function" and t[v]() or t[v] or "DB_ERROR_TRY_AGAIN"
            return status, value
        end
    end

    return status, value
end

--[[
--*****************************************************************************
-- dot11Tr.apCfgSet- set wlan AP configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.WiFi.AccessPoint.0.
--
-- Enable
-- SSIDReference
--
-- Returns: status
]]--
function dot11Tr.apCfgSet(input, rowids, actionType, tr69Param)
    require "teamf1lualib/gui"
    require "teamf1lualib/dot11_ul"

    local status = OK 
    local row = {}
    local rowId
    local query = nil
    local apConfTbl = {}
    local profileCfgTbl = {}
    local valid
    local faultTbl = {}
    local index = 0
    local apStatusFlag = 0
    local vapCfgFlag = 0
    local profileCfgFlag = 0
    local wmmCfgFlag = 0

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        tr69Glue.tf1Dbg("instanceMapLoad failed..")
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    --find the immediate parent object with instance number or extract
    --the Device.WiFi.AccessPoint.0. part from tr69Param
    local startIdx, endIdx
    local parentObjInstance
    startIdx, endIdx = string.find(tr69Param, "AccessPoint.")
    parentObjInstance = string.sub(tr69Param, 1, endIdx+2)

    --read the rowId mapping to dot11VAP
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        tr69Glue.tf1Dbg("No instance found for -- " .. parentObjInstance)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    local rows = {}
    rows["1"] = rowId

    --get correspnding db entry from dot11VAP 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("dot11VAP", query)
    if(row == nil) then
        tr69Glue.tf1Dbg("No entry in dot11VAP with rowId -- " .. rowId)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    query = "profileName='" .. row["dot11VAP.profileName"] .. "'"
    dot11ProfileRow = db.getRowWhere ("dot11Profile", query)
    if(dot11ProfileRow == nil) then
        tr69Glue.tf1Dbg("No entry in dot11Profile with profileName -- " .. row["dot11VAP.profileName"] )
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    query = "vapName='" .. row["dot11VAP.vapName"] .. "'"
    dot11InterfaceRow = db.getRowWhere ("dot11Interface", query, false)
    if(dot11InterfaceRow == nil) then
        tr69Glue.tf1Dbg("No entry in dot11Interface with vapName -- " .. dot11ProfileRow["dot11Profile.vapName"])
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    query = "_ROWID_=1"
    eogreCfgTbl = firewall.eogreGet(query)

    local chipsetRow = db.getRowWhere("chipsetInfo", "_ROWID_=1", false)

    apConfTbl = row
    apConfTbl["_ROWID_"] = rowId
    apConfTbl["dot11VAP.defaultSubnet"] = dot11InterfaceRow["defaultLANSubnet"]

    profileCfgTbl = dot11ProfileRow
    profileCfgTbl["_ROWID_"] = rowId
    
    -- Enable
    if(input["dot11VAP"]["dot11VAP.vapEnabled"] ~= nil) then 
        apConfTbl["dot11VAP.vapEnabled"] = input["dot11VAP"]["dot11VAP.vapEnabled"]

        --EoGRE Check
        statusCode, errMsg = eogreAPcheck (rows)
        if (statusCode == "ERROR")then
            tr69Glue.tf1Dbg("Eogre is enabled, errMsg : "..errMsg)
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Enable", error_code.REQUEST_DENIED)
        end

        apStatusFlag = 1
    end

    -- MaxAssociatedDevices
    if(input["dot11VAP"]["dot11VAP.maxClients"] ~= nil) then 
        apConfTbl["dot11VAP.maxClients"] = input["dot11VAP"]["dot11VAP.maxClients"]

        --max client per radio validation
        errorCode, statusMsg = maxClientsRadioValidate (apConfTbl, dot11InterfaceRow["radioNo"])
        if (errorCode == "ERROR")then
            tr69Glue.tf1Dbg("err msg:" ..statusMsg)
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."MaxAssociatedDevices", error_code.INVALID_PARAM_VALUE)
        end
        vapCfgFlag = 1
    end

    --X_RJIL_COM_UsePrimarySubnet
    if(input["dot11VAP"]["dot11VAP.defaultLANSubnet"] ~= nil) then
        apConfTbl["dot11VAP.defaultSubnet"] = input["dot11VAP"]["dot11VAP.defaultLANSubnet"]
        
        if(chipsetRow["Chipset"] == "Lantiq") then
            if(apConfTbl["dot11VAP.vapName"] == "ap1") then
                tr69Glue.tf1Dbg("connot enable default subnet for "..apConfTbl["dot11VAP.vapName"])
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."X_RJIL_COM_UsePrimarySubnet", error_code.REQUEST_DENIED)
            end
        else
            if(apConfTbl["dot11VAP.vapName"] == "ap1" or apConfTbl["dot11VAP.vapName"] == "ap4") then
                tr69Glue.tf1Dbg("connot enable default subnet for "..apConfTbl["dot11VAP.vapName"])
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."X_RJIL_COM_UsePrimarySubnet", error_code.REQUEST_DENIED)
            end
        end
        vapCfgFlag = 1
    end

    -- SSIDAdvertisementEnabled
    if (input["dot11VAP"]["dot11VAP.broadcastSSID"] ~= nil) then
        profileCfgTbl["dot11Profile.broadcastSSID"] = input["dot11VAP"]["dot11VAP.broadcastSSID"]
        profileCfgFlag = 1
    end

    -- WMMEnable
    if (input["dot11VAP"]["dot11VAP.qosEnable"] ~= nil) then
        profileCfgTbl["dot11Profile.qosEnable"] = input["dot11VAP"]["dot11VAP.qosEnable"]
        wmmCfgFlag = 1
    end

    -- X_RJIL_COM_EnableOffload
    if (input["dot11VAP"]["dot11VAP.eogreEnable"] ~= nil) then
        if(chipsetRow["Chipset"] == "Broadcom") then
            if(apConfTbl["dot11VAP.vapName"] == "ap3" or apConfTbl["dot11VAP.vapName"] == "ap6") then
                eogreCfgTbl["Enable"] = input["dot11VAP"]["dot11VAP.eogreEnable"]
                eogreCfgFlag = 1
            else
                tr69Glue.tf1Dbg("connot Enable Offload for "..apConfTbl["dot11VAP.vapName"])
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."X_RJIL_COM_EnableOffload", error_code.REQUEST_DENIED)
            end
        end
    end
    
    if (status ~= OK) then
        return status, faultTbl
    end
    
    --apply ap enable/disable settings
    if(apStatusFlag == 1) then
        if(apConfTbl["dot11VAP.vapEnabled"] == "1") then
            operation = "enable"
        else
            operation = "disable"
        end

        errorCode, statusMsg = gui.wireless.apProfileInfo.status (rows, operation, dbFlag)
        if(errorCode ~= "OK") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            tr69Glue.tf1Dbg("AP config failed, statusMsg = "..statusMsg)
            return status, faultTbl
        end 
        os.execute("/bin/touch /tmp/APStatusChange.txt")
    end

    --apply vap settings
    if(vapCfgFlag == 1) then
        errorCode, statusMsg, getDefaultSubnetAllVal = gui.wireless.apProfileInfo.edit.set (apConfTbl, "edit", dbFlag)
        if(errorCode ~= "OK") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            tr69Glue.tf1Dbg("VAP config failed, statusMsg = "..statusMsg)
            return status, faultTbl
        end 
    end

    --apply profile settings
    if(profileCfgFlag == 1) then
        errorCode, statusMsg = gui.wireless.profileInfo.set (profileCfgTbl, "edit", dbFlag)
        if(errorCode ~= "OK") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            tr69Glue.tf1Dbg("Profile config failed, statusMsg = "..statusMsg)
            return status, faultTbl
        end
        os.execute("/bin/touch /tmp/APProfileChange.txt")
    end

    --apply wmm settings
    if(wmmCfgFlag == 1) then
        errorCode, statusMsg = gui.wireless.wmm.set (profileCfgTbl, "edit", dbFlag)
        if(errorCode ~= "OK") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            tr69Glue.tf1Dbg("WMM config failed, statusMsg = "..statusMsg)
            return status, faultTbl
        end
    end

    --apply eogre settings
    if(eogreCfgFlag == 1) then
        errorCode, statusMsg = gui.networking.network.eogre.set (eogreCfgTbl, dbFlag)
        if(errorCode ~= "OK") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            tr69Glue.tf1Dbg("EOGRE config failed, statusMsg = "..statusMsg)
            return status, faultTbl
        end
    end

    db.save()
    
    if (getDefaultSubnetAllVal == 1 )then 
        require "teamf1lualib/tr69Glue"
        require "teamf1lualib/reboot"
        tr69Glue.reboot(20)
    end
    return 0;
end

--[[
--*****************************************************************************
-- dot11Tr.apSecurityGet- get security mode
-- 
-- Returns: value
]]--
function dot11Tr.apSecurityGet(profileRow)

    local value = "DB_ERROR_TRY_AGAIN"

    -- ModeEnabled
    if(profileRow["security"] == "OPEN") then
        value = "None"
    elseif(profileRow["security"] == "WEP") then
        if(profileRow["groupCipher"] == nil or profileRow["groupCipher"] == "") then
            return "1", "DB_ERROR_TRY_AGAIN"
        elseif(profileRow["groupCipher"] == "64") then
            value = "WEP-64"
        elseif(profileRow["groupCipher"] == "128") then
            value = "WEP-128"
        else
            return "DB_ERROR_TRY_AGAIN"
        end
    elseif(profileRow["security"] == "WPA" and profileRow["authMethods"] == "PSK") then
        value = "WPA-Personal"
    elseif(profileRow["security"] == "WPA2" and profileRow["authMethods"] == "PSK") then
        value = "WPA2-Personal"
    elseif(profileRow["security"] == "WPA+WPA2" and profileRow["authMethods"] == "PSK") then
        value = "WPA-WPA2-Personal"
    elseif(profileRow["security"] == "WPA" and profileRow["authMethods"] == "RADIUS") then
        value = "WPA-Enterprise"
    elseif(profileRow["security"] == "WPA2" and profileRow["authMethods"] == "RADIUS") then
        value = "WPA2-Enterprise"
    elseif(profileRow["security"] == "WPA+WPA2" and profileRow["authMethods"] == "RADIUS") then
        value = "WPA-WPA2-Enterprise"
    else
        return "DB_ERROR_TRY_AGAIN"
    end
    
    return value
end

--[[
--*****************************************************************************
-- dot11Tr.apSecurityCfgGet- get wlan authentication configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.WiFi.AccessPoint.0.Security.
--
-- ModesSupported
-- ModeEnabled
-- WEPKey
-- KeyPassphrase
--
-- Returns: status, value
]]--
function dot11Tr.apSecurityCfgGet(input)
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local profileRow = {} --dot11Profile entry
    local query = nil
    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "AccessPoint.")
    parentObjInstance = string.sub(param, 1, endIdx+2)

    --read the rowId mapping to dot11VAP
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from dot11VAP
    query = "_ROWID_=" .. rowId
    profileRow = db.getRowWhere ("dot11Profile", query, false)
    if(profileRow == nil) then
        tr69Glue.tf1Dbg("No entry in dot11profile with rowId -- " .. rowId)
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from radiusClient
    query = "_ROWID_= 1"
    radiusClientRow = db.getRowWhere ("radiusClient", query, false)
    if(radiusClientRow == nil) then
        tr69Glue.tf1Dbg("No entry in radiusClient with rowId -- " .. rowId)
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    local t = {
    ModesSupported = "None,WPA2-Personal,WPA2-Enterprise",
    apsecurity = dot11Tr.apSecurityGet(profileRow),
    groupKeyUpdateInterval = profileRow["groupKeyUpdateInterval"],
    ipType = radiusClientRow["ipType"],
    authserver = function() 
                      value = radiusClientRow["authserver"]
                      if(tonumber(radiusClientRow["ipType"]) == 1) then
                          value = radiusClientRow["authserverIP6"]
                      end
                      return value
                  end,
    --authserver = radiusClientRow["authserver"],
    secauthserver = function() 
                      value = radiusClientRow["secauthserver"]
                      if(tonumber(radiusClientRow["ipType"]) == 1) then
                          value = radiusClientRow["secauthserverIP6"]
                      end
                      return value
                  end,
    --secauthserver = radiusClientRow["secauthserver"],
    authport = radiusClientRow["authport"],
    }

    --find & return parameter values
    for k,v in pairs(input) do
        if(v == input["field"]) then
            value = type(t[v]) == "function" and t[v]() or t[v] or "DB_ERROR_TRY_AGAIN"
            if(value == "DB_ERROR_TRY_AGAIN") then
                status = "1"
            end
            return status, value
        end
    end

    return status, value
end

--[[
--*****************************************************************************
-- dot11Tr.passwordValidate - validation for passwords
--
-- Returns: 1(error), 0(success)
]]--
function dot11Tr.passwordValidate(password)
    if((string.len(password) < PASSPHRASE_MIN_LEN) or (string.len(password) > PASSPHRASE_MAX_LEN)) then
        return 1, "Invalid string length"
    elseif(tr69Glue.tf1HasTypeValidate(password, "%s") == 1) then
        return 1, "Password has spaces"
    elseif(string.find(password, '"')) then
        return 1, "Found double quotes"
    end

    return 0
end


--[[
--*****************************************************************************
-- dot11Tr.apSecurityCfgSet- set wlan authentication configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.WiFi.SSID.0.
--
-- Device.WiFi.AccessPoint.0.Security.
--
-- ModeEnabled
-- WEPKey
-- KeyPassphrase
--
-- Returns: status
]]--
function dot11Tr.apSecurityCfgSet(input, rowids, actionType, tr69Param)
    require "teamf1lualib/gui"
    require "teamf1lualib/dot11_ul"

    local row = {}
    local rowId
    local query = nil
    local profileRow = {}
    local newMode = ""
    local status = OK
    local faultTbl = {}
    local index = 0
    local profileCfgFlag = 0
    local radiusCfgFlag = 0

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        tr69Glue.tf1Dbg("instanceMapLoad failed..")
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    local parentObjInstance
    startIdx, endIdx = string.find(tr69Param, "AccessPoint.")
    parentObjInstance = string.sub(tr69Param, 1, endIdx+2)

    --read the rowId mapping to Device.WiFi.AccessPoint.0.Security.
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        tr69Glue.tf1Dbg("No entry in instanceMap for " .. parentObjInstance)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get corresponding db entry from dot11profile
    query = "_ROWID_=" .. rowId
    profileRow = db.getRowWhere ("dot11Profile", query)
    if(profileRow == nil) then
        tr69Glue.tf1Dbg("No entry in dot11profile with rowId -- " .. rowId)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    profileRow["_ROWID_"] = rowId

    --get corresponding db entry from dot11VAP
    query = "profileName='" .. profileRow["dot11Profile.profileName"] .. "'"
    vapRow = db.getRowWhere ("dot11VAP", query, false)
    if(vapRow == nil) then
        tr69Glue.tf1Dbg("No entry in dot11VAP with rowId -- " .. rowId)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get corresponding db entry from radiusClient
    query = "_ROWID_= 1"
    radiusClientRow = db.getRowWhere ("radiusClient", query, false)
    if(radiusClientRow == nil) then
        tr69Glue.tf1Dbg("No entry in radiusClient with rowId -- " .. rowId)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    radiusConfTbl = radiusClientRow

    --ModeEnabled
    if(input["dot11Profile"]["dot11Profile.apsecurity"] ~= nil) then
        statusCode, errMsg = eogrecheck (profileRow)
        if (statusCode == "ERROR")then
            tr69Glue.tf1Dbg("Eogre is enabled, errMsg : "..errMsg)
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Enable", error_code.REQUEST_DENIED)
        else
            --security mode has changed, update all values properly..
            newMode = input["dot11Profile"]["dot11Profile.apsecurity"]
            if(newMode == "None") then
                if(dot11Tr.wpsStatusCheck(vapRow["vapName"]) == "WPS_ENABLED") then
                    tr69Glue.tf1Dbg("WPS is enabled on AP using this profile, Cannot set security/auth methods to OPEN.. ")
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."ModeEnabled", error_code.REQUEST_DENIED)
                end
                profileRow["dot11Profile.security"] = "OPEN"
                profileRow["dot11Profile.pairwiseCiphers"] = "None"
                profileRow["dot11Profile.authMethods"] = "None"
                profileRow["dot11Profile.pskPassAscii"] = ""
                profileRow["dot11Profile.groupCipher"] = ""
            elseif(newMode == "WPA2-Personal") then
                if(input["dot11Profile"]["dot11Profile.appskPassAscii"] == nil) then
                    tr69Glue.tf1Dbg("KeyPassphrase is nil..")
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."ModeEnabled", error_code.REQUEST_DENIED)
                else
                    retStatus, errMessage = dot11Tr.passwordValidate(input["dot11Profile"]["dot11Profile.appskPassAscii"])
                    if(retStatus == 1) then
                        status = ERROR
                        index = index + 1
                        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."KeyPassphrase", error_code.INVALID_PARAM_VALUE)
                        tr69Glue.tf1Dbg("appskPassAscii errMessage = "..errMessage)
                    end
                    profileRow["dot11Profile.pskPassAscii"] = input["dot11Profile"]["dot11Profile.appskPassAscii"]
                end
                profileRow["dot11Profile.security"] = "WPA2"
                profileRow["dot11Profile.pairwiseCiphers"] = "CCMP"
                profileRow["dot11Profile.authMethods"] = "PSK"
                profileRow["dot11Profile.groupCipher"] = ""
            elseif(newMode == "WPA2-Enterprise") then
                if(dot11Tr.wpsStatusCheck(vapRow["vapName"]) == "WPS_ENABLED") then
                    tr69Glue.tf1Dbg("WPS is enabled on AP using this profile, Cannot set security/auth methods to RADIUS.. ")
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."ModeEnabled", error_code.REQUEST_DENIED)
                end
                profileRow["dot11Profile.security"] = "WPA2"
                profileRow["dot11Profile.authMethods"] = "RADIUS"
                profileRow["dot11Profile.pairwiseCiphers"] = "CCMP"
                profileRow["dot11Profile.pskPassAscii"] = ""
                profileRow["dot11Profile.groupCipher"] = ""
            else
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."ModeEnabled", error_code.INVALID_PARAM_VALUE)
                tr69Glue.tf1Dbg("Configured Security method is not supported..")
            end
        end
        profileCfgFlag = 1
    end

    --KeyPassphrase
    if(input["dot11Profile"]["dot11Profile.appskPassAscii"] ~= nil) then
        retStatus, errMessage = dot11Tr.passwordValidate(input["dot11Profile"]["dot11Profile.appskPassAscii"])
        if(retStatus == 1) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."KeyPassphrase", error_code.INVALID_PARAM_VALUE)
            tr69Glue.tf1Dbg("KeyPassphrase errMessage = "..errMessage)
        else
            profileRow["dot11Profile.pskPassAscii"] = input["dot11Profile"]["dot11Profile.appskPassAscii"]
        end
        profileCfgFlag = 1
    end

    --PreSharedKey
    if(input["dot11Profile"]["dot11Profile.pskPassHex"] ~= nil) then
        retStatus, errMessage = dot11Tr.passwordValidate(input["dot11Profile"]["dot11Profile.pskPassHex"])
        if(retStatus == 1) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."PreSharedKey", error_code.INVALID_PARAM_VALUE)
            tr69Glue.tf1Dbg("PreSharedKey errMessage = "..errMessage)
        else
            profileRow["dot11Profile.pskPassHex"] = input["dot11Profile"]["dot11Profile.pskPassHex"]
        end
        profileCfgFlag = 1
    end

    --RekeyingInterval
    if (input["dot11Profile"]["dot11Profile.groupKeyUpdateInterval"] ~= nil) then
        if(tonumber(input["dot11Profile"]["dot11Profile.groupKeyUpdateInterval"]) < REKEY_INTERVAL_MIN or tonumber(input["dot11Profile"]["dot11Profile.groupKeyUpdateInterval"]) > REKEY_INTERVAL_MAX) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."RekeyingInterval", error_code.INVALID_PARAM_VALUE)
        else
            profileRow["dot11Profile.groupKeyUpdateInterval"] = input["dot11Profile"]["dot11Profile.groupKeyUpdateInterval"]
        end
        profileCfgFlag = 1
    end

    --RadiusServerIPType
    if(input["dot11Profile"]["dot11Profile.ipType"] ~= nil) then
        radiusConfTbl["ipType"] = input["dot11Profile"]["dot11Profile.ipType"]
        radiusCfgFlag = 1
    end

    --RadiusServerIPAddr
    if(input["dot11Profile"]["dot11Profile.authserver"] ~= nil) then
        if(tonumber(radiusConfTbl["ipType"]) == 0)then
            if(tr69Glue.tf1IpAddressValidate(input["dot11Profile"]["dot11Profile.authserver"], "", "", "") == "OK") then 
                radiusConfTbl["authserver"] = input["dot11Profile"]["dot11Profile.authserver"]
            else
                -- radius auth server should be valid IP address
                -- setting INVALID_PARAM_VALUE error code
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."RadiusServerIPAddr", error_code.INVALID_PARAM_VALUE)
            end
        else
            if(tr69Glue.tf1ValidateIpv6Address(input["dot11Profile"]["dot11Profile.authserver"]) ~= 0) then 
                -- radius auth server should be valid IP address
                -- setting INVALID_PARAM_VALUE error code
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."RadiusServerIPAddr", error_code.INVALID_PARAM_VALUE)
            else
                radiusConfTbl["authserverIPv6"] = input["dot11Profile"]["dot11Profile.authserver"]
            end
        end
        radiusCfgFlag = 1
    end

    --SecondaryRadiusServerIPAddr
    if(input["dot11Profile"]["dot11Profile.secauthserver"] ~= nil) then
        if(tonumber(radiusConfTbl["ipType"]) == 0)then
            if(tr69Glue.tf1IpAddressValidate(input["dot11Profile"]["dot11Profile.secauthserver"], "", "", "") == "OK") then 
                radiusConfTbl["authserver2"] = input["dot11Profile"]["dot11Profile.secauthserver"]
            else
                -- radius auth server should be valid IP address
                -- setting INVALID_PARAM_VALUE error code
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."SecondaryRadiusServerIPAddr", error_code.INVALID_PARAM_VALUE)
            end
        else
            if(tr69Glue.tf1ValidateIpv6Address(input["dot11Profile"]["dot11Profile.secauthserver"]) ~= 0) then 
                -- radius auth server should be valid IP address
                -- setting INVALID_PARAM_VALUE error code
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."SecondaryRadiusServerIPAddr", error_code.INVALID_PARAM_VALUE)
            else
                radiusConfTbl["authserver2IPv6"] = input["dot11Profile"]["dot11Profile.secauthserver"]
            end
        end
        radiusCfgFlag = 1
    end

    --RadiusServerPort
    if(input["dot11Profile"]["dot11Profile.authport"] ~= nil) then
        if(tonumber(input["dot11Profile"]["dot11Profile.authport"]) >= RADIUS_PORT_MIN_VAL and tonumber(input["dot11Profile"]["dot11Profile.authport"]) <= RADIUS_PORT_MAX_VAL) then
            radiusConfTbl["authport"] = input["dot11Profile"]["dot11Profile.authport"]
        else
            -- radius auth port valid range(1-65535)
            -- setting INVALID_PARAM_VALUE error code
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."RadiusServerPort", error_code.INVALID_PARAM_VALUE)
        end
        radiusCfgFlag = 1
    end

    --RadiusSecret
    if(input["dot11Profile"]["dot11Profile.authsecret"] ~= nil) then
        if((string.len(input["dot11Profile"]["dot11Profile.authsecret"]) > RADIUS_SECRET_MAX_LEN) or (tr69Glue.tf1HasTypeValidate(input["dot11Profile"]["dot11Profile.authsecret"], "%s") == 1) or (string.find(input["dot11Profile"]["dot11Profile.authsecret"], '"'))) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."RadiusSecret", error_code.INVALID_PARAM_VALUE)
            tr69Glue.tf1Dbg("RadiusSecret length is invalid or RadiusSecret has all spaces or found double quote..")
        else
            radiusConfTbl["authsecret"] = input["dot11Profile"]["dot11Profile.authsecret"]
        end
        radiusCfgFlag = 1
    end

    if(status ~= OK) then
        return status, faultTbl
    end
      
    --apply profile settings
    if(profileCfgFlag == 1) then
        errorCode, statusMsg = gui.wireless.profileInfo.set (profileRow, "edit", dbFlag)
        if(errorCode ~= "OK") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            tr69Glue.tf1Dbg("Profile config failed, statusMsg = "..statusMsg)
            return status, faultTbl
        end
        os.execute("/bin/touch /tmp/APProfileChange.txt")
    end

    --apply radius settings
    if(radiusCfgFlag == 1) then
        radiusConfTbl = util.addPrefix(radiusConfTbl, "radiusClient.")
        errorCode, statusMsg = gui.administration.radiusClient.set(radiusConfTbl, dbFlag)
        if(errorCode ~= "OK") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            tr69Glue.tf1Dbg("Radius config failed, statusMsg = "..statusMsg)
            return status, faultTbl
        end
    end

    db.save()
    return status, faultTbl;
end

--[[
--*****************************************************************************
-- dot11Tr.wlanAuthGet- get wlan authentication configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.WiFi.AccessPoint.0.Security.
--
-- ModesSupported
-- ModeEnabled
-- WEPKey
-- KeyPassphrase
--
-- Returns: status, value
]]--
function dot11Tr.wlanAuthGet(input)
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local row = {} --dot11VAP entry
    local profileRow = {} --dot11Profile entry
    local query = nil
    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "AccessPoint.")
    parentObjInstance = string.sub(param, 1, endIdx+2)

    --read the rowId mapping to dot11VAP
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from dot11VAP
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("dot11VAP", query, false)
    if(row == nil) then
        tr69Glue.tf1Dbg("No entry in dot11VAP with rowId -- " .. rowId)
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from dot11profile
    query = "profileName='" .. row["profileName"] .. "'"
    profileRow = db.getRowWhere ("dot11Profile", query, false)
    if(profileRow == nil) then
        tr69Glue.tf1Dbg("No entry in dot11profile with profileName -- " .. row["profileName"])
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find & return parameter values
    if(string.find(input["param"], "ModesSupported")) then
        -- ModesSupported
        value = "None,WPA2-Personal,WPA2-Enterprise"
    elseif(string.find(input["param"], "ModeEnabled")) then
        -- ModeEnabled
        if(profileRow["security"] == "OPEN") then
            value = "None"
        elseif(profileRow["security"] == "WEP") then
            if(profileRow["groupCipher"] == nil or profileRow["groupCipher"] == "") then
                return "1", "DB_ERROR_TRY_AGAIN"
            elseif(profileRow["groupCipher"] == "64") then
                value = "WEP-64"
            elseif(profileRow["groupCipher"] == "128") then
                value = "WEP-128"
            else
                return "1", "DB_ERROR_TRY_AGAIN"
            end
        elseif(profileRow["security"] == "WPA" and profileRow["authMethods"] == "PSK") then
            value = "WPA-Personal"
        elseif(profileRow["security"] == "WPA2" and profileRow["authMethods"] == "PSK") then
            value = "WPA2-Personal"
        elseif(profileRow["security"] == "WPA+WPA2" and profileRow["authMethods"] == "PSK") then
            value = "WPA-WPA2-Personal"
        elseif(profileRow["security"] == "WPA" and profileRow["authMethods"] == "RADIUS") then
            value = "WPA-Enterprise"
        elseif(profileRow["security"] == "WPA2" and profileRow["authMethods"] == "RADIUS") then
            value = "WPA2-Enterprise"
        elseif(profileRow["security"] == "WPA+WPA2" and profileRow["authMethods"] == "RADIUS") then
            value = "WPA-WPA2-Enterprise"
        else
            return "1", "DB_ERROR_TRY_AGAIN"
        end
        elseif(string.find(input["param"], "RekeyingInterval")) then
        -- Enable
        value = profileRow["groupKeyUpdateInterval"]
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

--[[
    --these are write-only params
    elseif(string.find(input["param"], "WEPKey")) then
        if(profileRow["wepkey0"] == nil or profileRow["wepkey0"] == "") then
            value = "0"
        else
            value = profileRow["wepkey0"]
        end
    elseif(string.find(input["param"], "KeyPassphrase")) then
        if(profileRow["pskPassAscii"] == nil or profileRow["pskPassAscii"] == "") then
            value = "0"
        else
            value = profileRow["pskPassAscii"]
        end
]]--

    return status, value
end

--[[
--*****************************************************************************
-- dot11Tr.wepKeyValidate - validate the wepKeyVal based on dot11Profile.groupCipher
-- 
-- Returns: valid
]]--
function dot11Tr.wepKeyValidate(wepKeyVal, wepEnc)
    local valid = "ERR"

    if(wepKeyVal == nil or wepKeyVal == "") then
        return valid;
    end

    if(wepEnc == "64") then
        --wepKeyVal should be 5 bytes represented in hexBinaryType
        if(string.len(wepKeyVal) ~= 10) then
            tr69Glue.tf1Dbg("Mode is wep-64 but wepKey is not 5 bytes, return err..")
            return valid;
        end
    elseif(wepEnc == "128") then
        --wepKeyVal should be 5 bytes represented in hexBinaryType
        if(string.len(wepKeyVal) ~= 26) then
            tr69Glue.tf1Dbg("Mode is wep-128 but wepKey is not 13 bytes, return err..")
            return valid;
        end
    else
        return valid;
    end

    valid = "OK"
    return valid;
end

--[[
--*****************************************************************************
-- dot11Tr.get80211nStatus - fetch 802.11n status in the radio
-- 
-- Returns: 80211N_ENABLED/80211N_DISABLED 
]]--
function dot11Tr.get80211nStatus(radioNumber)
    local radioRow = {}
    local query = ""

    --get the db entry from dot11Radio
    query = "radioNo=" .. radioNumber
    radioRow = db.getRowWhere ("dot11Radio", query, false)
    if (radioRow == nil) then
        tr69Glue.tf1Dbg("Leaving dot11Tr.get80211nStatus(): " .. "DB_ERROR_TRY_AGAIN")
        return "DB_ERROR_TRY_AGAIN"
    end

    local chipsetRow = db.getRowWhere("chipsetInfo", "_ROWID_=1", false)
    if(chipsetRow["Chipset"] == "Lantiq") then
         if(radioRow["radioNo"] == "1") then
            if (string.find(radioRow["opMode"], "ng")) then
                tr69Glue.tf1Dbg("Leaving dot11Tr.get80211nStatus(): " .. "80211N_ENABLED")
                return "80211N_ENABLED"
            end
        end
    else
        if(radioRow["radioNo"] == "1") then
            if(radioRow["opMode"] == "5" or radioRow["opMode"] == "4") then
                tr69Glue.tf1Dbg("Leaving dot11Tr.get80211nStatus(): " .. "80211N_ENABLED")
                return "80211N_ENABLED"
            end
        elseif(radioRow["radioNo"] == "2") then
            if(radioRow["opMode"] == "2") then
                tr69Glue.tf1Dbg("Leaving dot11Tr.get80211nStatus(): " .. "80211N_ENABLED")
                return "80211N_ENABLED"
            end
        end
    end

    tr69Glue.tf1Dbg("Leaving dot11Tr.get80211nStatus(): " .. "80211N_DISABLED")
    return "80211N_DISABLED"
end

--[[
--*****************************************************************************
-- dot11Tr.wpsStatusCheck - returns the status of WPS
-- 
-- Returns: WPS_ENABLED/WPS_DISABLED 
]]--
function dot11Tr.wpsStatusCheck(vapName)
    local query = ""

    query = "vapName='" .. vapName .. "'"
    dot11InterfaceRow = db.getRowWhere ("dot11Interface", query, false)
    if(dot11InterfaceRow == nil) then
        tr69Glue.tf1Dbg("No entry in dot11Interface")
        return "DB_ERROR_TRY_AGAIN"
    end

    query = "vapName='" .. dot11InterfaceRow["interfaceName"] .. "'"
    tr69Glue.tf1Dbg("query = ".. query)
    dot11WPSRow = db.getRowWhere ("dot11WPS", query, false)
    if(dot11WPSRow == nil) then
        tr69Glue.tf1Dbg("WPS is disabled for interfaceName="..dot11InterfaceRow["interfaceName"])
        return "WPS_DISABLED"
    end

    if(dot11WPSRow["wpsEnabled"] == "1") then
        tr69Glue.tf1Dbg("WPS is enabled for interfaceName="..dot11InterfaceRow["interfaceName"])
        return "WPS_ENABLED"
    end

    tr69Glue.tf1Dbg("WPS is disabled for interfaceName="..dot11InterfaceRow["interfaceName"])
    return "WPS_DISABLED"
end

--[[
--*****************************************************************************
-- dot11Tr.wlanAuthSet- set wlan authentication configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.WiFi.SSID.0.
--
-- Device.WiFi.AccessPoint.0.Security.
--
-- ModeEnabled
-- WEPKey
-- KeyPassphrase
--
-- Returns: status
]]--
function dot11Tr.wlanAuthSet(input, rowids, actionType, tr69Param)
    local status = "0"
    local row = {}
    local rowId
    local query = nil
    local profileRow = {}
    local updateFlag = "0"
    local newMode = ""
    local newWepKey = ""
    local newPreShareKey = ""
    local k,v
    local errorCode,statusMsg
    local faultTbl = {}
    local index = 0
    local eogreEnabled = false

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        tr69Glue.tf1Dbg("instanceMapLoad failed..")
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    local parentObjInstance
    startIdx, endIdx = string.find(tr69Param, "AccessPoint.")
    parentObjInstance = string.sub(tr69Param, 1, endIdx+2)

    --read the rowId mapping to dot11VAP
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        tr69Glue.tf1Dbg("No entry in instanceMap for " .. parentObjInstance)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get corresponding db entry from dot11VAP
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("dot11VAP", query, false)
    if(row == nil) then
        tr69Glue.tf1Dbg("No entry in dot11VAP with rowId -- " .. rowId)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get corresponding radio number for profiles
    local radioNumber = db.getAttribute("dot11Interface","vapName",row["vapName"],"radioNo")
    if(radioNumber == nil) then
        tr69Glue.tf1Dbg("No entry in dot11profile with radioNumber -- " .. radioNumber)
        status = "1"
        return "1";
    end

    --get corresponding db entry from dot11profile
    query = "profileName='" .. row["profileName"] .. "'"
    profileRow = db.getRowWhere ("dot11Profile", query, false)
    if(profileRow == nil) then
        tr69Glue.tf1Dbg("No entry in dot11profile with profileName -- " .. row["profileName"])
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    if(input["dot11VAP"]["dot11VAP.apsecurity"] ~= nil) then
        local rowEogre = db.getRowWhere ("Eogre", "_ROWID_=1", false) 
        if(rowEogre["Enable"] == "1" and rowEogre["ModeOfOperation"] == "1" and (profileRow["profileName"] == "Jio_2" or profileRow["profileName"] == "Jio_5")) then
            tr69Glue.tf1Dbg("Eogre is enabled .. ")
            eogreEnabled = true
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."ModeEnabled", error_code.REQUEST_DENIED)
        end
    end

    --security mode didn't change but WEPKey or KeyPassphrase has changed
    if(input["dot11VAP"]["dot11VAP.apsecurity"] == nil) then
        tr69Glue.tf1Dbg("security mode hasn't changed..")
        if(profileRow["security"] == "OPEN") then
            --ignore WEPkey or KeyPassphrase changes
            tr69Glue.tf1Dbg("ignore WEPkey or KeyPassphrase changes..")
            return 0;
        elseif(profileRow["security"] == "WEP") then
            if(input["dot11VAP"]["dot11VAP.apwepkey0"] == nil) then
                --ignore KeyPassphrase change
                tr69Glue.tf1Dbg("ignore KeyPassphrase change..")
                return 0;
            end

            if(dot11Tr.wepKeyValidate(input["dot11VAP"]["dot11VAP.apwepkey0"], profileRow["groupCipher"]) ~= "OK") then
                tr69Glue.tf1Dbg("dot11Tr.wepKeyValidate returned not OK..")
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."WEPKey", error_code.INVALID_PARAM_VALUE)
            end

            updateFlag = "1"
            profileRow["wepkey0"] = input["dot11VAP"]["dot11VAP.apwepkey0"]
        elseif(profileRow["security"] == "WPA" or profileRow["security"] == "WPA2" or profileRow["security"] == "WPA+WPA2") then
            if((input["dot11VAP"]["dot11VAP.appskPassAscii"] == nil) and (input["dot11VAP"]["dot11VAP.pskPassHex"] == nil)) then
                --ignore WEPKey change
                tr69Glue.tf1Dbg("ignore WEPKey change")
                return 0;
            end
            updateFlag = "1"
	        if((input["dot11VAP"]["dot11VAP.appskPassAscii"] ~= nil)) then
		        if(string.len(input["dot11VAP"]["dot11VAP.appskPassAscii"]) < PASSPHRASE_MIN_LEN or string.len(input["dot11VAP"]["dot11VAP.appskPassAscii"]) > PASSPHRASE_MAX_LEN) then
                    -- PassphraseASCII range is (8-63) characters. 
                    -- setting INVALID_PARAM_VALUE error code
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."KeyPassphrase", error_code.INVALID_PARAM_VALUE)
		        else		
                    profileRow["pskPassAscii"] = input["dot11VAP"]["dot11VAP.appskPassAscii"]
                end
	        elseif((input["dot11VAP"]["dot11VAP.pskPassHex"] ~= nil)) then
		        if(string.len(input["dot11VAP"]["dot11VAP.pskPassHex"]) < PASSPHRASE_MIN_LEN or string.len(input["dot11VAP"]["dot11VAP.pskPassHex"]) > PASSPHRASE_MAX_LEN) then
                    -- PassphraseHEX range (8-63) characters. 
                    -- setting INVALID_PARAM_VALUE error code
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."PreSharedKey", error_code.INVALID_PARAM_VALUE)
		         else
	                profileRow["pskPassHex"] = input["dot11VAP"]["dot11VAP.pskPassHex"]
                 end
	        end
        else
            return 0;
        end

        if(status ~= OK) then
          return status, faultTbl
        end

        if(updateFlag == "1") then
            --apply auth changes in profile settings
            --call the backend lua to update the tbl entries
            profileRow = util.addPrefix(profileRow, "dot11Profile.")
            errorCode,statusMsg = dot11.profile_config (profileRow, profileRow["dot11Profile._ROWID_"], "edit") 
            if(util.fileExists("/pfrm2.0/BRCMJCO300"))then
                os.execute("sleep 3")
            end
            db.save()
            return 0;
        end
    end

    --security mode has changed, update all values properly..
    if (eogreEnabled == true) then
       return status, faultTbl
    end

    newMode = input["dot11VAP"]["dot11VAP.apsecurity"]
    if(newMode == "None") then
        if(dot11Tr.wpsStatusCheck(row["vapName"]) == "WPS_ENABLED") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."ModeEnabled", error_code.REQUEST_DENIED)
            return status, faultTbl;
        end
        profileRow["security"] = "OPEN"
        profileRow["pairwiseCiphers"] = "None"
        profileRow["authMethods"] = "None"
        profileRow["pskPassAscii"] = ""
    elseif(string.find(newMode, "WPA")) then
        if(newMode == "WPA2-Personal") then
            profileRow["security"] = "WPA2"
            profileRow["pairwiseCiphers"] = "CCMP"
            profileRow["authMethods"] = "PSK"
        elseif(newMode == "WPA2-Enterprise") then
            if(dot11Tr.wpsStatusCheck(row["vapName"]) == "WPS_ENABLED") then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."ModeEnabled", error_code.REQUEST_DENIED)
                return status, faultTbl;
            end
            profileRow["security"] = "WPA2"
            profileRow["authMethods"] = "RADIUS"
            profileRow["pairwiseCiphers"] = "CCMP"
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."ModeEnabled", error_code.INVALID_PARAM_VALUE)
            tr69Glue.tf1Dbg("Configured WPA method is not supported..")
            return status, faultTbl;
        end

        profileRow["groupCipher"] = ""
        if(string.find(newMode, "Personal")) then
            if(input["dot11VAP"]["dot11VAP.appskPassAscii"] == nil) then
                tr69Glue.tf1Dbg("preSharedKey is nil, just return..")
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."ModeEnabled", error_code.REQUEST_DENIED)
                return status, faultTbl;
            end

            if(string.len(input["dot11VAP"]["dot11VAP.appskPassAscii"]) < PASSPHRASE_MIN_LEN or string.len(input["dot11VAP"]["dot11VAP.appskPassAscii"]) > PASSPHRASE_MAX_LEN) then
                -- PassphraseASCII range is (8-63) characters. 
                -- setting INVALID_PARAM_VALUE error code
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."KeyPassphrase", error_code.INVALID_PARAM_VALUE)
                return status, faultTbl;
            end

            profileRow["pskPassAscii"] = input["dot11VAP"]["dot11VAP.appskPassAscii"]
        elseif(string.find(newMode, "Enterprise")) then
            profileRow["pskPassAscii"] = ""
        end
    else
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."ModeEnabled", error_code.INVALID_PARAM_VALUE)
        tr69Glue.tf1Dbg("Configured ModeEnabled not supported..")
        return status, faultTbl;
    end

    require "teamf1lualib/gui"
    require "teamf1lualib/wireless"

    local security = {}
    security =  gui.helper.securityGet(profileRow["security"],profileRow["pairwiseCiphers"],profileRow["wepAuth"],profileRow["groupCipher"])
    if (not(security)) then
        tr69Glue.tf1Dbg("Configured security not supported!!..")
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."ModeEnabled", error_code.INVALID_PARAM_VALUE)
        return status, faultTbl;
    end

    --apply auth changes in profile settings
    --call the backend lua to update the tbl entries
    profileRow = util.addPrefix(profileRow, "dot11Profile.")
    errorCode,statusMsg = dot11.profile_config (profileRow, profileRow["dot11Profile._ROWID_"], "edit") 
    if(util.fileExists("/pfrm2.0/BRCMJCO300"))then
        os.execute("sleep 3")
    end
        
    db.save()
    return status, faultTbl;
end

--[[
--*****************************************************************************
-- dot11Tr.profileSet- set wlan ssid profile configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.WiFi.AccessPoint.0.
--
-- SSIDAdvertisementEnabled
-- RekeyingInterval
--
-- Returns: status
]]--
function dot11Tr.profileSet(input, rowids, actionType, tr69Param)
    local status = "0"
    local row = {}
    local rowId
    local query = nil
    local ssidProfileConfTbl = {}
    local faultTbl = {}
    local index = 0

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        tr69Glue.tf1Dbg("instanceMapLoad failed..")
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --find the immediate parent object with instance number or
    --extract the Device.WiFi.AccessPoint.0. part from tr69Param
    local startIdx, endIdx
    local parentObjInstance
    startIdx, endIdx = string.find(tr69Param, "AccessPoint.")
    parentObjInstance = string.sub(tr69Param, 1, endIdx+2)
    
    --read the rowId mapping to dot11Profile
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        tr69Glue.tf1Dbg("No instance found for -- " .. parentObjInstance)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get correspnding db entry from dot11Profile 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("dot11Profile", query, false)
    if(row == nil) then
        tr69Glue.tf1Dbg("No entry in dot11Profile with rowId -- " .. rowId)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    ssidProfileConfTbl = row

    if (input["dot11Profile"]["dot11Profile.broadcastSSID"] ~= nil) then
        ssidProfileConfTbl["broadcastSSID"] = input["dot11Profile"]["dot11Profile.broadcastSSID"]
    elseif (input["dot11Profile"]["dot11Profile.groupKeyUpdateInterval"] ~= nil) then
        if(tonumber(input["dot11Profile"]["dot11Profile.groupKeyUpdateInterval"]) > 0 and tonumber(input["dot11Profile"]["dot11Profile.groupKeyUpdateInterval"]) < 65536) then
            ssidProfileConfTbl["groupKeyUpdateInterval"] = input["dot11Profile"]["dot11Profile.groupKeyUpdateInterval"]
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."RekeyingInterval", error_code.INVALID_PARAM_VALUE)
        end
    else
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
    end

    if (status ~= OK) then
        return status, faultTbl
    end

    --apply ssid profile settings
    local errorCode,statusMsg
    ssidProfileConfTbl = util.addPrefix(ssidProfileConfTbl, "dot11Profile.")
    errorCode,statusMsg = dot11.profile_config (ssidProfileConfTbl, ssidProfileConfTbl["dot11Profile._ROWID_"], "edit") 
    if(util.fileExists("/pfrm2.0/BRCMJCO300"))then
        os.execute("sleep 3")
    end
  
    db.save()
    return 0;
end

--[[
--*****************************************************************************
-- dot11Tr.wmmProfileSet- set WMMEnable configuration parameter
-- 
-- This function is called to set the following parameters in
-- Device.WiFi.AccessPoint.0.
--
-- WMMEnable
-- 
--
-- Returns: status
]]--
function dot11Tr.wmmProfileSet(input, rowids, actionType, tr69Param)
    local status = "0"
    local row = {}
    local rowId
    local query = nil
    local ssidProfileConfTbl = {}
    local faultTbl = {}
    local index = 0

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        tr69Glue.tf1Dbg("instanceMapLoad failed..")
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR) 
        return status, faultTbl;
    end

    --find the immediate parent object with instance number or
    --extract the Device.WiFi.AccessPoint.0. part from tr69Param
    local startIdx, endIdx
    local parentObjInstance
    startIdx, endIdx = string.find(tr69Param, "AccessPoint.")
    parentObjInstance = string.sub(tr69Param, 1, endIdx+2)
    
    --read the rowId mapping to dot11Profile
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        tr69Glue.tf1Dbg("No instance found for -- " .. parentObjInstance)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR) 
        return status, faultTbl;
    end

    --get correspnding db entry from dot11Profile 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("dot11Profile", query, false)
    if(row == nil) then
        tr69Glue.tf1Dbg("No entry in dot11Profile with rowId -- " .. rowId)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR) 
        return status, faultTbl;
    end

    if (input["dot11Profile"]["dot11Profile.qosEnable"] ~= nil) then
        local wmmEnable = input["dot11Profile"]["dot11Profile.qosEnable"]

	local radioNumber = db.getAttribute("dot11VAP","profileName",row["profileName"],"radioList")
  	local dot11VapTbl = db.getRowsWhere("dot11VAP", "radioList='"..radioNumber.."'",false)

        for k,v in pairs (dot11VapTbl) do
            db.setAttribute ("dot11Profile","_ROWID_",v["_ROWID_"], "qosEnable",wmmEnable) 
        end

	local radioInterface = db.getAttribute("dot11Radio","radioNo",radioNumber,"interfaceName")
	if(radioInterface ~= nil)then
  	    local enabledVapTable = db.getRowsWhere("dot11VAP", "radioList='"..radioNumber.."' and vapEnabled='1'",false)
   	    if(enabledVapTable ~= nil) then
       	        for k,v in pairs(enabledVapTable)do
                    local vapInterface = db.getAttribute("dot11Interface","vapName",v["vapName"],"interfaceName")
                    --bring down all vap interfaces
                    dot11.if_up(vapInterface,0)
                end
            end
   
            --bring down radio interface
            dot11.if_up(radioInterface,0)
            if (tonumber(wmmEnable) == tonumber(1))then
                --set wmm on radioInterface
                cmd = "/bin/wl -i " .. radioInterface .. " wme 1"
        	    tr69Glue.tf1Dbg("cmd =" .. cmd)
                os.execute (cmd)
            else
                --set wmm off radioInterface
                cmd = "/bin/wl -i " .. radioInterface .. " wme 0"
        	    tr69Glue.tf1Dbg("cmd =" .. cmd)
                os.execute (cmd)
            end
            --bring up radio interface
            dot11.if_up(radioInterface,1)
            if(enabledVapTable ~= nil) then
                for k,v in pairs(enabledVapTable)do
                    local vapInterface = db.getAttribute("dot11Interface","vapName",v["vapName"],"interfaceName")
                    --bring up all enabled vap interfaces
                    dot11.if_up(vapInterface,1)
                end
            end 
        end
    end

    db.save()
  
    return 0;
end

--[[
--*****************************************************************************
-- dot11Tr.wpsInfoGet- get WPS configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.WiFi.AccessPoint.0.WPS.
--
-- Enable
-- ConfigMethodsSupported
-- ConfigMethodsEnabled
--
-- Returns: status, value
]]--
function dot11Tr.wpsInfoGet(input)
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local row = {} --dot11WPS entry
    local vapRow = {} --dot11WPS entry
    local query = nil
    local vapQry = nil
    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "AccessPoint.")
    parentObjInstance = string.sub(param, 1, endIdx+2)

    --read the rowId mapping to dot11WPS
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from dot11WPS
    query = "_ROWID_= 1" 
    row = db.getRowWhere ("dot11WPS", query, false)
    if(row == nil) then
        tr69Glue.tf1Dbg("No entry in dot11WPS with rowId 1 -- ")
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    vapQry = "_ROWID_= " .. rowId 
    vapRow = db.getRowWhere ("dot11VAP", vapQry, false)
    if(vapRow == nil) then
        tr69Glue.tf1Dbg("No entry in dot11VAP with rowId -- "..rowId)
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    local interfaceName = nil
    interfaceName = db.getAttribute ("dot11Interface", "vapName", vapRow["vapName"], "interfaceName")
    if(interfaceName == nil or interfaceName == "") then
        tr69Glue.tf1Dbg("No entry in dot11Interface with vapName -- "..vapRow["vapName"])
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find & return parameter values
    if(string.find(input["param"], "ConfigMethodsSupported")) then
        -- ConfigMethodsSupported
        value = "PushButton"
    elseif(string.find(input["param"], "ConfigMethodsEnabled")) then
        -- ConfigMethodsEnabled
        value = "PushButton"
    elseif(string.find(input["param"], "Enable")) then
        -- Enable
        if(row["vapName"] == interfaceName) then
            value = row["wpsEnabled"]
        else
            value = 0
        end
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    
    return status, value
end

--[[
--*****************************************************************************
-- dot11Tr.wpsInfoSet- set WPS configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.WiFi.AccessPoint.0.WPS.
--
-- Enable
-- ConfigMethodsSupported
-- ConfigMethodsEnabled
--
-- Returns: status
]]--
function dot11Tr.wpsInfoSet(input, rowids, actionType, tr69Param)
    local status = OK
    local row = {}
    local rowId
    local vapRow = {} --dot11WPS entry
    local vapQry = nil
    local query = nil
    local wpsConfTbl = {}
    local faultTbl = {}
    local index = 0
    local wpsStatusFlag = 0
    local wpsCfgMethodFlag = 0

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        tr69Glue.tf1Dbg("instanceMapLoad failed..")
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end
    --find the immediate parent object with instance number or
    --extract the Device.WiFi.AccessPoint.0. part from tr69Param
    local startIdx, endIdx
    local parentObjInstance
    startIdx, endIdx = string.find(tr69Param, "AccessPoint.")
    parentObjInstance = string.sub(tr69Param, 1, endIdx+2)
    
    --read the rowId mapping to dot11WPS
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        tr69Glue.tf1Dbg("No instance found for -- " .. parentObjInstance)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    --get corresponding db entry from dot11WPS
    query = "_ROWID_= 1"
    row = db.getRowWhere ("dot11WPS", query, false)
    if(row == nil) then
        tr69Glue.tf1Dbg("No entry in dot11WPS with rowid 1")
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    vapQry = "_ROWID_= " .. rowId 
    vapRow = db.getRowWhere ("dot11VAP", vapQry, false)
    if(vapRow == nil) then
        tr69Glue.tf1Dbg("No entry in dot11VAP with rowId -- " .. rowId)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    local interfaceName = nil
    interfaceName = db.getAttribute ("dot11Interface", "vapName", vapRow["vapName"], "interfaceName")
    if(interfaceName == nil or interfaceName == "") then
        tr69Glue.tf1Dbg("No entry in dot11Interface with vapName -- " .. vapRow["vapName"])
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    wpsConfTbl = row

    -- Enable
    if(input["dot11VAP"]["dot11VAP.wpsEnabled"] ~= nil) then 
        local security = db.getAttribute("dot11Profile", "profileName", vapRow["profileName"], "security")
        authMethods = db.getAttribute("dot11Profile", "profileName", vapRow["profileName"], "authMethods")
        if (security == "OPEN" or security == "WEP" or authMethods == "RADIUS" or security == "WPA") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Enable", error_code.REQUEST_DENIED)
            tr69Glue.tf1Dbg("Cannot enable WPS if security is = "..security)
        else
            wpsConfTbl["wpsEnabled"] = input["dot11VAP"]["dot11VAP.wpsEnabled"]
            wpsStatusFlag = 1
        end
    end

    -- ConfigMethodsEnabled
    if(input["dot11VAP"]["dot11VAP.wpsMethodEnabled"] ~= nil) then
        if(input["dot11VAP"]["dot11VAP.wpsMethodEnabled"] == "PushButton") then
            if(vapRow["vapEnabled"] == "0") then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."ConfigMethodsEnabled", error_code.REQUEST_DENIED)
                tr69Glue.tf1Dbg("Selected AP is disabled..")
            else
                if(interfaceName == wpsConfTbl["vapName"]) then
                    if(wpsConfTbl["wpsEnabled"] == "1") then
                        wpsCfgMethodFlag = 1
                    else
                        status = ERROR
                        index = index + 1
                        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."ConfigMethodsEnabled", error_code.REQUEST_DENIED)
                        tr69Glue.tf1Dbg("WPS is disabled..")
                    end
                else
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."ConfigMethodsEnabled", error_code.REQUEST_DENIED)
                    tr69Glue.tf1Dbg("WPS is disabled for this AP..")
                end
            end
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."ConfigMethodsEnabled", error_code.INVALID_PARAM_VALUE)
            tr69Glue.tf1Dbg("ConfigMethodsEnabled not supported..")
        end
    end

    if(status == ERROR) then
        return status, faultTbl
    end

    local inputTable = {}
    inputTable["tf1_dot11WPS_vaps"] = vapRow["vapName"] 
    inputTable["enableDisableWPS"] = wpsConfTbl["wpsEnabled"]

    --apply wps enable/disable settings
    if(wpsStatusFlag == 1) then
        errorCode, statusMsg = gui.wireless.wps.set(inputTable, dbFlag) 
        if(errorCode ~= "OK") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Enable", error_code.INTERNAL_ERROR)
            tr69Glue.tf1Dbg("WPS config failed, statusMsg = " ..statusMsg)
            return status, faultTbl
        end
    end


    --apply pushbutton setting
    if(wpsCfgMethodFlag == 1) then
        errorCode, statusMsg = gui.wireless.wps.pbcConfig(inputTable, dbFlag)
        if(errorCode ~= "OK") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."ConfigMethodsEnabled", error_code.INTERNAL_ERROR)
            tr69Glue.tf1Dbg("WPS Pushbutton config failed, statusMsg = "..statusMsg)
            return status, faultTbl
        end
    end

    db.save()

    return status, faultTbl
end

--[[
--*****************************************************************************
-- dot11Tr.ieee1905InfoGet- get ieee1905 configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.WiFi.AccessPoint.0.WPS.
--
-- Enable
-- ConfigMethodsSupported
-- ConfigMethodsEnabled
--
-- Returns: status, value
]]--
function dot11Tr.ieee1905InfoGet(input)
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local row = {} --dot11WPS entry
    local vapRow = {} --dot11WPS entry
    local query = nil
    local vapQry = nil
    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "AccessPoint.")
    parentObjInstance = string.sub(param, 1, endIdx+2)

    --read the rowId mapping to ieee1905
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from ieee1905
    query = "_ROWID_= 1" 
    row = db.getRowWhere ("ieee1905", query, false)
    if(row == nil) then
        tr69Glue.tf1Dbg("No entry in dot11WPS with rowId 1 -- ")
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    vapQry = "_ROWID_= " .. rowId 
    vapRow = db.getRowWhere ("dot11VAP", vapQry, false)
    if(vapRow == nil) then
        tr69Glue.tf1Dbg("No entry in dot11VAP with rowId -- "..rowId)
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    local interfaceName = nil
    interfaceName = db.getAttribute ("dot11Interface", "vapName", vapRow["vapName"], "interfaceName")
    if(interfaceName == nil or interfaceName == "") then
        tr69Glue.tf1Dbg("No entry in dot11Interface with vapName -- "..vapRow["vapName"])
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        if(row["registrarName"] == interfaceName) then
            value = row["ieee1905Enabled"]
        else
            value = 0
        end
    elseif(string.find(input["param"], "WPSStart")) then
            value = "PushButton"
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    
    return status, value
end

--[[
--*****************************************************************************
-- dot11Tr.ieee1905Set- set ieee1905 configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.WiFi.AccessPoint.0.ieee1905.
--
-- Enable
-- ConfigMethodsSupported
-- ConfigMethodsEnabled
--
-- Returns: status
]]--
function dot11Tr.ieee1905Set(input, rowids, actionType, tr69Param)
    local status = OK
    local row = {}
    local rowId
    local vapRow = {} --dot11WPS entry
    local vapQry = nil
    local query = nil
    local ieee1905Tbl = {}
    local wpsConfTbl = {}
    local faultTbl = {}
    local index = 0
    local ieee1905StatusFlag = 0

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        tr69Glue.tf1Dbg("instanceMapLoad failed..")
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end
    --find the immediate parent object with instance number or
    --extract the Device.WiFi.AccessPoint.0. part from tr69Param
    local startIdx, endIdx
    local parentObjInstance
    startIdx, endIdx = string.find(tr69Param, "AccessPoint.")
    parentObjInstance = string.sub(tr69Param, 1, endIdx+2)
    
    --read the rowId mapping to dot11WPS
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        tr69Glue.tf1Dbg("No instance found for -- " .. parentObjInstance)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    --get corresponding db entry from dot11WPS
    query = "_ROWID_= 1"
    row = db.getRowWhere ("ieee1905", query, false)
    wpsConfTbl = db.getRowWhere ("dot11WPS", query, false)
    if(row == nil or wpsConfTbl == nil) then
        tr69Glue.tf1Dbg("No entry in ieee1905/dot11WPS with rowid 1")
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    vapQry = "_ROWID_= " .. rowId 
    vapRow = db.getRowWhere ("dot11VAP", vapQry, false)
    if(vapRow == nil) then
        tr69Glue.tf1Dbg("No entry in dot11VAP with rowId -- " .. rowId)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    local interfaceName = nil
    interfaceName = db.getAttribute ("dot11Interface", "vapName", vapRow["vapName"], "interfaceName")
    if(interfaceName == nil or interfaceName == "") then
        tr69Glue.tf1Dbg("No entry in dot11Interface with vapName -- " .. vapRow["vapName"])
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    ieee1905Tbl = row

    -- Enable
    if(input["dot11VAP"]["dot11VAP.ieee1905Enabled"] ~= nil) then 
        ieee1905Tbl["ieee1905Enabled"] = input["dot11VAP"]["dot11VAP.ieee1905Enabled"]
    end

    -- WPSStart
    if(input["dot11VAP"]["dot11VAP.WPSStart"] ~= nil) then
        if(input["dot11VAP"]["dot11VAP.WPSStart"] == "PushButton") then
            if(vapRow["vapEnabled"] == "0") then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."WPSStart", error_code.REQUEST_DENIED)
                tr69Glue.tf1Dbg("Selected AP is disabled..")
            else
                if(interfaceName == ieee1905Tbl["registrarName"] and wpsConfTbl["wpsEnabled"] == "1" and tonumber(ieee1905Tbl["ieee1905Enabled"]) == 1) then
                    ieee1905StatusFlag = 1
                else
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."WPSStart", error_code.REQUEST_DENIED)
                    tr69Glue.tf1Dbg("WPS is disabled for this AP..")
                end
            end
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."WPSStart", error_code.INVALID_PARAM_VALUE)
            tr69Glue.tf1Dbg("WPSStart not supported..")
        end
    end

    if(status == ERROR) then
        return status, faultTbl
    end

    --apply wps enable/disable settings
    if(ieee1905StatusFlag ~= 1) then
        errorCode, statusMsg = gui.wireless.ieee1905.set(ieee1905Tbl, dbFlag) 
        if(errorCode ~= "OK") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Enable", error_code.INTERNAL_ERROR)
            tr69Glue.tf1Dbg("WPS config failed, statusMsg = " ..statusMsg)
            return status, faultTbl
        end
    end


    --apply pushbutton setting
    if(ieee1905StatusFlag == 1) then
        errorCode, statusMsg = gui.wireless.ieee1905.pbcConfig(ieee1905Tbl, dbFlag)
        if(errorCode ~= "OK") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."WPSStart", error_code.INTERNAL_ERROR)
            tr69Glue.tf1Dbg("WPS Pushbutton config failed, statusMsg = "..statusMsg)
            return status, faultTbl
        end
    end

    db.save()

    return status, faultTbl
end

--[[
--*****************************************************************************
-- dot11Tr.radiusServerInfoGet- get radius server configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.WiFi.AccessPoint.0.Security.
--
-- RadiusServerIPAddr
-- RadiusServerPort
-- RadiusSecret
--
-- Returns: status, value
]]--
function dot11Tr.radiusServerInfoGet(input)
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local row = {} --radiusClient entry
    local query = nil
    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "AccessPoint.")
    parentObjInstance = string.sub(param, 1, endIdx+2)

    --read the rowId mapping to radiusClient
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from radiusClient
    query = "_ROWID_= 1"
    row = db.getRowWhere ("radiusClient", query, false)
    if(row == nil) then
        tr69Glue.tf1Dbg("No entry in radiusClient with rowId -- " .. rowId)
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find & return parameter values
    if(string.find(input["param"], "RadiusServerIPAddr")) then
        -- RadiusServerIPAddr
        value = row["authserver"]
    elseif(string.find(input["param"], "RadiusServerPort")) then
        -- RadiusServerPort
        value = row["authport"]
    elseif(string.find(input["param"], "RadiusSecret")) then
        -- RadiusSecret
        value = ""
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- dot11Tr.radiusServerInfoSet- set radius server configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.WiFi.AccessPoint.0.Security.
--
-- RadiusServerIPAddr
-- RadiusServerPort
-- RadiusSecret
--
-- Returns: status
]]--
function dot11Tr.radiusServerInfoSet(input, rowids, actionType, tr69Param)
    local status = "0"
    local row = {}
    local rowId
    local query = nil
    local ssidProfileConfTbl = {}
    local faultTbl = {}
    local index = 0

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        tr69Glue.tf1Dbg("instanceMapLoad failed..")
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end
    --find the immediate parent object with instance number or
    --extract the Device.WiFi.AccessPoint.0. part from tr69Param
    local startIdx, endIdx
    local parentObjInstance
    startIdx, endIdx = string.find(tr69Param, "AccessPoint.")
    parentObjInstance = string.sub(tr69Param, 1, endIdx+2)
    
    --read the rowId mapping to radiusClient
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        tr69Glue.tf1Dbg("No instance found for -- " .. parentObjInstance)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get corresponding db entry from radiusClient
    query = "_ROWID_= 1"
    row = db.getRowWhere ("radiusClient", query, false)
    if(row == nil) then
        tr69Glue.tf1Dbg("No entry in radiusClient with rowId -- " .. rowId)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end
    ssidProfileConfTbl = row
    --find & return parameter values
    if(input["dot11VAP"]["dot11VAP.authserver"] ~= nil) then
      if(tr69Glue.tf1IpAddressValidate(input["dot11VAP"]["dot11VAP.authserver"], "", "dot11VAP.authserver", "") == "OK") then 
        -- RadiusServerIPAddr
        ssidProfileConfTbl["authserver"] = input["dot11VAP"]["dot11VAP.authserver"]
      else
        -- radius auth server should be valid IP address
        -- setting INVALID_PARAM_VALUE error code
         status = ERROR
         index = index + 1
         faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."RadiusServerIPAddr", error_code.INVALID_PARAM_VALUE)
      end
    end

    if(input["dot11VAP"]["dot11VAP.authport"] ~= nil) then
        -- RadiusServerPort
        if(tonumber(input["dot11VAP"]["dot11VAP.authport"]) >= RADIUS_PORT_MIN_VAL and tonumber(input["dot11VAP"]["dot11VAP.authport"]) <= RADIUS_PORT_MAX_VAL) then
            ssidProfileConfTbl["authport"] = input["dot11VAP"]["dot11VAP.authport"]
        else
        -- radius auth port valid range(1-65535)
        -- setting INVALID_PARAM_VALUE error code
           status = ERROR
           index = index + 1
           faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."RadiusServerPort", error_code.INVALID_PARAM_VALUE)
        end
    end

    if(input["dot11VAP"]["dot11VAP.authsecret"] ~= nil) then
      if(string.len(input["dot11VAP"]["dot11VAP.authsecret"]) < RADIUS_SECRET_MAX_LEN) then
        -- RadiusSecret
        ssidProfileConfTbl["authsecret"] = input["dot11VAP"]["dot11VAP.authsecret"]
      else
        -- radius auth secret should not exceed 128 characters
        -- setting INVALID_PARAM_VALUE error code
          status = ERROR
          index = index + 1
          faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."RadiusSecret", error_code.INVALID_PARAM_VALUE)
      end
    end

    if (status == ERROR) then
       return status, faultTbl
    end

    --apply radiusClient settings
    local errorCode,statusMsg
    ssidProfileConfTbl = util.addPrefix(ssidProfileConfTbl, "radiusClient.")
    errorCode,statusMsg = db.update ("radiusClient",ssidProfileConfTbl, ssidProfileConfTbl["radiusClient._ROWID_"]) 
    db.save()
  
    return status, faultTbl;
end

--[[
--*****************************************************************************
-- dot11Tr.wifiClientInfoGet- get wifi Client configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.WiFi.AccessPoint.0.AssociatedDevice.0.
--
-- MACAddress
-- AuthenticationState
--
-- Returns: status, value
]]--
function dot11Tr.wifiClientInfoGet(input)
    local status = "0"
    local value = "0"
    local rowId
    local row = {} --dot11STA entry
    local query = nil
    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --read the rowId mapping to Device.WiFi.AccessPoint.0.AssociatedDevice.0.
    rowId = instanceMap[param]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from dot11STA
    query = "_ROWID_= " .. rowId
    row = db.getRowWhere ("dot11STA", query, false)
    if(row == nil) then
        tr69Glue.tf1Dbg("No entry in dot11STA with rowId -- " .. rowId)
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    local chipsetRow = db.getRowWhere("chipsetInfo", "_ROWID_=1", false)

    --find & return parameter values
    
    if(string.find(input["param"], "MACAddress")) then
        -- MACAddress
        value = row["macAddress"]
    elseif(string.find(input["param"], "OperatingStandard")) then
        -- OperatingStandard
        if(chipsetRow["Chipset"] == "Broadcom") then
            if(string.find(row["interfaceName"], "wl0")) then
                cmd = "/bin/wl -i "..row["interfaceName"].. " sta_info " .. row["macAddress"] .. " |grep 'HT caps'| cut -d':' -f 1 | cut -d' ' -f 4 > /tmp/oprStd"
                os.execute(cmd)
                val = util.fileToString("/tmp/oprStd")
                val = string.gsub(val, "\n", "")
                if(val == "0x0") then
                    cmd = "/bin/wl -i "..row["interfaceName"].. " sta_info " .. row["macAddress"] .. " |grep 'No-ERP' > /tmp/oprStd"
                    os.execute(cmd)
                    val = util.fileToString("/tmp/oprStd")
                    if(val ~= nil and val ~= "") then
                        value = "b"
                    else
                        value = "g"
                    end
                else
                    value = "n"
                end
            elseif(string.find(row["interfaceName"], "wl1")) then
                cmd = "/bin/wl -i "..row["interfaceName"].. " sta_info " .. row["macAddress"] .. " |grep 'VHT caps' > /tmp/oprStd"
                os.execute(cmd)
                val = util.fileToString("/tmp/oprStd")
                if(val ~= nil and val ~= "") then
                    value = "ac"
                else
                    value = "a"
                end
            end
        end
        os.remove("/tmp/oprStd")
    elseif(string.find(input["param"], "AuthenticationState")) then
        -- AuthenticationState
        if(row["authentication"] == "OPEN") then
            value = 0
        else
            value = 1
        end
    elseif(string.find(input["param"], "LastDataDownlinkRate")) then
        if(chipsetRow["Chipset"] == "Lantiq") then
            local rateCmd = "mtdump "..row["interfaceName"].. " PeerFlowStatus " .. row["macAddress"] .. " |grep 'Last receive rate' | cut -d':' -f 1 | sed -e's/  *//g'"
            local pipe = io.popen(rateCmd .. " 2>&1") -- redirect stderr to stdout
            local rxRate = pipe:read("*line")
            pipe:close()
            if(rxRate ~= nil) then
                rxRate = rxRate*1024
                value = math.floor(rxRate)
            else
                value = "0"
            end
        else
            local rateCmd = "wl -i "..row["interfaceName"].. " sta_info " .. row["macAddress"] .. " |grep rate|grep rx|cut -d ':' -f 2|cut -d ' ' -f 2"
            local pipe = io.popen(rateCmd .. " 2>&1") -- redirect stderr to stdout
            local rxRate = pipe:read("*line")
            pipe:close()
            if(rxRate ~= nil) then 
                value = rxRate
            else
                value = "0"
            end
        end
    elseif(string.find(input["param"], "LastDataUplinkRate")) then
        if(chipsetRow["Chipset"] == "Lantiq") then
            local rateCmd = "mtdump "..row["interfaceName"].. " PeerFlowStatus " .. row["macAddress"] .. " |grep 'Last transmit rate' | cut -d':' -f 1 | sed -e's/  *//g'"
            local pipe = io.popen(rateCmd .. " 2>&1") -- redirect stderr to stdout
            local txRate = pipe:read("*line")
            pipe:close()
            if(txRate ~= nil) then
                txRate = txRate*1024
                value = math.floor(txRate)
            else
                value = "0"
            end
        else
            local rateCmd = "wl -i "..row["interfaceName"].. " sta_info " .. row["macAddress"] .. " |grep rate|grep tx|cut -d ':' -f 2|cut -d ' ' -f 2"
            local pipe = io.popen(rateCmd .. " 2>&1") -- redirect stderr to stdout
            local txRate = pipe:read("*line")
            pipe:close()
            if(txRate ~= nil) then 
                value = txRate
            else
                value = "0"
            end
        end
    elseif(string.find(input["param"], "SignalStrength")) then
        -- SignalStrength 
        value = dot11Tr.getSignalNoise(row, "average rssi", chipsetRow["Chipset"])
        if(value == nil) then
            return "1", "DB_ERROR_TRY_AGAIN"
        end
    elseif(string.find(input["param"], "X_M_ConnectionTime")) then
        -- X_M_ConnectionTime
        if(chipsetRow["Chipset"] == "Lantiq") then
            local timeElapsed = ""
            local cmd = "/bin/hostapd_cli -i "..row["interfaceName"] .. " sta "..row["macAddress"].." | grep connected_time | cut -d'=' -f 2"
            local file = io.popen(cmd)
            if (file)then
                timeElapsed = file:read("*line")
                if(timeElapsed ~= nil and timeElapsed ~= '' and timeElapsed ~= " " and tonumber(timeElapsed) > 0) then
                    local mins = math.floor(tonumber(timeElapsed) / 60)
                    local sec = tonumber(timeElapsed) % 60
                    local hours = math.floor (mins / 60)
                    mins = mins % 60
                    local days = math.floor (hours / 24)
                    hours = hours % 24
                    timeElapsed = days .. " days, " .. hours .. " hours, " .. mins .. " minutes, " .. sec .. " seconds"
                    value = timeElapsed
                else
                    value = "N/A"
                end
            end
        else
            local cmd = "/bin/wl -i " ..row["interfaceName"].. " sta_info " ..row["macAddress"].. " assoclist | grep \"in\" | awk '{print($3)}' > /tmp/timeInfo"
            os.execute(cmd)

            local file = io.open("/tmp/timeInfo","r")
            if (file) then
                timeElapsed = file:read ("*line")
                value = util.timeConversion (timeElapsed)
                file:close()
            else
                os.remove("/tmp/timeInfo")
                return "1", "DB_ERROR_TRY_AGAIN"
            end
            os.remove("/tmp/timeInfo")
        end
    elseif(string.find(input["param"], "X_M_SNR")) then
        -- X_M_SNR 
        if(chipsetRow["Chipset"] == "Broadcom") then
            signalAvg = dot11Tr.getSignalNoise(row, "average rssi", chipsetRow["Chipset"])
            noiseAvg = dot11Tr.getSignalNoise(row, "noise", chipsetRow["Chipset"])
            if(signalAvg ~= nil and signalAvg ~= "" and noiseAvg ~= nil and noiseAvg ~= "" ) then
                value = signalAvg - noiseAvg
            else
                return "1", "DB_ERROR_TRY_AGAIN"
            end
        end
    elseif(string.find(input["param"], "Active")) then
        -- Active
        value = "1"
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- dot11Tr.assocStatsGet- get wlan ssid profile stats
-- 
-- This function is called to get the following parameters in
-- Device.WiFi.AccessPoint.0.AssociatedDevice.0.Stats.
--
-- BytesSent
-- BytesReceived
-- PacketsSent
-- PacketsReceived
--
-- Returns: status, value
]]--
function dot11Tr.assocStatsGet (input)
    -- require
    require "teamf1lualib/ifDev"

    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local row = {}
    local apCfgRow = {}
    local query = nil
    local param = input["param"]
    local cmd = ""

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find the immediate parent object with instance number
    local t = util.split(param, ".")
    parentObjInstance = t[1].."."..t[2].."."..t[3].."."..t[4].."."..t[5].."."..t[6].."."  
    
    --read the rowId mapping to Device.WiFi.AccessPoint.0.AssociatedDevice.0.
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from dot11STA
    query = "_ROWID_= " .. rowId
    row = db.getRowWhere ("dot11STA", query, false)
    if(row == nil) then
        tr69Glue.tf1Dbg("No entry in dot11STA with rowId -- " .. rowId)
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    local chipsetRow = db.getRowWhere("chipsetInfo", "_ROWID_=1", false)

    --find & return parameter values
    if(string.find(input["param"], "PacketsSent")) then
        -- PacketsSent
        if(chipsetRow["Chipset"] == "Broadcom") then
            cmd = "/bin/wl -i "..row["interfaceName"].. " sta_info " .. row["macAddress"] .. " |grep 'tx total pkts:'|cut -d ':' -f 2|cut -d ' ' -f 2"
        else
            cmd = "mtdump "..row["interfaceName"].. " PeerFlowStatus " .. row["macAddress"] .. " |grep 'Number of packets transmitted' | cut -d':' -f 1 | sed -e's/  *//g'"
        end

        local pipe = io.popen(cmd .. " 2>&1") -- redirect stderr to stdout
        local packetsSent = pipe:read("*line")
        pipe:close()
        if(packetsSent ~= nil) then 
            value = packetsSent
        else
            return "1", "DB_ERROR_TRY_AGAIN"
        end
    elseif(string.find(input["param"], "PacketsReceived")) then
        -- PacketsReceived
        if(chipsetRow["Chipset"] == "Broadcom") then
            cmd = "/bin/wl -i "..row["interfaceName"].. " sta_info " .. row["macAddress"] .. " |grep 'rx data pkts:'|cut -d ':' -f 2|cut -d ' ' -f 2"
        else
            cmd = "mtdump "..row["interfaceName"].. " PeerFlowStatus " .. row["macAddress"] .. " |grep 'Number of packets received' | cut -d':' -f 1 | sed -e's/  *//g'"
        end

        local pipe = io.popen(cmd .. " 2>&1") -- redirect stderr to stdout
        local packetsReceived = pipe:read("*line")
        pipe:close()
        if(packetsReceived ~= nil) then 
            value = packetsReceived
        else
            return "1", "DB_ERROR_TRY_AGAIN"
        end
    elseif(string.find(input["param"], "ErrorsSent")) then
        -- ErrorsSent
        if(chipsetRow["Chipset"] == "Broadcom") then
            cmd = "/bin/wl -i "..row["interfaceName"].. " sta_info " .. row["macAddress"] .. " |grep 'tx failures:'|cut -d ':' -f 2|cut -d ' ' -f 2"
            local pipe = io.popen(cmd .. " 2>&1") -- redirect stderr to stdout
            local errorsSent = pipe:read("*line")
            pipe:close()
            if(errorsSent ~= nil) then 
                value = errorsSent
            else
                return "1", "DB_ERROR_TRY_AGAIN"
            end
        end
    elseif(string.find(input["param"], "RetransCount")) then
        -- RetransCount
        if(chipsetRow["Chipset"] == "Broadcom") then
            cmd = "/bin/wl -i "..row["interfaceName"].. " sta_info " .. row["macAddress"] .. " |grep 'tx pkts retries:'|cut -d ':' -f 2|cut -d ' ' -f 2"
        else
            cmd = "mtdump "..row["interfaceName"].. " PeerFlowStatus " .. row["macAddress"] .. " |grep retransmissions | cut -d':' -f 1 | sed -e's/  *//g'"
        end

        local pipe = io.popen(cmd .. " 2>&1") -- redirect stderr to stdout
        local retransCount = pipe:read("*line")
        pipe:close()
        if(retransCount ~= nil) then 
            value = retransCount
        else
            return "1", "DB_ERROR_TRY_AGAIN"
        end
	elseif(string.find(input["param"], "BytesSent")) then
        -- BytesSent
        if(chipsetRow["Chipset"] == "Broadcom") then
			cmd = "/bin/wl -i "..row["interfaceName"].. " sta_info " .. row["macAddress"] .. " | grep 'tx total bytes:'|cut -d ':' -f 2|cut -d ' ' -f 2"
		end
        local pipe = io.popen(cmd .. " 2>&1") -- redirect stderr to stdout
        local bytesSent = pipe:read("*line")
        pipe:close()
        if(bytesSent ~= nil) then 
            value = bytesSent
        else
            return "1", "DB_ERROR_TRY_AGAIN"
        end
	elseif(string.find(input["param"], "BytesReceived")) then
        -- BytesReceived
        if(chipsetRow["Chipset"] == "Broadcom") then
			cmd = "/bin/wl -i "..row["interfaceName"].. " sta_info " .. row["macAddress"] .. " | grep 'rx data bytes:'|cut -d ':' -f 2|cut -d ' ' -f 2"
		end
        local pipe = io.popen(cmd .. " 2>&1") -- redirect stderr to stdout
        local bytesReceived = pipe:read("*line")
        pipe:close()
        if(bytesReceived ~= nil) then 
            value = bytesReceived
        else
            return "1", "DB_ERROR_TRY_AGAIN"
        end
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

-- function to check if file exist
--
function file_exists(name)
   local f=io.open(name,"r")
   if f~=nil then io.close(f) return true else return false end
end

-- file path in flash
local PKT_NAME = "/tmp/tr181_wifiThroughPutInfo.cfg"

--[[
--*****************************************************************************
-- dot11Tr.wifiThroughputGet - get Wifi ThroughtPut
-- 
-- Returns: wifiThroughtPut
]]--

function dot11Tr.wifiThroughputGet (input)
   
    local rx_pkt_sum = 0
    local tx_pkt_sum = 0
    local wifiThroughtPut = 0
    local status = "0"
    local value = "0"
     
    dofile (PKT_NAME)
   
    local f=io.open(PKT_NAME, "w")
    f:write ("rx_pkt = {}\n")
    for k,v in pairs (rx_pkt) do
    f:write ("rx_pkt[" .. k .. "]" .. " = " .. v .. "\n")
        rx_pkt_sum = rx_pkt_sum + rx_pkt[k]  
    end
    f:write ("tx_pkt = {}\n")
    for k,v in pairs (tx_pkt) do
    f:write ("tx_pkt[" .. k .. "]" .. " = " .. v .. "\n")
        tx_pkt_sum = tx_pkt_sum + tx_pkt[k]  
    end
    f:close()
    local rx_Avg = rx_pkt_sum / 60 
    local tx_Avg = tx_pkt_sum / 60
    local total_Avg = rx_Avg + tx_Avg
    wifiThroughtPut = total_Avg / 2

    -- considering this for clients
    if (string.find(input["param"], "Wifi_Uplink_Throughput")) then
        value = math.floor(rx_Avg)
    elseif (string.find(input["param"], "Wifi_Downlink_Throughput")) then
        value = math.floor(tx_Avg)
    else
        value = math.floor(wifiThroughtPut)
    end

    return status, value
end

--[[
--*****************************************************************************
-- dot11Tr.apMaxClientCfgSet- set wlan AP configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.WiFi.AccessPoint.0.
--
-- Enable
-- SSIDReference
--
-- Returns: status
]]--
function dot11Tr.apMaxClientCfgSet(input, rowids, actionType, tr69Param)
    local status = OK
    local row = {}
    local rowId
    local query = nil
    local apConfTbl = {}
    local valid
    local faultTbl = {}
    local index = 0

    --Skip if this fn has been called for Device.WiFi.SSID.0.Enable
    if(input["dot11VAP"]["dot11VAP.vapEnabled"] == nil and input["dot11VAP"]["dot11VAP.profileName"] == nil and input["dot11VAP"]["dot11VAP.maxClients"] == nil) then
        tr69Glue.tf1Dbg("vapEnabled and profileName are nil, just return..")
        return 0;
    end

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        tr69Glue.tf1Dbg("instanceMapLoad failed..")
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --find the immediate parent object with instance number or extract
    --the Device.WiFi.AccessPoint.0. part from tr69Param
    local startIdx, endIdx
    local parentObjInstance
    startIdx, endIdx = string.find(tr69Param, "AccessPoint.")
    parentObjInstance = string.sub(tr69Param, 1, endIdx+2)

    --read the rowId mapping to dot11VAP
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        tr69Glue.tf1Dbg("No instance found for -- " .. parentObjInstance)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get correspnding db entry from dot11VAP 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("dot11VAP", query, false)
    if(row == nil) then
        tr69Glue.tf1Dbg("No entry in dot11VAP with rowId -- " .. rowId)
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    apConfTbl = row
    
    if(input["dot11VAP"]["dot11VAP.maxClients"] ~= nil) then 
        if(apConfTbl["maxClients"] ~= input["dot11VAP"]["dot11VAP.maxClients"]) then
            apConfTbl["maxClients"] = input["dot11VAP"]["dot11VAP.maxClients"]

            if(tonumber(apConfTbl["maxClients"]) < 1) then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."MaxAssociatedDevices", error_code.INVALID_PARAM_VALUE)
                return status, faultTbl;
            end

            local dot11vap = db.getTable("dot11VAP", false)
            local totalClients = 0

            for _, vapRow in pairs (dot11vap) do
                if (vapRow["_ROWID_"] == rowId) then
                    totalClients = totalClients + tonumber(apConfTbl["maxClients"])
                else
                    totalClients = totalClients + tonumber(vapRow["maxClients"])
                end
            end

            local maxClientsPerRadio = db.getAttribute ("environment", "name", "MAX_CLIENTS_PER_RADIO", "value")
            if (maxClientsPerRadio and (totalClients > tonumber(maxClientsPerRadio))) then
                tr69Glue.tf1Dbg("Maximum of "..maxClientsPerRadio.." clients are supported for the device")
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."MaxAssociatedDevices", error_code.INVALID_PARAM_VALUE)
                return status, faultTbl;
            end

    
            --apply max client settings
            if(apConfTbl["maxClients"] ~= nil) then
                db.setAttribute("dot11VAP","_ROWID_",rowId,"maxClients",apConfTbl["maxClients"])
                local ifName = db.getAttribute("dot11Interface","vapName",apConfTbl["vapName"],"interfaceName")
                if(ifName ~= nil)then
                    dot11.MaxClient_config(ifName,apConfTbl["maxClients"])
                end
            end
            db.save()
        end
    end
    return 0;
end

function dot11Tr.apGroupNameSet(input, rowids, actionType, tr69Param)
    local status = "0"
    local row    = {}
    local rowId  = "1"
    local inputTable    = {}
    local faultTbl = {}
    local index = 0

    -- get corresponding db entry from 'apGroupName' 
    query = "_ROWID_='" .. rowId .. "'"
    row = db.getRowWhere ("apGroupName",query,false)

    if (row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    if (input["apGroupName"]["apGroupName.apGroupName"] ~= nil) then
        if(string.len(input["apGroupName"]["apGroupName.apGroupName"]) < 20 and string.len(input["apGroupName"]["apGroupName.apGroupName"]) > 0 )then 
            inputTable["dot11Profile.apgroupname"]= input["apGroupName"]["apGroupName.apGroupName"]
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INVALID_PARAM_VALUE)
        end
    end

    errorFlag, errorStatus = gui.wireless.apgroupname.set(inputTable, dbFlag)

    if (errorFlag ~= "OK") then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
    end

    
    return status, faultTbl;

end

------------------------------------------------------------------------------
-- @name : dot11Tr.wifiGet()
--
-- @description : Reads the status of wifi
--
-- @return : Entire wifi Status
-- 
function dot11Tr.wifiGet (input)
   
    local status = "0"
    local value = "0"
    local row = {}
    local query = nil
	
    --get corresponding db entry from 'easyMesh'
    query = "_ROWID_=1"
   
    row = db.getRowWhere ("dot11Wifi", query, false)
    
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    row = util.removePrefix(row,"dot11Wifi.")
    
    if(string.find(input["param"], "wifiOn")) then
        value = row["wifiOn"]
    else
        return "1", "DB_ERROR_TRY_AGAIN"                                                                
    end

    return status, value

end

------------------------------------------------------------------------------
-- @name : dot11Tr.WifiSet()
--
-- @description : setting the status of wifi
--
-- @return : Entire wifi Status
-- 
function dot11Tr.wifiSet (input, rowids, actionType, tr69Param)

    local status = OK
    local row = {}
    local query = nil
    local wifiTbl = {}
    local faultTbl = {}
    local index = 0
    local retStatus = OK
    local errorcode = OK
   
 
    --get corresponding db entry from 'easyMesh'
    query = "_ROWID_=1"
    wifiTbl = db.getRowWhere ("dot11Wifi", query,true)
    if(wifiTbl == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    if(input["dot11Wifi"]["dot11Wifi.wifiOn"] ~= nil) then
        row = input["dot11Wifi"]
        retStatus, errorcode = dot11.WifiSet(row)
         if(retStatus == "ERROR") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl
        else
            db.save2() 
        end
    end

    return status, faultTbl

end
