--[[ easyMesh.lua - Main handler for easyMesh API requests.
--
-- Copyright (c) 2008-2019, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: easyMesh.lua
-- Description: Main handler for easyMesh API requests.
-- 
-- modification history
-- --------------------
-- 01a, 26Nov19, ar written.
--
--]]

--************* Requires *************
require "teamf1lualib/db"
require "teamf1lualib/web"
require "teamf1lualib/util"
json = require ("teamf1lualib/json")

db.connect("/tmp/system.db")

-- easyMesh Global Lua variables 
mesh = {}

-- Mesh JSON Global Lua Variable
VAL=1

require "teamf1lualib/easyMeshDebug"
require "teamf1lualib/easyMeshResponses"
require "teamf1lualib/easyMeshMethodProcessLib"


----------------------------------------------------------------------------------
-- @name mesh.processRequest
--
-- @description This function processes Mesh API requests to the device
--
-- @return
--
function mesh.processRequest(meshApiProto, meshApiReqAction, httpReqMethod)

    local reqParams = {}
    local status , errorCode
    local sessionCookie
    
    mesh.dprintf(" ")
    mesh.dprintf("-----------------------------------------------")
    mesh.dprintf(" ")
    
    -- Sanity Check the Mesh API requests to the device. 
   
    --[[ 
    -- Request to here is unAuthorized if the request's Mesh protocol is not 1
    -- or, if the HTTP protocol request is other than "POST"
    --]]--
    if ((meshApiProto == nil) or (meshApiReqAction == nil) or (httpReqMethod == nil) or
        (meshApiProto ~= "1") or
        ((meshApiReqAction ~= "SET_CGI") and (meshApiReqAction ~= "GET_CGI")) or
        (httpReqMethod ~= "POST")) then

        mesh.dprintf("Invalid Mesh API Request Method")
        mesh.responseError ()
        return

    end
  
    -- We expect a custom HTTP header "RequestMethod" in every Mesh CGI requests
    -- to the device.
    local meshRequestMethod = cgi["RequestMethod"]
    if (meshRequestMethod == nil) then
        mesh.dprintf("Invalid Mesh API: No RequestMethod Header")
        mesh.responseError ()
        return
    end

    -- Check if POST data is received properly 
    if (cgi[VAL] == nil) then
        mesh.dprintf("JSON Data Not Provided.")
        mesh.responseError ()
        return
    end


    mesh.dprintf("MeshApi          : " .. meshApiReqAction)
    mesh.dprintf("Mesh Req Method  : " .. meshRequestMethod)
    mesh.dprintf("DATA             : " .. cgi[VAL])
    mesh.dprintf(" ")


    -- Process Easy Mesh Request Methods
    status, errorCode = mesh.requestMethodProcess(cgi[VAL], meshApiReqAction, meshRequestMethod)
    if (status == "ERROR") then
        mesh.dprintf("Operation not allowed.")
        mesh.responseError ()
        return
    end

    return
end

