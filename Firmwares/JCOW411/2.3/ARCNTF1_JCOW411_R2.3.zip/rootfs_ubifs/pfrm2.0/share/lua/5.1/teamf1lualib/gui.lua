-- gui.lua - glue GUI page with lua and mgmt lua

-- Copywrite (c) 2013 TeamF1, Inc.

--
-- modification history
-- --------------------
-- 01a, 12Mar13, sen dervied from reference solution. for RIL.

--[[
 * DESCRIPTION
 * Describe the routines to glue GUI page with component lua management code.
 * The operations that require accessing other components mgmt code or
 * database access will be implemented here.
--]]

--List of includes
require "teamf1lualib/db"
require "teamf1lualib/userdb"

DB_FILE_NAME="/tmp/system.db"

gui= {} -- This should be before the includes below

gui.debug = 0
gui.console_debug = 0
gui.web_debug = 0

if (gui.web_debug == 1) then
    util.setDebugStatus(true)
end

require "teamf1lualib/status"
require "teamf1lualib/administration"
require "teamf1lualib/networking"
require "teamf1lualib/security"
--require "teamf1lualib/voipSettings"
-- USe PCALL so that no error thrown if file are not present
pcall (require, "teamf1lualib/full_cone_nat")
pcall (require, "teamf1lualib/wireless")
pcall (require, "teamf1lualib/qosconf")
pcall (require, "teamf1lualib/diskconf")
require "teamf1lualib/debug"

function gui.dprintf(msg)

    if (gui.debug == 0) then
        return
    end

    if (msg) then

        msg = msg .. "<br>"

        if (gui.web_debug == 1) then
            util.appendDebugOut(msg)
        end

        if (gui.console_debug == 1) then
            print(msg)
        end
    end
end

function gui.makeTableWithPrefix (table, prefix)
    local newtab = {}
  	for k, v in pairs (table) do
        if (string.find(k, prefix) ~= nil) then
            newkey = string.gsub (k, prefix, "")
		    newtab[newkey] = v
        end            
  	end
    return newtab
end

