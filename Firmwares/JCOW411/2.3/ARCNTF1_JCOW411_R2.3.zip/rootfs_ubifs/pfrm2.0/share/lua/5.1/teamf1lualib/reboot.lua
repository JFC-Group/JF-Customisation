--[[
#### reboot.lua - lua file for reboot component

#### Copyright (c) 2014, TeamF1 Networks Pvt. Ltd.
#### (Subsidiary of D-Link India)

#### Revisions:
01a 18nov14 tbp written
]]--


require "rebootLib"

reboot = {}

function reboot.rebootConfig(count)
    require "teamf1lualib/firmware"
    firmware.voipCleanUp()
    -- calling reboot api in rebootLuaLib.c file
    rebootLib.reboot (count)
    if( util.fileExists("/pfrm2.0/HW_HG260ES") or util.fileExists("/pfrm2.0/HW_HG260X")) then
        os.execute("/bin/ledctl WLAN off")
        os.execute("/bin/ledctl WPS off")
    end
    return "OK"
end
