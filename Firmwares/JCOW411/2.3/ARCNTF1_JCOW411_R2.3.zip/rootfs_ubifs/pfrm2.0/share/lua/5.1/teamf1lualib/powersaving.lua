--[[
#### Venu babu.
#### TeamF1
#### www.TeamF1.com
#### Dec 14, 2009
#### File: powersaving.lua
#### Description: powersaving functions
#### Revisions:
]]--

--************* Initial Code *************

--package powersaving
powersaving = {}

--************* Functions *************
-- powersaving config


function powersaving.ps_config (inputTable, rowid, operation)
	-- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end
	db.beginTransaction() --begin transaction
	local valid = false

   	valid = powersaving.config(inputTable, rowid, operation)
	
	-- return
	if (valid) then
		db.commitTransaction(true)
	    return "OK", "STATUS_OK"            
	else
		db.rollback()
		return "ERROR", "POWERSAVING_CONFIG_FAILED"
	end
end

function powersaving.config (inputTable, rowid, operation)
    -- validate
    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
            return db.insert("PowerModeConf", inputTable)
        elseif (operation == "edit") then
            return db.update("PowerModeConf", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("PowerModeConf", inputTable)
        end
    end
    return false
end


