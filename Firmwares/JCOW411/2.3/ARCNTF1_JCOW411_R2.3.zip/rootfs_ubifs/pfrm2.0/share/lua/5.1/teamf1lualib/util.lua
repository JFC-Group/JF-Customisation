--[[
#### Adarsh Uppula
#### TeamF1
#### www.TeamF1.com
#### June 29, 2007

#### File: util.lua
#### Description: Utility (common) functions.

#### Revisions:
01e,25Apr18,swr  changes for SPR 63567(added proper checks for reboot for firmware upgrade case)
01d,11mar10,pnm  added util.stripLRSpaces function
01c,18feb10,pnm  added util.verifyLen function
01b,23Sep08,shv  added new function to get month number from month name
01a,17Apr08,shv  sending enpty string instead of "..." in case of
                 empty IP Address joing in joinFields function
]]--


--************* Requires *************
require "timeLib"
require "platformLib"

--************* Initial Code *************

-- package util
util = {}

-- global variables
_DEBUG_STATUS = false
_DEBUG_OUTPUT = "<br>"
_OUTPUT_STATUS = false
_OUTPUT = "<br>"

local processList = "dms mpe_server vsftpd ras"
local processList2 = "hgw-voice-app"
local processList3 = "nscand mcpd hgw-voice-app captivePortald qosMain dnsmasq radvd wide-dhcp6s linkMonitord crond slaacd ifDevd timeD firewalld ntpd radEap loggingd lua dhcpcConfig igmpproxy appd"
local forwardTrafficDropCmd = "/pfrm2.0/bin/iptables -w -I FORWARD -j DROP > /dev/null 2>&1"
local cacheFreeCmd = "/bin/sync && /bin/echo 3 > /proc/sys/vm/drop_caches"

--************* Functions *************

-- Toggle debugging.
function util.setDebugStatus (onoff)
	_DEBUG_STATUS = onoff
end

-- Get debugging status.
function util.getDebugStatus ()
	return _DEBUG_STATUS
end

-- Append debugging.
function util.appendDebugOut (stuff)
	if _DEBUG_STATUS then
		_DEBUG_OUTPUT = _DEBUG_OUTPUT .. stuff
	end
end

-- Get debugging.
function util.getDebugOut ()
	return _DEBUG_OUTPUT
end

-- Toggle output.
function util.setOutputStatus (onoff)
	_OUTPUT_STATUS = onoff
end

-- Get output status.
function util.getOutputStatus ()
	return _OUTPUT_STATUS
end

-- Append output.
function util.appendOut (stuff)
	if _OUTPUT_STATUS then
		_OUTPUT = _OUTPUT .. stuff
	end
end

-- Get output.
function util.getOut ()
	return _OUTPUT
end

-- Read file and return as string.
function util.fileToString (filename)
	local filep = io.open(filename, "r")
	if (filep == nil) then
		return nil
	end
	return filep:read("*all")
end

-- Check if file exists.
function util.fileExists(filename)
	local filep = io.open(filename)
	if filep then
		io.close(filep)
		return true
	else
		return false
	end
end

-- Convert the table to a string.
function util.tableToString (table)
	if (table == nil) then return "Nil table!" end
	local toReturn = "----- Table: -----<br>"
	for k,v in pairs(table) do
		toReturn = toReturn .. "Key = " .. k .. ", Value = " .. v .. "<br>"
	end
	return toReturn .. "----------------------<br>"
end

-- Convert the table recursively to a string.
function util.tableToStringRec (t, indent)
	if (table == nil) then return "Nil table!" end
	return "----- Recusive Table: -----<br>" .. util.tableToStringRecHelper(t, indent) .. "-------------------------------------<br>"
end

-- Helper - Convert the table recursively to a string.
function util.tableToStringRecHelper (t, indent)
	local toReturn = ""
	local indent = indent or ''
	for key,value in pairs(t) do
    	toReturn = toReturn .. indent .. '[' .. tostring(key) .. ']' 
    	if type(value)=="table" then toReturn = toReturn .. ':\n<br>' .. util.tableToStringRecHelper(value, indent .. '&nbsp&nbsp&nbsp')
    	else toReturn = toReturn .. ' = ' .. tostring(value) .. '\n<br>' end
  	end
	return toReturn
end

-- Return table1 - table2 (subtract all from table1 whose
-- values are not in table2).
function util.tableSubtract (table1, table2)
	if (table1 == nil) then return nil end
	if (table2 == nil) then return table1 end
	
	local result = util.filterTable(table1,
		function (v)
			for key, value in pairs(table2) do
         		if v == value then
         			return false
         		end
      		end
      		return true
      	end
	)
	return result
end

-- Generic table filter function. Filter table with given
-- boolean fucntion.
function util.filterTable (t, f)
	assert (type (t) == "table")
	assert (type (f) == "function")
	local k, v
	local result = {}
	for k, v in ipairs (t) do
    	if f (v) then
			table.insert(result, v)
		end -- if
  	end -- for
  	return result
end -- filtertable

-- Return new table table1 + table2 (add tables).
-- Overlapping keys will only have one entry.
function util.tableAdd (table1, table2)
	local result = {}
	for k, v in pairs (table1) do
		result[k] = v
  	end
  	for k, v in pairs (table2) do
		result[k] = v
  	end
	return result
end

-- Append table2 to table1 (append tables).
-- Overlapping keys will only have one entry.
function util.tableAppend (table1, table2)
	if (table1 == nil or table2 == nil) then return table1 end
  	for k, v in pairs (table2) do
		table1[k] = v
  	end
	return table1
end

-- Split string with divider and return table of parts.
function util.split (str, div)
    if (div=='') then return false end
    local pos,arr = 0,{}
    -- for each divider found
    for st,sp in function() return string.find(str,div,pos,true) end do
	    table.insert(arr,string.sub(str,pos,st-1)) -- Attach chars left of current divider
	    pos = sp + 1 -- Jump past current divider
    end
    table.insert(arr,string.sub(str,pos)) -- Attach chars right of last divider
    return arr
end

-- prefix the given str in the key
function util.addPrefix (table, prefix)
    local newtab = {}
  	for k, v in pairs (table) do
		newtab[prefix .. k] = v
  	end
    return newtab
end

-- remove prefix the given str in the key
function util.removePrefix (table, prefix)
    local newtab = {}
  	for k, v in pairs (table) do
        newkey = string.gsub (k, prefix, "")
		newtab[newkey] = v
  	end
    return newtab
end


-- Join table of parts with divider and return string.
function util.join (intable, div)
    if (not intable) then return "" end
    local str = {}
    -- make string
    for k, v in pairs (intable) do
    	if (k >= 2) then
			str = str .. div .. v
		else
			str = v
		end
  	end
  	return str
end

-- Returns table with entries from given table
-- where key's firstPart matches.
-- Returns nil if none found or error.
function util.tableSplit (table, div, firstPart)
	local splitted = {}
	local toReturn = {}
	for k,v in pairs(table) do
		splitted = util.split(k, div)
		if (#splitted == 2 and splitted[1] == firstPart) then
			toReturn[splitted[1] .. "." .. splitted[2]] = v
		end
	end
	if util.tableSize(toReturn) > 0 then
		return toReturn
	else
		return {}
	end
end

-- Search for given key in table. If matched, returns true.
function util.tableKeyExists (table, key)
	local toReturn = false
	for k,v in pairs(table) do
		if (k == key) then
			return true
		end
	end
	return toReturn
end

-- Search for given value in table. If matched, returns key, else nil.
function util.keyTableValueExists (table, value)
	local toReturn = false
	for k,v in pairs(table) do
		if (v == value) then
			return k
		end
	end
	return nil
end

-- Get size of table.
function util.tableSize (table)
	--if nil
	if table == nil then return nil end
	local i = 0
	for k,v in pairs(table) do
		i = i + 1
	end
	return i
end

-- Iterator that returns pairs in table sorted by keys.
function util.pairsByKeys (t, f)
	local a = {}
    for n in pairs(t) do table.insert(a, n) end
	table.sort(a, f)
	local i = 0      -- iterator variable
	local iter = function ()   -- iterator function
    	i = i + 1
    	if a[i] == nil then return nil
    	else return a[i], t[a[i]]
    	end
    end
    return iter
end

-- Return lua variable with given name in the global environment 
-- (does not use lexical scoping).
function util.getLuaVariable (varname)
	local f = loadstring("return " .. varname)
	return f()
end

-- Copy given file to other file.
function util.copyFile (fileHandle, filename)
	local BUFSIZE = 2^13 -- 8 KB
	local chunk = ""
	local fp = io.open(filename, "wb")
	
	while (true) do
		chunk = fileHandle:read(BUFSIZE)
		if not chunk then break end
		assert(fp:write(chunk))
		assert(fp:flush())
	end
	-- close handles
	fp:close()
	fileHandle:close()
end

-- Get system time in a default format.
function util.time ()
	return os.date("%A, %B %d, %Y, %X (GMT %z)")
end

-- Get system time and date.
-- Returns array of time and date info.
function util.date ()
	local info = {}
	info["month"] = os.date("%m")
	info["date"] = os.date("%d")
	info["year"] = os.date("%Y")
	info["hours"] = os.date("%H")
	info["minutes"] = os.date("%M")
	info["seconds"] = os.date("%S")
	return info
end

-- Get system up time.
function util.uptime (uptime)
    if (uptime == nil) then
        status,uptime = timeLib.uptime()
    end
    local mins = math.floor(uptime / 60)
	local sec = uptime % 60
    local hours = math.floor (mins / 60)
    mins = mins % 60
	local days = math.floor (hours / 24)
    hours = hours % 24
	uptime = days .. " days, " .. hours .. " hours, " .. mins .. " minutes, " .. sec .. " seconds"
	return uptime
end

-- Returns an array of bits (0 or 1 integer) based on integer (base 10) value.
-- First entry in array is the least significant bit (LSB), last is MSB.
-- Ex: integer 15 would return {1,1,1,1}, integer 10 would return {0,1,0,1}
function util.integerToBits (number)
	local toReturn = {}
	local remainder = 0
	local quotient = -1
	
	while (quotient ~= 0) do
		quotient = math.floor(number / 2)
		remainder = number % 2
		number = quotient
		table.insert(toReturn, remainder)
	end
	
	-- return
	return toReturn
end

-- Returns array of values in given input table that are keyed by <tablename><div><fieldname><i>
-- where i ranges from 1 to length using the given divider.
function util.getPartialArray (fulltable, tablename, fieldname, div, length)
	local toReturn = {}
	local i = 1
	
	while (i <= length) do
		table.insert(toReturn, fulltable[tablename .. div .. fieldname .. i]) 
		i = i + 1
	end
	return toReturn
end

-- Join the values in given input table that are keyed by <tablename><div><fieldname><i>
-- where i ranges from 1 to length using the given divider.
function util.joinFields (table, tablename, fieldname, div, length)
	local toReturn = ""
	local i = 1
	
	while (i <= length) do
		toReturn = toReturn .. table[tablename .. div .. fieldname .. i] .. div 
		i = i + 1
	end
	toReturn = toReturn:sub(1, toReturn:len()-div:len()) --shave last dot

    if (toReturn == "...") then
        toReturn = ""
    end

	return toReturn
end

-- Join the bit values in given input table that are keyed by <tablename><div><fieldname><i>
-- where i ranges from 1 to length using the given divider.
-- -reverse- dictates that first index should be LSB, not MSB.
function util.joinBitFields (table, tablename, fieldname, div, length, reverse)
	local binaryArray = util.getPartialArray(table, tablename, fieldname, div, length)
	local binaryString = ""
	
	if (reverse) then
		local i = length
		while (i >= 1) do
			binaryString = binaryString .. binaryArray[i]
			i = i - 1
		end
	else
		local i = 1
		while (i <= length) do
			binaryString = binaryString .. binaryArray[i]
			i = i + 1
		end
	end
	return tonumber(binaryString, 2) --to binary
end

-- 
-- 
-- Convert ASCII string to integer
-- ToDo: Add check for largest and smallest int
function util.atoi (str)
    local len = string.len (str)
    local intVal = 0
    local idx = 0
    local startIdx = 1
    
    if (string.byte (str, 1) == 45) then
        startIdx = 2
        base = math.pow (10, len-2)
    else
        startIdx = 1
        base = math.pow (10, len-1)
    end

    for idx = startIdx,len do
        local byteVal = string.byte (str, idx)
        if byteVal >= 48 and byteVal <= 58 then
            byteVal = byteVal - string.byte ("0", 1)
            intVal = intVal + base * byteVal
            base = base/10
        else
            return -1, 0
        end
    end
    if startIdx == 2 then intVal = intVal * -1 end
    return 0, intVal
end

-- Mask Password/Secret 
function util.mask (str)
    local len = string.len (str)
    local startIdx = 1
    local maskString = ""

    for idx = startIdx,len do
        maskString = maskString .. "*"
    end

    return maskString
end

-- Check for all '*' in  Password/Secret fields
function util.isAllMasked (str)
    if (str == "") then
        return false
    end
    local maskedStr = util.mask (str)
    local allMasked = true

    if (str ~= maskedStr) then
        allMasked = false
    end

    return allMasked
end

function util.splitDateTime(str)
    local dateTime = {}
    local strSplit  = util.split(str, "@")
    local date = util.split(strSplit[1], "/")
    dateTime[1] = date[2]
    dateTime[2] = date[3]
    dateTime[3] = date[1]
    local time = util.split(strSplit[2], ":")
    dateTime[4] = time[1]
    dateTime[5] = time[2]
    dateTime[6] = time[3]
    return dateTime
end

function util.getMonthNum (month)
    if (month == nil) then
        return 0
    elseif (month == "Jan") then
        return 1
    elseif (month == "Feb") then
        return 2
    elseif (month == "Mar") then
        return 3
    elseif (month == "Apr") then
        return 4
    elseif (month == "May") then
        return 5
    elseif (month == "Jun") then
        return 6
    elseif (month == "Jul") then
        return 7
    elseif (month == "Aug") then
        return 8
    elseif (month == "Sep") then
        return 9
    elseif (month == "Oct") then
        return 10
    elseif (month == "Nov") then
        return 11
    elseif (month == "Dec") then
        return 12
    else
        return 0
    end
end

function util.tableCopy( self, deep, ud_copy_fn )

    ud_copy_fn = ud_copy_fn or function ( ud ) return ud end

    local new_table = {}

    for key, value in pairs(self) do

        local new_key
        if ( deep and type( key ) == 'table' ) then
            new_key = util.tableCopy( key, deep, ud_copy_fn )
        elseif ( type( key ) == 'userdata' ) then
            new_key = ud_copy_fn( key )
        else
            new_key = key
        end

        local new_value
        if ( deep and type( value ) == 'table' ) then
            new_value = util.tableCopy( value, deep, ud_copy_fn )
        elseif ( type( value ) == 'userdata' ) then
            new_value = ud_copy_fn( value )
        else
            new_value = value
        end

        new_table[ new_key ] = new_value
    end

    return new_table
end

--[[
--*****************************************************************************
--util.verifyLength - verifies the length of given string
--
--This function verifies if the length of the string is between the min and
--max values provided.
--
--RETURNS - true - if the string length is between the min and max
--          false - otherwise
]]--
function util.verifyLength (str, minLen, maxLen)
    local retVal = true
    -- Get the len of the string
    local len = string.len (str)

    -- check if extracted length is greater or less than expected length
    if (len < minLen or len > maxLen)
    then
        retVal = false
    end

    return retVal
end

--[[
--*****************************************************************************
--util.hasAnyFieldChanged - has any field in the table changed
--
-- This function checks if any field in the table has changed.
--
--RETURNS - 
--	1 -  some value has changed
--	0 -  no value has changed 
--  -1 - internal error (database busy or row not found)
]]--

function util.hasAnyFieldChanged (tablename, tableInput, rowId)
	local fieldsSetString = ""
	local query = "_ROWID_=" .. rowId

	-- get old values
	local oldValues = db.getRowWhere(tablename, query, false)
	if (oldValues == nil) then
		return -1
	end

	-- get col names
	local allKeys = db.getColNames(tablename)

	for k,v in pairs(tableInput) do
		local splitparts = util.split(k, ".")
		-- if the column actually exists
		if (#splitparts == 2 and splitparts[1] == tablename and util.keyTableValueExists(allKeys, splitparts[2])) then
			local field = splitparts[2]
			-- check if field changed
			if (field == "objRevId") then
			   fieldsSetString = fieldsSetString..field.."=\'"..v+1
			   fieldsSetString = fieldsSetString.."\', "
			elseif (oldValues[field] ~= v) then
			    fieldsSetString = fieldsSetString .. splitparts[2] .. " = \'" .. v .. "\', "
    		end
        end
	end
	
	if (fieldsSetString ~= "") then
		return 1;
	else
		return 0;
	end
end

--[[
--*****************************************************************************
--util.stripLRSpaces - strips the leading and trailing spaces
--
--This function strips the leading and trailing spaces on the given string.
--
--RETURNS - new string
]]--
function util.stripLRSpaces (str)
    if (str == nil) then
        return str
    end
    return string.gsub (str, "^%s*(.-)%s*$", "%1")
end

--[[
--*****************************************************************************
--util.getHelp - returns help text for a specified page.
--
--This function returns help text for a specified page from a help text file.
--
--RETURNS - new string
]]--
function util.getHelp (pageTag, sectionTag, helpFileName)
    local helpText = "Text"
    local fp = assert(io.open("help/en_US/"..helpFileName, "r"))
    local data = ""
    while true do
    	local line = fp:read("*line")
    	if line == nil then break end
    	data = data .. line
    end
    assert(fp:close())

    local mainHedSt1,mainHeadEnd1 = string.find(data, "<h1>")
    local mainHedSt2,mainHeadEnd2 = string.find(data, "<\/h1>")
    if (mainHedSt1 ~= nil and mainHedSt2 ~= nil and mainHeadEnd1 ~= nil and mainHeadEnd2 ~= nil) then
    	mainHeading = string.sub(data, mainHeadEnd1+1, mainHedSt2-1)
    else
    	mainHeading = ""    
    end
 
    local helpStart1,helpEnd1 = string.find(data, ":|" .. pageTag .. "|:")
    local helpStart2,helpEnd2 = string.find(data, ":|".. pageTag .. "End|:")
    if (helpStart1 ~= nil and helpEnd1 ~= nil and helpStart2 ~= nil and helpEnd2 ~= nil) then
        helpText = string.sub(data, helpEnd1+1, helpStart2-1)
    else
    	helpText = ""
    end

    helpStart1,helpEnd1 = string.find(helpText, ":|" .. sectionTag .. "|:")
    helpStart2,helpEnd2 = string.find(helpText, ":|".. sectionTag .. "End|:")
    if (helpStart1 ~= nil and helpEnd1 ~= nil and helpStart2 ~= nil and helpEnd2 ~= nil) then
        helpText = string.sub(helpText, helpEnd1+1, helpStart2-1)
        -- Removeing <br> at starting of the help text
        helpStart1,helpEnd1 = string.find(helpText, "<br>")
        if (helpStart1 ~= nil and helpStart1 == 1) then
            helpText = string.sub(helpText, helpStart1+4)
        end
    else
    	helpText = ""
    end

    return helpText
end

-- User can inject sub commands inside original command string
-- using ; or `` or $() or | or &
-- And redirectors like > and < can cause damage by consuming space, etc..
-- eg: ping x;reboot   ping x`reboot`   ping x$(reboot)   ping x&reboot
--     ping x|reboot   ping x>somefile  ping x<somefile
--
-- Removes shell special characters from the command and parameters.
-- 'options' parameter is passed to shell without checking. So ensure that
-- no user-input is present in it.
-- Returns exit code of the command executed.
function util.runShellCmd(command, outputFile, errorFile, options)

    local charsToReplace = ";`$&|><"

    command = string.gsub(command, "[" .. charsToReplace .. "]", "")

    if (options) then
        command = command .. " " .. options
	end

    if (outputFile) then
        command = command .. " >" .. string.gsub(outputFile, "[" .. charsToReplace .. "]", "")
    end

    if (errorFile) then
        command = command .. " 2>" .. string.gsub(errorFile, "[" .. charsToReplace .. "]", "")
    end

    return os.execute (command)
end

-- Removes shell special characters from the command and parameters.
-- 'options' parameter is passed to shell without checking. So ensure that
-- no user-input is present in it.
-- Returns output of the command executed.
function util.shellCmdOutput(command, options)

    local charsToReplace = ";`$&|><"

    command = string.gsub(command, "[" .. charsToReplace .. "]", "")

    if (options) then
        command = command .. " " .. options
	end

   local pipe = io.popen(command .. " 2>&1") -- redirect stderr to stdout
   local cmdOutput = pipe:read("*a")
   pipe:close()
   return cmdOutput
end

--*****************************************************************************
-- util.cpuValidation () 
--
-- This routine validate the cpuusage invalid values.
--
-- RETURNS: True if value find to be invalid

function util.cpuValidation (cpuUsage)
	
	if(cpuUsage == nil or tonumber(cpuUsage) == nil or tonumber(cpuUsage) < 0 or tonumber(cpuUsage) > 100) then
		return false
	else 
		return true
	end
end

--*****************************************************************************
-- util.MemoryValidation () 
--
-- This routine validate the mememory usage invalid values.
--
-- RETURNS: True if value find to be invalid

function util.MemoryValidation (usedMem,totalMem) 
	
	if (usedMem == nil or totalMem == nil or (tonumber(usedMem)) == nil or (tonumber(totalMem)) == nil or (tonumber(usedMem)) < 0 or (tonumber(totalMem)) == 0) then
		return false
	else 
		return true
	end
end

--*****************************************************************************
-- util.DiskValidation () 
--
-- This routine validate the diskusage invalid values.
--
-- RETURNS: True if value find to be invalid

function util.DiskValidation (diskUsedinMB,diskTotalinMB) 
	
	if (diskUsedinMB == nil or diskTotalinMB == nil or diskUsedinMB < 0 or diskTotalinMB < 0) then
		return false
	else 
		return true
	end
end

--*****************************************************************************
-- util.percentageValidation () 
--
-- This routine validate the percentage values.
--
-- RETURNS: True if value find to be greater then 100

function util.percentageValidation (percentage) 
	
	if(percentage > 100) then
		return false
	else
		return true
	end
end

-- check for the valid cookie 
function util.cookieValidate (cookieVal)
    -- Check any unwant symbole in cookieVal instead of digits [0-9]
    -- and aplabets [a-f]
    if (string.match(cookieVal,'^[0-9a-f]+$') == nil) then
        return 1
    end
    return 0
end

----------------------------------------------------------------------
-- @name util.freeMemCheck ()
--
-- @description This function checks the available free Memory in system .
--
-- @return  "YES" on SUCCESS
--          "NO",  on FAILURE
----------------------------------------------------------------------
function util.freeMemCheck ()

    local status = "YES"
    local psKilledStatus = "NO"
    local freeMem = nil
	-- Need atleast 65 MB free because image size + min_free_kbytes + 2 MB headroom = ~50 + 4 + 2 MB )
	local minFree = 66560

	if (util.fileExists ("/pfrm2.0/HW_HG261GU")) then
		minFree = 35840
	end

    
    -- Getting the available free Memory in system
    status, freeMem = util.freeMemGet ()
    -- Checking if free memory is lessthan 64 MB in System
    if (freeMem ~= nil and tonumber (freeMem) < minFree) then
		-- free up memory
		util.freeUpMemory ()
        psKilledStatus = "YES"

        status, freeMem = util.freeMemGet ()
        -- Checking if free memory is lessthan 64 MB in System
        if (freeMem ~= nil and tonumber(freeMem) < minFree) then
            status = "NO"
        end
    end
    
    -- return 
    return status, psKilledStatus
end

----------------------------------------------------------------------
-- @name util.freeUpMemory ()
--
-- @description This function frees up memory by killed memory hogging process
--
-- @return
-- 
----------------------------------------------------------------------

function util.freeUpMemory ()

	local cmd = "/usr/bin/killall -q -9 " .. processList
	os.execute (cmd)

	if (util.fileExists ("/pfrm2.0/BRCMJCO300")) then

		if (util.fileExists ("/pfrm2.0/HW_HG261GU")) then
		cmd = "/usr/bin/killall -q -9 " .. processList3
		else
		cmd = "/usr/bin/killall -q -9 " .. processList2
		end
		os.execute (cmd)
		os.execute (cmd)
	end
	os.execute (forwardTrafficDropCmd)
	os.execute (cacheFreeCmd)
	
end



----------------------------------------------------------------------
-- @name util.freeMemGet ()
--
-- @description This function gives the available free Memory in system .
--
-- @return  "YES"  on SUCCESS
--          "NO",  on FAILURE
----------------------------------------------------------------------
function util.freeMemGet ()
    
    local status  = "YES"
    local freeMem = nil
    local command = "/usr/bin/free|awk NR==2'{print $4}'"
    local contents

    -- Executing coommand and opening the file
    local file = assert(io.popen(command))
    if (file) then
        while true do
            contents = file:read("*line")
            if contents == nil then break end
            freeMem = contents
        end
        file:close()
    else
        status = "NO"
    end

    -- return
    return status, freeMem
end
----------------------------------------------------------------------
-- @name util.timeConversion ()
--
-- @description This function converts sec to xx days,xx hours, xx mins, xx secs.
--
-- @return  xx days,xx hours, xx mins, xx secs  on SUCCESS
--          "N/A",                              on FAILURE
----------------------------------------------------------------------
function util.timeConversion (secs)
    --locals
    local time = "N/A"

    if(secs ~= nil and secs ~= '' and secs ~= " " and tonumber(secs) > 0) then
        local mins = math.floor(tonumber(secs) / 60)
        local sec = tonumber(secs) % 60
        local hours = math.floor (mins / 60)
        mins = mins % 60
        local days = math.floor (hours / 24)
        hours = hours % 24
        time = days .. " days, " .. hours .. " hours, " .. mins .. " minutes, " .. sec .. " seconds"
    end

    return time
end

local xssCharacters = {}
xssCharacters ["<"] = "&lt;"
xssCharacters [">"] = "&gt;"
xssCharacters ["\""] = "&quot;"
xssCharacters ["&"] = "&amp;"



function util.filterXSSChars (value)

	if (value == nil) then return nil end

	for i,j in pairs (xssCharacters) do
	value=string.gsub(value,i,j)
	end
	return value

end

----------------------------------------------------------------------
-- @name util.fileAppend ()
--
-- @description This function converts append string into file and append new
--              line in the end
--
-- @return  
----------------------------------------------------------------------
function util.fileAppend(fileName, string)
    filp = io.open (fileName, "a")
    if (filp)then
        filp:write(string)
        filp:write("\n")
        filp:close()
    end
    
end
----------------------------------------------------------------------
-- @name util.validPasswordCheck ()
--
-- @description This function checks the given password characters are
--              ascii characters or not 
--
-- @return  
----------------------------------------------------------------------
function util.validPasswordCheck(password)
	
    --password nil check 
    if(password == nil) then
        return "ERROR" , "PASSWORD should not be nil"
    end

    --Ascii chars check
    if (string.match (password, "[^\001-\127]") ~= nil) then
        return "ERROR" , "PASSWORD contain non ASCII Charaters"
    end

   --Special character check which are not allowed in password
    if (string.match (password, "^[^\"\'|;%s]*$") == nil) then
        return "ERROR", "Password should not contain space \"  | ; \' chars"
    end	
 
end    
