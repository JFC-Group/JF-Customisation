--[[
#### Hussain Vali.
#### TeamF1
#### www.TeamF1.com
#### April 01, 2008
#### File: igmp.lua
#### Description: IGMP Proxy Setup functions
#### Revisions:
]]--

--************* Requires *************

--************* Initial Code *************

--package IGMP Proxy Configurations
igmp = {}
igmp.events = {}

--************* Functions *************

-- IGMP Proxy config
function igmp.config (inputTable, rowid, operation)
    -- validate
    local valid = false
    if (ACCESS_LEVEL ~= 0) then
	return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
            return nil
        elseif (operation == "edit") then
            valid = db.update("Igmp", inputTable, rowid)
	    -- return
    	    if (valid) then
        	db.commitTransaction()
        	return "OK", "STATUS_OK"
            else
        	db.rollback()
        	return "ERROR", "IGMP_CONFIG_FAILED"
            end
        elseif (operation == "delete") then
            return nil
        end
    end
    return false
end

-- Delete Allowed Networks
function igmp.deleteAllowedNetwork (rowIds)

	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end

	db.beginTransaction() --begin transactions
    local valid = true
    local errStr = "STATUS_OK"

    for k,v in pairs(rowIds) do
        local inTable = {}
        inTable["allowedNets._ROWID_"] = v;
        valid = igmp.networkConfig(inTable, "-1", "delete", "allowedNets")
        if (valid == false) then
            errStr = "IGMP_NETWORK_DELETE_FAILED"
            break
        end
    end

    if (valid ~= false) then
        errStr = "STATUS_OK"
    end

	-- return
	if (valid) then
		db.commitTransaction(true)
        require "teamf1lualib/service"
        service.restart("igmp","1")
		return "OK", errStr
	else
		db.rollback()
		return "ERROR", errStr
	end
end

--  Allowed Networks Configuration
function igmp.allowedNetworkConfig (inputTable, rowid, operation)
	-- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end
	db.beginTransaction() --begin transaction
	local valid = false

   	valid = igmp.networkConfig(inputTable, rowid, operation, "allowedNets")
	
	-- return
	if (valid) then
		db.commitTransaction(true)
        require "teamf1lualib/service"
        service.restart("igmp","1")
	    return "OK", "STATUS_OK"            
	else
		db.rollback()
		return "ERROR", "ALLOWED_NETWORK_CONFIG_FAILED"
	end
end

-- Igmp Allowed Network Config
function igmp.networkConfig (inputTable, rowid, operation, DBTable)
    
    if (operation == "add") then
        return db.insert(DBTable, inputTable)
    elseif (operation == "edit") then
        return db.update(DBTable, inputTable, rowid)
    elseif (operation == "delete") then
        return db.delete(DBTable, inputTable)
    end
    
    return false
end

-------------------------------------------------------------------------------
-- @name igmp.import
--
-- @description 
--
-- @return 
--
function igmp.import (inputTable, defaultCfg, remCfg)
    if (inputTable == nil) then
        inputTable = defaultCfg
    end

    --initializing a temp table
    local configTable = {}

    if (inputTable ~= nil) then
        configTable = config.update (inputTable.Igmp, defaultCfg.Igmp, remCfg.snmp)
    
        if (configTable ~= nil and #configTable ~= 0) then
            for i,v in ipairs (configTable) do
                v = util.addPrefix (v, "Igmp.");
				if  util.fileExists ("/flash/configMerge/igmpProxyEnabled3") then
					print ("Igmp one time enabling done already")
				else
					print ("Enforce one time enabling of igmp proxy")
					v["Igmp.IgmpEnable"] = "1"
					local igmpProxyEnabled = io.open("/flash/configMerge/igmpProxyEnabled3", "w")                                                          
            		if(igmpProxyEnabled ~= nil) then                                                                       
            			igmpProxyEnabled:close()
            		end				
				end
                igmp.networkConfig (v, -1, "add", "Igmp");
            end
        end
    end

    if (inputTable ~= nil) then
        configTable = config.update (inputTable.allowedNets, defaultCfg.allowedNets, remCfg.allowedNets)
        if (configTable ~= nil and #configTable ~= 0) then
            for i,v in ipairs (configTable) do	
                v = util.addPrefix (v, "allowedNets.");
                igmp.networkConfig (v, -1, "add", "allowedNets");
            end
        end
    end
end


-------------------------------------------------------------------------------
-- @name igmp.export
--
-- @description 
--
-- @return 
--
function igmp.export ()
    local table = {}
    table["Igmp"] =  db.getTable ("Igmp", false)
    table["allowedNets"] =  db.getTable ("allowedNets", false)
    return table
end

if (config.register) then
   config.register("igmp", igmp.import, igmp.export, "2")
end

--[[
*******************************************************************************
-- @name igmp.dprintf
--
-- @description 
--
-- @param 
--
-- @return 
--
--]]

function igmp.dprintf(str)
    if (str == nil) then
        return
    end

    if (igmp.debug == 1) then
        print ("IGMP: " .. str)
        return
    end        

    if ((gui ~= nil) and (gui.debug == 1)) then
        igmp.dprintf ("igmp: "  .. str .. "<br>")
    end        

    return 
end
