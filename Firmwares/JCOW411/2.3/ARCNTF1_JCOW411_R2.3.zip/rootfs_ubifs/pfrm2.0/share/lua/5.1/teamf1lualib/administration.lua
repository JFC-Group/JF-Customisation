-- gui.administration.lua - lua wrapper calls for administration of Staging Firmware

-- Copywrite (c) 2013-2014 TeamF1, Inc.
--
--Copyright (c) 2013-2015, TeamF1 Networks Pvt. Ltd.
--(Subsidiary of D-Link India)
--
-- modification history
-- --------------------
-- 01o, 30Apr18, swr changes for SPR 63842(cp new third party tmp.param file to flash)
-- 01n, 23Nov17, swr changes for spr 62635(XSS vulnerability) and 61441
-- 01m, 29Aug17, sjr changes for WIFI optimization
-- 01l, 24Aug17, sjr changes for #61523
-- 01k, 04Dec15, ash changes for force password change after reset
-- 01j, 16Jan15, swr commenting out support for UpgradesManaged
-- 01i, 08Jan15, rsr changes for SQL injection prevention
-- 01h, 02dec14, mmk Added routing, system and IPv6 Logs support.
-- 01g, 31Oct14, swr changes for UpgradesManaged
-- 01f, 14Oct14, adk changes for SPR#47150
-- 01e, 24sep14, mmk Added fwRuleScript.lua to manage firewall rules
-- 01d, 23Apr14, vik changes for SPR#43245
-- 01d, 25Sep13, ash changes for SPR#40244
-- 01c, 25Sep13, ash changes for SPR#40247
-- 01b, 16jul13, ash added support for captive portal
-- 01a, 12Mar13, sen dervied from reference solution. for RIL
--

---------------------------------------------------------------------------------
-- The routines in this lua wrapper are called by htm(user interface) layer to
-- get & set the information for Download & Upgrade
---------------------------------------------------------------------------------
gui.administration = {}
--[[Download & Upgrade]]--
--Download & Upgrade
gui.administration.upgrade = {}

gui.administration.users = {}
gui.administration.users.add = {}
gui.administration.users.edit = {}

gui.administration.groups = {}
gui.administration.groups.add = {}
gui.administration.groups.edit = {}

--[[ Firmware Settings ]]--
gui.administration.firmware = {}
--Upgrade
gui.administration.firmware.upgrade = {}
-- Backup and restore
gui.administration.firmware.cfg = {}
-- USB --
gui.administration.firmware.usb = {}
-- USB upgrade--
gui.administration.firmware.usb.upgrade = {}
-- USB restore
gui.administration.firmware.usb.cfg = {}
--[[ SSH Settings ]]--
--SSH Setup
gui.administration.ssh = {}

--[[ Logging Settings ]]--
--Remote SysLog Setup
gui.administration.remote_logging = {}

--[[ System Time Settings ]]--
gui.administration.time = {}

--[[ Schedules ]]--
gui.administration.schedules = {}
gui.administration.schedules.helpers = {}
gui.administration.schedules.add = {}
gui.administration.schedules.edit = {}

--[[ Discovery Settings ]]--
--UPnP / Bonjour
gui.administration.discovery = {}

-- tr69 configuration
gui.administration.tr069Configuration = {}
gui.administration.tr069ThirdPartyConfiguration = {}

-- tftp management
gui.administration.tftpMgmt = {}

-- remote mgmt
gui.administration.remoteMgmt = {}
gui.administration.lan = {}
gui.administration.lan.remoteMgmt = {}

-- [[Snmp Settings]]--
-- Snmp Setup
gui.administration.snmp = {}
-- System Information
gui.administration.systemInfo = {}

-- [[Igmp proxy Settings]]--
-- Igmp Proxy Configuration
gui.administration.igmp = {}
gui.administration.igmp.allowedNets = {}
gui.administration.igmp.allowedNets.add = {}
gui.administration.igmp.allowedNets.edit = {}

--[[RadiusClient Settings]]--
gui.administration.radiusClient = {}
gui.administration.radiusDas = {}

--[[Captive Portal Settings]] --
--captive Portal Setup
gui.administration.captivePortal = {}
gui.administration.captivePortal.captivePortalProfiles = {}
gui.administration.captivePortal.captivePortalProfiles.add = {}
gui.administration.captivePortal.captivePortalProfiles.edit = {}
gui.administration.captivePortal.captivePortalProfiles.images = {}
gui.administration.captivePortalSession = {}

--[OSGI Settings]]--
gui.administration.osgi = {}

--[FTP Settings]]--
gui.administration.ftp = {}

--[Multi Subnet Settings]]--
gui.administration.multisubnet = {}

--[SecureF1rst Extension Settings]]--
gui.administration.secureF1rstExtension = {}

--[Web Mgmt Settings]]--
gui.administration.webMgmt = {}

-- [[Telnet Settings]]--
-- Telnet Configuration
gui.administration.telnet = {}

-- [APN Settings]
-- APN Configuration
gui.administration.apn = {}

-- [RoutingLogs Settings]
gui.administration.routingLogs = {}

-- [SystemLogs Settings]
gui.administration.systemLogs = {}

-- [ipv6Logs Settings]
gui.administration.ipv6Logs = {}

--[Change Password]
gui.administration.changePassword = {}

if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED")) then
--[EasyMesh]                                                                     
gui.administration.mesh = {}
gui.administration.meshWifi = {}
end

--[WifionOff for NonMesh]
gui.administration.Wifi = {}

local fwRulesScript = "/pfrm2.0/etc/fwRuleScript.lua"
local fwRulesCmd = "/pfrm2.0/bin/lua " .. fwRulesScript
local staticOpenPorts = {
    PORT_DNSMASQ1        = 53,
    PORT_RAS1            = 2872,
    PORT_ACSD1           = 5916,
    PORT_DMS             = 5566,
    PORT_WPS_MONITOR1    = 1990,
    PORT_RAS2            = 1900,
    PORT_SMD             = 30005, 
    PORT_DIMCLIENT       = 7547,
    PORT_HGW_VOICE_AP1   = 8443,
    PORT_LIGHTTPD1       = 443,
    PORT_HGW_VOICE_AP2   = 8080,
    PORT_LIGHTTPD2       = 80,
    PORT_EAPD1           = 45000,
    PORT_EAPD2           = 44000,
    PORT_EAPD3           = 43000,
    PORT_WLEVT           = 44032,
    PORT_LOGGINGD        = 514,
    PORT_EAPD4           = 42000,
    PORT_ACSD2           = 42032,
    PORT_WPS_MONITOR2    = 40500,
    PORT_DNSMASQ2        = 67,
    PORT_EAPD5           = 38000,
    PORT_EAPD6           = 37000,
    PORT_NAS1            = 38032,
    PORT_WPS_MONITOR3    = 40600,
    PORT_HGW_VOICE_APP3  = 14000,
    PORT_HGW_VOICE_APP4  = 14001,
    PORT_WPS_MONITOR4    = 37064,
    PORT_RAS3            = 30000,
    PORT_RAS4            = 1900,
    PORT_WPS_MONITOR5    = 1900,
    PORT_EAPD7           = 46000,
    PORT_WIDE_DHCP6S     = 547,
    PORT_NAS2            = 3799
}
----------------------------------------------------------------------------------
-- @name gui.administration.firmware.upgrade.get
--
-- @description This function gets the server information from which firmware is
-- downloaded
--
-- @return
--
-- @description This routine is used by both HYDROGEN & ATA.
--
function gui.administration.firmware.upgrade.get ()

    -- include
 require "teamf1lualib/firmware"

 -- locals
 local firmInfoTbl = {}
    local errMsg = nil
    local statusMsg = nil

 -- getting the info
 firmInfoTbl = firmware.firmUgradeGet()
 if (firmInfoTbl == nil) then
  return "ERROR", "DB_ERROR_TRY_AGAIN"
 end
	local date = ""
	local fp = io.open("/pfrm2.0/firmwareDate")
    if (fp ~= nil) then
        date=fp:read("*all")
        fp:close()
    end
	firmInfoTbl["firmwareDate"] = date or ""

	local secdate = ""
	local fp = io.open("/flash/secfirmwareDate","r")
	if(fp ~= nil) then
		secdate=fp:read("*all")
		fp:close()
		firmInfoTbl["SecfirmwareDate"] = secdate
	else
		firmInfoTbl["SecfirmwareDate"] = "N.A"
	end

	local secVersion = ""
	local fp = io.open("/flash/secfirmVersion","r")
	if(fp ~= nil) then
		secVersion=fp:read("*all")
		fp:close()
		firmInfoTbl["SecfirmwareVersion"] = secVersion
	else
		firmInfoTbl["SecfirmwareVersion"] = "N.A"
	end
	

        -- To set the Model Name used in firmware name check
        if (util.fileExists ("/pfrm2.0/GPON_ONLY_NEW")) then
            firmInfoTbl["deviceModelName"] = "JCO101"
        elseif (util.fileExists ("/pfrm2.0/HW_FIBERHOME_JEO300")) then
            firmInfoTbl["deviceModelName"] = "JEO300"
        elseif (util.fileExists ("/pfrm2.0/GPON_ONLY")) then
            firmInfoTbl["deviceModelName"] = "JCO100"
        elseif (util.fileExists ("/pfrm2.0/ETHERNET_ONLY")) then
            firmInfoTbl["deviceModelName"] = "JCE100"
        elseif (util.fileExists ("/pfrm2.0/HW_FOXCONN_JCO500")) then
            firmInfoTbl["deviceModelName"] = "JCO500"
        elseif (util.fileExists ("/pfrm2.0/HW_FOXCONN")) then
            firmInfoTbl["deviceModelName"] = "JCS5100"
        elseif (util.fileExists ("/pfrm2.0/HW_FIBERHOME_JCO300")) then
            firmInfoTbl["deviceModelName"] = "JCO300"
        elseif (util.fileExists ("/pfrm2.0/HW_JCO110")) then
            firmInfoTbl["deviceModelName"] = "JCO110"
        elseif (util.fileExists ("/pfrm2.0/HW_HG260ES")) then
            firmInfoTbl["deviceModelName"] = "HG260ES"
		elseif (util.fileExists ("/pfrm2.0/HW_ALU")) then
            firmInfoTbl["deviceModelName"] = "G240WA"
		elseif (util.fileExists ("/pfrm2.0/HW_HG261GU")) then
            firmInfoTbl["deviceModelName"] = "HG261GU"
		elseif (util.fileExists ("/pfrm2.0/HW_JCOW206")) then
            firmInfoTbl["deviceModelName"] = "JCOW206"
		elseif (util.fileExists ("/pfrm2.0/HW_JCOW401")) then
            firmInfoTbl["deviceModelName"] = "JCOW401"
		elseif (util.fileExists ("/pfrm2.0/HW_JCOW403")) then
            firmInfoTbl["deviceModelName"] = "JCOW403"
        elseif (util.fileExists ("/pfrm2.0/HW_JCOW404")) then
            firmInfoTbl["deviceModelName"] = "JCOW404"
		elseif (util.fileExists ("/pfrm2.0/HW_JCOW411")) then
            firmInfoTbl["deviceModelName"] = "JCOW411"
        elseif (util.fileExists ("/pfrm2.0/BRCMJCO300")) then
            firmInfoTbl["deviceModelName"] = "HG260X"
        else
            firmInfoTbl["deviceModelName"] = "JCD100"
        end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

 -- return
 return errMsg, statusMsg, firmInfoTbl

    end

function gui.administration.firmware.upgrade.lteSet (firmCfg)

	require "teamf1lualib/firmware"

	local status = 1
	local filename = "/tmp/" .. cgilua.cookies.get("TeamF1Login")
	status = firmware.lteUpgrade (filename)
	if (status == 0) then
    	statusMsg = "STATUS_OK"
    	errMsg = "OK"
	else
    	statusMsg = "ERROR"
    	errMsg = "ERROR"
	end

	-- return
	return errMsg, statusMsg


end

------------------------------------------------------------------------------------
-- @name gui.administration.firmware.upgrade.set
--
-- @description This function upgrades the firmware which is downloaded
--
-- @return
--
-- @description This routine is used by both HYDROGEN & ATA.
--
--
function gui.administration.firmware.upgrade.set (firmCfg)

    -- include
 require "teamf1lualib/firmware"

 -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
	
    --[[
    local trRow = db.getRow ("tr69Config", "_ROWID_", "1")
    if (trRow["tr69Config.UpgradesManaged"] == "1") then
        return "ERROR", "UPGRADE_ONLY_VIA_ACS"
    end
    --]]

 -- locals
 local status = nil
 local errMsg = nil
 
	if (UNIT_INFO == "ODU")	then
		-- use different routine for ODU
 		os.execute("/bin/sh /pfrm2.0/bin/preUpgrade2.sh")
	end

    --[[ The following field will indicate whether the upgrade is from network or
    -- using USB.
    -- Set upgradeType = 1 for network Upgrade (or)
    -- Set upgradeType = 2 for USB Upgrade.]]--
    firmCfg["upgradeType"] = "1"
 -- calling for upgrade if upgradeMode = 1
 if (firmCfg["upgradeMode"] == "1") then
		filename = UPLOAD_DIR .. cgilua.cookies.get("TeamF1Login")
        if (util.fileExists ("/pfrm2.0/FIRMWARE_SIGNING_ENABLED1") == true ) then
		    status = firmware.upgrade (filename, 1, 10, 0, "-S",2)
        elseif (util.fileExists ("/pfrm2.0/FIRMWARE_SIGNING_ENABLED2") == true ) then
		    status = firmware.upgrade ("/tmp/upgrade/download.dwn", 1, 10, 0, "-S",0)
        else
		    status = firmware.upgrade (filename, 1, 10, 0, "-S",0)
        end
 -- calling for upgrade if upgradeMode = 2
 elseif (firmCfg["upgradeMode"] == "2") then
  errMsg, status = firmware.firmResetUpgrade(firmCfg)
 end

	if (status == 0) then
        -- create file to detect upgrade from GUI, so that /pfrm2.0/etc/tmp_ThirdParty.param
        -- file is copied to /flash/thirdparty/thirdparty.param while TR69 init
        os.execute("/bin/touch /flash/firmUpgradeGUI")
    	statusMsg = "STATUS_OK"
    	errMsg = "OK"
	else
    	statusMsg = "ERROR"
    	errMsg = "ERROR"
		-- upgrade has failed, delete uploaded file from /tmp/upload
        if (util.fileExists ("/pfrm2.0/FIRMWARE_SIGNING_ENABLED2") == true ) then
		    os.execute ("/bin/rm -f /tmp/upgrade/download.dwn")
		    os.execute ("/bin/rm -f /tmp/upgrade/download.sig")
        else
		    os.execute ("/bin/rm -f "..filename)
        end
	end
	

 -- return
 return errMsg, statusMsg
end

-------------------------------------------------------------------------------
-- @name gui.administration.firmware.cfg.restore
--
-- @description This function restores the configruation file after checking
-- the checksum.
--
-- @return
--
function gui.administration.firmware.cfg.restore(firmCfg)

 -- include
 require "teamf1lualib/firmware"

 --locals
 local status = nil
 local errMsg = nil

 -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
   else


 -- calling the restore file
 errMsg, status = firmware.restore(firmCfg)
 end

 -- return
 return errMsg, status
end

-------------------------------------------------------------------------------
-- @name gui.administration.firmware.cfg.factory_reset
--
-- @description This function is called when the user pushes a factory reset
-- button on the web interface and restores the device to factory reset
-- condition.
--
-- @return
--
function gui.administration.firmware.cfg.factory_reset ()

 -- include
 require "teamf1lualib/firmware"

 --locals
 local status = nil
 local errMsg = nil

 -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
 end

 -- factory reset and rebooting (To reboot pass 1 as the argument.)
 errMsg, status = firmware.factoryReset(1)

 -- return
 return errMsg, status
end

-------------------------------------------------------------------------------
-- @name gui.administration.firmware.reboot
--
-- @description This function reboots the device
--
-- @return
--
function gui.administration.firmware.reboot ()

 -- include
 require "teamf1lualib/firmware"

 -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

 -- locals
 local status = nil
 local errMsg = nil

 -- getting rebooted
 errMsg, status = firmware.reboot()

 -- return
 return errMsg, status
end

-------------------------------------------------------------------------------
-- @name gui.administration.firmware.switch
--
-- @description This function switches the firmware between current and secondary
--
-- @return
--
function gui.administration.firmware.switch ()

 -- include

 -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

 -- locals
 local status = nil
 local errMsg = nil

 if (util.fileExists("/flash/secfirmVersion")) then
 	local runningFirmware = ""
 	f = io.open("/tmp/runningFirmware","r")
 	if(f ~= nil) then
 		runningFirmware = f:read("*line")
    	f:close()
 	else
		runningFirmware = "1"
 	end

	if (runningFirmware == "1") then		
		os.execute("/bin/fw_setenv currentRunning '2'")	
	else
		os.execute("/bin/fw_setenv currentRunning '1'")
	end
	
	os.execute("/bin/cp /pfrm2.0/firmVersion /flash/secfirmVersion")
	os.execute("/bin/cp /pfrm2.0/firmwareDate /flash/secfirmwareDate")

	errMsg = "STATUS_OK"
	status = "OK"	
 else
	errMsg = "No secondary image found"
	status = "ERROR"
 end

 -- return
 return status, errMsg
end

-------------------------------------------------------------------------------
-- @name gui.administration.firmware.usb.upgrade.get()
--
-- @description This function gets the details about the usb connectivity and
-- the files contained in the usb
--
-- @return
--
function gui.administration.firmware.usb.upgrade.get(method)
 -- include
 require "teamf1lualib/firmware"
 require "teamf1lualib/diskMgmt"

    -- locals
    local usbTbl = {}
    local errMsg = nil
    local statusMsg = nil
    local usbConnectionStatus = nil
    local usbMountName = nil

    -- get the usb status
    usbConnectionStatus = diskMgmt.usbConnStatusGet ();

    usbTbl["usb_connection_status"] = usbConnectionStatus["usb_connection_status"]

    -- get the mount partitionName
    usbMountName = diskMgmt.usbMountNameGet ();

    -- get file list with .img and .cfg extension
    if (usbMountName ~= nil) then
        usbFileList = diskMgmt.usbFileListGet (usbMountName, method);
        if (usbFileList == nil) then
            return "ERROR", "USB_FAILED_TO_GET_FILELIST"
        end
    else
        usbFileList = {"", "", ""};
    end

    usbTbl.usb_data = usbFileList

    return "OK", "STATUS_OK", usbTbl
end

-------------------------------------------------------------------------------
-- @name gui.administration.firmware.usb.cfg.restore
--
-- @description This function restores the configruation file after checking
-- the checksum.
--
-- @return
--
function gui.administration.firmware.usb.cfg.restore(firmCfg)

 -- include
 require "teamf1lualib/firmware"

 --locals
 local status = nil
 local errMsg = nil

 -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- calling the restore file
 errMsg, status = firmware.USBrestore(firmCfg)
    if (errMsg == "OK") then
        errMsg , statusMsg = firmware.reboot()
 end

 -- return
 return errMsg, status
end

-------------------------------------------------------------------------------
-- @name gui.administration.firmware.upgrade.set
--
-- @description This function upgrade the device with provided configuration
--
-- @return
--
function gui.administration.firmware.usb.upgrade.set(firmCfg)

 -- include
 require "teamf1lualib/firmware"

 -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

 -- locals
 local status = nil
 local errMsg = nil

    --[[ The following field will indicate whether the upgrade is from network or
    -- using USB.
    -- Set upgradeType = 1 for network Upgrade (or)
    -- Set upgradeType = 2 for USB Upgrade.]]--
    firmCfg["upgradeType"] = "2"
 -- calling for upgrade if upgradeMode = 1
 if (firmCfg["upgradeMode"] == "1") then
  errMsg, status = firmware.firmManualUpgrade(firmCfg)
 -- calling for factory reset & upgrade if upgradeMode = 2
 elseif (firmCfg["upgradeMode"] == "2") then
  errMsg, status = firmware.firmResetUpgrade(firmCfg)
 end

 -- return
 return errMsg, status
end

------------------------------------------------------------------------------------
-- @name gui.administration.users.get
--
-- @description This function gets the users details.
--
-- @return
--
-- @description This routine is used by both HYDROGEN & ATA.
--
--
function gui.administration.users.get()

    -- Require
    require "teamf1lualib/userdb"

    -- locals
 local usersInfo = {} --local table containing the users Info
 local page = {} --local table containing the users Info
    local errMsg = nil
    local statusMsg = nil
    page.users = {}

    -- get the system information from platform
 usersInfo = userdb.usersGet()
 if (usersInfo == nil) then
        return "OK", "DB_ERROR_TRY_AGAIN"
 end

    for i,v in ipairs (usersInfo)
    do
        page.users[i] = {}
        page.users[i].username = util.filterXSSChars(v["username"])
        page.users[i].groupname = util.filterXSSChars(v["groupname"])
        page.users[i].descr = util.filterXSSChars (v["descr"])
        page.users[i]._ROWID_ = v["_ROWID_"]
    end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

    --return
 return errMsg, statusMsg, page

end

-------------------------------------------------------------------------------
-- @name gui.administration.users.add.get
--
-- @description This function gets default configuration for adding a user in
-- system.
--
-- @return
--
function gui.administration.users.add.get ()

 --include
 require "teamf1lualib/userdb"

    --locals
    local userTbl = {}
    local page = {}
    local errMsg = nil
    local statusMsg = nil

    page.groups = {}
    -- getting the defaults for the users
    userTbl = userdb.usersAddGet()
    if (userTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    for k,v in pairs (userTbl.groupname) do
        page.groups[k] = {}
        page.groups[k].groupname = v["groups.name"]
    end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

 --return
 return errMsg, statusMsg, page

end

-------------------------------------------------------------------------------
-- @name gui.administration.users.add.set
--
-- @description This function adds a user in system.
--
-- @param lua table containing userdb confiuration
--
-- @return
--
function gui.administration.users.add.set (userdbCfg)

 --include
 require "teamf1lualib/userdb"

  -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
 local status = nil
 local errMsg = nil

 if (userdbCfg["groupname"] ~= "guest") then
        userdbCfg["enableAccess"] = "1"
 end

 --setting the new configuration in the users table
 errMsg, status = userdb.usersAddSet(userdbCfg)

 --return
 return errMsg, status

end

-------------------------------------------------------------------------------
-- @name gui.administration.users.edit.get
--
-- @description This function gets configuration for an existing user in
-- system.
--
-- @param rowid for which userdb configuration has to be modified.
--
-- @return
--
function gui.administration.users.edit.get (rowid)

    --include
    require "teamf1lualib/userdb"

    --locals
    local userTbl = {}
    local page = {}
    local errMsg = nil
    local statusMsg = nil

    page.groups = {}
     --getting the configuration for the selected row
    userTbl = userdb.usersEditGet(rowid)
    userTbl.usernameDisabled = ""
    if ((userTbl.username == "admin") or (userTbl.username == "guest")) then
	    userTbl.usernameDisabled = "DISABLED"
    end
    if (userTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    for k,v in pairs (userTbl.groups) do
        page.groups[k] = {}
        page.groups[k].groupname = v["groups.name"]
    end
    
    page.username = util.filterXSSChars (userTbl["username"])
    page.descr = util.filterXSSChars (userTbl["descr"])
    page._ROWID_ = userTbl["_ROWID_"]
    page.groupname = userTbl["groupname"]
    page.enableAccess = userTbl["enableAccess"]
    page.loginTimeout = util.filterXSSChars (userTbl["loginTimeout"])
    
    errMsg = "OK"
    statusMsg = "STATUS_OK"

 --return
 return errMsg, statusMsg, page
end

-------------------------------------------------------------------------------
-- @name gui.administration.users.edit.set
--
-- @description This function configures user in system.
--
-- @param lua table containing userdb confiuration
--
-- @return
--
function gui.administration.users.edit.set (userdbCfg)

 --include
 require "teamf1lualib/userdb"

  -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

 --locals
 local status = nil
 local errMsg = nil

 if (userdbCfg["groupname"] ~= "guest") then
        userdbCfg["enableAccess"] = "1"
 end

 --setting the new configuration in the users table
 errMsg, status = userdb.usersEditSet(userdbCfg)

 --return
 return errMsg, status

end

-------------------------------------------------------------------------------
-- @name gui.administration.users.delete
--
-- @description This function deletes user(s) from system
--
-- @param rowid(s) for which users has to be deleted.
--
-- @return
--
function gui.administration.users.delete (rowids)

  --include
 require "teamf1lualib/userdb"

  -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

 --locals
 local status = nil
 local errMsg = nil

 --setting the new configuration in the users table
 errMsg, status = userdb.usersDelete(rowids)

 --return
 return errMsg, status

end

------------------------------------------------------------------------------------
-- @name gui.administration.groups.get
--
-- @description This function gets the groups details.
--
-- @return
--
-- @description
--
--
function gui.administration.groups.get()

    -- Require
    require "teamf1lualib/userdb"

    -- locals
 local groupsInfo = {} --local table containing the groups Info
 local page = {} --local table containing the groups Info
    local errMsg = nil
    local statusMsg = nil
    page.groups = {}

    -- get the system information from platform
 groupsInfo = userdb.groupsGet()
 if (groupsInfo == nil) then
        return "OK", "DB_ERROR_TRY_AGAIN"
 end

    for i,v in ipairs (groupsInfo)
    do
        page.groups[i] = {}
        page.groups[i].name = v["name"]
        page.groups[i].descr = v["descr"]
        page.groups[i].accessLevel = v["accessLevel"]
        page.groups[i].capabilities = v["capabilities"]
        page.groups[i]._ROWID_ = v["_ROWID_"]
    end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

    --return
 return errMsg, statusMsg, page

end

-------------------------------------------------------------------------------
-- @name gui.administration.groups.add.get
--
-- @description This function gets default configuration for adding a group in
-- system.
--
-- @return
--
function gui.administration.groups.add.get ()

 --include
 require "teamf1lualib/userdb"

    --locals
 local groupTbl = {}
    local errMsg = nil
    local statusMsg = nil

 -- getting the defaults for the groups
 groupTbl = userdb.groupsAddGet()
 if (groupTbl == nil) then
  return "ERROR", "DB_ERROR_TRY_AGAIN"
 end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

 --return
 return errMsg, statusMsg, groupTbl

end

-------------------------------------------------------------------------------
-- @name gui.administration.groups.add.set
--
-- @description This function adds a group in system.
--
-- @param lua table containing userdb confiuration
--
-- @return
--
function gui.administration.groups.add.set (userdbCfg)

 --include
 require "teamf1lualib/userdb"

  -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
 local status = nil
 local errMsg = nil

 --setting the new configuration in the groups table
 errMsg, status = userdb.groupsAddSet(userdbCfg)

 --return
 return errMsg, status

end

-------------------------------------------------------------------------------
-- @name gui.administration.groups.edit.get
--
-- @description This function gets configuration for an existing group in
-- system.
--
-- @param rowid for which userdb configuration has to be modified.
--
-- @return
--
function gui.administration.groups.edit.get (rowid)

 --include
 require "teamf1lualib/userdb"

 --locals
 local groupTbl = {}
    local errMsg = nil
    local statusMsg = nil

 --getting the configuration for the selected row
 groupTbl = userdb.groupsEditGet(rowid)
 groupTbl.nameDisabled = "DISABLED"
 
 if (groupTbl == nil) then
  return "ERROR", "DB_ERROR_TRY_AGAIN"
 end

 errMsg = "OK"
    statusMsg = "STATUS_OK"

 --return
 return errMsg, statusMsg, groupTbl
end

-------------------------------------------------------------------------------
-- @name gui.administration.groups.edit.set
--
-- @description This function configures group in system.
--
-- @param lua table containing userdb confiuration
--
-- @return
--
function gui.administration.groups.edit.set (userdbCfg)

 --include
 require "teamf1lualib/userdb"

  -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

 --locals
 local status = nil
 local errMsg = nil

 --setting the new configuration in the groups table
 errMsg, status = userdb.groupsEditSet(userdbCfg)

 --return
 return errMsg, status

end

-------------------------------------------------------------------------------
-- @name gui.administration.groups.delete
--
-- @description This function deletes group(s) from system
--
-- @param rowid(s) for which groups has to be deleted.
--
-- @return
--
function gui.administration.groups.delete (rowids)

  --include
 require "teamf1lualib/userdb"

  -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

 --locals
 local status = nil
 local errMsg = nil

 --setting the new configuration in the groups table
 errMsg, status = userdb.groupsDelete(rowids)

 --return
 return errMsg, status

end
-------------------------------------------------------------------------------
-- @name gui.administration.firmware.cfg.restore
--
-- @description This function restores the configruation file after checking
-- the checksum.
--
-- @return
--
function gui.administration.firmware.cfg.restore(firmCfg)

 -- include
 require "teamf1lualib/firmware"

 --locals
 local status = nil
 local errMsg = nil

 -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
   else
 -- calling the restore file
 errMsg, status = firmware.restore(firmCfg)
 end

 -- return
 return errMsg, status
end

-------------------------------------------------------------------------------
-- @name gui.administration.firmware.cfg.factory_reset
--
-- @description This function is called when the user pushes a factory reset
-- button on the web interface and restores the device to factory reset
-- condition.
--
-- @return
--
function gui.administration.firmware.cfg.factory_reset ()

 -- include
 require "teamf1lualib/firmware"

 --locals
 local status = nil
 local errMsg = nil

 -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
 end

 -- factory reset and rebooting (To reboot pass 1 as the argument.)
 errMsg, status = firmware.factoryReset(1)

 -- return
 return errMsg, status
end

-------------------------------------------------------------------------------
-- @name gui.administration.firmware.reboot
--
-- @description This function reboots the device
--
-- @return
--
function gui.administration.firmware.reboot ()

 -- include
 require "teamf1lualib/firmware"

 -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

 -- locals
 local status = nil
 local errMsg = nil

 -- getting rebooted
 errMsg, status = firmware.reboot()

 -- return
 return errMsg, status
end

-------------------------------------------------------------------------------
-- @name gui.administration.ssh.lanGet
--
-- @description This function gets lan ssh configuration available in the
-- device
--
-- @return
--
function gui.administration.ssh.lanGet ()

 --include
 require "teamf1lualib/sshd"


 -- locals
 local sshTbl = {}
    local errMsg = nil
    local statusMsg = nil

 -- getting the table
 sshTbl = sshd.sshLanGet()
 if (sshTbl == nil) then
  return "ERROR", "DB_ERROR_TRY_AGAIN"
 end

 errMsg = "OK"
    statusMsg = "STATUS_OK"

 --return
 return errMsg, statusMsg, sshTbl
end

-------------------------------------------------------------------------------
-- @name gui.administration.ssh.wanGet
--
-- @description This function gets wan ssh configuration available in the
-- device
--
-- @return
--
function gui.administration.ssh.wanGet ()

 --include
 require "teamf1lualib/sshd"


 -- locals
 local sshTbl = {}
    local errMsg = nil
    local statusMsg = nil

 -- getting the table
 sshTbl = sshd.sshWanGet()
 if (sshTbl == nil) then
  return "ERROR", "DB_ERROR_TRY_AGAIN"
 end

 errMsg = "OK"
    statusMsg = "STATUS_OK"

 --return
 return errMsg, statusMsg, sshTbl
end

-------------------------------------------------------------------------------
-- @name gui.administration.ssh.set
--
-- @description This function sets ssh configuration in the device
--
-- @return
--
function gui.administration.ssh.set (sshCfg)

 --include
 require "teamf1lualib/sshd"

 -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

 -- locals
 local status = nil
 local errMsg = nil

    -- setting the new configuration
 errMsg, status = sshd.sshSet(sshCfg)

    -- updating bonjour default service table before the commit transaction
    local bonjourTbl = {}
    local bonjourServiceTbl = {}
    local ethaddress = db.getAttribute ("environment", "name", "ethaddr", "value")
    local name = db.getAttribute ("environment", "name", "product_name", "value")
    local MAC_LSB_6 = util.split(ethaddress, ":")
    BNJR_SERVICE_INSTANCE_NAME=name .. MAC_LSB_6[4] .. MAC_LSB_6[5] .. MAC_LSB_6[6]
    BNJR_SERVICE_TYPE="tcp"
    BNJR_SERVICE_DOMAIN="local"
    DEFAULT_LAN_INTERFACE = "IF2"
    BNJR_SERVICE_INTERFACE=DEFAULT_LAN_INTERFACE
    if((sshCfg["lanSsh"] ~= nil) and (sshCfg["lanSsh"] == "1")) then
        bonjourTbl["bonjourDefaultServices.serviceID"] = BNJR_SERVICE_INSTANCE_NAME
        bonjourTbl["bonjourDefaultServices.serviceName"] = "ssh"
        bonjourTbl["bonjourDefaultServices.serviceType"] = BNJR_SERVICE_TYPE
        bonjourTbl["bonjourDefaultServices.domainName"] = BNJR_SERVICE_DOMAIN
        bonjourTbl["bonjourDefaultServices.LogicalIfName"] = BNJR_SERVICE_INTERFACE
        bonjourTbl["bonjourDefaultServices.portNumber"] = "22"
        bonjourTbl["bonjourDefaultServices.textRecord"] = ""
        db.insert ("bonjourDefaultServices", bonjourTbl)
        errMsg = "OK"
        status = "STATUS_OK"
    else
        bonjourServiceTbl = db.getRowWhere ("bonjourDefaultServices", "serviceName='ssh'", false)
        if(bonjourServiceTbl ~= nil) then
            errMsg, status = db.deleteRowWhere ("bonjourDefaultServices", "serviceName='ssh'", false)
            if (errMsg == 1) then
                errMsg = "OK"
                status = "STATUS_OK"
            end
            if (errMsg ~= "OK") then
               return "ERROR", "OPERATION_NOT_SUCCEEDED"
            end
        end
     end

    if (errMsg == "OK") then db.save2() end

 --return
 return errMsg, status
end

-------------------------------------------------------------------------------
-- @name gui.administration.remote_logging.get
--
-- @description This function gets remote logging configuration available in
-- system
--
-- @return
--
function gui.administration.remote_logging.get ()

 --include
 require "teamf1lualib/logging"

 -- local
 local loggingTbl = {}
    local errMsg = nil
    local statusMsg = nil

 -- getting the info from the eventLog table
 loggingTbl = logging.remoteLoggingGet()
 if (loggingTbl == nil) then
  return "ERROR", "DB_ERROR_TRY_AGAIN"
 end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

    loggingTbl["serverName"] = util.filterXSSChars (loggingTbl["serverName"])
    loggingTbl["serverPort"] = util.filterXSSChars (loggingTbl["serverPort"])

 -- return
 return errMsg, statusMsg, loggingTbl
end

-------------------------------------------------------------------------------
-- @name gui.administration.remote_logging.set
--
-- @description This function configures remote logging feature in system
--
-- @return
--
function gui.administration.remote_logging.set (logCfg)

 --include
 require "teamf1lualib/logging"

 -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

 -- local
 local status = nil
 local errMsg = nil

 -- setting the eventLog table with new configuration
 errMsg, status = logging.remoteLoggingSet(logCfg)

    -- save db if no error
    if (errMsg == "OK") then db.save2() end

 -- return
 return errMsg, status
end

-------------------------------------------------------------------------------
-- @name gui.administration.time.get
--
-- @description This function gets ntp configuration available in system
--
-- @return
--
function gui.administration.time.get()

    --include
 require "teamf1lualib/time"


 -- local
 local ntpTbl = {}
 local inputTable = {}
    local errMsg = nil
    local statusMsg = nil

 -- getting the time info
 ntpTbl = ntp.timeGet()
 if (ntpTbl == nil) then
  return "ERROR", "DB_ERROR_TRY_AGAIN"
 end

    ntpTbl.server1 = util.filterXSSChars (ntpTbl.server1)
    ntpTbl.server2 = util.filterXSSChars (ntpTbl.server2)
    ntpTbl.reSyncNtpVal = util.filterXSSChars (ntpTbl.reSyncNtpVal)

 errMsg = "OK"
    statusMsg = "STATUS_OK"

 -- return
 return errMsg, statusMsg, ntpTbl

end

-------------------------------------------------------------------------------
-- @name gui.administration.time.set
--
-- @description This function configures time insystem by calling appropriate
-- mgmt routine(s)
--
-- @return
--
function gui.administration.time.set(timeCfg)

    --include
 require "teamf1lualib/time"

 -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

 -- local
 local status = nil
 local errMsg = nil

 -- setting the time in the ntp table
 errMsg, status = ntp.timeSet(timeCfg)

 -- return
 return errMsg, status

end

-------------------------------------------------------------------------------
-- @name gui.administration.discovery.upnpGet
--
-- @description This function gets configuration information about dicovery
-- protocols such as UPnP available in device
--
-- @return
--
function gui.administration.discovery.upnpGet ()

 --include
 require "teamf1lualib/upnp"

 -- locals
 local upnpTbl = {}
 local discovTbl = {}
    local networkTbl ={}
    local localTbl = {}
    local errmsg, statusMsg
 discovTbl.upnpTbl = {}
 discovTbl.networks = {}


 -- get the values from upnp tables
 errMsg, status, upnpTbl = upnp.upnpGet()
 if (upnpTbl == nil) then
  return "ERROR", "DB_ERROR_TRY_AGAIN", localTbl
 end

--[[
    networkTbl = db.getRows ("networkInterface", "zoneType", "secure")
    for i,v in pairs (networkTbl) do
        discovTbl.networks[i] = {}
        discovTbl.networks[i].networkname = v["networkInterface.networkName"]
    end

    discovTbl["networkName"] = db.getAttribute ("networkInterface","LogicalIfName", upnpTbl["LogicalIfName"], "networkName")


    discovTbl["upnpEnable"] = upnpTbl["upnpEnable"]

    errmsg = "OK"
    statusMsg = ""
--]]

    upnpTbl["advPeriod"] = util.filterXSSChars(upnpTbl["advPeriod"])
    upnpTbl["advTimeToLive"] = util.filterXSSChars(upnpTbl["advTimeToLive"])
    --return
    return errmsg, statusMsg, upnpTbl

end


-------------------------------------------------------------------------------
-- @name gui.administration.discovery.bonjourGet
--
-- @description This function gets configuration information about dicovery
-- protocols such as Bonjour available in device
--
-- @return
--
function gui.administration.discovery.bonjourGet ()

 --include
 require "teamf1lualib/bonjour"

 -- Sanity for privilages
    --[[if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end]]--

 -- locals
 local bonjourStateTbl = {}
 local discovTbl = {}
    local localTbl = {}
    local vlansTbl = {}
    local errmsg, statusMsg
 discovTbl.bonjourStateTbl = {}


 errMsg, status, bonjourStateTbl = bonjour.bonjourStateGet()
 if (bonjourStateTbl == nil) then
  return "ERROR", "DB_ERROR_TRY_AGAIN", localTbl
 end

    errMsg, status, vlansTbl = bonjour.associatedVlansGet()
    if (errMsg ~= "OK") then
        return errMsg, status
    end

    discovTbl["isEnabled"] = bonjourStateTbl["isEnabled"]
    discovTbl.vlansTbl = vlansTbl


    errmsg = "OK"
    statusMsg = ""

    --return
    return errmsg, statusMsg, discovTbl

end

-------------------------------------------------------------------------------
-- @name gui.administration.discovery.upnpSet
--
-- @description This function sets configuration UPnP services in
-- device.
--
-- @return
--
function gui.administration.discovery.upnpSet (protoCfg)

 --include
 require "teamf1lualib/upnp"

 -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

 -- locals
 local upnpTbl = {}
 local statusMsg = ""
 local errMsg = "ERROR"

    -- setting bonjour as enable/disable as per requirement
 errMsg, statusMsg = upnp.upnpSet(protoCfg)

    if (errMsg == "OK") then
        db.save2()
    end

 --return
 return errMsg, statusMsg
end

-------------------------------------------------------------------------------
-- @name gui.administration.discovery.bonjourSet
--
-- @description This function sets configuration Bonjour services in
-- device.
--
-- @return
--
function gui.administration.discovery.bonjourSet (protoCfg)

 --include
 require "teamf1lualib/bonjour"

 -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

 -- locals
 local bonjourTbl = {}
 local statusMsg = ""
 local errMsg = "ERROR"
    local vlansTbl = {}

    errMsg, statusMsg = bonjour.bonjourStateSet(protoCfg)
    if (errMsg == "ERROR") then
        return errMsg, statusMsg
    end

    local tbltosplit
    for k, p in pairs (protoCfg) do
        if (string.find(k, "_") ~= nil) then
            tbltosplit = string.sub (k, 8)
            errMsg, statusMsg = bonjour.associatedVlansEditSet(tbltosplit, p)
            if (errMsg == "ERROR") then
                return errMsg, statusMsg
            end
        end
    end

    if (errMsg == "OK") then
        db.save2()
    end

 --return
 return errMsg, statusMsg
end

----------------------------------------------------------------------------------
-- @name gui.administration.tr069Configuration.get
--
-- @description This function gets the tr69 configuration information
--
-- @return
--
-- @description This routine is used by both HYDROGEN & ATA.
--
function gui.administration.tr069Configuration.get ()
    local tr69Config = {}
    local connreq = {}
    local stun = {}
    local acs_config = {}
    local networkName

    local query = "_ROWID_=1"
    tr69Config = db.getRowWhere("tr69Config", query, false)
    if (tr69Config == nil) then
        return "ERROR", "TR69_CONFIG_NOT_FOUND", acs_config
    end

    acs_config["tr69Status"] = tr69Config["tr69Status"]
    acs_config["URL"] = util.filterXSSChars (tr69Config["URL"])
    if (tr69Config["ACSPasswordGeneration"] == "0") then
        acs_config["Username"] = tr69Config["Username"]
    else
        acs_config["Username"] = tr69Config["serialUsername"]
    end
	acs_config["Username"] = util.filterXSSChars (acs_config["Username"])
    if (tr69Config["ACSPasswordGeneration"] == "0") then
        acs_config["Password"] = util.mask (tr69Config["Password"])
    else
        acs_config["Password"] = util.mask (tr69Config["serialPassword"])
    end
    acs_config["ConnectionRequestUsername"] = util.filterXSSChars(tr69Config["ConnectionRequestUsername"])
    acs_config["ConnectionRequestPassword"] = util.filterXSSChars(tr69Config["ConnectionRequestPassword"])
    acs_config["InformInterval"] = util.filterXSSChars(tr69Config["InformInterval"])
    acs_config["STUNEnable"] = tr69Config["STUNEnable"]
    acs_config["STUNServerAddress"] = util.filterXSSChars(tr69Config["STUNServerAddress"])
    acs_config["STUNUsername"] = util.filterXSSChars(tr69Config["STUNUsername"])
    acs_config["STUNPassword"] = util.filterXSSChars (tr69Config["STUNPassword"])
    acs_config["ACSPasswordGeneration"] = tr69Config["ACSPasswordGeneration"]
    return "OK", "STATUS_OK", acs_config
end

----------------------------------------------------------------------------------
-- @name gui.administration.tr069ThirdPartyConfiguration.get
--
-- @description This function gets the third party application 
-- configuration information
--
-- @return
--
function gui.administration.tr069ThirdPartyConfiguration.get (configTbl)
    require "tr69clientLib"

    local ParamValue
    local status = nil

    if (configTbl == nil) then
        return "ERROR", "ERR_INVALID_CONFIG_TABLE"
    end

    -- loop input table and get values of parameters in each row
    for i,v in pairs (configTbl) do

        ParamValue = nil

        if ((v.ParamName ~= nil) and (v.PartyName ~= nil)) then
            status, ParamValue = tr69clientLib.thirdPartyConfGet (v.ParamName, v.PartyName);

            if (ParamValue ~= nil) then
                v.ParamValue = ParamValue
                v.Status = status
            else
                -- Failed to get the value
                v.ParamValue = ""
                v.Status = status
            end

        else
            -- ParamName or PartyName is nil
            v.Status = "ERROR"
        end
    end

    return "OK", configTbl
end

----------------------------------------------------------------------------------
-- @name gui.administration.tr069ThirdPartyConfiguration.set
--
-- @description This function sets the third party application 
-- configuration information
--
-- @return
--
function gui.administration.tr069ThirdPartyConfiguration.set (configTbl)
    require "tr69clientLib"

    local setStatus 
    local status = nil

    if (configTbl == nil) then
        return "ERROR", "ERR_INVALID_CONFIG_TABLE"
    end

    -- loop input table and set values of parameters in each row
    for i,v in pairs (configTbl) do

        setStatus = nil

        if ((v.ParamName ~= nil) and (v.PartyName ~= nil) and (v.ParamValue ~= nil)) then
            status, setStatus = tr69clientLib.thirdPartyConfSet (v.ParamName, v.PartyName, v.ParamValue);

            if (setStatus ~= nil) then
                v.SetStatus = setStatus
                v.Status = status
            else
                -- Failed to get the value
                v.Status = status
            end

        else
            -- ParamName or PartyName or ParamValue is nil
            v.Status = "ERROR"
        end
    end

    return "OK", configTbl
end

----------------------------------------------------------------------------------
-- @name gui.administration.tr069Configuration.set
--
-- @description This function gets the tr69 configuration information
--
-- @return status, errMsg
--
-- @description This routine is used to set tr69 settings in the device
--
function gui.administration.tr069Configuration.set (acs_config)
    require "teamf1lualib/tr69Mgmt"
    require "teamf1lualib/ifDev"

    local tr69Config = {}
    local query = "_ROWID_=1"
    local connreq = {}
    local stun = {}
    local status = nil
    local acs_url = nil
    local acsUrlFlag = 0;
    local UsernameSetFlag = 0;
    local PasswordSetFlag = 0;
    local informIntervalFlag = 0;
    local tr69StatusFlag = 0;
    local connReqFlag = 0;
    local stunStatusFlag = 0;
    local stunServerFlag = 0;
    local stunUsernameFlag = 0;
    local stunPasswordFlag = 0;
    local acsPasswordGeneration = 0;
    local k,v
    local DEFAULT_THROTTLE = "10"

    tr69Config = db.getRowWhere("tr69Config", query, false)
    if (tr69Config == nil) then
        return "ERROR","TR69_CONFIG_NOT_FOUND"
    end

    --
    -- ACS settings
    --
    -- ACS URL
    if (acs_config["URL"] ~= nil) then
        acs_url = acs_config["URL"]
        if ((string.match(acs_url, "http:") == nil) and
            (string.match(acs_url, "https:") == nil)) then
            return "ERROR","TR69_INVALID_ACS_URL"
        end

        local urlArr = util.split (acs_config["URL"], "//");
        if (urlArr[2] == nil or urlArr[2] == "" or urlArr[2] == " ") then
            return "ERROR","TR69_INVALID_ACS_URL"
        end

        if (acs_config["URL"] ~= tr69Config["URL"]) then
            os.execute ("touch /flash/urlChangeACS")
            acsUrlFlag = 1
        end
        tr69Config["URL"] = acs_config["URL"]
    end
    -- ACS Username 
    if (acs_config["Username"] ~= nil) then
        if (tr69Config["Username"] ~= acs_config["Username"]) then
            UsenameSetFlag = 1
        end
        tr69Config["Username"] = acs_config["Username"]
    end
    if (tr69Config["ACSPasswordGeneration"] ~= nil) then
        if (tr69Config["ACSPasswordGeneration"] == "1" and UsenameSetFlag == 1) then
            return "ERROR", "ACS_PWD_GENERATION_ENABLED"
        end
    end
    -- ACS Password
    if (acs_config["Password"] ~= nil) then
        if (util.isAllMasked (acs_config["Password"])) then
            acs_config["Password"] = tr69Config["Password"]
        end
        if (tr69Config["Password"] ~= acs_config["Password"]) then
            PasswordSetFlag = 1
        end
        tr69Config["Password"] = acs_config["Password"]
    end
    if (tr69Config["ACSPasswordGeneration"] ~= nil) then
        if (tr69Config["ACSPasswordGeneration"] == "1" and PasswordSetFlag == 1) then
            return "ERROR", "ACS_PWD_GENERATION_ENABLED"
        end
    end

    --
    -- Connection Request
    --
    -- CRQ Username
    if (acs_config["ConnectionRequestUsername"] ~= nil) then
        if (tr69Config["ConnectionRequestUsername"] ~= acs_config["ConnectionRequestUsername"]) then
            connReqFlag = 1
        end
        tr69Config["ConnectionRequestUsername"] = acs_config["ConnectionRequestUsername"]
    end
    -- CRQ Password
    if (acs_config["ConnectionRequestPassword"] ~= nil) then
        if (tr69Config["ConnectionRequestPassword"] ~= acs_config["ConnectionRequestPassword"]) then
            connReqFlag = 1
        end
        tr69Config["ConnectionRequestPassword"] = acs_config["ConnectionRequestPassword"]
    end

    --
    -- PeriodicInfom Interval
    --
    if (acs_config["InformInterval"] ~= nil) then
        if (tr69Config["InformInterval"] ~= acs_config["InformInterval"]) then
            informIntervalFlag = 1
        end
        tr69Config["InformInterval"] = acs_config["InformInterval"]
	    if(tonumber(acs_config["InformInterval"]) < tonumber(tr69Config["DefaultActiveNotificationThrottle"])) then
	        tr69Config["DefaultActiveNotificationThrottle"] = DEFAULT_THROTTLE
	    end
    end

    --
    -- STUN Status
    --
    if (acs_config["STUNEnable"] ~= nil) then
        if (tr69Config["STUNEnable"] ~= acs_config["STUNEnable"]) then
            stunStatusFlag = 1
        end
        tr69Config["STUNEnable"] = acs_config["STUNEnable"]
    end

    --
    -- STUN Server Address
    --
    if (acs_config["STUNServerAddress"] ~= nil) then
        if (tr69Config["STUNServerAddress"] ~= acs_config["STUNServerAddress"]) then
            stunServerFlag = 1
        end
        tr69Config["STUNServerAddress"] = acs_config["STUNServerAddress"]
    end

    --
    -- STUN Username
    --
    if (acs_config["STUNUsername"] ~= nil) then
        if (tr69Config["STUNUsername"] ~= acs_config["STUNUsername"]) then
            stunUsernameFlag = 1
        end
        tr69Config["STUNUsername"] = acs_config["STUNUsername"]
    end

    --
    -- STUN Password
    --
    if (acs_config["STUNPassword"] ~= nil) then
        if (tr69Config["STUNPassword"] ~= acs_config["STUNPassword"]) then
            stunPasswordFlag = 1
        end
        tr69Config["STUNPassword"] = acs_config["STUNPassword"]
    end

    --
    -- TR-069 status
    --
    if (acs_config["tr69Status"] ~= nil) then
        if (tr69Config["tr69Status"] ~= acs_config["tr69Status"]) then
            tr69StatusFlag = 1
        end
        tr69Config["tr69Status"] = acs_config["tr69Status"]
    end

    --
    -- ACS Password Generation 
    if (acs_config["ACSPasswordGeneration"] ~= nil) then
        if (tr69Config["ACSPasswordGeneration"] ~= acs_config["ACSPasswordGeneration"]) then
            acsPasswordGeneration = 1
        end
        tr69Config["ACSPasswordGeneration"] = acs_config["ACSPasswordGeneration"]
    end

    --Always update the configuration to 'tr69Config' tbl in system.db
    local tr69CfgRow = tr69Config
    tr69CfgRow = util.addPrefix(tr69CfgRow, "tr69Config.")
    db.update("tr69Config", tr69CfgRow, tr69CfgRow["tr69Config._ROWID_"]);
    db.save2();
    -- don't remove this, needed for synchronization with saving configuration
    os.execute ("sleep 3"); 

    --Case-1
    --If ACS URL has changed or TR-069 got enabled, then remove persistent TR-069 configuration
    --and reboot the device
    if (acsUrlFlag == 1 or (tr69StatusFlag == 1 and tr69Config["tr69Status"] == "1")) then
        -- remove tr69 persistent data
        local cfg = db.getAttribute("environment", "name", "TR69_PERSISTENT_STORE", "value")
        if (cfg ~= nil) then
            os.execute ("rm -Rf " .. cfg)
        end

        return "OK", "STATUS_OK_REBOOT"
    end

    --Case-2
    -- If TR-069 got disabled, then stop the service in the CPE
    if(tr69StatusFlag == 1 and tr69Config["tr69Status"] == "0") then
        tr69Mgmt.stop()
        return "OK", "STATUS_OK"
    end

    --Case-3
    --If ACS URL didn't change and TR-069 status didn't change, but one of the other entries
    --have changed, then update the corresponding entries of 'params' tbl in parameters.db 
    if (UsenameSetFlag == 1 or PasswordSetFlag == 1 or connReqFlag == 1 or informIntervalFlag == 1 or stunStatusFlag == 1 or stunServerFlag == 1 or stunUsernameFlag == 1 or stunPasswordFlag == 1 or acsPasswordGeneration == 1) then
        --Don't restart dimclient. Restarting after bootup will break the get/set actions
        --for multiobject entries, maintained by dimclient, that got generated on receiving
        --corresponding tbl update events.This is a known limitation of TF1 TRi-069 framework.

        --update the values to params tbl in parameters.db
        tr69Mgmt.configReWrite(tr69Mgmt.runtimeParamFile, tr69Config)
        
        --[[
        status = tr69Mgmt.configure(tr69Config)
        if (status ~= 0) then
                return "ERROR","TR69_CONFIG_FAILED"
        end
        ]]--
    end

    return "OK", "STATUS_OK"
end

----------------------------------------------------------------------------------
-- @name gui.administration.tftpMgmt.get
--
-- @description This function gets the tftpMgmt configuration information
--
-- @return
--
-- @description This routine is used by both HYDROGEN & ATA.
--
--
function gui.administration.tftpMgmt.get ()

    local query = "_ROWID_='1'"
    local tftpMgmtRow = db.getRowWhere ("tftpMgmtTbl", query, false);
    local outputTbl = {}

    local tr69Row = db.getRowWhere ("tr69Config", query, false);

    if(tr69Row["tr69Status"] == "0") then
    outputTbl["tftpMgmtStatus"] = "2" -- tr is disabled
    elseif (tftpMgmtRow["tftpMgmtStatus"] == "0" ) then
        outputTbl["tftpMgmtStatus"] = "0";
    elseif (tftpMgmtRow["tftpMgmtStatus"] == "1" ) then
        outputTbl["tftpMgmtStatus"] = "1"
        if(tftpMgmtRow["tftpMgmtUrl"] == "NULL") then
        outputTbl["tftpMgmtUrl"] = ""
        else
        outputTbl["tftpMgmtUrl"] = tftpMgmtRow["tftpMgmtUrl"]
        end
    end

    if (tftpMgmtRow["tftpMgmtMethod"] == "0") then
        outputTbl["dhcpOption"] = "1"
    else
        outputTbl["dhcpOption"] = "0"
    end

    if(outputTbl["tftpMgmtStatus"] == "2") then
        return "OK", "TFTPMGMT_ENABLE_TR69", outputTbl
    end

    return "OK", "STATUS_OK", outputTbl
end

----------------------------------------------------------------------------------
-- @name gui.administration.tftpMgmt.set
--
-- @description This function sets the tftpMgmt
--
-- @return
--
-- @description This routine is used by both HYDROGEN & ATA.
--
function gui.administration.tftpMgmt.set (inputTbl)

    local query = "_ROWID_='1'"
    local tftpMgmtRow = db.getRowWhere ("tftpMgmtTbl", query, false);
    local tr69Row = db.getRowWhere ("tr69Config", query, false);
    local tftpMgmtMethod
    local tftp_url

    -- proceed if tr is enabled only
    if (tr69Row["tr69Status"] == "0") then
        return "ERROR", "TFTPMGMT_ENABLE_TR69"
    end

    -- update table and return in case of disabling tftpMgmt
    if(inputTbl["tftpMgmtStatus"] == "0") then
        -- kill the corresponding process and residue pid file
        os.execute("killall tftpMgmtConfig")
        os.execute("rm -rf /var/tftpMgmt.pid")
    tftpMgmtRow["tftpMgmtStatus"] = "0"
    tftpMgmtRow = util.addPrefix(tftpMgmtRow,"tftpMgmtTbl.")
    db.update ("tftpMgmtTbl", tftpMgmtRow, tftpMgmtRow["tftpMgmtTbl._ROWID_"]);
    return "OK", "STATUS_OK"
    end

    -- if tftpMgmtConfig is running in backend and pid file exists do nothing
    -- elseif no process but still pid file exists remove pid file and proceed
    -- further since process may get exited while trying to download file from
    -- unreachable or unresolvable tftp server
    os.execute("ps | grep tftpMgmtConfig | grep -v grep > /tmp/tftpStatus.txt")
    local filep = io.open("/tmp/tftpStatus.txt", "r")
    if (filep == nil) then
        return "ERROR"
    end

     local tftpStatus = filep:read("*l")
     if(tftpStatus) then
         --:nothing todo
    else
         if(util.fileExists("/var/tftpMgmt.pid") == true) then
             os.execute("rm -rf /var/tftpMgmt.pid")
         end
    end


    if(inputTbl["dhcpOption"] == "0") then
        -- sanity on tftp url
    tftp_url = inputTbl["tftpMgmtUrl"]
    if(string.match(tftp_url, "tftp:") == nil) then
       return "ERROR","TFTPMGMT_INVALID_URL"
 end

    local urlArr = util.split (tftp_url, "//");
    if (urlArr[2] == nil or urlArr[2] == "" or urlArr[2] == " ") then
     return "ERROR","TFTPMGMT_INVALID_URL"
    end

    local urlArr2 = util.split(urlArr[2],"/")
    if(urlArr2[1] == nil or urlArr2[1] == "" or urlArr2[1] == " " or urlArr2[2] == nil or urlArr2[2] == "" or urlArr2[2] == " ") then
     return "ERROR","TFTPMGMT_INVALID_URL"
    end

    -- tftpMgmtMethod has values 0 - auto configuaration using dhcp options 66 && 67
    -- 1 - manually giving URl from UI
    tftpMgmtMethod = "1"
    elseif(inputTbl["dhcpOption"] == "1") then
        if(util.fileExists("/tmp/tftp_url.txt") == false) then
            -- no url file exists nad proceeding further in dhcp options case
            -- is useless
            -- so throw out an error to user such that
            -- he will be prompted to do use automatic get ip for wan and
            -- try to get Url
            return "ERROR","TFTPMGT_NO_URL_FILE"
        end
    tftpMgmtMethod = "0"
    end
    -- TODO: this is really crappy, need to get the url fromdb
    require "tftpMgmtLib"
    local status, errCode = tftpMgmtLib.tftpMgmtConfigure (tftpMgmtMethod, "/tmp/tftp_url.txt",
                                                           "/var/tftpMgmt.pid", tftp_url,
                                                           "/tmp/system.db");
    if (status ~= 0) then
        return status, errCode
    end

    return "OK", "STATUS_OK"
end

----------------------------------------------------------------------------------
-- @name gui.administration.remoteMgmt.get
--
-- @description This function gets the remote mgmt configuration information
--
-- @return
--
function gui.administration.remoteMgmt.get (pageReload)
    -- include
    require "teamf1lualib/httpsMgmt"
    require "teamf1lualib/upnp"
   
    -- update upnp ports
	if (pageReload == "0") then
   		upnp.openPortsGet()
	end

    --locals 
    local configTbl = {}
    debug.Debugger("Calling  httpsMgmt.configGet")
    --getting the values from 'httpsMgmt' table
    configTbl = httpsMgmt.configGet()
    if(configTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    configTbl["httpsMgmtIP1"] = util.filterXSSChars (configTbl["httpsMgmtIP1"])
    configTbl["httpsMgmtIP2"] = util.filterXSSChars (configTbl["httpsMgmtIP2"])
    configTbl["httpsMgmtPort"] = util.filterXSSChars (configTbl["httpsMgmtPort"])

    -- return
    return "OK", "STATUS_OK", configTbl
end

----------------------------------------------------------------------------------
-- @name gui.administration.lan.remoteMgmt.get
--
-- @description This function gets the tr69 configuration information
--
-- @return
--
-- @description This routine is used by both HYDROGEN & ATA.
--
function gui.administration.lan.remoteMgmt.get ()

    local page = {}

    -- lan https mgmt
    local query = "_ROWID_='2'"
    local lanMgmtTbl = db.getRowWhere ("accessMgmt", query, false)
    page.accessMgmtEnable = lanMgmtTbl["accessMgmtEnable"];

    -- return
 return "OK", "STATUS_OK", page
end

----------------------------------------------------------------------------------
-- @name gui.administration.remoteMgmt.set
--
-- @description This function sets the remote mgmt information
--
-- @return
--
function gui.administration.remoteMgmt.set (remoteMgmtCfg)
    -- require
    require "teamf1lualib/httpsMgmt"

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg
    local query
    local portRow = {}
    local staticPorts = {}
    local matched = 0
    -- static ports 
    staticPorts["ports"] = {9999,53,21,80,7547,16000,514,37000}

    --Check for port to be configure should not be used any other place
    if (remoteMgmtCfg["httpsMgmtEnable"] ~= nil and remoteMgmtCfg["httpsMgmtEnable"] == "1") then
        -- Support only a specific IP Adress
        remoteMgmtCfg["httpsMgmtAccessType"] = 2;
        query = "intPort = '" .. remoteMgmtCfg["httpsMgmtPort"] .. "'" .. " or extPort = '" .. remoteMgmtCfg["httpsMgmtPort"] .. "'"
        portRow = db.getRowWhere ("upnpPortMap", query, false)
        if (portRow ~= nil) then
            return "ERROR", "PORT_ALREADY_IN_USE"
        end
		if (UNIT_INFO ~= "ODU") then
		if(not(util.fileExists ("/pfrm2.0/HW_NO_USB"))) then
		local ftpRow = db.getRow ("ftpd", "_ROWID_", "1")
        if (ftpRow == nil) then
            return "ERROR", "Configuration Update Failed"
        end
		if ((ftpRow ["ftpd.enable"] == "1") and (ftpRow ["ftpd.portNumber"] == remoteMgmtCfg["httpsMgmtPort"])) then
			return "ERROR","PORT_ALREADY_IN_USE"
		end
		end
		end
        
        -- Adding check to restrict user use any port clashed btw 1-1024, but should
        -- be allowed to configure for ports 443 and 80.
        if ((tonumber (remoteMgmtCfg ["httpsMgmtPort"]) > 1 and tonumber (remoteMgmtCfg ["httpsMgmtPort"]) < 1024) and
            (tonumber(remoteMgmtCfg["httpsMgmtPort"]) ~= 443 and tonumber (remoteMgmtCfg["httpsMgmtPort"]) ~= 80)) then
            return "ERROR", "RESERVED_PORT_CANNOT_USE"
        end
        
        -- adding checks for statically configured ports.
        for p, q in pairs (staticPorts) do
            for pp, qq in pairs (q) do
                if (tonumber (remoteMgmtCfg ["httpsMgmtPort"]) == qq) then
                    matched = 1
                    break
                end
            end
        end
    
        if (matched == 1) then
            return "ERROR","PORT_ALREADY_IN_USE"
        end
    
        if (tonumber(remoteMgmtCfg["httpsMgmtPort"]) ~= 443 and tonumber (remoteMgmtCfg["httpsMgmtPort"]) ~= 80) then
            -- function already exists so we are using for checking if ports are
            -- already opened.
            require "fwPortTriggerLuaLib"
            local errPort = fwPortTriggerLuaLib.isIPv4PortOpen (remoteMgmtCfg["httpsMgmtPort"])
            if (tonumber(errPort) == 1) then
                -- Check that configured port is used in remote mgmt then skip
                query = "httpsMgmtPort = '" .. remoteMgmtCfg["httpsMgmtPort"] .. "'"
                portRow = db.getRowWhere ("httpsMgmt", query, false)
                if (portRow == nil) then
                    return "ERROR", "PORT_ALREADY_IN_USE"
                end
            end
        end
    end

    --setting the new configuration in the table
    status, errMsg = httpsMgmt.configSet(remoteMgmtCfg)

    if (status == "OK") then
        db.save()
    end
    
    --return
    return status, errMsg
end

----------------------------------------------------------------------------------
-- @name gui.administration.lan.remoteMgmt.set
--
-- @description This function gets the tr69 configuration information
--
-- @return
--
-- @description This routine is used by both HYDROGEN & ATA.
--
function gui.administration.lan.remoteMgmt.set (remoteMgmtCfg)

    -- configure lan https mgmt
    local query = "_ROWID_='2'"
    local errorCode, statusMsg
    local lanHttpsMgmtTbl = db.getRowWhere ("accessMgmt", query, true);
    if (remoteMgmtCfg["accessMgmtEnable"] ~= lanHttpsMgmtTbl["accessMgmt.accessMgmtEnable"]) then
        lanHttpsMgmtTbl["accessMgmt.accessMgmtEnable"] = remoteMgmtCfg["accessMgmtEnable"]
        db.update ("accessMgmt", lanHttpsMgmtTbl, lanHttpsMgmtTbl["accessMgmt._ROWID_"]);
    end

    -- updating bonjour default service table before the commit transaction
    local bonjourTbl = {}
    local bonjourServiceTbl = {}
    local ethaddress = db.getAttribute ("environment", "name", "ethaddr", "value")
    local name = db.getAttribute ("environment", "name", "product_name", "value")
    local MAC_LSB_6 = util.split(ethaddress, ":")
    BNJR_SERVICE_INSTANCE_NAME=name .. MAC_LSB_6[4] .. MAC_LSB_6[5] .. MAC_LSB_6[6]
    BNJR_SERVICE_TYPE="tcp"
    BNJR_SERVICE_DOMAIN="local"
    DEFAULT_LAN_INTERFACE = "IF2"
    BNJR_SERVICE_INTERFACE=DEFAULT_LAN_INTERFACE
    if(remoteMgmtCfg["accessMgmtEnable"] == "1") then
        bonjourServiceTbl = db.getRowWhere ("bonjourDefaultServices", "serviceName='http'", false)
        if(bonjourServiceTbl ~= nil) then
            errorCode, statusMsg = db.deleteRowWhere ("bonjourDefaultServices", "serviceName='http'", false)
            if (errorCode == 1) then
                errorCode = "OK"
            end
            if (errorCode ~= "OK") then
               return "ERROR", "OPERATION_NOT_SUCCEEDED"
            end
        end
        -- adding a row for https service
        bonjourTbl["bonjourDefaultServices.serviceID"] = BNJR_SERVICE_INSTANCE_NAME
        bonjourTbl["bonjourDefaultServices.serviceName"] = "https"
        bonjourTbl["bonjourDefaultServices.serviceType"] = BNJR_SERVICE_TYPE
        bonjourTbl["bonjourDefaultServices.domainName"] = BNJR_SERVICE_DOMAIN
        bonjourTbl["bonjourDefaultServices.LogicalIfName"] = BNJR_SERVICE_INTERFACE
        bonjourTbl["bonjourDefaultServices.portNumber"] = "443"
        bonjourTbl["bonjourDefaultServices.textRecord"] = "path=/platform.cgi"
        db.insert ("bonjourDefaultServices", bonjourTbl)

    else
        bonjourServiceTbl = db.getRowWhere ("bonjourDefaultServices", "serviceName='https'", false)
        if(bonjourServiceTbl ~= nil) then
            errorCode, statusMsg = db.deleteRowWhere ("bonjourDefaultServices", "serviceName='https'", false)
            if (errorCode == 1) then
                errorCode = "OK"
            end
            if (errorCode ~= "OK") then
               return "ERROR", "OPERATION_NOT_SUCCEEDED"
            end
        end
        -- adding a row for http service
        bonjourTbl["bonjourDefaultServices.serviceID"] = BNJR_SERVICE_INSTANCE_NAME
        bonjourTbl["bonjourDefaultServices.serviceName"] = "http"
        bonjourTbl["bonjourDefaultServices.serviceType"] = BNJR_SERVICE_TYPE
        bonjourTbl["bonjourDefaultServices.domainName"] = BNJR_SERVICE_DOMAIN
        bonjourTbl["bonjourDefaultServices.LogicalIfName"] = BNJR_SERVICE_INTERFACE
        bonjourTbl["bonjourDefaultServices.portNumber"] = "80"
        bonjourTbl["bonjourDefaultServices.textRecord"] = "path=/platform.cgi"
        db.insert ("bonjourDefaultServices", bonjourTbl)
     end

     db.save2 ()
     return "OK", "STATUS_OK"
end

----------------------------------------------------------------------------------
-- @name gui.administration.snmp.get ()
--
-- @description This function gets the configuration information for snmp
--
-- @return
--
function gui.administration.snmp.get()

    -- require
    require "teamf1lualib/net-snmp"
    require "teamf1lualib/platform"

    -- locals
    local snmpInfoTbl = {}
    local snmpTbl = {}
    local snmpTrapTbl = {}
    local networkTbl = {}
    local snmpAccessCtrlTbl = {}
    local snmpv3usersTbl = {}
    local nilTable = {}
    local query = "_ROWID_ = 1"
    local errCode,statusMsg

    snmpInfoTbl.networks = {}
    -- get snmp related information
    snmpTbl = db.getRowWhere("snmp",query,false)
    -- if table is nil return error with nilTable
    if(snmpTbl == nil) then
        return "ERROR","DB_ERROR_TRY_AGAIN",nilTable
    end
    -- get snmpTrap,snmpAccessControl related information
    snmpTrapTbl= db.getRowWhere("snmpTrap",query,false)
    snmpAccessCtrlTbl = db.getRowWhere("snmpAccessControl",query,false)
    -- initially snmpTrap & snmpACcessControl table can be nil so no need to
    -- check them whether they are nil and return error
    -- getting snmpv3Users information
    snmpv3usersTbl = db.getRowWhere ("snmpv3Users",query,false)-- using snmp for admin user only
    --if snmpv3Users table is nil return error with nilTable
    if(snmpv3usersTbl == nil) then
        return "ERROR","DB_ERROR_TRY_AGAIN",nilTable
    end
    -- get snmp table related information
    snmpInfoTbl["snmpEnable"] = snmpTbl["snmpEnable"]
    snmpInfoTbl["snmpVersion"] = snmpTbl["snmpVersion"]
    snmpInfoTbl["snmpTrapEnable"] = snmpTbl["snmpTrap"]

    --Fill the Dropdown with LAN networks for GUI display.
      networkTbl = platform.availableNetworkGet ()
      if (networkTbl == nil) then
        return "ERROR", "AVAILABLE_NETWORKS_GET_FAILED"
      end
    for i,v in pairs (networkTbl) do
        snmpInfoTbl.networks[i] = {}
        snmpInfoTbl.networks[i].networkname = v["networkName"]
    end
    snmpInfoTbl["networkName"] = db.getAttribute ("networkInterface","LogicalIfName", snmpTbl["LogicalIfName"], "networkName")

    -- get snmpTrap related information if table exists
    if (snmpTrapTbl ~= nil and snmpTrapTbl["port"] ~= nil) then
        snmpInfoTbl["port"] = snmpTrapTbl["port"]
    else
        snmpInfoTbl["port"] = ""
    end

    if ( snmpTrapTbl ~= nil and snmpTrapTbl["ipAddr"] ~= nil) then
        snmpInfoTbl["ipAddrTrap"] = snmpTrapTbl["ipAddr"]
    else
        snmpInfoTbl["ipAddrTrap"] = ""
    end

    -- get snmpAccessControl related information if table exists
    if ( snmpAccessCtrlTbl ~= nil and snmpAccessCtrlTbl["commName"] ~= nil) then
        snmpInfoTbl["commonName"] = snmpAccessCtrlTbl["commName"]
    else
        snmpInfoTbl["commonName"] = ""
    end

    if ( snmpAccessCtrlTbl ~= nil and snmpAccessCtrlTbl["accessType"] ~= nil) then
        snmpInfoTbl["accessType"] = snmpAccessCtrlTbl["accessType"]
    else
        snmpInfoTbl["accessType"] = ""
    end

     if ( snmpAccessCtrlTbl ~= nil and snmpAccessCtrlTbl["ipAddr"] ~= nil) then
        snmpInfoTbl["ipAddrAccess"] = snmpAccessCtrlTbl["ipAddr"]
    else
        snmpInfoTbl["ipAddrAccess"] = ""
    end

    if ( snmpAccessCtrlTbl ~= nil and snmpAccessCtrlTbl["subnetMask"] ~= nil) then
        snmpInfoTbl["subnetMask"] = snmpAccessCtrlTbl["subnetMask"]
    else
        snmpInfoTbl["subnetMask"] = ""
    end

    -- get snmpv3users related information--[[
    snmpInfoTbl["userName"] = snmpv3usersTbl["userName"]
    snmpInfoTbl["securityLevel"] = snmpv3usersTbl["securityLevel"]
    snmpInfoTbl["authAlgo"] = snmpv3usersTbl["authAlgo"]
    snmpInfoTbl["authPassword"] = util.mask (snmpv3usersTbl["authPassword"])
    snmpInfoTbl["privAlgo"] = snmpv3usersTbl["privAlgo"]
    snmpInfoTbl["privPassword"] = util.mask (snmpv3usersTbl["privPassword"])
    -- check whether the table filled or not,if nil retrun error with nilTable
    if(snmpInfoTbl == nil) then
        return "ERROR","DB_ERROR_TRY_AGAIN",nilTable
    end
    errorCode = "OK"
    statusMsg = ""

    -- return
    return errorCode,statusMsg,snmpInfoTbl
end

----------------------------------------------------------------------------------
-- @name gui.administration.snmp.set ()
--
-- @description This function sets the configuration for snmp
--
-- @return
--
function gui.administration.snmp.set (snmpCfg)

    --require
    require "teamf1lualib/net-snmp"

    --locals
    local snmpTbl = {}
    local snmpTrapTbl = {}
    local snmpAccessCtrlTbl = {}
    local snmpv3UsersTbl = {}
    local query = "_ROWID_=1" -- we are having onle one row in each table.User cannot add multiple entries as per GUI
    local result = ""
    local val = ""
    local errorCode, statusMsg
    -- if not allowed to edit
 if (ACCESS_LEVEL ~=0) then
     return "ACCESS_DENIED", "ADMIN_REQD"
 end

    -- querying the snmp table
    snmpTbl = db.getRowWhere("snmp",query,false)
    -- if snmp table is nil return error
    if(snmpTbl == nil) then
        return "ERROR","DB_ERROR_TRY_AGAIN"
    end

    --updating snmp table with new configuration
    snmpTbl["snmpEnable"] = snmpCfg["snmpEnable"]

    if(snmpCfg["snmpVersion"] ~= nil) then
     snmpTbl["snmpVersion"] = snmpCfg["snmpVersion"]
    end

    if(snmpCfg["snmpTrapEnable"] ~= nil) then
     snmpTbl["snmpTrap"] = snmpCfg["snmpTrapEnable"]
    else
 snmpTbl["snmpTrap"] = "0"
    end

    if (snmpCfg["snmpEnable"] ~= "0") then
        snmpTbl["LogicalIfName"] = db.getAttribute ("networkInterface", "networkName", snmpCfg["networkName"], "LogicalIfName")
        require "ifDevLib"
        require "teamf1lualib/nimf"

        local net = ifDevLib.netIfInfoGet (snmpTbl["LogicalIfName"]);

        if (net == nil) then
            return "ERROR","NETWORK_INFORMATION_FAILED"
        end

        if(snmpCfg["ipAddrAccess"] ~= nil) then
            if (nimfLib.isAddrInNetwork(net["interfaceName"],snmpCfg["ipAddrAccess"]) ~= 1) then
                return "ERROR","IPADDRESS_NOT_IN_NETWORK_SUBNET"
            end
        end

        if((snmpCfg["ipAddrTrap"] ~= nil) and (snmpCfg["ipAddrTrap"] ~= '')) then
            if (nimfLib.isAddrInNetwork(net["interfaceName"],snmpCfg["ipAddrTrap"]) ~= 1) then
                return "ERROR","IPADDRESS_NOT_IN_NETWORK_SUBNET"
            end
        end
    end

    -- checking the ipaddress belongs to the same subnet
    if (snmpCfg["snmpEnable"] ~= "0") then
    end

    --db.beginTransation
    db.beginTransaction()
    -- adding prefix
    snmpTbl = util.addPrefix(snmpTbl,"snmp.")
    errorCode,statusMsg = snmp.snmp_config(snmpTbl,1,"edit")
    if(errorCode ~= "OK") then
        db.rollback() -- else rollback
        return errorCode,statusMsg
    end

    -- updating bonjour default service table before the commit transaction
    local bonjourTbl = {}
    local bonjourServiceTbl = {}
    local ethaddress = db.getAttribute ("environment", "name", "ethaddr", "value")
    local name = db.getAttribute ("environment", "name", "product_name", "value")
    local MAC_LSB_6 = util.split(ethaddress, ":")
    BNJR_SERVICE_INSTANCE_NAME=name .. MAC_LSB_6[4] .. MAC_LSB_6[5] .. MAC_LSB_6[6]
    BNJR_SERVICE_TYPE="udp"
    BNJR_SERVICE_DOMAIN="local"
    DEFAULT_LAN_INTERFACE = "IF2"
    BNJR_SERVICE_INTERFACE=DEFAULT_LAN_INTERFACE

    if(snmpCfg["snmpEnable"] == "1") then
        bonjourTbl["bonjourDefaultServices.serviceID"] = BNJR_SERVICE_INSTANCE_NAME
        bonjourTbl["bonjourDefaultServices.serviceName"] = "snmp"
        bonjourTbl["bonjourDefaultServices.serviceType"] = BNJR_SERVICE_TYPE
        bonjourTbl["bonjourDefaultServices.domainName"] = BNJR_SERVICE_DOMAIN
        bonjourTbl["bonjourDefaultServices.LogicalIfName"] = BNJR_SERVICE_INTERFACE
        bonjourTbl["bonjourDefaultServices.portNumber"] = "162"
        bonjourTbl["bonjourDefaultServices.textRecord"] = ""
        db.insert ("bonjourDefaultServices", bonjourTbl)
        errorCode = "OK"
        statusMsg = "STATUS_OK"
    else
        bonjourServiceTbl = db.getRowWhere ("bonjourDefaultServices", "serviceName='snmp'", false)
        if(bonjourServiceTbl ~= nil) then
            errorCode, statusMsg = db.deleteRowWhere ("bonjourDefaultServices", "serviceName='snmp'", false)
            if (errorCode == 1) then
                errorCode = "OK"
                statusMsg = "STATUS_OK"
            end
            if (errorCode ~= "OK") then
               return "ERROR", "OPERATION_NOT_SUCCEEDED"
            end
        end
     end

    -- if disabling snmp then no need for further configuration commit the
    -- transaction and retrun from here
    if(snmpCfg["snmpEnable"] == "0") then

        if(errorCode == "OK") then
            db.commitTransaction() -- commit transaction if everything is fine
            db.save2() -- save changes, to persist after reboot
        else
            db.rollback() -- else rollback
        end

        return errorCode,statusMsg
    end

    if((snmpCfg["snmpTrapEnable"] ~= nil) and (snmpCfg["snmpTrapEnable"] == "1")) then

     -- cheking whether snmpTrap table having any rows or not
     result = db.existsRowWhere ("snmpTrap",query)
     snmpTrapTbl = db.getRowWhere("snmp", query, false)

 if(snmpCfg["ipAddrTrap"] ~= nil) then
      snmpTrapTbl["ipAddr"] = snmpCfg["ipAddrTrap"]
     end

     if(snmpCfg["port"] ~= nil) then
      snmpTrapTbl["port"] = snmpCfg["port"]
     end

     -- fill new configuration into the table
     if(snmpCfg["snmpVersion"] ~= nil) then
         snmpTrapTbl["snmpVersion"] = snmpCfg["snmpVersion"]
     end

     -- update community only if version is v1/v2c only
     if((snmpCfg["snmpVersion"] == "v1") or (snmpCfg["snmpVersion"] == "v2c")) then
         if(snmpCfg["commonName"] ~= nil) then
              snmpTrapTbl["commName"] = snmpCfg["commonName"]
         end
     end

     -- adding prefix
     snmpTrapTbl = util.addPrefix(snmpTrapTbl,"snmpTrap.")

     if(result == false) then -- no row exists table is nil,so operation is add
         if (snmpCfg["snmpVersion"] == "v3") then
              snmpTrapTbl["snmpTrap.commName"] = ""
         end
         errorCode,statusMsg = snmp.snmpTrap_config (snmpTrapTbl,-1,"add")
     else -- row exists table is not nil ,so operation is edit
         errorCode,statusMsg = snmp.snmpTrap_config (snmpTrapTbl,1,"edit")
     end

     if(errorCode ~= "OK") then
         db.rollback() -- rollback
         return errorCode,statusMsg
     end
    else
     snmpTrapTbl = db.getRowWhere("snmpTrap",query,false)
        if (snmpTrapTbl ~= nil) then
             errorCode,statusMsg = snmp.snmpTrap_config(snmpTrapTbl,snmpTrapTbl["_ROWID_"],"delete")
        end

 if(errorCode ~= "OK") then
             db.rollback() -- rollback
             return errorCode,statusMsg
     end
    end

    if((snmpCfg["snmpVersion"] == "v1") or (snmpCfg["snmpVersion"] == "v2c")) then
        -- cheking whether snmpAccessControl table having any rows or not
        val = db.existsRowWhere("snmpAccessControl",query)
        -- fill the new configuration only if version is v1/v2c
        if(snmpCfg["commonName"] ~= nil) then
            snmpAccessCtrlTbl["commName"] = snmpCfg["commonName"]
        end
        if(snmpCfg["ipAddrAccess"] ~= nil) then
            snmpAccessCtrlTbl["ipAddr"] = snmpCfg["ipAddrAccess"]
            snmpAccessCtrlTbl["subnetMask"] = snmpCfg["subnetMask"]
        end
        if(snmpCfg["accessType"] ~= nil) then
            snmpAccessCtrlTbl["accessType"] = snmpCfg["accessType"]
        end
        -- adding prefix
        snmpAccessCtrlTbl = util.addPrefix(snmpAccessCtrlTbl,"snmpAccessControl.")
        if(val == false) then -- no rows exists table is nil, so operation is add
            errorCode,statusMsg = snmp.snmpAccessControl_config(snmpAccessCtrlTbl,-1,"add")
        else -- row exists table is not nil, so operation is edit
            errorCode,statusMsg = snmp.snmpAccessControl_config(snmpAccessCtrlTbl,1,"edit")
        end
        if(errorCode ~= "OK") then
            db.rollback() -- rollback
            return errorCode,statusMsg
        end
    end
    -- if snmpversion is v3 only then proceed
    if(snmpCfg["snmpVersion"] == "v3") then

        -- first delete the Access control Table entries
        -- get snmpAccessControl Table information
        snmpAccessCtrlTbl = db.getRowWhere("snmpAccessControl",query,false)
        if (snmpAccessCtrlTbl ~= nil) then
            errorCode,statusMsg = snmp.snmpAccessControl_config(snmpAccessCtrlTbl,snmpAccessCtrlTbl["_ROWID_"],"delete")
        end

        -- get snmpv3users information
        snmpv3UsersTbl = db.getRowWhere("snmpv3Users",query,false)
        -- if snmpv3Users table is nil return error
        if(snmpv3UsersTbl == nil) then
            return "ERROR","DB_ERROR_TRY_AGAIN"
        end
        -- having only admin user as snmpv3User so providng read/write
        -- privilage.There is no option in GUI to update it.
        snmpv3UsersTbl["accessType"] = "RWUSER"
        -- updating snmpv3Users table with new configuration, if respective
        -- fields are not null
        if(snmpCfg["securityLevel"] ~= nil) then
            snmpv3UsersTbl["securityLevel"] = snmpCfg["securityLevel"]
        end
        if(snmpCfg["authAlgo"] ~= nil) then
            snmpv3UsersTbl["authAlgo"] = snmpCfg["authAlgo"]
        end

        if(snmpCfg["authPassword"] ~= nil) then
            if (util.isAllMasked (snmpCfg["authPassword"]) == false) then
                snmpv3UsersTbl["authPassword"] = snmpCfg["authPassword"]
            end
        end
        if(snmpCfg["privAlgo"] ~= nil) then
            snmpv3UsersTbl["privAlgo"] = snmpCfg["privAlgo"]
        end
        if(snmpCfg["privPassword"] ~= nil) then
            if (util.isAllMasked (snmpCfg["privPassword"]) == false) then
                snmpv3UsersTbl["privPassword"] = snmpCfg["privPassword"]
            end
        end
        -- adding prefix
        snmpv3UsersTbl = util.addPrefix(snmpv3UsersTbl, "snmpv3Users.")
        errorCode,statusMsg = snmp.snmpv3Users_config(snmpv3UsersTbl,1,"edit")
    end

    if(errorCode == "OK") then
        db.commitTransaction() -- commit transaction if everything is fine
        db.save2() -- save changes, to persist after reboot
    else
        db.rollback() -- else rollback
        return errorCode,statusMsg
    end

    --return
    return errorCode,statusMsg
end

----------------------------------------------------------------------------------
-- @name gui.administration.systemInfo.get ()
--
-- @description This function gets the system
-- Information form "system" table.
--
-- @return

function gui.administration.systemInfo.get()

    local snmpSysInfo = {}
    local query = "_ROWID_=1"

 snmpSysInfo = db.getRowWhere("system", query, false)

    if (snmpSysInfo == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN", nil
    end

    return "OK", "STATUS_OK", snmpSysInfo

end

----------------------------------------------------------------------------------
-- @name gui.administration.systemInfo.set ()
--
-- @description This function sets the system information
--
-- @return
--
function gui.administration.systemInfo.set(systemCfg)

    --require
    require "teamf1lualib/net-snmp"
    require "teamf1lualib/pdinfo"

    --locals
    local sysInfoTbl = {}
    local query= "_ROWID_= 1"
    local errorCode,statusMsg

    -- if not allowed to edit
 if (ACCESS_LEVEL ~=0) then
     return "ACCESS_DENIED", "ADMIN_REQD"
 end
    -- querying the system table
    sysInfoTbl = db.getRowWhere("system",query,false)
    -- if system is nil return error
    if(sysInfoTbl == nil) then
        return "ERROR","DB_ERROR_TRY_AGAIN"
    end
    -- fill the new configuration
    sysInfoTbl["sysContact"] = systemCfg["sysContact"]
    sysInfoTbl["sysLoc"] = systemCfg["sysLoc"]
    sysInfoTbl["name"] = systemCfg["name"]

    local result = pdinfo.setSysName(sysInfoTbl["name"])

    if(result == -1) then
      return "ERROR", "SYS_NAME_CONFIG_FAILED"
    end

    -- adding prefix
    sysInfoTbl = util.addPrefix(sysInfoTbl,"system.")
    --db.beginTransation
    db.beginTransaction()
    errorCode,statusMsg = snmp.system_config (sysInfoTbl,1, "edit")
    if(errorCode == "OK") then
        db.commitTransaction() -- commit transaction
        db.save2() -- save changes,to persist after reboot
    else
        db.rollback() -- else rollback
        return errorCode,statusMsg
    end

    --return
    return errorCode,statusMsg
end

----------------------------------------------------------------------------------
-- @name gui.administration.igmp.get ()
--
-- @description This function gets the Igmp configuration which is currently set
-- in the device.
--
-- @return
--
-- Main table:-
-- ----------
-- igmpCfg ==> (This is the actual table returned by this function.)
-- {
-- IgmpEnable
-- upstreamInterface
-- downstreamInterface
-- _ROWID_
-- allowNetworks [Lua table]
-- wanNetworks [Lua Array]
-- netAssocTable [Lua table]
-- }
--
-- Sub tables:-
-- -----------
-- allowNetworks ==> (This is the subtable of "igmpCfg", and contains
-- allowed networks information)
-- {
-- networkAddr
-- maskLength
-- }
--
-- wanNetworks ==> (This is the Lua "Array" of "igmpCfg", which contains
-- the upstream Networks List to be displayed on Frontend)
-- {
-- WAN_Network-1
-- WAN_Network-2
-- WAN_Network-3
-- .
-- .
-- .
-- }
--
-- netAssocTable ==> (This is the subtable of "igmpCfg", which
-- contains Network mappings..Used for JS logic)
-- {
-- downstreamNet
-- upstreamNet
-- }
--
function gui.administration.igmp.get()

    local igmpCfg = {}
    local nilTable = {}
    local lanNetTable = {}
    local wanNetTable = {}
    local assocNets = {}
    local query= "_ROWID_= 1"
    local index = 1
    local indexW = 1
    local duplicateNet = 0

    igmpCfg = db.getRowWhere("Igmp", query, false)
    if(igmpCfg == nil) then
        return "ERROR","DB_ERROR_TRY_AGAIN",nilTable
    end

    -- Query - 1
    query = "zoneType='secure' and LogicalIfName='IF2'"
 -- getting the info
 lanNetTable = db.getRowsWhere ("networkInterface", query, false);
    if(lanNetTable == nil) then
        return "ERROR","DB_ERROR_TRY_AGAIN",nilTable
    end

    -- Query - 2
    query = "zoneType='insecure'"
 -- getting the info
 wanNetTable = db.getRowsWhere ("networkInterface", query, false);
    if(wanNetTable == nil) then
        return "ERROR","DB_ERROR_TRY_AGAIN",nilTable
    end

    for i,rows in pairs (wanNetTable) do
        if(rows["LogicalIfName"] == igmpCfg["upstreamInterface"]) then
            igmpCfg["upstreamInterface"] = rows["networkName"]
        end
    end

    igmpCfg.netAssocTable = {}
    igmpCfg.wanNetworks = {}
    for i,rows in pairs (lanNetTable) do

        -- Find the downstream network Name selected by user...
        if (rows["LogicalIfName"] == igmpCfg["downstreamInterface"]) then
            igmpCfg["downstreamInterface"] = rows["networkName"]
        end

        local var = util.split(rows["connectionType"], ":")
        if (var[1] == "ROUTED") then
            igmpCfg.netAssocTable[index] = {}
            igmpCfg.netAssocTable[index]["downstreamNet"] = rows["networkName"]
            igmpCfg.netAssocTable[index]["upstreamNet"] = var[2]

            -- Prevent filling duplicate entries in UpStream DropDown..!
            if(#igmpCfg.wanNetworks == 0) then
                igmpCfg.wanNetworks[indexW] = {}
                igmpCfg.wanNetworks[indexW] = var[2]
                indexW = indexW + 1
            else
                for j,k in pairs (igmpCfg.wanNetworks) do
                    if(k == var[2]) then
                        duplicateNet = 1
                    end
                end

                if (duplicateNet ~= 1) then
                    igmpCfg.wanNetworks[indexW] = {}
                    igmpCfg.wanNetworks[indexW] = var[2]
                    indexW = indexW + 1
                end
            end
            duplicateNet = 0
            index = index + 1
        end
    end

    igmpCfg.allowNetworks = {}
    igmpCfg.allowNetworks = db.getTable("allowedNets", false)
    if(igmpCfg.allowNetworks == nil) then
        igmpCfg.allowNetworks = nilTable
    end

    for i,v in ipairs (igmpCfg.allowNetworks) do
        igmpCfg.allowNetworks[i] = {}
        igmpCfg.allowNetworks[i] = v
        igmpCfg.allowNetworks[i].networkAddr = util.filterXSSChars(v["networkAddr"])
        igmpCfg.allowNetworks[i].maskLength = util.filterXSSChars(v["maskLength"])
    end

    return "OK","STATUS_OK", igmpCfg

end

----------------------------------------------------------------------------------
-- @name gui.administration.igmp.set ()
--
-- @description This function set the Igmp configuration into the device .
--
-- @return "OK", "STATUS_OK" on SUCCESS
-- "ERROR", "IGMP_CONFIG_FAILED" on FAILURE
--
function gui.administration.igmp.set(igmpCfg)

    local igmpInfoTbl = {}
    local query= "_ROWID_= 1"
    local errMsg
    local statusMsg
    local valid

    -- if not allowed to edit
 if (ACCESS_LEVEL ~= 0) then
  return "ACCESS_DENIED", "ADMIN_REQD"
 end

    igmpInfoTbl = db.getRowWhere("Igmp", query, false)
    if(igmpInfoTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    igmpInfoTbl["IgmpEnable"] = igmpCfg["IgmpEnable"]
    igmpInfoTbl["allowUpstreamNetworks"] = igmpCfg["allowUpstreamNetworks"]

    if (igmpCfg["IgmpEnable"] ~= "0") then
        if (igmpCfg["upstreamInterface"] ~= nil) then
            igmpInfoTbl["upstreamInterface"] = db.getAttribute("networkInterface", "networkName", igmpCfg["upstreamInterface"], "LogicalIfName")
        end
        if (igmpCfg["downstreamInterface"] ~= nil) then
            igmpInfoTbl["downstreamInterface"] = db.getAttribute("networkInterface", "networkName", igmpCfg["downstreamInterface"], "LogicalIfName")
        end
    end

    --db.beginTransation
    db.beginTransaction()
    igmpInfoTbl = util.addPrefix (igmpInfoTbl, "Igmp.")

    valid = db.update("Igmp", igmpInfoTbl, 1)

    if (valid) then
        db.commitTransaction()
        db.save2()
        return "OK", "STATUS_OK"
    else
        db.rollback()
        return "ERROR", "IGMP_CONFIG_FAILED"
    end

end

----------------------------------------------------------------------------------
-- @name gui.administration.igmp.allowedNets.get()
--
-- @description This function set the Igmp configuration into the device .
--
-- @return Lua Table
--
-- allowedNetTbl
-- {
-- networkAddr
-- maskLength
-- _ROWID_
-- }
--

function gui.administration.igmp.allowedNets.get()
    --locals
    local nilTable = {}
 local allowedNetTbl = {}

 -- Get the list of users from db
 allowedNetTbl = db.getTable ("allowedNets", false)
 if (allowedNetTbl == nil) then
  return "OK", "STATUS_OK", nilTable
 end

 --return
 return "OK", "STATUS_OK", allowedNetTbl
end

----------------------------------------------------------------------------------
-- @name gui.administration.igmp.allowedNets.delete()
--
-- @description This function deletes a set of allowed Networks from the db.
--
-- @return "OK", "STATUS_OK" on SUCCESS
-- "ERROR", "IGMP_NETWORK_DELETE_FAILED" on FAILURE
--
function gui.administration.igmp.allowedNets.delete(rowids)

    require "teamf1lualib/igmp"

 local statusMsg = nil
 local errMsg = nil

    errMsg, statusMsg = igmp.deleteAllowedNetwork(rowids)

    -- save the database
    if (errMsg == "OK") then
        db.save2()
    end

 -- delete quota for this user
 --return
 return errMsg, statusMsg
end

----------------------------------------------------------------------------------
-- @name gui.administration.igmp.allowedNets.add.get()
--
-- @description This function returns a blank table to the Frontend.
--
-- @return "OK", "STATUS_OK", nilTable
--
-- nilTable ==> {
-- networkAddr (should be blank)
-- maskLength (should be blank)
-- }
--
function gui.administration.igmp.allowedNets.add.get()

    local nilTable = {}

    return "OK", "STATUS_OK", nilTable
end

----------------------------------------------------------------------------------
-- @name gui.administration.igmp.allowedNets.add.set()
--
-- @description This function set the Igmp Allowed Networks configuration
-- into the device .
--
-- @return "OK", "STATUS_OK" on SUCCESS
-- ERROR ALLOWED_NETWORK_CONFIG_FAILED on FAILURE
--
function gui.administration.igmp.allowedNets.add.set(igmpAllowNetCfg)

    require "teamf1lualib/igmp"

    local errMsg, statusMsg

    if (ACCESS_LEVEL ~= 0) then
  return "ACCESS_DENIED", "ADMIN_REQD"
 end

    if (igmpAllowNetCfg == nil) then
        return "ERROR", "ALLOWED_NETWORK_CONFIG_FAILED"
    end

    igmpAllowNetCfg = util.addPrefix(igmpAllowNetCfg, "allowedNets.")

    errMsg, statusMsg = igmp.allowedNetworkConfig (igmpAllowNetCfg, -1, "add")
    if(errMsg == "OK") then
        db.save2()
    end

    return errMsg, statusMsg
end

----------------------------------------------------------------------------------
-- @name gui.administration.igmp.allowedNets.edit.get()
--
-- @description This function get the Igmp Allowed Network configuration of a
-- given rowid.
--
-- @return "OK", "STATUS_OK", allowedNetworkTbl on SUCCESS
-- "ERROR", "DB_ERROR_TRY_AGAIN", nilTable on FAILURE
--
-- allowedNetworkTbl
-- {
-- networkAddr
-- maskLength
-- }
--
function gui.administration.igmp.allowedNets.edit.get(rowid)

    local allowedNetworkTbl = {}
    local nilTable = {}
    local query= "_ROWID_= " .. rowid

    -- get the row from db
    allowedNetworkTbl = db.getRowWhere ("allowedNets", query, false)
    if (allowedNetworkTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN", nilTable
    end

    allowedNetworkTbl["networkAddr"] = util.filterXSSChars(allowedNetworkTbl["networkAddr"])
    allowedNetworkTbl["maskLength"] = util.filterXSSChars(allowedNetworkTbl["maskLength"])

    --return
 return "OK", "STATUS_OK", allowedNetworkTbl
end

----------------------------------------------------------------------------------
-- @name gui.administration.igmp.allowedNets.edit.set()
--
-- @description This function set given Igmp Allowed Network configuration
-- into the device .
--
-- @return "OK", "STATUS_OK" on SUCCESS
-- ERROR ALLOWED_NETWORK_CONFIG_FAILED on FAILURE
--
function gui.administration.igmp.allowedNets.edit.set(igmpAllowNetCfg)

    require "teamf1lualib/igmp"

    local errMsg, statusMsg

    if (ACCESS_LEVEL ~= 0) then
  return "ACCESS_DENIED", "ADMIN_REQD"
 end

    if (igmpAllowNetCfg == nil) then
        return "ERROR", "ALLOWED_NETWORK_CONFIG_FAILED"
    end

    igmpAllowNetCfg = util.addPrefix(igmpAllowNetCfg, "allowedNets.")

    errMsg, statusMsg = igmp.allowedNetworkConfig (igmpAllowNetCfg, igmpAllowNetCfg["allowedNets._ROWID_"], "edit")
    if(errMsg == "OK") then
        db.save2()
    end

    return errMsg, statusMsg
end


function gui.administration.radiusClient.set(inputTable, dbFlag)

    --include
    require "teamf1lualib/radius"

    --locals
    local tempInputTablePri = {}
    local CMD_EXEC_SCRIPT   = "/tmp/cmdExecscript.sh"
    local SH_BIN            = "/bin/sh "
if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED")) then
    --if wifi is off, no wifi operation is permiitted
    
    local wifienabled = db.getAttribute("easyMesh","meshInterfacename","bdg2","wifiOn")
    
    if(wifienabled == "0") then
        return "ERROR","wifi Operation is not supported When Wifi is disabled"
    end
end
    -- flag to Enable db operations.
    if (dbFlag == nil) then
        dbFlag = 1
    end

    --if(inputTable["radiusClient.ipType"] == "0" or inputTable["radiusClient.ipType"] == nil)then
    if(inputTable["radiusClient.authserver"] ~= nil) then
        tempInputTablePri["radiusClient.authserver"] = inputTable["radiusClient.authserver"]
        if(inputTable["radiusClient.acctserver"] == nil) then
            tempInputTablePri["radiusClient.acctserver"] = inputTable["radiusClient.authserver"]
        else
            tempInputTablePri["radiusClient.acctserver"] = inputTable["radiusClient.acctserver"]
        end
    end
    --Secondary Radius Server IP
    if(inputTable["radiusClient.authserver2"] ~= nil)then
        tempInputTablePri["radiusClient.secauthserver"] = inputTable["radiusClient.authserver2"]
        if(inputTable["radiusClient.acctserver2"] == nil) then
            tempInputTablePri["radiusClient.secacctserver"] = inputTable["radiusClient.authserver2"]
        else
            tempInputTablePri["radiusClient.secacctserver"] = inputTable["radiusClient.acctserver2"]
        end
    end
  --else
    if(inputTable["radiusClient.authserverIPv6"] ~= nil)then
        tempInputTablePri["radiusClient.authserverIP6"] = inputTable["radiusClient.authserverIPv6"]
        if(inputTable["radiusClient.acctserverIPv6"] == nil) then
            tempInputTablePri["radiusClient.acctserverIP6"] = inputTable["radiusClient.authserverIPv6"]
        else
            tempInputTablePri["radiusClient.acctserverIP6"] = inputTable["radiusClient.acctserverIPv6"]
        end
    end
    --Secondary Radius Server IP
    if(inputTable["radiusClient.authserver2IPv6"] ~= nil)then
        tempInputTablePri["radiusClient.secauthserverIP6"] = inputTable["radiusClient.authserver2IPv6"]
        if(inputTable["radiusClient.acctserver2IPv6"] == nil) then
            tempInputTablePri["radiusClient.secacctserverIP6"] = inputTable["radiusClient.authserver2IPv6"]
        else
            tempInputTablePri["radiusClient.secacctserverIP6"] = inputTable["radiusClient.acctserver2IPv6"]
        end
    end
  --end

    if(inputTable["radiusClient.ipType"] ~= nil) then
        tempInputTablePri["radiusClient.ipType"] = inputTable["radiusClient.ipType"]
    else
        tempInputTablePri["radiusClient.ipType"] = "0"
    end

    tempInputTablePri["radiusClient.authport"] = inputTable["radiusClient.authport"]
    if(inputTable["radiusClient.acctport"] ~= nil)then
        tempInputTablePri["radiusClient.acctport"] = inputTable["radiusClient.acctport"]
    else
        tempInputTablePri["radiusClient.acctport"] = 1813
    end

    if (util.isAllMasked (inputTable["radiusClient.authsecret"]) == false) then
        tempInputTablePri["radiusClient.authsecret"] = inputTable["radiusClient.authsecret"]
        if(inputTable["radiusClient.acctsecret"] == nil)then
            tempInputTablePri["radiusClient.acctsecret"] = inputTable["radiusClient.authsecret"]
        else
            tempInputTablePri["radiusClient.acctsecret"] = inputTable["radiusClient.acctsecret"]
        end
    end

    tempInputTablePri["radiusClient.authtimeout"] = inputTable["radiusClient.authtimeout"]
    tempInputTablePri["radiusClient.authretries"] = inputTable["radiusClient.authretries"]
    tempInputTablePri["radiusClient.authType"] = inputTable["radiusClient.authType"]
    tempInputTablePri["radiusClient.radAccntEnable"] = inputTable["radiusClient.radiusAccounting"]
    tempInputTablePri["radiusClient.interimUpdateInterval"] = inputTable["radiusClient.interimUpdate"]
    if(inputTable["radiusClient.primaryRadiusRetry"] == "1")then
        tempInputTablePri["radiusClient.retryInterval"] = inputTable["radiusClient.primaryRadiusRetryInterval"]
    else
        tempInputTablePri["radiusClient.retryInterval"] = "0"
    end

    --Secondary Radius Server Port
    if(inputTable["radiusClient.authport2"] ~= nil)then
        tempInputTablePri["radiusClient.secauthport"] = inputTable["radiusClient.authport2"]
    elseif (tempInputTablePri["radiusClient.authport"] ~= nil)then
        tempInputTablePri["radiusClient.secauthport"] = inputTable["radiusClient.authport"]
    else
        tempInputTablePri["radiusClient.secauthport"] = 1812
    end

    if(inputTable["radiusClient.acctport2"] ~= nil) then
        tempInputTablePri["radiusClient.secacctport"] = inputTable["radiusClient.acctport2"]
    elseif (tempInputTablePri["radiusClient.acctport"] ~= nil)then
        tempInputTablePri["radiusClient.secacctport"] = inputTable["radiusClient.acctport"]
    else
        tempInputTablePri["radiusClient.secacctport"] = 1813
    end

    --Secondary Radius Server Secret
    if (inputTable["radiusClient.authsecret2"] == nil) then
        tempInputTablePri["radiusClient.secauthsecret"] = tempInputTablePri["radiusClient.authsecret"]
        if(inputTable["radiusClient.acctsecret2"] == nil)then
            tempInputTablePri["radiusClient.secacctsecret"] = tempInputTablePri["radiusClient.secauthsecret"]
        else
            tempInputTablePri["radiusClient.secacctsecret"] = inputTable["radiusClient.acctsecret2"]
        end
    elseif(util.isAllMasked (inputTable["radiusClient.authsecret2"]) == false)then
        tempInputTablePri["radiusClient.secauthsecret"] = inputTable["radiusClient.authsecret2"]
    end

    --Whenever Radius Page is configured FallBack to Primary Radius Server			
    tempInputTablePri["radiusClient.serverinuse"] = 0

    if (dbFlag == 1)then
        db.beginTransaction() -- begin transcation
    end

    errorFlag, statusCode = radius.radius_config(tempInputTablePri, "1", "edit")

    -- save db if no error
    if(errorFlag == "OK")then
	if(util.fileExists("/usr/bin/embedur/wifi_reloaded.sh")) then
        	os.execute ("echo \'/bin/sh /usr/bin/embedur/wifi_reloaded.sh 1\' >> "..CMD_EXEC_SCRIPT)
	end
        if (dbFlag == 1) then
            db.commitTransaction()
            db.save2()
            if (util.fileExists (CMD_EXEC_SCRIPT)) then
                util.runShellCmd (SH_BIN..CMD_EXEC_SCRIPT)
                os.remove (CMD_EXEC_SCRIPT)
            end
            if(util.fileExists("/pfrm2.0/JIO_PRIVATE_NET"))then
                local jioPrivateNetSupport = "0"
                jioPrivateNetSupport = db.getAttribute ("environment", "name", "JIO_PRIVATE_NET" ,"value")
                local eogreTmp =  db.getRowWhere ("Eogre",  "_ROWID_=1", false)
                if (eogreTmp == nil) then
                    return "ERROR", "DB_ERROR_TRY_AGAIN"
                end
                if( jioPrivateNetSupport == "1" and tonumber(eogreTmp["secEnable"]) == 1)then
                    local valid = db.setAttribute ("Eogre", "_ROWID_","1","secEnable","0")
                    local valid = db.setAttribute ("Eogre", "_ROWID_","1","Enable","1")
                end
            end
        end
    else
        if (dbFlag == 1) then
            db.rollback()
            if (util.fileExists (CMD_EXEC_SCRIPT)) then
                os.remove (CMD_EXEC_SCRIPT)
            end
        end
    end

    --return
    return errorFlag, statusCode

end

function gui.administration.radiusClient.get(inputTable)

    --include
    require "teamf1lualib/radius"

    local configRow = {}

    configRow = db.getRow("radiusClient", "_ROWID_", "1")
    if (configRow == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN", nilTable
    end

    configRow["radiusClient.authsecret"] = util.filterXSSChars(util.mask (configRow["radiusClient.authsecret"]))
    configRow["radiusClient.interimUpdate"] = util.filterXSSChars(configRow["radiusClient.interimUpdateInterval"])
    configRow["radiusClient.authport"] = util.filterXSSChars(configRow["radiusClient.authport"])
    configRow["radiusClient.ipType"] = util.filterXSSChars(configRow["radiusClient.ipType"])
    configRow["radiusClient.authretries"] = util.filterXSSChars(configRow["radiusClient.authretries"])
    configRow["radiusClient.authtimeout"] = util.filterXSSChars(configRow["radiusClient.authtimeout"])
    configRow["radiusClient.authsecret2"] = util.filterXSSChars(util.mask (configRow["radiusClient.secauthsecret"] or ""))
    configRow["radiusClient.authserver"] = util.filterXSSChars(configRow["radiusClient.authserver"]) or ""
    configRow["radiusClient.authserver2"] = util.filterXSSChars(configRow["radiusClient.secauthserver"]) or ""
    configRow["radiusClient.authserverIPv6"] = util.filterXSSChars(configRow["radiusClient.authserverIP6"]) or ""
    configRow["radiusClient.authserver2IPv6"] = util.filterXSSChars(configRow["radiusClient.secauthserverIP6"]) or ""
    configRow["radiusClient.authport2"] = util.filterXSSChars(configRow["radiusClient.secauthport"])
    if(configRow["radiusClient.retryInterval"] == "0")then
        configRow["radiusClient.primaryRadiusRetry"] = "0"
    else
        configRow["radiusClient.primaryRadiusRetry"] = "1"
        configRow["radiusClient.primaryRadiusRetryInterval"] = util.filterXSSChars(configRow["radiusClient.retryInterval"])
    end

    return "OK", "STATUS_OK", configRow

end

function gui.administration.radiusDas.set(inputTable, dbFlag)

    --include
    require "teamf1lualib/radius"

    --locals
    local tempInputTablePri = {}
    local CMD_EXEC_SCRIPT   = "/tmp/cmdExecscript.sh"
    local SH_BIN            = "/bin/sh "
if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED")) then
    --if wifi is off, no wifi operation is permiitted
    
    local wifienabled = db.getAttribute("easyMesh","meshInterfacename","bdg2","wifiOn")
    
    if(wifienabled == "0") then
        return "ERROR","wifi Operation is not supported When Wifi is disabled"
    end
end
 
    -- flag to Enable db operations.
    if (dbFlag == nil) then
        dbFlag = 1
    end

    tempInputTablePri["radiusDas.dasClient"] = inputTable["radiusDas.dasClient"]
    tempInputTablePri["radiusDas.dasServerPort"] = inputTable["radiusDas.dasServerPort"]
    if (util.isAllMasked (inputTable["radiusDas.dasSecret"]) == false) then
        tempInputTablePri["radiusDas.dasSecret"] = inputTable["radiusDas.dasSecret"]
    end
    tempInputTablePri["radiusDas.dasTimeWindow"] = inputTable["radiusDas.dasTimeWindow"]
    tempInputTablePri["radiusDas.dasRequireTimeStamp"] = inputTable["radiusDas.dasRequireTimeStamp"]
    tempInputTablePri["radiusDas.dasRequireMsgAuth"] = inputTable["radiusDas.dasRequireMsgAuth"]


    if (dbFlag == 1)then
        db.beginTransaction() -- begin transcation
    end

    errorFlag, statusCode = das.das_config(tempInputTablePri, "1", "edit")

    -- save db if no error
    if(errorFlag == "OK")then
	if(util.fileExists("/usr/bin/embedur/wifi_reloaded.sh")) then
        	os.execute ("echo \'/bin/sh /usr/bin/embedur/wifi_reloaded.sh 1\' >> "..CMD_EXEC_SCRIPT)
	end
        if (dbFlag == 1) then
            db.commitTransaction()
            db.save2()
            if (util.fileExists (CMD_EXEC_SCRIPT)) then
                util.runShellCmd (SH_BIN..CMD_EXEC_SCRIPT)
                os.remove (CMD_EXEC_SCRIPT)
            end
        end
    else
        if (dbFlag == 1) then
            db.rollback()
            if (util.fileExists (CMD_EXEC_SCRIPT)) then
                os.remove (CMD_EXEC_SCRIPT)
            end
        end
    end

    --return
    return errorFlag, statusCode

end

function gui.administration.radiusDas.get(inputTable)

    --include
    require "teamf1lualib/radius"

    local configRow = {}

    configRow = db.getRow("radiusDas", "_ROWID_", "1")
    if (configRow == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN", nilTable
    end

    configRow["radiusDas.dasSecret"] = util.filterXSSChars(util.mask (configRow["radiusDas.dasSecret"]))
    configRow["radiusDas.dasClient"] = util.filterXSSChars(configRow["radiusDas.dasClient"])
    configRow["radiusDas.dasServerPort"] = util.filterXSSChars(configRow["radiusDas.dasServerPort"])
    configRow["radiusDas.dasTimeWindow"] = util.filterXSSChars(configRow["radiusDas.dasTimeWindow"])
    configRow["radiusDas.dasRequireTimeStamp"] = util.filterXSSChars(configRow["radiusDas.dasRequireTimeStamp"])
    configRow["radiusDas.dasRequireMsgAuth"] = util.filterXSSChars(configRow["radiusDas.dasRequireMsgAuth"])

    return "OK", "STATUS_OK", configRow

end

--
-- Schedules
--
local days_type = {
        {"1", "everyday", "127"},
        {"2", "weekends", "96" },
        {"3", "weekdays", "31" },
        {"4", "custom"  , "0"  }
	}

local time_type = {
        {"1", "allday","Entire Day" },
        {"2", "morning", "Morning (5 AM - 11 AM)"},
        {"3", "afternoon", "Afternoon (11 AM - 4 PM)" },
        {"4", "evening", "Evening (4 PM - 7 PM)"},
        {"5", "night", "Night (7 PM - 11 PM)"  },
        {"6", "custom", "0" }
    }

--
-- Routing Logs
--

--------------------------------------------------------------------------------
-- @name gui.administration.routingLogs.get()
--
-- @description This function gets the routingLogs configuration
--
-- @return status, errMsg, lua table containing routingLogs configuration in the device
--
function gui.administration.routingLogs.get()
    --include
    require "teamf1lualib/firewall"

   --locals
    local routingLogsConfigRow = {}
    local configTbl = {}

    --get values from 'AlgConf' table
    routingLogsConfigRow = firewall.routingLogsConfigGet()
    if(routingLogsConfigRow == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    configTbl["LANToWANAccept"]     = routingLogsConfigRow["LANToWANAccept"]
    configTbl["LANToWANDrop"]       = routingLogsConfigRow["LANToWANDrop"]
    configTbl["WANToLANAccept"]     = routingLogsConfigRow["WANToLANAccept"]
    configTbl["WANToLANDrop"]       = routingLogsConfigRow["WANToLANDrop"]

    --return
    return "OK", "STATUS_OK", configTbl
end

--------------------------------------------------------------------------------
-- @name gui.administration.routingLogs.set()
--
-- @description This function sets the routingLogs configuration
--
-- @return status, errMsg
--
function gui.administration.routingLogs.set(inCfg)
    -- require
    require "teamf1lualib/firewall"

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg
    local routingLogsConfigRow = {}

    --setting the values in 'AlgConf' table
    routingLogsConfigRow["LANToWANAccept"]  = inCfg["LANToWANAccept"]
    routingLogsConfigRow["LANToWANDrop"]    = inCfg["LANToWANDrop"]
    routingLogsConfigRow["WANToLANAccept"]  = inCfg["WANToLANAccept"]
    routingLogsConfigRow["WANToLANDrop"]    = inCfg["WANToLANDrop"]
    status, errMsg = firewall.routingLogsConfigSet(routingLogsConfigRow)

    if (status == "OK") then
        db.save2()
    end
    
    --return
    return status, errMsg
end

--
-- System Logs
--

--------------------------------------------------------------------------------
-- @name gui.administration.systemLogs.get()
--
-- @description This function gets the systemLogs configuration
--
-- @return status, errMsg, lua table containing systemLogs configuration in the device
--
function gui.administration.systemLogs.get()
    --include
    require "teamf1lualib/firewall"

   --locals
    local systemLogsConfigRow = {}
    local configTbl = {}

    --get values from 'AlgConf' table
    systemLogsConfigRow = firewall.systemLogsConfigGet()
    if(systemLogsConfigRow == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    configTbl["UnicastTraffic"]                     = systemLogsConfigRow["UnicastTraffic"]
    configTbl["BroadCastORMulticastTraffic"]        = systemLogsConfigRow["BroadCastORMulticastTraffic"]
    configTbl["FtpLogs"]                            = systemLogsConfigRow["FtpLogs"]
    configTbl["IcmpRedirectedLogs"]                 = systemLogsConfigRow["IcmpRedirectedLogs"]
    configTbl["logInvalidPacket"]                   = systemLogsConfigRow["logInvalidPacket"]

    --return
    return "OK", "STATUS_OK", configTbl
end

--------------------------------------------------------------------------------
-- @name gui.administration.systemLogs.set()
--
-- @description This function sets the systemLogs configuration
--
-- @return status, errMsg
--
function gui.administration.systemLogs.set(inCfg)
    -- require
    require "teamf1lualib/firewall"

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg
    local systemLogsConfigRow = {}
    
    --setting the values in 'AlgConf' table
    systemLogsConfigRow["UnicastTraffic"]               = inCfg["UnicastTraffic"]
    systemLogsConfigRow["BroadCastORMulticastTraffic"]  = inCfg["BroadCastORMulticastTraffic"]
    systemLogsConfigRow["FtpLogs"]                      = inCfg["FtpLogs"]
    systemLogsConfigRow["IcmpRedirectedLogs"]           = inCfg["IcmpRedirectedLogs"]
    systemLogsConfigRow["logInvalidPacket"]             = inCfg["logInvalidPacket"]  
    status, errMsg = firewall.systemLogsConfigSet(systemLogsConfigRow)

    if (status == "OK") then
        db.save2()
    end
    
    --return
    return status, errMsg
end

--
-- ipv6 Logs
--

--------------------------------------------------------------------------------
-- @name gui.administration.ipv6Logs.get()
--
-- @description This function gets the ipv6Logs configuration
--
-- @return status, errMsg, lua table containing ipv6Logs configuration in the device
--
function gui.administration.ipv6Logs.get()
    --include
    require "teamf1lualib/firewall"

   --locals
    local ipv6LogsConfigRow = {}
    local configTbl = {}

    --get values from 'AlgConf' table
    ipv6LogsConfigRow = firewall.ipv6LogsConfigGet()
    if(ipv6LogsConfigRow == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    configTbl["LANToWANAccept"]     = ipv6LogsConfigRow["LANToWANAccept"]
    configTbl["LANToWANDrop"]       = ipv6LogsConfigRow["LANToWANDrop"]
    configTbl["WANToLANAccept"]     = ipv6LogsConfigRow["WANToLANAccept"]
    configTbl["WANToLANDrop"]       = ipv6LogsConfigRow["WANToLANDrop"]

    --return
    return "OK", "STATUS_OK", configTbl
end

--------------------------------------------------------------------------------
-- @name gui.administration.ipv6Logs.set()
--
-- @description This function sets the ipv6Logs configuration
--
-- @return status, errMsg
--
function gui.administration.ipv6Logs.set(inCfg)
    -- require
    require "teamf1lualib/firewall"

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg
    local ipv6LogsConfigRow = {}

    --setting the values in 'AlgConf' table
    ipv6LogsConfigRow["LANToWANAccept"]  = inCfg["LANToWANAccept"]
    ipv6LogsConfigRow["LANToWANDrop"] = inCfg["LANToWANDrop"]
    ipv6LogsConfigRow["WANToLANAccept"] = inCfg["WANToLANAccept"]
    ipv6LogsConfigRow["WANToLANDrop"] = inCfg["WANToLANDrop"]
    status, errMsg = firewall.ipv6LogsConfigSet(ipv6LogsConfigRow)

    if (status == "OK") then
        db.save2()
    end
    
    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.administration.schedules.helpers.daysCfgToNum
--
-- @description : calculate the sum of days
--
-- @param : daysType, lua table containing days configuration
--
-- @return : total days value
--
function gui.administration.schedules.helpers.daysCfgToNum(daysType, days)
    local total_days = "0"

    for k,v in pairs(days_type) do
        if(daysType == v[1]) then
            total_days = v[3]
            break
        end
    end

    if(total_days ~= "0") then
        return total_days
    end

	if (days["monday"] == "1") then
  	   total_days = tonumber(total_days) + 	1
	end

	if (days["tuesday"] == "1") then
  	   total_days = tonumber(total_days) + 	2
	end

	if (days["wednesday"] == "1") then
  	   total_days = tonumber(total_days) + 	4
	end

	if (days["thursday"] == "1") then
  	   total_days = tonumber(total_days) + 	8
	end

	if (days["friday"] == "1") then
  	   total_days = tonumber(total_days) + 	16
	end

	if (days["saturday"] == "1") then
  	   total_days = tonumber(total_days) + 	32
	end

	if (days["sunday"] == "1") then
  	   total_days = tonumber(total_days) + 	64
	end
    
    return total_days
end

-------------------------------------------------------------------------------
-- @name : gui.administration.schedules.helpers.findDays
--
-- @description : find the configured days from sum of days by checking bitwise
--
-- @param : total days value & empty days cfg table
--
-- @return : lua table containing days configuration
--
function gui.administration.schedules.helpers.findDays(totalDays, inDayTbl)
    local dayCfg = {}
    local m = 0
    local e = 0
    local dayNum = 0
    local newTotalDays = 0

    if(totalDays <= 0 or totalDays > 127) then
        --Invalid totalDays received
        return dayCfg
    end

    dayCfg = inDayTbl
    --math.frexp(x) receives a value x and returns two values m & e,
    --such that x = (m * (2 ^ e))
    m,e = math.frexp(totalDays)
    dayNum = e - 1

    if(m ~= 0.5) then
        newTotalDays = totalDays - 2 ^ (e-1)
        dayCfg = gui.administration.schedules.helpers.findDays(newTotalDays, inDayTbl)
    end

    if(dayNum == 0) then
        --print("setting monday")
        dayCfg["monday"] = "1"
    elseif(dayNum == 1) then
        --print("setting tuesday")
        dayCfg["tuesday"] = "1"
    elseif(dayNum == 2) then
        --print("setting wednesday")
        dayCfg["wednesday"] = "1"
    elseif(dayNum == 3) then
        --print("setting thursday")
        dayCfg["thursday"] = "1"
    elseif(dayNum == 4) then
        --print("setting friday")
        dayCfg["friday"] = "1"
    elseif(dayNum == 5) then
        --print("setting saturday")
        dayCfg["saturday"] = "1"
    elseif(dayNum == 6) then
        --print("setting sunday")
        dayCfg["sunday"] = "1"
    else
        --print("Unknown dayNum value..")
    end

    return dayCfg
end

-------------------------------------------------------------------------------
-- @name : gui.administration.schedules.helpers.daysNumToCfg
--
-- @description : get the days configured from sum of days
--
-- @param : total days value
--
-- @return : lua table containing days configuration
--
function gui.administration.schedules.helpers.daysNumToCfg(totalDays)
    local daysNum = tonumber(totalDays)
    local daysTbl = {}

    daysTbl["monday"]    = "0" --1
    daysTbl["tuesday"]   = "0" --2
    daysTbl["wednesday"] = "0" --4
    daysTbl["thursday"]  = "0" --8
    daysTbl["friday"]    = "0" --16
    daysTbl["saturday"]  = "0" --32
    daysTbl["sunday"]    = "0" --64

    daysTbl = gui.administration.schedules.helpers.findDays(daysNum, daysTbl)

    return daysTbl
end

-------------------------------------------------------------------------------
-- @name : gui.administration.schedules.helpers.daysNumToStr
--
-- @description : get the days configured string from sum of days
--
-- @param : total days value
--
-- @return : lua table containing days configuration
--
function gui.administration.schedules.helpers.daysNumToStr(totalDays)
    local daysNum = tonumber(totalDays)
    local daysTbl = {}
    local daysStr = ""

    daysTbl["monday"]    = "0" --1
    daysTbl["tuesday"]   = "0" --2
    daysTbl["wednesday"] = "0" --4
    daysTbl["thursday"]  = "0" --8
    daysTbl["friday"]    = "0" --16
    daysTbl["saturday"]  = "0" --32
    daysTbl["sunday"]    = "0" --64

    daysTbl = gui.administration.schedules.helpers.findDays(daysNum, daysTbl)

    --format the string here
    if(daysTbl["monday"] == "1") then
        daysStr = daysStr .. "Mon,"
    end
    if(daysTbl["tuesday"] == "1") then
        daysStr = daysStr .. "Tue,"
    end
    if(daysTbl["wednesday"] == "1") then
        daysStr = daysStr .. "Wed,"
    end
    if(daysTbl["thursday"] == "1") then
        daysStr = daysStr .. "Thu,"
    end
    if(daysTbl["friday"] == "1") then
        daysStr = daysStr .. "Fri,"
    end
    if(daysTbl["saturday"] == "1") then
        daysStr = daysStr .. "Sat,"
    end
    if(daysTbl["sunday"] == "1") then
        daysStr = daysStr .. "Sun,"
    end

    if(daysStr ~= "") then
       daysStr = string.sub(daysStr, 1, string.len(daysStr) - 1) --shave last comma
    end

    return daysStr
end

-------------------------------------------------------------------------------
-- @name : gui.administration.schedules.helpers.timeToValuesCfg
--
-- @description : find time string from time values
--
-- @param : lua table containing schedule configuration from db
--
-- @return : lua table containing time configuration for gui
--
function gui.administration.schedules.helpers.timeValuesToCfg(schedCfg)
    local timeCfg = {}

    if(schedCfg["StartTimeMeridian"] == "1") then
        timeCfg["StartMeridStr"] = "AM"
    else
        timeCfg["StartMeridStr"] = "PM"
    end

    if(schedCfg["EndTimeMeridian"] == "1") then
        timeCfg["EndMeridStr"] = "AM"
    else
        timeCfg["EndMeridStr"] = "PM"
    end

    if(tonumber(schedCfg["StartTimeHours"]) < 10) then
        schedCfg["StartTimeHours"] = "0" .. schedCfg["StartTimeHours"] 
    end

    if(tonumber(schedCfg["StartTimeMins"]) < 10) then
        schedCfg["StartTimeMins"] = "0" .. schedCfg["StartTimeMins"] 
    end 

    if(tonumber(schedCfg["EndTimeHours"]) < 10) then
        schedCfg["EndTimeHours"] = "0" .. schedCfg["EndTimeHours"] 
    end 

    if(tonumber(schedCfg["EndTimeMins"]) < 10) then
        schedCfg["EndTimeMins"] = "0" .. schedCfg["EndTimeMins"] 
    end 

    timeCfg["DatePickerStartTime"] = string.format("%s:%s %s", schedCfg["StartTimeHours"], schedCfg["StartTimeMins"], timeCfg["StartMeridStr"])
    timeCfg["DatePickerEndTime"] = string.format("%s:%s %s", schedCfg["EndTimeHours"], schedCfg["EndTimeMins"], timeCfg["EndMeridStr"])

    return timeCfg
end

-------------------------------------------------------------------------------
-- @name : gui.administration.schedules.helpers.timeStrParse
--
-- @description : find time values from time string
--
-- @param : lua table containing time configuration
--
-- @return : lua table containing time values
--
function gui.administration.schedules.helpers.timeStrParse(schedCfg)
    local parsedTime = {}

    --Time string is in "HH:MM MD" format
    parsedTime["StartTimeHours"] = string.sub(schedCfg["DatePickerStartTime"], 1, 2)
    parsedTime["StartTimeMins"] = string.sub(schedCfg["DatePickerStartTime"], 4, 5)
    if(string.sub(schedCfg["DatePickerStartTime"], 7, 8) == "AM") then
        parsedTime["StartTimeMeridian"] = "1"
    else
        parsedTime["StartTimeMeridian"] = "2"
    end

    parsedTime["EndTimeHours"] = string.sub(schedCfg["DatePickerEndTime"], 1, 2)
    parsedTime["EndTimeMins"] = string.sub(schedCfg["DatePickerEndTime"], 4, 5)
    if(string.sub(schedCfg["DatePickerEndTime"], 7, 8) == "AM") then
        parsedTime["EndTimeMeridian"] = "1"
    else
        parsedTime["EndTimeMeridian"] = "2"
    end

    return parsedTime
end

-------------------------------------------------------------------------------
-- @name : gui.administration.schedules.helpers.timeCfgToValues
--
-- @description : find time values
--
-- @param : lua table containing schedule configuration from gui
--
-- @return : lua table containing time configuration for db
--
function gui.administration.schedules.helpers.timeCfgToValues(schedCfg)
    local timeCfg = {}
    local parsedTime = {}

    if(schedCfg["TimeType"] == "1") then --allday
        timeCfg["StartTimeHours"] = "12" 
        timeCfg["StartTimeMins"] = "0"
        timeCfg["StartTimeMeridian"] = "1"
        timeCfg["EndTimeHours"] = "11"
        timeCfg["EndTimeMins"] = "59"
        timeCfg["EndTimeMeridian"] = "2"

    elseif(schedCfg["TimeType"] == "2") then --morning
        timeCfg["StartTimeHours"] = "5"
        timeCfg["StartTimeMins"] = "0"
        timeCfg["StartTimeMeridian"] = "1"
        timeCfg["EndTimeHours"] = "11"
        timeCfg["EndTimeMins"] = "0"
        timeCfg["EndTimeMeridian"] = "1"

    elseif(schedCfg["TimeType"] == "3") then --afternoon
        timeCfg["StartTimeHours"] = "11"
        timeCfg["StartTimeMins"] = "0"
        timeCfg["StartTimeMeridian"] = "1"
        timeCfg["EndTimeHours"] = "4"
        timeCfg["EndTimeMins"] = "0"
        timeCfg["EndTimeMeridian"] = "2"

    elseif(schedCfg["TimeType"] == "4") then --evening
        timeCfg["StartTimeHours"] = "4"
        timeCfg["StartTimeMins"] = "0"
        timeCfg["StartTimeMeridian"] = "2"
        timeCfg["EndTimeHours"] = "7"
        timeCfg["EndTimeMins"] = "0"
        timeCfg["EndTimeMeridian"] = "2"

    elseif(schedCfg["TimeType"] == "5") then --night
        timeCfg["StartTimeHours"] = "7"
        timeCfg["StartTimeMins"] = "0"
        timeCfg["StartTimeMeridian"] = "2"
        timeCfg["EndTimeHours"] = "11"
        timeCfg["EndTimeMins"] = "0"
        timeCfg["EndTimeMeridian"] = "2"

    else --custom
        parsedTime = gui.administration.schedules.helpers.timeStrParse(schedCfg)
        timeCfg["StartTimeHours"] = parsedTime["StartTimeHours"]
        timeCfg["StartTimeMins"] = parsedTime["StartTimeMins"]
        timeCfg["StartTimeMeridian"] = parsedTime["StartTimeMeridian"]
        timeCfg["EndTimeHours"] = parsedTime["EndTimeHours"]
        timeCfg["EndTimeMins"] = parsedTime["EndTimeMins"]
        timeCfg["EndTimeMeridian"] = parsedTime["EndTimeMeridian"]
    end

    --return
    return timeCfg
end

-------------------------------------------------------------------------------
-- @name : gui.administration.schedules.get
--
-- @description : fetches all schedules in the device
--
-- @return : lua table containing all schedules
--
function gui.administration.schedules.get()
    --locals
    local schedTbl = {}
    local page = {} --getting the Services table
    local meridianName = ""
    page.Schedules = {}

    schedTbl = firewall.fwSchedGet()
    if (schedTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    for i,v in pairs (schedTbl) do
        page.Schedules[i] = {}
        page.Schedules[i].ScheduleName = util.filterXSSChars (v["ScheduleName"])
        page.Schedules[i]._ROWID_ =  v["_ROWID_"]

        --Day of week
        page.Schedules[i].DaysStr = util.filterXSSChars (gui.administration.schedules.helpers.daysNumToStr(v["Days"]))

        --Time of day
        if(tonumber(v["StartTimeHours"]) < 10) then
            v["StartTimeHours"] = "0" .. v["StartTimeHours"] 
        end

        if(tonumber(v["StartTimeMins"]) < 10) then
            v["StartTimeMins"] = "0" .. v["StartTimeMins"] 
        end 
           
        page.Schedules[i].StarTime = v["StartTimeHours"]
        if (v["StartTimeMins"] ~= "0") then 
            page.Schedules[i].StarTime = page.Schedules[i].StarTime .. ":" .. v["StartTimeMins"]
        end

        if (v["StartTimeMeridian"] == "1") then
            meridianName = " AM"
        else 
            meridianName = " PM"
        end
        page.Schedules[i].StarTime = page.Schedules[i].StarTime .. meridianName


        if(tonumber(v["EndTimeHours"]) < 10) then
            v["EndTimeHours"] = "0" .. v["EndTimeHours"] 
        end 

        if(tonumber(v["EndTimeMins"]) < 10) then
            v["EndTimeMins"] = "0" .. v["EndTimeMins"] 
        end 

        page.Schedules[i].EndTime = v["EndTimeHours"]
        if (v["EndTimeMins"] ~= "0") then
            page.Schedules[i].EndTime = page.Schedules[i].EndTime .. ":" .. v["EndTimeMins"]
        end

        if (v["EndTimeMeridian"]=="1") then
            meridianName = " AM"
        else
            meridianName = " PM"
        end
        page.Schedules[i].EndTime = page.Schedules[i].EndTime .. meridianName

        page.Schedules[i].TimeOfDay = util.filterXSSChars (page.Schedules[i].StarTime) .. " - " .. util.filterXSSChars (page.Schedules[i].EndTime)
    end

    -- return
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name : gui.administration.schedules.add.get
--
-- @description : This function gets defaults to add a schedule
--
-- @return : lua table containing default values
--
function gui.administration.schedules.add.get()
    --locals
    local page = {}

    --return
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name : gui.administration.schedules.add.set
--
-- @description : This function will add new schedule
--
-- @param : lua table containing schedule configuration
--
-- @return : status, errorMsg
--
function gui.administration.schedules.add.set (schedCfg)
    --local
    local status, errMsg
    local schedule = {}
    local days = {}
    local time = {}

    local startTimeInHours
    local startTimeInMins
    local endTimeInHours
    local endTimeInMins
    local startTimeMeridian
    local endTimeMeridian

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    schedule["ScheduleName"] = schedCfg["ScheduleName"]
    schedule["DaysType"] = schedCfg["DaysType"]

    if (schedule["DaysType"] == "4") then --custom
        days =  gui.makeTableWithPrefix(schedCfg, "DayOfWeek.")
        schedule["Days"] = gui.administration.schedules.helpers.daysCfgToNum(schedCfg["DaysType"], days)
    else
        schedule["Days"] = gui.administration.schedules.helpers.daysCfgToNum(schedCfg["DaysType"])
    end

    schedule["TimeType"] = schedCfg["TimeType"]
    time = gui.administration.schedules.helpers.timeCfgToValues(schedCfg)
    schedule["StartTimeHours"] = time["StartTimeHours"]
    schedule["StartTimeMins"] = time["StartTimeMins"]
    schedule["StartTimeMeridian"] = time["StartTimeMeridian"]
    schedule["EndTimeHours"] = time["EndTimeHours"]
	schedule["EndTimeMins"] = time["EndTimeMins"]
    schedule["EndTimeMeridian"] = time["EndTimeMeridian"]

    startTimeInHours = schedule["StartTimeHours"]
    startTimeInMins = schedule["StartTimeMins"]
    endTimeInHours = schedule["EndTimeHours"]
    endTimeInMins = schedule["EndTimeMins"]
    startTimeMeridian =  schedule["StartTimeMeridian"]
    endTimeMeridian = schedule["EndTimeMeridian"]

    if (startTimeInHours == nil and startTimeInMins == nil and endTimeInHours == nil and endTimeInMins == nil and startTimeMeridian == nil and endTimeMeridian == nil) then 
        return "ERROR", "Config failed"
    end

    if (tonumber (startTimeMeridian) == 1) then
            if (startTimeInHours == "12") then
                startTimeInHours = "0"
            end
        else
            if (startTimeInHours ~= "12") then
                startTimeInHours = tonumber(startTimeInHours) + 12
            end
        end

        if (tonumber (endTimeMeridian) == 1) then
            if (endTimeInHours == "12") then
                endTimeInHours = "0"
            end
        else
            if (endTimeInHours ~= "12") then
                endTimeInHours = tonumber(endTimeInHours) + 12
            end
        end

        if((tonumber(startTimeInHours) * 60 + tonumber(startTimeInMins)) >= 
                    (tonumber(endTimeInHours) * 60 + tonumber(endTimeInMins))) then
        return "ERROR", "Start Time should be less than End Time"
    end

    --setting the rules
    status, errMsg = firewall.fwSchedAddSet (schedule)
    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.administration.schedules.edit.get
--
-- @description : This function gets schedule being edited
--
-- @ param: ROWID of the schedule being edited
-- 
-- @return : lua table containing current configuration of schedule
-- 
function gui.administration.schedules.edit.get(rowId)
    --locals
    local schedule = {}
    local page = {}
    local daysConfig = {}
    local timeConfig = {}
    
    --fetch the row with corresponding rowId from 'Schedules' table
    schedule = firewall.fwSchedEditGet(rowId)
    if(schedule == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    page["ScheduleName"] = util.filterXSSChars (schedule["ScheduleName"])
    page["_ROWID_"] = rowId

    page["DaysType"] = schedule["DaysType"]
    if(page["DaysType"] == "4") then --custom
        daysConfig = gui.administration.schedules.helpers.daysNumToCfg(schedule["Days"])
        page["DayOfWeek.monday"] = daysConfig["monday"]
        page["DayOfWeek.tuesday"] = daysConfig["tuesday"]
        page["DayOfWeek.wednesday"] = daysConfig["wednesday"]
        page["DayOfWeek.thursday"] = daysConfig["thursday"]
        page["DayOfWeek.friday"] = daysConfig["friday"]
        page["DayOfWeek.saturday"] = daysConfig["saturday"]
        page["DayOfWeek.sunday"] = daysConfig["sunday"]
    end

    page["TimeType"] = schedule["TimeType"]
    if(page["TimeType"] == "6") then 
        timeConfig = gui.administration.schedules.helpers.timeValuesToCfg(schedule)
        page["DatePickerStartTime"] = util.filterXSSChars (timeConfig["DatePickerStartTime"])
        page["DatePickerEndTime"] = util.filterXSSChars (timeConfig["DatePickerEndTime"])
    end
    
    --return
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name : gui.administration.schedules.edit.set
--
-- @description : This function sets schedule being edited
--
-- @param : lua table containing new configuration of the schedule
--
-- @return : status, errMsg
--
function gui.administration.schedules.edit.set(scheduleCfg)
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg
    local schedule = {}
    local days = {}
    local time = {}
    local schName = ""
    local query = ""
    local isFwRuleExist, isBlockedExist, isApprovedExist, isFw6RuleExist
    local startTimeInHours
    local startTimeInMins
    local endTimeInHours
    local endTimeInMins
    local startTimeMeridian
    local endTimeMeridian

    --Checks here to see if the schedule is in use with old schedule name
    schName = db.getAttribute ("Schedules", "_ROWID_", scheduleCfg["_ROWID_"], "ScheduleName")
    if(schName == nil or schName == "") then
        db.rollback()
        return "ERROR", "SCHEDULE_DELETE_FAILED"
    end
    query = "ScheduleName = '" .. schName .. "'"

    -- check if the schedule is being used in an IPv4 Firewall Rules
    isFwRuleExist = db.existsRowWhere("FirewallRules", "ScheduleName = '" .. schName .. "'")
    if (isFwRuleExist) then
        db.rollback()
        return "ERROR", "Schedule " .. schName .. " cannot be edited as it is being user in Firewall Rule(s)."
    end

        -- check if the schedule is being used in an IPv4 Firewall Rules
    isFw6RuleExist = db.existsRowWhere("FirewallRules6", "ScheduleName = '" .. schName .. "'")
    if (isFw6RuleExist) then
        db.rollback()
        return "ERROR", "Schedule " .. schName .. " cannot be edited as it is being user in Firewall Rule(s)."
    end

    -- check if the schedule is being used in blocked keyword configuration
    isBlockedExist = db.existsRowWhere("BlockSites", "ScheduleName = '" .. schName .. "'")
    if (isBlockedExist) then
        db.rollback()
        return "ERROR", "Schedule " .. schName .. " cannot be edited as it is being used in Blocked Keyword(s)."
    end

    -- check if the schedule is being used in approved url configuration
    isApprovedExist = db.existsRowWhere("TrustedDomains", "ScheduleName = '" .. schName .. "'")
    if (isApprovedExist) then
        db.rollback()
        return "ERROR", "Schedule " .. schName .. " cannot be edited as it is being used in Approved URL(s)."
    end

    schedule["ScheduleName"] = scheduleCfg["ScheduleName"]
    schedule["_ROWID_"] = scheduleCfg["_ROWID_"]
    schedule["DaysType"] = scheduleCfg["DaysType"]

    if (schedule["DaysType"] == "4") then --custom
        days =  gui.makeTableWithPrefix(scheduleCfg, "DayOfWeek.")
        schedule["Days"] = gui.administration.schedules.helpers.daysCfgToNum(scheduleCfg["DaysType"], days)
    else
        schedule["Days"] = gui.administration.schedules.helpers.daysCfgToNum(scheduleCfg["DaysType"])
    end

    schedule["TimeType"] = scheduleCfg["TimeType"]
    time = gui.administration.schedules.helpers.timeCfgToValues(scheduleCfg)
    schedule["StartTimeHours"] = time["StartTimeHours"]
    schedule["StartTimeMins"] = time["StartTimeMins"]
    schedule["StartTimeMeridian"] = time["StartTimeMeridian"]
    schedule["EndTimeHours"] = time["EndTimeHours"]
	schedule["EndTimeMins"] = time["EndTimeMins"]
    schedule["EndTimeMeridian"] = time["EndTimeMeridian"]



    startTimeInHours = schedule["StartTimeHours"]
    startTimeInMins = schedule["StartTimeMins"]
    endTimeInHours = schedule["EndTimeHours"]
    endTimeInMins = schedule["EndTimeMins"]
    startTimeMeridian =  schedule["StartTimeMeridian"]
    endTimeMeridian = schedule["EndTimeMeridian"]

    if (startTimeInHours == nil and startTimeInMins == nil and endTimeInHours == nil and endTimeInMins == nil and startTimeMeridian == nil and endTimeMeridian == nil) then 
        return "ERROR", "Config failed"
    end

    if (tonumber (startTimeMeridian) == 1) then
            if (startTimeInHours == "12") then
                startTimeInHours = "0"
            end
        else
            if (startTimeInHours ~= "12") then
                startTimeInHours = tonumber(startTimeInHours) + 12
            end
        end

        if (tonumber (endTimeMeridian) == 1) then
            if (endTimeInHours == "12") then
                endTimeInHours = "0"
            end
        else
            if (endTimeInHours ~= "12") then
                endTimeInHours = tonumber(endTimeInHours) + 12
            end
        end

        if((tonumber(startTimeInHours) * 60 + tonumber(startTimeInMins)) >= 
                    (tonumber(endTimeInHours) * 60 + tonumber(endTimeInMins))) then
        return "ERROR", "Start Time should be less than End Time"
    end

    --setting the new configuration in the table
    status, errMsg = firewall.fwSchedEditSet(schedule)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.administration.schedules.delete
--
-- @description : This function deletes schedules
--
-- @param : ROWIDs of schedules to be deleted
--
-- @return : status, errorMsg
--
function gui.administration.schedules.delete (rowIds)
    --local
    local status, errMsg
    local schName = ""
    local query = ""
    local isFwRuleExist, isBlockedExist, isApprovedExist,isFw6RuleExist

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    db.beginTransaction() --begin transactions

    --delete each schedule
    for k,v in pairs(rowIds) do
        local deleteSch = {}
        deleteSch["_ROWID_"] = v

        --Checks here to see if the schedule is in use
        schName = db.getAttribute ("Schedules", "_ROWID_", v, "ScheduleName")
        if(schName == nil or schName == "") then
            db.rollback()
            return "ERROR", "SCHEDULE_DELETE_FAILED"
        end
        query = "ScheduleName = '" .. schName .. "'"

        -- check if the schedule is being used in an IPv4 Firewall Rules
        isFwRuleExist = db.existsRowWhere("FirewallRules", "ScheduleName = '" .. schName .. "'")
        if (isFwRuleExist) then
            db.rollback()
            return "ERROR", "Schedule " .. schName .. " is in use. Delete associated Firewall Rule(s) first."
        end

        -- check if the schedule is being used in an IPv4 Firewall Rules
        isFw6RuleExist = db.existsRowWhere("FirewallRules6", "ScheduleName = '" .. schName .. "'")
        if (isFw6RuleExist) then
            db.rollback()
            return "ERROR", "Schedule " .. schName .. " is in use. Delete associated Firewall Rule(s) first."
        end
        

        -- check if the schedule is being used in blocked keyword configuration
        isBlockedExist = db.existsRowWhere("BlockSites", "ScheduleName = '" .. schName .. "'")
        if (isBlockedExist) then
            db.rollback()
            return "ERROR", "Schedule " .. schName .. " is in use. Delete associated Blocked Keyword(s) first."
        end

        -- check if the schedule is being used in approved url configuration
        isApprovedExist = db.existsRowWhere("TrustedDomains", "ScheduleName = '" .. schName .. "'")
        if (isApprovedExist) then
            db.rollback()
            return "ERROR", "Schedule " .. schName .. " is in use. Delete associated Approved URL(s) first."
        end

        status, errMsg = firewall.fwSchedDelete(deleteSch)
        if (status ~= "OK") then
            db.rollback()
            return status, errMsg
        end
    end

    if (status == "OK") then
        db.commitTransaction(true)
        db.save2()
    else
        db.rollback()
    end

    --return
    return status, errMsg
end
-------------------------------------------------------------------------------
-- @name : gui.administration.captivePortal.get()
--
-- @description : This function get captive Portal configuration
--
-- @param : 
--
-- @return : status, errorMsg
--
function gui.administration.captivePortal.get()
       -- include
    require "teamf1lualib/captivePortal"

    local status = "ERROR"
    local errMsg = "CAPTIVE_PORTAL_CONF_GET_FAILED"
    local confRow = {}
    local profTbl = {}
    local page = {}
    page.profiles = {}

    --getting captivePortalProfiles
    profTbl = captivePortal.profilesGet()
    if (profTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    for k,v in pairs (profTbl) do
        page.profiles[k] = {}
        page.profiles[k].name = util.filterXSSChars(v["configurationName"])
        page.profiles[k].profileId = v["profileId"]
    end

    status, errMsg, confRow = captivePortal.confGet()
    if(status == "ERROR") then
        return "ERROR", "CAPTIVE_PORTAL_CONF_GET_FAILED", nil
    end
    
    page.enable = confRow["enable"]
    
    if(confRow["authServerId"] ~= nil) then
        page.authServerId = confRow["authServerId"]
    end

    if(confRow["accessType"] ~= nil) then
        page.accessType = confRow["accessType"]
    end

    if(confRow["profileId"] ~= nil) then
        page.profileId = confRow["profileId"]
    end

    if(confRow["redirectType"] ~= nil) then
        page.redirectType = confRow["redirectType"]
    end

    --return
    return status, errMsg, page
end

-------------------------------------------------------------------------------
-- @name : gui.administration.captivePortal.set()
--
-- @description : This function set captive Portal configuration
--
-- @param : 
--
-- @return : status, errorMsg
--
function gui.administration.captivePortal.set(conf)
       -- include
    require "teamf1lualib/captivePortal"

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
    
    local status
    local errMsg

    status, errMsg = captivePortal.configure(conf)

    if (status == "OK") then
        db.save2()
        os.execute(fwRulesCmd)
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.administration.captivePortal.captivePortalProfiles.get()
--
-- @description : This function get captive Portal Profiles
--
-- @param : 
--
-- @return : status, errorMsg
--
function gui.administration.captivePortal.captivePortalProfiles.get()
       -- include
    require "teamf1lualib/captivePortal"
    
    local query = nil
    local vlanRow = {}
    local profTbl = {}
    local page = {}
    page.profiles = {}

    --getting captivePortalProfiles
    profTbl = captivePortal.profilesGet()
    if (profTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    for i,v in pairs (profTbl) do
        page.profiles[i] = {}
        page.profiles[i].configurationName = util.filterXSSChars(v["configurationName"])
        vlanRow = db.getRows ("CaptivePortalVlan", "profileId", v["profileId"], false)
        if (#vlanRow == 0) then
            page.profiles[i].status = "Not In Use"
        else
            page.profiles[i].status = "In Use"
        end
        page.profiles[i]._ROWID_ = v["_ROWID_"]
    end

    --return
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------------
-- @name : gui.administration.captivePortal.captivePortalProfiles.add.get()
--
-- @description :
--
-- @param : 
--
-- @return : 
--
function gui.administration.captivePortal.captivePortalProfiles.add.get()
    
    local configTbl = {}

    return "OK", "STATUS_OK", configTbl
end

-------------------------------------------------------------------------------
-- @name : gui.administration.captivePortal.captivePortalProfiles.images.get()
--
-- @description :
--
-- @param : 
--
-- @return : 
--
function gui.administration.captivePortal.captivePortalProfiles.images.get()
   
    -- include
    require "teamf1lualib/captivePortal"

    local configTbl = {}

    configTbl = captivePortal.imagesGet()
    if(configTbl == nil)  then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    return "OK", "STATUS_OK", configTbl
end

-------------------------------------------------------------------------------
-- @name : gui.administration.captivePortalSession.get()
--
-- @description :
--
-- @param : 
--
-- @return : 
--
function gui.administration.captivePortalSession.get()
   
    -- include
    require "teamf1lualib/captivePortal"

    local configTbl = {}

    configTbl = captivePortal.sessionGet()
    if(configTbl == nil)  then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    for i,v in ipairs (configTbl) do
        configTbl[i] = {}
        configTbl[i] = v
        configTbl["UserName"] = util.filterXSSChars (configTbl["UserName"])
        configTbl["ipAddr"] = util.filterXSSChars (configTbl["ipAddr"])
        configTbl["macAddr"] = util.filterXSSChars (configTbl["macAddr"])
    end

    return "OK", "STATUS_OK", configTbl
end

-------------------------------------------------------------------------------
-- @name : gui.administration.captivePortalSession.disconnect()
--
-- @description :
--
-- @param : 
--
-- @return : 
--
function gui.administration.captivePortalSession.disconnect(rowId)
   
    -- include
    require "teamf1lualib/captivePortal"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    local errMsg 
    local stat

    stat, errMsg = captivePortal.usersDisconnect(rowId)
    
    return stat, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.administration.captivePortal.captivePortalProfiles.add.set()
--
-- @description :
--
-- @param : 
--
-- @return : 
--
function gui.administration.captivePortal.captivePortalProfiles.add.set(conf)
       -- include
    require "teamf1lualib/captivePortal"

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    status, errMsg = captivePortal.profilesAddSet(conf)
    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.administration.captivePortal.captivePortalProfiles.edit.get()
--
-- @description :
--
-- @param : 
--
-- @return : 
--
function gui.administration.captivePortal.captivePortalProfiles.edit.get(rowId)
       -- include
    require "teamf1lualib/captivePortal"
    
    local configRow = {} 

    configRow = captivePortal.profilesEditGet(rowId)
  
    if (configRow == nil) then
        return "ERROR", "CAPTIVE_PORTAL_PROFILE_GET_FAILED"
    end

    configRow["configurationName"] = util.filterXSSChars(configRow["configurationName"])
    configRow["title"] = util.filterXSSChars(configRow["title"])
    configRow["CustomColor"] = util.filterXSSChars(configRow["CustomColor"])
    configRow["headerCaption"] = util.filterXSSChars(configRow["headerCaption"])
    configRow["LoginBoxTitle"] = util.filterXSSChars(configRow["LoginBoxTitle"])
    configRow["welcomeMessage"] = util.filterXSSChars(configRow["welcomeMessage"])
    configRow["errorMessage"] = util.filterXSSChars(configRow["errorMessage"])
    configRow["AdContent"] = util.filterXSSChars(configRow["AdContent"])
    configRow["FooterContent"] = util.filterXSSChars(configRow["FooterContent"])
    
    --return
    return "OK", "STATUS_OK", configRow
end

-------------------------------------------------------------------------------
-- @name : gui.administration.captivePortal.captivePortalProfiles.edit.set()
--
-- @description :
--
-- @param : 
--
-- @return : 
--
function gui.administration.captivePortal.captivePortalProfiles.edit.set(conf)
       -- include
    require "teamf1lualib/captivePortal"
    
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    status, errMsg = captivePortal.profilesEditSet(conf)
  
    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.administration.captivePortal.captivePortalProfiles.delete()
--
-- @description :
--
-- @param : 
--
-- @return : 
--
function gui.administration.captivePortal.captivePortalProfiles.delete(rowIds)
       -- include
    require "teamf1lualib/captivePortal"

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    db.beginTransaction() --begin transactions

    --delete each MAC filter rule
    for k,v in pairs(rowIds) do
        local inTable = {}
        inTable["CaptivePortalPageDetails._ROWID_"] = v

        status, errMsg = captivePortal.profilesDelete(inTable)
        if (status ~= "OK") then
            break
        end
    end

    if (status ~= "OK") then
        db.rollback()
        return status, errMsg
    end

    db.commitTransaction(true)
    db.save2()

    --return
    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name : gui.administration.osgi.get ()
--
-- @description :
--
-- @param : 
--
-- @return : 
--
function gui.administration.osgi.get()
    -- include
    require "teamf1lualib/osgi"

    -- locals
    local errMsg
    local osgiTbl = {}
    local tmpTbl = {}

    osgiTbl, errMsg = osgi.appList()
    if (errMsg == "ERROR") then
        return tmpTbl
    end

    return osgiTbl
end

-------------------------------------------------------------------------------
-- @name : gui.administration.osgi.editGet (appId)
--
-- @description :
--
-- @param : 
--
-- @return : 
--
function gui.administration.osgi.editGet(appId)
    -- include
    require "teamf1lualib/osgi"

    -- locals
    local osgiTbl = {}
    local retrunTbl = {}

    osgiTbl = gui.administration.osgi.get()
    if (osgiTbl ~= nil) then
    for i,v in pairs (osgiTbl) do
        if (v["id"] == appId) then
            retrunTbl["name"]           = v["name"]
            retrunTbl["description"]    = v["description"]
            retrunTbl["symName"]        = v["symName"]
            retrunTbl["status"]         = v["status"]
        end
    end
    end

    return retrunTbl
end
-------------------------------------------------------------------------------
-- @name : gui.administration.osgi.start (appId)
--
-- @description :
--
-- @param : 
--
-- @return : 
--
function gui.administration.osgi.start(appId)
     -- include
    require "teamf1lualib/osgi"

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg
    
    status, errMsg = osgi.appStart (appId)

    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.administration.osgi.stop (appId)
--
-- @description :
--
-- @param : 
--
-- @return : 
--
function gui.administration.osgi.stop(appId)
     -- include
    require "teamf1lualib/osgi"

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg
    
    status, errMsg = osgi.appStop (appId)

    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.administration.osgi.delete (appId)
--
-- @description :
--
-- @param : 
--
-- @return : 
--
function gui.administration.osgi.delete(appId)
     -- include
    require "teamf1lualib/osgi"

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg
    
    status, errMsg = osgi.appUninstall (appId)

    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.administration.osgi.upload (filePath, fileName)
--
-- @description :
--
-- @param : 
--
-- @return : 

function verifySign (fileName)
    require "kliteLib"
	local pubKey = "/pfrm2.0/etc/public.key"
	local lfile = UPLOAD_DIR .. fileName
	local sigFile = lfile..".sha256"

	-- check for the special characters in fileName and reject if found. Only -,_,. are allowed.
	if fileName ~= nil then
		if fileName:match '[&"#$[%.%./]@%%!^*]' then
    			return "ERROR", "DB_ERROR_INVALID_CHARACTER"
		end
	end

	if (util.fileExists(sigFile) == false ) then
			return "ERROR"
	end

	if (util.fileExists(lfile) == false ) then
			return "ERROR"
	end

    kliteLib.openssl("dgst","-sha1","-verify", pubKey, "-signature", sigFile, "-out", lfile)
--	local cmd = "/pfrm2.0/bin/usrKlite openssl dgst -sha256 -verify " .. pubKey .. " -signature  " .. sigFile .. " " ..lfile .. " > /tmp/check"
--	os.execute (cmd)
	local check = util.fileToString (lfile)
	if (check == "") then
		return "OK"
	else
		return "ERROR"
	end	


end
--
function gui.administration.osgi.upload (filePath, fileName)
     -- include
    require "teamf1lualib/osgi"

     local path, name, extnsn = string.match(fileName, "(.-)([^\/]-([^%.]+))$")
   
    -- check for the file extension. Reject if it is not .jar.
    if ( extnsn ~= 'jar' ) then
    	return "ERROR", "DB_ERROR_INVALID_FILE_EXTENSION"
    end
  
    -- check for the special characters in path and reject if found. Only -,_,. are allowed.
    if path:match '[&"#$[%.%./]@%%!^*]' then
    	return "ERROR", "DB_ERROR_INVALID_CHARACTER"
    end
    
    -- check for the special characters in the name and reject if found. Only -,_,. are allowed.
    if name:match '[&"#$[%.%./]@%%!^*]' then
    	return "ERROR", "DB_ERROR_INVALID_CHARACTER"
    end

    os.execute("mv -f " .. UPLOAD_DIR .. filePath .. "  " .. UPLOAD_DIR .. fileName)

    --locals
    local status, errMsg
	
	status = verifySign (fileName)
	if (status == "ERROR") then
	        return "ERROR", "INVALID_ZIP_FILE"
    end
     
    status, errMsg = osgi.appInstall (UPLOAD_DIR, fileName)
    if (status == "ERROR") then
        errMsg = "INVALID_ZIP_FILE"
    end
    
    --return status, errMsg
    return "OK", "OK"
end

-------------------------------------------------------------------------------
-- @name : gui.administration.osgi.osgiAppiExists ()
--
-- @description :
--
-- @param : 
--
-- @return : 

function gui.administration.osgi.osgiAppiExists (fileName)

    -- return
    return db.existsRow ("osgiApps", "filename", fileName)

end
-------------------------------------------------------------------------------
-- @name : gui.administration.osgi.dfstatGet (path)
--
-- @description :
--
-- @param : 
--
-- @return : 
--
function gui.administration.osgi.dfstatGet(path)
    
    local stats = {}
	local index = 1
	local filename = "/tmp/dfstat"
	local lineno = 0

	os.execute("df -h  " .. path .. " > " .. filename)

	for line in io.lines(filename) do
		lineno = lineno + 1
	    if (lineno > 1) then
			for device,sp1,size,sp2,used,sp3,avail,rest in string.gmatch(line, "([%w/.]*)(%s*)([%w%.]*)(%s*)([%w%.]*)(%s*)([%w%.]*)(.+)") do
		        stats[index] = {}
				stats[index]["device"] = device
		        stats[index]["size"] = size
				stats[index]["used"] = used
		        stats[index]["avail"] = avail
				index = index + 1
			end
		end
	end

	return stats

end

-------------------------------------------------------------------------------
-- @name : gui.administration.osgi.getdiskstats ()
--
-- @description :
--
-- @param : 
--
-- @return : 
--
function gui.administration.osgi.getdiskstats()

    local diskstat ={}

	osgiPartition = db.getAttribute("environment", "name", "OSGI_PARTITION", "value")
	if (osgiPartition ~= nil) then
		stats = gui.administration.osgi.dfstatGet(osgiPartition)
		if ((stats ~= nil) and (stats[1] ~= nil)) then
			diskstat["size"] = stats[1]["size"]
			diskstat["used"] = stats[1]["used"]
			diskstat["avail"] = stats[1]["avail"] 
		end
	end

	return diskstat
end

-------------------------------------------------------------------------------
-- @name : gui.administration.ftp.get()
--
-- @description : This function get FTP Server configuration
--
-- @param : 
--
-- @return : status, errorMsg
--
function gui.administration.ftp.get()
       -- include
    require "teamf1lualib/vsftpd"

    local status = "ERROR"
    local errMsg = "FTPD_CONF_GET_FAILED"
    local confRow = {}

    status, errMsg, confRow = vsftpd.confGet()
    if(status == "ERROR") then
        return "ERROR", "FTPD_CONF_GET_FAILED", nil
    end
    
    confRow["portNumber"] = util.filterXSSChars(confRow["portNumber"])

    --return
    return status, errMsg, confRow
end

-------------------------------------------------------------------------------
-- @name : gui.administration.ftp.set()
--
-- @description : This function set FTP Server configuration
--
-- @param : 
--
-- @return : status, errorMsg
--
function gui.administration.ftp.set(conf)
       -- include
    require "teamf1lualib/vsftpd"
    local matched = 0            
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

	-- check if ftp server is being enabled and port is already beng used in remote mgmt
	if (conf["enable"] == "1") then
		local remoteMgmtRow = db.getRow ("httpsMgmt", "_ROWID_", "1")
        if (remoteMgmtRow ~= nil) then
		if ((remoteMgmtRow ["httpsMgmt.httpsMgmtEnable"] == "1") and (remoteMgmtRow ["httpsMgmt.httpsMgmtPort"] == conf["portNumber"])) then
			return "ERROR","PORT_ALREADY_IN_USE"
		end
        else
            return "ERROR", "DB_ERROR_TRY_AGAIN"
        end

        if ((tonumber (conf["portNumber"]) >= 1 and tonumber (conf["portNumber"]) < 1024) and
            (tonumber(conf["portNumber"]) ~= 20 and tonumber (conf["portNumber"]) ~= 21)) then
            return "ERROR", "RESERVED_PORT_CANNOT_USE"
        end
    -- adding checks for statically configured open ports.
        for p, q in pairs (staticOpenPorts) do
            if (tonumber (conf["portNumber"]) == q) then
                matched = 1
                break
            end
        end

        if (matched == 1) then
            return "ERROR","OPEN_PORT_CANNOT_USE"
        end
	end
    
    local status
    local errMsg

    status, errMsg = vsftpd.configure(conf)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------
-- @name gui.administration.multisubnet.get
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--
function gui.administration.multisubnet.get ()

	require "teamf1lualib/platform" 

    --locals
    local page = {}
    page = platform.multisubnetGet() 
    --return
	if (page == nil) then
		return "ERROR","ERROR", nil
	else
		return "OK", "STATUS_OK", page
	end

end


-------------------------------------------------------------------------
-- @name gui.administration.multisubnet.set
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--
function gui.administration.multisubnet.set (conf)

	require "teamf1lualib/platform"

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
    --locals
    local status, errMsg

    db.beginTransaction() --begin transactions

    status, errMsg = platform.multisubnetSet(conf)

    if (status ~= "OK") then
        db.rollback()
        return status, errMsg
    end

    db.commitTransaction(true)
    db.save2()

    --return
    return "OK", "STATUS_OK"
end 

-------------------------------------------------------------------------------
-- @name : gui.administration.secureF1rstExtension.get()
--
-- @description : This function get secureF1rstExtension configuration
--
-- @param : 
--
-- @return : drivers
--
function gui.administration.secureF1rstExtension.get()
    require "teamf1lualib/pkgMgmt"

    pkgMgmt.sys_DB_conn = db.get_connection() 

    pkgMgmt.pkgdbConnect()

    local drivers = db.getRowsWhere ("pkgMgmtRepo", "Section='Drivers'", false)

    if (#drivers == 0) then
        db.set_connection (pkgMgmt.sys_DB_conn)
        return drivers
    end

    local installed = db.getTable("pkgInstalled", false)
    local pkgSource = db.getTable("pkgMgmtSource", false)
    
    if (pkgSource == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end
    local installed2 = {}

    for k,v in pairs (installed) do
        installed2[v.Package] = v
    end
    for k,v in pairs (drivers) do 
        v.name = v.Package
        v.description = v.Description
        v.buttons = {}
        local i = 1
        v.buttons[i] = {}
        v.uri = pkgSource[1].uri
        v.sourceName = pkgSource[1].sourceName

        if (installed2[v.name]) then
            v.version = installed2[v.name].Version
            if (pkgMgmt.compareVersion (v.Version, v.version) > 0) then
                v.buttons[i] = {}
                v.buttons[i].name="install"
                v.buttons[i].label = "Update to " .. v.Version
                i = i + 1
                v.buttons[i] = {}
            end
            v.buttons[i].name = "remove"
            v.buttons[i].label = "Remove"
        else
            v.buttons[i].name = "install"
            v.buttons[i].label = "Install " .. v.Version
        end
    end

    db.set_connection (pkgMgmt.sys_DB_conn)
    
    return drivers
end

-------------------------------------------------------------------------------
-- @name : gui.administration.secureF1rstExtension.urlGet()
--
-- @description : This function get secureF1rstExtension repository
-- url
--
-- @param : 
--
-- @return : url
--
--
function gui.administration.secureF1rstExtension.urlGet ()
    require "teamf1lualib/pkgMgmt"

    pkgMgmt.sys_DB_conn = db.get_connection()
    
    local url = pkgMgmt.getPkgMgmtSource ()
   
    db.set_connection (pkgMgmt.sys_DB_conn)

    return url
end

-------------------------------------------------------------------------------
-- @name : gui.administration.secureF1rstExtension.urlSet(url)
--
-- @description : This function set secureF1rstExtension repository
-- url
-- @param : 
--
-- @return : status, statCode
--
--
function gui.administration.secureF1rstExtension.urlSet (url)
    require "teamf1lualib/pkgMgmt"

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    local status = "OK" 
    local statCode ="STATUS_OK"
    pkgMgmt.sys_DB_conn = db.get_connection()
   
    local valid = pkgMgmt.setPkgMgmtSource (url)
    if (valid ~= "ok") then
        status = "ERROR"
        statCode = "REPO_SOURCE_CONF_FAILED"
    end
   
    db.set_connection (pkgMgmt.sys_DB_conn)

    return status, statCode

end

-------------------------------------------------------------------------------
-- @name : gui.administration.secureF1rstExtension.action()
--
-- @description : This function set secureF1rstExtension 
--
-- @param : 
--
-- @return : status, statCode
--
--
function gui.administration.secureF1rstExtension.action (command, package)
    require "teamf1lualib/pkgMgmt"

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    local status = "OK"
    local statCode = "STATUS_OK"
    local tmpTbl = {}
    local value = ""

    pkgMgmt.sys_DB_conn = db.get_connection() 

    if (command == "install") then
        status, tmpTbl =  pkgMgmt.installByName (package)
        if (status ~= "ok") then
            status = "ERROR"
            statCode = "PKG_INSTALL_FAILED"
        end
    elseif (command == "remove") then
        status, tmpTbl =  pkgMgmt.removeByName (package)
        if (status ~= "ok") then
            status = "ERROR"
            statCode = "PKG_REMOVE_FAILED"
        end
    elseif (command == "update") then
        if (pkgMgmt.update() ~= "ok") then 
            status = "ERROR"
            statCode = "PKG_UPDATE_FAILED"
        end
    elseif (command == "clear") then
        if (pkgMgmt.clearPkgInstallHistory () ~= "ok") then
            status = "ERROR"
            statCode = "PKG_CLEAR_HISTORY_FAILED"
        end
    else
        status = "ERROR"
        statCode = "STATUS_ERROR"
    end

    db.set_connection (pkgMgmt.sys_DB_conn)

    -- Calling helping systemDB API
    if (status == "ok") then
        if (command == "install") then
            status ,statCode = gui.administration.secureF1rstExtension.systemDB (package, command, tmpTbl)
        elseif (command == "remove") then
            status ,statCode = gui.administration.secureF1rstExtension.systemDB (package, command, tmpTbl)
        end
    end
   
    return status, statCode
end

-------------------------------------------------------------------------------
-- @name : gui.administration.secureF1rstExtension.historyGet()
--
-- @description : This function get secureF1rstExtension history
--
-- @param : 
--
-- @return : history
--
--
function gui.administration.secureF1rstExtension.historyGet ()
    require "teamf1lualib/pkgMgmt"

    pkgMgmt.sys_DB_conn = db.get_connection() 

    pkgMgmt.pkgdbConnect ()

    history = db.getTable ("pkgInstallHistory", false)

    for k,v in pairs (history) do
        v.textMessage = os.date ("%a %b %e %T", tonumber(v.time)) .. " " .. v.textMessage
    end

    db.set_connection (pkgMgmt.sys_DB_conn)
    return history
end

-------------------------------------------------------------------------------
-- @name : gui.administration.secureF1rstExtension.systemDB
--
-- @description : This function updates secureF1rstExtension systemDB 
--
-- @param : 
--
-- @return : status statusCode
--
--
function gui.administration.secureF1rstExtension.systemDB (package, command, tmpTbl)
    require "teamf1lualib/pkgSystemdb"

    local status = "OK"
    local statCode = "STATUS_OK"

    if (command == "install") then
        status, statCode = pkgSys.installByName (package, tmpTbl)
    elseif (command == "remove") then
        status, statCode = pkgSys.removeByName (package, tmpTbl)
    end
    
    return status, statCode
end

-------------------------------------------------------------------------------
-- @name : gui.administration.webMgmt.get()
--
-- @description : This function get Web Management configuration
--
-- @param : 
--
-- @return : status, errorMsg
--
function gui.administration.webMgmt.get()
       -- include
    require "teamf1lualib/firewall"

    local status = "ERROR"
    local errMsg = "WEBACCESS_CONF_GET_FAILED"
    local confRow = {}

    status, errMsg, confRow = firewall.webAccessConfGet()
    if(status == "ERROR") then
        return "ERROR", "WEBACCESS_CONF_GET_FAILED", nil
    end
    
    --return
    return status, errMsg, confRow
end

-------------------------------------------------------------------------------
-- @name : gui.administration.webMgmt.set()
--
-- @description : This function set Web Management configuration
--
-- @param : 
--
-- @return : status, errorMsg
--
function gui.administration.webMgmt.set(conf)
       -- include
    require "teamf1lualib/firewall"

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
    
    local status
    local errMsg

    status, errMsg = firewall.webAccessConfSet(conf)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

----------------------------------------------------------------------------------
-- @name gui.administration.telnet.get ()
--
-- @description This function gets the telnet configuration which is currently set
-- in the device.
--
-- @return
--
-- Main table:-
-- ----------
-- telnet ==> (This is the actual table returned by this function.)
-- {
-- Enable
-- }
-- }
--
function gui.administration.telnet.get()

    local telnetCfg = {}
    local nilTable = {}
    local query= "_ROWID_= 1"
    
    telnetCfg = db.getRowWhere("telnetConfig", query, false)
    if(telnetCfg == nil) then
        return "ERROR","DB_ERROR_TRY_AGAIN",nilTable
    end
    return "OK","STATUS_OK", telnetCfg

end

----------------------------------------------------------------------------------
-- @name gui.administration.telnet.set ()
--
-- @description This function set the telnet configuration into the device .
--
-- @return "OK", "STATUS_OK" on SUCCESS
-- "ERROR", "TELNET_CONFIG_FAILED" on FAILURE
--
function gui.administration.telnet.set(telnetCfg)

    local telnetTbl = {}
    local telnetTbl1 = {}
    local query= "_ROWID_= 1"
    local errMsg
    local statusMsg
    local valid

    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    telnetTbl = db.getRowWhere("telnetConfig", query, false)
    if(telnetTbl == nil) then
        return "ERROR", "TELNET_CONFIG_FAILED"
    else
        telnetTbl["telnetStatus"] = telnetCfg["Status"]
        --db.beginTransation
        db.beginTransaction()
        telnetTbl = util.addPrefix (telnetTbl, "telnetConfig.")
        
        valid = db.update("telnetConfig", telnetTbl, 1)
    end

    if (valid) then
        db.commitTransaction()
        db.save2()
        return "OK", "STATUS_OK"
    else
        db.rollback()
        return "ERROR", "TELNET_CONFIG_FAILED"
    end

end

----------------------------------------------------------------------------------
-- @name gui.administration.apn.set ()
--
-- @description This function set the apn configuration into the device .
--
-- @return "OK", "STATUS_OK" on SUCCESS
-- "ERROR", "APN_CONFIG_FAILED" on FAILURE
--
function gui.administration.apn.set(conf)
    -- require
    require "teamf1lualib/lte"
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    --setting the new configuration in the table
    status, errMsg = lte.defaultAPNSet (conf)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

----------------------------------------------------------------------------------
-- @name gui.administration.apn.get ()
--
-- @description This function get the apn configuration into the device .
--
-- @return 
--
function gui.administration.apn.get()
    -- require
    require "teamf1lualib/lte"
    --locals
    local configTbl = {}

    --getting the values from ApnManagement table
    configTbl = apnManagement.confGet()
    if(configTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    --return
    return "OK", "STATUS_OK", configTbl
end

----------------------------------------------------------------------
-- @name gui.administration.firmware.freeMemCheck ()
--
-- @description This function checks the available free Memory in system .
--
-- @return "YES" on SUCCESS
--         "NO",  on FAILURE
----------------------------------------------------------------------
function gui.administration.firmware.freeMemCheck ()

    -- include
    require "teamf1lualib/util"
    
    --locals
    local status, psKilledStatus = util.freeMemCheck ()

    -- return 
    return status
end

----------------------------------------------------------------------
-- @name gui.administration.changePassword.set ()
--
-- @description This function will change the password after factoryDefault .
--
-- @return "YES" on SUCCESS
--         "NO",  on FAILURE
----------------------------------------------------------------------
function gui.administration.changePassword.set (conf)
   
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
    
    local adminNewPassword = conf["adminNewPassword"]
    local guestNewPassword = conf["guestNewPassword"]

    if(adminNewPassword ~= nil) then
        local error_msg = userdb.passwordCheck(adminNewPassword)
        if (error_msg) then
            return "ERROR", error_msg
        end

        local error_msg = util.validPasswordCheck(adminNewPassword)
        if (error_msg) then
            return "ERROR", error_msg
        end

        local valid = db.setAttribute("users", "username", "admin", "password", adminNewPassword)
        if(tostring(valid) ~= "1") then
            return "ERROR", "DB_ERROR_TRY_AGAIN"
        end 
    end

    if(guestNewPassword ~=nil) then
        local status, error_msg = userdb.passwordCheck(guestNewPassword)
        if (error_msg) then
            return "ERROR", error_msg
        end

        local status, error_msg = util.validPasswordCheck(guestNewPassword)
        if (error_msg) then
            return "ERROR", error_msg
        end


        local valid = db.setAttribute("users", "username", "guest", "password", guestNewPassword)
        if(tostring(valid) ~= "1") then
            return "ERROR", "DB_ERROR_TRY_AGAIN"
        end
    end
    
    db.save2()
    -- return 
    return "OK", "STATUS_OK"
end
if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED")) then
-------------------------------------------------------------------------------
-- @name : gui.administration.wifi.get()
--
-- @description : This function get wifi configuration
--
-- @param : 
--
-- @return : status, errorMsg
--
function gui.administration.meshWifi.get()
       
        -- include
        require "teamf1lualib/easyMeshMgmt"
        
       --locals
        local easyMeshConfigRow = {}
        local configTbl = {}
    
        --get values from 'AlgConf' table
        easyMeshConfigRow = easyMeshMgmt.easyMeshGet()
        if(easyMeshConfigRow == nil) then
            return "ERROR", "DB_ERROR_TRY_AGAIN"
        end
        configTbl["wifiOn"] = easyMeshConfigRow["wifiOn"]
    
        --return
        return "OK", "STATUS_OK", configTbl
    
end
    
function gui.administration.meshWifi.set(inputTable)
            -- require
            require "teamf1lualib/easyMeshMgmt"
        
            -- check for privileges
            if (ACCESS_LEVEL ~= 0) then
                return "ACCESS_DENIED", "ADMIN_REQD"
            end
        
            --locals
            local status, errMsg
            local easyMeshConfigRow = {}
        
            --setting the values in 'AlgConf' table
            easyMeshConfigRow["wifiOn"] = inputTable["wifiOn"]
    status, errMsg = easyMeshMgmt.easyMeshWifiSet(easyMeshConfigRow)

    if (status == "OK") then
        db.save2()
    end
    
    --return
    return status, errMsg
end
-------------------------------------------------------------------------------
-- @name : gui.administration.mesh.get()
--
-- @description : This function get Mesh configuration
--
-- @param : 
--
-- @return : status, errorMsg
function gui.administration.mesh.get()
    
    -- include
    require "teamf1lualib/easyMeshMgmt"
    
   --locals
    local easyMeshConfigRow = {}
    local configTbl = {}

    --get values from 'AlgConf' table
    easyMeshConfigRow = easyMeshMgmt.easyMeshGet()
    if(easyMeshConfigRow == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end
    configTbl["meshEnable"] = easyMeshConfigRow["meshEnable"]

    --return
    return "OK", "STATUS_OK", configTbl

end
function gui.administration.mesh.set(inputTable)
        -- require
        require "teamf1lualib/easyMeshMgmt"
    
        -- check for privileges
        if (ACCESS_LEVEL ~= 0) then
            return "ACCESS_DENIED", "ADMIN_REQD"
        end
 if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED")) then   
    --if wifi is off, no wifi operation is permiitted
    
    local wifienabled = db.getAttribute("easyMesh","meshInterfacename","bdg2","wifiOn")
    
    if(wifienabled == "0") then
        return "ERROR","wifi Operation is not supported When Wifi is disabled"
    end
end
 
        --locals
        local status, errMsg
        local easyMeshConfigRow = {}
    
        --setting the values in 'AlgConf' table
        easyMeshConfigRow["meshEnable"] = inputTable["meshEnable"]
        status, errMsg = easyMeshMgmt.easyMeshSet(easyMeshConfigRow)
    
        if (status == "OK") then
            db.save2()
        end
        
        --return
        return status, errMsg
end
end
-------------------------------------------------------------------------------
-- @name : gui.administration.wifi.get()
--
-- @description : This function get wifi configuration
--
-- @param : 
--
-- @return : status, errorMsg
--
function gui.administration.Wifi.get()
       
        -- include
        require "teamf1lualib/dot11"
        
       --locals
        local wifiConfigRow = {}
        local configTbl = {}
    
        --get values from 'AlgConf' table
        wifiConfigRow = dot11.WifiGet()
        if(wifiConfigRow == nil) then
            return "ERROR", "DB_ERROR_TRY_AGAIN"
        end
        configTbl["wifiOn"] = wifiConfigRow["dot11Wifi.wifiOn"]
    
        --return
        return "OK", "STATUS_OK", configTbl
    
end
    
function gui.administration.Wifi.set(inputTable)
            -- require
            require "teamf1lualib/dot11"
        
            -- check for privileges
            if (ACCESS_LEVEL ~= 0) then
                return "ACCESS_DENIED", "ADMIN_REQD"
            end
        
            --locals
            local status, errMsg
            local wifiConfigRow = {}
        
            --setting the values in 'AlgConf' table
            wifiConfigRow["dot11Wifi.wifiOn"] = inputTable["wifiOn"]
    status, errMsg = dot11.WifiSet(wifiConfigRow)

    if (status == "OK") then
        db.save2()
    end
    
    --return
    return status, errMsg
end
