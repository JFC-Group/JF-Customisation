--[[ easyMeshChangePassword.lua - Handler for Easy Mesh Login passord Change.
--
-- Copyright (c) 2008-2014, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: easyMeshChangePassword.lua
-- Description: Handler for Easy Mesh Login passord Change.
-- 
-- modification history
-- --------------------
-- 01a, 17Dec19, ar written.
--
--]]

require "easyMeshLib"
require "ifDevLib"

-- List of WiFi_AP Tags as defined by Customer Specification.
local WiFi_Obj = {
    ["Result"] = "Result"
}

-- Initialise the SSIDGetResponse_t Lua Table which will be coverted as JSON Object
local WiFiStatusGetResponse_t = {
    ["Result"] = "ERROR",
    ["Response_Code"] = "400",
    ["Error_Message"] = "Failed to get WiFiSSID"
}

-- Supported Return Codes for "SSIDGetResponse"
local WiFiStatusGetResponse_ReturnCodes = {
    ["OK"] = "OK",
    ["ERROR"] = "ERROR",
    ["SUCCESS"] = "Success",
    ["FAILED"]  = "Failed",
}


local WIFISON_NODE_DEVICE_MAC = "Device_MAC"
----------------------------------------------
--Mesh Status Get Request
--
-- @description This function Handles EasyMesh SSID Get Request Method.
--
--returns JSON response for EasyMesh SSID Get Request
--

function WiFiStatusInfoHandler(methodObj, meshRequestMethod)

    local status
    local WiFi_Obj = methodObj["WiFi_Obj"]
    local easyMesh_t
        
    if((WiFi_Obj == nil) or (type(WiFi_Obj) ~= "table"))then
        WiFiStatusGetResponse_t["Result"] = WiFiStatusGetResponse_ReturnCodes["FAILED"]  
        WiFiStatusGetResponse_t["Response_Code"] = "400"
        WiFiStatusGetResponse_t["Error_Message"] = "Bad Request"
        --mesh.sendResponse (WiFiStatusGetResponse_t) 
        return "ERROR", "INVALID_METHOD", WiFiStatusGetResponse_t
    end
   
    --Get the SSID Information from dot11VAP and dot11Profile Table
    easyMesh_t = db.getTable("easyMesh",false)

    if(easyMesh_t == nil) then
        WiFiStatusGetResponse_t["Result"] = WiFiStatusGetResponse_ReturnCodes["FAILED"]  
        WiFiStatusGetResponse_t["Response_Code"] = "400"
        WiFiStatusGetResponse_t["Error_Message"] = "Bad Request"
        --mesh.sendResponse (WiFiStatusGetResponse_t) 
        return "ERROR", "INVALID_METHOD", WiFiStatusGetResponse_t
    end    

    WiFiStatusGetResponse_t["WiFi_Enable"] = db.getAttribute ("easyMesh", "_ROWID_", "1", "wifiOn") 
    WiFiStatusGetResponse_t[WIFISON_NODE_DEVICE_MAC] = ifDevLib.getMac("bdg2")
    WiFiStatusGetResponse_t["Result"] = WiFiStatusGetResponse_ReturnCodes["OK"]  
    WiFiStatusGetResponse_t["Error_Message"] = nil
    WiFiStatusGetResponse_t["Response_Code"] = "200"
    --mesh.sendResponse (WiFiStatusGetResponse_t) 
    return "OK", "SUCCESS", WiFiStatusGetResponse_t

end

meshRequestMethodsList["WiFiStatus"]["methodHandler"] = WiFiStatusInfoHandler



