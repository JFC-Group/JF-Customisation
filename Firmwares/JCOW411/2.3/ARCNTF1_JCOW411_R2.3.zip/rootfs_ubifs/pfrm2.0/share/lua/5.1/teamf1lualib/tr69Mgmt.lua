--[[
--#### 
--#### TeamF1
--#### www.TeamF1.com
--#### Mar 21, 2011
--
--#### Copyright (c) 2011-2014, TeamF1 Networks Pvt. Ltd.
--#### (Subsidiary of D-Link India)
--
--#### File: tr69Mgmt.lua
--#### Description: tr69Mgmt functions
--
--#### Revisions:
--01h, 09Jul18, swr changes for SPR 64269(Missing TR params)
--01g, 31Jul17, swr Changes for SPR 60117
--01f, 30May17, swr changes to add model name to file
--01e, 15Sep16, MSV Made changes for CLM 103497
--01e, 02Sep16, swr Changes for SPR 56532(FCAPS)
--01d, 28Sep15, swr Changes for SPR 53087
--01c, 21Jul15, swr Fix for SPR 52486 
--01b, 27oct14, msv changes for spr#47431
--01a, 08oct13, ash changes for password encryption/descryption
--]]--
--
--
----************* Requires *************
require "teamf1lualib/config"
require "teamf1lualib/trDeviceDefaults"
require "passwdSecureLib"
--
----************* Initial Code *************
--

--package tr69Mgmt
tr69Mgmt = {}
tr69Mgmt.helper = {}
tr69Mgmt.clientPath = "/pfrm2.0/bin/dimclient "
tr69Mgmt.keepAliveScript = "/pfrm2.0/bin/tr69KeepAlive.sh"
tr69Mgmt.logFile = "/tmp/tr69client.log "
tr69Mgmt.staticParamFile = "/pfrm2.0/etc/tmp.param "
tr69Mgmt.runtimeParamFile = "/tmp/cpe3/tmp.param "
tr69Mgmt.confFile = "/pfrm2.0/etc/tr69.cfg"
tr69Mgmt.serialNumFile = "/tmp/cpe3/dps.serial"
tr69Mgmt.debug = 0
tr69Mgmt.logCfg = "/pfrm2.0/etc/tr69.logcfg"
tr69Mgmt.db = "/tmp/cpe3/parameters.db"
tr69Mgmt.prodclassFile = "/tmp/cpe3/dps.productclass"
tr69Mgmt.prodTypeFile = "/tmp/productType"

DEVICE_MANUFACTURER = DEFAULT_DEVICE_MANUFACTURER
DEVICE_MANUFACTURER_OUI = DEFAULT_DEVICE_MANUFACTURER_OUI
DEVICE_MODELNAME = DEFAULT_DEVICE_MODELNAME
DEVICE_DESCRIPTION = DEFAULT_DEVICE_DESCRIPTION
DEVICE_PRODUCT_CLASS = DEFAULT_DEVICE_PRODUCT_CLASS
DEVICE_SERIAL = DEFAULT_DEVICE_SERIAL
DEVICE_HWVERSION = DEFAULT_DEVICE_HWVERSION
DEVICE_CONNECTION_REQUEST_URL = DEFAULT_DEVICE_CONNECTION_REQUEST_URL
--DEVICE_URL = "http://test.dimark.com:8080/dps-basic/TR069"
--DEVICE_URL = "http://testacs.friendly-tech.com:8080/ftacs-digest/ACS"
--DEVICE_USERNAME = "tr-069"
--DEVICE_USERNAME = "RelianceIN"
--DEVICE_PASSWORD = "tr-069"
--DEVICE_PASSWORD = "RelianceIN"

--[[
*****************************************************************************
- Code added to store the value of the product class in a file
--]]
function tr69Mgmt.StoreProdClass()
	os.execute ("echo -n " ..DEVICE_PRODUCT_CLASS.. " > "  ..tr69Mgmt.prodclassFile.. " ")
    os.execute ("echo -n " ..DEVICE_MODELNAME.. " > "  ..tr69Mgmt.prodTypeFile.. " ")
end
--[[
*****************************************************************************
- tr69Mgmt.checkIfFileExists - check if the given file exists 
-
- This function checks if the given file exists
-
- RETURN: 
-]]--
function tr69Mgmt.checkIfFileExists(fileName)
	local fileHandle = nil

	fileHandle = io.open(fileName, "r");
	if (fileHandle == nil) then
		tr69Mgmt.debugPrint("File " .. fileName .. " not found")
		return false
	end
	
	fileHandle:close()
	tr69Mgmt.debugPrint("File " .. fileName .. " found")
	return true
end

--[[
*****************************************************************************
- tr69Mgmt.checkIfFileHasContent - check if the given file exists 
-
- This function checks if the given file exists
-
- RETURN: 
-]]--
function tr69Mgmt.checkIfFileHasContent(fileName)
	local fileHandle = nil
    local fileSize = 0

	fileHandle = io.open(fileName, "r");
	if (fileHandle == nil) then
		tr69Mgmt.debugPrint("File " .. fileName .. " not found")
		return false, fiendleSize
	end
	
    fileSize = fileHandle:seek("end")
	fileHandle:close()
	tr69Mgmt.debugPrint("File " .. fileName .. " found and size is " .. fileSize .. " bytes")
	return true, fileSize
end


--[[
*****************************************************************************
- tr69Mgmt.debugPrint - stop the tr-69 client
-
- This function stops the tr69 client
-
- RETURN: 
-]]--

function tr69Mgmt.debugPrint(debugMsg)
	if (tr69Mgmt.debug == 1) then
		print ("TR69MGMT: " .. debugMsg)
    end
end

--[[
*****************************************************************************
- tr69Mgmt.serialNumRetrieve -  retrieve the serial number
-
- This function retrieves the serial number from the ramdisk 
-
- RETURN: 
-]]--

function tr69Mgmt.serialNumRetrieve()
	local SerialNumber =  nil
	
	fileHandle = io.open(tr69Mgmt.serialNumFile, "r")
    if (fileHandle ~= nil) then
    	SerialNumber = fileHandle:read("*a")
	    fileHandle:close()
    end

	return SerialNumber
end

--[[
*****************************************************************************
- tr69Mgmt.productClassRetrieve -  retrieve the product class
-
- This function retrieves the product class from the ramdisk 
-
- RETURN: 
-]]--

function tr69Mgmt.productClassRetrieve()
	local productClass =  nil
	
	fileHandle = io.open(tr69Mgmt.prodclassFile, "r")
    if (fileHandle ~= nil) then
    	productClass = fileHandle:read("*a")
	    fileHandle:close()
    end

	return productClass
end

--[[
*****************************************************************************
- tr69Mgmt.setDeviceSerial - read device serial
- 
- This function fetches device serial number from environment
-
- RETURN: OK for success else ERROR
-]]--
function tr69Mgmt.setDeviceSerial()
    local value = os.getenv("DEVICE_SERIAL_NUMBER")
    local value2 = os.getenv("DEVICE_WAN_MAC")
    local value3 = os.getenv("DEVICE_HW_VERSION")
    if (value == nil) then
        tr69Mgmt.debugPrint("Couldn't get serial from environment")

        tr69Mgmt.debugPrint("Calling tr69Mgmt.serialNumRetrieve")
        value = tr69Mgmt.serialNumRetrieve()
        if (value == nil) then
            tr69Mgmt.serialNumRetrieve("Couldn't get serial from file")
            return "ERROR"
        end
    end

    DEVICE_SERIAL = value
    DEVICE_HWVERSION = value3
    tr69Mgmt.setMgmtOUI( value2 )
    tr69Mgmt.debugPrint("DEVICE_SERIAL:" .. DEVICE_SERIAL)

    return "OK"
end

--[[
*****************************************************************************
- tr69Mgmt.setMgmtOUI - read device serial
- 
- This function fetches management OUI from environment
-
- RETURN: OK for success else ERROR
-]]--

function tr69Mgmt.setMgmtOUI (serial)
    local value = string.sub (serial, 1, 6)
    DEVICE_MANUFACTURER_OUI = value
    tr69Mgmt.debugPrint("DEVICE_MANUFACTURER_OUI:" .. DEVICE_MANUFACTURER_OUI)
    return "OK"
end

--[[
*****************************************************************************
- tr69Mgmt.stop - stop the tr-69 client
-
- This function stops the tr69 client
-
- RETURN: 
-]]--
function tr69Mgmt.stop()
	local command = "killall -9 dimclient"
	local status = 0

    -- before killing dimclient, check if the ACS LED related files are present and
    -- if so remove them and run led.lua script to reset the LED behaviour
    if (util.fileExists("/tmp/acsFailed")) then
        os.remove ("/tmp/acsFailed")
        os.execute ("/pfrm2.0/bin/lua /pfrm2.0/bin/led.lua")
    end
	-- stop the tr-069 client
	tr69Mgmt.debugPrint("EXEC:  " .. command)
	status = os.execute(command)
	if (status ~= 0) then
		tr69Mgmt.debugPrint("command execution failed with status: " .. status)
	end

    -- stop the keepalive script
    command = "killall -15 tr69KeepAlive.sh"
    tr69Mgmt.debugPrint("script EXEC:  " .. command)
    os.execute(command)

	return
end

--[[
*****************************************************************************
- tr69Mgmt.start - start the tr-069 client
-
- This function starts the tr-069 client
- -h - Help
- -d - IP address for binding Connection Request handler
- -b - Base port for binding Connection Request handler
- -p - Temporary folder for runtime DB (must be writable)
- -i - Proxy host
- -o - Proxy port
- -f - Configuration file
- -l - Log configuration file path (default "log.config")
-
- RETURN: 
-]]--
function tr69Mgmt.start(acs_config, tr69ClientfilePath)
	require "ifDevLib"
	local logcfg = tr69Mgmt.logCfg

    util.runShellCmd("/bin/touch /tmp/dimclientBindToAnyAddr", nil, nil, nil) 

    local tr69Clientbinary = ""
    if (tr69ClientfilePath ~= nil) then
        tr69Clientbinary = tr69ClientfilePath
    else
        tr69Clientbinary = tr69Mgmt.clientPath
    end
    tr69Mgmt.debugPrint("Entering tr69Mgmt.start function...")

    local command = " " .. tr69Clientbinary .. " -l" .. tr69Mgmt.logCfg .." -p/tmp/cpe3 -b" .. acs_config["PortBase"] .." -d::/128"
	local status = 0

	--command = " " .. command .. " -b " .. acs_config["PortBase"]
	command = " " .. command .. " -f " .. tr69Mgmt.confFile
    command = " " .. command .. " & "

	-- start the tr-069 client
	tr69Mgmt.debugPrint("EXEC:  " .. command)
	status = ifDevLib.cmdExec(command, "/dev/null", 1)
	if (status ~= 0) then
		tr69Mgmt.debugPrint("command execution failed with status: " .. status)
	end

    -- start the keepalive script
    command = " " .. tr69Mgmt.keepAliveScript .. " & "
    tr69Mgmt.debugPrint("script EXEC:  " .. command)
    ifDevLib.cmdExec(command, "/dev/null", 1)

	return status
end

--[[
*****************************************************************************
- tr69Mgmt.configure - configure TR-069 client
- 
- This function re-writes the TR-069 configuration and starts the client
-
- RETURN: 0 for success else 1
-]]--
function tr69Mgmt.configure(tr69_config, tr69ClientfilePath)
    local configStatus = ""

	if (tr69_config == nil) then
		-- get the configurable parameters from the database
		query = "_ROWID_=1"
		tr69_config = db.getRowWhere("tr69Config", query, false)
	end

    -- fetch device serial based on device MAC address
    configStatus = tr69Mgmt.setDeviceSerial()
    if (configStatus ~= "OK") then 
        tr69Mgmt.debugPrint("Couldn't determine device serial, exiting..")
        return 0
    end

    --storing the device productclass to a file in flash
    tr69Mgmt.StoreProdClass()
    -- configure tr69 only when it is enabled
    if (tr69_config["tr69Status"] == "0") then
        -- stop the tr-069 client
		tr69Mgmt.stop()

        return 0 
    end

	os.execute("mkdir -p /var/log/")

	if (tr69_config ~= nil) then
		-- copy the static configuration file
		os.execute("cp  " .. tr69Mgmt.staticParamFile .. "  " .. tr69Mgmt.runtimeParamFile .. " ")

		-- re-write the configuration file & update the params db if exists
		tr69Mgmt.configReWrite(tr69Mgmt.runtimeParamFile, tr69_config)
	
		-- stop the tr-069 client
		tr69Mgmt.stop()

		-- start the tr-069 client
		tr69Mgmt.start(tr69_config, tr69ClientfilePath)
	end

    return 0
end

--[[
*****************************************************************************
- tr69Mgmt.configReWrite - rewrite dps.param
-
- This function rewrites the configurable parameters in dps.param.
-
- RETURN: 
-]]--
function tr69Mgmt.configReWrite(file, tr69_config)
    require "teamf1lualib/db"

    if (util.fileExists(tr69Mgmt.db)) then
        -- connect to the tr69 database
        db.connect(tr69Mgmt.db);
    end

    -- rewrite device info configuration
    tr69Mgmt.helper.rewriteDeviceServerCfg (file, tr69_config)

	-- rewrite acs server configuration
    tr69Mgmt.helper.rewriteAcsServerCfg (file, tr69_config)

    --TODO update CRQ configuration
    --TODO update STUN configuration

    -- rewrite connection request address
    tr69Mgmt.helper.rewriteUDPconnectionRequestAddress (file, DEVICE_CONNECTION_REQUEST_URL);

    -- rewrite provisioning code
    tr69Mgmt.helper.rewriteProvisioningCode (file, tr69_config)

    if (util.fileExists(tr69Mgmt.db)) then
        -- restore system db connection
        db.connect("/tmp/system.db")
    end

	return 
end

--[[
*****************************************************************************
- tr69Mgmt.helper.rewriteDeviceServerCfg  - rewrite acs account configuration
-
- This function re-writes the following parameters in dps.param
-
- Device.DeviceInfo.Manufacturer;
- Device.DeviceInfo.ManufacturerOUI;
- Device.DeviceInfo.ModelName;
- Device.DeviceInfo.Description;
- Device.DeviceInfo.ProductClass;
- Device.DeviceInfo.SerialNumber;
- Device.DeviceInfo.HardwareVersion
- Device.ManagementServer.ConnectionRequestURL
- 
- RETURN: 
-]]--
function tr69Mgmt.helper.rewriteDeviceServerCfg (file, tr69_config)
    -- rewrite manufacturer oui
    tr69Mgmt.helper.searchReplace(file, "DEVICE_MANUFACTURER_OUI", DEVICE_MANUFACTURER_OUI);

    -- rewrite manufacturer
    tr69Mgmt.helper.searchReplace(file, "DEVICE_MANUFACTURER", DEVICE_MANUFACTURER);

    -- rewrite model name
    tr69Mgmt.helper.searchReplace(file, "DEVICE_MODELNAME", DEVICE_MODELNAME);

    -- rewrite description
    tr69Mgmt.helper.searchReplace(file, "DEVICE_DESCRIPTION", DEVICE_DESCRIPTION);

    -- rewrite product class
    tr69Mgmt.helper.searchReplace(file, "DEVICE_PRODUCT_CLASS", DEVICE_PRODUCT_CLASS);

    -- rewrite device serial
    tr69Mgmt.helper.searchReplace(file, "DEVICE_SERIAL", DEVICE_SERIAL);

    -- rewrite device hardware version
    tr69Mgmt.helper.searchReplace(file, "DEVICE_HWVERSION", DEVICE_HWVERSION);

    -- rewrite connection request url
    tr69Mgmt.helper.searchReplace(file, "DEVICE_CONNECTION_REQUEST_URL", DEVICE_CONNECTION_REQUEST_URL);
    

end

--[[
*****************************************************************************
- tr69Mgmt.rewriteAcsServerCfg  - rewrite acs account configuration
-
- This function re-writes the following parameters in dps.param
-
- Device.ManagementServer.URL
- Device.ManagementServer.Username
- Device.ManagementServer.Password
- Device.ManagementServer.PeriodicInformInterval
-
- RETURN: 
-]]--
function tr69Mgmt.helper.rewriteAcsServerCfg(file, acs_config)

    if (util.fileExists(tr69Mgmt.db)) then
        if (acs_config["tr69Status"] ~= nil) then
	    	tr69Mgmt.helper.searchReplace(file, "DEVICE_TRSTATUS", acs_config["tr69Status"])
            db.setAttribute("params", "name", "Device.ManagementServer.EnableCWMP", 
                            "value", acs_config["tr69Status"])
	    end

        if (acs_config["URL"] ~= nil) then
	    	tr69Mgmt.helper.searchReplace(file, "DEVICE_URL", acs_config["URL"])
            db.setAttribute("params", "name", "Device.ManagementServer.URL", 
                            "value", acs_config["URL"])
	    end

        if (acs_config["Username"] ~= nil and acs_config["ACSPasswordGeneration"] == "0") then
            tr69Mgmt.helper.searchReplace(file, "DEVICE_USERNAME", acs_config["Username"])
            db.setAttribute("params", "name", "Device.ManagementServer.Username", 
                            "value", acs_config["Username"])
        end

	    if (acs_config["Password"] ~= nil and acs_config["ACSPasswordGeneration"] == "0") then
            tr69Mgmt.helper.searchReplace(file, "DEVICE_PASSWORD", acs_config["Password"])
            db.setAttribute("params", "name", "Device.ManagementServer.Password", 
                            "value", acs_config["Password"])
        end
        
        if (acs_config["ACSPasswordGeneration"] == "1") then
            tr69Mgmt.helper.searchReplace(file, "DEVICE_USERNAME", acs_config["serialUsername"])
            db.setAttribute("params", "name", "Device.ManagementServer.Username", 
                            "value", acs_config["serialUsername"])
		    tr69Mgmt.helper.searchReplace(file, "DEVICE_PASSWORD", acs_config["serialPassword"])
            db.setAttribute("params", "name", "Device.ManagementServer.Password", 
                            "value", acs_config["serialPassword"])
        end

        if (acs_config["InformInterval"] ~= nil) then
            tr69Mgmt.helper.searchReplace(file, "DEVICE_PERIODICINFORMINTERVAL", acs_config["InformInterval"])
            db.setAttribute("params", "name", "Device.ManagementServer.PeriodicInformInterval", 
                            "value", acs_config["InformInterval"])
        end
        
        if (acs_config["DefaultActiveNotificationThrottle"] ~= nil) then
            tr69Mgmt.helper.searchReplace(file, "DEVICE_DEFAULTACTIVENOTIFICATIONTHROTTLE", acs_config["DefaultActiveNotificationThrottle"])
            db.setAttribute("params", "name", "Device.ManagementServer.DefaultActiveNotificationThrottle", 
                            "value", acs_config["DefaultActiveNotificationThrottle"])
        end
        
        if (acs_config["ConnectionRequestUsername"] ~= nil) then
            tr69Mgmt.helper.searchReplace(file, "DEVICE_CONNECTIONREQUESTUSERNAME", acs_config["ConnectionRequestUsername"])
            db.setAttribute("params", "name", "Device.ManagementServer.ConnectionRequestUsername", 
                            "value", acs_config["ConnectionRequestUsername"])
        end

        if (acs_config["ConnectionRequestPassword"] ~= nil) then
            tr69Mgmt.helper.searchReplace(file, "DEVICE_CONNECTIONREQUESTPASSWORD", acs_config["ConnectionRequestPassword"])
            db.setAttribute("params", "name", "Device.ManagementServer.ConnectionRequestPassword", 
                            "value", acs_config["ConnectionRequestPassword"])
        end
        
        if (acs_config["CWMPRetryMinimumWaitInterval"] ~= nil) then
            tr69Mgmt.helper.searchReplace(file, "DEVICE_CWMPRETRYMINIMUMWAITINTERVAL", acs_config["CWMPRetryMinimumWaitInterval"])
            db.setAttribute("params", "name", "Device.ManagementServer.CWMPRetryMinimumWaitInterval", 
                            "value", acs_config["CWMPRetryMinimumWaitInterval"])
        end
        
        if (acs_config["CWMPRetryIntervalMultiplier"] ~= nil) then
            tr69Mgmt.helper.searchReplace(file, "DEVICE_CWMPRETRYINTERVALMULTIPLIER", acs_config["CWMPRetryIntervalMultiplier"])
            db.setAttribute("params", "name", "Device.ManagementServer.CWMPRetryIntervalMultiplier", 
                            "value", acs_config["CWMPRetryIntervalMultiplier"])
        end

        if (acs_config["STUNEnable"] ~= nil) then
            tr69Mgmt.helper.searchReplace(file, "DEVICE_STUNENABLE", acs_config["STUNEnable"])
            db.setAttribute("params", "name", "Device.ManagementServer.STUNEnable", 
                            "value", acs_config["STUNEnable"])
        end

        if (acs_config["STUNServerAddress"] ~= nil) then
            tr69Mgmt.helper.searchReplace(file, "DEVICE_STUNSERVERADDRESS", acs_config["STUNServerAddress"])
            db.setAttribute("params", "name", "Device.ManagementServer.STUNServerAddress", 
                            "value", acs_config["STUNServerAddress"])
        end

        if (acs_config["STUNUsername"] ~= nil) then
            tr69Mgmt.helper.searchReplace(file, "DEVICE_STUNUSERNAME", acs_config["STUNUsername"])
            db.setAttribute("params", "name", "Device.ManagementServer.STUNUsername", 
                            "value", acs_config["STUNUsername"])
        end

        if (acs_config["STUNPassword"] ~= nil) then
            tr69Mgmt.helper.searchReplace(file, "DEVICE_STUNPASSWORD", acs_config["STUNPassword"])
            db.setAttribute("params", "name", "Device.ManagementServer.STUNPassword", 
                            "value", acs_config["STUNPassword"])
        end

        if (acs_config["PeriodicInformEnable"] ~= nil) then
            tr69Mgmt.helper.searchReplace(file, "DEVICE_PERIODICINFORMENABLE", acs_config["PeriodicInformEnable"]) 
            db.setAttribute("params", "name", "Device.ManagementServer.PeriodicInformEnable",
		            "value", acs_config["PeriodicInformEnable"])
        end

        if (acs_config["PeriodicInformTime"] ~= nil) then
            tr69Mgmt.helper.searchReplace(file, "DEVICE_PERIODICINFORTIME", acs_config["PeriodicInformTime"]) 
            db.setAttribute("params", "name", "Device.ManagementServer.PeriodicInformTime",
		            "value", acs_config["PeriodicInformTime"])
        end

        if (acs_config["STUNServerPort"] ~= nil) then
            tr69Mgmt.helper.searchReplace(file, "DEVICE_STUNPORT", acs_config["STUNServerPort"]) 
            db.setAttribute("params", "name", "Device.ManagementServer.STUNServerPort",
		            "value", acs_config["STUNServerPort"])
        end
		
		if (acs_config["STUNMaximumKeepAlivePeriod"] ~= nil) then
            tr69Mgmt.helper.searchReplace(file, "DEVICE_STUNMAXALIVEPERIOD", acs_config["STUNMaximumKeepAlivePeriod"]) 
            db.setAttribute("params", "name", "Device.ManagementServer.STUNMaximumKeepAlivePeriod",
		            "value", acs_config["STUNMaximumKeepAlivePeriod"])
        end

		if (acs_config["STUNMinimumKeepAlivePeriod"] ~= nil) then
            tr69Mgmt.helper.searchReplace(file, "DEVICE_STUNMINALIVEPERIOD", acs_config["STUNMinimumKeepAlivePeriod"]) 
            db.setAttribute("params", "name", "Device.ManagementServer.STUNMinimumKeepAlivePeriod",
		            "value", acs_config["STUNMinimumKeepAlivePeriod"])
        end
        if (acs_config["CRSURLList"] ~= nil) then
            tr69Mgmt.helper.searchReplace(file, "DEVICE_CRSURLList", acs_config["CRSURLList"])
            db.setAttribute("params", "name", "Device.ManagementServer.X_RJIL_COM_CRSURLList", 
                            "value", acs_config["CRSURLList"])
            local file = io.open("/tmp/tr69URL.txt","w")
            if (file ~= nil) then
               file:write(acs_config["CRSURLList"])
               file:close()
            end
        end

    else -- previous cfg doesn't exist
        tr69Mgmt.helper.searchReplace(file, "DEVICE_TRSTATUS", acs_config["tr69Status"])
        tr69Mgmt.helper.searchReplace(file, "DEVICE_URL", acs_config["URL"])
        if (acs_config["ACSPasswordGeneration"] == "0") then
            -- add logic to user serial generated password only if device is in factory state
		    if (util.fileExists ("/pfrm2.0/HW_FOXCONN")) then
                tr69Mgmt.helper.searchReplace(file, "DEVICE_USERNAME", acs_config["Username"])
                tr69Mgmt.helper.searchReplace(file, "DEVICE_PASSWORD", acs_config["Password"])
            else
                if (not(util.fileExists ("/flash/teamf1.cfg.ascii"))) then
                    tr69Mgmt.helper.searchReplace(file, "DEVICE_USERNAME", acs_config["serialUsername"])
                    tr69Mgmt.helper.searchReplace(file, "DEVICE_PASSWORD", acs_config["serialPassword"])
                else
                    if(acs_config["Username"] == "" or acs_config["Username"] == nil) then
                        tr69Mgmt.helper.searchReplace(file, "DEVICE_USERNAME", acs_config["serialUsername"])
                    else
                        tr69Mgmt.helper.searchReplace(file, "DEVICE_USERNAME", acs_config["Username"])
                    end

                    if(acs_config["Password"] == "" or acs_config["Password"] == nil) then
                        tr69Mgmt.helper.searchReplace(file, "DEVICE_PASSWORD", acs_config["serialPassword"])
                    else
                        tr69Mgmt.helper.searchReplace(file, "DEVICE_PASSWORD", acs_config["Password"])
                    end
                end
            end
        else
            tr69Mgmt.helper.searchReplace(file, "DEVICE_USERNAME", acs_config["serialUsername"])
            tr69Mgmt.helper.searchReplace(file, "DEVICE_PASSWORD", acs_config["serialPassword"])
        end

        tr69Mgmt.helper.searchReplace(file, "DEVICE_PERIODICINFORMINTERVAL", acs_config["InformInterval"])
        tr69Mgmt.helper.searchReplace(file, "DEVICE_DEFAULTACTIVENOTIFICATIONTHROTTLE", acs_config["DefaultActiveNotificationThrottle"])
        tr69Mgmt.helper.searchReplace(file, "DEVICE_STUNENABLE", acs_config["STUNEnable"])
        tr69Mgmt.helper.searchReplace(file, "DEVICE_STUNSERVERADDRESS", acs_config["STUNServerAddress"])
        tr69Mgmt.helper.searchReplace(file, "DEVICE_STUNUSERNAME", acs_config["STUNUsername"])
        tr69Mgmt.helper.searchReplace(file, "DEVICE_STUNPASSWORD", acs_config["STUNPassword"])
        tr69Mgmt.helper.searchReplace(file, "DEVICE_PERIODICINFORMENABLE", acs_config["PeriodicInformEnable"])
        tr69Mgmt.helper.searchReplace(file, "DEVICE_CONNECTIONREQUESTUSERNAME", acs_config["ConnectionRequestUsername"])
        tr69Mgmt.helper.searchReplace(file, "DEVICE_CONNECTIONREQUESTPASSWORD", acs_config["ConnectionRequestPassword"])
        tr69Mgmt.helper.searchReplace(file, "DEVICE_CWMPRETRYMINIMUMWAITINTERVAL", acs_config["CWMPRetryMinimumWaitInterval"])
        tr69Mgmt.helper.searchReplace(file, "DEVICE_CWMPRETRYINTERVALMULTIPLIER", acs_config["CWMPRetryIntervalMultiplier"])
        tr69Mgmt.helper.searchReplace(file, "DEVICE_PERIODICINFORTIME", acs_config["PeriodicInformTime"])
        tr69Mgmt.helper.searchReplace(file, "DEVICE_STUNPORT", acs_config["STUNServerPort"])
        tr69Mgmt.helper.searchReplace(file, "DEVICE_STUNMAXALIVEPERIOD", acs_config["STUNMaximumKeepAlivePeriod"])
        tr69Mgmt.helper.searchReplace(file, "DEVICE_STUNMINALIVEPERIOD", acs_config["STUNMinimumKeepAlivePeriod"])        
        tr69Mgmt.helper.searchReplace(file, "DEVICE_CRSURLList", acs_config["CRSURLList"])
        local filecrs = io.open("/tmp/tr69URL.txt","w")
        if (filecrs ~= nil) then
            filecrs:write(acs_config["CRSURLList"])
            filecrs:close()
        end
    end

	return
end   

--[[
*****************************************************************************
- tr69Mgmt.helper.rewriteProvisioningCode - rewrite provisioning code
-
- This function re-writes the following parameters in dps.param
-
- InternetGatewayDevice.DeviceInfo.ProvisioningCode
-
- RETURN: 
-]]--
function tr69Mgmt.helper.rewriteProvisioningCode (file, provisioningCode_config)

    if (provisioningCode_config["ProvisioningCode"] ~= nil) then
		tr69Mgmt.helper.searchReplace(file, "DEVICE_PROVISIONINGCODE", provisioningCode_config["ProvisioningCode"])
        if (util.fileExists(tr69Mgmt.db)) then
            db.setAttribute("params", "name", "Device.ManagementServer.ProvisioningCode", 
                            "value", provisioningCode_config["ProvisioningCode"])
        end
	end
end

--[[
*****************************************************************************
- tr69Mgmt.helper.rewriteUDPconnectionRequestAddress - rewrite UDPConnectionRequestAddress
-
- This function extract and rewrite the UDPConnectionRequestAddress from ConnectionRequestURL
-
- InternetGatewayDevice.DeviceInfo.UDPConnectionRequestAddress
-
- RETURN: 
-]]--

function tr69Mgmt.helper.rewriteUDPconnectionRequestAddress (file, connectionReuestURL)
    local port = 7547
    local extractPart = string.sub(connectionReuestURL, 8)
    local index = string.find(extractPart, ":")
    local ipAddr = string.sub(extractPart,1, index)
    udpConnectionRequestAddress = ipAddr .. port
    tr69Mgmt.helper.searchReplace(file, "DEVICE_CONNECTION_REQUEST_ADDRESS", udpConnectionRequestAddress)
end

--[[
*****************************************************************************
- tr69Mgmt.searchReplace - search/replace pattern
-
- This function searches and replaces a pattern in the given file.
-
- RETURN: 
-]]--

function tr69Mgmt.helper.searchReplace(file, pattern, substString)
	local command = "/bin/sed -i 's"

	-- substitute all occurences of / in the string with // so that sed
	-- can escape it.
	--
	substString = string.gsub(substString, "/", "\\/")
	tr69Mgmt.debugPrint ("replacing pattern: " .. pattern .. " with " .. substString ..  " in " .. file)

	if (substString ~= nil) then
		command = command .. "/" .. pattern .. "/" .. substString .. "/g' " .. file
		local status = os.execute(command)
		if (status ~= 0) then
			tr69Mgmt.debugPrint("Command execution failed with status: " .. status)
		end
	end

	return
end

--[[
*****************************************************************************
- tr69Mgmt.dbEdit - edit the configuration in the database 
-
- This function edits the configuration in the database.
-
- RETURN: 
-]]--

function tr69Mgmt.dbEdit(table, conf, rowid, operation)

    if (db.typeAndRangeValidate(conf)) then
        if (operation == "add") then
            return db.insert(table, conf)
        elseif (operation == "edit") then
            return db.update(table, conf, rowid)
        elseif (operation == "delete") then
			return  nil
        end
    end

end

--[[
*****************************************************************************
- tr69Mgmt.serialNumStore -  store the serial number
-
- This function stores the serial number in ramdisk for later retrieval
-
- RETURN: 
-]]--

function tr69Mgmt.serialNumStore(SerialNumber)
	local fileHandle =  nil
	
	if (SerialNumber ~= nil) then
		fileHandle = io.open(tr69Mgmt.serialNumFile, "w")
		fileHandle:write(SerialNumber)
		fileHandle:close()
	end
end

--[[
*****************************************************************************
- tr69Mgmt.serialNumRetrieve -  retrieve the serial number
-
- This function retrieves the serial number from the ramdisk 
-
- RETURN: 
-]]--

function tr69Mgmt.serialNumRetrieve()
	local SerialNumber =  nil
	
	fileHandle = io.open(tr69Mgmt.serialNumFile, "r")
    if (fileHandle ~= nil) then
    	SerialNumber = fileHandle:read("*a")
	    fileHandle:close()
    end

	return SerialNumber
end

--[[
*****************************************************************************
- tr69Mgmt.import - import configuration
-
- This function imports the configuration into the database.
-
- RETURN: 
-]]--

function tr69Mgmt.import (tr69Cfg, defTr69Cfg, removeCfg)
	local tr69configTbl = nil
    local acsAlarmFaultTbl = nil
    local acsAlarmTbl = nil
    local acsFaultTbl = nil

    local status
    local DEFAULT_THROTTLE = "10"

	if ((tr69Cfg == nil)  and (defTr69Cfg == nil)) then
		return
    elseif ((tr69Cfg == nil) and (defTr69Cfg ~= nil)) then
        tr69Cfg = defTr69Cfg
    end

    if(tr69Cfg["acsAlarmsFaults"] == nil and defTr69Cfg["acsAlarmsFaults"] ~= nil) then
        tr69Cfg["acsAlarmsFaults"] = defTr69Cfg["acsAlarmsFaults"]
    end

    if(tr69Cfg["acsAlarms"] == nil and defTr69Cfg["acsAlarms"] ~= nil) then
        tr69Cfg["acsAlarms"] = defTr69Cfg["acsAlarms"]
    end

    if(tr69Cfg["acsFaults"] == nil and defTr69Cfg["acsFaults"] ~= nil) then
        tr69Cfg["acsFaults"] = defTr69Cfg["acsFaults"]
    end

    local cfg = {}
    local acsCfg = {}
    local acsAlarmsCfg = {}
    local acsFaultsCfg = {}
    local configMergeDone = "0"
    local configMergeDone1 = "0"
    local configMergeDone2 = "0"

    if (tr69Cfg["ManagementServer"] ~= nil) then
        cfg = config.update (tr69Cfg.ManagementServer, defTr69Cfg.ManagementServer, removeCfg.ManagementServer)
        tr69configTbl = cfg[1]
    end

    if (tr69configTbl ~= nil ) then
        if (tr69configTbl["Password"] ~= nil and
            tr69configTbl["Password"] ~= "") then
            status, tr69configTbl["Password"] = 
                passwdSecureLib.decryptData (tr69configTbl["Password"], "")
        end
        local fp = io.open("/tmp/acs_passwd", "r")
         if (fp ~= nil) then
             tr69configTbl["serialPassword"] = fp:read("*line")
             fp:close();
         end 
         local fp = io.open("/tmp/deviceSerial", "r")
         if (fp ~= nil) then
             tr69configTbl["serialUsername"] = fp:read("*line")
             fp:close();
         end 
        if (tr69configTbl["STUNPassword"] ~= nil and
            tr69configTbl["STUNPassword"] ~= "") then
            status, tr69configTbl["STUNPassword"] =
                passwdSecureLib.decryptData (tr69configTbl["STUNPassword"], "")
        end
        if (tr69configTbl["ConnectionRequestPassword"] ~= nil and
            tr69configTbl["ConnectionRequestPassword"] ~= "") then
            status, tr69configTbl["ConnectionRequestPassword"] =
                passwdSecureLib.decryptData (tr69configTbl["ConnectionRequestPassword"], "")
        end
	if (tonumber(tr69configTbl["DefaultActiveNotificationThrottle"]) > tonumber(tr69configTbl["InformInterval"])) then
	    tr69configTbl["DefaultActiveNotificationThrottle"] = DEFAULT_THROTTLE
	end
        if (tr69configTbl["PortBase"] == "9000") then
	    tr69configTbl["PortBase"] = defTr69Cfg.ManagementServer[1]["PortBase"]
	end
        if (tr69configTbl["PortBase"] == "8080") then
	    tr69configTbl["PortBase"] = defTr69Cfg.ManagementServer[1]["PortBase"]
	end
		-- add logic to user serial generated password only if device is in factory state

		-- remove unique password for JCS5100 as per below mail
		-- email - "Re: Builds for JCS5100 (Incremental build) & JCO500 (Test Build) || 1st June 2016 ||"
   			   
		if (not(util.fileExists ("/pfrm2.0/HW_FOXCONN"))) then
			if (not(util.fileExists ("/flash/teamf1.cfg.ascii"))) then
				tr69configTbl["Password"] = tr69configTbl["serialPassword"]
				tr69configTbl["Username"] = tr69configTbl["serialUsername"]
			end
		end

		if (util.fileExists("/pfrm2.0/DEVICE_REPEATER")) then
        	if(not(util.fileExists("/flash/acsConfigUpdate"))) then
            	local file = io.open("/flash/acsConfigUpdate","w")
            	if (file ~= nil) then
                	file:close()
            	end
    			local cmdStrinterval ="/userfs/bin/tcapi get Cwmp_Entry periodInterval > /tmp/acs_interval"
    			local cmdStrurl ="/userfs/bin/tcapi get Cwmp_Entry acsUrl > /tmp/acs_url"
    			local cmdStrusername ="/userfs/bin/tcapi get Cwmp_Entry acsUserName > /tmp/acs_uname"
    			local cmdStrpassword ="/userfs/bin/tcapi get Cwmp_Entry acsPassword > /tmp/acs_password"
                local cmdStrStunEnable ="/userfs/bin/tcapi get Cwmp_Entry StunEnable > /tmp/acs_stunenable"
                local cmdStrStunUrl ="/userfs/bin/tcapi get Cwmp_Entry StunUrl >/tmp/acs_stunurl"
                local cmdStrStunUsername ="/userfs/bin/tcapi get Cwmp_Entry StunUsername > /tmp/acs_stunusername"
                local cmdStrStunPassword ="/userfs/bin/tcapi get Cwmp_Entry StunPassword > /tmp/acs_stunPassword"
                os.execute(cmdStrurl)
                local url=util.fileToString("/tmp/acs_url")
                url = url:sub(1, (#url - 1))
                tr69configTbl["URL"]=url
                os.execute(cmdStrinterval)
                local interval =util.fileToString("/tmp/acs_interval")
                interval = interval:sub(1, (#interval - 1))
                tr69configTbl["InformInterval"]=interval
                os.execute(cmdStrpassword)
                local password = util.fileToString("/tmp/acs_password")
                password = password:sub(1, (#password -1))
                tr69configTbl["Password"]=password
                os.execute(cmdStrusername)
                local username = util.fileToString("/tmp/acs_uname")
                username = username:sub(1, (#username -1))
                tr69configTbl["Username"]=username
                os.execute(cmdStrStunEnable)
                local stunenable = util.fileToString("/tmp/acs_stunenable")
                if ( stunenable ~= nil) then
                    stunenable = stunenable:sub(1, (#stunenable -1))
                    tr69configTbl["STUNEnable"]=stunenable
                end
                os.execute(cmdStrStunUrl)
                local stunurl = util.fileToString("/tmp/acs_stunurl")
                if ( stunurl ~= nil) then
                    stunurl = stunurl:sub(1, (#stunurl -1))
                    tr69configTbl["STUNServerAddress"]=stunurl
                end
                os.execute(cmdStrStunUsername)
                local stununame = util.fileToString("/tmp/acs_stunusername")
                if (stununame ~= nil) then
                    stununame = stununame:sub(1, (#stununame -1))
                    tr69configTbl["STUNUsername"]=stununame
                end
                os.execute(cmdStrStunPassword)
                local stunpasswd = util.fileToString("/tmp/acs_stunPassword")
                if ( stunpasswd ~= nil) then
                    stunpasswd = stunpasswd:sub(1, (#stunpasswd -1))
                    tr69configTbl["STUNPassword"]=stunpasswd
                end
            end
        end


		-- for HG260X , enforce a one time move to unique useername/password when upgrding from old image
		-- CLM : 455221	"TeamF1 - HG260X : Force usage of unique ACS credentials
		if ((util.fileExists ("/pfrm2.0/HW_HG260X")) and (not(util.fileExists ("/flash/configMerge/useTr69UseUniqueCredentials")))) then
				tr69configTbl["Password"] = tr69configTbl["serialPassword"]
				tr69configTbl["Username"] = tr69configTbl["serialUsername"]
				os.execute ("/bin/touch /flash/configMerge/useTr69UseUniqueCredentials")
		end
		if (tr69configTbl["STUNMaximumKeepAlivePeriod"] ~= nil and tr69configTbl["STUNMinimumKeepAlivePeriod"] ~= nil) then
			if(util.fileExists("/flash/configMerge/stunValuesChange") == false) then
				tr69configTbl["STUNMaximumKeepAlivePeriod"] = "45" 
				tr69configTbl["STUNMinimumKeepAlivePeriod"] = "30" 
				local tmpvar = io.open("/flash/configMerge/stunValuesChange", "w")
				if(tmpvar ~= nil) then
                    tmpvar:close()
				end

			end
		end


	    tr69configTbl["CRSURLList"] = tr69configTbl["CRSURLList"]
		tr69configTbl = util.addPrefix(tr69configTbl, "tr69Config.")
		tr69Mgmt.dbEdit ("tr69Config", tr69configTbl, "-1", "add")
	end

    -- import ACSAlarmsFaults
    if (tr69Cfg["acsAlarmsFaults"] ~= nil) then
        acsCfg = config.update (tr69Cfg.acsAlarmsFaults, defTr69Cfg.acsAlarmsFaults, removeCfg.acsAlarmsFaults)
        acsAlarmFaultTbl = acsCfg[1]
    end

    if(acsAlarmFaultTbl ~= nil) then
        acsAlarmFaultTbl = util.addPrefix(acsAlarmFaultTbl, "ACSAlarmsFaults.")

        if(util.fileExists("/flash/configMerge/allFaultsEnable") == false) then
            acsAlarmFaultTbl["ACSAlarmsFaults.Faults"] = 1
            configMergeDone2 = "1"
        end 
        tr69Mgmt.dbEdit ("ACSAlarmsFaults", acsAlarmFaultTbl, "-1", "add")

        if (configMergeDone2 == "1") then
            local tmpvar = io.open("/flash/configMerge/allFaultsEnable", "w")
            if(tmpvar ~= nil) then
                tmpvar:close()
            end
        end
    end

    -- import ACSAlarms
    if (tr69Cfg["acsAlarms"] ~= nil) then
        acsAlarmsCfg = config.update (tr69Cfg.acsAlarms, defTr69Cfg.acsAlarms, removeCfg.acsAlarms)
        if (acsAlarmsCfg ~= nil and #acsAlarmsCfg ~= 0) then
            for i,v in ipairs (acsAlarmsCfg) do
                v = util.addPrefix (v, "ACSAlarms.");
                if(util.fileExists("/flash/configMerge/internetRetry") == false) then
                    v["ACSAlarms.LowerLimit"] = 3
                    configMergeDone = "1"
                end 
                if(util.fileExists("/pfrm2.0/HW_NO_WIFI")) then
                    if(v["ACSAlarms.AlarmFile"] == "WifiAlarmOn") then
                        v["ACSAlarms.Enable"] = "0"
                        v["ACSAlarms.AlarmEnable"] = "0"
                    end
                end
                if(v["ACSAlarms.AlarmFile"] == "CpuUsageAlarmOn" and util.fileExists("/flash/configMerge/cpuLimitCheck") == false) then
                    v["ACSAlarms.LowerLimit"] = "75"
                    v["ACSAlarms.LowerLimitFile"] = "cpuLimit"
                    local tmpvar = io.open("/flash/configMerge/cpuLimitCheck", "w")
                    if(tmpvar ~= nil) then
                        tmpvar:close()
                    end
                end
                tr69Mgmt.dbEdit ("ACSAlarms", v, "-1", "add")
            end
            if (configMergeDone == "1") then
                local tmpvar = io.open("/flash/configMerge/internetRetry", "w")
                if(tmpvar ~= nil) then
                    tmpvar:close()
                end
            end
        end
    end

    -- import ACSFaults
    if (tr69Cfg["acsFaults"] ~= nil) then
        acsFaultsCfg = config.update (tr69Cfg.acsFaults, defTr69Cfg.acsFaults, removeCfg.acsFaults)
        if (acsFaultsCfg ~= nil and #acsFaultsCfg ~= 0) then
            for i,v in ipairs (acsFaultsCfg) do
                v = util.addPrefix (v, "ACSFaults.");
                if(util.fileExists("/flash/configMerge/faultEnable") == false) then
                    if(v["ACSFaults.FaultEnable"] == "1") then
                        v["ACSFaults.Enable"] = 1
                        configMergeDone1 = "1"
                    end
                end
                if(util.fileExists("/pfrm2.0/ae_wan_type") and v["ACSFaults.FaultFile"] == "GponFaultOn") then
                        v["ACSFaults.Enable"] = 0
                        v["ACSFaults.FaultEnable"] = 0
                end
                tr69Mgmt.dbEdit ("ACSFaults", v, "-1", "add")
            end
            if (configMergeDone1 == "1") then
                local tmpvar = io.open("/flash/configMerge/faultEnable", "w")
                if(tmpvar ~= nil) then
                    tmpvar:close()
                end
            end
        end
    end

    return
end

--[[
*****************************************************************************
- tr69Mgmt.export - export configuration
-
- This function exports the configuration from the database.
-
- RETURN: 
-]]--

function tr69Mgmt.export ()
	local tr69Conf = {}
    local table = {}
    table["ACSAlarmsFaults"] = {}
    table["ACSAlarms"] = {}
    table["ACSFaults"] = {}

    tr69Conf.ManagementServer = db.getTable ("tr69Config", false)
    local status

    for i, v in ipairs (tr69Conf.ManagementServer) do
        if ( v["Password"] ~= "" and v["Password"] ~= nil) then
            status, tr69Conf.ManagementServer[i].Password = 
                    passwdSecureLib.encryptData (v["Password"], "")
        end
        if ( v["STUNPassword"] ~= "" and v["STUNPassword"] ~= nil) then
            status, tr69Conf.ManagementServer[i].STUNPassword = 
                    passwdSecureLib.encryptData (v["STUNPassword"], "")
        end
        if ( v["ConnectionRequestPassword"] ~= "" and 
            v["ConnectionRequestPassword"] ~= nil) then
            status, tr69Conf.ManagementServer[i].ConnectionRequestPassword = 
                passwdSecureLib.encryptData (v["ConnectionRequestPassword"], "")
        end
    end

    -- export ACSAlarmsFaults
    tr69Conf.acsAlarmsFaults = db.getTable ("ACSAlarmsFaults", false)

    -- export ACSAlarms
    table["ACSAlarms"] = db.getTable ("ACSAlarms", false)
    if(table["ACSAlarms"] ~= nil) then
        tr69Conf.acsAlarms = table["ACSAlarms"]
    end

    -- export ACSFaults
    table["ACSFaults"] = db.getTable ("ACSFaults", false)
    if(table["ACSFaults"] ~= nil) then
        tr69Conf.acsFaults = table["ACSFaults"]
    end

	return tr69Conf
end

if (config.register) then
   config.register("tr69", tr69Mgmt.import, tr69Mgmt.export, "1")
end


        
