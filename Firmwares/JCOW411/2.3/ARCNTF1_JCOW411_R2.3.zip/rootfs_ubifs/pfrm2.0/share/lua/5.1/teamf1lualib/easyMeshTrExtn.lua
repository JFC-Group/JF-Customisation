--[[ 
---
-- Copyright (c) 2008-2020, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: easyMeshTrExtn.lua
-- Description: TR 181 Handles For EasyMesh,Included from tr69fucs.lua.
-- 
-- modification history
-- --------------------
-- 01a, 24apr2020 vin written.
--
--]]

easyMeshMgmtTr = {}

require "teamf1lualib/easyMeshMgmt"
------------------------------------------------------------------------------
-- @name : easyMeshMgmtTr.easyMeshGet()
--
-- @description : Reads the status of EasyMesh
--
-- @return : Entire easyMesh Status
-- 
function easyMeshMgmtTr.easyMeshGet (input)
   
    local status = "0"
    local value = "0"
    local row = {}
    local query = nil
	
    --get corresponding db entry from 'easyMesh'
    query = "_ROWID_=1"
    
    row = db.getRowWhere ("easyMesh", query, false)
    
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    
    if(string.find(input["param"], "meshEnable")) then
        value = row["meshEnable"]
    else
        return "1", "DB_ERROR_TRY_AGAIN"                                                                
    end

    return status, value

end

------------------------------------------------------------------------------
-- @name : easyMeshMgmtTr.easyMeshSet()
--
-- @description : setting the status of EasyMesh
--
-- @return : Entire easyMesh Status
-- 
function easyMeshMgmtTr.easyMeshSet (input, rowids, actionType, tr69Param)

    local status = OK
    local row = {}
    local query = nil
    local easyMeshTbl = {}
    local faultTbl = {}
    local index = 0
    local retStatus = OK
    local errorcode = OK
    local rebootFlag = 0

    --get corresponding db entry from 'easyMesh'
    query = "_ROWID_=1"
    easyMeshTbl = db.getRowWhere ("easyMesh", query,true)
    if(easyMeshTbl == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    if(easyMeshTbl["easyMesh.wifiOn"] == "0") then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    if(input["easyMesh"]["easyMesh.meshEnable"] ~= nil) then
        row["meshEnable"] = input["easyMesh"]["easyMesh.meshEnable"]   
        retStatus, errorcode = easyMeshMgmt.easyMeshSet(row)
         if(retStatus == "ERROR") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl
        else
            db.save2() 
            rebootFlag = 1
        end
    end

    -- reboot if Mesh  is changed
    if(rebootFlag == 1) then
        require "teamf1lualib/tr69Glue"
        require "teamf1lualib/reboot"
        tr69Glue.reboot(30)
    end

    return status, faultTbl

end
------------------------------------------------------------------------------
-- @name : easyMeshMgmtTr.easyMeshWifiGet()
--
-- @description : Reads the status of EasyMesh
--
-- @return : Entire easyMesh Status
-- 
function easyMeshMgmtTr.easyMeshWifiGet (input)
   
    local status = "0"
    local value = "0"
    local row = {}
    local query = nil
	
    --get corresponding db entry from 'easyMesh'
    query = "_ROWID_=1"
    
    row = db.getRowWhere ("easyMesh", query, false)
    
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    
    if(string.find(input["param"], "wifiOn")) then
        value = row["wifiOn"]
    else
        return "1", "DB_ERROR_TRY_AGAIN"                                                                
    end

    return status, value

end

------------------------------------------------------------------------------
-- @name : easyMeshMgmtTr.easyMeshSet()
--
-- @description : setting the status of EasyMesh
--
-- @return : Entire easyMesh Status
-- 
function easyMeshMgmtTr.easyMeshWifiSet (input, rowids, actionType, tr69Param)

    local status = OK
    local row = {}
    local query = nil
    local easyMeshTbl = {}
    local faultTbl = {}
    local index = 0
    local retStatus = OK
    local errorcode = OK
    local rebootFlag = 0
 
    --get corresponding db entry from 'easyMesh'
    query = "_ROWID_=1"
    easyMeshTbl = db.getRowWhere ("easyMesh", query,true)
    if(easyMeshTbl == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    if(input["easyMesh"]["easyMesh.wifiOn"] ~= nil) then
        row["wifiOn"] = input["easyMesh"]["easyMesh.wifiOn"]   
        retStatus, errorcode = easyMeshMgmt.easyMeshWifiSet(row)
         if(retStatus == "ERROR") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl
        else
            db.save2() 
        end
    end

    return status, faultTbl

end
------------------------------------------------------------------------------
-- @name : easyMeshMgmtTr.easyMeshBhInfoGet()
--
-- @description : Get EasyMesh BH Information
-- 
function easyMeshMgmtTr.easyMeshBhInfoGet (input)

    local status = "0"
    local value = "0"
    local row = {}
    local query = nil
    
    -- To Update BHInfo DB table
    os.execute("/pfrm2.0/bin/lua /pfrm2.0/bin/bhAgentInfo.lua")

    --get corresponding db entry from 'easyMeshBhInfo'
    query = "_ROWID_=1"
    
    row = db.getRowWhere ("easyMeshBhInfo", query, false)
    
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    row = util.removePrefix(row,"easyMeshBhInfo.")

    if(string.find(input["param"], "CAPMode")) then
        if (row["deviceRole"] == "1") then
           value = row["deviceRole"] 
        else
            value = 0
        end
    elseif (string.find(input["param"], "ParentAPMAC"))then
        if (row["deviceRole"] == "1") then
            value = "00:00:00:00:00:00"
        else
            value = row["parenrtApMacAddr"]
        end
    elseif (string.find(input["param"], "Uplink"))then
        if (row["uplinkType"] ~=nil) then
            value = row["uplinkType"]
        end
    elseif (string.find(input["param"], "RSSI")) then
        if(row["uplinkType"] == "Ethernet")then
            value = "NA"
        else
            value = row["rssi"]
        end
    else
        return "1", "DB_ERROR_TRY_AGAIN"                                                                
    end

    return status, value

end

------------------------------------------------------------------------------
-- @name : easyMeshMgmtTr.easyMeshBhInfoSetMode()
--
-- @description : Set EasyMesh BH Information and Mode
-- 
--
function easyMeshMgmtTr.easyMeshBhInfoSet (input, rowids, actionType, tr69Param)
   
    tr69Glue.tf1Dbg("Entering easyMeshBhInfoSet..")
    local status = OK
    local row = {}
    local query = nil
    local easyMeshBhTbl = {}
    local faultTbl = {}
    local index = 0
    local retStatus = OK
    local errorcode = OK
    local rebootFlag = 0

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR) 
        return status, faultTbl;
    end
    
    --get corresponding db entry from 'easyMeshBhInfo'
    query = "_ROWID_=1"
    easyMeshBhTbl = db.getRowWhere ("easyMeshBhInfo", query,false)
    if(easyMeshBhTbl == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end
   
    if(input["easyMeshBhInfo"]["easyMeshBhInfo.deviceRole"] ~=nil) then

        if(tonumber(input["easyMeshBhInfo"]["easyMeshBhInfo.deviceRole"]) == tonumber(0) and tonumber(easyMeshBhTbl["deviceRole"]) == tonumber(2) ) then
            return status, faultTbl
        else
            if(tonumber(easyMeshBhTbl["deviceRole"]) == tonumber(input["easyMeshBhInfo"]["easyMeshBhInfo.deviceRole"])) then
                return status, faultTbl
            end
        end

    
        if(tonumber(input["easyMeshBhInfo"]["easyMeshBhInfo.deviceRole"]) == tonumber(1)) then
            easyMeshBhTbl["deviceRole"] = input["easyMeshBhInfo"]["easyMeshBhInfo.deviceRole"]
            easyMeshBhTbl["deviceName"] = "Controller"
        else
            easyMeshBhTbl["deviceRole"] = "2"  
            easyMeshBhTbl["deviceName"] = "Agent"
        end
        easyMeshBhTbl["parenrtApMacAddr"] = "00:00:00:00:00:00"
        easyMeshBhTbl["ConnectionState"] = "0"
        easyMeshBhTbl["uplinkType"] = "NA"
        easyMeshBhTbl["rssi"] = "NA"
        retStatus, errorcode = easyMeshMgmt.easyMeshBhInfoSet(easyMeshBhTbl)
        if(retStatus == "ERROR") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl
        else
            db.save2()
            rebootFlag = 1
        end
    end

    -- reboot if Device Mode  is changed
    if(rebootFlag == 1) then
        require "teamf1lualib/tr69Glue"
        require "teamf1lualib/reboot"
        tr69Glue.reboot(30)
    end

    return status, faultTbl

end    
