-- @copyright Copyright (c) 2018, TeamF1, Inc. 

--[[ modification history:
--01a,09may18,ask written.
--
--
--
--]]--


require "teamf1lualib/evtDsptch"
require "appExtn/AppExtn"
require "ndppdLib"

NdppdExtn = OoUtil.inheritsFrom(AppExtn)
NdppdExtn.name    = "Ndppd"
NdppdExtn.classId = "ndppd"
NdppdExtn.className  =  "NdppdExtn"
NdppdExtn.dbTable = "ndppd"
NdppdExtn.logger  = nil

local SUPER = require("appExtn.AppExtn")

-- network events
local netEvents = {}
netEvents[evtDsptch.event.IFDEV_EVENT_IP6_NET_UP]   =  1
netEvents[evtDsptch.event.IFDEV_EVENT_IP6_NET_DOWN] =  1

-- configuration events
local cfgEvents = {}
cfgEvents[db.event.SQLITE_INSERT] = 1
cfgEvents[db.event.SQLITE_UPDATE] = 1
cfgEvents[db.event.SQLITE_DELETE] = 1

-------------------------------------------------------------------------------
-- @name NdppdExtn.cfgEventCallback
--
-- @description 
--
-- @param  
--
-- @return  
--

function NdppdExtn.cfgEventCallback(obj, info)
    local status = "ERROR"
    local errcode = ""

    LOG:ddebug(NdppdExtn.classId .. " configuration callback called  " .. 
               "for event: " ..  info.event .. " on rowId " .. info.rowId)

    if (info.event == db.event.SQLITE_INSERT) then
        if (obj ~= nil) then 
            assert(nil, NdppdExtn.classId .. "(" .. info.rowId  .. ")" ..
                   "already created")
            return -1
        end        

        -- create instance and process event
        obj = NdppdExtn:new(info.rowId)
        if (obj) then 
            obj:onCfgEvent(info) 
        end

    elseif (info.event == db.event.SQLITE_UPDATE) then
        -- re-load and process event
        if (obj) then 
            status, errCode, obj = obj:load()
            if (status == "OK") then
                obj:onCfgEvent(info) 
            end            
        end
    elseif (info.event == db.event.SQLITE_DELETE) then
        -- process event and destroy instance
        if (obj) then
            obj:onCfgEvent(info)
            obj:delete()
        end
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name NdppdExtn.bootstrap
--
-- @description This function is called by appd on startup to bootstrap all 
-- instances of this application. 
--
-- @param  
--
-- @return  
--

function NdppdExtn.bootstrap()
    local instanceId
    local callbackTable= {}

    ndppdLib.killAll()

    local callback = {}
    callback.type = appd.eventType.APPD_EV_CFG
    callback.dbTable = NdppdExtn.dbTable
    callback.routine = NdppdExtn.cfgEventCallback
    table.insert(callbackTable, callback)
    appd.callbackRegister (NdppdExtn.classId, callbackTable)

    local cfg = db.getTable(NdppdExtn.dbTable, false)
    if (cfg == nil) then
        return 0
    end        

    for index, record in pairs(cfg) do
        instanceId = record["_ROWID_"]
        local obj = NdppdExtn:new(instanceId)
        if (obj and obj:isEnabled()) then
            obj:start()
        end                        
    end

    return 0
end

-------------------------------------------------------------------------------
-- @name NdppdExtn:new
--
-- @description This function creates a new instance object for ndppd, loads
-- the configuration and event subcriptions
--
-- @return  0 for success and -1 for error
--

function NdppdExtn:new(instanceId, props)

    -- create a new instance
    self = NdppdExtn.create()

    SUPER.new(self, NdppdExtn.classId, instanceId, props)

    self.name  = NdppdExtn.name
    self.dbTable =  NdppdExtn.dbTable

    -- initialize events for this instance
    self.netEvents = netEvents              
    self.cfgEvents = cfgEvents

    local handle = db.gethandle(self.dbconn)
    ndppdLib.init(handle)

    -- load the instance          
    local status, errCode, self = self:load()
    if (status == nil) then
        LOG:error("failed to load " .. classId .. 
                  "(" .. instanceId .. ")")
        return nil
    end        

    -- register with appd
    appd.appExtnRegister(self)                    

    return self
end

-------------------------------------------------------------------------------
-- @name NdppdExtn:delete
--
-- @description This function deletes an instance of this extension
--
-- @param instanceId
--
-- @return  
--

function NdppdExtn:delete()
    appd.appExtnUnregister(self)
end

-------------------------------------------------------------------------------
-- @name NdppdExtn:stop
--
-- @description This function starts ndppd
--
-- @return  0 for success and -1 for error
--

function NdppdExtn:stop ()


    ndppdLib.stop()

    return 0
end

-------------------------------------------------------------------------------
-- @name NdppdExtn:isEnabled
--
-- @description This function checks if this instance is enabled
--
-- @return  true if enabled else false
--

function NdppdExtn:isEnabled()
    local props = self:getProps()

    if (tonumber(props.ndppdStatus) > 0) then
        return true
    end        

    return false
end

-------------------------------------------------------------------------------
-- @name NdppdExtn:start
--
-- @description This function starts ndppd
--
-- @return  0 for success and -1 for error
--

function NdppdExtn:start ()
    require "teamf1lualib/nimf"
    local props = self:getProps()

    if (self:isEnabled()) then

        -- check if the network is UP
        if (nimfConn.isIPv6Up(props.LogicalIfName) == false) then
            LOG:debug(self.name .. " network(" .. props.LogicalIfName  .. ") is not UP")
            return -1
        end        

        LOG:info("Starting " .. self.name ..  "(" ..  self.instanceId .. ")")

        if (ndppdLib.restart() < 0) then
            return -1
        end            
    end
end

-------------------------------------------------------------------------------
-- @name NdppdExtn:restart
--
-- @description This function restarts ndppd
--
-- @return  0 for success and -1 for error
--

function NdppdExtn:restart ()

    -- stop ndppd if it's running previously
    self.stop()

    -- restart the server
    if (self:start() < 0) then
        return -1
    end

    return 0
end

-------------------------------------------------------------------------------
-- @name NdppdExtn:getAppName
--
-- @description This function gets the name of this extension
--
-- @return  
--

function NdppdExtn:getAppName()
   return self.name
end

-------------------------------------------------------------------------------
-- @name NdppdExtn:getDbTableName
--
-- @description This function gets the database table name which contains
-- configuration records for all instances of this application.
--
-- @return  
--

function NdppdExtn:getDbTableName()
   return self.dbTable
end

-------------------------------------------------------------------------------
-- @name NdppdExtn:onNetEvent
--
-- @description This function handles network events
--
-- @param  netevent  network event
--
-- @return  0 for success and -1 for error
--

function NdppdExtn:onNetEvent(netevent)

    if (self:isEventSubscribed(netevent) == false) then
        LOG:ddebug(self.name .. " not subscribed to event: " ..
                   netevent.event .. " on " .. netevent.ifname)
        return 0
    end        

    self:restart()

    return 0
end

-------------------------------------------------------------------------------
-- @name NdppdExtn:isEventSubscribed
--
-- @description This function checks if this instance is subcribed to
-- the event pass as input
--
-- @param event event information
--
-- @return  0 for success and -1 for error
--

function NdppdExtn:isEventSubscribed(event)
    require "teamf1lualib/network"
    local props = self:getProps()

    if (event.type == appd.eventType.APPD_EV_NET) then

        local evstate = self.netEvents[event.event]
        if (evstate == nil) then
            return false
        end            
                    
        if (evstate > 0) then
            return true
        end        

    elseif (event.type == appd.eventType.APPD_EV_CFG) then

        -- are we subscribed to this event                        
        local evstate = self.cfgEvents[event.event]
        if (evstate == nil) then
            return false
        end            

        if (evstate > 0) then
            return true
        end        
    end

    return false
end

-------------------------------------------------------------------------------
-- @name NdppdExtn:onCfgEvent
--
-- @description This function is to handle configuration events
-- 
-- @param  cfgevent event information
--
-- @return  
--

function NdppdExtn:onCfgEvent(cfgevent)
    local props = self:getProps()

    if (self:isEventSubscribed(cfgevent) == false) then
        LOG:ddebug(self.name .. " not subscribed to event: " ..
                   cfgevent.event .. " on " .. cfgevent.dbTable)
        return
    end        

    return
end

-------------------------------------------------------------------------------
-- @name NdppdExtn:print
--
-- @description This function prints the properties of this application instance
--
-- @param  
--
-- @return  
--

function NdppdExtn:print()
    require "util/strlib"

    LOG:info("Class     : " .. self.classId)
    LOG:info("Instance  : " .. self.instanceId)
    LOG:info("App Name  : " .. self:getAppName())
    LOG:info("Conf      : " .. strlib.serializeTbl(self:getProps()))
    return
end

return NdppdExtn
