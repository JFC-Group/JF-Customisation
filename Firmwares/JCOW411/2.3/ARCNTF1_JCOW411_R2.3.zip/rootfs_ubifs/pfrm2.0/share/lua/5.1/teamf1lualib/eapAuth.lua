--[[
#### Saurabh Garg
#### TeamF1
#### www.TeamF1.com
#### Apr 13, 2009

#### File: eapAuth.lua
#### Description: eapAuth functions

#### Revisions:

]]--

--package eapAuth
eapAuth = {}

-- C eapAuth library adds an _index function to eapAuth
require "teamf1lualib/config"
if (db == nil) then
    require "teamf1lualib/db"
end
require "eapAuthLib"

--table packages
eapAuthProfile = {}

-- locals


--************* Functions *************
function eapAuth.eapAuthProfile_config(inputTable, rowid, operation)
    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    local valid = false
    valid = eapAuthProfile.config (inputTable, rowid, operation)

    if (valid) then
        config.recOp (eapAuth.profile_config_apply ,inputTable, operation);
    end

    -- return
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "EAPAUTH_CONFIG_FAILED"
    end	 	
end

-- eapAuth Config
function eapAuthProfile.config (inputTable, rowid, operation)
    -- validate
    if (eapAuthProfile.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
       	    return db.insert("eapAuthProfile", inputTable)
        elseif (operation == "edit") then
       	    return db.update("eapAuthProfile", inputTable, rowid)
        elseif (operation == "delete") then
            return false
       	end
    end
    return false
end

-- eapAuth input validate
function eapAuthProfile.inputvalidate (inputTable, operation)
    return true;
end

function eapAuth.Authval2str(val) 
    if( val == "0") then
 	return "noauth"
    elseif( val == '1') then
	return "pap"
    elseif( val == '2') then
	return "chap"
    elseif( val == '3') then
	return "mschap"
    elseif( val == '4') then
	return "mschapv2"
    elseif( val == '5') then
	return "token"
    elseif( val == '6') then
	return "eap"
    else
	return nil
    end
end

--	*  EAP Method Name          | Value
--	*  -------------------------|------
--  	*  AUTH_TYPE_EAP_MD5        | 0x01
-- 	*  AUTH_TYPE_EAP_MSCHAPV2   | 0x02 
-- 	*  AUTH_TYPE_EAP_TLS        | 0x04
-- 	*  AUTH_TYPE_EAP_TTLS       | 0x08
-- 	*  AUTH_TYPE_EAP_PEAP       | 0x10

function eapAuth.EAPval2str(val)
    if ( val == "0") then
	return nil	
    elseif(val == "1") then
  	return "md5"
    elseif( val == "2") then
 	return "mschapv2"
    elseif( val == "4" ) then
	return "tls"
    elseif( val == "8" ) then
	return "ttls"
    elseif( val == "16" ) then
	return "peap"
    else
	return nil		
    end
end

--function eapAuth profile apply
function eapAuth.profile_config_apply (inputTable, operation)

    local eapProfile = util.removePrefix (inputTable, "eapAuthProfile.")

    local profileName = eapProfile["profileName"]

    if (operation == "delete") then
        eapAuth.ProfileDelete (profileName)
        return true
    elseif (operation == "add") then
        eapAuth.ProfileCreate (profileName)
    end

    if (eapProfile["userName"] ~= nil) then
        eapAuth.ProfileUserSet (profileName, eapProfile["userName"], eapProfile["password"]);
    end
    -- Registers all the authentication schemes
    -- This is needed before calling eapProfileAuthSet to succeed
    eapAuth.AuthRegInit()

    local outerEAP = eapAuth.EAPval2str(eapProfile["outerEAP"])
    local innerEapAuth = "0"
    local innerAuth = eapProfile["innerAuth"]
--      InnerAuth   :   AUTH_TYPE_PAP            |   1
--                      AUTH_TYPE_CHAP           |   2 
-- 		        AUTH_TYPE_MSCHAP         |   3  
-- 			AUTH_TYPE_MSCHAPV2       |   4 
--			AUTH_TYPE_EAP_MD5        |   6 
-- 			AUTH_TYPE_EAP_MSCHAPv2   |   7  

    if(eapProfile["innerAuth"] == nil) then
        innerAuth =0
    elseif(eapProfile["innerAuth"] == '6') then
	innerAuth = '6'    -- EAP
        innerEapAuth = "1"     -- EAP_MD5
    elseif (eapProfile["innerAuth"]  == '7') then
	innerAuth = '6'    -- EAP
        innerEapAuth = "2"    -- EAP-MSCHAPv2
    end
    innerAuth = eapAuth.Authval2str(innerAuth)
    innerEapAuth = eapAuth.EAPval2str(innerEapAuth)

    if (outerEAP == nil or innerAuth == nil) then
	return false   -- Error!! the arguments are not correct
    end

	
    if (eapProfile["profileName"] ~= nil) then
 	if ( innerEapAuth ~= nil ) then
             eapAuth.ProfileAuthSet (profileName, outerEAP, eapProfile["anonymousID"],innerAuth,innerEapAuth);
	else
             eapAuth.ProfileAuthSet (profileName, outerEAP, eapProfile["anonymousID"],innerAuth);
	end
    end

    -- Sets the server Name here. Certs are set in x509.lua
    if(eapProfile["serverName"] ~= nil) then
	eapAuth.ProfileCertSet (profileName, nil, nil, nil, nil , eapProfile["serverName"])
    end
  
end

function vartofile(var, filename)
    file = assert( io.open (filename ,"w"))
   file:write (var)
   assert(file:close ())
end

function eapAuthProfile.import (configTable, defaultConfigTable, removeConfigTable)

   if (configTable == nil) then
        configTable = defaultConfigTable
   end	

   local eapAuthTbl = {}
   eapAuthTbl = config.update (configTable, defaultConfigTable, removeConfigTable)
   if (eapAuthTbl ~= nil and #eapAuthTbl ~= 0) then
       for i,v in ipairs (eapAuthTbl) do
           v = util.addPrefix (v, "eapAuthProfile.")
           eapAuth.eapAuthProfile_config (v, "-1", "add");
           
           -- Setting self certs
           k = db.getRowWhere("cert","certType='self'",false)
           if( k~= nil) then
               cert = "/var/certs/self/self" ..  k["_ROWID_"] .. ".crt"
               eapAuth.ProfileCertSet (v["eapAuthProfile.profileName"], cert, nil, nil, nil , v["eapAuthProfile.serverName"])
               vartofile(k["certData"], cert);
           end
           -- Setting CA certs
           k = db.getRowWhere("cert","certType='ca'",false)
           if( k~= nil) then
               cert = "/var/certs/ca/CA" ..  k["_ROWID_"] .. ".crt"
               eapAuth.ProfileCertSet (v["eapAuthProfile.profileName"], nil, cert, nil, nil , v["eapAuthProfile.serverName"])
               vartofile(k["certData"], cert);
           end
       end
   end

end

function eapAuthProfile.export ()
    local eapAuthProfile = db.getTable ("eapAuthProfile", false)
    return eapAuthProfile
end

if (config.register) then
   config.register("eapAuthProfile", eapAuthProfile.import, eapAuthProfile.export, "1")
end

