-- network.lua - lua wrapper calls for network tab

-- Copywrite (c) 2013 TeamF1, Inc.
-- Copyright (c) 2017, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
--
--
-- modification history
-- --------------------
-- 01d, 23Nov17, swr changes for spr 62635(XSS vulnerability) and 61441
-- 01c, 08Jun17, sjr added packet capture check for LAN/WAN
-- 01b, Aug2213, sen added checks for dependencies between LAN/WAN side vlans
--               and bridgeMode
-- 01a, 12Mar13, sen dervied from reference solution. for RIL.
--
---------------------------------------------------------------------------------
-- The routines in this lua wrapper are called by htm(user interface) layer to
-- get the information to display in user interface or to configure network
-- properties for which the respective routines will satisfy the purpose of
-- creating/modifying/destroying a network such as (re)start/stop network
-- bound application.
---------------------------------------------------------------------------------
gui.networking= {}


-- Dynamic DNS set-up
gui.networking.ddns = {}
gui.networking.ddns.get = {}
gui.networking.ddns.set = {}
--[[ Network tests ]]--
gui.networking.diagnostics = {}
--Ping or Trace an IP Address
gui.networking.diagnostics.ping = {}
gui.networking.diagnostics.traceroute = {}
--DNS lookup
gui.networking.diagnostics.dnslookup = {}
gui.networking.packetTrace = {}
gui.networking.bridgeMode = {}
gui.networking.bridgeModeAE = {}
gui.networking.gpon = {}
gui.networking.voip = {}

require "teamf1lualib/netconf"
require "teamf1lualib/routing"
require "teamf1lualib/wifiSecMap"
require "teamf1lualib/wireless"
--require "teamf1lualib/wizard"

    
function gui.networking.voip.get ()

require "teamf1lualib/voip"
    
     local voipRow = {}
     local errMsg = ""
     local statusMsg = ""
     -- require
     voipRow = voipCfg.get ()
     if (voipRow == nil) then
             return  "ERROR", "DB_ERROR_TRY_AGAIN", nil
     end
     return errMsg, statusMsg, voipRow
end
                                                                                                    
function gui.networking.voip.set (inputTable)

require "teamf1lualib/voip"
    local errMsg = ""
    local statusMsg = ""
                                                                                                                    
    local valid  = true
    
    valid = voipCfg.configure (inputTable, "1", "edit")
    
    if (valid) then
        errMsg = "OK"
        statusMsg = "STATUS_OK"
    else
        errMsg = "ERROR"
        statusMsg = "WAN_PORT_MODE_CONFIG_FAILED"
    end             
    
    return errMsg, statusMsg
        
end
       
--util.setDebugStatus(true)
-------------------------------------------------------------------------------
-- @name gui.networking.ddns.get
--
-- @description This function will get the status of ddns in device.
--
--
-- @return
--
function gui.networking.ddns.get ()

    -- require
    require "teamf1lualib/ddns"

    -- locals
    local ddnsTbl = {}
    local errMsg = nil
    local statusMsg = nil

    -- Logic
    ddnsTbl = ddns.ddnsGet()
 if (ddnsTbl == nil) then
  return "ERROR", "DB_ERROR_TRY_AGAIN"
 end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

    -- return
    return errMsg, statusMsg, ddnsTbl
end

-------------------------------------------------------------------------------
-- @name gui.networking.ddns.set
--
-- @description This function will configure ddns service in device.
--
-- @return
--
function gui.networking.ddns.set (ddnsCfg)

    -- require
 require "teamf1lualib/ddns"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- locals
    local status, err

    -- Logic
    status, err = ddns.ddnsSet(ddnsCfg)

    -- return
    return status, err
end
-------------------------------------------------------------------------------
-- @name gui.networking.diagnostics.networksGet
--
-- @description This function will get the currently available networks in the
-- system.
--
-- @param
--
-- @return
--
function gui.networking.diagnostics.networksGet()

    -- require
    require "teamf1lualib/platform"

    -- locals
    local netTbl = {}
    local errMsg = nil
    local statusMsg = nil
    local page = {} --local table containing the available networks Info
    page.networks = {}

    netTbl = platform.availableNetworkGet()
    if (netTbl == nil) then
        return "ERROR", "AVAILABLE_NETWORKS_GET_FAILED"
    end

    for i,v in ipairs (netTbl)
    do
        page.networks[i] = {}
        page.networks[i].networkname = v["networkName"]
    end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

    --return
 return errMsg, statusMsg, page
end

-------------------------------------------------------------------------------
-- @name gui.networking.diagnostics.ping.set
--
-- @description This function will execute ping for given ip address or FQDN.
--
-- @param lua table containing ip/fqdn to which ping has to be tested.
--
-- @return
--
function gui.networking.diagnostics.ping.set (pingCfg)

    -- require
    require "teamf1lualib/platform"

    -- Sanity for privilages
    --if (ACCESS_LEVEL ~= 0) then
      -- return "ACCESS_DENIED", "ADMIN_REQD"
    --end

    -- locals
    local status, err

    -- execute ping command for given ip/fqdn
    status, err = platform.pingTest (pingCfg);

 --return
 return status, err
end


-------------------------------------------------------------------------------
-- @name gui.networking.diagnostics.ping.get
--
-- @description This function will get the ping output stored in a file.
--
-- @param lua table containing ping
--
-- @return
--
function gui.networking.diagnostics.ping.get()

    -- require
 require "teamf1lualib/platform"

 -- locals
 local pingTbl = {} -- local table containing ping output
 local localTbl = {}
    local errMsg = nil
    local statusMsg = nil

    local arg="ping"
 -- we only write the ping Result into a file
 pingTbl = platform.diagnosticResultGet(arg)

    if(pingTbl == nil) then
        return localTbl
    end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

    return errMsg, statusMsg, pingTbl
end




-------------------------------------------------------------------------------
-- @name gui.networking.diagnostics.traceroute.set
--
-- @description This function will execute traceroute for given ip address or
-- FQDN and print the route packets trace to network host.
--
-- @param lua table containing ip/fqdn to which traceroute has to be tested.
--
-- @return
--
function gui.networking.diagnostics.traceroute.set (traceCfg)

    -- require
    require "teamf1lualib/platform"

    -- Sanity for privilages
    --if (ACCESS_LEVEL ~= 0) then
      -- return "ACCESS_DENIED", "ADMIN_REQD"
    --end

    -- locals
    local status, err

    -- execute ping command for given ip/fqdn
    status, err = platform.traceroute (traceCfg);

 --return
 return status, err
end

-------------------------------------------------------------------------------
-- @name gui.networking.diagnostics.traceroute.get
--
-- @description This function will get traceroute result from the stored file.
--
-- @param
--
-- @return
--
function gui.networking.diagnostics.traceroute.get()

    -- require
 require "teamf1lualib/platform"

 -- locals
 local traceTbl = {} -- local table containing traceroute output
    local localTbl = {}
    local errMsg = nil
    local statusMsg = nil

    local arg="traceroute"
 -- we only write the ping Result into a file
 traceTbl = platform.diagnosticResultGet(arg)

    if(traceTbl == nil) then
        return localTbl
    end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

    return errMsg, statusMsg, traceTbl

end

-------------------------------------------------------------------------------
-- @name gui.networking.diagnostics.dnslookup.set
--
-- @description This function will execute nslookup for given ip address or
-- FQDN and query Internet name servers interactively.
--
-- @param lua table containing ip/fqdn to which dnslookup has to be tested.
--
-- @return
--
function gui.networking.diagnostics.dnslookup.set (lookupCfg)

    -- require
    require "teamf1lualib/platform"

    -- Sanity for privilages
    --if (ACCESS_LEVEL ~= 0) then
      -- return "ACCESS_DENIED", "ADMIN_REQD"
    --end

    -- locals
    local status, err

    -- TODO: execute nslookup command for the domain name entered
    status, err = platform.nslookup(lookupCfg)

 --return
 return status, err

end

function gui.networking.diagnostics.dnslookup.get()

    -- require
 require "teamf1lualib/platform"

 -- locals
 local lookTbl = {} -- local table containing traceroute output
    local localTbl = {}
    local errMsg = nil
    local statusMsg = nil

    local arg="nslookup"
 -- we only write the ping Result into a file
 lookTbl = platform.diagnosticResultGet(arg)

    if(lookTbl == nil) then
        return localTbl
    end

   errMsg = "OK"
   statusMsg = "STATUS_OK"

    return errMsg, statusMsg, lookTbl
end

function gui.networking.packetTrace.set(conf)

    -- require
    require "teamf1lualib/tcpdump"

   	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"    
	end 
   
    if (conf == nil) then
        return "ERROR", "PTRACE_INVALID_PARAM"        
    end

    if (conf["networkName"] == nil) then
        return "ERROR", "INVALID_NETWORK_NAME"        
    end

	-- For HG261GU , check if atleast 20 MB free memory in system to generate and download packet capture
	if (util.fileExists ("/pfrm2.0/HW_HG261GU")) then

	-- If already started when free memory was above 20 MB but now below 20 MB , if we dont have this check , then user can never stop the capture. 
	if (conf["tcpdumpEnabled"] == "1" ) then
	status, freeMem = util.freeMemGet ()
	 if (freeMem ~= nil and tonumber (freeMem) < 20480 ) then
        return "ERROR", "LOW_MEMORY"        
	end
	end
	end

    local query = "networkName='" .. conf["networkName"] .. "'"
    local row = db.getRowWhere("networkInterface", query, false)
    if (row == nil) then
        return "ERROR", "FAILED_TO_GET_NETWORK"
    end

    conf["interfaceName"] = row["interfaceName"]

--[[ Remove this check because RIL wants packet capture when WAN is down

    local status, errCode, networkInfo = gui.networking.network.statusGet(row["LogicalIfName"])
    if (status ~= "OK") then
        return status, errCode
    end

    if (networkInfo.ipv4 ~= "nil") then
        if (networkInfo.ipv4["ConnectionStatus"] ~= "CONNECTED") then
            return "ERROR", "NETWORK_DOWN"
        end
    end

--]]

    errMsg, statusMsg = tcpdump.configure(conf)

    return errMsg, statusMsg
end

function gui.networking.packetTrace.get()

    local lookTbl = {}
    local netwrkInterfaceTbl = {}
    local page = {}
    local i = 0
    local j = 0
    page.networks = {}

    local intName = nil
    -- require
    require "teamf1lualib/tcpdump"
    local tcpdumpTbl = tcpdump.get()
    if (tcpdumpTbl ~= nil) then
        for k,v in pairs(tcpdumpTbl) do
            i = i + 1
		    local row = tcpdumpTbl[i]
		    if (row["tcpdumpEnabled"] == "1") then
                intName = row["interfaceName"]
                break
		    end
	    end
    end
   
    if (intName ~= nil) then
        local query = "interfaceName='" .. intName .. "'"
        lookTbl = db.getRowWhere("networkInterface", query, false)
        if (lookTbl == nil) then
            return "ERROR", "FAILED_TO_GET_NETWORK", netwrkInterfaceTbl
        end
    end

    -- getting the networkInterface table
    netwrkInterfaceTbl = db.getTable("networkInterface", false)
    if (netwrkInterfaceTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN", netwrkInterfaceTbl 
    end
    
    -- getting the statistics of all the networks configured
    for k,v in pairs (netwrkInterfaceTbl) do
        j = j + 1
        if (v["LogicalIfName"] == "IF1" or v["LogicalIfName"] == "IF2") then
            page.networks[k] = {}
            page.networks[k].interfaceName = v["interfaceName"]
            page.networks[k].LogicalIfName = v["LogicalIfName"]
            page.networks[k].networkName = v["networkName"]
        end
    end

    errMsg = "OK"
    statusMsg = "STATUS_OK"

    return errMsg, statusMsg, lookTbl, page
end

function gui.networking.bridgeMode.get ()

	local bridgeRow = {}

    -- require
    require "teamf1lualib/bridgeLib"
	bridgeRow = bridgeMode.get ()
	
	if (bridgeRow == nil) then
		return  "ERROR", "DB_ERROR_TRY_AGAIN", nil
	end

    if (util.fileExists("/pfrm2.0/MULTI_VLAN_BRIDGE")) then
	    bridgeModeVlanRows = bridgeModeVlan.get()
    	if (bridgeModeVlanRows == nil) then
			return  "ERROR", "DB_ERROR_TRY_AGAIN", nil
    	end
    	bridgeRow.vlanRows = {}

    	bridgeRow.vlanRows = bridgeModeVlanRows
	end

    bridgeRow["bridgeMode.vlanID"] = util.filterXSSChars (bridgeRow["bridgeMode.vlanID"])
	return errMsg, statusMsg, bridgeRow

end

function gui.networking.bridgeModeAE.set (inputTable, dbFlag)

	local errMsg = ""
	local statusMsg = ""

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
      return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- Making dbFlag 1, to perform db transactions
    if (dbFlag == nil) then
        dbFlag = 1
    end

    -- require
    require "teamf1lualib/bridgeLib"

    if(dbFlag == 1) then
        db.beginTransaction() -- begin transcation
    end
    
    errMsg, statusMsg = bridgeMode.configure(inputTable, "1", "edit", dbFlag)

    if(statusMsg == "STATUS_OK") then
        errMsg = "OK"
        statusMsg = "STATUS_OK"
        if(dbFlag == 1) then
            db.commitTransaction()
        end
        db.save2()
    else
        if(dbFlag == 1) then
            db.rollback()
        end
    end		

	return errMsg, statusMsg

end

function gui.networking.bridgeMode.set (inputTable)

	local errMsg = ""
	local statusMsg = ""

	local valid  = true
    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
      return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- require
    require "teamf1lualib/bridgeLib"

    if (UNIT_INFO == "ODU") then
        errMsg, statusMsg = bridge.changeBridgeMode (inputTable["bridgeModeStatus"])
        
        if (errMsg == "OK") then
            db.save2()
        else
            errMsg = "ERROR"
            statusMsg = "BRIDGE_MODE_CONFIG_FAILED"
        end	
        
        return errMsg, statusMsg    
    end

	local bridgeRow = {}
	bridgeRow["bridgeMode.status"] = inputTable["bridgeModeStatus"]
	bridgeRow["bridgeMode.portNumber"] = inputTable["portNumber"]
	bridgeRow["bridgeMode.vlanID"] = inputTable["vlanId"]


	if (inputTable["bridgeModeStatus"] == "1") then
		-- do the sanity checks
		local wanVlanRows = db.getRows ("ethernetVLAN", "vlanId", inputTable["vlanId"])
		if (#wanVlanRows ~= 0) then
			return "ERROR", "SELECTED_VLAN_ID_PRESENT_ON_WAN"
		end

		local lanVlanRows = db.getRows ("vlanEncapIf", "vlanId", inputTable["vlanId"])
		if (#lanVlanRows ~= 0) then
			return "ERROR", "SELECTED_VLAN_ID_PRESENT_ON_LAN"
		end

		local gponRow = db.getRow ("gpon", "_ROWID_", "1")
		if ((gponRow["gpon.status"] == "1") and gponRow ~= nil and (gponRow["gpon.vlanStatus"] == "1") and (gponRow["gpon.vlanID"] == inputTable["vlanId"])) then
			return "ERROR", "SELECTED_VLAN_ID_PRESENT_ON_GPON"
		end
		

		lanVlanRows = db.getTable("vlanEncapIf")
		for k,v in pairs (lanVlanRows) do
			if (string.find (v["vlanEncapIf.fwdMap"], inputTable["portNumber"]) ~= nil ) then
				return "ERROR", "CONFIGURED_PORT_PRESENT_IN_FWD_MAP"
			end
		end
	else
		bridgeRow["bridgeMode.portNumber"] = "1"
		bridgeRow["bridgeMode.vlanID"] = "0"
	end

	if (inputTable["vlanId"] and ((tonumber(inputTable["vlanId"]) < 2) or (tonumber(inputTable["vlanId"]) > 4094))) then
		return "ERROR", "Enter VLAN ID between 2-4094"
	end
	

	db.beginTransaction() -- begin transcation

	valid = bridgeMode.config (bridgeRow, "1", "edit")
	
	if (valid) then
                local insertFlag = "1"
	        local status  = true
                local vlanRows = db.getTable("bridgeModeVlan", false)

                if(#vlanRows >= 1) then
                    for k,v in pairs (vlanRows) do
                        if(inputTable["vlanId"] == v["vlanID"]) then
                            insertFlag = "0"
                        end
                    end
                end

                if(insertFlag == "1" and inputTable["vlanId"] ~= nil) then
                    local input = {}
                    input["bridgeModeVlan.Enable"] = "1" 
    		    input["bridgeModeVlan.vlanID"] = inputTable["vlanId"] 
    		    input["bridgeModeVlan.Name"] = "VLAN" 
    		    status = bridgeModeVlan.config (input, nil, "add")
                end

                if(status) then
		    errMsg = "OK"
		    statusMsg = "STATUS_OK"
		    db.commitTransaction()
		    db.save2()
                else
                    errMsg = "ERROR"
		    statusMsg = "BRIDGE_MODE_CONFIG_FAILED"
		    db.rollback()
                end
	else
		errMsg = "ERROR"
		statusMsg = "BRIDGE_MODE_CONFIG_FAILED"
		db.rollback()
	end		
	
	return errMsg, statusMsg

end

function gui.networking.gpon.get ()

	local gponTable = {}

    -- require
    require "teamf1lualib/gpon"
	gponRow = gpon.get ()
	
	if (gponRow == nil) then
		return  "ERROR", "DB_ERROR_TRY_AGAIN", nil
	end

    gponRow["vlanID"] = util.filterXSSChars(gponRow["vlanID"])

	return errMsg, statusMsg, gponRow

end

function gui.networking.gpon.set (inputTable)

	local errMsg = ""
	local statusMsg = ""

	local valid  = true
    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
      return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- require
    require "teamf1lualib/gpon"
	local bridgeRow = db.getRow ("bridgeMode", "_ROWID_", "1")
	if ((bridgeRow["bridgeMode.status"] == "1") and ((bridgeRow["bridgeMode.vlanID"] == inputTable ["vlanID"]) or (bridgeRow["bridgeMode.vlanID"] == inputTable ["wifiVlanID"]))) then
		return "ERROR", "SELECTED_VLAN_ID_PRESENT_ON_BRIDGE"
	end

	if (inputTable ["vlanID"] ~= nil) then
		local ethernetVLANRows = db.getRows ("ethernetVLAN", "vlanId" , inputTable ["vlanID"])
		if (ethernetVLANRows ~= nil and #ethernetVLANRows > 0) then
			return "ERROR", "SELECTED_VLAN_ID_PRESENT_ON_WAN"
		end
	end

	if (inputTable["vlanID"] and (tonumber(inputTable["vlanID"]) < 1) and  (tonumber(inputTable["vlanID"]) > 4094)) then
		return "ERROR", "Enter VLAN ID between 1-4094"
	end

    if (inputTable["vlanID"] == inputTable["wifiVlanID"]) then
        if (util.fileExists("/pfrm2.0/ae_wan_type"))then
            return "ERROR", "Active Ethernet VLAN ID and WIFI VLAN ID cannot be same"
        else
            return "ERROR", "GPON VLAN ID and WIFI VLAN ID cannot be same"
        end
    end
            
    if (util.fileExists("/pfrm2.0/ae_wan_type") or util.fileExists("/pfrm2.0/HW_HG260ES") or util.fileExists("/pfrm2.0/HW_JCO110") or util.fileExists("/pfrm2.0/HW_FIBERHOME_JCO300") or util.fileExists("/pfrm2.0/HW_FOXCONN_JCO500") or util.fileExists("/pfrm2.0/HW_HG261GU") or util.fileExists("/pfrm2.0/HW_HG260X") or util.fileExists("/pfrm2.0/HW_JCOW401") or util.fileExists("/pfrm2.0/HW_JCOW403") or util.fileExists("/pfrm2.0/HW_JCOW404") or util.fileExists("/pfrm2.0/HW_JCOW411"))then
        local vlanRows = db.getTable("bridgeModeVlan", false)
        if (vlanRows == nil) then
            return  "ERROR", "DB_ERROR_TRY_AGAIN"
        end
        
        if (#vlanRows > 0) then
            for i,row in pairs(vlanRows) do
                if ((bridgeRow["bridgeMode.status"] == "1") and ((tonumber(row["vlanID"]) == tonumber(inputTable ["vlanID"])) or (tonumber(row["vlanID"]) == tonumber(inputTable ["wifiVlanID"])))) then
			        return "ERROR", "SELECTED_VLAN_ID_PRESENT_ON_BRIDGE"
                end
            end
        end
    end


	db.beginTransaction() -- begin transcation

	local tmpRow = {}
	if (inputTable ["wanPortType"] == "1" ) then
		tmpRow ["gpon.status"] = "0"
	else
		tmpRow ["gpon.status"] = "1"
	end
	tmpRow ["gpon.vlanStatus"] = inputTable ["enableDisableVLAN"]
	tmpRow ["gpon.vlanID"] = inputTable ["vlanID"]
	tmpRow ["enableDisableSerialNumber"] = inputTable["enableDisableSerialNumber"]
	tmpRow ["ponPasswd"] = inputTable["ponPasswd"]
	tmpRow ["serialNum"] = inputTable["serialNum"]

	valid = gpon.configure (tmpRow, "1", "edit")

        local jioPrivateNetSupport = "0"
        jioPrivateNetSupport = db.getAttribute ("Eogre", "_ROWID_", 1, "jioPrivateNet")
        --jioPrivateNetSupport = db.getAttribute ("environment", "name", "JIO_PRIVATE_NET" ,"value")
        if (jioPrivateNetSupport == "1") then
	    local eogregponRow = db.getRow ("gpon", "_ROWID_", "2")
            if(eogregponRow and inputTable["wifiVlanID"] ~= nil and eogregponRow["gpon.vlanID"] ~= inputTable["wifiVlanID"])then
                valid = db.setAttribute ("gpon", "_ROWID_","2","vlanID",inputTable["wifiVlanID"])
	        if (valid) then
                    valid = db.setAttribute ("gpon", "_ROWID_","2","status",tmpRow ["gpon.status"])
                end
            end
        end


	if (valid) then
		errMsg = "OK"
		statusMsg = "STATUS_OK"
		db.commitTransaction()
		-- change to save2 else, sometimes device rebooting without saving. CLM:349993
		db.save2()
	else
		errMsg = "ERROR"
		statusMsg = "WAN_PORT_MODE_CONFIG_FAILED"
		db.rollback()
	end		
	
	return errMsg, statusMsg
	

end
