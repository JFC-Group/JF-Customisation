-------------------------------------------------------------------------------
-- Sends logging information to syslog
--
-- @copyright Copyright (c) 2012, TeamF1, Inc. 
-------------------------------------------------------------------------------

require"lualogging/logging"
require "syslog"

local LOG_LEVEL = {
	["DEBUG"] = "LOG_DEBUG",
	["INFO"]  = "LOG_INFO",
	["WARN"]  = "LOG_WARNING",
	["ERROR"] = "LOG_ERR",
	["FATAL"] = "LOG_CRIT",
}

function logging.syslog(facility)
    syslog.openlog(facility, syslog.LOG_ODELAY, "LOG_USER")
    return logging.new(function(self, level, message)
                       level = LOG_LEVEL[level]
                       syslog.syslog(level, message)
                       return true
                       end)
end
