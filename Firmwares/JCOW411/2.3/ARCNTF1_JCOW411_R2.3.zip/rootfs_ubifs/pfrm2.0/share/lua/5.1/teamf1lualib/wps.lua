--[[
#### Hussain Vali.
#### TeamF1
#### www.TeamF1.com
#### Jan 30, 2009

#### File: wps.lua
#### Description: wps functions

#### Revisions:
]]--


--table packages
wps = {}

--************* Functions *************
-- wps config
function wps.config (inputTable, rowid, operation)
    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
           return db.insert("dot11WPS", inputTable)
        elseif (operation == "edit") then
           return db.update("dot11WPS", inputTable, rowid)
        elseif (operation == "delete") then
           return db.delete("dot11WPS", inputTable)
        end
    else
        return false
    end
end

-- dot11VAP config
function wps.wpsConfig (inputTable, rowid, operation)
	-- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end
	
	db.beginTransaction() --begin transaction
	local valid = false

    valid = wps.config (inputTable, rowid, operation)

    -- return
	if (valid) then
		db.commitTransaction()
		return "OK", "STATUS_OK"
	else
		db.rollback()
		return "ERROR", "DOT11_WPS_CONFIG_FAILED"
	end
end

function wps.validatePin (pinStr)
    local pinNum = 0
    local accum = 0
    
    util.appendDebugOut ("In wpsValidatePin<br>")
    if ( string.len (pinStr) == 8) then
        pinNum = tonumber (pinStr)

        accum = math.floor (accum + (3 * (math.floor((pinNum / 10000000))% 10)))
        accum = math.floor (accum + (1 * (math.floor((pinNum / 1000000))% 10)))
        accum = math.floor (accum + (3 * (math.floor((pinNum / 100000))% 10))) 
        accum = math.floor (accum + (1 * (math.floor((pinNum / 10000))% 10))) 
        accum = math.floor (accum + (3 * (math.floor((pinNum / 1000))% 10))) 
        accum = math.floor (accum + (1 * (math.floor((pinNum / 100))% 10))) 
        accum = math.floor (accum + (3 * (math.floor((pinNum / 10))% 10))) 
        accum = math.floor (accum + (1 * (math.floor((pinNum / 1)) % 10))) 

        util.appendDebugOut ("accum " .. accum .. "<br>")
        if ((accum % 10) == 0) then
            util.appendDebugOut ("Returning OK<br>")
            return "OK", "STATUS_OK"
        end
    end

    util.appendDebugOut ("Returning ERROR<br>")
    return "ERROR", "DOT11_WPS_PIN_INVALID"

end
