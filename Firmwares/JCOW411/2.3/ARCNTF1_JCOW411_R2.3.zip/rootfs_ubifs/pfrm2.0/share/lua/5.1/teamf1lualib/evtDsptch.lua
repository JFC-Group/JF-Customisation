-- @copyright Copyright (c) 2012, TeamF1, Inc. 

evtDsptch = {}
evtDsptch.debug  = 0
evtDsptch.event =  {
    IFDEV_EVENT_IF_ADD                  = 0, 
    IFDEV_EVENT_IF_DEL                  = 1,
    IFDEV_EVENT_FLAGS_UP                = 2,
    IFDEV_EVENT_FLAGS_DOWN              = 3,
    IFDEV_EVENT_MAC_ADDR_CHG            = 4,

    IFDEV_EVENT_IP_ADDR_CHG             = 5,

    IFDEV_EVENT_IP6_ADDR_ADD            = 6,
    IFDEV_EVENT_IP6_ADDR_DEL            = 7,
    IFDEV_EVENT_IP6_NET_UP              = 8,
    IFDEV_EVENT_IP6_NET_DOWN            = 9,

    IFDEV_EVENT_IP4_NET_UP              = 10,
    IFDEV_EVENT_IP4_NET_DOWN            = 11,
    IFDEV_EVENT_IP4_ADDR_ADD            = 12,
    IFDEV_EVENT_IP4_ADDR_DEL            = 13,

    IFDEV_EVENT_MTU_CHG                 = 14,

    IFDEV_EVENT_NET_ADD                 = 15,
    IFDEV_EVENT_NET_DEL                 = 16,
    IFDEV_EVENT_NETIF_CHG               = 17,
    IFDEV_EVENT_IFNAME_CHG              = 18,
    IFDEV_EVENT_IFMODE_CHG              = 19,
    IFDEV_EVENT_IFZONE_CHG              = 20,
    IFDEV_EVENT_MAX                     = 21,
}

-------------------------------------------------------------------------------
-- @name evtDsptch.evtUnregister
--
-- @description 
-- TODO: This function should make an UMI request to the event dispatcher
-- instead of modifying the DB.
--
-- @return 
--

function evtDsptch.evtUnregister (userId, filter)
    local query = ""

    if (userId == nil) then
        evtDsptch.dprintf("evtUnregister: Invalid args")
        return "ERROR", "EVTDSPTCH_INVALID_ARG"
    end
            
    query = "userId='" .. userId .. "' "
    if (filter ~= nil) then
        query = query .. " and " .. filter
    end        

    evtDsptch.dprintf("Delete event registration: " .. query)
     
    local valid, errstr = db.deleteRowWhere("ifDevEventTbl", query);
    if (not valid) then
        evtDsptch.dprintf("evtUnregister: failed to delete event registration. " ..
                          "Query: " .. query  .. 
                          "Err: " .. errstr)
        return "ERROR", "EVTDSPTCH_DB_ERR"
    end        

    return  "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name evtDsptch.evtRegister
--
-- @description 
-- TODO: This function should make an UMI request to the event dispatcher
-- instead of modifying the DB.
--
-- @return 
--

function evtDsptch.evtRegister (regTbl)
    for i,v in ipairs (regTbl) do
        v = util.addPrefix (v, "ifDevEventTbl.");
        evtDsptch.dprintf("evtRegister: Adding event registration: " .. util.tableToStringRec(v))
        local valid, errstr = db.insert ("ifDevEventTbl", v)
        if (not valid) then
            evtDsptch.dprintf("evtRegister: failed to register to event:" ..
                              v["ifDevEventTbl.event"] .. " for " .. 
                              v["ifDevEventTbl.userId"] .. "ERR:" .. errstr)
        end            
    end        

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name evtDsptch.import
--
-- @description 
--
-- @return 
--

function evtDsptch.import (configTable)
end

-------------------------------------------------------------------------------
-- @name evtDsptch.export
--
-- @description 
--
-- @return 
--

function evtDsptch.export ()
    local cfg = {}
    return cfg 
end

if (config.register) then
   config.register("evtDsptch", evtDsptch.import, evtDsptch.export, "1")
end

--[[
*******************************************************************************
-- @name evtDsptch.dprintf
--
-- @description 
--
-- @param 
--
-- @return 
--
--]]

function evtDsptch.dprintf(str)
    if (str == nil) then
        return
    end

    if (evtDsptch.debug == 1) then
        print ("EVTDSPTCH: " .. str)
        return
    end        

    if ((gui ~= nil) and (gui.debug == 1)) then
        util.appendDebugOut ("EVTDSPTCH: "  .. str .. "<br>")
    end        

    return 
end
