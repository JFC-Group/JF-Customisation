--[[ easyMeshDevicesInfo.lua - Handler for Easy Mesh DeviceInfo Method.
--
-- Copyright (c) 2008-2019, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: easyMeshDevicesInfo.lua
-- Description: Handler for Easy Mesh DeviceInfo Method.
-- 
-- modification history
-- --------------------
-- 01a, 20Jan2020, ar written.
--
--]]
require "teamf1lualib/ifDev"
require "teamf1lualib/easyMeshTopologyLib"
--require "teamf1lualib/easyMeshClientInfoLib"

-- Devices Request Object as defined by Customer Specification.
local DeviceRequestObj = {
    ["Device_Type"]      = "Device_Type",
    ["Device_MAC"]  = "Device_MAC",
    ["Hop_Count"]  = "Hop_Count"
}

-- List of Device Tags as defined by Customer Specification.
local DeviceeResObj = {
    ["Result"] = "Result"
}

-- Initialise the DeviceResponse_t Lua Table which will be coverted as JSON Object
local DeviceResponse_t = {
    ["Result"] = "ERROR",
    ["Response_Code"] = "400",
    ["Error_Message"] = "Failed to get Device Info"
}

-- Supported Return Codes for "Device Response"
local DeviceResponse_ReturnCodes = {
    ["OK"] = "OK",
    ["ERROR"] = "ERROR",
    ["SUCCESS"] = "Success",
    ["FAILED"]  = "Failed"
}

if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then
	TOPOLOGY_DUMP_GENERATE_CMD = "/bin/sh /pfrm2.0/bin/brcmGenerateDump.sh"
else
	TOPOLOGY_DUMP_GENERATE_CMD = "/userfs/bin/mapd_cli /tmp/mapd_ctrl dump_topology_v1"
end
TOPOLOGY_DUMP_FILE = "/tmp/dump.txt"
INTERNET_FILE_CHECK = "/tmp/gponFailed"

function getDeviceSerial()
    local serialFilep = io.open("/tmp/deviceSerial", "r")
    local serial = "N.A"
    if (serialFilep ~= nil) then
        serial = serialFilep:read("*all")
    end
    return serial
end

function getDeviceHwVersion()
    local hwFilep = io.open("/tmp/hwVersion", "r")
    local hwVersion = "N.A"
    if (hwFilep ~= nil) then
        hwVersion = hwFilep:read("*all")
    end
    return hwVersion
end


function getDeviceIPAddress()

    local ipAddr = nil

    local iprow = db.getRowWhere("ifstatic", "LogicalIfName='IF2' and AddressFamily=2", false)
    if (iprow ~= nil and iprow["StaticIp"] ~= nil and iprow["StaticIp"] ~= "") then
        ipAddr = iprow["StaticIp"]
    end
   
    return ipAddr
end

function getDeviceUplinkSignalStrength(topology_t, deviceMac)

    local topologyRoot = {}
    local currNode = {}
    local upLink = ""
    local signalStrength = ""
    
    topologyRoot = topology_t[TOPOLOGY_INFO_NODE]
    for i=1,#topologyRoot do
        currNode = topologyRoot[i]
        if (string.upper(currNode[AL_MAC]) == string.upper(deviceMac)) then
            break
        end
    end

    if ((currNode[BH_INFO_NODE] ~= nil) and (currNode[BH_INFO_NODE][1] ~= nil) 
        and (currNode[BH_INFO_NODE][1]["RSSI"] ~= nil) and 
	(currNode[BH_INFO_NODE][1]["Backhaul Medium Type"] ~= nil)) then
        upLink =  currNode[BH_INFO_NODE][1]["Backhaul Medium Type"]
        signalStrength =  currNode[BH_INFO_NODE][1]["RSSI"]
    end

    return upLink, signalStrength
end


function getDeviceSerialNo(topology_t, deviceMac)

    local topologyRoot = {}
    local currNode = {}
    local upLink = ""
    local signalStrength = ""
    
    topologyRoot = topology_t[TOPOLOGY_INFO_NODE]
    for i=1,#topologyRoot do
        currNode = topologyRoot[i]
        if (string.upper(currNode[AL_MAC]) == string.upper(deviceMac)) then
            break
        end
    end


    return currNode["model serial number"]
end

function getEasyMeshDevicesInfoHandler(methodObj, meshRequestMethod)

    local status
    local topology_t
    local deviceType    = methodObj["Device_Type"]
    local deviceMac     = methodObj["Device_MAC"]
    local deviceHopCount    = methodObj["Hop_Count"]
    local DeviceInfo    = {}
    local WiFiSonResponse_t    = {}
    local meshTopology_t    = {}

    if ((deviceType == nil) or (deviceMac == nil) or 
	    ((deviceType ~= "CAP") and (deviceType ~= "RE")) or 
	    (ifDev.macValidate(deviceMac) ~= "OK") ) then
        DeviceResponse_t["Result"] = DeviceResponse_ReturnCodes["FAILED"]
        DeviceResponse_t["Response_Code"] = "400"
        DeviceResponse_t["Error_Message"] = "Bad Request"
        --mesh.sendResponse (DeviceResponse_t) 
        return "ERROR", "INVALID_METHOD", DeviceResponse_t
    end

    mesh.dprintf("Device Type: " .. deviceType)
    mesh.dprintf("Device MAC: " .. deviceMac)

    -- generate topology dump.txt by executing below command.
    util.runShellCmd(TOPOLOGY_DUMP_GENERATE_CMD, "/dev/null")

    if (not (util.fileExists (TOPOLOGY_DUMP_FILE))) then
        DeviceResponse_t["Result"] = DeviceResponse_ReturnCodes["FAILED"]
        DeviceResponse_t["Response_Code"] = "501"
        DeviceResponse_t["Error_Message"] = "No Data Available"
        --mesh.sendResponse (DeviceResponse_t) 
        return "ERROR", "INVALID_METHOD", DeviceResponse_t
    end

    -- convert the generated topology dump.txt file to a Lua Table
    topology_t = json.decode(util.fileToString (TOPOLOGY_DUMP_FILE))

    if (topology_t == nil) then
        DeviceResponse_t["Result"] = DeviceResponse_ReturnCodes["FAILED"]
        DeviceResponse_t["Response_Code"] = "501"
        DeviceResponse_t["Error_Message"] = "No Data Available"
       -- mesh.sendResponse (DeviceResponse_t) 
        return "ERROR", "INVALID_METHOD", DeviceResponse_t
    end

    status, WiFiSonResponse_t, meshTopology_t = easyMeshTopologyLib.getMeshTopologyNodes(topology_t)
    if (status ~= "OK") then
        DeviceResponse_t["Result"] = DeviceResponse_ReturnCodes["FAILED"]
        DeviceResponse_t["Response_Code"] = "501"
        DeviceResponse_t["Error_Message"] = "No Data Available"
        --mesh.sendResponse (DeviceResponse_t) 
        return "ERROR", "INVALID_METHOD", DeviceResponse_t
    end

    for i,device in pairs(WiFiSonResponse_t["WiFiSON"]) do
        if( string.lower(device["Device_MAC"]) == string.lower(deviceMac)) then
            DeviceInfo = device
            break
        end
    end

    if (DeviceInfo == nil) then
        DeviceResponse_t["Result"] = DeviceResponse_ReturnCodes["FAILED"]
        DeviceResponse_t["Response_Code"] = "501"
        DeviceResponse_t["Error_Message"] = "No Data Available"
        --mesh.sendResponse (DeviceResponse_t) 
        return "ERROR", "INVALID_METHOD", DeviceResponse_t
    end

    if (deviceType == "CAP") then
        if ((DeviceInfo["ParentAPMAC"] ~= "00:00:00:00:00:00") and (DeviceInfo["Hop_Count"] ~= "0")) then
            DeviceResponse_t["Result"] = DeviceResponse_ReturnCodes["FAILED"]
            DeviceResponse_t["Response_Code"] = "501"
            DeviceResponse_t["Error_Message"] = "No Data Available"
            --mesh.sendResponse (DeviceResponse_t) 
            return "ERROR", "INVALID_METHOD", DeviceResponse_t
        end
    else
        if ((DeviceInfo["ParentAPMAC"] == "00:00:00:00:00:00") or (DeviceInfo["Hop_Count"] == "0")) then
            DeviceResponse_t["Result"] = DeviceResponse_ReturnCodes["FAILED"]
            DeviceResponse_t["Response_Code"] = "501"
            DeviceResponse_t["Error_Message"] = "No Data Available"
            --mesh.sendResponse (DeviceResponse_t) 
            return "ERROR", "INVALID_METHOD", DeviceResponse_t
        end
    end

    if ((DeviceInfo["ParentAPMAC"] == "00:00:00:00:00:00") and (DeviceInfo["Hop_Count"] == "0")) then
        DeviceResponse_t["Device_HWVersion"] = getDeviceHwVersion()
        DeviceResponse_t["Device_FWVersion"] = db.getAttribute ("system", "_ROWID_", "1", "firmwareVer") or ""
        DeviceResponse_t["Device_IPAddress"] = getDeviceIPAddress()
        DeviceResponse_t["Device_SN"] = getDeviceSerial()
	    DeviceResponse_t["Device_Uplink"] = "Wired"
        if (util.fileExists (INTERNET_FILE_CHECK)) then
            DeviceResponse_t["WiFiSON_Internet"] = "0"
        else
            DeviceResponse_t["WiFiSON_Internet"] = "1"
        end
    else
        DeviceResponse_t["Device_HWVersion"] = ""
        DeviceResponse_t["Device_FWVersion"] = ""
        local deviceIpAddr = db.getAttribute("LanHosts" ,"MACAddress",string.lower(deviceMac),"IPAddress")
        DeviceResponse_t["Device_IPAddress"] = deviceIpAddr or ""
        DeviceResponse_t["Device_SN"] = getDeviceSerialNo(topology_t,deviceMac) or ""
        DeviceResponse_t["Device_Uplink"], DeviceResponse_t["SignalStrength"] = getDeviceUplinkSignalStrength(topology_t,deviceMac)
    end

    DeviceResponse_t["Device_Type"] = deviceType
    DeviceResponse_t["Hop_Count"] = DeviceInfo["Hop_Count"]
    DeviceResponse_t["ParentAPMAC"] = DeviceInfo["ParentAPMAC"]
    DeviceResponse_t["Device_ModelNumber"] = DeviceInfo["Device_ModelNumber"]
    DeviceResponse_t["Device_NickName"] = DeviceInfo["Device_Name"]
    DeviceResponse_t["Device_MAC"] = deviceMac
    DeviceResponse_t["Result"] = DeviceResponse_ReturnCodes["OK"]
    DeviceResponse_t["Response_Code"] = "200"
    DeviceResponse_t["Error_Message"] = nil

    --mesh.sendResponse (DeviceResponse_t) 
    return "OK", "SUCCESS", DeviceResponse_t
end

meshRequestMethodsList["Device"]["methodHandler"] = getEasyMeshDevicesInfoHandler
