-- tr69funcs.lua - TR69 get/set functions

-- Copyright (c) 2010 TeamF1, Inc.

-- Copyright (c) 2010-2014, TeamF1 Networks Pvt. Ltd.
-- (Subsidiary of D-Link India)

--[[
 * modification history
 * --------------------
 * 01i,22Jan19,mou  Changes for SPR 64817
 * 01h,31Jul17,swr  Changes for SPR 60117
 * 01g,18Apr17,swr  Changes for exclude dot11, pkgMgmt, diskMgmt files for hg261gu
 * 01f,11Jan17,swr  Changes for SPR 58560
 * 01e,11Aug15,swr  added validation function for IP, string length and subnet.
 * 01d,10oct14,swr  included captivePortalTrExtn file
 * 01c,12aug13,lnv  modifed and adapted for ril 
 * 01b,21jun11,sam  added function to get the active wan interface.
 * 01a,29mar10,sam  written.
--]]

--[[
 * DESCRIPTION
 * This file is included from tr69Glue.lua. All the custom get/set functions defined
 * in tr69DB.map are defined here.
 *
 * TR69 GET FUNCTION REQUIREMENTS
 * ------------------------------
 * The input to all the GET functions is a table having the following columns
 * param: name of the TR69 parameter
 * table: table name (that is registered in tr69DB.map for this parameter)
 * field: name of the field (that is registered in tr69DB.map for this parameter) 
 *
 * All functions should return two values (The name of the variables MUST
 * also be same, The caller looks for these variable names in the stack)
 *
 * Returns: status, value
 * -------
 * status - "0" means success . Any other value is considered error
 *
 * TR69 ADD/SET/DELETE FUNCTION REQUIREMENTS
 * ------------------------------------------ 
 * The input arguments to all the SET/Add/Delete funcitons are below
 *
 * a) table of tablenames, fieldnames and the values of the parameter being set
 * b) table of rowids of all the tables in a)
 * c) action types -  (set/add/delete)
 * d) tr69Param - TR69 parameter name of the parent object
 *
 *    case 1
 *    ------
 *    if there is table T in which field F1 has to be set to a value V1, field 
 *    F2 has to be set to a value V2, then the first argument that is passed to the 
 *	  set function is filled as below
 *   
 *    input[T]={}
 *    input[T][F1] = V1
 *    input[T][F2] = V2
 *
 *    rowids = {}
 *    rowids[T] = <rowid>
 *  
 *    actionType = 1 (set), 2 (add) ,3 (delete)
 *    tr69Param = <name of the tr69 param>	
 * 
 *   case 2
 *   ------
 *    if an action request contains fields from different table, then the table is filled
 *    as below:
 *
 *    input[T1]={}
 *    input[T1][F1] = V1
 *    input[T2]={}
 *    input[T2][F2] = V2
 *
 *    rowids = {}
 *    rowids[T1] = <rowid>
 *    rowids[T2] = <rowid>
 *
 *    actionType = 1 (set), 2 (add) ,3 (delete)
 *    tr69Param = <name of the tr69 param>	
 *
 * The custom lua function has to update the database and also save the configuration change.
 *
--]]

-- Table for error code
error_code = {}
error_code["INVALID_PARAM_VALUE"] = "9007"
error_code["REQUEST_DENIED"] = "9001"
error_code["INTERNAL_ERROR"] = "9002"

OK = "0"
ERROR = "1"

-- Macros for min and max parameter values
ROUTE_METRIC_MIN_VAL = 2
ROUTE_METRIC_MAX_VAL = 15
RADIUS_PORT_MIN_VAL = 1
RADIUS_PORT_MAX_VAL = 65535 
RADIUS_SECRET_MAX_LEN = 128 
SSID_MIN_LEN = 1
if (util.fileExists ("/pfrm2.0/ASSOC_RADIUS_AUTH") or util.fileExists ("/pfrm2.0/JIO_PRIVATE_NET")) then
SSID_MAX_LEN =24
else    
SSID_MAX_LEN =32
end 
PASSPHRASE_MIN_LEN = 8
PASSPHRASE_MAX_LEN = 63
SUBNET_MASK_MAX = 255 

NAT_PORT_MIN_VAL = 1
NAT_PORT_MAX_VAL = 65535

VLANID_MIN_VAL = 1
VLANID_MAX_VAL = 4096

DATARATE_MIN_VAL = 1
DATARATE_MAX_VAL = 30720

MTU_MIN_VAL = 900
MTU_MAX_VAL = 1500

PREFIX_LEN_MIN = 1
PREFIX_LEN_MAX = 128

REKEY_INTERVAL_MIN = 600
REKEY_INTERVAL_MAX = 7200

LOOP_BACK_ADDRESS = "127.0.0.1"


local domainNameExt = {'.com', '.net', '.aero', '.asia', '.cat', '.jobs', '.org', '.biz', '.coop', '.info', '.museum', '.name', '.pro', '.tel', '.travel', '.edu', '.gov', '.int', '.mil', '.mobi', '.ac', '.ad', '.ae', '.af', '.ag', '.ai', '.al', '.am', '.an', '.ao', '.aq', '.ar', '.as', '.at', '.au', '.aw', '.ax', '.az', '.ba', '.bb', '.bd', '.be', '.bf', '.bg', '.bh', '.bi', '.bj', '.bm', '.bn', '.bo', '.br', '.bs', '.bt', '.bv', '.bw', '.by', '.bz', '.ca', '.cc', '.cd', '.cf', '.cg', '.ch', '.ci', '.ck', '.cl', '.cm', '.cn', '.co', '.cr', '.cu', '.cv', '.cx', '.cy', '.cz', '.de', '.dj', '.dk', '.dm', '.do', '.dz', '.ec', '.ee', '.eg', '.er', '.es', '.et', '.eu', '.fi', '.fj', '.fk', '.fm', '.fo', '.fr', '.ga', '.gb', '.gd', '.ge', '.gf', '.gg', '.gh', '.gi', '.gl', '.gm', '.gn', '.gp', '.gq', '.gr', '.gs', '.gt', '.gu', '.gw', '.gy', '.hk', '.hm', '.hn', '.hr', '.ht', '.hu', '.id', '.ie', '.il', '.im', '.in', '.io', '.iq', '.ir', '.is', '.it', '.je', '.jm', '.jo', '.jp', '.ke', '.kg', '.kh', '.ki', '.km', '.kn', '.kp', '.kr', '.kw', '.ky', '.kz', '.la', '.lb', '.lc', '.li', '.lk', '.lr', '.ls', '.lt', '.lu', '.lv', '.ly', '.ma', '.mc', '.md', '.me', '.mg', '.mh', '.mk', '.ml', '.mm', '.mn', '.mo', '.mp', '.mq', '.mr', '.ms', '.mt', '.mu', '.mv', '.mw', '.mx', '.my', '.mz', '.na', '.nc', '.ne', '.nf', '.ng', '.ni', '.nl', '.no', '.np', '.nr', '.nu', '.nz', '.om', '.pa', '.pe', '.pf', '.pg', '.ph', '.pk', '.pl', '.pm', '.pn', '.pr', '.ps', '.pt', '.pw', '.py', '.qa', '.re', '.ro', '.rw', '.ru', '.sa', '.sb', '.sc', '.sd', '.se', '.sg', '.sh', '.si', '.sj', '.sk', '.sl', '.sm', '.sn', '.so', '.sr', '.st', '.sv', '.sy', '.sz', '.tc', '.td', '.tf', '.tg', '.th', '.tj', '.tk', '.tm', '.tn', '.to', '.tp', '.tr', '.tt', '.tv', '.tw', '.tz', '.ua', '.ug', '.uk', '.um', '.us', '.uy', '.uz', '.va', '.vc', '.ve', '.vg', '.vi', '.vn', '.vu', '.ws', '.wf', '.ye', '.yt', '.yu', '.za', '.zm', '.zw'}

--[[
--*****************************************************************************
-- tr69Glue.instanceMapLoad - load the instance map file
--
-- This function reads the instance map file and load the contents into
-- a array.
--
--RETURN: instanceMap array
]]--

function tr69Glue.instanceMapLoad()
    local instanceMap = nil

    local filep = io.open("/tmp/tr69Instance.map", "r")
    if (filep ~= nil) then

        instanceMap = {}

        for line in io.lines ("/tmp/tr69Instance.map") do
	        for param,rowId in string.gfind (line, "(.*) (%w+)") do
	        	instanceMap[param] = rowId
        	end
        end
        io.close(filep)

    end

    return instanceMap   
end

--[[
--*****************************************************************************
-- tr69Glue.instanceNumberGet -
-- 
-- This function gets the instance number of a given level in the parameter.
--
-- RETURN: nil or instance number
]]--

function tr69Glue.instanceNumberGet (param, level)
	local count = 1

	for instanceNum in  string.gmatch(param, "%d+") do
		if (level == count) then	
			return instanceNum
		end
		count = count + 1
	end

	return nil
end

--[[
--*****************************************************************************
-- tr69Glue.maxRowIdGet - get the value max rowId
-- 
-- This function gets the maximum value of rowId in this table.
--
-- RETURN: 
]]--

function tr69Glue.maxRowIdGet (tableName)
	local rows = {}
	local rowId = 0
	local maxRowId = 0

	rows = db.getTable(tableName, false)
	if (rows == nil) then
		print ("tr69Glue.maxRowIdGet: " ..
			   "failed to get table:" .. tableName)
		return 0
	end
	
	for i,v in ipairs(rows) do
		rowId = tonumber(v["_ROWID_"])
		if (rowId > maxRowId) then
			maxRowId = rowId
		end
	end

	return maxRowId
end

--[[
--*****************************************************************************
-- tr69Glue.LogicalIfNameGet - find the LogicalIfName
-- 
-- This function finds the LogicalIfName.
--
-- RETURN: number of instances
]]--

function tr69Glue.LogicalIfNameGet(param)
	local rowId 
	local row = {}
	local query = nil

    local instanceMap =  tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
		print ("tr69Glue.LogicalIfNameGet: " ..
			   "failed to load instanceMap")
		return nil
    end

    rowId = instanceMap [param]
    if (rowId == nil) then
		print ("tr69Glue.LogicalIfNameGet: " ..
			    "could not get instance for " .. param)
		print ("instanceMap: " .. util.tableToStringRec(instanceMap))
		return nil
    end

	if (string.find(param,"LANDevice") ~= nil) then
		local query ="_ROWID_=" .. rowId

		-- get the bridge interface name
		local row = db.getRowWhere ("bridgeTable", query, false)
		if (row == nil) then
			print ("tr69Glue.LogicalIfNameGet: " ..
				    "query: " .. query .. "failed for bridgeTable")
			return nil
		end
		local interfaceName = row["interfaceName"]

		-- find the logical name of the bridge interface.
		return row["LogicalIfName"]
	else
		local query ="_ROWID_=" .. rowId

		-- get the bridge interface name
		local row = db.getRowWhere ("NimfConf", query, false)
		if (row == nil) then
			print ("tr69Glue.LogicalIfNameGet: " ..
				    "query: " .. query .. "failed for NimfConf")
			return nil
		end

		return row["LogicalIfName"]
	end
end

--[[
--*****************************************************************************
-- tr69Glue.activeWanIfNameGet - get active wan interface name
-- 
-- This function gets the active wan interface name.
--
-- activeWanIfName is the global variable
--
-- RETURN: interface name
]]--

function tr69Glue.activeWanIfNameGet()
	local query ="_ROWID_=1"
    local record = nil
    local LogicalIfName = 'IF1'  -- default
    require "teamf1lualib/ifDev"
    require "nimfLib"

    record = db.getRowWhere("tr69Config", query, false)
    if (record ~= nil) then
        LogicalIfName = record["LogicalIfName"]
    end        

    local status, errCode, cfg =  ifDev.cfgByNameGet(LogicalIfName)
    if (status ~= "OK") then
        return nil
    end        

    local connID = {}
    connID["LogicalIfName"] = LogicalIfName
    connID["AddressFamily"] = "2"
    connID["ConnectionKey"] = "0"

    local conn = nimfLib.connGet (connID)
    if (conn == nil) then
        return nil
    end

    return conn["Interface"]
end

--[[
--*****************************************************************************
-- tr69Glue.tf1Dbg - print dbg messages
-- 
-- This function prints dbg messages to a file
--
]]--

function tr69Glue.tf1Dbg(dbgMessage) 
   local dbgfile = ""
   dbgfile = io.open("/tmp/tf1GlueLua.log","a")
   if dbgfile~=nil then 
       dbgfile:write(dbgMessage .. "\n")
       io.close(dbgfile) 
   end
end

--[[
--*****************************************************************************
-- tr69Glue.tf1CheckSubnetValue - Subnet mask validation
-- 
-- This function validates the subnet mask 
--
-- Returns: 0 (success) 1 (error)
]]--
function tr69Glue.tf1CheckSubnetValue(subnet, field)
   local flag = 0
   local errMsg
   local subnetTable
    if (subnet ~= "" ) then
       if (validations.hasTypeValidate(subnet,"%a%s") == 1) then
          return 1;
       elseif (validations.hasTypeValidate(subnet,"%p",".",3) == 1) then
          return 1;
       else
          subnetTable = validations.split(subnet,".")
          flag,errMsg,field = validations.checkSubnetOctetValues(subnetTable,field)
       -- To validate whether a subnet octet sequnece is proper 
       -- Eg:- 0.255.0.255
          if (flag == 0) then
             if((subnetTable[1] == 0) or
               (subnetTable[1] ~= SUBNET_MASK_MAX and subnetTable[2] ~= 0) or
               (subnetTable[2] ~= SUBNET_MASK_MAX and subnetTable[3] ~=0) or
               (subnetTable[3] ~= SUBNET_MASK_MAX and subnetTable[4] ~= 0)) then
               return 1;
             end
          end
       end
    end
    return flag;
end

--[[
--*****************************************************************************
-- tr69Glue.tf1IpAddressValidate- IP address validation
-- 
-- This function is called to valid the IP address
--
-- Returns: OK (success) 1 (error)
]]--

function tr69Glue.tf1IpAddressValidate(ip,subnet,field,skipVar)
     return(validations.ipAddressValidate(ip,subnet,field,skipVar))
end

--[[
--*****************************************************************************
-- tr69Glue.tf1ValidateStringLength - validate string length 
-- 
-- Returns: OK ( no error ), 1 ( error), error message  
]]--

function tr69Glue.tf1ValidateStringLength(min, max, input, field)
   return validations.checkStringLength(min,max,input,field)
end

--[[
--*****************************************************************************
-- tr69Glue.tf1ValidateIpv6Address - validate IPv6 address 
-- 
-- Returns: OK ( no error ), 1 ( error), error message  
]]--

function tr69Glue.tf1ValidateIpv6Address(ipAddr, field, skipChk)
   return validations.ipv6AddrValidate(ipAddr, field, skipChk)
end

--[[
--*****************************************************************************
-- tr69Glue.isGatewayInTunnelSubnet - validate if the addr is valid 6to4 tunnel
-- address
-- 
-- Returns: 0(no error) or 1(error)  
]]--
function tr69Glue.isGatewayInTunnelSubnet (addr)
    if(addr == nil or addr == "") then
        return 1
    end

    local tunnelAddr = {}
    tunnelAddr = util.split(addr,"::") 

    --if number of values in tunnelAddr is more than 2, return error
    if(#tunnelAddr ~= 2) then
        return 1
    end

    if(tunnelAddr[1] ~= nil and tunnelAddr[1] ~= "") then
        return 1
    end

    if(tunnelAddr[2] == LOOP_BACK_ADDRESS or tunnelAddr[2] == "") then
        return 1
    end

    if(tr69Glue.tf1IpAddressValidate(tunnelAddr[2],"","","") ~= "OK") then
        return 1
    end

	return 0
end

--[[
--*****************************************************************************
-- tr69Glue.tf1IpRangeValidate(ip1,ip2) - validate IP range 
-- 
-- Returns: OK ( no error ), 1 ( error), error message  
]]--

function tr69Glue.tf1IpRangeValidate(ip1, ip2)
   return validations.ipRangeValidate(ip1, ip2)
end

--[[
--*****************************************************************************
-- tr69Glue.tf1ValidateMacAddr - validate MAC address 
-- 
-- Returns: OK ( no error ), 1 ( error), error message  
]]--

function tr69Glue.tf1ValidateMacAddr(mac,field)
   return validations.macAddressValidate(mac,field)
end

--[[
--*****************************************************************************
-- tr69Glue.tf1ValidateDUID - validate DUID 
-- 
-- Returns: OK ( no error ), 1 ( error), error message  
]]--

function tr69Glue.tf1ValidateDUID(duid, field)
    local flag = 0
    local errMsg = ""

    duidTable = validations.split(duid, ":")
    if(#duidTable < 8 or #duidTable > 130 ) then
        return "ERROR", "ERROR_DUID_NUMBER_OF_OCTETS", field ,""
    end

    flag = validations.hasTypeValidate(duid, "%s%p", ":", #duidTable-1)
    if(flag == 1) then
        return 1, "INVALID_DUID_ERR_SPCLCHAR", field, ""
    elseif (flag == 0) then
        for k,v in pairs(duidTable) do
            if(duidTable[k] == nil or duidTable[k] == "") then
                return 1, "ERR_DUID_EMPTY_VALUE_OCTET_"..k, field,""
            elseif(string.len(duidTable[k]) ~= 2) then
                return 1, "ERR_TWOCHAR_OCTET_"..k, field, ""
            else
                if(validations.hasTypeValidate(duidTable[k], "g-z") == 1) then
                    return 1, "ERR_ONLYHEX_OCTET_"..k, field, ""
                else
                    flag = 0
                end
            end
        end
    end

    return flag, errMsg, field, ""
end

--[[
--******************************************************************************
-- tr69Glue.tf1domainNameValidate  - validate domain name
--
--Returns: OK( no error ), ERROR
]]--
function tr69Glue.tf1domainNameValidate(domainName,lastOctateVal)
    local status = "ERROR"
    local node=""
    local addrTbl = {}
    local i = 1
    
    addrTbl = util.split(domainName, ".")
    local j = util.tableSize(addrTbl)
    if (tr69Glue.tf1checkDomainExtension(lastOctateVal) ~= "OK") then
        return status
    end

    for i,j in pairs(addrTbl) do
        node = addrTbl[i]
        if (string.len(node) > 63) then
            return status
        end
    end

    if (string.len(domainName) > 253 or string.len(domainName) < 1) then
        return status
    end

    if (tr69Glue.tf1checkSpecialChar(domainName)~= "OK") then
        return status
    end

    return "OK"
end

--[[
--******************************************************************************
-- tr69Glue.tf1checkDomainExtension  - validate domain name extension
--
--Returns: OK( no error ), ERROR
]]--

function tr69Glue.tf1checkDomainExtension(lastOctateVal)
    local ext = "." .. lastOctateVal
    local i=1
    local j=util.tableSize(domainNameExt)
    for i,j in pairs (domainNameExt)do
        if (ext == domainNameExt[i]) then 
            return "OK" 
        end
    end
    return "ERROR"
end

--[[
--******************************************************************************
-- tr69Glue.tf1checkSpecialChar  - validate domain name for special characters
--
--Returns: OK( no error ), ERROR
]]--

function tr69Glue.tf1checkSpecialChar(domainName)
     local exceptionChars = {'-','.'}
     local idx = 1
     local charCode = "" 
     local addrTbl = {}
     addrTbl = util.split(domainName, ".")
     local v= util.tableSize(addrTbl)
    
   for k,v in pairs(addrTbl) do
        for idx = 1, string.len(addrTbl[k]) do
            charCode = string.sub(addrTbl[k],idx,idx)
            charCode = string.byte(charCode)
            if (not((charCode >= 97 and charCode <= 122) or (charCode >= 65 and charCode <= 90) or (charCode >= 48 and charCode <= 57) or charCode == exceptionChars[1] or charCode == exceptionChars[2])) then
                
                return "ERROR"
            end
        end
   end
    local firstChar = string.sub(domainName,1,1)
    local lastChar = string.sub(domainName,string.len(domainName),string.len(domainName)) 
    if ((firstChar == exceptionChars[1] or firstChar == exceptionChars[2]) or (lastChar == exceptionChars[1] or lastChar == exceptionChars[2])) then
        return "ERROR"
    end
    return "OK"
end
--[[
--*****************************************************************************
-- tr69Glue.tf1HasTypeValidate - Pattern Matching with type 
-- 
-- Returns: error flag = 0 (no error), 1 (error)  
]]--

function tr69Glue.tf1HasTypeValidate(value,regexp,except,count)
   return validations.hasTypeValidate(value,regexp,except,count)
end


function tr69Glue.tf1SetFaultCode(faultTbl, index, param, faultcode)
   faultTbl[index] = {}
   faultTbl[index]["parameterName"] = param
   faultTbl[index]["faultCode"] = faultcode
   return faultTbl
end

-- INCLUDE ALL TR-EXTENSION FILES BELOW 
require "teamf1lualib/timeTrExtn"
require "teamf1lualib/nimfTrExtn2"
require "teamf1lualib/ifDevTrExtn"
require "teamf1lualib/iputilsTrExtn"
require "teamf1lualib/maptTrExtn"
if(not util.fileExists("/pfrm2.0/HW_HG261GU")) then
require "teamf1lualib/dot11TrExtn"
require "teamf1lualib/diskMgmtTrExtn"
end
require "teamf1lualib/qosTrExtn"
require "teamf1lualib/firewallTrExtn"
require "teamf1lualib/cpuMemUsageTrExtn"
require "teamf1lualib/radvdTrExtn"
require "teamf1lualib/bridgeTrExtn"
require "teamf1lualib/routedTrExtn"
require "teamf1lualib/iprouteTrExtn"
require "teamf1lualib/captivePortalTrExtn"
require "teamf1lualib/validations"
require "teamf1lualib/userdbTrExtn"
require "teamf1lualib/igmpProxyTrExtn"
if (util.fileExists("/pfrm2.0/IPSEC_VPN_ENABLED")) then
require "teamf1lualib/vpnTrExtn"
end
if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED")) then
    require "teamf1lualib/easyMeshTrExtn"
end

