--[[
/*
Copyright (c) 2014, TeamF1 Networks Pvt. Ltd.
(Subsidiary of D-Link India)
*/

#### 
#### File: tr181_firewallTrExtn.lua
#### Description: 
#### TR-181 handlers for firewall. This file is included from tr181_tr69funcs.lua
####

/* modification history
 * --------------------
 * 01n,31Jul17,swr  Changes for SPR 60117
 * 01m,31Dec15,swr  Fix for SPR 54656 
 * 01l,23Nov15,srm  changes to support AO/DO functionality for PortMapping
 * 01k,20Nov15,srm  changes for SPR 51850
 * 01j,28Sep15,swr  changes for AddObject for portMapping from tr69
 * 01i,13Aug15,swr  changes for PortMapping get/set functions 
 * 01h,05Aug15,sda  Changes for SPR 51320.
 * 01g,24Jul14,swr  Changes for SPR 52567.
 * 01f,21Jun15,swr  changes for get/set functions 
 * 01e,06apr15,swr  Fix for SPR 50469 
 * 01d,01apr15,swr  Fix for SPR 50469 
 * 01c,17Feb15,swr  changes for PortMapping issue.
 * 01b,13Feb15,swr  Fix for SPR 49292.
 * 01a,17oct14,swr  changes for ALG get and set functions.
 */

]]--

fwTr = {}

-- includes
require "teamf1lualib/firewall"

local fwRulesScript = "/pfrm2.0/etc/fwRuleScript.lua"
local fwRulesCmd = "/pfrm2.0/bin/lua " .. fwRulesScript
local dbFlag = 0

--[[
--*****************************************************************************
-- fwTr.fwCfgGet- get firewall default policy configuration
-- 
-- This function is called to get the following parameters
-- Device.Firewall.Enable
-- Device.Firewall.Level.0.DefaultPolicy
-- Device.Firewall.Chain.0.Enable
--
-- Returns: status, value
]]--
function fwTr.fwCfgGet(input)
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local row = {}
    local query = nil
    local param = input["param"]

    --get corresponding db entry from 'defaultPolicy'
    query = "_ROWID_=1"
    row = db.getRowWhere ("defaultPolicy", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = "1"
    elseif(string.find(input["param"], "DefaultPolicy")) then
        -- DefaultPolicy
        if(row["defaultIpv4FwPolicy"] == "0") then
            value = "Drop"
        elseif(row["defaultIpv4FwPolicy"] == "1") then
            value = "Accept"
        else
            return "1", "DB_ERROR_TRY_AGAIN"
        end
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- fwTr.fwCfgSet- set firewall default policy configuration
-- 
-- This function is called to set the following parameters
-- Device.Firewall.Enable
-- Device.Firewall.Level.0.DefaultPolicy
-- Device.Firewall.Chain.0.Enable
--
-- Returns: status
]]--
function fwTr.fwCfgSet(input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering fwCfgSet..")

    local status = "0"
    local row = {}
    local rowId
    local query = nil
    local defPolicyRow = {}

    --get corresponding db entry from 'defaultPolicy'
    query = "_ROWID_=1"
    row = db.getRowWhere ("defaultPolicy", query, false)
    if(row == nil) then
        tr69Glue.tf1Dbg("Couldn't fetch corresponding defaultPolicy row..")
        status = "1"
        return "1";
    end

    --if 'Device.Firewall.Level.0.DefaultPolicy' didn't change then just return
    if(input["defaultPolicy"]["defaultPolicy.defaultIpv4FwPolicy"] == "" or
       input["defaultPolicy"]["defaultPolicy.defaultIpv4FwPolicy"] == nil ) then
        tr69Glue.tf1Dbg("only 'Device.Firewall.Enable' has changed then just return")
        return 0;
    end

    defPolicyRow = row
    --configure default policy
    if(input["defaultPolicy"]["defaultPolicy.defaultIpv4FwPolicy"] == "Drop") then
        defPolicyRow["defaultIpv4FwPolicy"] = "0"
    elseif(input["defaultPolicy"]["defaultPolicy.defaultIpv4FwPolicy"] == "Accept") then
        defPolicyRow["defaultIpv4FwPolicy"] = "1"
    else
        tr69Glue.tf1Dbg("Invalid default policy..")
        status = "1"
        return "1";
    end

    tr69Glue.tf1Dbg("Calling defaultPolciyConfigSet..")
    firewall.defaultPolicyConfigSet(defPolicyRow)

    tr69Glue.tf1Dbg("Leaving fwCfgSet..")
    return 0;
end

--[[
--*****************************************************************************
-- fwTr.fwPingEnableGet- get firewall default policy configuration
-- 
-- This function is called to get the following parameters
-- Device.Firewall.Enable
-- Device.Firewall.Level.0.DefaultPolicy
-- Device.Firewall.Chain.0.Enable
--
-- Returns: status, value
]]--
function fwTr.fwPingEnableGet(input)
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local row = {}
    local query = nil
    local param = input["param"]

    --get corresponding db entry from 'defaultPolicy'
    query = "_ROWID_=1"
    row = db.getRowWhere ("SpecificAttackChecks", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find & return parameter values
    if(string.find(input["param"], "X_TEAMF1_ExternalPing")) then
        value = row ["ExternalPing"]
    else
            return "1", "DB_ERROR_TRY_AGAIN"
    end
    
    return status, value
end

--[[
--*****************************************************************************
-- fwTr.fwPingEnableSet- set firewall default policy configuration
-- 
-- This function is called to set the following parameters
-- Device.Firewall.Enable
-- Device.Firewall.Level.0.DefaultPolicy
-- Device.Firewall.Chain.0.Enable
--
-- Returns: status
]]--
function fwTr.fwPingEnableSet(input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering fwCfgSet..")

    local status = "0"
    local errMsg = ""
    local row = {}
    local rowId
    local query = nil
    local pingEnableRow = {}

    --get corresponding db entry from 'defaultPolicy'
    query = "_ROWID_=1"
    row = db.getRowWhere ("SpecificAttackChecks", query, false)
    if(row == nil) then
        tr69Glue.tf1Dbg("Couldn't fetch corresponding SpecificAttackChecks row..")
        status = "1"
        return "1";
    end

    --if 'Device.Firewall.Level.0.DefaultPolicy' didn't change then just return
    if(input["defaultPolicy"]["defaultPolicy.X_TEAMF1_ExternalPing"] == "" or
       input["defaultPolicy"]["defaultPolicy.X_TEAMF1_ExternalPing"] == nil ) then
        tr69Glue.tf1Dbg("Nothing has changed then just return")
        return 0;
    end

    defPolicyRow = row
    --configure default policy
    if(input["defaultPolicy"]["defaultPolicy.X_TEAMF1_ExternalPing"] ~= nil) then
        if (input["defaultPolicy"]["defaultPolicy.X_TEAMF1_ExternalPing"] ~= "0" and 
            input["defaultPolicy"]["defaultPolicy.X_TEAMF1_ExternalPing"] ~= "1") then
                return 0;
            else
                pingEnableRow["ExternalPing"] = input["defaultPolicy"]["defaultPolicy.X_TEAMF1_ExternalPing"]
            end
    end

    tr69Glue.tf1Dbg("Calling specAttChkConfigSet..")
    status, errMsg = firewall.specAttChkConfigSet(pingEnableRow)
    
    if (status == "OK") then
        db.save()
    end

    tr69Glue.tf1Dbg("Leaving fwPingEnableSet..")
    return 0;
end

--[[
--*****************************************************************************
-- fwTr.ruleCfgGet- get firewall rule configuration
-- 
-- This function is called to get the following parameters
-- Device.Firewall.Chain.0.Rule.0.
--
-- Enable
-- Status
-- Target
-- SourceIP
-- DestIP
-- DestPort
-- DestPortRangeMax
--
-- Returns: status, value
]]--
function fwTr.ruleCfgGet(input)
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local row = {}
    local serviceEntry = {}
    local query = nil
    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "Rule.")
    parentObjInstance = string.sub(param, 1, endIdx+2)

    --read the rowId mapping to FirewallRules
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from FirewallRules
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("FirewallRules", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from Services
    query = "ServiceName='" .. row["ServiceName"] .. "'"
    serviceEntry = db.getRowWhere ("Services", query, false)
    if(serviceEntry == nil) then 
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = row["Status"]
    elseif(string.find(input["param"], "Status")) then
        -- Status
        if(row["Status"] == "1") then
            value = "Enabled"
        else
            value = "Disabled"
        end
    elseif(string.find(input["param"], "Target")) then
        -- Target
        if(row["Action"] == "ACCEPT") then
            value = "Accept"
        else
            value = "Drop"
        end
    elseif(string.find(input["param"], "SourceIP")) then
        -- SourceIP
        if(row["SourceAddressType"] == "0") then
            value = "ANY"
        elseif(row["SourceAddressType"] == "1") then
            value = row["SourceAddressStart"]
        elseif(row["SourceAddressType"] == "2") then
            value = row["SourceAddressStart"] .. "-" .. row["SourceAddressEnd"]
        else
            return "1", "DB_ERROR_TRY_AGAIN"
        end
    elseif(string.find(input["param"], "DestIP")) then
        -- DestIP
        if(row["DestinationAddressType"] == "0") then
            value = "ANY"
        elseif(row["DestinationAddressType"] == "1") then
            value = row["DestinationAddressStart"]
        elseif(row["DestinationAddressType"] == "2") then
            value = row["DestinationAddressStart"] .. "-" .. row["DestinationAddressEnd"]
        else
            return "1", "DB_ERROR_TRY_AGAIN"
        end
    elseif(string.find(input["param"], "DestPortRangeMax")) then
        -- DestPortRangeMax
        value = serviceEntry["DestinationPortEnd"]
    elseif(string.find(input["param"], "DestPort")) then
        -- DestPort
        value = serviceEntry["DestinationPortStart"]
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- fwTr.serviceByPortGet - fetch the service corresponding to this port
-- 
-- This function fetches the corresponding service row by DestPortStart
--
-- Returns: lua tbl containing a service row or nil
]]--
function fwTr.serviceByPortGet(dstPortStart)
    local serviceRow = {}
    local query = ""

    query = "DestinationPortStart='" .. dstPortStart .. "'"
    serviceRow = db.getRowWhere ("Services", query, false)

    if(serviceRow == nil) then
        return nil; 
    end

    return serviceRow;
end

--[[
--*****************************************************************************
-- fwTr.ruleCfgSet- set firewall rule configuration
-- 
-- This function is called to set the following parameters
-- Device.Firewall.Chain.0.Rule.0.
--
-- Enable
-- Target
-- SourceIP
-- DestIP
-- DestPort
-- DestPortRangeMax
--
-- Returns: status, value
]]--
function fwTr.ruleCfgSet(input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering ruleCfgSet..")

    local status = "0"
    local row = {}
    local rowId
    local query = nil
    local ruleConfTbl = {}

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = "1"
        return "1";
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(tr69Param, "Rule.")
    parentObjInstance = string.sub(tr69Param, 1, endIdx+2)

    --read the rowId mapping to FirewallRules
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        status = "1"
        return "1";
    end

    --get corresponding db entry from FirewallRules
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("FirewallRules", query, false)
    if(row == nil) then
        status = "1"
        return "1";
    end

    ruleConfTbl = row
    --Enable
    if(input["FirewallRules"]["FirewallRules.Status"] ~= nil) then
        ruleConfTbl["Status"] = input["FirewallRules"]["FirewallRules.Status"]
    end

    --Target
    if(input["FirewallRules"]["FirewallRules.Action"] ~= nil) then
        if(input["FirewallRules"]["FirewallRules.Action"] == "Accept") then
            ruleConfTbl["Action"] = "ACCEPT"
        elseif(input["FirewallRules"]["FirewallRules.Action"] == "Drop") then
            ruleConfTbl["Action"] = "DROP"
        else
            status = "1"
            return "1";
        end
    end

    local startIp, endIp
    -- SourceIP
    if(input["FirewallRules"]["FirewallRules.srcIP"] ~= nil) then
        tr69Glue.tf1Dbg("srcIP:" .. input["FirewallRules"]["FirewallRules.srcIP"])

        if(input["FirewallRules"]["FirewallRules.srcIP"] == "ANY") then
            ruleConfTbl["SourceAddressType"] = "0"
        elseif(string.find(input["FirewallRules"]["FirewallRules.srcIP"], "-")) then 
            startIdx, endIdx = string.find(input["FirewallRules"]["FirewallRules.srcIP"], "-")
            startIp = string.sub(input["FirewallRules"]["FirewallRules.srcIP"], 1, endIdx-1)
            endIp = string.sub(input["FirewallRules"]["FirewallRules.srcIP"], endIdx+1)

            ruleConfTbl["SourceAddressType"] = "2"
            ruleConfTbl["SourceAddressStart"] = startIp
            ruleConfTbl["SourceAddressEnd"] = endIp

            tr69Glue.tf1Dbg("startIp:" .. startIp)
            tr69Glue.tf1Dbg("endIp:" .. endIp)
        else
            tr69Glue.tf1Dbg("singleip case..")
            ruleConfTbl["SourceAddressType"] = "1"
            ruleConfTbl["SourceAddressStart"] = input["FirewallRules"]["FirewallRules.srcIP"]
        end
    end

    -- DestIP
    if(input["FirewallRules"]["FirewallRules.dstIP"] ~= nil) then
        tr69Glue.tf1Dbg("dstIP:" .. input["FirewallRules"]["FirewallRules.dstIP"])
        if(input["FirewallRules"]["FirewallRules.dstIP"] == "ANY") then
            ruleConfTbl["DestinationAddressType"] = "0"
        elseif(string.find(input["FirewallRules"]["FirewallRules.dstIP"], "-")) then 
            startIdx, endIdx = string.find(input["FirewallRules"]["FirewallRules.dstIP"], "-")
            startIp = string.sub(input["FirewallRules"]["FirewallRules.dstIP"], 1, endIdx-1)
            endIp = string.sub(input["FirewallRules"]["FirewallRules.dstIP"], endIdx+1)

            ruleConfTbl["DestinationAddressType"] = "2"
            ruleConfTbl["DestinationAddressStart"] = startIp
            ruleConfTbl["DestinationAddressEnd"] = endIp

            tr69Glue.tf1Dbg("startIp:" .. startIp)
            tr69Glue.tf1Dbg("endIp:" .. endIp)
        else
            tr69Glue.tf1Dbg("singleip case..")
            ruleConfTbl["DestinationAddressType"] = "1"
            ruleConfTbl["DestinationAddressStart"] = input["FirewallRules"]["FirewallRules.dstIP"]
        end
    end

    local serviceRow = {}
    -- DestPort
    if(input["FirewallRules"]["FirewallRules.dstPort"] ~= nil) then 
        serviceRow = fwTr.serviceByPortGet(input["FirewallRules"]["FirewallRules.dstPort"])
        if(serviceRow == nil or serviceRow == "") then
            tr69Glue.tf1Dbg("No service exists with this dest port..")
            status = "1"
            return "1";
        end

        ruleConfTbl["ServiceName"] = serviceRow["ServiceName"]
    end

    --apply rule settings
    local ret, errorCode
    ret, errorCode = firewall.fwRulesEditSet(ruleConfTbl)
    db.save()

    tr69Glue.tf1Dbg("Leaving ruleCfgSet..")
    return 0;
end

--[[
--*****************************************************************************
-- fwTr.portMapCfgGet- get port forwarding rule configuration
-- 
-- This function is called to get the following parameters
-- Device.NAT.PortMapping.0.
--
-- Enable
-- Status
-- X_TEAMF1_Action
-- RemoteHost
-- ExternalPort
-- InternalClient
-- InternalPort
--
-- Returns: status, value
]]--
function fwTr.portMapCfgGet(input)
    local status = "0"
    local value = "0"
    local rowId
    local row = {}
    local serviceEntry = {}
    local query = nil
    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --read the rowId mapping to FirewallRules
    rowId = instanceMap[param]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from FirewallRules
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("FirewallRules", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from Services
    query = "ServiceName='" .. row["ServiceName"] .. "'"
    serviceEntry = db.getRowWhere ("Services", query, false)
    if(serviceEntry == nil) then 
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = row["Status"]
    elseif(string.find(input["param"], "Status")) then
        -- Status
        if(row["Status"] == "1") then
            value = "Enabled"
        else
            value = "Disabled"
        end
    elseif(string.find(input["param"], "X_TEAMF1_Action")) then
        -- X_TEAMF1_Action
        if(row["Action"] == "ACCEPT") then
            value = "Accept"
        else
            value = "Drop"
        end
    elseif(string.find(input["param"], "RemoteHost")) then
        -- RemoteHost
        if(row["SourceAddressType"] == "0") then
            value = "ANY"
        elseif(row["SourceAddressType"] == "1") then
            value = row["SourceAddressStart"]
        elseif(row["SourceAddressType"] == "2") then
            value = row["SourceAddressStart"] .. "-" .. row["SourceAddressEnd"]
        else
            return "1", "DB_ERROR_TRY_AGAIN"
        end
    elseif(string.find(input["param"], "ExternalPort")) then
        -- ExternalPort
        value = serviceEntry["DestinationPortStart"]
    elseif(string.find(input["param"], "InternalClient")) then
        -- InternalClient
        value = row["DNATAddress"]
    elseif(string.find(input["param"], "InternalPort")) then
        -- InternalPort
        value = row["DNATPort"]
    elseif((string.sub(input["param"], -9, -1)) == "Interface") then
        local logicalIfName = "IF1"
        local ifObj = ""
        ifObj = nimfTr.getIfaceObjFromIfname(logicalIfName)
        value = ifObj
    elseif((string.sub(input["param"], -13, -1)) == "AllInterfaces") then
        -- Port Triggering is not enabled for all interface
        value = 0
    elseif(string.find(input["param"], "LeaseDuration")) then
        -- Static Always
        value = 0
    elseif(string.find(input["param"], "Description")) then
        -- Description
        if(row["Description"] ~= nil and row["Description"] ~= "") then
            value = row["Description"]
        else
            value = ""
        end
    elseif(string.find(input["param"], "Protocol")) then
        if (serviceEntry["Protocol"] == "6" ) then
            value = "TCP"
        else
            value = "UDP"
        end
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- fwTr.portMappingCfgGet- get port forwarding rule configuration
-- 
-- This function is called to get the following parameters
-- Device.NAT.PortMapping.0.
--
-- Enable
-- Status
-- X_TEAMF1_Action
-- RemoteHost
-- ExternalPort
-- InternalClient
-- InternalPort
--
-- Returns: status, value
]]--
function fwTr.portMappingCfgGet(input)
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local row = {}
    local serviceEntry = {}
    local query = nil
    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "PortMapping.")
    parentObjInstance = string.sub(param, 1, endIdx+2)

    --read the rowId mapping to FirewallRules
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from FirewallRules
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("FirewallRules", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = row["Status"]
    elseif(string.find(input["param"], "Status")) then
        -- Status
        if(row["Status"] == "1") then
            value = "Enabled"
        else
            value = "Disabled"
        end
    elseif(string.find(input["param"], "ExternalPort")) then
        -- ExternalPort
        value = row["DestinationPortStart"]        
    elseif(string.find(input["param"], "InternalClient")) then
        -- InternalClient
        value = row["DNATAddress"]
    elseif((string.sub(input["param"], 26, -1)) == "Interface") then
        local logicalIfName = "IF1"
        local ifObj = ""
        ifObj = nimfTr.getIfaceObjFromIfname(logicalIfName)
        value = ifObj
    elseif((string.sub(input["param"], 26, -1)) == "AllInterfaces") then
        -- Port Triggering is not enabled for all interface
        value = 0
    elseif(string.find(input["param"], "LeaseDuration")) then
        -- Static Always
        value = 0
    elseif(string.find(input["param"], "Description")) then
        -- Static Always
        value = "default" .. rowId
    elseif(string.find(input["param"], "Protocol")) then
        if (row["Protocol"] == "6" ) then
            value = "TCP"
        elseif (row["Protocol"] == "17" ) then
            value = "UDP"
        elseif (row["Protocol"] == "256" ) then
            value = "BOTH"
        end
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- fwTr.portMapCfgSet- set firewall rule configuration
-- 
-- This function is called to set the following parameters
-- Device.NAT.PortMapping.0.
--
-- Enable
-- X_TEAMF1_Action
-- RemoteHost
-- ExternalPort
-- InternalClient
-- InternalPort
--
-- Returns: status, value
]]--
function fwTr.portMapCfgSet(input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering portMapCfgSet..")

    local status = OK
    local row = {}
    local rowId
    local query = nil
    local portMapConfTbl = {}
    local faultTbl = {}
    local index = 0
    local addCustomServiceFlag = 0
    local errorCode = "OK"
    local protoNum = ""
    local serviceRow = {}
    local rmtHostFlag = 0
    local internalClientFlag = 0

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --read the rowId mapping to FirewallRules
    rowId = instanceMap[tr69Param]
    if (rowId == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get corresponding db entry from FirewallRules
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("FirewallRules", query, false)
    if(row == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    portMapConfTbl = row

    --Enable
    if(input["FirewallRules"]["FirewallRules.Status"] ~= nil) then
        portMapConfTbl["Status"] = input["FirewallRules"]["FirewallRules.Status"]
    end

    --Description
    if(input["FirewallRules"]["FirewallRules.Description"] ~= nil) then
        portMapConfTbl["Description"] = input["FirewallRules"]["FirewallRules.Description"]
    end

    --X_TEAMF1_Action
    if(input["FirewallRules"]["FirewallRules.Action"] ~= nil) then
        if(input["FirewallRules"]["FirewallRules.Action"] == "Accept") then
            portMapConfTbl["Action"] = "ACCEPT"
        elseif(input["FirewallRules"]["FirewallRules.Action"] == "Drop") then
            portMapConfTbl["Action"] = "DROP"
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."X_TEAMF1_Action", error_code.INTERNAL_ERROR)
        end
    end

    local startIp, endIp
    -- RemoteHost
    if(input["FirewallRules"]["FirewallRules.rmtHost"] ~= nil) then
        if(input["FirewallRules"]["FirewallRules.rmtHost"] == "ANY") then
            portMapConfTbl["SourceAddressType"] = "0"
        elseif(string.find(input["FirewallRules"]["FirewallRules.rmtHost"], "-")) then 
            startIdx, endIdx = string.find(input["FirewallRules"]["FirewallRules.rmtHost"], "-")
            startIp = string.sub(input["FirewallRules"]["FirewallRules.rmtHost"], 1, endIdx-1)
            endIp = string.sub(input["FirewallRules"]["FirewallRules.rmtHost"], endIdx+1)

            portMapConfTbl["SourceAddressType"] = "2"
            portMapConfTbl["SourceAddressStart"] = startIp
            portMapConfTbl["SourceAddressEnd"] = endIp

            if(tr69Glue.tf1IpRangeValidate(startIp, endIp) ~= 0 or startIp == LOOP_BACK_ADDRESS or endIp == LOOP_BACK_ADDRESS) then
                status = ERROR
                index = index + 1
                rmtHostFlag = 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."RemoteHost", error_code.INVALID_PARAM_VALUE)
            end
        else
            portMapConfTbl["SourceAddressType"] = "1"
            if(tr69Glue.tf1IpAddressValidate(input["FirewallRules"]["FirewallRules.rmtHost"],"","rmtHost","") ~= "OK" or input["FirewallRules"]["FirewallRules.rmtHost"] == LOOP_BACK_ADDRESS) then
                status = ERROR
                index = index + 1
                rmtHostFlag = 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."RemoteHost", error_code.INVALID_PARAM_VALUE)
            else
                portMapConfTbl["SourceAddressStart"] = input["FirewallRules"]["FirewallRules.rmtHost"]
            end
        end
    end    

    -- ExternalPort
    if(input["FirewallRules"]["FirewallRules.extPort"] ~= nil) then 
        if((tonumber(input["FirewallRules"]["FirewallRules.extPort"]) >= NAT_PORT_MIN_VAL) and (tonumber(input["FirewallRules"]["FirewallRules.extPort"]) <= NAT_PORT_MAX_VAL)) then
            serviceRow = fwTr.serviceByPortGet(input["FirewallRules"]["FirewallRules.extPort"])
            if(serviceRow == nil or serviceRow == "") then
                addCustomServiceFlag = 1
            else
                portMapConfTbl["ServiceName"] = serviceRow["ServiceName"]
            end
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."ExternalPort", error_code.INVALID_PARAM_VALUE)
        end
    end

    -- Protocol
    if(input["FirewallRules"]["FirewallRules.Protocol"] ~= nil) then
        protoNum = fwTr.protoNumGet(input["FirewallRules"]["FirewallRules.Protocol"])
        if(protoNum == "0") then
            tr69Glue.tf1Dbg("Invalid Protocol..")
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Protocol", error_code.INVALID_PARAM_VALUE)
        else
            if(input["FirewallRules"]["FirewallRules.extPort"] ~= nil) then
                serviceRow = fwTr.serviceByPortGet(input["FirewallRules"]["FirewallRules.extPort"])
                if(serviceRow == nil or serviceRow == "") then
                    addCustomServiceFlag = 1
                else
                    if (serviceRow["Protocol"] == protoNum) then
                        portMapConfTbl["ServiceName"] = serviceRow["ServiceName"]
                    else
                        tr69Glue.tf1Dbg("No service exists with this dest port and protocol..")
                        status = ERROR
                        index = index + 1
                        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Protocol", error_code.REQUEST_DENIED)
                    end
                end
            elseif(input["FirewallRules"]["FirewallRules.extPort"] == nil) then
                tr69Glue.tf1Dbg("cannot change the protocol as this service is used by port forwarding rule..")
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Protocol", error_code.REQUEST_DENIED)
            end
        end
    end

    -- InternalClient
    if(input["FirewallRules"]["FirewallRules.DNATAddress"] ~= nil) then
       if(tr69Glue.tf1IpAddressValidate(input["FirewallRules"]["FirewallRules.DNATAddress"],"","DNATAddr","") ~= "OK" or input["FirewallRules"]["FirewallRules.DNATAddress"] == LOOP_BACK_ADDRESS) then
            status = ERROR
            index = index + 1
            internalClientFlag = 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."InternalClient", error_code.INVALID_PARAM_VALUE)
        else
            portMapConfTbl["DNATAddress"] = input["FirewallRules"]["FirewallRules.DNATAddress"]
        end
    end

    -- InternalPort
    if(input["FirewallRules"]["FirewallRules.DNATPort"] ~= nil) then
        if((tonumber(input["FirewallRules"]["FirewallRules.DNATPort"]) >= NAT_PORT_MIN_VAL) and (tonumber(input["FirewallRules"]["FirewallRules.DNATPort"]) <= NAT_PORT_MAX_VAL)) then
            portMapConfTbl["DNATPort"] = input["FirewallRules"]["FirewallRules.DNATPort"]
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."InternalPort", error_code.INVALID_PARAM_VALUE)
        end
    end

    if(portMapConfTbl["SourceAddressType"] == "1" and portMapConfTbl["SourceAddressStart"] == portMapConfTbl["DNATAddress"]) then
        if(input["FirewallRules"]["FirewallRules.rmtHost"] ~= nil and rmtHostFlag == 0) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."RemoteHost", error_code.REQUEST_DENIED)
        end
        if(input["FirewallRules"]["FirewallRules.DNATAddress"] ~= nil and internalClientFlag == 0) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."InternalClient", error_code.REQUEST_DENIED)
        end
    end

    if(status ~= OK) then
        return status, faultTbl;
    end

    -- apply rule settings

    -- if external port is custom port, add a row in service tbl and update the
    -- firewall rules
    if(addCustomServiceFlag == 1) then
        query = "ServiceName='" ..row["ServiceName"].. "'"
        servicesRow = db.getRowWhere("Services", query, false)

        --form custom servicename
        local servicesTbl = db.getTable ("Services", false)
        local maxRowId = db.getMaxVal ("Services", "_ROWID_")
        if(maxRowId == nil or maxRowId == "") then
            maxRowId = 0
        end

        maxRowId = tonumber(maxRowId)

        cnt = maxRowId+1
        serName = "customService"..cnt
        for k,v in pairs (servicesTbl) do
            if(v["ServiceName"] == serName) then
                cnt = cnt + 1
                serName = "customService"..cnt
            end
        end

        CustomSvcAddTbl = {}
        CustomSvcAddTbl["PortType"] = "1"
        if(protoNum ~= nil and protoNum ~= "") then
            CustomSvcAddTbl["Protocol"] = protoNum
        else
            CustomSvcAddTbl["Protocol"] = servicesRow["Protocol"]
        end
        CustomSvcAddTbl["DestinationPortStart"] = input["FirewallRules"]["FirewallRules.extPort"]
        CustomSvcAddTbl["ServiceName"] = serName
        CustomSvcAddTbl["DestinationPortEnd"] = input["FirewallRules"]["FirewallRules.extPort"]
        
        errorCode, errMsg = firewall.fwCustomSvcAddSet (CustomSvcAddTbl)
        
        portMapConfTbl["ServiceName"] = CustomSvcAddTbl["ServiceName"]
    end
        
    if(errorCode == "OK") then
        errorCode, errMsg = firewall.portFwdRulesEditSet(portMapConfTbl)
    else
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
    end

    db.save()

    tr69Glue.tf1Dbg("Leaving portMapCfgSet..")
    return status, faultTbl;
end

--[[
--*****************************************************************************
-- fwTr.portMappingAdd - Add port forwarding rule configuration
-- 
-- This function is called to set the following parameters
-- Device.NAT.PortMapping.0.
--
-- Enable
-- RemoteHost
-- ExternalPort
-- InternalClient
-- InternalPort
--
-- Returns: status
]]--
function fwTr.portMappingAdd(input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering portMappingAdd..")

    local status = "0"
    local errorFlag
    local row = {}
    local query = nil

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = "1"
        return "1";
    end

    -- Filling the parameters of FirewallRules when Add Object for FirewallRules is called
    rows = db.getTable ("FirewallRules", false)
    tr69Glue.tf1Dbg("Number of Rows Present .." ..#rows)
    input["ServiceName"] = "HTTP" 
    input["Action"] = "ACCEPT"
    input["SourceAddressType"] = "0"
    input["DNATAddress"] = "192.168.29.2"
    input["DestinationAddressType"] = "0"
    input["DNATPort"] = "80"
    
    require "teamf1lualib/gui"
    require "teamf1lualib/security"
    status, errorFlag = gui.security.portFwd.add.set (input, "-1", "add")

    if (status ~= "OK") then
        tr69Glue.tf1Dbg("errorFlag : " .. errorFlag)
        return error_code.REQUEST_DENIED;
    end
    tr69Glue.tf1Dbg("Leaving portMappingAdd..")
    return 0;
end

--[[
--*****************************************************************************
-- fwTr.portMappingCfgAdd - Add port forwarding rule configuration
-- 
-- This function is called to set the following parameters
-- Device.NAT.PortMapping.0.
--
-- Enable
-- RemoteHost
-- ExternalPort
-- InternalClient
-- InternalPort
--
-- Returns: status
]]--
function fwTr.portMappingCfgAdd(input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering portMappingCfgAdd..")

    local status = "0"
    local errorFlag
    local row = {}
    local query = nil

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = "1"
        return "1";
    end

    -- Filling the parameters of FirewallRules when Add Object for FirewallRules is called
    rows = db.getTable ("FirewallRules", false)
    tr69Glue.tf1Dbg("Number of Rows Present .." ..#rows)
    input["ServiceName"] = "ANY" 
    input["Action"] = "ACCEPT"
    input["Status"] = "0"
    input["DNATAddress"] = "192.168.1.2"
    input["Protocol"] = "256"
    input["DestinationPortStart"] = "0"
    input["DestinationPortEnd"] = "0"
    
    require "teamf1lualib/gui"
    require "teamf1lualib/security"
    status, errorFlag = gui.security.portFwd.add.set (input, "-1", "add")

    if (status ~= "OK") then
        tr69Glue.tf1Dbg("errorFlag : " .. errorFlag)
        return error_code.REQUEST_DENIED;
    end
    tr69Glue.tf1Dbg("Leaving portMappingCfgAdd..")
    return 0;
end

--[[
--*****************************************************************************
-- fwTr.portMappingCfgSet- set firewall rule configuration
-- 
-- This function is called to set the following parameters
-- Device.NAT.PortMapping.0.
--
-- Enable
-- X_TEAMF1_Action
-- RemoteHost
-- ExternalPort
-- InternalClient
-- InternalPort
--
-- Returns: status, value
]]--
function fwTr.portMappingCfgSet(input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering portMappingCfgSet..")

    local status = "0"
    local row = {}
    local rowId
    local query = nil
    local portMapConfTbl = {}
    local faultTbl = {}
    local index = 0

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(tr69Param, "PortMapping.")
    parentObjInstance = string.sub(tr69Param, 1, endIdx+2)

    --read the rowId mapping to FirewallRules
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get corresponding db entry from FirewallRules
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("FirewallRules", query, false)
    if(row == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    portMapConfTbl = row
    --Enable
    if(input["FirewallRules"]["FirewallRules.Status"] ~= nil) then
        portMapConfTbl["Status"] = input["FirewallRules"]["FirewallRules.Status"]
    end

    -- Backend is not present for Set operation of Interface, LeaseDuration and Description parameters.
    if(input["FirewallRules"]["FirewallRules.Interface"] ~= nil or input["FirewallRules"]["FirewallRules.LeaseDuration"] ~= nil or input["FirewallRules"]["FirewallRules.Description"] ~= nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.REQUEST_DENIED)
        return status, faultTbl;
    end

    -- ExternalPort
    if(input["FirewallRules"]["FirewallRules.extPort"] ~= nil) then

        local extPort = input["FirewallRules"]["FirewallRules.extPort"]
        if((tonumber (extPort) < 1) or (tonumber (extPort) > 65535) or (tonumber (portMapConfTbl["DestinationPortEnd"]) < tonumber (extPort))) then
            -- DestinationPortEnd MUST be greater than or equal to the value of DestinationPortStart.
           status = ERROR
           index = index + 1
           faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."ExternalPort", error_code.INVALID_PARAM_VALUE)
        else  
           portMapConfTbl["DestinationPortStart"] = input["FirewallRules"]["FirewallRules.extPort"]
        end
    end

    -- Protocol
    if (input["FirewallRules"]["FirewallRules.Protocol"] ~= nil) then
        if(input["FirewallRules"]["FirewallRules.Protocol"] == "TCP") then
           portMapConfTbl["Protocol"] = "6"
        elseif(input["FirewallRules"]["FirewallRules.Protocol"] == "UDP") then
           portMapConfTbl["Protocol"] = "17"
        elseif(input["FirewallRules"]["FirewallRules.Protocol"] == "BOTH") then
           portMapConfTbl["Protocol"] = "256"
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Protocol", error_code.INVALID_PARAM_VALUE)
        end
    end

    -- InternalClient
    if(input["FirewallRules"]["FirewallRules.DNATAddress"] ~= nil) then
        -- validations for InternalClient
        local dnatAddress = input["FirewallRules"]["FirewallRules.DNATAddress"] 
        local octetTable = validations.split(dnatAddress,".")
	local flag , errMsg = validations.ipAddressValidate(dnatAddress,"")

        if (flag ~= 0 and flag ~= "OK") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."InternalClient", error_code.INVALID_PARAM_VALUE)
        end
        if (flag == "OK" and ((dnatAddress == "127.0.0.1") or 
                             (tonumber(octetTable[4]) == 0))) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."InternalClient", error_code.INVALID_PARAM_VALUE)
        else
            portMapConfTbl["DNATAddress"] = input["FirewallRules"]["FirewallRules.DNATAddress"]
        end
    end

    --apply rule settings
    if (status == OK) then
       local ret, errorCode
       ret, errorCode = firewall.portFwdRulesEditSet(portMapConfTbl)
       db.save()
    end

    tr69Glue.tf1Dbg("Leaving portMappingCfgSet..")
    return status, faultTbl;
end

--[[
--*****************************************************************************
-- fwTr.algCfgGet- get alg status
-- 
-- This function is called to get the following parameters
-- Device.X_TEAMF1.ALG.FtpStatus
-- Device.X_TEAMF1.ALG.H323Status
-- Device.X_TEAMF1.ALG.RtspStatus
-- Device.X_TEAMF1.ALG.SipStatus
-- Device.X_TEAMF1.ALG.TftpStatus
-- Device.X_TEAMF1.ALG.UPnP
--
-- Returns: status, value
]]--
function fwTr.algCfgGet(input)
    local status = "0"
    local value  = "0"
    local i,v

    --get corresponding db entry from either 'AlgConf' or 'SipStatusCtrl'
    query = "_ROWID_=1"
    
    row = db.getRowWhere ("AlgConf", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    
    if (string.find(input["param"], "FtpStatus")) then    
        value = row["FtpStatus"]
    elseif (string.find(input["param"], "H323Status") or string.find(input["param"], "H323_ALG")) then
        value = row["H323Status"]
    elseif (string.find(input["param"], "RtspStatus") or string.find(input["param"], "RTSP_ALG")) then
        value = row["RtspStatus"]
    elseif (string.find(input["param"], "SipStatus") or string.find(input["param"], "SIP_ALG")) then
        row = db.getRowWhere ("SipStatusCtrl", query, false)
        value = row["SipStatus"]
    elseif (string.find(input["param"], "TFTP_ALG")) then
        value = row["TftpStatus"]
    elseif (string.find(input["param"], "UPnP")) then
        row = db.getRowWhere ("upnp", query, false)
        value = row["upnpEnable"]
    end
    
    -- returning with status and value
    return status,value
end

--[[
--*****************************************************************************
-- fwTr.algCfgSet- set alg status
-- 
-- This function is called to set the following parameters
-- Device.X_TEAMF1.ALG.FtpStatus
-- Device.X_TEAMF1.ALG.H323Status
-- Device.X_TEAMF1.ALG.RtspStatus
-- Device.X_TEAMF1.ALG.TftpStatus
--
-- Returns: status, value
]]--
function fwTr.algCfgSet(input, rowids, actionType, tr69Param)
    local status = "0"
    local value  = "0"
    local i,v
    local inRow  = {}
    local row    = {}
    local rowId  = "1"
    local param  = ""
    local tmp
   
    -- get corresponding db entry from 'AlgConf'
    query = "_ROWID_='" .. rowId .. "'"
    row = db.getRowWhere ("AlgConf",query,false)

    if (row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    if (input["AlgConf"]["AlgConf.FtpStatus"] ~= nil) then    
        row["FtpStatus"] = input["AlgConf"]["AlgConf.FtpStatus"]
    end
    if (input["AlgConf"]["AlgConf.H323Status"] ~= nil) then
        row["H323Status"] = input["AlgConf"]["AlgConf.H323Status"]
    end
    if (input["AlgConf"]["AlgConf.RtspStatus"] ~= nil) then
        row["RtspStatus"] = input["AlgConf"]["AlgConf.RtspStatus"]
    end
    if (input["AlgConf"]["AlgConf.TftpStatus"] ~= nil) then
        row["TftpStatus"] = input["AlgConf"]["AlgConf.TftpStatus"]
    end
    
    row = util.addPrefix (row,"AlgConf.")
    local valid, errstr = db.update("AlgConf",row, "1")
    if (not valid) then
        status = "1"
        return "1";
    end
    
    -- saving DB
    db.save()

    return status,value 
end

--[[
--*****************************************************************************
-- fwTr.algCfgSipSet- set sip alg status
-- 
-- This function is called to set the following parameter
-- Device.X_TEAMF1.ALG.SipStatus
--
-- Returns: status, value
]]--
function fwTr.algCfgSipSet(input, rowids, actionType, tr69Param)
    local status = "0"
    local value  = "0"
    local i,v
    local inRow  = {}
    local row    = {}
    local rowId  = "1"
    local param  = ""
    local tmp
   
    -- get corresponding db entry from 'SipStatusCtrl'
    query = "_ROWID_='" .. rowId .. "'"
    row = db.getRowWhere ("SipStatusCtrl",query,false)

    if (row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    if (input["AlgConf"]["AlgConf.SipStatus"] ~= nil) then
        row["SipStatus"] = input["AlgConf"]["AlgConf.SipStatus"]
    end
    
    row = util.addPrefix (row,"SipStatusCtrl.")
    local valid, errstr = db.update("SipStatusCtrl",row, "1")
    if (not valid) then
        status = "1"
        return "1";
    end

    -- saving DB
    db.save()

    return status,value 
end

--[[
--*****************************************************************************
-- fwTr.algCfgUpnpSet- set upnp status
-- 
-- This function is called to set the following parameter
-- Device.X_RJIL_COM_ALG_Control.UPnP
--
-- Returns: status, value
]]--
function fwTr.algCfgUpnpSet(input, rowids, actionType, tr69Param)
    local status = "0"
    local value  = "0"
    local i,v
    local inRow  = {}
    local row    = {}
    local rowId  = "1"
    local param  = ""
    local tmp
   
    -- get corresponding db entry from 'upnp'
    query = "_ROWID_='" .. rowId .. "'"
    row = db.getRowWhere ("upnp",query,false)

    if (row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    if (input["AlgConf"]["AlgConf.upnpStatus"] ~= nil) then
        row["upnpEnable"] = input["AlgConf"]["AlgConf.upnpStatus"]
    end
    
    row = util.addPrefix (row,"upnp.")
    local valid, errstr = db.update("upnp",row, "1")
    if (not valid) then
        status = "1"
        return "1";
    end
 
    -- saving DB
    db.save()

    return status,value 
end

--[[
--*****************************************************************************
-- fwTr.interfaceSettingCfgGet- get nat setting
-- 
-- This function is called to get the following parameters
-- Device.NAT.InterfaceSetting.0.Enable
-- Device.NAT.InterfaceSetting.0.Status
-- Device.NAT.InterfaceSetting.0.Interface
--
-- Returns: status, value
]]--
function fwTr.interfaceSettingCfgGet(input)
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local row = {}
    local query = nil
    local param = input["param"]

    --get corresponding db entry from 'routingMode'
    query = "_ROWID_=1"
    row = db.getRowWhere ("routingMode", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        if (row["natSetting"] == "2") then
            value = 0
        else
            value = 1
        end
    elseif(string.find(input["param"], "Status")) then
        -- DefaultPolicy
        if(row["natSetting"] == "2") then
            value = "Disabled"
        elseif(row["natSetting"] == "1") then
            value = "Enabled"
        else
            return "1", "DB_ERROR_TRY_AGAIN"
        end
    elseif(string.find(input["param"], "Interface")) then
        -- Interface
        -- find the corresponding interface entry from instanceMap using LogicalIfName
        local logicalIfName = "IF1"
        local wanIfaceObj = ""
        wanIfaceObj = nimfTr.getIfaceObjFromIfname(logicalIfName)
        value = wanIfaceObj
        if(value == nil or value == "") then
            return "1", "DB_ERROR_TRY_AGAIN"
        end
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- fwTr.interfaceSettingCfgSet- set nat interface setting object
-- 
-- This function is called to set the following parameters
-- Device.NAT.InterfaceSetting.0.Enable
-- Device.NAT.InterfaceSetting.0.Status
-- Device.NAT.InterfaceSetting.0.Interface
--
-- Returns: status
]]--
function fwTr.interfaceSettingCfgSet(input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering interfaceSettingCfgSet..")

    local status = "0"
    local row = {}
    local inRow = {}
    local rowId
    local query = nil
    local faultTbl = {}
    local index = 0
    
    inRow = input["routingMode"]

    --get corresponding db entry from 'routingMode'
    query = "_ROWID_=1"
    row = db.getRowWhere ("routingMode", query, false)
    if(row == nil) then
        tr69Glue.tf1Dbg("Couldn't fetch corresponding routingMode row..")
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Enable", error_code.INVALID_PARAM_VALUE)
        return status, faultTbl;
    end

    if(inRow["routingMode.natSetting"] ~= "" or inRow["routingMode.natSetting"] ~= nil ) then
        if (inRow["routingMode.natSetting"] == "0") then
            row["natSetting"] = 2
        else
            row["natSetting"] = 1
        end
    else
        tr69Glue.tf1Dbg("Invalid nat setting ..")
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Enable", error_code.INVALID_PARAM_VALUE)
        return status, faultTbl;
    end

    tr69Glue.tf1Dbg("Calling routingModeConfigSet..")
    firewall.routingModeConfigSet(row)

    tr69Glue.tf1Dbg("Leaving interfaceSettingCfgSet..")
    return 0;
end

--[[
--*****************************************************************************
-- fwTr.protoNumGet - fetch the protocol number using protocol Name 
-- 
-- This function fetches the protocol number using protocol name
--
-- Returns: protocol Number
]]--
function fwTr.protoNumGet(protoName)
    local protoNum = "0"

    if (protoName == "TCP") then
        protoNum = "6"
    elseif (protoName == "UDP") then
        protoNum = "17"
    end

    return protoNum;
end

--[[
--*****************************************************************************
-- fwTr.macFilterCfgGet- get macFilter configuration
-- 
-- This function is called to get the following parameters
-- Device.X_RJIL_MacFiltering.Enable
-- Device.X_RJIL_MacFiltering.Mode
--
-- Returns: status, value
]]--
function fwTr.macFilterCfgGet(input)
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local row = {}
    local query = nil
    local param = input["param"]

    --get corresponding db entry from 'macFilterConfig'
    query = "_ROWID_=1"
    row = db.getRowWhere ("macFilterConfig", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = row["MACFilteringStatus"]
    elseif(string.find(input["param"], "Mode")) then
        -- Mode
        if(row["MACFilteringPolicy"] == "1") then
            value = "0"
        else
            value = "1"
        end
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- fwTr.macFilterCfgSet- set macFilter configuration
-- 
-- This function is called to set the following parameters
-- Device.X_RJIL_MacFiltering.Enable
-- Device.X_RJIL_MacFiltering.Mode
--
-- Returns: status
]]--
function fwTr.macFilterCfgSet(input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering macFilterCfgSet..")

    local status = "0"
    local row = {}
    local rowId
    local query = nil
    local macFilterConfigRow = {}
    local status, errMsg

    --get corresponding db entry from 'macFilterConfig'
    query = "_ROWID_=1"
    row = db.getRowWhere ("macFilterConfig", query, false)
    if(row == nil) then
        tr69Glue.tf1Dbg("Couldn't fetch corresponding macFilterConfig row..")
        status = "1"
        return "1";
    end

    macFilterConfigRow = row
    --configure MACFilteringStatus
    if(input["macFilterConfig"]["macFilterConfig.MACFilteringStatus"] ~= nil) then
        macFilterConfigRow["MACFilteringStatus"] = input["macFilterConfig"]["macFilterConfig.MACFilteringStatus"]
    end

    --configure MACFilteringStatus
    if(input["macFilterConfig"]["macFilterConfig.MACFilteringPolicy"] ~= nil) then
        if(input["macFilterConfig"]["macFilterConfig.MACFilteringPolicy"] == "1") then
            macFilterConfigRow["MACFilteringPolicy"] = "2"
        elseif(input["macFilterConfig"]["macFilterConfig.MACFilteringPolicy"] == "0") then
            macFilterConfigRow["MACFilteringPolicy"] = "1"
        end
    end

    --setting the new configuration in the table
    status, errMsg = firewall.macFilterConfigSet(macFilterConfigRow)

    if (status == "OK") then
        db.save()
        os.execute(fwRulesCmd)
    end

    tr69Glue.tf1Dbg("Leaving macFilterCfgSet..")
    return 0;
end

--[[
--*****************************************************************************
-- fwTr.macFilterRulesAdd - add MAC filtering Rule parameters
-- 
-- This function is called to set the following parameters in
-- Device.X_RJIL_MacFiltering.MacFiltering.0.
--
-- MacAddress
-- Description
--
-- Returns: status
]]--
function fwTr.macFilterRulesAdd(input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering macFilterRulesAdd..")

    local status = "0"
    local errorFlag
    local row = {}
    local rowId
    local query = nil
    local portMapConfTbl = {}

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = "1"
        return "1";
    end

    --get db entry from 'macFilterConfig'
    query = "_ROWID_=1"
    row = db.getRowWhere ("macFilterConfig", query, false)
    if(row["MACFilteringStatus"] == "0") then
        tr69Glue.tf1Dbg("Enable Source MAC Address Filtering to apply MAC Filtering Rules.")
        return 0;
    end
    
    -- Filling the parameters of macFilterRules when Add Object for macFilterRules is called
    rows = db.getTable ("macFilterRules", false)
    tr69Glue.tf1Dbg("Number of Rows Present .." ..#rows)
    input["sourceMacAddr"] = "00:00:00:00:00:01" 
    input["decription"] = "MAC"

    -- Instead of calling fwMacRulesConfig function which already exists
    -- we are calling tr69fwMacRulesConfig function because in those
    -- functions db.commitTransaction,db.BeginTransaction and db.RollOver
    -- have been called.
    -- As tr69Client internally will take care of these calls, so duplicated 
    -- these calls seperately for tr069

    -- Adding rows in the firewall
    require "teamf1lualib/firewall"
    status, errorFlag = firewall.tr69fwMacRulesConfig (input, "-1", "add")

    if (status == "OK") then
        db.save ()
    end
    tr69Glue.tf1Dbg("Leaving macFilterRulesAdd..")
    return 0;
end

--[[
--*****************************************************************************
-- fwTr.macFilterRulesGet- get macFilter rules configuration
-- 
-- This function is called to get the following parameters in
-- Device.X_RJIL_MacFiltering.MacFiltering.0.
--
-- MacAddress
-- Description
--
-- Returns: status, value
]]--
function fwTr.macFilterRulesGet(input)
    local status = "0"
    local value = "0"
    local rowId
    local row = {}
    local serviceEntry = {}
    local query = nil
    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    -- read the rowId mapping to clientMacConfig
    rowId = instanceMap[param]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from clientMacConfig
    row = firewall.clientMacConfigEditGet(rowId)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    for k,v in pairs(input) do
        value = v == input["field"] and row[v] or "DB_ERROR_TRY_AGAIN"
        return status, value
    end

    return status, value
end

--[[
--*****************************************************************************
-- fwTr.macFilterRulesSet- set macFilter rules configuration
-- 
-- This function is called to set the following parameters in
-- Device.X_RJIL_MacFiltering.MacFiltering.0.
--
-- MacAddress
-- Description
--
-- Returns: status, value
]]--
function fwTr.macFilterRulesSet(input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering macFilterRulesSet..")

    local status = "0"
    local row = {}
    local rowId
    local query = nil
    local macFilterRulesTbl = {}

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = "1"
        return "1";
    end

    --read the rowId mapping to clientMacConfig
    rowId = instanceMap[tr69Param]
    if (rowId == nil) then
        status = "1"
        return "1";
    end

    --get db entry from 'macFilterConfig'
    query = "_ROWID_=1"
    row = db.getRowWhere ("macFilterConfig", query, false)
    if(row["MACFilteringStatus"] == "0") then
        tr69Glue.tf1Dbg("Enable Source MAC Address Filtering to apply MAC Filtering Rules.")
        status = "1"
        return "1";
    end

    --get corresponding db entry from clientMacConfig
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("clientMacConfig", query, false)
    if(row == nil) then
        status = "1"
        return "1";
    end

    macFilterRulesTbl = row

    -- Description
    if(input["clientMacConfig"]["clientMacConfig.decription"] ~= nil) then 
        macFilterRulesTbl["decription"] = input["clientMacConfig"]["clientMacConfig.decription"]
    end

    -- Enable
    if(input["clientMacConfig"]["clientMacConfig.MACFilteringPolicy"] ~= nil) then 
        macFilterRulesTbl["MACFilteringPolicy"] = input["clientMacConfig"]["clientMacConfig.MACFilteringPolicy"]
    end

    -- Alias
    if(input["clientMacConfig"]["clientMacConfig.alias"] ~= nil) then 
        macFilterRulesTbl["alias"] = input["clientMacConfig"]["clientMacConfig.alias"]
    end

    macFilterRulesTbl = util.addPrefix (macFilterRulesTbl,"clientMacConfig.")
    local valid, errstr = db.update("clientMacConfig", macFilterRulesTbl, macFilterRulesTbl["clientMacConfig._ROWID_"])
    if (not valid) then
        status = "1"
        return "1";
    end

    db.save()
    tr69Glue.tf1Dbg("Leaving macFilterRulesSet..")
    return 0;
end

--[[
--*****************************************************************************
-- fwTr.EogreCfgGet- get EoGRE configuration
-- 
-- This function is called to get the parameters for
-- Device.GRE. object
--
-- Returns: status, value
]]--
function fwTr.EogreCfgGet(input)
    local status = "0"
    local value = "0"
    local rowId
    local row = {}
    local serviceEntry = {}
    local query = "_ROWID_=1"
    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --read the rowId mapping to Eogre
    rowId = instanceMap[param]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    -- get corresponding db entry from Eogre
    row = firewall.eogreGet(query)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    local t = {
    Enable = function() return row["Enable"] or row["secEnable"] end,
    Status = function() return ((row["Enable"] or row["secEnable"]) == "1") and "Enabled" or "Disabled" end,
    ipType = function() return row["ipType"] == "0" and "IPv4" or "IPv6" end,
    RemoteIP = function()
                   if(tonumber(row["ipType"]) == 1)then
                       if(row["ModeOfOperation"] == "1" and row["EnableOffloadFallBack"] == "1") then
                           if(row["RemoteIP6"] ~= nil and row["secRemoteIP6"] ~= nil) then 
                               return row["RemoteIP6"]..","..row["secRemoteIP6"]
                           end
                       elseif((row["ModeOfOperation"] == "1" and row["EnableOffloadFallBack"] == "0") or row["ModeOfOperation"] == "2") then
                           return row["RemoteIP6"] 
                       end
                   else
                       if(row["ModeOfOperation"] == "1" and row["EnableOffloadFallBack"] == "1") then
                           if(row["RemoteIP"] ~= nil and row["secRemoteIP"] ~= nil) then 
                               return row["RemoteIP"]..","..row["secRemoteIP"]
                           end
                       elseif((row["ModeOfOperation"] == "1" and row["EnableOffloadFallBack"] == "0") or row["ModeOfOperation"] == "2") then
                           return row["RemoteIP"] 
                       end
                   end
               end,
    dataRate = row["dataRate"],
    ModeOfOperation = function() return row["ModeOfOperation"] == "1" and "Bridge Mode" or "Wlan Gateway" end,
    Name = "gre2",
    LowerLayers = function() return (row["Enable"] or row["Enable"]) and "Device.Ethernet.Interface.1." or "" end, 
    TunnelKey = row["TunnelKey"],
    Interface = "Device.GRE.Tunnel.1.Interface.1.",
    AllInterfaces = "0",
    vlanId = function() return (row["vlanId"] == "0") and "" or row["vlanId"] end,
    VLANIDExclude = "0",
    EnableOffloadFallBack = function() return row["EnableOffloadFallBack"] end,
    FallBackTime = function() return row["FallBackTime"] end

    }

    for k,v in pairs(input) do
        if(v == input["field"]) then
            value = type(t[v]) == "function" and t[v]() or t[v] or "DB_ERROR_TRY_AGAIN"
            return status, value
        end
    end

    return status, value
end

--[[
--*****************************************************************************
-- fwTr.EogreCfgSet- set firewall rule configuration
-- 
-- This function is called to set the parameters of Device.GRE. object
--
-- Returns: status, value
]]--
function fwTr.EogreCfgSet(input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering EogreCfgSet..")

    local status = "0"
    local row = {}
    local rowId
    local query = nil
    local eogreConfTbl = {}
    local faultTbl = {}
    local index = 0

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR) 
        return status, faultTbl;
    end

    --read the rowId mapping to Eogre
    rowId = instanceMap[tr69Param]
    if (rowId == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR) 
        return status, faultTbl;
    end

    --get corresponding db entry from Eogre
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("Eogre", query, false)
    if(row == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR) 
        return status, faultTbl;
    end

    eogreConfTbl = row

    -- Enable
    if(input["Eogre"]["Eogre.Enable"] ~= nil) then
        eogreConfTbl["Enable"] = input["Eogre"]["Eogre.Enable"]
    elseif(eogreConfTbl["secEnable"] == "1")then
        eogreConfTbl["Enable"] = "1"
    end

    if(eogreConfTbl["Enable"] == "1") then
        -- DeliveryHeaderProtocol
        if(input["Eogre"]["Eogre.ipType"] ~= nil) then
            if(input["Eogre"]["Eogre.ipType"] == "IPv4") then
                eogreConfTbl["ipType"] = "0"
            elseif(input["Eogre"]["Eogre.ipType"] == "IPv6") then
                eogreConfTbl["ipType"] = "1"
            else
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."DeliveryHeaderProtocol", error_code.INVALID_PARAM_VALUE) 
            end
        end
        -- X_RJIL_COM_ModeOfOperation
        if(input["Eogre"]["Eogre.ModeOfOperation"] ~= nil) then
            if(input["Eogre"]["Eogre.ModeOfOperation"] == "Bridge Mode") then
                eogreConfTbl["ModeOfOperation"] = "1"
            elseif(input["Eogre"]["Eogre.ModeOfOperation"] == "Wlan Gateway") then
                eogreConfTbl["ModeOfOperation"] = "2"
            else
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."X_RJIL_COM_ModeOfOperation", error_code.INVALID_PARAM_VALUE) 
            end
        end

        -- X_RJIL_COM_EnableOffloadFallback
        if (input["Eogre"]["Eogre.EnableOffloadFallBack"] ~= nil) then
            eogreConfTbl["EnableOffloadFallBack"] = input["Eogre"]["Eogre.EnableOffloadFallBack"]
        end

        -- X_RJIL_COM_FallBackTime
        if (input["Eogre"]["Eogre.FallBackTime"] ~= nil) then
            eogreConfTbl["FallBackTime"] = input["Eogre"]["Eogre.FallBackTime"]
        end

        -- RemoteEndpoints
        if(input["Eogre"]["Eogre.RemoteIP"] ~= nil) then
            local remoteIPs = input["Eogre"]["Eogre.RemoteIP"]
            if(eogreConfTbl["ipType"] == "0")then
                if(eogreConfTbl["ModeOfOperation"] == "1" and eogreConfTbl["EnableOffloadFallBack"] == "1") then
                    if(string.find(remoteIPs, ",")) then
                        remoteIpTbl = util.split(remoteIPs, ",")
                        eogreConfTbl["RemoteIP"] = remoteIpTbl[1]
                        eogreConfTbl["secRemoteIP"] = remoteIpTbl[2]

                        if((tr69Glue.tf1IpAddressValidate(eogreConfTbl["RemoteIP"],"","RemoteIP","") ~= "OK") or (tr69Glue.tf1IpAddressValidate(eogreConfTbl["secRemoteIP"],"","RemoteIP","") ~= "OK")) then
                            status = ERROR
                            index = index + 1
                            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."RemoteEndPoints", error_code.INVALID_PARAM_VALUE) 
                        end
                    else
                        status = ERROR
                        index = index + 1
                        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."RemoteEndPoints", error_code.INVALID_PARAM_VALUE)
                    end
                elseif((eogreConfTbl["ModeOfOperation"] == "1" and eogreConfTbl["EnableOffloadFallBack"] == "0") or eogreConfTbl["ModeOfOperation"] == "2") then
                    if(string.find(remoteIPs, ",")) then
                        status = ERROR
                        index = index + 1
                        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."RemoteEndPoints", error_code.INVALID_PARAM_VALUE)
                    else
                        eogreConfTbl["RemoteIP"] = input["Eogre"]["Eogre.RemoteIP"]
                        if(tr69Glue.tf1IpAddressValidate(eogreConfTbl["RemoteIP"],"","RemoteIP","") ~= "OK") then
                            status = ERROR
                            index = index + 1
                            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."RemoteEndPoints", error_code.INVALID_PARAM_VALUE) 
                        end
                    end
                end
            else
                if(eogreConfTbl["ModeOfOperation"] == "1" and eogreConfTbl["EnableOffloadFallBack"] == "1") then
                    if(string.find(remoteIPs, ",")) then
                        remoteIpTbl = util.split(remoteIPs, ",")
                        eogreConfTbl["RemoteIP6"] = remoteIpTbl[1]
                        eogreConfTbl["secRemoteIP6"] = remoteIpTbl[2]
                        if(tr69Glue.tf1ValidateIpv6Address(eogreConfTbl["RemoteIP6"]) == 1 or tr69Glue.tf1ValidateIpv6Address(eogreConfTbl["secRemoteIP6"]) == 1 ) then
                            status = ERROR
                            index = index + 1
                            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."RemoteEndPoints", error_code.INVALID_PARAM_VALUE)
                        end
                    else
                        status = ERROR
                        index = index + 1
                        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."RemoteEndPoints", error_code.INVALID_PARAM_VALUE)
                    end
                elseif((eogreConfTbl["ModeOfOperation"] == "1" and eogreConfTbl["EnableOffloadFallBack"] == "0") or eogreConfTbl["ModeOfOperation"] == "2") then
                    if(string.find(remoteIPs, ",")) then
                        status = ERROR
                        index = index + 1
                        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."RemoteEndPoints", error_code.INVALID_PARAM_VALUE)
                    else
                        eogreConfTbl["RemoteIP6"] = input["Eogre"]["Eogre.RemoteIP"]
                        if(tr69Glue.tf1ValidateIpv6Address(eogreConfTbl["RemoteIP6"]) == 1) then
                            status = ERROR
                            index = index + 1
                            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."RemoteEndPoints", error_code.INVALID_PARAM_VALUE) 
                        end
                    end
                end
            end
        end

        -- KeyIdentifier
        if(input["Eogre"]["Eogre.TunnelKey"] ~= nil) then
            if((input["Eogre"]["Eogre.TunnelKey"] == "") or ((tonumber(input["Eogre"]["Eogre.TunnelKey"])) and (string.len(input["Eogre"]["Eogre.TunnelKey"]) <= 8))) then
                eogreConfTbl["TunnelKey"] = input["Eogre"]["Eogre.TunnelKey"]
            else
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."KeyIdentifier", error_code.INVALID_PARAM_VALUE) 
            end
        end

        -- VLANIDCheck
        if(input["Eogre"]["Eogre.vlanId"] ~= nil) then
            if((tonumber(input["Eogre"]["Eogre.vlanId"]) > VLANID_MIN_VAL) and (tonumber(input["Eogre"]["Eogre.vlanId"]) < VLANID_MAX_VAL)) then
                eogreConfTbl["vlanId"] = input["Eogre"]["Eogre.vlanId"]
            else
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."VLANIDCheck", error_code.INVALID_PARAM_VALUE) 
            end 
        end

        -- X_RJIL_COM_DataRate
        if(input["Eogre"]["Eogre.dataRate"] ~= nil) then
            if((tonumber(input["Eogre"]["Eogre.dataRate"]) >= DATARATE_MIN_VAL) and (tonumber(input["Eogre"]["Eogre.dataRate"]) <= DATARATE_MAX_VAL)) then
                eogreConfTbl["dataRate"] = input["Eogre"]["Eogre.dataRate"]
            else
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."X_RJIL_COM_DataRate", error_code.INVALID_PARAM_VALUE) 
            end 
        end
    end

    if(status ~= OK) then
       return status, faultTbl
    end

    --apply rule settings
    require "teamf1lualib/gui"
       
    local ret, errorCode
    ret, errorCode = gui.networking.network.eogre.set(eogreConfTbl, dbFlag)
    if(ret ~= "OK") then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR) 
        return status, faultTbl;
    end

    tr69Glue.tf1Dbg("Leaving EogreCfgSet..")
    return status, faultTbl;
end
--[[
--*****************************************************************************
-- fwTr.thirdPartyCfgSet- set thirdparty configuration
-- 
-- This function is called to set the parameters of Device.SoftwareModules. object
--
-- Returns: status, value
]]--
function fwTr.thirdPartyCfgSet(input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering thirdPartyCfgSet..")

    local status = "0"
    local row = {}
    local rowId
    local query = nil
    local thirdpartyConfTbl = {}
    local faultTbl = {}
    local index = 0

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR) 
        return status, faultTbl;
    end
    rowId = instanceMap[tr69Param]
    if (rowId == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR) 
        return status, faultTbl;
    end

    --get corresponding db entry from ThirdParty 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("ThirdParty", query, false)
    if(row == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR) 
        return status, faultTbl;
    end
    thirdpartyConfTbl = row

    -- Enable
    if(input["ThirdParty"]["ThirdParty.Enable"] ~= nil and row["Name"] ~= "Mesh") then
        thirdpartyConfTbl["Enable"] = input["ThirdParty"]["ThirdParty.Enable"]
        db.setAttribute ("ThirdParty","_ROWID_" , rowId, "Enable",thirdpartyConfTbl["Enable"] )
        if (row["Name"] == "DMS" ) then
            if (thirdpartyConfTbl["Enable"] == "0") then
                os.execute("killall -9 dms")
            else
                if (util.fileExists("/pfrm2.0/BRCMJCO300") or util.fileExists("/pfrm2.0/HW_JCO410") or util.fileExists("/pfrm2.0/HW_JCE410"))then
                    os.execute("/pfrm2.0/bin/dms -c /var/twine/dms/xml -e /var/twine/dms -f /tmp/dms.log > /dev/null &")
                else
                    os.execute("/pfrm2.0/bin/dms -c /var/twine/xml -e /var/twine -f /tmp/dms.log > /dev/null &")
                end
            end
        elseif ( row["Name"] == "RAS") then
            if (thirdpartyConfTbl["Enable"] == "0") then
                os.execute("killall -9 ras")
            else
                os.execute("/pfrm2.0/bin/ras -c /var/twine/ras/xml -f /tmp/ras.log -w > /dev/null &")
            end
        elseif (row["Name"] == "Juice") then
            if (thirdpartyConfTbl["Enable"] == "0") then
                os.execute("killall -9 hgw-sip-service")
            else
                os.execute("/pfrm2.0/bin/hgw-sip-service > /dev/null &")
            end
        elseif (row["Name"] == "DC") then
            if (thirdpartyConfTbl["Enable"] == "0") then
                os.execute("killall -9 ont_dc")
            else
                os.execute("/pfrm2.0/bin/ont_dc > /dev/null &")
            end            
        end
    end
    db.save()
    tr69Glue.tf1Dbg("Leaving thirdPartyCfgSet..")
    return status, faultTbl;

end

--[[
--*****************************************************************************
-- fwTr.thirdPartyCfgGet- Get thirdparty configuration
-- 
-- This function is called to get the parameters of  Device.SoftwareModules. object
--
-- Returns: status, value
]]--
function fwTr.thirdPartyCfgGet(input)
    tr69Glue.tf1Dbg("Entering thirdPartyCfgGet..")
    local status = "0"
    local value = "0"
    local rowId
    local row = {}
    local serviceEntry = {}
    local query = nil 
    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --read the rowId mapping to Eogre
    rowId = instanceMap[param]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from route 
    query = "_ROWID_=" .. rowId
    if (util.fileExists ("/pfrm2.0/BRCMJCO300")) then
    	row = db.getRowWhere ("ThirdParty", query, false)
    elseif (util.fileExists ("/pfrm2.0/ECONET")) then
    	row = db.getRowWhere ("ThirdPartyTbl", query, false)
    end
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = row ["Enable"]
    elseif(string.find(input["param"], "Status")) then
        -- Status
        if (row["Enable"] == "1") then
            value = "Enabled"
        elseif (row["Enable"] == "0") then
            value = "Disabled"
        end
    elseif(string.find(input["param"], "Name")) then
        -- Name type
            value = row["Name"]
    elseif(string.find(input["param"], "Vendor")) then
        -- Vendor
        if (row["Name"] == "DMS") then
            value = "Access" 
        elseif (row["Name"] == "RAS") then
            value = "Access" 
        elseif (row["Name"] == "Juice") then
            if (util.fileExists("/pfrm2.0/HW_JCO4031") or util.fileExists("/pfrm2.0/HW_JCO2031")) then
                value = "WIT" 
            elseif (util.fileExists("/pfrm2.0/HW_JCO4032") or util.fileExists("/pfrm2.0/HW_JCOW206") or util.fileExists("/pfrm2.0/HW_JCOW401") or util.fileExists("/pfrm2.0/HW_JCOW403") or util.fileExists("/pfrm2.0/HW_JCOW407") or util.fileExists("/pfrm2.0/HW_JCOW402") or util.fileExists("/pfrm2.0/HW_JCOW404") or util.fileExists("/pfrm2.0/HW_JCOW411")) then
                value = "Jio" 
            elseif (util.fileExists("/pfrm2.0/BRCMJCO300")) then
                value = "Jio" 
            end
        elseif (row["Name"] == "DC") then
            value = "Jio" 
        elseif (row["Name"] == "Mesh") then
            value = "EmbedUR" 
--        elseif (row["Name"] == "IOT") then
--            value = "Oblo" 
        end
    elseif(string.find(input["param"], "Version")) then
        -- Version
        local cmd = "" 
        if (row["Name"] == "DMS" ) then
            if (util.fileExists("/flash2/pfrm2.0/bin/dms")) then
                cmd = "egrep -rni \"twineVersion\" /flash2/pfrm2.0/etc/dms_xml|cut -d \">\" -f 2|cut -d \"<\" -f 1 > /tmp/thirdparty/version.txt"
            else
                cmd = "egrep -rni \"twineVersion\" /pfrm2.0/etc/dms_xml|cut -d \">\" -f 2|cut -d \"<\" -f 1 > /tmp/thirdparty/version.txt"
            end
        elseif (row["Name"] == "RAS") then
            if (util.fileExists("/flash2/pfrm2.0/bin/ras")) then
                cmd = "egrep -rni \"twineVersion\" /flash2/pfrm2.0/etc/ras_xml|cut -d \">\" -f 2|cut -d \"<\" -f 1 > /tmp/thirdparty/version.txt"
            else
                cmd = "egrep -rni \"twineVersion\" /pfrm2.0/etc/ras_xml|cut -d \">\" -f 2|cut -d \"<\" -f 1 > /tmp/thirdparty/version.txt"
            end
        elseif (row["Name"] == "Juice") then
            if (util.fileExists("/flash2/pfrm2.0/bin/hgw-voice-app")) then
                cmd = "strings /flash2/pfrm2.0/lib/libims.so | grep 'JUICEVERSION' | awk -F '/' '{print $2}' | awk -F ' ' '{print $1}' > /tmp/thirdparty/version.txt"
            else
                cmd = "strings /pfrm2.0/lib/libims.so | grep 'JUICEVERSION' | awk -F '/' '{print $2}' | awk -F ' ' '{print $1}' > /tmp/thirdparty/version.txt"
            end
        elseif (row["Name"] == "DC") then
            if (util.fileExists("/flash2/pfrm2.0/bin/ont_dc")) then
                cmd = "/flash2/pfrm2.0/bin/ont_dc -v | grep -i Collector | awk '{print $6}'  > /tmp/thirdparty/version.txt"
            else
                cmd = "/pfrm2.0/bin/ont_dc -v | grep -i Collector | awk '{print $6}'  > /tmp/thirdparty/version.txt"
            end
        elseif (row["Name"] == "Mesh") then
            cmd = "cat /tmp/embedur/version | cut -d \"-\" -f 1 > /tmp/thirdparty/version.txt"
        else
            value = ""
        end
        if (cmd ~= nil) then
            os.execute(cmd)
        end
        f = io.open ("/tmp/thirdparty/version.txt", "r")
        if (f ~= nil) then
            value = f:read("*all")
            f:close()
            os.execute("rm -rf /tmp/thirdparty/version.txt")
        end
    end

    tr69Glue.tf1Dbg("Leaving thirdPartyCfgGet..")

    return status, value
end
