--[[
#### Copyright (c) 2010, TeamF1, Inc.
#### Oct 12, 2010
#### File: qosRule.lua
#### Description: QoS 
#### Revisions:
01a 12Oct10, sam written
]]--

--************* Requires *************
-- XXX: qos.lua includes this file

--************* Initial Code *************

--************* Global Variables *************

qos.rule = {}

-------------------------------------------------------------------------------
-- @name  qos.rule.add 
--
-- @param classification rule
--
-- @description This function adds a rule to the profile. The input must be a LUA
-- table described by the qosClassification table in the database. The mandatory 
-- keys is - ProfileKey. The ClassificationKey is initialized after the rule 
-- is added.
--
-- @return 0 for success, < 0 for errr
--

function qos.rule.add (rule)
	local ret
	local errCode
	local ruleId

	if (rule == nil) then
		return -1, "QOS_INVALID_ARG"
	end

	if (rule["ProfileKey"] == 0 or nil) then
		return -1, "QOS_INVALID_ARG"
	end

	local ProfileKey = rule["ProfileKey"]

	ruleId, errCode = qosLib.ruleAdd(ProfileKey, rule)
	if (ruleId <= 0) then
		return ret, errCode
	end

	-- set unique ruleId
	rule["ClassificationKey"] = ruleId

	-- add table prefix
	rule = util.addPrefix(rule, "qosClassification.")

	-- update the database
	ret, errCode = db.insert("qosClassification", rule)
	if (ret) then
		return 0, "STATUS_OK"
	else
		return -1, errCode
	end
	
end

-------------------------------------------------------------------------------
-- @name qos.rule.delete - 
--
-- @param ID classification rule Id
--
-- @description This function delets a classification rule from the profile
--
-- @return  0 for success, < 0 for errr
--

function qos.rule.delete (ruleId)
	local ret
	local errCode
	local rule = {}

	if (ruleId == nil) then
		return -1, "QOS_INVALID_ARG"
	end

	rule, errCode = qos.rule.get(ruleId)
	if (rule == nil) then
		return -1, "QOS_RULE_NOT_FOUND"
	end

	local ProfileKey = rule["ProfileKey"]
	ret, errCode = qosLib.ruleDel(ProfileKey, ruleId)
	if (ret < 0) then
		return ret, errCode
	end

	query = "_ROWID_=" .. rule["_ROWID_"]
	ret, errCode = db.deleteRowWhere("qosClassification", query)
	if (ret) then
	    return 0, "STATUS_OK"
	else
	    return -1, errCode
	end
end

-------------------------------------------------------------------------------
-- @name qos.rule.edit 
--
-- @param classification rule
--
-- @description
-- This function edits a qos rule in the profile. The input to this function
-- must be a LUA table whose schema is described by qosClassification. 
--
-- @return 0 for success and < 0 for error
--

function qos.rule.edit (rule)
	local ret
	local errCode
	local ruleId
	local row = {}

	if (rule == nil) then
		return -1, "QOS_INVALID_ARG"
	end

	-- check if the rule exits in the database
	ruleId = rule["ClassificationKey"]
	row, errCode = qos.rule.get(ruleId)
	if (row == nil) then
		return -1, "RULE_NOT_FOUND"
	end

	local ProfileKey = row["ProfileKey"]
   
    -- Prepare other match type parameters.
    -- This is to update only Current MATCH Type details in Database.
    for k,v in pairs(row) do
        if(rule[k] == nil) then
            rule[k] = ""
        end
    end

	-- change the rule in the qos daemon
	ret, errCode = qosLib.ruleEdit(ProfileKey, rule)
	if (ret < 0) then
		return ret, errCode
	end

	rule = util.addPrefix(rule, "qosClassification.")

	-- update the database
	local rowid = row["_ROWID_"]
	ret, errCode = db.update("qosClassification", rule, rowid)
	if (ret) then
		return 0, "STATUS_OK"
	else
		return -1, errCode
	end
end

-------------------------------------------------------------------------------
-- @name qos.rule.get 
--
-- @param ID classification rule Id
--
-- @description This function gets a rule from the datbase based on the ruleId
--
-- @return rule or nil
--

function qos.rule.get (ruleId)

	-- validate arguments
	if ((ruleId == nil) or (ruleId == 0)) then
		return -1, "QOS_INVALID_ARG"
	end

	-- get the rule from the database
	local query = "ClassificationKey=" .. ruleId
	local rule = db.getRowWhere ("qosClassification", query, false)
	if (rule == nil) then
		return rule, "QOS_RULE_NOT_FOUND"
	end

	return rule, "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name  qos.rule.tableGet
--
-- @param search query
--
-- @description This function gets the configuration of the rule based on
-- the given query. The result is returned in the form of a LUA table.
--
-- @return OK or ERROR
-- @return errCode 
-- @return rule table
--

function qos.rule.tableGet (query)
    local ruleTbl = nil

    if (query == nil) then
        ruleTbl = db.getTable("qosClassification", false)
    else
        ruleTbl = db.getRowsWhere("qosClassification", query, false)
    end        

    if (ruleTbl == nil) then
        return "ERROR", "QOS_CRULE_ERR_ENOENT"
    end
            
    return "OK","STATUS_OK", ruleTbl            
end

-------------------------------------------------------------------------------
-- @name  qos.rule.cfgByQueryGet
--
-- @param search query
--
-- @description This function gets the configuration of the rule based on
-- the given query. 
--
-- @return OK or ERROR
-- @return errCode 
-- @return rule 
--

function qos.rule.cfgByQueryGet(query)
    local rule = nil

    if (query == nil) then
        return "ERROR", "QOS_CRULE_ERR_INVALID_ARG"
    end        

    rule = db.getRowWhere("qosClassification", query, false)
    if (rule == nil) then
        return "ERROR", "QOS_CRULE_ERR_ENOENT"
    end        
                
    return "OK","STATUS_OK", rule
end
