--[[
#### Copyright (c) 2012, TeamF1, Inc.
#### File: qosIf.lua
#### Description: 
#### Revisions:
01a 03aug12, sam written
]]--

qos.iface = {}
qos.iface.MAX_UPSTREAM_BPS=1000000000 
qos.iface.MAX_DOWNSTREAM_BPS=1000000000
qos.iface.default = {}
qos.iface.default["UpstreamBandwidth"] = qos.iface.MAX_UPSTREAM_BPS
qos.iface.default["DownstreamBandwidth"] = qos.iface.MAX_DOWNSTREAM_BPS
qos.iface.default["Enable"] = "1"
qos.iface.default["MeasureBandwidth"] = "0"
qos.iface.default["ProfileKey"] ="0"
qos.iface.default["InterfaceName"] =""

-------------------------------------------------------------------------------
-- @name qos.iface.add
--
-- @description This function adds qos management to the interface
--
-- @param  LogicalIfName  Logical Name of the network
--
-- @return  status OK or ERROR
-- @return  errCode error code string
-- @return  rowid
--

function qos.iface.add (LogicalIfName)
    local row = {}
    local query 

    if (LogicalIfName == nil) then
        qos.dprintf("iface.add: failed to add qos management to interface");
        return "ERROR","QOS_ERR_IFACE_ADD_INVALID_ARGS"
    end
            
    query = "InterfaceName='" .. LogicalIfName .. "'"

    -- check if the interface already exists
    row = db.getRowWhere("qosQueueManagement", query, false)
    if (row ~= nil) then
        qos.dprintf("iface.add: qos management already added to interface")
        return "ERROR","QOS_ERR_IFACE_EXISTS"        
    end        

    row = qos.iface.default
    row["InterfaceName"] = LogicalIfName
    
	local status = qosLib.ifAdd(row)
	if (status < 0) then
		return "ERROR", errCode
	end
    
    row = util.addPrefix(row, "qosQueueManagement.")
    local valid, errstr, rowid = db.insert("qosQueueManagement", row)
    if (not valid) then
        qos.dprintf("iface.add:failed to add qos management configuration on " .. 
                    LogicalIfName)
        return "ERROR","QOS_ERR_IFACE_ADD_DB_ERR"
    end        

    return "OK", "STATUS_OK", rowid
end

-------------------------------------------------------------------------------
-- @name qos.iface.delete
--
-- @description This function deletes qos management from the interface
--
-- @param  LogicalIfName  Logical Name of the network
--
-- @return  status OK or ERROR
-- @return  errCode error code string
--

function qos.iface.delete (LogicalIfName)
    local row = {}
    local query 

    if (LogicalIfName == nil) then
        qos.dprintf("iface.delete: failed to delete qos management from interface");
        return "ERROR","QOS_ERR_IFACE_DELETE_INVALID_ARGS"
    end
            
    query = "InterfaceName='" .. LogicalIfName .. "'"

    -- check if the interface exists
    row = db.getRowWhere("qosQueueManagement", query, false)
    if (row == nil) then
        qos.dprintf("iface.delete: qos management not configured for interface")
        return "ERROR","QOS_ERR_IFACE_NOENT"        
    end        

	local status = qosLib.ifDelete(LogicalIfName)
	if (status < 0) then
		return "ERROR", errCode
	end
    
    local delRow = {}
    delRow[1] = row["_ROWID_"]
    local valid, errstr = db.delete("qosQueueManagement", delRow)
    if (not valid) then
        qos.dprintf("iface.delete:failed to delete qos management configuration from " .. 
                    LogicalIfName .. ". Err: " .. errstr)
        return "ERROR","QOS_ERR_IFACE_DELETE_DB_ERR"
    end        

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name qos.iface.measureBandwidth
--
-- @description This function enable/disable bandwidth measurement on interface
-- and initiates the test if enabled
--
-- @param  LogicalIfName  Logical Name of the network
-- @param  enable         1 to enable else 0
--
-- @return  status OK or ERROR
-- @return  errCode error code string
--

function qos.iface.measureBandwidth (LogicalIfName, enable)
    local value
    
    if ((LogicalIfName == nil) or (enable == nil))  then
        qos.dprintf("iface.measureBandwidth: failed to enable/disable " ..
                    "bandwith measurement");
        return "ERROR","QOS_ERR_IFACE_BWM_INVALID_ARGS"
    end

    value = tonumber(enable)
    local valid, errstr = db.setAttribute("qosQueueManagement", "InterfaceName", 
                                          LogicalIfName, "MeasureBandwidth", value)
    if (not valid) then
        qos.dprintf("iface.measureBandwidth: failed to change bandwidth " ..
                    "measurement configuration for:" .. LogicalIfName .. 
                    "Error: " .. (errstr or 'n/a'));
        return "ERROR", "QOS_ERR_IFACE_BWM_DB_ERR"
    end        
    
    local status, errCode = qos.bwTest.ifaceSet(LogicalIfName)
    if (status ~= "OK") then
        return status, errCode
    end        

    if (value == 1) then
        status, errCode = qos.bwTest.start(LogicalIfName)
        if (status ~= "OK") then
            qos.dprintf("failed to start bandwidth measurement")
        end            
    end
            
    return "OK", "STATUS_OK"    
end

-------------------------------------------------------------------------------
-- @name qos.iface.bandwidthSet
--
-- @description This function sets bandwidth on this interface
--
-- @param  LogicalIfName  Logical Name of the network
-- @param  upstream       upstream bandwidth in bps
-- @param  downstream     downstream bandwidth in bps
--
-- @return  status OK or ERROR
-- @return  errCode error code string
--

function qos.iface.bandwidthSet (LogicalIfName, upstream, downstream)
    local row = {}
    local query 

    if (LogicalIfName == nil) then
        qos.dprintf("iface.bandwidthSet: failed to change bandwidth of network");
        return "ERROR","QOS_ERR_IFACE_BWM_INVALID_ARGS"
    end
            
    query = "InterfaceName='" .. LogicalIfName .. "'"

    -- check if the interface exists
    row = db.getRowWhere("qosQueueManagement", query, false)
    if (row == nil) then
        qos.dprintf("iface.bandwidthSet: qos management for interface not configured")
        return "ERROR","QOS_ERR_IFACE_NOENT"        
    end        

    --
    -- if bandwidth has not changed, then skip
    --
    if ((tonumber(row["UpstreamBandwidth"]) == tonumber(upstream)) and
        (tonumber(row["DownstreamBandwidth"]) == tonumber(downstream))) then
		return  "OK", errCode
    end        

    row["UpstreamBandwidth"] = tonumber(upstream)
    row["DownstreamBandwidth"] = tonumber(downstream)
    
	local status, errCode = qosLib.ifBwChange(LogicalIfName, upstream, downstream)
	if (status < 0) then
        qos.dprintf("iface.bandwidthSet: qos management for interface not configured")
		return "ERROR", errCode
	end
    
    row = util.addPrefix(row, "qosQueueManagement.")
    local valid, errstr = db.update("qosQueueManagement", row, 
                                    row["qosQueueManagement._ROWID_"])
    if (not valid) then
		return "ERROR", "QOS_ERR_IFACE_BWM_DB_ERR"
    end
    
    return "OK", "STATUS_OK"        
end

-------------------------------------------------------------------------------
-- @name qos.iface.get
--
-- @description This function gets the qos management settings of the interface
--
-- @param  LogicalIfName  Logical Name of the network
--
-- @return  status OK or ERROR
-- @return  errCode error code string
-- @return  qosIfObj
--

function qos.iface.get (LogicalIfName)
    local row = {}
    local query 

    if (LogicalIfName == nil) then
        qos.dprintf("iface.get: failed to get qos management for interface");
        return "ERROR","QOS_ERR_IFACE_GET_INVALID_ARGS"
    end
            
    query = "InterfaceName='" .. LogicalIfName .. "'"

    -- check if the interface exists
    row = db.getRowWhere("qosQueueManagement", query, false)
    if (row == nil) then
        qos.dprintf("iface.get: qos management for interface not configured")
        return "ERROR","QOS_ERR_IFACE_NOENT"        
    end        

    return "OK", "STATUS_OK", row
end

-------------------------------------------------------------------------------
-- @name  qos.iface.namechange 
--
-- @param
--
-- @description
-- This function changes the interface name in the qos daemon. The arguments
-- to this function are the LogicalIfName of the interface and actual interface 
-- name. The qos daemon works on the actual interface names. 
--
-- @return 0 for success, < 0 for error
--

function qos.iface.namechange (LogicalIfName, ifname)
	local ret
	local errCode

	if ((LogicalIfName == nil) or (ifname == nil)) then
		return -1, "QOS_INVALID_IFACE_NAME"
	end

	-- change the interface name in the qos daemon
	ret, errCode = qosLib.ifNameChange(LogicalIfName, ifname)
	
	return ret, errCode;
end

-------------------------------------------------------------------------------
-- @name  qos.iface.statuschange 
--
-- @param
--
-- @description This function changes the qos state of an interface
--
-- @return 0 for success, < 0 for error
--

function qos.iface.statuschange (LogicalIfName, status)
	local ret
	local errCode

	if (LogicalIfName == nil) then
		return -1, "QOS_INVALID_ARG"
	end

	-- change the qos state of this interface 
	ret, errCode = qosLib.ifStatusChange(LogicalIfName, status)
	if (ret < 0) then
		return ret, errCode
	end
	
	-- update the database 
	ret, errCode = db.setAttribute("qosQueueManagement", "InterfaceName", 
									LogicalIfName, "Enable", status)
	if (ret) then
		return  0, errCode;
	else
		return -1, errCode;
	end
end

-------------------------------------------------------------------------------
-- @name qos.iface.bwchange 
--
-- @param
--
-- @description This function changes the interface bandwidth in the qos daemon.
--
-- @return 0 for success, < 0 for error
--

function qos.iface.bwchange (LogicalIfName, upstream, downstream)
	local ret
	local errCode = "STATUS_OK"

	if (LogicalIfName == nil) then
		return -1, "QOS_INVALID_IFACE_NAME"
	end
    
	local query = "InterfaceName='" .. LogicalIfName .. "'"
	local wanBw = db.getRowWhere("qosQueueManagement", query, false)
	if (wanBw == nil) then
		return -1, "QOS_DB_ERR"
	end

    --
    -- if bandwidth has not changed, then skip
    --
    if ((tonumber(wanBw["UpstreamBandwidth"]) == tonumber(upstream)) and
        (tonumber(wanBw["DownstreamBandwidth"]) == tonumber(downstream))) then
		return  0, errCode
    end        

	-- change the qos state of the interface  in the qos daemon
	ret, errCode = qosLib.ifBwChange(LogicalIfName, upstream, downstream)
	if (ret < 0) then
		return ret, errCode;
	end

	-- update the database 
	wanBw["UpstreamBandwidth"] = upstream
	wanBw["DownstreamBandwidth"] = downstream

    wanBw = util.addPrefix(wanBw, "qosQueueManagement.")
	ret, errCode = db.update("qosQueueManagement", wanBw,
							 wanBw["qosQueueManagement._ROWID_"])
	if (ret) then
		return  0, errCode;
	else
		return -1, errCode;
	end
end

-------------------------------------------------------------------------------
-- @name qos.iface.classQueueCountGet 
--
-- @param
--
-- @description
-- This function counts the classes configured by the user in the profile
-- installed on this interface.
--
-- @return count for success, < 0 for error
--

function qos.iface.classQueueCountGet(LogicalIfName)
	local classTbl = {}
	local count = 0

	classTbl = 
	db.getTableWithJoin({"qosQueueManagement:qosClassQueue:ProfileKey"},
						"qosQueueManagement.InterfaceName", LogicalIfName);

	if (classTbl == nil) then
		return -1
	end

	for k,v in pairs(classTbl) do
		if (v["qosClassQueue.ConfigDefault"] == "0") then
			count  = count + 1
		end
	end

	return count
end

-------------------------------------------------------------------------------
-- @name qos.iface.tableGet
--
-- @description This function gets the qos management settings for all the
-- interfaces that are returned by the database query. The results are
-- returned as a table.
--
-- @param  query  search query
--
-- @return  status OK or ERROR
-- @return  errCode error code string
-- @return  table of qos settings of all interfaces
--

function qos.iface.tableGet (query)
    local rows = {}

    if (query == nil) then            
        rows = db.getTable("qosQueueManagement", false)
    else                
        rows = db.getRowsWhere("qosQueueManagement", query, false)
    end

    if (rows == nil) then
        qos.dprintf("iface.tableGet: no results from the search query")
        return "ERROR","QOS_ERR_IFACE_NOENT"        
    end        

    return "OK", "STATUS_OK", rows
end

-------------------------------------------------------------------------------
-- @name qos.iface.cfgByQueryGet
--
-- @description This function gets the qos management settings of the
-- interface that are returned by the database query. 
--
-- @param  query  search query
--
-- @return  status OK or ERROR
-- @return  errCode error code string
-- @return  qos settings of the interface
--

function qos.iface.cfgByQueryGet (query)
    local row = {}

    if (query == nil) then
        qos.dprintf("iface.cfgByQueryGet: failed to get qos management for interface");
        return "ERROR","QOS_ERR_IFACE_GET_INVALID_ARGS"
    end
            
    -- check if the interface exists
    row = db.getRowWhere("qosQueueManagement", query, false)
    if (row == nil) then
        qos.dprintf("iface.cfgByQueryGet: qos management for interface not configured. Query:" .. query)
        return "ERROR","QOS_ERR_IFACE_NOENT"        
    end        

    return "OK", "STATUS_OK", row
end

-------------------------------------------------------------------------------
-- @name qos.iface.profileSet
--
-- @description This function sets the given profile on the interface
--
-- @param LogicalIfName  logicalIfname of the interface or network
-- @param ProfileName    name of the profile being set
--
-- @return  status OK or ERROR
-- @return  errCode error code string
--

function qos.iface.profileSet (LogicalIfName, ProfileName)
    local oldProfileName = nil
    local status = "ERROR"
    local errCode = ""

    -- sanitize the input
    if ((LogicalIfName == nil) or (ProfileName == nil)) then
        qos.dprintf("iface.profileSet: invalid arguments")
        return "ERROR", "QOS_ERR_IFACE_PROF_SET_INVALID_ARGS"
    end        

    -- Get the profile 
    local ProfileKey = qos.profile.NameToId (ProfileName)
    if (ProfileKey == nil) then
        qos.dprintf("iface.profileSet: could not find profile=" .. ProfileName)
        return "ERROR", "QOS_ERR_IFACE_INVALID_PROFILE"
    end        

    -- Check if a profile has already been set
    oldProfileName = qos.iface.profileGet (LogicalIfName)
    if (oldProfileName ~= nil) then
        status, errCode = qos.iface.profileUnset(LogicalIfName)
        if (status ~= "OK") then
            qos.dprintf("iface.profileSet: Failed to unset old profile: " .. oldProfileName  ..
                        " on LogicalIfName=" .. LogicalIfName)
            return "ERROR", errCode
        end            
    end        

    -- set the new profile on the interface    
    status, errCode = qosLib.ifProfileSet(LogicalIfName, ProfileName)
    if (status < 0) then
        qos.dprintf("iface.profileSet: Failed to set profile: " .. ProfileName  ..
                    " on LogicalIfName=" .. LogicalIfName)
        return "ERROR", errCode
    end        

    -- initialize the profile for this interface
    ret, errCode = qos.profile.init(ProfileKey)
    if (ret < 0) then
        qos.dprintf("iface.profileSet: failed to initialise default classes for " ..
                    "profileID=" .. ProfileKey)
        return -1, errCode
    end        

    -- update the database 
	status, errCode = db.setAttribute("qosQueueManagement", "InterfaceName", 
									   LogicalIfName, "ProfileKey", ProfileKey)
    if (not status) then
        qos.dprintf("profileUnset: failed to unset profile cfg")
        return "ERROR", errCode
    end        

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name qos.iface.profileGet
--
-- @description This function gets the profile that has been set on the 
-- interface
--
-- @param LogicalIfName  logicalIfname of the interface or network
--
-- @return  ProfileName or nil
--

function qos.iface.profileGet (LogicalIfName)
    local profile = nil
    local ProfileName = nil
    
    -- sanitize the input
    if (LogicalIfName == nil) then
        return nil, "QOS_ERR_IFACE_PROF_GET_INVALID_ARGS"
    end        

    --- get the iface
    local status, errCode, iface = qos.iface.get(LogicalIfName)
    if (status ~= "OK") then
        return nil, errCode
    end        

    local ProfileKey = iface["ProfileKey"]
    if ((ProfileKey ~= nil) and (tonumber(ProfileKey) > 0)) then
        profile = qos.profile.get(ProfileKey)
        if (profile == nil) then
            return nil, "QOS_ERR_IFACE_PROF_NOT_FOUND"
        end            
        ProfileName = profile["ProfileName"]
    end
            
    return ProfileName, profile
end

-------------------------------------------------------------------------------
-- @name qos.iface.profileUnset
--
-- @description This function unsets the given profile from the interface
--
-- @param LogicalIfName  logicalIfname of the interface or network
--
-- @return  status OK or ERROR
-- @return  errCode error code string
--

function qos.iface.profileUnset (LogicalIfName)
    local status
    local errCode
    
    -- sanitize the input
    if (LogicalIfName == nil) then
        return "ERROR", "QOS_ERR_IFACE_PROF_UNSET_INVALID_ARGS"
    end        

    -- Check if a profile has been set
    local ProfileName, profile = qos.iface.profileGet(LogicalIfName)
    if (ProfileName == nil) then
        qos.dprintf("profileUnset: No profile set on " .. LogicalIfName)
        return "OK", "STATUS_OK"
    end        

    -- check if the profile has been configured 
    local ProfileKey = qosLib.profileNameToId(ProfileName)
    if (ProfileKey == nil) then
        qos.dprintf("profileUnset: profile not installed on " .. LogicalIfName)
        return "OK", "STATUS_OK"
    end        

    local profileId =  profile["ProfileKey"]
    ret, errCode = qos.profile.deinit(profileId)
	if (ret < 0) then
        qos.dprintf("profileUnset: failed to deinit profile")
		return ret, errCode
	end

    -- Unset the profile
    status, errCode = qosLib.ifProfileUnset(LogicalIfName)
    if (status < 0) then
        qos.dprintf("profileUnset: failed to unset profile")
        return "ERROR", errCode
    end        

    -- update the database 
	status, errCode = db.setAttribute("qosQueueManagement", "InterfaceName", 
									   LogicalIfName, "ProfileKey", 0)
    if (not status) then
        qos.dprintf("profileUnset: failed to unset profile cfg")
        return "ERROR", errCode
    end        

    return "OK", "STATUS_OK"
end
