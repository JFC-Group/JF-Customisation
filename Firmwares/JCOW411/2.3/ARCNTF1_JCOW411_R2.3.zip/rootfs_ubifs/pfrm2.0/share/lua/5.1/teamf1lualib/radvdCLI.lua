-- radvdCLI.lua
-- Samer Sayeed
-- TeamF1
-- www.TeamF1.com
--
-- Modification History
-- 31jan09,ss  modified validation routine 
-- 12jan09,ss  written 
--
-- Description
-- CLI interface set and get routines

require "teamf1lualib/radvd"

function radvdCfgSave(configRow)
    DBTable = "radvd"
    errorFlag, statusCode = radvd.profileConfig(configRow, "1", "edit")
    if (errorFlag == "OK") then db.save() end
    statusMessage = db.getAttribute("stringsMap", "stringId", statusCode, LANGUAGE)
    return errorFlag, statusMessage
end

function radvdCfgInit (args)
    configRow = db.getRow("radvd", "_ROWID_", "1")
    return 1, configRow
end

function radvdCfgInputVal (configRow)
    local ipMode = db.getAttribute ("networkInfo", "_ROWID_", "1", "netWorkMode") or ''
    if (ipMode == "1") then
        printCLIError ("Please Set IP Mode to IPv4/IPv6 to configure RADVD.\n")
	return false
    end
    return true
end

function radvdPoolCfgInputVal (configRow)
    local ipMode = db.getAttribute ("networkInfo", "_ROWID_", "1", "netWorkMode") or ''
    if (ipMode == "1") then
        printCLIError ("Please Set IP Mode to IPv4/IPv6 to configure IPv6 RADVD.\n")
        return false
    end
    if (configRow["radvdLANPrefixPool.radvdPrefixType"] == nil or configRow["radvdLANPrefixPool.radvdPrefixType"] == "") then
        printCLIError("Enter valid ipv6 prefix type\n")
        return false
    end
    if (configRow["radvdLANPrefixPool.radvdPrefixType"] == "2") then
        if (configRow["radvdLANPrefixPool.radvdAdvPrefix"] == nil or configRow["radvdLANPrefixPool.radvdAdvPrefix"] == "") then
            printCLIError("Enter valid ipv6 prefix\n")
            return false
        end
        if (configRow["radvdLANPrefixPool.radvdAdvPrefixLength"] == nil or configRow["radvdLANPrefixPool.radvdAdvPrefixLength"] == "") then
            printCLIError("Enter valid ipv6 prefix length\n")
            return false
        end
    end
    if (configRow["radvdLANPrefixPool.radvdPrefixType"] == "1") then
        if (configRow["radvdLANPrefixPool.SLAIdentifier"] == nil or configRow["radvdLANPrefixPool.SLAIdentifier"] == "") then
            printCLIError("Enter valid SLA ID \n")
            return false
        end
    end
    if (configRow["radvdLANPrefixPool.radvdAdvPrefixLifetime"] == nil or configRow["radvdLANPrefixPool.radvdAdvPrefixLifetime"] == "") then
        printCLIError("Enter valid prefix life time\n")
        return false
    end
    return true
end

function radvdCfgGet (args)
    local table = db.getTable ("radvdLANPrefixPool")
    local radvdRow = db.getRow ("radvd", "_ROWID_", "1")
    local resultTab = {}
    local i = 0
    printLabel("Router Advertisement Daemon ( RADVD )")
    if (radvdCfgInputVal ()) then
    if (radvdRow["radvd.isEnabled"] == "1") then 
    print("RADVD Status: Enabled\t")
    elseif (radvdRow["radvd.isEnabled"] == "0") then
    print("RADVD Status: Disabled\t")
    end
    if (radvdRow["radvd.UnicastOnly"] == "0") then 
    print("Advertise Mode: Unsolicited Multicast\t")
    elseif (radvdRow["radvd.UnicastOnly"] == "1") then
    print("Advertise Mode: Unicast only\t")
    end
    print("Advertise Interval: " .. radvdRow["radvd.MaxRtrAdvInterval"] or "" .. " Seconds\t")
    print("RA Flags\n")
    if (radvdRow["radvd.AdvManagedFlag"] == "0") then
    print("Managed: Disabled\t")
    elseif (radvdRow["radvd.AdvManagedFlag"] == "1") then
    print("Managed: Enabled\t")
    end
    if (radvdRow["radvd.AdvOtherConfigFlag"] == "0") then
    print("Other: Disabled\t")
    elseif (radvdRow["radvd.AdvOtherConfigFlag"] == "1") then
    print("Other: Enabled\t")
    end
    if (radvdRow["radvd.AdvDefaultPreference"] == "1") then
    print("Router Preference: Low\t")
    elseif (radvdRow["radvd.AdvDefaultPreference"] == "2") then
    print("Router Preference: Medium\t")
    elseif (radvdRow["radvd.AdvDefaultPreference"] == "3") then
    print("Router Preference: High\t")
    end
    if (radvdRow["radvd.AdvLinkMTU"] ~= nil) then 
    print("MTU: " .. radvdRow["radvd.AdvLinkMTU"] .. "\t")
    end
    if (radvdRow["radvd.AdvDefaultLifetime"] ~= nil) then 
    print("Router Lifetime: " .. radvdRow["radvd.AdvDefaultLifetime"] .. " Seconds\n")
    end
    printLabel("List of Available Prefixes to Advertise")
    for k,v in pairs(table) do
	i = i + 1
	local row = table[i]
        resTab.insertField (resultTab, "ROW ID", row["radvdLANPrefixPool._ROWID_"] or "")
        resTab.insertField (resultTab, "IPv6 Prefix", row["radvdLANPrefixPool.radvdAdvPrefix"] or "")
        resTab.insertField (resultTab, "IPv6 Prefix Length", row["radvdLANPrefixPool.radvdAdvPrefixLength"] or "" ) 
        resTab.insertField (resultTab, "Life Time", row["radvdLANPrefixPool.radvdAdvPrefixLifetime"] or "")
    end
    resTab.print (resultTab, 0)
    end
end

function radvdPoolCfgInit (args)
    if(args[1] == nil)then
        configRow={}
        configRow["radvdLANPrefixPool._ROWID_"] = "-1"
    else
        configRow = db.getRow("radvdLANPrefixPool", "_ROWID_", args[1])
    end
    if(configRow == nil)then
        print("Row deleted\n")
        return -1, {}
    end
    return configRow["radvdLANPrefixPool._ROWID_"], configRow
end

function radvdPoolCfgSave(configRow)
    DBTable = "radvdLANPrefixPool"
    if(configRow["radvdLANPrefixPool._ROWID_"] == "-1") then
        errorFlag, statusCode = radvd.profileConfig(configRow, configRow["radvdLANPrefixPool._ROWID_"], "add")
    else
        errorFlag, statusCode = radvd.profileConfig(configRow, configRow["radvdLANPrefixPool._ROWID_"], "edit")
    end
    if (errorFlag == "OK") then db.save() end
    statusMessage = db.getAttribute("stringsMap", "stringId", statusCode, LANGUAGE)
    return errorFlag, statusMessage
end

function radvdPoolCfgDel(configRow)
    DBTable = "radvdLANPrefixPool"
    rows = {}
    rows["rowid"] = configRow["radvdLANPrefixPool._ROWID_"]
    -- if any rows to delete
    if (rows) then
        errorFlag, statusCode =  radvdPrefix.deleteProfiles (rows)
    end
    -- save db if no error
    if (errorFlag == "OK") then db.save() end
    statusMessage = db.getAttribute("stringsMap", "stringId", statusCode, LANGUAGE)
    return errorFlag, statusMessage
end
