-- @copyright Copyright (c) 2012, TeamF1, Inc. 

require "teamf1lualib/evtDsptch"
require "appExtn/AppExtn"
require "upnpLib"

UpnpExtn = OoUtil.inheritsFrom(AppExtn)
UpnpExtn.name    = "UPnP Daemon"
UpnpExtn.classId = "upnp"
UpnpExtn.className  =  "UpnpExtn"
UpnpExtn.dbTable = "upnp"
UpnpExtn.logger  = nil

local SUPER = require("appExtn.AppExtn")

-- network events
local netEvents = {}
netEvents[evtDsptch.event.IFDEV_EVENT_IP4_NET_UP]   =  1
netEvents[evtDsptch.event.IFDEV_EVENT_IP4_NET_DOWN] =  1

-- configuration events
local cfgEvents = {}
cfgEvents[db.event.SQLITE_INSERT] = 1
cfgEvents[db.event.SQLITE_UPDATE] = 1
cfgEvents[db.event.SQLITE_DELETE] = 1

-------------------------------------------------------------------------------
-- @name UpnpExtn.cfgEventCallback
--
-- @description 
--
-- @param  
--
-- @return  
--

function UpnpExtn.cfgEventCallback(obj, info)
    local status = "ERROR"
    local errcode = ""

    LOG:ddebug(UpnpExtn.classId .. " configuration callback called  " .. 
              "for event: " ..  info.event .. " on rowId " .. info.rowId)

    if (info.event == db.event.SQLITE_INSERT) then
        if (obj ~= nil) then 
            assert(nil, UpnpExtn.classId .. "(" .. info.rowId  .. ")" ..
                   "already created")
            return -1
        end        

        -- create instance and process event
        obj = UpnpExtn:new(info.rowId)
        if (obj) then 
            obj:onCfgEvent(info) 
        end

    elseif (info.event == db.event.SQLITE_UPDATE) then
        -- re-load and process event
        if (obj) then 
            status, errCode, obj = obj:load()
            if (status == "OK") then
                obj:onCfgEvent(info) 
            end            
        end
    elseif (info.event == db.event.SQLITE_DELETE) then
        -- process event and destroy instance
        if (obj) then
            obj:onCfgEvent(info)
            obj:delete()
        end
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name UpnpExtn.bootstrap
--
-- @description This function is called by appd on startup to bootstrap all 
-- instances of this application. 
--
-- @param  
--
-- @return  
--

function UpnpExtn.bootstrap()
    local instanceId
    local callbackTable= {}

    upnpLib.killAll()

    local callback = {}
    callback.type = appd.eventType.APPD_EV_CFG
    callback.dbTable = UpnpExtn.dbTable
    callback.routine = UpnpExtn.cfgEventCallback
    table.insert(callbackTable, callback)
    appd.callbackRegister (UpnpExtn.classId, callbackTable)

    local cfg = db.getTable(UpnpExtn.dbTable, false)
    if (cfg == nil) then
        return 0
    end        

    for index, record in pairs(cfg) do
        instanceId = record["_ROWID_"]
        local obj = UpnpExtn:new(instanceId)
        if (obj and obj:isEnabled()) then
            obj:start()
        end                        
    end

    return 0
end

-------------------------------------------------------------------------------
-- @name UpnpExtn:new
--
-- @description This function creates a new instance object for upnp, loads
-- the configuration and event subcriptions
--
-- @return  0 for success and -1 for error
--

function UpnpExtn:new(instanceId, props)

    -- create a new instance
    self = UpnpExtn.create()

    SUPER.new(self, UpnpExtn.classId, instanceId, props)

    self.name  = UpnpExtn.name
    self.dbTable =  UpnpExtn.dbTable

    -- initialize events for this instance
    self.netEvents = netEvents              
    self.cfgEvents = cfgEvents

    -- load the instance          
    local status, errCode, self = self:load()
    if (status == nil) then
        LOG:error("failed to load " .. classId .. 
                  "(" .. instanceId .. ")")
        return nil
    end        

    -- register with appd
    appd.appExtnRegister(self)                    

    return self
end

-------------------------------------------------------------------------------
-- @name UpnpExtn:delete
--
-- @description This function deletes an instance of this extension
--
-- @param instanceId
--
-- @return  
--

function UpnpExtn:delete()
    appd.appExtnUnregister(self)
end

-------------------------------------------------------------------------------
-- @name UpnpExtn:stop
--
-- @description This function starts upnp
--
-- @return  0 for success and -1 for error
--

function UpnpExtn:stop ()
    local props = self:getProps()

    upnpLib.cfgLoad(props)

    LOG:info("Stopping " .. self.name .. 
             "(" ..  self.instanceId .. ")")

    upnpLib.stop()

    return 0
end

-------------------------------------------------------------------------------
-- @name UpnpExtn:isEnabled
--
-- @description This function checks if this instance is enabled
--
-- @return  true if enabled else false
--

function UpnpExtn:isEnabled()

    local props = self:getProps()

    if (tonumber(props.upnpEnable) > 0) then
        return true
    end        

    return false
end

-------------------------------------------------------------------------------
-- @name UpnpExtn:start
--
-- @description This function starts upnp
--
-- @return  0 for success and -1 for error
--

function UpnpExtn:start ()
    require "teamf1lualib/nimf"
    local props = self:getProps()

    if (self:isEnabled()) then

        -- check if the network is UP
        if (nimfConn.isIPv4Up(props.LogicalIfName) == false) then
            LOG:debug(self.name .. " network(" .. props.LogicalIfName  .. ") is not UP")
            return -1
        end        

        if (upnpLib.cfgLoad(props) < 0) then
            return -1
        end            

        LOG:info("Starting " .. self.name ..  "(" ..  self.instanceId .. ")")

        if (upnpLib.start() < 0) then
            return -1
        end            
    end

    return 0
end

-------------------------------------------------------------------------------
-- @name UpnpExtn:restart
--
-- @description This function restarts upnp
--
-- @return  0 for success and -1 for error
--

function UpnpExtn:restart ()

    -- stop the server
    self:stop() 

    -- start the server
    if (self:start() < 0) then
        return -1
    end                

    return 0
end

-------------------------------------------------------------------------------
-- @name UpnpExtn:getAppName
--
-- @description This function gets the name of this extension
--
-- @return  
--

function UpnpExtn:getAppName()
   return self.name
end

-------------------------------------------------------------------------------
-- @name UpnpExtn:getDbTableName
--
-- @description This function gets the database table name which contains
-- configuration records for all instances of this application.
--
-- @return  
--

function UpnpExtn:getDbTableName()
   return self.dbTable
end

-------------------------------------------------------------------------------
-- @name UpnpExtn:onNetEvent
--
-- @description This function handles network events
--
-- @param  netevent  network event
--
-- @return  0 for success and -1 for error
--

function UpnpExtn:onNetEvent(netevent)

    if (self:isEventSubscribed(netevent) == false) then
        LOG:ddebug(self.classId .. " not subscribed to event: " ..
                  netevent.event .. " on " .. netevent.ifname)
        return 0
    end        

    self:restart()

    return 0
end

-------------------------------------------------------------------------------
-- @name UpnpExtn:isEventSubscribed
--
-- @description This function checks if this instance is subcribed to
-- the event pass as input
--
-- @param event event information
--
-- @return  0 for success and -1 for error
--

function UpnpExtn:isEventSubscribed(event)
    require "teamf1lualib/network"
    local props = self:getProps()

    if (event.type == appd.eventType.APPD_EV_NET) then

        if (network.isLAN(event.ifname)) then
            if (strlib.strcasecmp(props.LogicalIfName, event.ifname) ~= 0) then
                return false
            end            
        end
        
        local evstate = self.netEvents[event.event]
        if (evstate == nil) then
            return false
        end            
                    
        if (evstate > 0) then
            return true
        end        

    elseif (event.type == appd.eventType.APPD_EV_CFG) then

        -- are we subscribed to this event                        
        local evstate = self.cfgEvents[event.event]
        if (evstate == nil) then
            return false
        end            

        if (evstate > 0) then
            return true
        end        
    end

    return false
end

-------------------------------------------------------------------------------
-- @name UpnpExtn:onCfgEvent
--
-- @description This function is to handle configuration events
-- 
-- @param  cfgevent event information
--
-- @return  
--

function UpnpExtn:onCfgEvent(cfgevent)
    local props = self:getProps()

    if (self:isEventSubscribed(cfgevent) == false) then
        LOG:ddebug(self.name .. " not subscribed to event: " ..
                  cfgevent.event .. " on " .. cfgevent.dbTable)
        return
    end        

    if (cfgevent.event == db.event.SQLITE_INSERT) then
        self:start()
    elseif (cfgevent.event == db.event.SQLITE_UPDATE) then
        self:restart()
    elseif (cfgevent.event == db.event.SQLITE_DELETE) then
        self:stop()
    end                

    return
end

-------------------------------------------------------------------------------
-- @name UpnpExtn:print
--
-- @description This function prints the properties of this application instance
--
-- @param  
--
-- @return  
--

function UpnpExtn:print()
    require "util/strlib"

    LOG:info("Class     : " .. self.classId)
    LOG:info("Instance  : " .. self.instanceId)
    LOG:info("App Name  : " .. self:getAppName())
    LOG:info("Conf      : " .. strlib.serializeTbl(self:getProps()))
    return
end

return UpnpExtn
