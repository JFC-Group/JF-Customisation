--[[
#### 
#### File: tr181_qosTrExtn.lua
#### Description: 
#### TR-181 handlers for QoS. This file is included from tr181_tr69funcs.lua
####
]]--

qosTr = {}

-- includes 
require "teamf1lualib/qos"

--[[
--*****************************************************************************
-- qosTr.bwprofGet- get bandwidth profile configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.QoS.Queue.0.
--
-- Enable
-- Status
-- TrafficClasses
-- ShapingRate
--
-- Returns: status, value
]]--
function qosTr.bwprofGet(input)
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local row = {}
    local query = nil
    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "Queue.")
    parentObjInstance = string.sub(param, 1, endIdx+2)
    
    --read the rowId mapping to qosClassQueue
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from qosClassQueue 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("qosClassQueue", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = row["QueueEnabled"]
    elseif(string.find(input["param"], "Status")) then
        -- Status
        if(row["QueueEnabled"] == "1") then
            value = "Enabled"
        else
            value = "Disabled"
        end
    elseif(string.find(input["param"], "Alias")) then
        -- Alias
        if(row["ConfigDefault"] == "1") then
            value = "default" .. row["QueueKey"]
        else
            value = "custom" .. row["QueueKey"]
        end
    elseif(string.find(input["param"], "TrafficClasses")) then
        -- TrafficClasses
        local classfierList = qosTr.mappedClassifiersGet(row)

        if(classfierList ~= nil and classfierList ~= "") then
            value = classfierList
        else
            value = "0"
        end
    elseif(string.find(input["param"], "ShapingRate")) then
        -- ShapingRate
        if(row["HTBShapingRate"] ~= nil and row["HTBShapingRate"] ~= "") then
            value = row["HTBShapingRate"]
        else
            value = "0"
        end
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- qosTr.mappedClassifiersGet - get traffic classifiers mapped to the given
--                              bandwidth profile
-- 
-- This function fetches a comma separated list of 'ClassificationKey' from
-- qosClassification tbl of classifiers that map to the given bandwidth profile
--
-- Returns: <valid_string> or ""
]]--
function qosTr.mappedClassifiersGet(bwprofRow)
    local classList = ""
    local query = ""
    local delim = ""
    local k,v

    query = "QueueKey='" .. bwprofRow["QueueKey"] .. "'"
    local classTable = db.getRowsWhere("qosClassification", query)

    if(classTable == nil) then
        return classList; 
    end

    for k,v in pairs(classTable) do
        if(delim == "") then
            delim = ","
        else
            classList = classList .. delim
        end

        classList = classList .. v["qosClassification.ClassificationKey"]
    end

    return classList;
end

--[[
--*****************************************************************************
-- qosTr.bwprofUsageStatus - check if the bwprof is being used
-- 
-- This function checks whether this bwprof is used by any traffic classifier
--
-- Returns: 'BWPROF_IN_USE'/'BWPROF_NOT_IN_USE'
]]--
function qosTr.bwprofUsageStatus(bwprofRow)
    local checkFlag = "0"
    local query = ""
    local k,v

    query = "QueueKey='" .. bwprofRow["QueueKey"] .. "'"
    local classTable = db.getRowsWhere("qosClassification", query)

    if(classTable == nil) then
        return "BWPROF_NOT_IN_USE"; 
    end

    for k,v in pairs(classTable) do
        checkFlag = "1"
    end

    if(checkFlag == "1") then
        return "BWPROF_IN_USE"
    else
        return "BWPROF_NOT_IN_USE"
    end
end

--[[
--*****************************************************************************
-- qosTr.bwprofSet- set bandwidth profile configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.QoS.Queue.0.
--
-- Enable
-- Alias
-- TrafficClasses
-- ShapingRate
--
-- Returns: status
]]--
function qosTr.bwprofSet(input, rowids, actionType, tr69Param)
    local status = "0"
    local row = {}
    local rowId
    local query = nil
    local bwprofConfTbl = {}

    --Skip if this fn has been called only for Device.QoS.Queue.0.Alias
    --or Device.QoS.Queue.0.TrafficClasses
    if(input["qosClassQueue"]["qosClassQueue.QueueEnabled"] == nil and input["qosClassQueue"]["qosClassQueue.HTBShapingRate"] == nil) then
        return 0;
    end

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = "1"
        return "1";
    end

    --find the immediate parent object with instance number or
    --extract the Device.QoS.Queue.0. part from tr69Param
    local startIdx, endIdx
    local parentObjInstance
    startIdx, endIdx = string.find(tr69Param, "Queue.")
    parentObjInstance = string.sub(tr69Param, 1, endIdx+2)
    
    --read the rowId mapping to qosClassQueue
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        status = "1"
        return "1";
    end

    --get correspnding db entry from qosClassQueue 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("qosClassQueue", query, false)
    if(row == nil) then
        status = "1"
        return "1";
    end

    --check if its a default entry
    if(row["ConfigDefault"] == "1") then
        status = "1"
        return "1";
    end

    --check if its in use in which case edit is not allowed
    if(qosTr.bwprofUsageStatus(row) == "BWPROF_IN_USE") then
        status = "1"
        return "1";
    end
    
    bwprofConfTbl = row
    if(input["qosClassQueue"]["qosClassQueue.QueueEnabled"] ~= nil) then
        bwprofConfTbl["QueueEnabled"] = input["qosClassQueue"]["qosClassQueue.QueueEnabled"]
    end
    if(input["qosClassQueue"]["qosClassQueue.HTBShapingRate"] ~= nil) then
        bwprofConfTbl["HTBShapingRate"] = input["qosClassQueue"]["qosClassQueue.HTBShapingRate"]
        bwprofConfTbl["HTBShapingRateMax"] = input["qosClassQueue"]["qosClassQueue.HTBShapingRate"]
    end

    --apply bandwidth profile settings
    local ret, errorCode
    ret, errorCode = qos.classQueue.edit(bwprofConfTbl);
    db.save()

    return 0;
end

--[[
--*****************************************************************************
-- qosTr.trafficClassGet- get traffic class configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.QoS.Classification.0.
--
-- Enable
-- Status
-- SourceIP
-- SourceMask
-- DestPort
-- SourceMACAddress
-- TrafficClass
--
-- Returns: status, value
]]--
function qosTr.trafficClassGet(input)
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local row = {}
    local trafficClassCfgRow = {}
    local query = nil
    local param = input["param"]
    
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "Classification.")
    parentObjInstance = string.sub(param, 1, endIdx+2)
    
    --read the rowId mapping to qosClassQueue
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from qosClassification 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("qosClassification", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    
    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = "1"
    elseif(string.find(input["param"], "Status")) then
        -- Status
		value = "Enabled"
    elseif(string.find(input["param"], "Alias")) then
        -- Alias
        if(row["ConfigDefault"] == "1") then
            value = "default" .. row["ClassificationKey"]
        else
            value = "custom" .. row["ClassificationKey"]
        end
    elseif(string.find(input["param"], "SourceIP")) then
        -- SourceIP
        if(row["SourceIP"] ~= nil and row["SourceIP"] ~= "") then
            value = row["SourceIP"]
        else
            value = "0.0.0.0"
        end
    elseif(string.find(input["param"], "SourceMask")) then
        -- SourceMask
        if(row["SourceMask"] ~= nil and row["SourceMask"] ~= "") then
            value = row["SourceMask"]
        else
            value = "0"
        end
    elseif(string.find(input["param"], "DestPort")) then
        -- DestPort
        if(row["DestPort"] ~= nil and row["DestPort"] ~= "") then
            value = row["DestPort"]
        else
            value = "0"
        end
    elseif(string.find(input["param"], "SourceMACAddress")) then
        -- SourceMACAddress
        if(row["SourceMACAddress"] ~= nil and row["SourceMACAddress"] ~= "") then
            value = row["SourceMACAddress"]
        else
            value = "00:00:00:00:00:00"
        end
    elseif(string.find(input["param"], "TrafficClass")) then
        -- TrafficClass
        value = row["ClassificationKey"]
    elseif(string.find(input["param"], "Protocol")) then
        -- Protocol
        value = row["Protocol"]
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- qosTr.serviceByPortGet - fetch the service corresponding service to the destination
-- port and Protocol
-- 
-- This function fetches the corresponding service row.
--
-- Returns: lua tbl containing a service row or nil
]]--
function qosTr.serviceByPortGet(dstPortStart, protocol)
    local serviceRow = {}
    local query = ""

    query = "DestinationPortStart='" .. dstPortStart .. "'".."and Protocol='" ..protocol .."'"
    serviceRow = db.getRowWhere ("Services", query, false)

    if(serviceRow == nil) then
        return nil; 
    end

    return serviceRow;
end

--[[
--*****************************************************************************
-- qosTr.trafficClassSet- set traffic class configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.QoS.Classification.0.
--
-- Enable
-- Alias
-- SourceIP
-- SourceMask
-- DestPort
-- SourceMACAddress
-- TrafficClass
-- Protocol
--
-- Returns: status
]]--
function qosTr.trafficClassSet(input, rowids, actionType, tr69Param)
    local status = "0"
    local row = {}
    local rowId
    local query = nil
    local trafficClassConfTbl = {}
    
    --Skip if this fn has been called only for Device.QoS.Classification.0.Enable or
    --Device.QoS.Classification.0.Alias or Device.QoS.Classification.0.TrafficClass
    if(input["qosClassification"]["qosClassification.SourceIP"] == nil and
        input["qosClassification"]["qosClassification.SourceMask"] == nil and
        input["qosClassification"]["qosClassification.DestPort"] == nil and
        input["qosClassification"]["qosClassification.SourceMACAddress"] == nil and 
        input["qosClassification"]["qosClassification.Protocol"] == nil and
        input["qosClassification"]["qosClassification.DestPort"] == nil) then
        return 0;
    end
    
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = "1"
        return "1";
    end

    --find the immediate parent object with instance number or extract
    --the Device.QoS.Classification.0. part from tr69Param
    local startIdx, endIdx
    local parentObjInstance
    startIdx, endIdx = string.find(tr69Param, "Classification.")
    parentObjInstance = string.sub(tr69Param, 1, endIdx+2)

    --read the rowId mapping to qosClassification
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        status = "1"
        return "1";
    end

    --get correspnding db entry from qosClassification 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("qosClassification", query, false)
    if(row == nil) then
        status = "1"
        return "1";
    end

    --check if its a default entry
    if(row["ConfigDefault"] == "1") then
        status = "1"
        return "1";
    end

    trafficClassConfTbl = row
    if(input["qosClassification"]["qosClassification.SourceIP"] ~= nil) then
        trafficClassConfTbl["SourceIP"] = input["qosClassification"]["qosClassification.SourceIP"]
        trafficClassConfTbl["SourceMACAddress"] = ""
    end
    if(input["qosClassification"]["qosClassification.SourceMask"] ~= nil) then
        trafficClassConfTbl["SourceMask"] = input["qosClassification"]["qosClassification.SourceMask"]
    end
    
    if(input["qosClassification"]["qosClassification.SourceMACAddress"] ~= nil) then
        trafficClassConfTbl["SourceMACAddress"] = input["qosClassification"]["qosClassification.SourceMACAddress"]
        trafficClassConfTbl["SourceIP"] = ""
    end
    
    -- Mapping protocol and destPort.  
    local confTbl = {}
    local serviceRow = {}
    if(input["qosClassification"]["qosClassification.DestPort"] ~= nil) then
        confTbl ["DestPort"] = input["qosClassification"]["qosClassification.DestPort"]
        confTbl ["Protocol"] = trafficClassConfTbl ["Protocol"]
    end
        
    if(input["qosClassification"]["qosClassification.Protocol"] ~= nil) then
        confTbl["Protocol"] = input["qosClassification"]["qosClassification.Protocol"]
        confTbl ["DestPort"] = trafficClassConfTbl ["DestPort"]
    end
    
    if(input["qosClassification"]["qosClassification.Protocol"] ~= nil and input["qosClassification"]["qosClassification.DestPort"] ~= nil) then
        confTbl["Protocol"] = input["qosClassification"]["qosClassification.Protocol"]
        confTbl ["DestPort"] = input["qosClassification"]["qosClassification.DestPort"]
    end
    
    if (confTbl["DestPort"] ~= nil or confTbl["Protocol"] ~= nil) then
        serviceRow = qosTr.serviceByPortGet(confTbl["DestPort"], confTbl["Protocol"])
        if(serviceRow == nil or serviceRow == "") then
            status = "1"
            return "1";
        end
    end
   
    if (serviceRow["DestinationPortStart"] ~= nil) then
        trafficClassConfTbl["DestPort"] = serviceRow["DestinationPortStart"]
    end
    if (serviceRow["Protocol"] ~= nil) then
        trafficClassConfTbl["Protocol"] = serviceRow["Protocol"] 
    end
    if (serviceRow["DestinationPortEnd"] ~= nil) then
        trafficClassConfTbl["DestPortRangeMax"] = serviceRow["DestinationPortEnd"]
    end
    if (serviceRow["ServiceName"] ~= nil) then
        trafficClassConfTbl["Service"] = serviceRow["ServiceName"]
    end
    
    --apply traffic classifier settings
    local ret, errorCode
    ret, errorCode = qos.rule.edit(trafficClassConfTbl);
    db.save()

    return 0;
end

