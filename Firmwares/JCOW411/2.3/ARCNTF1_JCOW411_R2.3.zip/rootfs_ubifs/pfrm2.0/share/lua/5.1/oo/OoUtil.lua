--[[
		Copyright(c) 2008, 2009 - TeamF1, Inc.
		All rights reserved.
OoUtil.lua -- This class implements util functions to implement OO inheritance.

  $Id: OoUtil.lua 1210 2011-01-22 17:26:04Z prasanna@teamf1.com $ 
]]--

OoUtil = {}

-- Create a new class that inherits from a base class
--
function OoUtil.inheritsFrom( baseClass )

    local new_class = {}
    local class_mt = { __index = new_class }

    function new_class:create()
        local newinst = {}
        setmetatable( newinst, class_mt )
        return newinst
    end

    if nil ~= baseClass then
        setmetatable( new_class, { __index = baseClass } )
    end

    -- Implementation of additional OO properties starts here --

    -- Return the class object of the instance
    function new_class:class()
        return new_class
    end

    -- Return the super class object of the instance
    function new_class:superClass()
        return baseClass
    end

    -- Return true if the caller is an instance of theClass
    function new_class:isa( theClass )
        local b_isa = false

        local cur_class = new_class

        while ( nil ~= cur_class ) and ( false == b_isa ) do
            if cur_class == theClass then
                b_isa = true
            else
                cur_class = cur_class:superClass()
            end
        end

        return b_isa
    end


    -- dump hierarchy for debugging purposes
    function new_class:dump_hier( theClass )
       local cur_class = new_class
       local hier = ""
       while ( nil ~= cur_class ) do
          hier = hier .. " ->> " .. tostring(cur_class)
          cur_class = cur_class:superClass()
       end
       print (hier)
    end

    return new_class
end



