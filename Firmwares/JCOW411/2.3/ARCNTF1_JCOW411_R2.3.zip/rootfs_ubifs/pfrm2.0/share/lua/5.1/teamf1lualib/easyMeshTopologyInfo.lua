--[[ easyMeshTopology.lua - Handler for Easy Mesh Topology request
--
-- Copyright (c) 2008-2019, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: easyMeshTopology.lua
-- Description: Handler for Easy Mesh Topology  request
-- 
-- modification history
-- --------------------
-- 01a, 1jun2020, vin written.
--
--]]

require "easyMeshLib"
require "teamf1lualib/easyMeshTopologyInfoLib"

-- Topology Object as defined by Customer Specification.
local TopologyRequestObj = {
    ["Topology"]      = {}
}

-- List of Topology Tags as defined by Customer Specification.
local TopologyObj = {
    ["Result"] = "Result"
}

-- Initialise the TopologyResponse_t Lua Table which will be coverted as JSON Object
local TopologyResponse_t = {
    ["Result"] = "ERROR",
    ["Response_Code"] = "400",
    ["Error_Message"] = "Failed to get WiFiSON"
}

-- Supported Return Codes for "LoginResponse"
local TopologyResponse_ReturnCodes = {
    ["OK"] = "OK",
    ["ERROR"] = "ERROR",
    ["SUCCESS"] = "Success",
    ["FAILED"]  = "Failed",
}

if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then
	TOPOLOGY_DUMP_GENERATE_CMD = "/bin/sh /pfrm2.0/bin/brcmGenerateDump.sh"
else
	TOPOLOGY_DUMP_GENERATE_CMD = "/userfs/bin/mapd_cli /tmp/mapd_ctrl dump_topology_v1"
end
TOPOLOGY_DUMP_FILE = "/tmp/dump.txt"
INTERNET_FILE_CHECK = "/tmp/gponFailed"


----------------------------------------------------------------------------------
-- @name getEasyMeshTopologyHandler
--
-- @description This function Handles EasyMesh Topology (WiFiSON) Request Method.
--
-- @return JSON response to EasyMesh Topology request
--
function getEasyMeshTopologyInfoHandler(methodObj, meshRequestMethod)
   
    local status
    local TopologyObj    = methodObj["Topology"]
    local topology_t

    if ((TopologyObj == nil) or (type(TopologyObj) ~= "table")) then
        TopologyResponse_t["Result"] = TopologyResponse_ReturnCodes["FAILED"]
        TopologyResponse_t["Response_Code"] = "400"
        TopologyResponse_t["Error_Message"] = "Bad Request"
        --mesh.sendResponse (TopologyResponse_t) 
        return "ERROR", "INVALID_METHOD" ,TopologyResponse_t
    end

    -- generate topology dump.txt by executing below command.
    util.runShellCmd(TOPOLOGY_DUMP_GENERATE_CMD, "/dev/null")

    if (not (util.fileExists (TOPOLOGY_DUMP_FILE))) then
        status,TopologyResponse_t = easyMeshTopologyInfoLib.getMeshTopologyController()
         if (util.fileExists (INTERNET_FILE_CHECK)) then
            TopologyResponse_t[WIFISON_INTERNET] = "0"
        else
            TopologyResponse_t[WIFISON_INTERNET] = "1"
        end
        TopologyResponse_t[WIFISON_NUMBER] = "1"
        TopologyResponse_t["Result"] = TopologyResponse_ReturnCodes["OK"]
        TopologyResponse_t["Response_Code"] = "200"
        TopologyResponse_t["Error_Message"] = nil
        --mesh.sendResponse (TopologyResponse_t) 
        return "OK", "SUCCESS", TopologyResponse_t
    end

    -- convert the generated topology dump.txt file to a Lua Table
    topology_t = json.decode(util.fileToString (TOPOLOGY_DUMP_FILE))

    if (topology_t == nil) then
        TopologyResponse_t["Result"] = TopologyResponse_ReturnCodes["FAILED"]
        TopologyResponse_t["Response_Code"] = "501"
        TopologyResponse_t["Error_Message"] = "No Data Available"
        --mesh.sendResponse (TopologyResponse_t) 
        return "ERROR", "INVALID_METHOD", TopologyResponse_t
    end

    status, TopologyResponse_t = easyMeshTopologyInfoLib.getMeshTopologyNodes(topology_t)
    if (status ~= "OK") then
        TopologyResponse_t["Result"] = TopologyResponse_ReturnCodes["FAILED"]
        TopologyResponse_t["Response_Code"] = "501"
        TopologyResponse_t["Error_Message"] = "No Data Available"
        --mesh.sendResponse (TopologyResponse_t) 
        return "ERROR", "INVALID_METHOD", TopologyResponse_t
    end

    TopologyResponse_t[WIFISON_NUMBER] = #TopologyResponse_t[WIFISON_NODE]

    if (util.fileExists (INTERNET_FILE_CHECK)) then
        TopologyResponse_t[WIFISON_INTERNET] = "0"
    else
        TopologyResponse_t[WIFISON_INTERNET] = "1"
    end
    TopologyResponse_t["Result"] = TopologyResponse_ReturnCodes["OK"]
    TopologyResponse_t["Response_Code"] = "200"
    TopologyResponse_t["Error_Message"] = nil
    
    --mesh.sendResponse (TopologyResponse_t) 
    return "OK", "SUCCESS", TopologyResponse_t
end

meshRequestMethodsList["Topology"]["methodHandler"] = getEasyMeshTopologyInfoHandler

