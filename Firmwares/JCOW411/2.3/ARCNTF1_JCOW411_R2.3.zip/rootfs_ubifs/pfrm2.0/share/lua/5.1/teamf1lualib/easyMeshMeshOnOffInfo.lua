--[[ easyMeshMeshOnOffInfo.lua - Handler for EasyMesh Mesh On Off Change.
--
-- Copyright (c) 2008-2014, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: easyMeshMeshOnOff.lua
-- Description: Handler for EasyMesh Mesh On off Change.
-- 
-- modification history
-- --------------------
-- 01a, 15Jun21, vin written.
--
--]]

require "easyMeshLib"
require "ifDevLib"
require "teamf1lualib/dot11"
require "teamf1lualib/dot11_ul"
require "teamf1lualib/gui"


local CMD_EXEC_SCRIPT = "/tmp/cmdExecscript.sh"
local SH_BIN          = "/bin/sh "


-- Initialise the SSIDGetResponse_t Lua Table which will be coverted as JSON Object
local MeshSetResponse_t = {
    ["Result"] = "ERROR",
    ["Response_Code"] = "400",
    ["Error_Message"] = "Failed to Set MeshConfig"
}

-- Supported Return Codes for "SSIDGetResponse"
local MeshSetResponse_ReturnCodes = {
    ["OK"] = "OK",
    ["ERROR"] = "ERROR",
    ["SUCCESS"] = "Success",
    ["FAILED"]  = "Failed",
}


----------------------------------------------
--MESH On Off Set Request
--
-- @description This function Handles EasyMesh MESH On Off Set Request Method.
--
--returns JSON response for EasyMesh MeshOnOff Set Request
--
function MeshOnOffInfoHandler(methodObj, meshRequestMethod)

    require "teamf1lualib/easyMeshMgmt"
    local status = "ERROR"
    local errorFlag
    local inputTable = {}
    local rowid="1"
  
    inputTable["meshEnable"] = methodObj["Mesh_Enable"]
--    inputTable["Device_Mac"] = methodObj["Device_MAC"]
    
    --sanity Check
    
  --  if((inputTable["meshEnable"] == nil) or (inputTable["Device_Mac"] == nil) or (string.upper(inputTable["Device_Mac"]) ~= ifDevLib.getMac("bdg2")) ) then
    if((inputTable["meshEnable"] == nil)) then
        MeshSetResponse_t["Result"] = MeshSetResponse_ReturnCodes["FAILED"]  
        MeshSetResponse_t["Response_Code"] = "400"
        MeshSetResponse_t["Error_Message"] = "Bad Request"
        --mesh.sendResponse (MeshSetResponse_t) 
        return "ERROR", "INVALID_METHOD", MeshSetResponse_t
    end

    
    local easyMeshRow = db.getRowWhere("easyMesh", "_ROWID_ ='" ..rowid.."'" , false)
    
    if(easyMeshRow["meshEnable"] == inputTable["meshEnable"]) then
            status = "OK"
    end

    if(status == "OK") then
        MeshSetResponse_t["Result"] = MeshSetResponse_ReturnCodes["OK"]  
        MeshSetResponse_t["Error_Message"] = nil
        MeshSetResponse_t["Response_Code"] = "200"
        MeshSetResponse_t["Device_Mac"] = ifDevLib.getMac("bdg2")
        --mesh.sendResponse (MeshSetResponse_t) 
        return "OK", "SUCCESS", MeshSetResponse_t
    end

    ----Checking When Wifi is Disabled We can not do any Wifi Operations 
     
    local wifienabled = db.getAttribute("easyMesh","meshInterfacename","bdg2","wifiOn")
    
    if(wifienabled == "0") then
        MeshSetResponse_t["Result"] = MeshSetResponse_ReturnCodes["FAILED"]  
        MeshSetResponse_t["Response_Code"] = "400"
        MeshSetResponse_t["Error_Message"] = "WiFi is Disabled,No WiFi Operation is Allowed"
        --mesh.sendResponse (MeshSetResponse_t) 
        return "ERROR", "INVALID_METHOD",MeshSetResponse_t
    end
    
    --MeshOnOff 
   status,errorFlag = easyMeshMgmt.easyMeshSet(inputTable) 

    if(status ~= "OK") then
        MeshSetResponse_t["Result"] = MeshSetResponse_ReturnCodes["FAILED"]  
        MeshSetResponse_t["Response_Code"] = "400"
        MeshSetResponse_t["Error_Message"] = "Bad Request"
        --mesh.sendResponse (MeshSetResponse_t) 
        return "ERROR", "INVALID_METHOD",MeshSetResponse_t
    end    
 
    db.save2()
    
    MeshSetResponse_t["Result"] = MeshSetResponse_ReturnCodes["OK"]  
    MeshSetResponse_t["Error_Message"] = nil
    MeshSetResponse_t["Response_Code"] = "200"
    MeshSetResponse_t["Device_Mac"] =  ifDevLib.getMac("bdg2")
    --mesh.sendResponse (MeshSetResponse_t)
    --Rebooting the Device When Mesh is Enabled/Disable
    
    db.setAttribute ("reboot", "reboot._ROWID_", "1", "rebootTime", "10")
	db.setAttribute ("reboot", "reboot._ROWID_", "1", "reboot", "1")
    

    return "OK", "SUCCESS", MeshSetResponse_t

end

meshRequestMethodsList["MeshOnOff"]["methodHandler"] = MeshOnOffInfoHandler

