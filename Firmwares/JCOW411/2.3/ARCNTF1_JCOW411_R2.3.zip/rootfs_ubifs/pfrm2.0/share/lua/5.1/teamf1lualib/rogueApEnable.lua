
-- gui.rogueAPEnable.lua 

-- Copywrite (c) 2013 TeamF1, Inc.

--
-- modification history
-- --------------------
-- 01a, 12Mar13, sen dervied from reference solution. for RIL.


-------------------------------------------------------------------------------
-- This file is being called from rc script to trigger RogueAPCheckEnable/Rogue
-- APCheckDisable functions to persist rogueAP changes after reboot/upgrade 
-------------------------------------------------------------------------------
require "teamf1lualib/gui"
ACCESS_LEVEL = 0
db.connect("/tmp/system.db")

local rogueCfg = {}
local query = "_ROWID_ = 1"
local value 
value = db.getAttribute("environment", "name", "BOOTSTRAP", "value")
-- for upgrade/reboot case
if(tonumber(value)== 0) then   
    rogueCfg = db.getRowWhere("dot11Radio",query,false)    
    gui.wireless.rogueap.set(rogueCfg)
end
