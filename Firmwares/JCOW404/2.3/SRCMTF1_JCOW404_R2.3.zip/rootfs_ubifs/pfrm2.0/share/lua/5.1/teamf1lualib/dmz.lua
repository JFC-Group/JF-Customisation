require "teamf1lualib/firewall"

dmz = {}
-------------------------------------------------------------------------------
-- @name : firewall.dmzGet()
--
-- @description : API to return 'dmz' table
--
-- @return : Entire dmz table
-- 
function dmz.dmzGet ()
    local dmzTbl = {}
    dmzTbl = db.getRow ("dmz", "_ROWID_", "1")     
    return dmzTbl
end
-------------------------------------------------------------------------------
-- @name : firewall.dmzSet()
--
-- @description : API to set values in 'dmz' table
--
-- @return : None
-- 
function dmz.dmzSet (dmzTable)

    local ifStaticTbl = {}
    local query = "LogicalIfName='IF2' AND AddressFamily=2"

    -- getting the ifStatic table
    
    ifStaticTbl = db.getRowWhere("ifStatic", query, false)
    if (dmzTable["dmz.ipAddr"] == ifStaticTbl["StaticIp"]) then 
    	return "ERROR", "Configured IP belongs to LAN ip address,please configure other valid ip address"
    end

    statusFlag = fw.config ("dmz", dmzTable, "1", "edit")
    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "Dmz configuration failed"
    end  
end


-------------------------------------------------------------------------------
-- @name : firewall.dmz6Get()
--
-- @description : API to return 'dmz' table
--
-- @return : Entire dmz table
-- 
function dmz.dmz6Get ()
    local dmzTbl = {}
    dmzTbl = db.getRow ("dmz6", "_ROWID_", "1")     
    return dmzTbl
end
-------------------------------------------------------------------------------
-- @name : firewall.dmz6Set()
--
-- @description : API to set values in 'dmz' table
--
-- @return : None
-- 
function dmz.dmz6Set (dmzTable)

    local query = "LogicalIfName='IF2' AND AddressFamily=10"
    local dmzipaddr = nil
    local StaticIp = {} 
    
    -- getting the ifStatic table
    local  ifStaticTbl = db.getRowsWhere("ipAddressTable", query, false) 

    -- Converting IPV6 to Standard form
    if(dmzTable["dmz6.ipAddr"] ~= nil )  then
        dmzipaddr = validations.ipv6Convert(dmzTable["dmz6.ipAddr"])                                             
    end
    for k , v in pairs(ifStaticTbl) do                                                                        
        StaticIp[k]  = validations.ipv6Convert(ifStaticTbl[k]["ipAddress"])                                      
    end          

    -- check if the ipv6 is not a link-local address
    if (dmzipaddr ~= nil) then
        if (string.match(dmzipaddr, '^fe80') or string.match(dmzipaddr, '^FE80')) then
            return "ERROR", "Cannot configure a Link-Local Address" 
        end
    end

     -- check if the ipv6 is a reserved address
    if (dmzipaddr ~= nil) then
        if (ifDevLib.isIpv6AddressReserved(dmzipaddr) > 0) then
            status = "ERROR"
            errCode = "RESERVED_IPV6_ADDRESS1"
            return status, errCode
        elseif(ifDevLib.isIpv6AddressMulticast(dmzipaddr) > 0) then
            status = "ERROR"
            errCode = "MULTICAST_IPV6_ADDRESS"
            return status, errCode
        end
    end

   --[[ local query1 = "LogicalIfName='IF2'"      
     local row = db.getRowWhere("radvdLANPrefixPool", query1, false)
                                                                               
    row["radvdAdvPrefix"] =  string.gsub(row["radvdAdvPrefix"],"::",":")   
                                                                   
    if (dmzipaddr ~= nil) then                       
        if (string.match(dmzipaddr, row["radvdAdvPrefix"]) == nil  ) then
            return "ERROR", "DMZ IP MUST BE IN LAN SUBNET "                            
        end                                                                            
    end  ]]--                
    
    -- Comparing DMZ IP with LAN 
    for k,v in pairs ( StaticIp ) do
        if( dmzipaddr ==  StaticIp[k] ) then
        	return "ERROR", "Configured IP belongs to LAN ip address,please configure other valid ip address"
        end
    end
    statusFlag = fw.config ("dmz6", dmzTable, "1", "edit")
    if (statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "Dmz configuration failed"
    end  
end
