--[[
#### 
#### File: routedTrExtn.lua
#### Description: 
#### TR-181 handlers for routed. This file is included from
#### tr69Glue code.
####

#### Revisions:
01b,08oct15,swr  Fix for SPR 53600.
01a,10may14,swr  written.
]]--

routedTr = {}

--[[
--*****************************************************************************
--  routedTr.ripStatusGet: get parameters for Rip
--
-- This function gets values for the following parameters -
--
-- Device.Routing.RIP.
-- Enable
-- Status
--
-- RETURN: 0 for success, > 0 for failure 
]]--

function routedTr.ripStatusGet(input)
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local row = {}
    local query = nil
    local param = input["param"]
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()

    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    query = "_ROWID_=1"
    row = db.getRowWhere ("Rip", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        if (row["Version"] == "1" or row["Version"] == "2" or row["Version"] == "3") then
            value = "1"
        elseif (row["Version"] == "0") then
            value = "0"
        end
    end
    tr69Glue.tf1Dbg ("Value = " .. value)
    return status, value
end

--[[
--*****************************************************************************
--  routedTr.ripGet: get parameters for Rip
--
-- This function gets values for the following parameters -
--
-- Device.Routing.RIP.InterfaceSetting.0.
-- Enable
-- Status
--
-- RETURN: 0 for success, > 0 for failure 
]]--
function routedTr.ripGet(input)
    local status = "0"
    local value = "0"
    local rowId
    local parentObjInstance = ""
    local row = {}
    local query = nil
    local param = input["param"]
    
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "InterfaceSetting.")
    parentObjInstance = string.sub(param, 1, endIdx+2)
   
    --read the rowId mapping to qosClassQueue
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from qosClassification 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("Rip", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        if (row["Version"] == "1" or row["Version"] == "2" or row["Version"] == "3") then
            value = "1"
        elseif (row["Version"] == "0") then
            value = "0"
        end
    elseif(string.find(input["param"], "Status")) then
        -- Status
        if (row["Version"] == "1" or row["Version"] == "2" or row["Version"] == "3") then
            value = "Enabled"
        elseif (row["Version"] == "0") then
            value = "Disabled"
        end
    elseif(string.find(input["param"], "Alias")) then
        -- Alias
        value = "Rip"..rowId
    elseif(string.find(input["param"], "AcceptRA")) then
        -- AcceptRA
        if(row["Direction"] == "1" or row["Direction"] == "3")  then
            value = "1"
        elseif(row["Direction"] == "0" or row["Direction"] == "2") then
            value = "0"
        end
    elseif(string.find(input["param"], "SendRA")) then
        -- SendRA
        if(row["Direction"] == "2" or row["Direction"] == "3")  then
            value = "1"
        elseif(row["Direction"] == "0" or row["Direction"] == "1") then
            value = "0"
        end
    elseif((string.sub(input["param"], 39, -1)) == "Interface") then
        -- Interface
        value = "Device.IP.Interface.2.,Device.IP.Interface.1."
    elseif(string.find(input["param"], "Version")) then
        -- Version
        if(row["Version"] == "0") then
            value = "Disabled"
        elseif(row["Version"] == "1") then
            value = "RIP-1"
        elseif(row["Version"] == "2") then
            value = "RIP-2B"
        elseif(row["Version"] == "3") then
            value = "RIP-2M"
        end
    end

    tr69Glue.tf1Dbg ("Value = " .. value)
    return status, value
end

--[[
--*****************************************************************************
--  routedTr.ripSet: set parameters for Rip
--
-- This function gets values for the following parameters -
--
-- Device.Routing.RIP.InterfaceSetting.0.
-- Enable
-- AcceptRA
-- SendRA
--
-- RETURN: 0 for success, > 0 for failure 
]]--

function routedTr.ripSet(input, rowids, actionType, tr69Param)
     -- require
    require "teamf1lualib/rip"

    local status = "0"
    local errMsg
    local row = {}
    local ripTbl = {}
    local rowId
    local query = nil
    local logicalIfName
    local faultTbl = {}
    local index = 0
    
    --Skip if this fn has been called only for Device.Routing.RIP.InterfaceSetting.0.Alias
    --and Device.Routing.RIP.InterfaceSetting.0.interfaceObject
    if(input["Rip"]["Rip.Enable"] == nil and
        input["Rip"]["Rip.AcceptRA"] == nil and
        input["Rip"]["Rip.Version"] == nil and
        input["Rip"]["Rip.SendRA"] == nil) then
        return 0;
    end
    
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
       status = ERROR
       index = index + 1
       faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
       return status, faultTbl
    end

    --find the immediate parent object with instance number or extract
    --the Device.Routing.Router.0.IPv4Forwarding.0. part from tr69Param
    local startIdx, endIdx
    local parentObjInstance
    startIdx, endIdx = string.find(tr69Param, "InterfaceSetting.")
    parentObjInstance = string.sub(tr69Param, 1, endIdx+2)

    --read the rowId mapping to qosClassification
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    --get correspnding db entry from qosClassification 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("Rip", query, false)
    if(row == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    ripTbl = row
    if(input["Rip"]["Rip.Enable"] ~= nil) then
        ripTbl["Version"] = input["Rip"]["Rip.Enable"]
    end 
   
    if(input["Rip"]["Rip.Version"] ~= nil) then
        if(input["Rip"]["Rip.Version"] == "Disabled") then
            ripTbl["Version"] = "0"
        elseif(input["Rip"]["Rip.Version"] == "RIP-1") then
            ripTbl["Version"] = "1"
        elseif(input["Rip"]["Rip.Version"] == "RIP-2B") then
            ripTbl["Version"] = "2"
        elseif(input["Rip"]["Rip.Version"] == "RIP-2M") then
            ripTbl["Version"] = "3"
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Version", error_code.INVALID_PARAM_VALUE)
        end
    end

    if(input["Rip"]["Rip.AcceptRA"] ~= nil) then
        if(input["Rip"]["Rip.AcceptRA"] == "0") then
            if(ripTbl["Direction"] == "0") then
                ripTbl["Direction"] = "0"
            elseif(ripTbl["Direction"] == "1") then
                ripTbl["Direction"] = "0"
            elseif(ripTbl["Direction"] == "2") then
                ripTbl["Direction"] = "2"
            elseif(ripTbl["Direction"] == "3") then
                ripTbl["Direction"] = "2"
            end
        elseif(input["Rip"]["Rip.AcceptRA"] == "1") then
            if(ripTbl["Direction"] == "0") then
                ripTbl["Direction"] = "1"
            elseif(ripTbl["Direction"] == "1") then
                ripTbl["Direction"] = "1"
            elseif(ripTbl["Direction"] == "2") then
                ripTbl["Direction"] = "3"
            elseif(ripTbl["Direction"] == "3") then
                ripTbl["Direction"] = "3"
            end
        end
    end

    if(input["Rip"]["Rip.SendRA"] ~= nil) then
        if(input["Rip"]["Rip.SendRA"] == "0") then
            if(ripTbl["Direction"] == "0") then
                ripTbl["Direction"] = "0"
            elseif(ripTbl["Direction"] == "1") then
                ripTbl["Direction"] = "1"
            elseif(ripTbl["Direction"] == "2") then
                ripTbl["Direction"] = "0"
            elseif(ripTbl["Direction"] == "3") then
                ripTbl["Direction"] = "1"
            end
        elseif(input["Rip"]["Rip.SendRA"] == "1") then
            if(ripTbl["Direction"] == "0") then
                ripTbl["Direction"] = "2"
            elseif(ripTbl["Direction"] == "1") then
                ripTbl["Direction"] = "3"
            elseif(ripTbl["Direction"] == "2") then
                ripTbl["Direction"] = "2"
            elseif(ripTbl["Direction"] == "3") then
                ripTbl["Direction"] = "3"
            end
        end
    end

    if (status == OK) then
       ripTbl = util.addPrefix (ripTbl, "Rip.")
       local valid = db.update ("Rip", ripTbl, "1")

       if(valid) then
           db.save()
           return 0;
       else
           status = ERROR
           index = index + 1
           faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
           return status, faultTbl;
       end
    end

    return status, faultTbl

end

--[[
--*****************************************************************************
--  routedTr.ripStatusSet: set parameters for Rip
--
-- This function gets values for the following parameters -
--
-- Device.Routing.RIP.
-- Enable
--
-- RETURN: 0 for success, > 0 for failure 
]]--

function routedTr.ripStatusSet(input, rowids, actionType, tr69Param)
     -- require
    require "teamf1lualib/rip"
    local status = "0"
    local errMsg
    local row = {}
    local ripTbl = {}
    local rowId
    local query = nil
    local logicalIfName
    
    if(input["Rip"]["Rip.Enable"] == nil) then
        return 0;
    end
    
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = "1"
        return "1";
    end

    query = "_ROWID_= 1"
    row = db.getRowWhere ("Rip", query, false)
    if(row == nil) then
        status = "1"
        return "1";
    end

    local enable = tonumber(input["Rip"]["Rip.Enable"])

    local valid , errstr = db.setAttribute ("Rip", "_ROWID_", "1", "Version", enable)
    if (not valid) then
        return "ERROR", "RIP_CONFIG_FAILED", errstr
    end

    -- savedb if no error
    if(errMsg == "OK") then db.save() end

    -- return
    return 0;
end
