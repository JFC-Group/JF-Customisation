--[[
#### Adarsh Uppula
#### TeamF1
#### www.TeamF1.com
#### June 29, 2007

#### File: radius.lua
#### Description: radius functions

#### Revisions:
01c,29Aug17,sjr changes for WIFI optimization
01b,24Aug17,sjr changes for 59560.
01a,08Oct13,ash Changes for password encryption/decryption
]]--


--************* Requires *************
require "passwdSecureLib"

--************* Initial Code *************

--package radius
radius = {}
radiusClient = {}
radiusAttributes = {}
das = {}
radiusDas = {}
--************* Functions *************

-- das config
function das.das_config (inputTable, rowid, operation)
	
    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
    local valid = false

    -- das radius
    valid = das.config(inputTable, rowid, operation)
	
    -- return
    if (valid) then
        require "teamf1lualib/dot11"
        if(util.fileExists("/pfrm2.0/BRCMJCO300") and operation == "edit")then
            local WLCONF_CMD_BINARY = "/bin/wlconf"
            local CMD_EXEC_SCRIPT  = "/tmp/cmdExecscript.sh"
            local radioTable = db.getTable("dot11Radio",true)
            local ifTbl = db.getTable("dot11Interface", false)
            local interface
            local cmd = ""
            -- for rowid 1 set the values in nvram for both wireless interfaces
            -- TODO check if broadcom nas utility supports more than 1 radius server
            for key,value in pairs(ifTbl) do
                interface = value["interfaceName"]
                if (rowid == "1" or inputTable["radiusDas._ROWID_"] == '1') then
                    if(inputTable["radiusDas.dasSecret"] ~= nil)then
                        nvramSetCmdWrite(interface, "radius_das_key", inputTable["radiusDas.dasSecret"])
                    else
                        local radius_das_key = db.getAttribute("radiusDas","_ROWID_","1","dasSecret")
                        if(radius_das_key ~= nil) then
                            nvramSetCmdWrite(interface, "radius_das_key", radius_das_key)
                        end
                    end
                    if(inputTable["radiusDas.dasServerPort"] ~= nil)then
                        nvramSetCmdWrite(interface, "radius_das_port", inputTable["radiusDas.dasServerPort"])
                    else
                        nvramSetCmdWrite(interface, "radius_das_port", "3799")
                    end
                    if(inputTable["radiusDas.dasClient"] ~= nil)then
                        nvramSetCmdWrite(interface, "radius_das_ipaddr", inputTable["radiusDas.dasClient"])
                    end
                    if(inputTable["radiusDas.dasTimeWindow"] ~= nil)then
                        nvramSetCmdWrite(interface, "das_time_window", inputTable["radiusDas.dasTimeWindow"])
                    end
                    if(inputTable["radiusDas.dasRequireTimeStamp"] ~= nil)then
                        nvramSetCmdWrite(interface, "das_require_event_time_stamp", inputTable["radiusDas.dasRequireTimeStamp"])
                    end
                    if(inputTable["radiusDas.dasRequireMsgAuth"] ~= nil)then
                        nvramSetCmdWrite(interface, "das_require_msg_auth", inputTable["radiusDas.dasRequireMsgAuth"])
                    end
                    --This will be taken care by radius_config
                    --cmd = "echo \'nvram commit\' >> "..CMD_EXEC_SCRIPT
                    --os.execute (cmd)
                else
                    if(rowid == "-1")then
                        local inputTable = db.getRowWhere("radiusDas","_ROWID_='1'",true)
                        if(inputTable ~= nil and inputTable["radiusDas.dasSecret"] ~= nil)then
                            nvramSetCmdWrite(interface, "radius_das_key", inputTable["radiusDas.dasSecret"])
                        end
                        if(inputTable ~= nil and inputTable["radiusDas.dasServerPort"] ~= nil)then
                            nvramSetCmdWrite(interface, "radius_das_port", inputTable["radiusDas.dasServerPort"])
                        else
                            nvramSetCmdWrite(interface, "radius_das_port", "3799")
                        end
                        if(inputTable ~= nil and inputTable["radiusDas.dasClient"] ~= nil)then
                            nvramSetCmdWrite(interface, "radius_das_ipaddr", inputTable["radiusDas.dasClient"])
                        end
                        if(inputTable ~= nil and inputTable["radiusDas.dasTimeWindow"] ~= nil)then
                            nvramSetCmdWrite(interface, "das_time_window", inputTable["radiusDas.dasTimeWindow"])
                        end
                        if(inputTable ~= nil and inputTable["radiusDas.dasRequireTimeStamp"] ~= nil)then
                            nvramSetCmdWrite(interface, "das_require_event_time_stamp", inputTable["radiusDas.dasRequireTimeStamp"])
                        end
                        if(inputTable ~= nil and inputTable["radiusDas.dasRequireMsgAuth"] ~= nil)then
                            nvramSetCmdWrite(interface, "das_require_msg_auth", inputTable["radiusDas.dasRequireMsgAuth"])
                        end
			--This will be taken care by radius_config
                        --cmd = "echo \'nvram commit\' >> "..CMD_EXEC_SCRIPT
                        --os.execute (cmd)
                    end
                end
            end
	    --This will be taken care by radius_config
            --[[
            if(radioTable ~= nil)then
                for k,v in pairs(radioTable)do
                    local inputTable = v
                    local dot11Radios = db.getRowsWhere ("dot11Radio", "radioNo = " .. inputTable["dot11Radio.radioNo"], false)
                    local radioInterface = dot11Radios[1]["interfaceName"]
                    cmd = WLCONF_CMD_BINARY .." "..radioInterface.. " up"
                    wlconfExclude(CMD_EXEC_SCRIPT,cmd)
                end
            end

            dot11.ServiceStopStart2 (false)
            dot11.ServiceStopStart2 (true)

            if(radioTable ~= nil)then
                for k,v in pairs(radioTable)do
                    local inputTable = v
                    local dot11Radios = db.getRowsWhere ("dot11Radio", "radioNo = " .. inputTable["dot11Radio.radioNo"], false)
                    local radioInterface = dot11Radios[1]["interfaceName"]
                    cmd = WLCONF_CMD_BINARY .." "..radioInterface.. " start"
                    wlconfExclude(CMD_EXEC_SCRIPT,cmd)
                end
            end

            for k,v in pairs(ifTbl)do                                                                                                         
                local inputTable = v                                                                                                                   
                wlCmdWrite(inputTable["interfaceName"], "phy_ed_thresh", "-50")
            end
            ]]--
        elseif (util.fileExists("/pfrm2.0/HW_JCO410") or util.fileExists("/pfrm2.0/HW_JCE410")) then
            if (operation == "edit") then
                bootFlag = "0"
            else
                bootFlag = "1"
            end
	    --This will be taken care by radius_config
            --[[
            local profileTable = db.getTable("dot11Profile",true)
            if(profileTable ~= nil)then
                for k,v in pairs(profileTable)do
                    local inputTable = v
                    if(inputTable["dot11Profile.authMethods"] == "RADIUS")then
                        local vapName = db.getAttribute("dot11VAP","profileName",inputTable["dot11Profile.profileName"],"vapName")
                        local vapEnabled = db.getAttribute("dot11VAP","profileName",inputTable["dot11Profile.profileName"],"vapEnabled")
                        local vapInterface = db.getAttribute("dot11Interface","vapName",vapName,"interfaceName")
                        hostapd_stop(vapInterface,bootFlag)
                        hostapd_create_config(vapInterface,bootFlag)
                        if(vapEnabled == "1")then
                            if (bootFlag == "1") then
                                hostapd_start_boot(vapInterface)
                            else
                                hostapd_start(vapInterface)
                            end
                        end
                    end
                end 
            end
            ]]--
        end
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DAS_CONFIG_FAILED"
    end

end

-- radius config
function radius.radius_config (inputTable, rowid, operation)
	
    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
    local valid = false

    -- config radius
    valid = radius.config(inputTable, rowid, operation)
	
    -- return
    if (valid) then
        require "teamf1lualib/dot11"
        if(util.fileExists("/pfrm2.0/BRCMJCO300") and operation == "edit")then
            local WLCONF_CMD_BINARY = "/bin/wlconf"
            local CMD_EXEC_SCRIPT  = "/tmp/cmdExecscript.sh"

            local radioTable = db.getTable("dot11Radio",true)
            local ifTbl = db.getTable("dot11Interface", false)
            local interface
            local cmd = ""
            -- for rowid 1 set the values in nvram for both wireless interfaces
            -- TODO check if broadcom nas utility supports more than 1 radius server
            for key,value in pairs(ifTbl) do
                interface = value["interfaceName"]
                if (rowid == "1" or inputTable["radiusClient._ROWID_"] == '1') then
                    if(inputTable["radiusClient.authsecret"] ~= nil)then
                        nvramSetCmdWrite(interface, "radius_key", inputTable["radiusClient.authsecret"])
                        if(inputTable["radiusClient.acctsecret"] ~= nil)then
                            nvramSetCmdWrite(interface, "radius_acct_key", inputTable["radiusClient.acctsecret"])
                        else
                            nvramSetCmdWrite(interface, "radius_acct_key", inputTable["radiusClient.authsecret"])
                        end
                    else
                        local radius_key = db.getAttribute("radiusClient","_ROWID_","1","authsecret")
                        if(radius_key ~= nil) then
                            nvramSetCmdWrite(interface, "radius_key", radius_key)
                            local radius_acct_key = db.getAttribute("radiusClient","_ROWID_","1","acctsecret")
                            if(radius_acct_key ~= nil) then
                                nvramSetCmdWrite(interface, "radius_acct_key", radius_acct_key)
                            else
                                nvramSetCmdWrite(interface, "radius_acct_key", radius_key)
                            end
                        end
                    end

                    if(inputTable["radiusClient.authport"] ~= nil)then
                        nvramSetCmdWrite(interface, "radius_port", inputTable["radiusClient.authport"])
                        if(inputTable["radiusClient.acctport"] ~= nil)then
                            nvramSetCmdWrite(interface, "radius_acct_port", inputTable["radiusClient.acctport"])
                        else
                            nvramSetCmdWrite(interface, "radius_acct_port", "1813")
                        end
                    end

                    --Radius IP Type
                    if(inputTable["radiusClient.ipType"] ~= nil)then
                        nvramSetCmdWrite(interface, "radius_iptype", inputTable["radiusClient.ipType"])
                    end
                    
                    --Primary Radius Auth & Acct Servers 
                    if(inputTable["radiusClient.ipType"] ~= nil and inputTable["radiusClient.ipType"] == "0")then
                        if(inputTable["radiusClient.authserver"] ~= nil)then
                            nvramSetCmdWrite(interface, "radius_ipaddr", inputTable["radiusClient.authserver"])
                            if(inputTable["radiusClient.acctserver"] ~= nil)then
                                nvramSetCmdWrite(interface, "radius_acct_ipaddr", inputTable["radiusClient.acctserver"])
                            else
                                nvramSetCmdWrite(interface, "radius_acct_ipaddr", inputTable["radiusClient.authserver"])
                            end
                        end
                    else
                        if(inputTable["radiusClient.authserverIP6"] ~= nil)then
                            nvramSetCmdWrite(interface, "radius_ipaddr", inputTable["radiusClient.authserverIP6"])
                            if(inputTable["radiusClient.acctserverIP6"] ~= nil)then
                                nvramSetCmdWrite(interface, "radius_acct_ipaddr", inputTable["radiusClient.acctserverIP6"])
                            else
                                nvramSetCmdWrite(interface, "radius_acct_ipaddr", inputTable["radiusClient.authserverIP6"])
                            end
                        end
                    end

                    --Secondary Radius Secret Configuration
                    if(inputTable["radiusClient.secauthsecret"] ~= nil)then
                        nvramSetCmdWrite(interface, "sec_radius_key", inputTable["radiusClient.secauthsecret"])
                        if(inputTable["radiusClient.secacctsecret"] ~= nil)then
                            nvramSetCmdWrite(interface, "sec_radius_acct_key", inputTable["radiusClient.secacctsecret"])
                        else
                            nvramSetCmdWrite(interface, "sec_radius_acct_key", inputTable["radiusClient.secauthsecret"])
                        end
                    else
                        local sec_radius_key = db.getAttribute("radiusClient","_ROWID_","1","secauthsecret")
                        if(sec_radius_key ~= nil) then
                            nvramSetCmdWrite(interface, "sec_radius_key", sec_radius_key)
                            local sec_radius_acct_key = db.getAttribute("radiusClient","_ROWID_","1","secacctsecret")
                            if(sec_radius_acct_key ~= nil) then
                                nvramSetCmdWrite(interface, "sec_radius_acct_key", sec_radius_acct_key)
                            else
                                nvramSetCmdWrite(interface, "sec_radius_acct_key", sec_radius_key)
                            end
                        end
                    end

                    --Secondary Radius Port Configuration
                    if(inputTable["radiusClient.secauthport"] ~= nil)then
                        nvramSetCmdWrite(interface, "sec_radius_port", inputTable["radiusClient.secauthport"])
                        if(inputTable["radiusClient.secacctport"] ~= nil)then
                            nvramSetCmdWrite(interface, "sec_radius_acct_port", inputTable["radiusClient.secacctport"])
                        else
                            nvramSetCmdWrite(interface, "sec_radius_acct_port", "1813")
                        end
                    else
                        nvramSetCmdWrite(interface, "sec_radius_port", "1812")
                        nvramSetCmdWrite(interface, "sec_radius_acct_port", "1813")
                    end

                    --Secondary Radius Auth & Acct IP Configuration
                    if(inputTable["radiusClient.ipType"] ~= nil and inputTable["radiusClient.ipType"] == "0")then
                        if(inputTable["radiusClient.secauthserver"] ~= nil)then
                            nvramSetCmdWrite(interface, "sec_radius_ipaddr", inputTable["radiusClient.secauthserver"])
                            if(inputTable["radiusClient.secacctserver"] ~= nil)then
                                nvramSetCmdWrite(interface, "sec_radius_acct_ipaddr", inputTable["radiusClient.secacctserver"])
                            else
                                nvramSetCmdWrite(interface, "sec_radius_acct_ipaddr", inputTable["radiusClient.secauthserver"])
                            end
                        end
                    else
                        if(inputTable["radiusClient.secauthserverIP6"] ~= nil)then
                            nvramSetCmdWrite(interface, "sec_radius_ipaddr", inputTable["radiusClient.secauthserverIP6"])
                            if(inputTable["radiusClient.secacctserverIP6"] ~= nil)then
                                nvramSetCmdWrite(interface, "sec_radius_acct_ipaddr", inputTable["radiusClient.secacctserverIP6"])
                            else
                                nvramSetCmdWrite(interface, "sec_radius_acct_ipaddr", inputTable["radiusClient.secauthserverIP6"])
                            end
                        end
                    end

                    --Primary Radius Retry Interval
                    if(inputTable["radiusClient.retryInterval"] ~= nil)then
                        nvramSetCmdWrite(interface, "radius_retry_primary_interval", inputTable["radiusClient.retryInterval"])
                    end

                    --Radius Retry TimeOut
                    if(inputTable["radiusClient.authtimeout"] ~= nil)then
                        nvramSetCmdWrite(interface, "radius_retry_timeout", inputTable["radiusClient.authtimeout"])
                    end

                    --Radius Retry Count
                    if(inputTable["radiusClient.authretries"] ~= nil)then
                        nvramSetCmdWrite(interface, "radius_retries", inputTable["radiusClient.authretries"])
                    end

                    if(inputTable["radiusClient.serverinuse"] ~= nil)then
                        nvramSetCmdExecute(interface, "radius_server_in_use", inputTable["radiusClient.serverinuse"])
                        nvramSetCmdExecute(interface, "radius_acct_server_in_use", inputTable["radiusClient.serverinuse"])
                    end

                    cmd = "echo \'nvram commit\' >> "..CMD_EXEC_SCRIPT
                    os.execute (cmd)
                else
                    if(rowid == "-1")then
                        local inputTable = db.getRowWhere("radiusClient","_ROWID_='1'",true)
                        if(inputTable ~= nil) then
                            if(inputTable["radiusClient.authsecret"] ~= nil)then
                                nvramSetCmdWrite(interface, "radius_key", inputTable["radiusClient.authsecret"])
                                if(inputTable["radiusClient.acctsecret"] ~= nil)then
                                    nvramSetCmdWrite(interface, "radius_acct_key", inputTable["radiusClient.acctsecret"])
                                else
                                    nvramSetCmdWrite(interface, "radius_acct_key", inputTable["radiusClient.authsecret"])
                                end
                            end
                            if(inputTable["radiusClient.authport"] ~= nil)then
                                nvramSetCmdWrite(interface, "radius_port", inputTable["radiusClient.authport"])
                                if(inputTable["radiusClient.acctport"] ~= nil)then
                                    nvramSetCmdWrite(interface, "radius_acct_port", inputTable["radiusClient.acctport"])
                                else
                                    nvramSetCmdWrite(interface, "radius_acct_port", "1813")
                                end
                            end

                            --Primary Radius Auth & Acct Servers 
                            if(inputTable["radiusClient.ipType"] ~= nil and inputTable["radiusClient.ipType"] == "0")then
                                if(inputTable["radiusClient.authserver"] ~= nil)then
                                    nvramSetCmdWrite(interface, "radius_ipaddr", inputTable["radiusClient.authserver"])
                                    if(inputTable["radiusClient.acctserver"] ~= nil)then
                                        nvramSetCmdWrite(interface, "radius_acct_ipaddr", inputTable["radiusClient.acctserver"])
                                    else
                                        nvramSetCmdWrite(interface, "radius_acct_ipaddr", inputTable["radiusClient.authserver"])
                                    end
                                end
                            else
                                if(inputTable["radiusClient.authserverIP6"] ~= nil)then
                                    nvramSetCmdWrite(interface, "radius_ipaddr", inputTable["radiusClient.authserverIP6"])
                                    if(inputTable["radiusClient.acctserverIP6"] ~= nil)then
                                        nvramSetCmdWrite(interface, "radius_acct_ipaddr", inputTable["radiusClient.acctserverIP6"])
                                    else
                                        nvramSetCmdWrite(interface, "radius_acct_ipaddr", inputTable["radiusClient.authserverIP6"])
                                    end
                                end
                            end

                            --Secondary Radius Configuration
                            if(inputTable["radiusClient.secauthsecret"] ~= nil)then
                                nvramSetCmdWrite(interface, "sec_radius_key", inputTable["radiusClient.secauthsecret"])
                                if(inputTable["radiusClient.secacctsecret"] ~= nil)then
                                    nvramSetCmdWrite(interface, "sec_radius_acct_key", inputTable["radiusClient.secacctsecret"])
                                else
                                    nvramSetCmdWrite(interface, "sec_radius_acct_key", inputTable["radiusClient.secauthsecret"])
                                end
                            end
                            if(inputTable["radiusClient.secauthport"] ~= nil)then
                                nvramSetCmdWrite(interface, "sec_radius_port", inputTable["radiusClient.secauthport"])
                                if(inputTable["radiusClient.sec_acctport"] ~= nil)then
                                    nvramSetCmdWrite(interface, "sec_radius_acct_port", inputTable["radiusClient.sec_acctport"])
                                else
                                    nvramSetCmdWrite(interface, "sec_radius_acct_port", "1813")
                                end
                            end

                           --Secondary Radius Auth & Acct IP Configuration
                           if(inputTable["radiusClient.ipType"] ~= nil and inputTable["radiusClient.ipType"] == "0")then
                               if(inputTable["radiusClient.secauthserver"] ~= nil)then
                                   nvramSetCmdWrite(interface, "sec_radius_ipaddr", inputTable["radiusClient.secauthserver"])
                                   if(inputTable["radiusClient.secacctserver"] ~= nil)then
                                       nvramSetCmdWrite(interface, "sec_radius_acct_ipaddr", inputTable["radiusClient.secacctserver"])
                                   else
                                       nvramSetCmdWrite(interface, "sec_radius_acct_ipaddr", inputTable["radiusClient.secauthserver"])
                                   end
                               end
                            else
                                if(inputTable["radiusClient.secauthserverIP6"] ~= nil)then
                                    nvramSetCmdWrite(interface, "sec_radius_ipaddr", inputTable["radiusClient.secauthserverIP6"])
                                    if(inputTable["radiusClient.secacctserverIP6"] ~= nil)then
                                        nvramSetCmdWrite(interface, "sec_radius_acct_ipaddr", inputTable["radiusClient.secacctserverIP6"])
                                    else
                                        nvramSetCmdWrite(interface, "sec_radius_acct_ipaddr", inputTable["radiusClient.secauthserverIP6"])
                                    end
                                end
                            end

                            --Primary Radius Retry Interval
                            if(inputTable["radiusClient.retryInterval"] ~= nil)then
                                nvramSetCmdWrite(interface, "radius_retry_primary_interval", inputTable["radiusClient.retryInterval"])
                            end
                            --Radius Retry TimeOut
                            if(inputTable["radiusClient.authtimeout"] ~= nil)then
                                nvramSetCmdWrite(interface, "radius_retry_timeout", inputTable["radiusClient.authtimeout"])
                            end
                            --Radius Retry Count
                            if(inputTable["radiusClient.authretries"] ~= nil)then
                                nvramSetCmdWrite(interface, "radius_retries", inputTable["radiusClient.authretries"])
                            end

                            cmd = "echo \'nvram commit\' >> "..CMD_EXEC_SCRIPT
                            os.execute (cmd)
                        end --inputTable nil loop
                    end -- rowid -1 loop
                end
            end -- for loop
            if(radioTable ~= nil)then
                for k,v in pairs(radioTable)do
                    local inputTable = v
                    local dot11Radios = db.getRowsWhere ("dot11Radio", "radioNo = " .. inputTable["dot11Radio.radioNo"], false)
                    local radioInterface = dot11Radios[1]["interfaceName"]
                    cmd = WLCONF_CMD_BINARY .." "..radioInterface.. " up"
                    wlconfExclude(CMD_EXEC_SCRIPT,cmd)
                end
            end

            dot11.ServiceStopStart2 (false)
            dot11.ServiceStopStart2 (true)

            if(radioTable ~= nil)then
                for k,v in pairs(radioTable)do
                    local inputTable = v
                    local dot11Radios = db.getRowsWhere ("dot11Radio", "radioNo = " .. inputTable["dot11Radio.radioNo"], false)
                    local radioInterface = dot11Radios[1]["interfaceName"]
                    cmd = WLCONF_CMD_BINARY .." "..radioInterface.. " start"
                    wlconfExclude(CMD_EXEC_SCRIPT,cmd)
                end
            end

            for k,v in pairs(ifTbl)do                                                                                                         
                local inputTable = v                                                                                                                   
                if ((util.fileExists("/pfrm2.0/HW_JCO110"))) then
                    wlCmdWrite(inputTable["interfaceName"], "phy_ed_thresh", "-30")
                else
                    wlCmdWrite(inputTable["interfaceName"], "phy_ed_thresh", "-50")
                end
            end
        elseif (util.fileExists("/pfrm2.0/HW_JCO410") or util.fileExists("/pfrm2.0/HW_JCE410")) then
            if (operation == "edit") then
                bootFlag = "0"
            else
                bootFlag = "1"
            end
            local profileTable = db.getTable("dot11Profile",true)
            if(profileTable ~= nil)then
                for k,v in pairs(profileTable)do
                    local inputTable = v
                    if(inputTable["dot11Profile.authMethods"] == "RADIUS")then
                        local vapName = db.getAttribute("dot11VAP","profileName",inputTable["dot11Profile.profileName"],"vapName")
                        local vapEnabled = db.getAttribute("dot11VAP","profileName",inputTable["dot11Profile.profileName"],"vapEnabled")
                        local vapInterface = db.getAttribute("dot11Interface","vapName",vapName,"interfaceName")
                        hostapd_stop(vapInterface,bootFlag)
                        hostapd_create_config(vapInterface,bootFlag)
                        if(vapEnabled == "1")then
                            if (bootFlag == "1") then
                                hostapd_start_boot(vapInterface)
                            else
                                hostapd_start(vapInterface)
                            end
                        end
                    end
                end 
            end
        elseif (util.fileExists("/pfrm2.0/HW_JCO4032") or util.fileExists("/pfrm2.0/HW_JCOW407") or util.fileExists("/pfrm2.0/HW_JCOW402") or (util.fileExists("/flash/JMA24_CAP_MODE"))) then
            local radioTable = db.getTable("dot11Radio",true)
            local cmd = ""
            if(radioTable ~= nil)then
                for k,v in pairs(radioTable)do
                    local dot11Interfaces = db.getRowsWhere ("dot11Interface", "radioNo = " .. v["dot11Radio.radioNo"], false)
                    local radio1vaps = #(db.getRowsWhere ("dot11Interface", "radioNo = " .. v["dot11Radio.radioNo"], false))
                    -- no interface corresponding to the radio
                    if (dot11Interfaces == nil or dot11Interfaces[1] == nil) then
                         return "ERROR", "RADIUS_CONFIG_FAILED"
                    end

                    for kk,vv in pairs(dot11Interfaces) do
                        local vapDbStringIndex = vv["radioNo"]
                        local vapDbString ="_Entry"
                        if(util.fileExists("/pfrm2.0/MESH_ENABLED")) then
                           if (((vv["_ROWID_"] == "1") or (vv["_ROWID_"] == "4"))) then
                               if(tonumber(vv["radioNo"])==1)then
                                   vapDbStringIndex = vv["_ROWID_"]-1
                                   vapDbString ="_Entry"..vapDbStringIndex
                               elseif(tonumber(vv["radioNo"])==2)then
                                   vapDbStringIndex = vv["_ROWID_"]-radio1vaps-1
                                   vapDbString ="11ac_Entry"..vapDbStringIndex
                               end
                           else
                             if(tonumber(vv["radioNo"])==1)then
                                 vapDbStringIndex = vv["_ROWID_"]
                                 vapDbString ="_Entry"..vapDbStringIndex
                             elseif(tonumber(vv["radioNo"])==2)then
                                 vapDbStringIndex = vv["_ROWID_"]-radio1vaps
                                 vapDbString ="11ac_Entry"..vapDbStringIndex
                             end
                           end
                       else
                           if(tonumber(vv["radioNo"])==1)then
                               vapDbStringIndex = vv["_ROWID_"]-1
                               vapDbString ="_Entry"..vapDbStringIndex
                            elseif(tonumber(vv["radioNo"])==2)then
                               vapDbStringIndex = vv["_ROWID_"]-radio1vaps-1
                               vapDbString ="11ac_Entry"..vapDbStringIndex
                             end
                       end

                        if (rowid == "1" or inputTable["radiusClient._ROWID_"] == '1') then
                            
                            if(inputTable["radiusClient.authserver"] ~= nil)then
                                tcapiSetCmdWrite(vapDbString, "RADIUS_Server", inputTable["radiusClient.authserver"])
                            end
                            
                            if(inputTable["radiusClient.authport"] ~= nil)then
                                tcapiSetCmdWrite(vapDbString, "RADIUS_Port", inputTable["radiusClient.authport"])
                            end
                            
                            if(inputTable["radiusClient.authsecret"] ~= nil)then
                                tcapiSetCmdWrite(vapDbString, "RADIUS_Key", inputTable["radiusClient.authsecret"])
                            else
                                local radius_key = db.getAttribute("radiusClient","_ROWID_","1","authsecret")
                                if(radius_key ~= nil) then
                                    tcapiSetCmdWrite(vapDbString, "RADIUS_Key", radius_key)
                                end
                            end

                        else
                            if(rowid == "-1")then
                                local inputTable = db.getRowWhere("radiusClient","_ROWID_='1'",true)
                                if(inputTable ~= nil and inputTable["radiusClient.authserver"] ~= nil)then
                                    tcapiSetCmdWrite(vapDbString, "RADIUS_Server", inputTable["radiusClient.authserver"])
                                end
                                if(inputTable ~= nil and inputTable["radiusClient.authport"] ~= nil)then
                                    tcapiSetCmdWrite(vapDbString, "RADIUS_Port", inputTable["radiusClient.authport"])
                                end
                                if(inputTable ~= nil and inputTable["radiusClient.authsecret"] ~= nil)then
                                    tcapiSetCmdWrite(vapDbString, "RADIUS_Key", inputTable["radiusClient.authsecret"])
                                end
                            end
                        end
                    end
                    dot11.RadioSetVapState(v["dot11Radio.radioNo"])
                end
            end --radioTable nil check
        end
        return "OK", "STATUS_OK"
    else
        return "ERROR", "RADIUS_CONFIG_FAILED"
    end

end

-- radius config
function radius.config (inputTable, rowid, operation)
	-- validate
	if (radius.inputvalidate(inputTable, operation)) then
		if (operation == "add") then
			return db.insert("radiusClient", inputTable)
		elseif (operation == "edit") then
			return db.update("radiusClient", inputTable, rowid)
		elseif (operation == "delete") then
            for k,v in pairs(inputTable) do
                valid  = db.deleteRow("radiusClient", "_ROWID_", v)
                if (not valid) then  return false end
            end
            return true
		end
	end
	return false
end

-- das config
function das.config (inputTable, rowid, operation)
	-- validate
	if (das.inputvalidate(inputTable, operation)) then
		if (operation == "add") then
			return db.insert("radiusDas", inputTable)
		elseif (operation == "edit") then
			return db.update("radiusDas", inputTable, rowid)
		elseif (operation == "delete") then
            for k,v in pairs(inputTable) do
                valid  = db.deleteRow("radiusDas", "_ROWID_", v)
                if (not valid) then  return false end
            end
            return true
		end
	end
	return false
end

-- radius inputvalidate
function radius.inputvalidate (inputTable, operation)
	if (false) then
		return db.typeAndRangeValidate(inputTable)
	end
	return true
end

-- das inputvalidate
function das.inputvalidate (inputTable, operation)
	if (false) then
		return db.typeAndRangeValidate(inputTable)
	end
	return true
end

function radiusClient.import (configTable, defaultConfigTable, removeTbl)
   local status

   if (configTable == nil) then
        configTable = defaultConfigTable
   end

   local radiusClientTbl = {}
   radiusClientTbl = config.update (configTable, defaultConfigTable, removeTbl)

   for i,v in ipairs (radiusClientTbl) do
       if (v["authsecret"] ~= nil and v["authsecret"] ~= "") then
           status, v["authsecret"] = passwdSecureLib.decryptData (v["authsecret"], "")
       end
       if (v["acctsecret"] ~= nil and v["acctsecret"] ~= "") then
           status, v["acctsecret"] = passwdSecureLib.decryptData (v["acctsecret"], "")
       end
       v = util.addPrefix (v, "radiusClient.")
       radius.radius_config (v, "-1", "add");
   end

end

function radiusClient.export ()
    local status
    local radiusClient = db.getTable ("radiusClient", false)
    for i, v in ipairs (radiusClient) do
        if (v["authsecret"] ~= nil and v["authsecret"] ~= "") then
            status, radiusClient[i].authsecret = passwdSecureLib.encryptData (v["authsecret"], "")
        end
        if (v["acctsecret"] ~= nil and v["acctsecret"] ~= "") then
            status, radiusClient[i].acctsecret = passwdSecureLib.encryptData (v["acctsecret"], "")
        end
    end
    return radiusClient
end

function radiusDas.import (configTable, defaultConfigTable, removeTbl)
    local status

    if (configTable == nil) then
         configTable = defaultConfigTable
    end

    local radiusDasTbl = {}
    radiusDasTbl = config.update (configTable, defaultConfigTable, removeTbl)

    if(radiusDasTbl ~= nil)then
        for i,v in ipairs (radiusDasTbl) do
            if (v["dasSecret"] ~= nil and v["dasSecret"] ~= "") then
                status, v["dasSecret"] = passwdSecureLib.decryptData (v["dasSecret"], "")
            end
            v = util.addPrefix (v, "radiusDas.")
            das.das_config (v, "-1", "add");
        end
    end

end

function radiusDas.export ()

    local status
    local radiusDas = db.getTable ("radiusDas", false)
    if(radiusDas ~= nil)then
        for i, v in ipairs (radiusDas) do
            if (v["dasSecret"] ~= nil and v["dasSecret"] ~= "") then
                status, radiusDas[i].dasSecret = passwdSecureLib.encryptData (v["dasSecret"], "")
            end
        end
    end
    return radiusDas

end

function radiusAttributes.import (configTable, defaultConfigTable)
   if (configTable == nil) then
        configTable = defaultConfigTable
   end

	if (configTable ~= nil) then
	   for i,v in ipairs (configTable) do
		    v = util.addPrefix (v, "radiusAttributes.")
			db.insert ("radiusAttributes", v)
	   end
	end
end

function radiusAttributes.export ()
    local radiusAttributes = db.getTable ("radiusAttributes", false)
    return radiusAttributes
end

if (config.register) then
   		config.register("radiusDas", radiusDas.import, radiusDas.export)
   		config.register("radiusClient", radiusClient.import, radiusClient.export)
   		config.register("radiusAttributes", radiusAttributes.import, radiusAttributes.export)
end

