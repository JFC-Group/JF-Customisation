
-- pptpClient.lua : PPTP VPN Client core API to configure PPTP VPN Client

-- Copyright (c) 2011, TeamF1, Inc 

-- modification history 
-- --------------------
-- 01a,03June11,nis created.
--

--module (com.teamf1.core.security.vpn.pptpClient, seeall)

--**********Requires**********
require "teamf1lualib/db"
require "teamf1lualib/util"

--**********Package Configurations**********
pptpClient = {}

--**********Defines**********
function pptpDBConfig(inputTable,tableName, uniqueId, operation)
    if (db.typeAndRangeValidate (inputTable)) then
        if (operation == "add") then
            return db.insert(tableName, inputTable)
        elseif (operation == "edit") then
            return db.update(tableName, inputTable, uniqueId)
        elseif (operation == "delete") then
            return db.delete(tableName, inputTable)
        end
    end
end

-- pptpDBConfig = db.crud
pptpDBRowGet = db.getRow


--- @description Sets pptp client configuration
--
-- @param pptpClientInfo An array containing pptpClient information. Array structure:
--    pptpClientEnable     : To enable/disable pptp vpn Client
--    ServerIp             : IP of the pptp Server
--    RemoteNetwork        : Network address of network local to pptp Server, remote to pptp vpn Client
--    RemoteNetmask        : Subnet Mask of network local to pptp Server, remote to pptp vpn Client 
--    UserName             : Username allocated to pptp client
--    Password             : Password allocated to pptp client
--    MppeEncryptionEnable : To enable/disable mppe 
--    IdleTimeOut          : User Time Out 
--
-- @return OK on success, ERROR on failure
--         Error Code - Description of the error
--
-- @see get()
function pptpClient.set (pptpClientInfo)
    db.beginTransaction() --begin transaction
    local actionStatusFlag = false
    local statusFlag = false

    if (pptpClientInfo["pptpClient.pptpClientEnable"] == "1") then
        actionStatusFlag = db.setAttribute("pptpClientConnectionStatus", "_ROWID_", 1, "actionStatus", "1")
        if (pptpClientInfo["pptpClient.ServerIp"] == "0.0.0.0") then
		    return "ERROR","INVALID_SERVER_IP"
		end
		if (pptpClientInfo["pptpClient.RemoteNetwork"] == "0.0.0.0") then
		    return "ERROR","INVALID_REMOTE_NETWORK"
		end
    else -- if client is disabled
        actionStatusFlag = db.setAttribute("pptpClientConnectionStatus", "_ROWID_", 1, "actionStatus", "0")
    end
    
	statusFlag =  pptpDBConfig (pptpClientInfo, "pptpClient", 1, "edit") and actionStatusFlag

    if (statusFlag) then
        db.commitTransaction()
        return "OK", "STATUS_OK"        
    else
        db.rollback()
        return "ERROR", "PPTP_CLIENT_STATUS_CONFIG_FAILED"
    end

end


-- @description Gets pptp Client configuration
--
-- @return An array containing pptp client configuration
--  
-- @see set()
function pptpClient.get ()
	return pptpDBRowGet ("pptpClient", "_ROWID_", 1)
end


-- @description Sets action as connect/drop 
-- 
-- @param Following parameters are passed:
--       tableName      :   table which contains the connection status parameters                 
--       keyName        :   "_ROWID_" parameter
--       keyValue       :   value of row id
--       attributeName  :   Action
--       attributeValue :   value of action parameter
--       operation      :   type of operation (connect/drop)   
--
-- @return OK on success, ERROR on failure
--         Error Code - Description of the error
--
-- @see getConnStatus() 

function pptpClient.ConnStatusConfig (tableName, keyName,keyValue,attributeName,attributeValue, operation)
    db.beginTransaction() --begin transaction
    local actionFlag = false

    -- validate
    if (operation == "Connect") then
		actionFlag = db.setAttribute (tableName, keyName,keyValue,attributeName,attributeValue)
	else
		actionFlag = db.setAttribute (tableName, keyName,keyValue,attributeName,attributeValue)
	end

    -- return
    if (actionFlag) then
        db.commitTransaction()
        return "OK", "STATUS_OK"
    else
        db.rollback()
        return "ERROR", "PPTP_CLIENT_STATUS_CONFIG_FAILED"
    end
end

-- @description Gets pptp Client status configuration
-- 
-- @return  array containing connectionStatus,action and actionStatus
-- 
-- @see ConnStatusConfig() 
function pptpClient.getConnStatus()
    return pptpDBRowGet ("pptpClientConnectionStatus", "_ROWID_", 1)
end
