-- @copyright Copyright (c) 2012, TeamF1, Inc. 

require "teamf1lualib/nimfStatic"
require "teamf1lualib/nimfDhcp"
require "teamf1lualib/nimfPPPoE"
require "teamf1lualib/nimfPPTP"
require "teamf1lualib/nimfL2TP"
require "teamf1lualib/nimfSlaac"

--[[
*******************************************************************************
-- @name nimfConn.methodValidate
--
-- @description This function calls the appropriate method to validate i
-- the given configuration.
--
-- @param conf  configuration.
--
-- @return  status
-- @errCode error string
--]]

function nimfConn.methodValidate(conf)
    local connType
    local status = "ERROR"
    local errCode = ""

    -- check if the connection type is supported
    connType = nimfConn.isMethodSupported(conf["ConnectionType"])
    if ((connType == nil) or (connType == nimf.method.NIMF_CONN_NONE)) then
        errCode = "NET_ERR_INVALID_CONN_TYPE"
        nimf.dprintf("Connection method not supported")
        return status, errCode
    end        

    -- validate the connection parameters
    if (connType == nimf.method.NIMF_IPV4_CONN_STATIC) then
        status, errCode = nimfConn.ipv4StaticConfValidate(conf)
    elseif (connType == nimf.method.NIMF_IPV4_CONN_PPPOE) then
        status, errCode = nimfConn.ipv4PPPoEConfValidate(conf)
    elseif (connType == nimf.method.NIMF_IPV4_CONN_PPTP) then
        status, errCode = nimfConn.ipv4PPTPConfValidate(conf)
    elseif (connType == nimf.method.NIMF_IPV4_CONN_L2TP) then
        status, errCode = nimfConn.ipv4L2TPConfValidate(conf)
    elseif (connType == nimf.method.NIMF_IPV4_CONN_DHCP) then
        status, errCode = nimfConn.ipv4DhcpConfValidate(conf)
    elseif (connType == nimf.method.NIMF_IPV6_CONN_STATIC) then
        status, errCode = nimfConn.ipv6StaticConfValidate(conf)
    elseif (connType == nimf.method.NIMF_IPV6_CONN_DHCP) then
        status, errCode = nimfConn.ipv6DhcpConfValidate(conf)
    elseif (connType == nimf.method.NIMF_IPV6_CONN_DHCP_STATELESS) then
        status, errCode = nimfConn.ipv6DhcpConfValidate(conf)
    elseif (connType == nimf.method.NIMF_IPV6_CONN_AUTO) then
        status, errCode = nimfConn.ipv6AutoConfValidate(conf)
    end    

    return status, errCode
end

--[[
*******************************************************************************
-- @name nimfConn.methodConfigure
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.methodConfigure(conf)
    local connType
    local status = "ERROR"
    local errCode = ""
    local changed = false

    -- check if the connection type is supported
    connType = nimfConn.isMethodSupported(conf["ConnectionType"])
    if ((connType == nil) or (connType == nimf.method.NIMF_CONN_NONE)) then
        errCode = "NET_ERR_INVALID_CONN_TYPE"
        nimf.dprintf("nimfConn.methodConfigure: method " .. 
                     conf["ConnectionType"] .. " not supported")
        return status, errCode
    end        

    -- validate the connection parameters
    if (connType == nimf.method.NIMF_IPV4_CONN_STATIC) then
        status, errCode, changed = nimfConn.ipv4StaticConfigure(conf)
    elseif (connType == nimf.method.NIMF_IPV4_CONN_PPPOE) then
        status, errCode, changed = nimfConn.ipv4PPPoEConfigure(conf)
    elseif (connType == nimf.method.NIMF_IPV4_CONN_PPTP) then
        status, errCode, changed = nimfConn.ipv4PPTPConfigure(conf)
    elseif (connType == nimf.method.NIMF_IPV4_CONN_L2TP) then
        status, errCode, changed = nimfConn.ipv4L2TPConfigure(conf)
    elseif (connType == nimf.method.NIMF_IPV4_CONN_DHCP) then
        status, errCode, changed  = nimfConn.ipv4DhcpConfigure(conf)
    elseif (connType == nimf.method.NIMF_IPV6_CONN_STATIC) then
        status, errCode, changed = nimfConn.ipv6StaticConfigure(conf)
    elseif (connType == nimf.method.NIMF_IPV6_CONN_DHCP) then
        status, errCode, changed = nimfConn.ipv6DhcpConfigure(conf)
    elseif (connType == nimf.method.NIMF_IPV6_CONN_DHCP_STATELESS) then
        status, errCode, changed = nimfConn.ipv6DhcpConfigure(conf)
    elseif (connType == nimf.method.NIMF_IPV6_CONN_AUTO) then
        status, errCode, changed = nimfConn.ipv6AutoConfigure(conf)
    end    

    nimf.dprintf ("methodConfigure: " .. status .. "," .. (errCode or ""))
    return status, errCode,  changed
end

--[[
*******************************************************************************
-- @name nimfConn.methodDeconfigure
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.methodDeconfigure(conf)
    local connType
    local status = "ERROR"
    local errCode = ""

    -- check if the connection type is supported
    connType = nimfConn.isMethodSupported(conf["ConnectionType"])
    if ((connType == nil) or (connType == nimf.method.NIMF_CONN_NONE)) then
        nimf.dprintf("network.methodDeconfigure:Connection type(" .. 
                     conf["ConnectionType"] or 'NULL'.. ") not supported")
        errCode = "NET_ERR_INVALID_CONN_TYPE"
        return status, errCode
    end        

    nimf.dprintf("network.methodDeconfigure:Deconfigure connection method:" .. 
                 conf["ConnectionType"])

    -- validate the connection parameters
    if (connType == nimf.method.NIMF_IPV4_CONN_STATIC) then
        status, errCode = nimfConn.ipv4StaticDeconfigure(conf)
    elseif (connType == nimf.method.NIMF_IPV4_CONN_PPPOE) then
        status, errCode = nimfConn.ipv4PPPoEDeconfigure(conf)
    elseif (connType == nimf.method.NIMF_IPV4_CONN_PPTP) then
        status, errCode = nimfConn.ipv4PPTPDeconfigure(conf)
    elseif (connType == nimf.method.NIMF_IPV4_CONN_L2TP) then
        status, errCode = nimfConn.ipv4L2TPDeconfigure(conf)
    elseif (connType == nimf.method.NIMF_IPV4_CONN_DHCP) then
        status, errCode = nimfConn.ipv4DhcpDeconfigure(conf)
    elseif (connType == nimf.method.NIMF_IPV6_CONN_STATIC) then
        status, errCode = nimfConn.ipv6StaticDeconfigure(conf)
    elseif (connType == nimf.method.NIMF_IPV6_CONN_DHCP) then
        status, errCode = nimfConn.ipv6DhcpDeconfigure(conf)
    elseif (connType == nimf.method.NIMF_IPV6_CONN_DHCP_STATELESS) then
        status, errCode = nimfConn.ipv6DhcpDeconfigure(conf)
    elseif (connType == nimf.method.NIMF_IPV6_CONN_AUTO) then
        status, errCode = nimfConn.ipv6AutoDeconfigure(conf)
    end    

    return status, errCode
end

--[[
*******************************************************************************
-- @name nimfConn.isMethodSupported
--
-- @description This function checks if the connection type is supported.
--
-- @param method  type of the connection.
--
-- @return method if supported, 0 if not supported, else 0
--
--]]

function nimfConn.isMethodSupported(methodStr)

    if (methodStr == nil) then
        return nil
    end        

    if (platformLib.strcasecmp(methodStr, "ifStatic") == 0)then
        return nimf.method.NIMF_IPV4_CONN_STATIC
    elseif (platformLib.strcasecmp(methodStr, "ifStatic6") == 0)then      
        return nimf.method.NIMF_IPV6_CONN_STATIC
    elseif (platformLib.strcasecmp(methodStr, "dhcpc") == 0)then      
        return nimf.method.NIMF_IPV4_CONN_DHCP
    elseif (platformLib.strcasecmp(methodStr, "dhcp6c") == 0)then      
        return nimf.method.NIMF_IPV6_CONN_DHCP
    elseif (platformLib.strcasecmp(methodStr, "dhcp6c-stateless") == 0)then      
        return nimf.method.NIMF_IPV6_CONN_DHCP_STATELESS
    elseif (platformLib.strcasecmp(methodStr, "ipv6-auto") == 0)then      
        return nimf.method.NIMF_IPV6_CONN_AUTO
    elseif (platformLib.strcasecmp(methodStr, "pppoe") == 0)then      
        return nimf.method.NIMF_IPV4_CONN_PPPOE
    elseif (platformLib.strcasecmp(methodStr, "pptp") == 0)then      
        return nimf.method.NIMF_IPV4_CONN_PPTP
    elseif (platformLib.strcasecmp(methodStr, "l2tp") == 0)then      
        return nimf.method.NIMF_IPV4_CONN_L2TP
    else        
        return nimf.method.NIMF_CONN_NONE
    end        
end

--[[
*******************************************************************************
-- @name nimfConn.methodToStr 
--
-- @description This function gets the connection type string
--
-- @param method  type of the connection.
--
-- @return nil for failure , else connection type string
--
--]]

function nimfConn.methodToStr(method)

    if (method == nil) then
        return nil
    end        

    method = tonumber(method)

    if (method == nimf.method.NIMF_IPV4_CONN_STATIC) then
        return "ifStatic"                    
    elseif (method == nimf.method.NIMF_IPV6_CONN_STATIC) then        
        return "ifStatic6"                    
    elseif (method == nimf.method.NIMF_IPV4_CONN_DHCP) then        
        return "dhcpc"
    elseif (method == nimf.method.NIMF_IPV6_CONN_DHCP) then        
        return "dhcp6c"
    elseif (method == nimf.method.NIMF_IPV6_CONN_DHCP_STATELESS) then        
        return "dhcp6c-stateless"
    elseif (method == nimf.method.NIMF_IPV4_CONN_PPPOE) then        
        return "pppoe"
    elseif (method == nimf.method.NIMF_IPV4_CONN_PPTP) then        
        return "pptp"
    elseif (method == nimf.method.NIMF_IPV4_CONN_L2TP) then        
        return "l2tp"
    elseif (method == nimf.method.NIMF_IPV6_CONN_AUTO) then        
        return "ipv6-auto"
     end

    return nil
end

--[[
*******************************************************************************
-- @name nimfConn.methodConfGet
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.methodConfGet(conf)
    local connType
    local status = "ERROR"
    local errCode = ""
    local methodConf = {}

    -- check if the connection type is supported
    connType = nimfConn.isMethodSupported(conf["ConnectionType"])
    if ((connType == nil) or (connType == nimf.method.NIMF_CONN_NONE)) then
        errCode = "NET_ERR_INVALID_CONN_TYPE"
        return status, errCode
    end        

    -- validate the connection parameters
    if (connType == nimf.method.NIMF_IPV4_CONN_STATIC) then
        status, errCode, methodConf = nimfConn.ipv4StaticConfGet(conf)
    elseif (connType == nimf.method.NIMF_IPV4_CONN_PPPOE) then
        status, errCode, methodConf = nimfConn.ipv4PPPoEConfGet(conf)
    elseif (connType == nimf.method.NIMF_IPV4_CONN_PPTP) then
        status, errCode, methodConf = nimfConn.ipv4PPTPConfGet(conf)
    elseif (connType == nimf.method.NIMF_IPV4_CONN_L2TP) then
        status, errCode, methodConf = nimfConn.ipv4L2TPConfGet(conf)
    elseif (connType == nimf.method.NIMF_IPV4_CONN_DHCP) then
        status, errCode, methodConf = nimfConn.ipv4DhcpConfGet(conf)
    elseif (connType == nimf.method.NIMF_IPV6_CONN_STATIC) then
        status, errCode, methodConf = nimfConn.ipv6StaticConfGet(conf)
    elseif (connType == nimf.method.NIMF_IPV6_CONN_DHCP) then
        status, errCode, methodConf = nimfConn.ipv6DhcpConfGet(conf)
    elseif (connType == nimf.method.NIMF_IPV6_CONN_DHCP_STATELESS) then
        status, errCode, methodConf = nimfConn.ipv6DhcpConfGet(conf)
    elseif (connType == nimf.method.NIMF_IPV6_CONN_AUTO) then
        status, errCode, methodConf = nimfConn.ipv6AutoConfGet(conf)
    end    


    if (methodConf ~= nil) then
        -- Append method configuration to main configuration
        conf = util.tableAppend (conf, methodConf)
    end

    return status, errCode, conf
end

--[[
*******************************************************************************
-- @name nimfConn.methodDefConfGet
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.methodDefConfGet(conf)
    local connType
    local status = "OK"
    local errCode = "STATUS_OK"
    local methodConf = {}

    -- check if the connection type is supported
    connType = nimfConn.isMethodSupported(conf["ConnectionType"])
    if ((connType == nil) or (connType == nimf.method.NIMF_CONN_NONE)) then
        return "ERROR", "NET_ERR_INVALID_CONN_TYPE"
    end        

    if (connType == nimf.method.NIMF_IPV4_CONN_STATIC) then
        methodConf = nimfConn.ipv4StaticDefConfGet(conf)
    elseif (connType == nimf.method.NIMF_IPV4_CONN_DHCP) then
        methodConf = nimfConn.ipv4DhcpDefConfGet(conf)
    elseif (connType == nimf.method.NIMF_IPV6_CONN_STATIC) then
        methodConf = nimfConn.ipv6StaticDefConfGet(conf)
    elseif (connType == nimf.method.NIMF_IPV6_CONN_DHCP) then
        methodConf = nimfConn.ipv6DhcpDefConfGet(conf)
    elseif (connType == nimf.method.NIMF_IPV6_CONN_DHCP_STATELESS) then
        methodConf = nimfConn.ipv6DhcpStatelessDefConfGet(conf)
    elseif (connType == nimf.method.NIMF_IPV6_CONN_AUTO) then
        methodConf = nimfConn.ipv6AutoDefConfGet(conf)
    end    


    if (methodConf ~= nil) then
        -- Append method configuration to main configuration
        conf = util.tableAppend (conf, methodConf)
    end

    return status, errCode, conf
end
