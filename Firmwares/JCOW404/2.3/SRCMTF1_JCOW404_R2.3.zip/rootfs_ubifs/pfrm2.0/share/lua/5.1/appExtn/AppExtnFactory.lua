-- @copyright Copyright (c) 2012, TeamF1, Inc. 

require("oo/OoUtil")
require("ds/DsFactory")
require "lualogging/lsyslog"
require "teamf1lualib/util"
pcall(require, "appExtn/AppExtnClassRegistry")

AppExtnFactory = OoUtil.inheritsFrom(DsFactory)
local isInitialized = false
local THE_FACTORY = nil
local SUPER = require("ds.DsFactory")

-------------------------------------------------------------------------------
-- @name bootstrapAppExtnClass
--
-- @description 
--
-- @return
--

local function bootstrapAppExtnClass(dsClassObj)                
    local status = 0
    local valid = false

    if (dsClassObj.bootstrap == nil) then
        return 0
    end
                
    -- bootstrap the class
    valid, status = pcall(dsClassObj.bootstrap)
    if ((not valid) or (status < 0)) then
        LOG:error("AppExtn(" .. dsClassObj.className .. ") " ..
                  "failed to bootstrap. Error:" .. status)            
        return -1        
    end 

    return 0
end                

-------------------------------------------------------------------------------
-- @name loadAppExtnClass
--
-- @description 
--
-- @return
--

local function loadAppExtnClass(dsClassName)
    assert(dsClassName, "Class name not provided")

    local valid, dsClassObj = pcall(require, "appExtn/".. dsClassName)
    if (not valid) then
        LOG:error("Error (" .. dsClassObj .. ") " ..
                  "loading appExtn/" .. dsClassName)
        return nil
    end 

    -- assert for mandatory methods
    assert(dsClassObj.className, "class name not initialized")
    assert(dsClassObj.classId, "classId not initialized")

    local entry = {}
    entry.classId = dsClassObj.classId
    entry.className = dsClassObj.className
    entry.classObj = dsClassObj
    AppExtnFactory.register(THE_FACTORY, dsClassObj.classId, entry)
    LOG:ddebug("loaded appExtn/" .. dsClassObj.className)

    return dsClassObj
end

-------------------------------------------------------------------------------
-- @name AppExtnFactory.init
--
-- @description This function initializes the factory. This is called
-- from appd
--
-- @return  
--

function AppExtnFactory.init()
    LOG:ddebug("initializing AppExtn Factory")

    if (not isInitialized) then
        THE_FACTORY = AppExtnFactory:new()
        THE_FACTORY:registerClassTbl(AppExtnClassRegistry.getDsClassTbl())
        isInitialized = true
        LOG:ddebug("AppExtn Factory initalized")
    end

    -- bootstrap all classes
    for class, meta in pairs(THE_FACTORY._classTbl) do
        bootstrapAppExtnClass(meta.classObj)                
    end
end

-------------------------------------------------------------------------------
-- @name AppExtnFactory.new
--
-- @description This function creats a single instance of factory
--
-- @param  
--
-- @return  
--

function AppExtnFactory:new()
    self = AppExtnFactory.create()
    SUPER.new(self)
    return self
end

-------------------------------------------------------------------------------
-- @name AppExtnFactory.getFactory
--
-- @description This function gets the handle to the factory
--
-- @return  
--

function AppExtnFactory.getFactory()
   if (not isInitialized) then 
      AppExtnFactory.init() 
   end
   return THE_FACTORY
end

-------------------------------------------------------------------------------
-- @name AppExtnFactory.registerClassTbl
--
-- @description  This function registers all the app extension from a
-- static table defined in AppExtnClassRegistry.lua
--
-- @param  
--
-- @return  
--

function AppExtnFactory:registerClassTbl(dsClassTable)

    LOG:ddebug("Registering App Extension classes..")
    for classId, registryEntry in pairs(dsClassTable) do
        loadAppExtnClass(registryEntry.dsClass) 
    end 

    return 0
end

-------------------------------------------------------------------------------
-- @name AppExtnFactory.getClass
--
-- @description This function gets the class object for the given class
--
-- @param  
--
-- @return  
--

function AppExtnFactory:getClass(classId)
   local classObj = nil

   local meta = self._classTbl[classId]
   if (meta and meta.classObj) then
      return meta.classObj
   end

   return nil
end

return AppExtnFactory
