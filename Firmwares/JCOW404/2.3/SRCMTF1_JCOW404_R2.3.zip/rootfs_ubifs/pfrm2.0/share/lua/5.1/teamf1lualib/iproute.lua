--[[
#### Hussain Vali.
#### TeamF1
#### www.TeamF1.com
#### Dec 19, 2007

#### File: iproute.lua
#### Description: routing functions

#### Revisions:
01g 19Apr19, swr Changes for SPR 65926(validations for IPv4 route)
01f 21Jun18, swr Changes for SPR 62176(add dynamic routes to route DB table)
01e 21Nov17, swr Changes for SPR 62609 and 62467
01d 28Sep15, swr changes for AddObject support for route and route6 from tr69  
01c 15dec11, adk added ipv4&ipv6 script execution functions
01b 18oct08, nrj Fixed SPR 8705
01a 19Jun08, sdv Added ipv6 routing configuration functions
]]--


--************* Requires *************

--************* Initial Code *************

--package iproute
iproute = {}

--************* Functions *************


-- routing config
function iproute.config (inputTable, rowid, operation, dbFlag)
	-- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "Administrator Privileges Are Required"
	end

    if(dbFlag == 1) then
        db.beginTransaction() --begin transaction
    end

	local valid = false
    local statusMsg = ""
    local size = 0
   
    --maximum limit check
    local Statictable = db.getRowsWhere ("route" ,"routeType = '0'" )
    if (Statictable ~= nil ) then
        size=#Statictable
    end
    if( size >= 100 ) then
        errMsg = "ERROR"
        statusMsg = "MAXIMUM LIMIT REACHED"
        return errMsg,statusMsg
    end
	
	-- config Routes
	if (iproute.inputvalidate(inputTable)) then
	    if (operation == "add") then
            local table = db.getRowsWhere ("route", "routeName = '" .. inputTable["route.routeName"] .. "'")
            if (#table == 0) then
                table = db.getTable ("route")
                local count = 0
                local rowids = {}
                for k,v in pairs (table) do
                    if ((v["route.dstIpAddr"] == inputTable["route.dstIpAddr"] and v["route.metric"] == inputTable["route.metric"]) or
                        (v["route.dstIpAddr"] == inputTable["route.dstIpAddr"] and v["route.gwIpAddr"] == inputTable["route.gwIpAddr"])) then
                        count = count + 1
                        rowids[count] = v["route._ROWID_"]
                    end
                end
                if (#rowids == 0) then
                    valid = db.insert("route", inputTable)
    	    	    if (valid) then
	    	    	    statusMsg = "STATUS_OK"
    	    	    else
	    	    	    statusMsg = "ROUTE_ADD_FAILED"
    		        end
                else
                    statusMsg = "ROUTE_ALREADY_EXISTS"
                    valid = false
                end   
            else
                    statusMsg = "ROUTE_ALREADY_EXISTS"
                valid = false
            end
    	elseif (operation == "edit") then
            local table = db.getTable ("route")
            local count = 0
            local rowids = {}
            for k,v in pairs (table) do
                if ((v["route.dstIpAddr"] == inputTable["route.dstIpAddr"] and v["route.metric"] == inputTable["route.metric"]) or 
                    (v["route.dstIpAddr"] == inputTable["route.dstIpAddr"] and v["route.gwIpAddr"] == inputTable["route.gwIpAddr"]) or 
                    (v["route.routeName"] == inputTable["route.routeName"]))then
                    count = count + 1
                    rowids[count] = v["route._ROWID_"]
                end
            end
            if ((#rowids == 0) or (#rowids == 1 and rowids[1] == rowid)) then
                valid = db.update("route", inputTable, rowid)
    	    	if (valid) then
	    	    	statusMsg = "STATUS_OK"
    	    	else
	    	    	statusMsg = "ROUTE_EDIT_FAILED"
    		    end
            else
                statusMsg = "ROUTE_ALREADY_EXISTS"
                valid = false
            end
	    end
	end

	-- return
	if (valid) then
        if(dbFlag == 1) then
            db.commitTransaction(true)
        end
		return "OK", statusMsg
	else
        if(dbFlag == 1) then
            db.rollback()
        end
		return "ERROR", statusMsg
	end
end

-- routing config
function iproute.tr69Config (inputTable, rowid, operation)
	-- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "Administrator Privileges Are Required"
	end

	local valid = false
        local statusMsg = ""
	
	-- config Routes
	if (iproute.inputvalidate(inputTable)) then
	    if (operation == "add") then
            local table = db.getRowsWhere ("route", "routeName = '" .. inputTable["route.routeName"] .. "'")
            if (#table == 0) then
                table = db.getTable ("route")
                local count = 0
                local rowids = {}
                for k,v in pairs (table) do
                    if (v["route.dstIpAddr"] == inputTable["route.dstIpAddr"] and
                        v["route.metric"] == inputTable["route.metric"]) then
                        count = count + 1
                        rowids[count] = v["route._ROWID_"]
                    end
                end
                if (#rowids == 0) then
                    valid = db.insert("route", inputTable)
    	    	    if (valid) then
	    	    	    statusMsg = "STATUS_OK"
    	    	    else
	    	    	    statusMsg = "ROUTE_ADD_FAILED"
    		        end
                else
                    statusMsg = "ROUTE_ALREADY_EXISTS"
                    valid = false
                end   
            else
                    statusMsg = "ROUTE_ALREADY_EXISTS"
                valid = false
            end
    	elseif (operation == "edit") then
            local table = db.getTable ("route")
            local count = 0
            local rowids = {}
            for k,v in pairs (table) do
                if (v["route.dstIpAddr"] == inputTable["route.dstIpAddr"] and
                    v["route.metric"] == inputTable["route.metric"]) then
                    count = count + 1
                    rowids[count] = v["route._ROWID_"]
                end
            end
            if ((#rowids == 0) or (#rowids == 1 and rowids[1] == rowid)) then
                valid = db.update("route", inputTable, rowid)
    	    	if (valid) then
	    	    	statusMsg = "STATUS_OK"
    	    	else
	    	    	statusMsg = "ROUTE_EDIT_FAILED"
    		    end
            else
                statusMsg = "ROUTE_ALREADY_EXISTS"
                valid = false
            end
	    end
	end

	-- return
	if (valid) then
		return "OK", statusMsg
	else
		return "ERROR", statusMsg
	end
end

--Route(s) Delete
function iproute.deleteRoute (rowIds)
	-- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end

	db.beginTransaction() --begin transaction
	local valid = false

	-- delete routes
	for k,v in pairs(rowIds) do
        local inTable = {}
        inTable["route._ROWID_"] = v;
	    valid = db.delete("route", inTable)
	    if (not valid) then
	    	break
	    end
	end

	-- return
	if (valid) then
		db.commitTransaction(true)
		return "OK", "STATUS_OK"
	else
		db.rollback()
		return "ERROR", "ROUTE_DELETE_FAILED"
	end
end

-- route inputvalidate
function iproute.inputvalidate (inputTable)
	local valid = db.typeAndRangeValidate(inputTable)
	if (valid) then
		return true
	else
		return false
	end
end

-- Ipv6 routing config
function iproute.ipv6Config (inputTable, rowid, operation, dbFlag)
    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if(dbFlag == 1) then
        db.beginTransaction() --begin transaction
    end

    local valid = false
    local statusMsg = ""
	
    -- config Routes
    if (iproute.inputvalidate(inputTable)) then
        if (operation == "add") then
            local table = db.getRowsWhere ("route6", "routeName = '" .. inputTable["route6.routeName"] .. "'")
            if (#table == 0) then
                local table = db.getTable ("route6")
                local count = 0
                local rowids = {}
                for k,v in pairs (table) do
                    if ((v["route6.dstIpAddr"] == inputTable["route6.dstIpAddr"] and v["route6.metric"] == inputTable["route6.metric"]) or 
                        (v["route6.dstIpAddr"] == inputTable["route6.dstIpAddr"] and v["route6.gwIpAddr"] == inputTable["route6.gwIpAddr"])) then
                        count = count + 1
                        rowids[count] = v["route6._ROWID_"]
                    end
                end
                if (#rowids == 0) then
                    valid = db.insert("route6", inputTable)
	                if (valid) then
            		    statusMsg = "STATUS_OK"
        	        else
		                statusMsg = "ROUTE_ADD_FAILED"
                    end
                else
                     statusMsg = "ROUTE_ALREADY_EXISTS"
                     valid = false
                end
            else
                statusMsg = "ROUTE_ALREADY_EXISTS"
                valid = false
            end
    	elseif (operation == "edit") then
            local table = db.getTable ("route6")
            local count = 0
            local rowids = {}
            for k,v in pairs (table) do
                if ((v["route6.dstIpAddr"] == inputTable["route6.dstIpAddr"] and v["route6.metric"] == inputTable["route6.metric"]) or 
                    (v["route6.dstIpAddr"] == inputTable["route6.dstIpAddr"] and v["route6.gwIpAddr"] == inputTable["route6.gwIpAddr"]) or 
                    (v["route6.routeName"] == inputTable["route6.routeName"])) then
                    count = count + 1
                    rowids[count] = v["route6._ROWID_"]
                end
            end
            if ((#rowids == 0) or (#rowids == 1 and rowids[1] == rowid)) then
        	    valid = db.update("route6", inputTable, rowid)
	            if (valid) then
            		statusMsg = "STATUS_OK"
                else
            		statusMsg = "ROUTE_EDIT_FAILED"
        	    end
            else
                statusMsg = "ROUTE_ALREADY_EXISTS"
                valid = false
            end
    	end
    end

    -- return
    if (valid) then
        if(dbFlag == 1) then
	        db.commitTransaction(true)
        end
    	return "OK", statusMsg
    else
        if(dbFlag == 1) then
	        db.rollback()
        end
    	return "ERROR", statusMsg
    end
end

-- Ipv6 routing config
function iproute.tr69IPv6Config (inputTable, rowid, operation)
    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    local valid = false
    local statusMsg = ""
	
    -- config Routes
    if (iproute.inputvalidate(inputTable)) then
        if (operation == "add") then
            local table = db.getRowsWhere ("route6", "routeName = '" .. inputTable["route6.routeName"] .. "'")
            if (#table == 0) then
                local table = db.getTable ("route6")
                local count = 0
                local rowids = {}
                for k,v in pairs (table) do
                    if (v["route6.dstIpAddr"] == inputTable["route6.dstIpAddr"] and
                        v["route6.metric"] == inputTable["route6.metric"]) then
                        count = count + 1
                        rowids[count] = v["route6._ROWID_"]
                    end
                end
                if (#rowids == 0) then
                    valid = db.insert("route6", inputTable)
	                if (valid) then
            		    statusMsg = "STATUS_OK"
        	        else
		                statusMsg = "ROUTE_ADD_FAILED"
                    end
                else
                     statusMsg = "ROUTE_ALREADY_EXISTS"
                     valid = false
                end
            else
                statusMsg = "ROUTE_ALREADY_EXISTS"
                valid = false
            end
    	elseif (operation == "edit") then
            local table = db.getTable ("route6")
            local count = 0
            local rowids = {}
            for k,v in pairs (table) do
                if (v["route6.dstIpAddr"] == inputTable["route6.dstIpAddr"] and
                    v["route6.metric"] == inputTable["route6.metric"]) then
                    count = count + 1
                    rowids[count] = v["route6._ROWID_"]
                end
            end
            if ((#rowids == 0) or (#rowids == 1 and rowids[1] == rowid)) then
        	    valid = db.update("route6", inputTable, rowid)
	            if (valid) then
            		statusMsg = "STATUS_OK"
                else
            		statusMsg = "ROUTE_EDIT_FAILED"
        	    end
            else
                statusMsg = "ROUTE_ALREADY_EXISTS"
                valid = false
            end
    	end
    end

    -- return
    if (valid) then
    	return "OK", statusMsg
    else
    	return "ERROR", statusMsg
    end
end

-- Ipv6 Route(s) Delete
function iproute.deleteIpv6Route (rowIds)
    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    db.beginTransaction() --begin transaction
    local valid = false

    -- delete routes
    for k,v in pairs(rowIds) do
        local inTable = {}
        inTable["route6._ROWID_"] = v;
    	valid = db.delete("route6", inTable)
	    if (not valid) then
	        break
    	end
    end

    -- return
    if (valid) then
	    db.commitTransaction(true)
    	return "OK", "STATUS_OK"
    else
	    db.rollback()
    	return "ERROR", "ROUTE_DELETE_FAILED"
    end
end

--***************************************************************************
	--Function to execute the scripts for ipv4 and ipv6 routes
--***************************************************************************
--@name iproute.ipv4RouteGet()
--
--@description The function executes the command for getting the ipv4 routes
--
--@return


function iproute.ipv4RouteGet()
	
	--locals
	local route4Tbl = db.getAttribute("environment", "name", "ROUTE_SCRIPT","value")
	local route4File = db.getAttribute("environment", "name", "ROUTE_FILE_NAME","value")
	local script = "/bin/sh"
    local ipRouteTbl = {}
    local lvar = 0
    local i = 1

    --executing the script and directing it to the route6 file
	os.execute(script .. " " .. route4Tbl .. " > " .. route4File);
	os.execute("usleep 500");

    -- open the file from which data needs to manipulated
    local pFile = assert(io.open(route4File,"rb"));
    if (pFile ~= nil) then
        for line in pFile:lines() do
            --skip the first two lines
            if(lvar < 2) then
                lvar= lvar+1
            else
                ipRouteTbl[i] = {}
                -- the "[^%s]+" pattern matches to every non-empty 
                -- string in between space characters.
                for token in string.gmatch(line, "[^%s]+") do
                    table.insert(ipRouteTbl[i], token)
                end
                i = i+1
            end
        end
    -- close the file
     if (pFile ~= nil) then
         io.close (pFile);
     end
 end

    return ipRouteTbl;	
end

--****************************************************************************
--@name iproute.ipv6RouteGet()
--
--@description The function executes the command to get the ipv6 routes
--
--@return

function iproute.ipv6RouteGet()

	--locals
	local route6Tbl = db.getAttribute("environment", "name", "ROUTE6_SCRIPT","value")
	local route6File = db.getAttribute("environment", "name", "ROUTE6_FILE_NAME","value")
	local script = "/bin/sh"
    local ipRouteTbl = {}
    local lvar = 0
    local i = 1

    --executing the script and directing it to the route6 file
	os.execute(script .. " " .. route6Tbl .. " > " .. route6File);
    os.execute("usleep 100");

    -- open the file from which data needs to manipulated
    local pFile = assert(io.open(route6File,"rb"));
    if (pFile ~= nil) then
        for line in pFile:lines() do
            --skip the first two lines
            if(lvar < 2) then
                lvar= lvar+1
            else
                ipRouteTbl[i] = {}
                -- the "[^%s]+" pattern matches to every non-empty 
                -- string in between space characters.
                for token in string.gmatch(line, "[^%s]+") do
                    table.insert(ipRouteTbl[i], token)
                end
                i = i+1
            end
        end
    -- close the file
     if (pFile ~= nil) then
         io.close (pFile);
     end
end

    return ipRouteTbl;	
end

--***********************************************************************************
	--IPV4 Functions
--***********************************************************************************
--@name  iproute.ipv4routeTblGet()
--
--@description  The function gets the value from the database 
--
--@return  

function iproute.ipv4routeTblGet()
	--include
	require "teamf1lualib/iproute"

	--locals
	local routeTbl = {}	
	local inputTable = {}

	--getting the table
	routeTbl = db.getTable("route", false)
	if (routeTbl == nil) then
		return inputTable
	end
	
	--return 
	return routeTbl
end

--*******************************************************************************

function iproute.ipv4routeGet ()
	
		--locals
		local inputTable = {}
		
		--return 
		return inputTable
end

--********************************************************************************
--@name iproute.ipv4routeSet (inputTable)
--
--@description  - The function will add the table in the database
--		The function will check for the following-
--		1.if the gateway address in the same subnet as the interface	
--
--@param inputTable -The inputTable recevied from the management interface
--			
--@return 
--

function iproute.ipv4routeSet (inputTable, dbFlag)
	--include
	require "teamf1lualib/ifStatic"
	require "teamf1lualib/ifDev"
	require "teamf1lualib/iprouteTrExtn"
	
	--locals
	local errMsg = ""
	local statusMsg = ""
    local interfaceObject = ""
	if( iproute.inputvalidate(inputTable)) then 
		--check if the gateway address in the same subnet as the interface
		
		util.appendDebugOut("check if gw addr is in same subnet as interface")
		if (ifDev.validateAddrInNetwork(inputTable["gwIpAddr"],inputTable["interfaceName"]) ~= 1) then
			errMsg = "ERROR"
			statusMsg = "ROUTE_ERR_GATEWAY_NOT_IN_SUBNET"
			return errMsg, statusMsg
		end
       --[[This is handled in the TR069 routeTr.routingGet function
       interfaceObject = routeTr.RouteInterfaceGet (inputTable["interfaceName"])
       inputTable["interfaceObject"] = interfaceObject
       ]]--
		--adding the prefix
		route = util.addPrefix(inputTable, "route.")
		--setting the values for the iproutes
		errMsg, statusMsg = iproute.config(route, "-1", "add", dbFlag)
    	return errMsg, statusMsg

	else
			statusMsg = "INPUT_VALIDATION_FAILED"
			errMsg = "ERROR"
	end
	
	--return
	return errMsg, statusMsg
end

--********************************************************************************
--@name iproute.tr69IPv4routeSet (inputTable)
--
--@description  - The function will add the table in the database
--		The function will check for the following-
--		1.if the gateway address in the same subnet as the interface	
--
--@param inputTable -The inputTable recevied from the management interface
--			
--@return 
--

function iproute.tr69IPv4routeSet (inputTable)
	--include
	require "teamf1lualib/ifStatic"
	require "teamf1lualib/ifDev"
	require "teamf1lualib/iprouteTrExtn"
	
	--locals
	local errMsg = {}
	local statusMsg = {}
    local interfaceObject = ""
	if( iproute.inputvalidate(inputTable)) then 
		--check if the gateway address in the same subnet as the interface
		
		util.appendDebugOut("check if gw addr is in same subnet as interface")
		if (ifDev.validateAddrInNetwork(inputTable["gwIpAddr"],inputTable["interfaceName"]) ~= 1) then
			errMsg = "ERROR"
			statusMsg = "ROUTE_ERR_GATEWAY_NOT_IN_SUBNET"
			return errMsg, statusMsg
		end
       --[[This is handled in the TR069 routeTr.routingGet function
       interfaceObject = routeTr.RouteInterfaceGet (inputTable["interfaceName"])
       inputTable["interfaceObject"] = interfaceObject
       ]]--
		--adding the prefix
		route = util.addPrefix(inputTable, "route.")
		--setting the values for the iproutes
		errMsg, statusMsg = iproute.tr69Config(route, "-1", "add")
    	return errMsg, statusMsg

	else
			statusMsg = "INPUT_VALIDATION_FAILED"
			errMsg = "ERROR"
	end
	
	--return
	return errMsg, statusMsg
end

--*****************************************************************************
--@name iproute.ipv4routeEditGet (rowid)
--
--@description - The function will get the detail of the row to be edited
--
--@param rowid - The row is the parameter which is passed from the 
--				management interface
--
--@return 
--
function iproute.ipv4routeEditGet (rowid)

	--include
	require "teamf1lualib/ifDev"

	--locals
	local query = nil
	local row = {}
	local inputTable = {}
		
	-- get the route being edited
		
	query = "_ROWID_=" .. rowid
	--getting the row from the table route
	row = db.getRowWhere("route", query, false)
	if (row == nil) then
		return inputTable
	end

	--return
	return row

end

--******************************************************************************
--@name iproute.ipv4routeEditSet(inputTable)
--
--@description - The function will set the fields of a row to be edited
--
--@param inputTable - inputTable contains the value of the row to be edited
--
--@return 
function iproute.ipv4routeEditSet(inputTable, dbFlag)

	--include
	require "teamf1lualib/ifDev"

	--locals	
	local errMsg 
	local statusMsg
	local route = {} 
	
    -- check if the gateway address in the same subnet as the interface
	util.appendDebugOut("check if gw addr is in same subnet as interface")
		if (ifDev.validateAddrInNetwork(inputTable["gwIpAddr"],inputTable["interfaceName"]) ~= 1) then
				errMsg = "ERROR"
				statusMsg = "ROUTE_ERR_GATEWAY_NOT_IN_SUBNET"
				return errMsg,statusMsg
		end	

	route = util.addPrefix(inputTable, "route.")
	 errMsg, statusMsg = iproute.config(route, route["route._ROWID_"], "edit", dbFlag)

	return errMsg, statusMsg


end 

--*******************************************************************************
--@name  iproute.ipv4routeDelete (rowids) 
--
--@description  The function will delete the row passed 
--				from the management interface
--@param row  The parameter contains the row to be deleted
--
--@return 
--	   

function iproute.ipv4routeDelete (rowids) 
	
	--include
	local statusMsg = {}
	local errMsg = {}
	
	--deleting the required row
	errMsg, statusMsg = iproute.deleteRoute(rowids)

    -- save db if no error
    if (errMsg == "OK") then db.save() end

	--return
	return errMsg, statusMsg

end	
--*****************************************************************************
--@name iproute.v4deleteByName(name)
--
--@description - The function will delete the row if the route name mached
--
--@param name - parameter contain the routeName to be deleted
--
--@return  

function iproute.v4deleteByName(name)
	
	--debug
	util.appendDebugOut("The name of the route is  = " ..name)

	--locals
	local query = nil
	local row = {}
	local statusMsg, errMsg
	
	query = "routeName ='" .. name .. "'"
	row = db.getRowWhere("route", query, false)
	if (row == nil) then
			errMsg = "ERROR"
			statusMsg = "ROUTE_NOT_FOUND"
	else
		
		errMsg, statusMsg = iproute.deleteRoute(row)
	end

	--return
	return errMsg, statusMsg

end

--*****************************************************************************
	--IPV6 Functions
--*****************************************************************************
--@name iproute.ipv6routeTblGet ()
--
--@description  --The function gets the value from the database 
--
--@return

function iproute.ipv6routeTblGet ()
	
	--locals
	local routeTbl = {}
	local inputTable = {}

	--getting the ipv6 info from the route6 table
	routeTbl = db.getTable("route6", false)
	if (routeTbl == nil) then
		return inputTable
	end

	--return
	return routeTbl

end

--*****************************************************************************

function  iproute.ipv6routeGet ()
	
		--locals
		local inputTable = {}
		
		--return 
		return inputTable
  
end

--****************************************************************************
--@name  iproute.ipv6routeSet (inputTable)
--
--@description  - The function will add the table in the database
--		It will check for following-
--	1.	if the destination is a reserved address
--	2.	if the gateway is a reserved address
--	3.	if the gateway address in the same subnet as the interface
--
--@param inputTable -The inputTable recevied from the management interface
--			
--@return 
--

function iproute.ipv6routeSet (inputTable, dbFlag)
	
	--include
	require "teamf1lualib/ifStatic"
	require "teamf1lualib/ifDev"
	require "ifDevLib"	

	--locals
	local errMsg = nil
	local statusMsg = nil
	local route = {}
   	local size = 0

   	--maximum limit check
    	local Statictable = db.getRowsWhere ("route6" ,"routeType = '0'" )
    	if (Statictable ~= nil ) then
        	size=#Statictable
    	end
    	if( size >=  100 ) then
           errMsg = "ERROR"
           statusMsg = "MAXIMUM LIMIT REACHED"
           return errMsg,statusMsg
    	end
	
	util.appendDebugOut("checking if desitnation is a reserved address")
  
    if (inputTable["interfaceName"] ~= "sit0-WAN") then

	    -- check if the destination is a reserved address
	    if (ifDevLib.isIpv6AddressReserved(inputTable["dstIpAddr"]) > 0) then
		    erMsg = "ERROR"
		    statusMsg = "RESERVED_IPV6_ADDRESS1"
		    return errMsg, statusMsg
	    end
  
	    -- check if the gateway is a reserved address
	    util.appendDebugOut("checking if gateway is a reserved address")
	    if (ifDevLib.isIpv6AddressReserved(inputTable["gwIpAddr"]) > 0) then
		    erMsg = "ERROR"
		    statusMsg = "RESERVED_IPV6_ADDRESS2"
		    return errMsg, statusMsg
	    end

	    --check if the gateway address in the same subnet as the interface
	    util.appendDebugOut("checking if gateway address is in the same subnet as the interface")
	    if (ifDev.validateAddrInNetwork(inputTable["gwIpAddr"],inputTable["interfaceName"]) ~= 1) then
		    erMsg = "ERROR"
		    statusMsg = "GATEWAYIP_NOT_IN_SUBNET_OF_INTERFACE"
		    return errMsg, statusMsg
	    end

        if(dbFlag == 1) then
	        -- check if the gateway ip is already configured on any interface
            local ipAddressTbl = db.getRowsWhere("ipAddressTable", "addressFamily=10", false)
            for k,v in pairs (ipAddressTbl) do
                if(v["ipAddress"] == inputTable["gwIpAddr"]) then
                    errmsg = "ERROR"
		            statusMsg = "IP_CONFIGURED_ON_SYSTEM"
		            return errMsg, statusMsg
                end
            end
        end
    else
        if (iproute.validateTunnelNetwork (inputTable["gwIpAddr"], inputTable["interfaceName"]) ~= 1) then
            errmsg = "ERROR"
		    statusMsg = "TUNNEL_INTERFACE_IS_NOT_CONFIGURED"
		    return errMsg, statusMsg
        end
    end

	util.appendDebugOut("configure the ipv6 address")
	
	--adding prefix
	route = util.addPrefix(inputTable, "route6.")

	--adding the routes
	errMsg, statusMsg = iproute.ipv6Config(route, "-1", "add", dbFlag)


    -- save db if no error
    if (errMsg == "OK") then db.save() end

	--return
	return errMsg, statusMsg


end

--****************************************************************************
--@name  iproute.tr69IPv6routeSet (inputTable)
--
--@description  - The function will add the table in the database
--		It will check for following-
--	1.	if the destination is a reserved address
--	2.	if the gateway is a reserved address
--	3.	if the gateway address in the same subnet as the interface
--
--@param inputTable -The inputTable recevied from the management interface
--			
--@return 
--

function iproute.tr69IPv6routeSet (inputTable)
	
	--include
	require "teamf1lualib/ifStatic"
	require "teamf1lualib/ifDev"
	require "ifDevLib"	

	--locals
	local errMsg = nil
	local statusMsg = nil
	local route = {}
	
	util.appendDebugOut("checking if desitnation is a reserved address")
  
    if (inputTable["interfaceName"] ~= "sit0-WAN") then

	    -- check if the destination is a reserved address
	    if (ifDevLib.isIpv6AddressReserved(inputTable["dstIpAddr"]) > 0) then
		    erMsg = "ERROR"
		    statusMsg = "RESERVED_IPV6_ADDRESS1"
		    return errMsg, statusMsg
	    end
  
	    -- check if the gateway is a reserved address
	    util.appendDebugOut("checking if gateway is a reserved address")
	    if (ifDevLib.isIpv6AddressReserved(inputTable["gwIpAddr"]) > 0) then
		    erMsg = "ERROR"
		    statusMsg = "RESERVED_IPV6_ADDRESS2"
		    return errMsg, statusMsg
	    end

	    --check if the gateway address in the same subnet as the interface
	    util.appendDebugOut("checking if gateway address is in the same subnet as the interface")
	    if (ifDev.validateAddrInNetwork(inputTable["gwIpAddr"],inputTable["interfaceName"]) ~= 1) then
		    erMsg = "ERROR"
		    statusMsg = "GATEWAYIP_NOT_IN_SUBNET_OF_INTERFACE"
		    return errMsg, statusMsg
	    end
    else
        if (iproute.validateTunnelNetwork (inputTable["gwIpAddr"], inputTable["interfaceName"]) ~= 1) then
            errmsg = "ERROR"
		    statusMsg = "TUNNEL_INTERFACE_IS_NOT_CONFIGURED"
		    return errMsg, statusMsg
        end
    end

	util.appendDebugOut("configure the ipv6 address")
	
	--adding prefix
	route = util.addPrefix(inputTable, "route6.")

	--adding the routes
	errMsg, statusMsg = iproute.tr69IPv6Config(route, "-1", "add")

    -- save db if no error
    if (errMsg == "OK") then db.save() end

	--return
	return errMsg, statusMsg


end

--**************************************************************************
--@name iproute.ipv6routeEditGet (rowid)
--
--@description - The function will get the detail of the row to be edited
--
--@param rowid - The row is the parameter which is passed from the 
--				management interface
--@return row -The function will return the row with the rowid passed from the
--				interface

function iproute.ipv6routeEditGet (rowid)

	--include
	require "teamf1lualib/ifDev"
	
	--locals
	local query = nil
	local row = {}
	local inputTable = {}	

	-- get the route being edited
	query = "_ROWID_=" .. rowid
	row = db.getRowWhere("route6", query, false)
	if (row == nil) then
		return inputTable
	end

	--return
	return row
end

--****************************************************************************
--@name iproute.ipv6routeEditSet (inputTable, dbFlag)
--
--@description - The function will set the fields of a row to be edited
--		It will check for the following -
--		1.if the destination is a reserved address
--		2.if the gateway is a reserved address
--		3. if the gateway address in the same subnet as the interface
--
--@param inputTable - inputTable contains the value of the row to be edited
--
--@return 
--

function iproute.ipv6routeEditSet (inputTable, dbFlag)
	
	--include
	require "teamf1lualib/ifDev"

	--locals
	local errMsg = ""
	local statusMsg = ""
	local route = {}
	
	util.appendDebugOut("checking if desitnation is a reserved address")

    if (inputTable["interfaceName"] ~= "sit0-WAN") then

	    -- check if the destination is a reserved address
	    if (ifDevLib.isIpv6AddressReserved(inputTable["dstIpAddr"]) > 0) then
		    errMsg = "ERROR"
		    statusMsg = "RESERVED_IPV6_ADDRESS"
		    return errMsg, statusMsg
	    end
	    -- check if the gateway is a reserved address
	    util.appendDebugOut("checking if gateway is a reserved address")
	    if (ifDevLib.isIpv6AddressReserved(inputTable["gwIpAddr"]) > 0) then
		    errMsg = "ERROR"
		    statusMsg = "RESERVED_IPV6_ADDRESS"
		    return errMsg, statusMsg
	    end

	    -- check if the gateway address in the same subnet as the interface
	    util.appendDebugOut("check if gw addr is in same subnet as interface")
	    if (ifDev.validateAddrInNetwork(inputTable["gwIpAddr"], inputTable["interfaceName"]) ~= 1) then
		    errMsg = "ERROR"
		    statusMsg = "GATEWAYIP_NOT_IN_SUBNET_OF_INTERFACE"
		    return errMsg, statusMsg
	    end

        -- check if the gateway ip is already configured on any interface
        local ipAddressTbl = db.getRowsWhere("ipAddressTable", "addressFamily=10", false)
        for k,v in pairs (ipAddressTbl) do
            if(v["ipAddress"] == inputTable["gwIpAddr"]) then
                errmsg = "ERROR"
		        statusMsg = "IP_CONFIGURED_ON_SYSTEM"
		        return errMsg, statusMsg
            end
        end
    else
        if (iproute.validateTunnelNetwork (inputTable["gwIpAddr"], inputTable["interfaceName"]) ~= 1) then
            errMsg = "ERROR"
		    statusMsg = "TUNNEL_INTERFACE_IS_NOT_CONFIGURED"
		    return errMsg, statusMsg
        end
    end


	route = util.addPrefix(inputTable, "route6.")
	errMsg, statusMsg = iproute.ipv6Config(route, route["route6._ROWID_"], "edit", dbFlag)

    -- save db if no error
    if (errMsg == "OK") then db.save() end

	return errMsg, statusMsg

end 

--*******************************************************************************
--@name iproute.ipv6routeDelete (rowids)
--
--@description - The function will delete the row passed 
--		from the management interface
--
--@param row - The parameter contains the row to be deleted
--
--@return 
--
function iproute.ipv6routeDelete (rowids)
	
	--locals
	local statusMsg 
	local errMsg
	
	--deleting the routes
	errMsg, statusMsg = iproute.deleteIpv6Route(rowids)

    -- save db if no error
    if (errMsg == "OK") then db.save() end

	--return
	return errMsg, statusMsg	

end 

--******************************************************************************
--@name iproute.v6deleteByName(name)
--
--@description - The function will delete the row if the route name mached
--
--@param name - parameter contain the routeName to be deleted
--
--@return 

function iproute.v6deleteByName(name)

	--locals
	local query = nil
	local row = {}
	local statusMsg, errMsg
	
	--query to get the name
	query = "routeName ='" .. name .. "'"

	--getting the route6 row from the table
	row = db.getRowWhere("route6", query, false)
	if (row == nil) then
		errMsg = "ERROR"
		statusMsg = "ROUTE_NOT_FOUND"
	else
	
		errMsg, statusMsg = iproute.deleteIpv6Route(row)
	end

	--return
	return errMsg, statusMsg

end

--****************************************************************************
	--END
--****************************************************************************


function iproute.import (inputTable,defaultConfigTable,removeConfig)
    if (inputTable == nil) then
        inputTable = defaultConfigTable
    end
    local route4Table = {}
	if (inputTable["route4"] ~= nil) then
        for i,v in pairs (inputTable.route4) do
            if (inputTable.route4[i]["metric"] == nil) then
                v["metric"] = defaultConfigTable.route4[i]["metric"] or ""
            end
            if (inputTable.route4[i]["gwIpAddr"] == nil) then
                v["gwIpAddr"] = defaultConfigTable.route4[i]["gwIpAddr"] or ""
            end
            if (inputTable.route4[i]["routeType"] == "" or inputTable.route4[i]["routeType"] == nil) then
                v["routeType"] = "0"
            end
        end
        route4Table = config.update(inputTable.route4,defaultConfigTable.route4,removeConfig.route4)
        if (route4Table ~= nil and #route4Table ~= 0) then
            for i,v in ipairs (route4Table) do
              if(v["routeType"] == "0") then
                v = util.addPrefix (v, "route.")
                iproute.config (v, "-1", "add", 1)
              end
            end
        end
	end

    local route6Table = {}
	if (inputTable["route6"] ~= nil) then
        for i,v in pairs (inputTable.route6) do
            if (inputTable.route6[i]["metric"] == nil) then
                v["metric"] = defaultConfigTable.route6[i]["metric"]
            end
             if (inputTable.route6[i]["interfaceObject"] == nil) then
                if(defaultConfigTable.route6[i] ~= nil)  then
                    v["interfaceObject"] = defaultConfigTable.route6[i]["interfaceObject"]
                end
            end
        end
        route6Table = config.update(inputTable.route6,defaultConfigTable.route6,removeConfig.route6)
        if (route6Table ~= nil and #route6Table ~= 0) then
            for i,v in ipairs (route6Table) do
                if (v["interfaceName"] ~= "sit0-WAN")then
                    v = util.addPrefix (v, "route6.")
                    iproute.ipv6Config (v, -1, "add", 1)
                end
            end
        end
    end
end

function iproute.export ()
    local table = {}
    -- export only static routes
    table["route4"] =  db.getRowsWhere ("route", "routeType=0", false)
    table["route6"] =  db.getTable ("route6", false)
    return table
end

if (config.register) then
   config.register("route", iproute.import, iproute.export, "1")
end

--******************************************************************************
--@name iproute.6to4StaticRouteConfigure(conf)
--
--@description - The function will update static route row for 6to4 tunnel
--
--@param name - parameter contain the conf table
--
--@return 

function iproute.sixToFourStaticRouteConfigure(conf)

    local query

    -- Get the sixToFour configuration
    query = "routeName='6to4-Tunnel'"
    local row = db.getRowWhere("route6", query, false)
    if (row ~= nil) then
        row = iproute.sixToFourCfgInit(row, conf)

        row = util.addPrefix(row, "route6.")
        local valid, errstr = db.update("route6", row, row["route6._ROWID_"])
        if (not valid) then
            return "ERROR", "6TO4_ROUTE_UPDATE_FAILED"
        end            
    else
        row = iproute.sixToFourDefCfgGet()
        row = iproute.sixToFourCfgInit(row, conf)

        util.appendDebugOut ("conf.." .. util.tableToStringRec(row))

        row = util.addPrefix(row, "route6.")
        local valid, errstr, rowid  = db.insert("route6", row)
        if (not valid) then
            return "ERROR", "6To4_ROUTE_ADD_FAILED"
        end            
    end        

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name iproute.sixToFourCfgInit
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function iproute.sixToFourCfgInit (row, conf)

    if (conf["routeName"] ~= nil) then
        row["routeName"] = conf["routeName"]  
    end        
    
    if (conf["dstIpAddr"] ~= nil) then
        row["dstIpAddr"] = conf["dstIpAddr"]  
    end        

    if (conf["prefix"] ~= nil) then
        row["prefix"] = conf["prefix"]  
    end

    if (conf["gwIpAddr"] ~= nil) then
        row["gwIpAddr"] =  conf["gwIpAddr"]
    end

    if (conf["interfaceName"] ~= nil) then
        row["interfaceName"] = conf["interfaceName"]
    end

    if (conf["metric"] ~= nil) then
        row["metric"] = conf["metric"]
    end

    if (conf["active"] ~= nil) then
        row["active"] = conf["active"]
    end

    return row
end

-------------------------------------------------------------------------
-- @name iproute.sixToFourDefCfgGet
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function iproute.sixToFourDefCfgGet()
    local conf = {}
    
    conf["routeName"] = " 6to4-Tunnel"
    conf["dstIpAddr"] = "2000::"
    conf["prefix"] = "3"
    conf["gwIpAddr"] = "::192.88.99.1"
    conf["interfaceName"] = "sit0-WAN"
    conf["metric"] = "15"
    conf["active"] = "0"

    return conf
end

--[[
--*****************************************************************************
-- iproute.validateTunnelNetwork - validate if 6to4 tunnel is enabled and gw addr 
-- 
-- This function validates if gw address and 6to4 tunnel network is enabled.
--
-- RETURN: 
-- -3 other errors
-- -2 invalid addresss
-- -1 no address configured on the interface
--  0 address does not belong to the same network
--  1 if the address belongs to same subnet/network 
]]--

function iproute.validateTunnelNetwork (addr, ifname)
	local ipRows = {}
    local where = "LogicalIfName = '" .. ifname .. "' and addressFamily= '10'" 

	-- get all the addresses that belong to the 
	-- specified interface
    if (not db.existsRowWhere ("ipAddressTable", where)) then
		return -1
	end
    
    if (addr ~= nil) then
        return 1
    end
	
	return 0
end
