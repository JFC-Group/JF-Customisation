-- @copyright Copyright (c) 2012, TeamF1, Inc. 

require "teamf1lualib/evtDsptch"
require "appExtn/AppExtn"
require "thttpdLib"

ThttpdExtn = OoUtil.inheritsFrom(AppExtn)
ThttpdExtn.name    = "tiny/turbo/throttling HTTP server"
ThttpdExtn.classId = "thttpd"
ThttpdExtn.className  =  "ThttpdExtn"
ThttpdExtn.dbTable = "accessMgmt"
ThttpdExtn.logger  = nil

local SUPER = require("appExtn.AppExtn")

-- network events
local netEvents = {}
netEvents[evtDsptch.event.IFDEV_EVENT_IP4_NET_UP]   =  1
netEvents[evtDsptch.event.IFDEV_EVENT_IP4_NET_DOWN] =  1

-- configuration events
local cfgEvents = {}
cfgEvents[db.event.SQLITE_INSERT] = 1
cfgEvents[db.event.SQLITE_UPDATE] = 1
cfgEvents[db.event.SQLITE_DELETE] = 1

-------------------------------------------------------------------------------
-- @name ThttpdExtn.cfgEventCallback
--
-- @description 
--
-- @param  
--
-- @return  
--

function ThttpdExtn.cfgEventCallback(obj, info)
    local status = "ERROR"
    local errcode = ""

    LOG:ddebug(ThttpdExtn.classId .. " configuration callback called  " .. 
              "for event: " ..  info.event .. " on rowId " .. info.rowId)

    if (info.event == db.event.SQLITE_INSERT) then
        if (obj ~= nil) then 
            assert(nil, ThttpdExtn.classId .. "(" .. info.rowId  .. ")" ..
                   "already created")
            return -1
        end        

        -- create instance and process event
        obj = ThttpdExtn:new(info.rowId)
        if (obj) then 
            obj:onCfgEvent(info) 
        end

    elseif (info.event == db.event.SQLITE_UPDATE) then
        -- re-load and process event
        if (obj) then 
            status, errCode, obj = obj:load()
            if (status == "OK") then
                obj:onCfgEvent(info) 
            end            
        end
    elseif (info.event == db.event.SQLITE_DELETE) then
        -- process event and destroy instance
        if (obj) then
            obj:onCfgEvent(info)
            obj:delete()
        end
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name ThttpdExtn.bootstrap
--
-- @description This function is called by appd on startup to bootstrap all 
-- instances of this application. 
--
-- @param  
--
-- @return  
--

function ThttpdExtn.bootstrap()
    local instanceId
    local callbackTable= {}

    thttpdLib.killAll()

    local callback = {}
    callback.type = appd.eventType.APPD_EV_CFG
    callback.dbTable = ThttpdExtn.dbTable
    callback.routine = ThttpdExtn.cfgEventCallback
    table.insert(callbackTable, callback)
    appd.callbackRegister (ThttpdExtn.classId, callbackTable)

    local cfg = db.getTable(ThttpdExtn.dbTable, false)
    if (cfg == nil) then
        return 0
    end        

    for index, record in pairs(cfg) do
        instanceId = record["_ROWID_"]
        local obj = ThttpdExtn:new(instanceId)
        if (obj and obj:isEnabled()) then
            obj:start()
        end                        
    end

    return 0
end

-------------------------------------------------------------------------------
-- @name ThttpdExtn:new
--
-- @description This function creates a new instance object for thttpd, loads
-- the configuration and event subcriptions
--
-- @return  0 for success and -1 for error
--

function ThttpdExtn:new(instanceId, props)

    -- create a new instance
    self = ThttpdExtn.create()

    SUPER.new(self, ThttpdExtn.classId, instanceId, props)

    self.name  = ThttpdExtn.name
    self.dbTable =  ThttpdExtn.dbTable

    -- initialize events for this instance
    self.netEvents = netEvents              
    self.cfgEvents = cfgEvents

    -- load the instance          
    local status, errCode, self = self:load()
    if (status == nil) then
        LOG:error("failed to load " .. classId .. 
                  "(" .. instanceId .. ")")
        return nil
    end        

    -- register with appd
    appd.appExtnRegister(self)                    

    return self
end

-------------------------------------------------------------------------------
-- @name ThttpdExtn:delete
--
-- @description This function deletes an instance of this extension
--
-- @param instanceId
--
-- @return  
--

function ThttpdExtn:delete()
    appd.appExtnUnregister(self)
end

-------------------------------------------------------------------------------
-- @name ThttpdExtn:stop
--
-- @description This function starts thttpd
--
-- @return  0 for success and -1 for error
--

function ThttpdExtn:stop ()
    local props = self:getProps()

    thttpdLib.cfgLoad(props)

    LOG:info("Stopping " .. self.name .. 
             "(" ..  self.instanceId .. ")")

    thttpdLib.stop()

    return 0
end

-------------------------------------------------------------------------------
-- @name ThttpdExtn:isEnabled
--
-- @description This function checks if this instance is enabled
--
-- @return  true if enabled else false
--

function ThttpdExtn:isEnabled()
    require "teamf1lualib/network"

    local props = self:getProps()

    --
    -- The server is always running on secure networks
    -- The field accessMgmtEnable only determines if
    -- it is HTTP or HTTPS
    --
    if (network.isLAN(props.LogicalIfName)) then
        return true
    end
            
    if (tonumber(props.accessMgmtEnable) > 0) then
        return true
    end        

    return false
end

-------------------------------------------------------------------------------
-- @name ThttpdExtn:start
--
-- @description This function starts thttpd
--
-- @return  0 for success and -1 for error
--

function ThttpdExtn:start ()
    require "teamf1lualib/nimf"
    local props = self:getProps()

    if (self:isEnabled()) then

        -- check if the network is UP
        if (nimfConn.isUp(props.LogicalIfName) == false) then
            LOG:debug(self.name .. " Network:" .. props.LogicalIfName  .. 
                      " is not UP")
            return -1
        end        

        if (thttpdLib.cfgLoad(props) < 0) then
            return -1
        end            

        LOG:info("Starting " .. self.name .. 
                    "(" ..  self.instanceId .. ")")

        if (thttpdLib.start() < 0) then
            return -1
        end            
    end

    return 0
end

-------------------------------------------------------------------------------
-- @name ThttpdExtn:restart
--
-- @description This function restarts thttpd
--
-- @return  0 for success and -1 for error
--

function ThttpdExtn:restart ()

    -- stop the server
    self:stop() 

    -- start the server
    if (self:start() < 0) then
        return -1
    end                

    return 0
end

-------------------------------------------------------------------------------
-- @name ThttpdExtn:getAppName
--
-- @description This function gets the name of this extension
--
-- @return  
--

function ThttpdExtn:getAppName()
   return self.name
end

-------------------------------------------------------------------------------
-- @name ThttpdExtn:getDbTableName
--
-- @description This function gets the database table name which contains
-- configuration records for all instances of this application.
--
-- @return  
--

function ThttpdExtn:getDbTableName()
   return self.dbTable
end

-------------------------------------------------------------------------------
-- @name ThttpdExtn:onNetEvent
--
-- @description This function handles network events
--
-- @param  netevent  network event
--
-- @return  0 for success and -1 for error
--

function ThttpdExtn:onNetEvent(netevent)

    if (self:isEventSubscribed(netevent) == false) then
        LOG:ddebug(self.classId .. " not subscribed to event: " ..
                   netevent.event .. " on " .. netevent.ifname)
        return 0
    end        

    self:restart()

    return 0
end

-------------------------------------------------------------------------------
-- @name ThttpdExtn:isEventSubscribed
--
-- @description This function checks if this instance is subcribed to
-- the event pass as input
--
-- @param event event information
--
-- @return  0 for success and -1 for error
--

function ThttpdExtn:isEventSubscribed(event)
    local props = self:getProps()

    if (event.type == appd.eventType.APPD_EV_NET) then

        if (strlib.strcasecmp(props.LogicalIfName, event.ifname) ~= 0) then
            return false
        end            
        
        local evstate = self.netEvents[event.event]
        if (evstate == nil) then
            return false
        end            
                    
        if (evstate > 0) then
            return true
        end        

    elseif (event.type == appd.eventType.APPD_EV_CFG) then

        -- are we subscribed to this event                        
        local evstate = self.cfgEvents[event.event]
        if (evstate == nil) then
            return false
        end            

        if (evstate > 0) then
            return true
        end        
    end

    return false
end

-------------------------------------------------------------------------------
-- @name ThttpdExtn:onCfgEvent
--
-- @description This function is to handle configuration events
-- 
-- @param  cfgevent event information
--
-- @return  
--

function ThttpdExtn:onCfgEvent(cfgevent)
    local props = self:getProps()

    if (self:isEventSubscribed(cfgevent) == false) then
        LOG:ddebug(self.classId .. " not subscribed to event: " ..
                   cfgevent.event .. " on " .. cfgevent.dbTable)
        return
    end        

    if (cfgevent.event == db.event.SQLITE_INSERT) then
       self:start()
    elseif (cfgevent.event == db.event.SQLITE_UPDATE) then
        self:restart()
    elseif (cfgevent.event == db.event.SQLITE_DELETE) then
        self:stop()
    end                

    return
end

-------------------------------------------------------------------------------
-- @name ThttpdExtn:print
--
-- @description This function prints the properties of this application instance
--
-- @param  
--
-- @return  
--

function ThttpdExtn:print()
    require "util/strlib"

    LOG:info("Class     : " .. self.classId)
    LOG:info("Instance  : " .. self.instanceId)
    LOG:info("App Name  : " .. self:getAppName())
    LOG:info("Conf      : " .. strlib.serializeTbl(self:getProps()))
    return
end

return ThttpdExtn
