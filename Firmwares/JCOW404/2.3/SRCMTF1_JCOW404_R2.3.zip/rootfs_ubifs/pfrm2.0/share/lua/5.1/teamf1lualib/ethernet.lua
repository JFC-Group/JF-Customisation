--[[
#### Adarsh Uppula
#### TeamF1
#### www.TeamF1.com
#### June 29, 2007

#### File: ethernet.lua
#### Description: ethernet functions

#### Revisions:
None
]]--


--************* Requires *************


--************* Initial Code *************

--package ethernet
ethernet = {}
ethernetVLAN = {}
--************* Functions *************

-- ethernet config
function ethernet.ethernet_config (inputTable, rowid, operation)
    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
 
    if (ethernet.config (inputTable, rowid, operation)) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "ETHERNET_PORT_CONFIG_FAILED"
    end
end

-- ethernet config
function ethernet.config (inputTable, rowid, operation)
    -- validate
    if (ethernet.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("ethernet", inputTable)
        elseif (operation == "edit") then
            return db.update("ethernet", inputTable, rowid)
        elseif (operation == "delete") then
            return nil
        end
    end
    return false
end

-- ethernet config
function ethernetVLAN.config (inputTable, rowid, operation)
    -- validate
    if (ethernet.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("ethernetVLAN", inputTable)
        elseif (operation == "edit") then
            return db.update("ethernetVLAN", inputTable, rowid)
        elseif (operation == "delete") then
            for k,v in pairs(inputTable) do
                valid = db.deleteRow ("ethernetVLAN", "_ROWID_", v)
                if (not valid) then return false end
            end
            return true
        end
    end
    return false
end
--[[
*******************************************************************************
-- @name ethernet.confGet
--
--
--
-- @return conf or nil
--]]

function ethernet.confGet(ifName)
    local query = ""
    local record = {}
-- correcting query to Logical IF name.
    if (util.fileExists ("/pfrm2.0/FXN_ODU")) then
        query = "LogicalIfName='" .. ifName .. "'"
    else
        query = "interfaceName='" .. ifName .. "'"
    end
    record  = db.getRowWhere("ethernet", query, false) 
    if (record == nil) then
        return nil
    end        

    return record
end

-- ethernet inputvalidate
function ethernet.inputvalidate (inputTable, operation)
    if (true) then
        return db.typeAndRangeValidate(inputTable)
    end
    return false
end

function ethernet.trunkModeGet (LogicalIfName)

	local ethernetRow = {}
	ethernetRow = db.getRow ("ethernet", "LogicalIfName", LogicalIfName)
    if (ethernetRow == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN",nil
    end

    --return
    return "OK", "STATUS_OK", ethernetRow	

end

function ethernet.vlansGet (LogicalIfName)

	local vlanIf = {}
    if (LogicalIfName == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end
	
	vlanIf = db.getRows("ethernetVLAN", "LogicalIfName", LogicalIfName)
	return "OK", "STATUS_OK", vlanIf
	
	
end


function ethernet.trunkModeSet (inputTable, rowId, operation)
	require "teamf1lualib/bridgeLib"
	local valid = false
	local ifTbl = {}
	local status = ""
	local errorCode = ""
	local ethernetVlanTbl = {}

	-- update the DB
	valid = ethernet.config (inputTable, rowId, operation)

	if (valid) then
		local bridgeName= bridge.ifNameGet(inputTable["ethernet.LogicalIfName"])
		-- update bridgePorts entry.
		if (inputTable["ethernet.trunkPort"] == "1") then
			-- Remove phy interface and replace with vlan interfaces
			ifTbl[1] = {}
			ifTbl[1]["ifname"] = inputTable["ethernet.interfaceName"]
			status, errorCode = bridge.portDelete(bridgeName, ifTbl)
			ifTbl = {}
			ethernetVlanTbl = db.getRows ("ethernetVLAN", "LogicalIfName", inputTable["ethernet.LogicalIfName"])
			for k,v in pairs (ethernetVlanTbl) do
				ifTbl[k] = {}
				ifTbl[k]["ifname"] = inputTable["ethernet.interfaceName"].."."..v["ethernetVLAN.vlanId"]
			end
			status, errorCode = bridge.portAdd(bridgeName, ifTbl)
		else
			ethernetVlanTbl = db.getRows ("ethernetVLAN", "LogicalIfName", inputTable["ethernet.LogicalIfName"])
			for k,v in pairs (ethernetVlanTbl) do
				ifTbl[k] = {}
				ifTbl[k]["ifname"] = inputTable["ethernet.interfaceName"].."."..v["ethernetVLAN.vlanId"]
			end			
			status, errorCode = bridge.portDelete(bridgeName, ifTbl)
			ifTbl = {}
			ifTbl[1] = {}
			ifTbl[1]["ifname"] = inputTable["ethernet.interfaceName"]
			status, errorCode = bridge.portAdd(bridgeName, ifTbl)			
		end	
	end

	return status, errorCode

end

function ethernet.vlanAdd (ifName, vlanID)

	local  cmdStr = ""
	if (ifName == nil or vlanID == nil) then
		return "ERROR"
	end

	cmdStr = "/sbin/vconfig add " .. ifName .. " " .. vlanID
	os.execute(cmdStr)
	cmdStr = "/sbin/ifconfig " .. ifName .. "." .. vlanID .. " up"
	os.execute(cmdStr)
	return "OK"
end

	
function ethernet.vlanRemove (ifName, vlanID)
	local  cmdStr = ""
	if (ifName == nil or vlanID == nil) then
		return "ERROR"
	end
	cmdStr = "/sbin/vconfig rem " .. ifName .. "." .. vlanID
	os.execute(cmdStr)
	return "OK"
end


function ethernetVLAN.ethernetVLAN_config (inputTable, rowid, operation)
	require "teamf1lualib/bridgeLib"
	local interfaceName = ""
	local bridgeName = ""
	local ifTbl = {}
	local valid = false

	if (operation == "add" or operation == "edit") then
		valid = ethernetVLAN.config (inputTable, rowid, operation)

		bridgeName= bridge.ifNameGet(inputTable["ethernetVLAN.LogicalIfName"])
		interfaceName = db.getAttribute ("ethernet", "LogicalIfName", inputTable["ethernetVLAN.LogicalIfName"], "interfaceName")
		if (interfaceName ~= nil) then
			if (operation == "add") then
				ethernet.vlanAdd (interfaceName, inputTable["ethernetVLAN.vlanId"])
				if (bridgeName ~= nil and bridgeName ~= "") then
					ifTbl[1] = {}
					ifTbl[1]["ifname"] = interfaceName .. "." .. inputTable["ethernetVLAN.vlanId"]
					status, errorCode = bridge.portAdd(bridgeName, ifTbl)
				end
			end
		end

	elseif (operation == "delete") then
		for k,v in pairs (inputTable) do
			local vlanRow = db.getRow ("ethernetVLAN", "_ROWID_",v)
			if (vlanRow == nil) then
				return "ERROR", "ETHERNET_VLAN_CONFIG_FAILED"
			end
			interfaceName = db.getAttribute ("ethernet", "LogicalIfName", vlanRow["ethernetVLAN.LogicalIfName"], "interfaceName")
			bridgeName= bridge.ifNameGet(vlanRow["ethernetVLAN.LogicalIfName"])
			ifTbl[1] = {}
			ifTbl[1]["ifname"] = interfaceName .. "." .. vlanRow["ethernetVLAN.vlanId"]
			status, errorCode = bridge.portDelete(bridgeName, ifTbl)
			ethernet.vlanRemove (interfaceName, vlanRow["ethernetVLAN.vlanId"])
		end

		valid = ethernetVLAN.config (inputTable, rowid, operation)	
	end

	if (valid) then
		return "OK", "STATUS_OK"
	else
		return "ERROR", "ETHERNET_VLAN_CONFIG_FAILED"
	end
	
end

function ethernet.import (configTable,defaultConfig,removeConfig)

    if(configTable == nil) then
        configTable = defaultConfig
    end
    local ethernetTbl = {}
    ethernetTbl = config.update (configTable, defaultConfig, removeConfig)

    if (ethernetTbl ~= nil and #ethernetTbl ~= 0) then
        for i,v in pairs (ethernetTbl) do
            v = util.addPrefix (v, "ethernet.");
            ethernet.config (v, -1, "add")
        end
    end
end

function ethernetVLAN.import (configTable,defaultConfig,removeConfig)

    if(configTable == nil) then
        configTable = defaultConfig
    end
	local ethernetVLANTbl = {}
	ethernetVLANTbl = config.update (configTable, defaultConfig,removeConfig )

	if (ethernetVLANTbl ~= nil and #ethernetVLANTbl ~= 0) then
        for i,v in pairs (ethernetVLANTbl) do
            v = util.addPrefix (v, "ethernetVLAN.");
            ethernetVLAN.ethernetVLAN_config (v, -1, "add")
        end
    end
	
end

function ethernet.export ()
	return db.getTable ("ethernet", false)	
end

function ethernetVLAN.export ()
	return db.getTable ("ethernetVLAN", false)
end

if (config.register) then
   config.register("ethernet", ethernet.import, ethernet.export, "1")
   config.register("ethernetVLAN", ethernetVLAN.import, ethernetVLAN.export, "1")
end
