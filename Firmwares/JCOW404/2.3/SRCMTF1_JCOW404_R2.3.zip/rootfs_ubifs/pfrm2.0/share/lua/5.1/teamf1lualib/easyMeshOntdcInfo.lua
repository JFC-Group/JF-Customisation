--[[ easyMeshTopology.lua - Handler for Easy Mesh Topology request
--
-- Copyright (c) 2008-2019, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: easyMeshTopology.lua
-- Description: Handler for Easy Mesh Topology  request
-- 
-- modification history
-- --------------------
-- 01a, 1jun2020, vin written.
--
--]]

require "easyMeshLib"
require "teamf1lualib/easyMeshOntdcInfoLib"

-- Topology Object as defined by Customer Specification.
local TopologyRequestObj = {
    ["Topology"]      = {}
}

-- List of Topology Tags as defined by Customer Specification.
local TopologyObj = {
    ["Result"] = "Result"
}

-- Initialise the TopologyResponse_t Lua Table which will be coverted as JSON Object
local TopologyResponse_t = {
    ["Result"] = "ERROR",
    ["Response_Code"] = "400",
    ["Error_Message"] = "Failed to get WiFiSON"
}

-- Supported Return Codes for "LoginResponse"
local TopologyResponse_ReturnCodes = {
    ["OK"] = "OK",
    ["ERROR"] = "ERROR",
    ["SUCCESS"] = "Success",
    ["FAILED"]  = "Failed",
}

if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then
	TOPOLOGY_DUMP_GENERATE_CMD = "/bin/sh /pfrm2.0/bin/brcmGenerateDump.sh"
else
	TOPOLOGY_DUMP_GENERATE_CMD = "/userfs/bin/mapd_cli /tmp/mapd_ctrl dump_topology_v1"
	TOPOLOGY_DUMP_GENERATE_CMD2 = "/userfs/bin/mapd_cli /tmp/mapd_ctrl dump_topology_v2"
	TOPOLOGY_DUMP_FILE2 = "/tmp/dump_v2.txt"
end
TOPOLOGY_DUMP_FILE = "/tmp/dump.txt"
INTERNET_FILE_CHECK = "/tmp/gponFailed"


--Merge to lua tables
-- Overlapping keys will only have one entry

function tableMerge(t1, t2)
    for k,v in pairs(t2) do
        if type(v) == "table" then
            if type(t1[k] or false) == "table" then
                tableMerge(t1[k] or {}, t2[k] or {})
            else
                t1[k] = v
            end
        else
            t1[k] = v
        end
    end
    return t1
end

----------------------------------------------------------------------------------
-- @name getEasyMeshTopologyHandler
--
-- @description This function Handles EasyMesh Topology (WiFiSON) Request Method.
--
-- @return JSON response to EasyMesh Topology request
--
function getEasyMeshOntdcInfoHandler(methodObj, meshRequestMethod)
   
    local status
    local TopologyObj    = methodObj["Topology"]
    local topology_t
    local topology_t2
    local topology_t3

    if ((TopologyObj == nil) or (type(TopologyObj) ~= "table")) then
        TopologyResponse_t["Result"] = TopologyResponse_ReturnCodes["FAILED"]
        TopologyResponse_t["Response_Code"] = "400"
        TopologyResponse_t["Error_Message"] = "Bad Request"
        --mesh.sendResponse (TopologyResponse_t) 
        return "ERROR", "INVALID_METHOD" ,TopologyResponse_t
    end

    -- generate topology dump.txt by executing below command.
    util.runShellCmd(TOPOLOGY_DUMP_GENERATE_CMD, "/dev/null")

    if (not (util.fileExists (TOPOLOGY_DUMP_FILE))) then
        TopologyResponse_t["Result"] = TopologyResponse_ReturnCodes["FAILED"]
        TopologyResponse_t["Response_Code"] = "501"
        TopologyResponse_t["Error_Message"] = "No Data Available"
        --mesh.sendResponse (TopologyResponse_t) 
        return "ERROR", "INVALID_METHOD", TopologyResponse_t
    end

    -- convert the generated topology dump.txt file to a Lua Table
    if(util.fileExists("/pfrm2.0/ECONET")) then
        util.runShellCmd(TOPOLOGY_DUMP_GENERATE_CMD2, "/dev/null")
        topology_t3 = json.decode(util.fileToString (TOPOLOGY_DUMP_FILE))
        if(util.fileExists(TOPOLOGY_DUMP_FILE2)) then 
            topology_t2 = json.decode(util.fileToString (TOPOLOGY_DUMP_FILE2))
        
            topology_t = tableMerge(topology_t3,topology_t2)
        else
            topology_t = topology_t3
        end
    else
        topology_t = json.decode(util.fileToString (TOPOLOGY_DUMP_FILE))
    end

    if (topology_t == nil) then
        TopologyResponse_t["Result"] = TopologyResponse_ReturnCodes["FAILED"]
        TopologyResponse_t["Response_Code"] = "501"
        TopologyResponse_t["Error_Message"] = "No Data Available"
        --mesh.sendResponse (TopologyResponse_t) 
        return "ERROR", "INVALID_METHOD", TopologyResponse_t
    end

    status, TopologyResponse_t = easyMeshTopologyInfoLib.getMeshTopologyNodes(topology_t)
    if (status ~= "OK") then
        TopologyResponse_t["Result"] = TopologyResponse_ReturnCodes["FAILED"]
        TopologyResponse_t["Response_Code"] = "501"
        TopologyResponse_t["Error_Message"] = "No Data Available"
        --mesh.sendResponse (TopologyResponse_t) 
        return "ERROR", "INVALID_METHOD", TopologyResponse_t
    end

    TopologyResponse_t[WIFISON_NUMBER] = #TopologyResponse_t[WIFISON_NODE]

    if (util.fileExists (INTERNET_FILE_CHECK)) then
        TopologyResponse_t[WIFISON_INTERNET] = "0"
    else
        TopologyResponse_t[WIFISON_INTERNET] = "1"
    end
    TopologyResponse_t["Result"] = TopologyResponse_ReturnCodes["OK"]
    TopologyResponse_t["Response_Code"] = "200"
    TopologyResponse_t["Error_Message"] = nil
    
    --mesh.sendResponse (TopologyResponse_t) 
    return "OK", "SUCCESS", TopologyResponse_t
end

meshRequestMethodsList["ONTDC"]["methodHandler"] = getEasyMeshOntdcInfoHandler

