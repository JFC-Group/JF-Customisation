-- ripCLI.lua
-- Samer Sayeed
-- TeamF1
-- www.TeamF1.com
--
-- Modification History
-- 31jan09,ss  modified the validation routine 
-- 02dec08,ss  written 
--
-- Description
-- CLI interface set and get routines

require "teamf1lualib/rip"

local ripVersionType={
"Disabled",
"RIP-1",
"RIP-2B",
"RIP-2M"
}

local ripDirectionType={
"None",
"In Only",
"Out Only",
"Both"
}

function ripCfgInit(configRow)
    local FirstKeyFrom = {}
    local FirstKeyTo = {}
    local SecondKeyFrom = {}
    local SecondKeyTo = {}
    local rowid = 1
    local configRow = {}
	
    configRow = db.getRow("Rip", "_ROWID_", "1")
    if(configRow) then
        if(configRow["Rip.FirstKeyFrom"] ~= nil and configRow["Rip.FirstKeyFrom"] ~= "") then
            FirstKeyFrom = util.splitDateTime(configRow["Rip.FirstKeyFrom"])
        end
	if(configRow["Rip.FirstKeyTo"] ~= nil and configRow["Rip.FirstKeyTo"] ~= "") then        
            FirstKeyTo = util.splitDateTime(configRow["Rip.FirstKeyTo"])
        end
	if(configRow["Rip.SecondKeyFrom"] ~= nil and configRow["Rip.SecondKeyFrom"] ~= "") then        
            SecondKeyFrom = util.splitDateTime(configRow["Rip.SecondKeyFrom"])
        end
	if(configRow["Rip.SecondKeyTo"] ~= nil and configRow["Rip.SecondKeyTo"] ~= "") then        
            SecondKeyTo = util.splitDateTime(configRow["Rip.SecondKeyTo"])
	end
        for idx= 1, 6 do
        configRow["Rip.SecondKeyTo" .. idx] = SecondKeyTo[idx]
        configRow["Rip.SecondKeyFrom" .. idx] = SecondKeyFrom[idx]
        configRow["Rip.FirstKeyTo" .. idx] = FirstKeyTo[idx]
        configRow["Rip.FirstKeyFrom" .. idx] = FirstKeyFrom[idx]
        end            
    else
        configRow = db.getDefaults(true, "Rip")
    end
 
    return rowid, configRow 
end

function ripCfgSave(configRow) 
    local errorFlag = nil
    local statusCode = ""
    local statusMessage = nil

    errorFlag, statusCode = rip.config(configRow, "1", "edit")
    -- save db if no error
    if (errorFlag == "OK") then db.save() end
    statusMessage = db.getAttribute("stringsMap", "stringId", statusCode, LANGUAGE)
    return errorFlag, statusMessage
end

function ripCfgInputVal(configRow)
    if (configRow["Rip.Direction"] == "0" and configRow["Rip.AuthenticationType"] == "1") then
            printCLIError("Invalid Rip Direction. Authentication for RIP 2B/2M cannot be enabled\n")
            return false
    end
    if ((configRow["Rip.Version"] == "0" or configRow["Rip.Version"] == "1" ) and configRow["Rip.AuthenticationType"] == "1") then
            printCLIError("Invalid Rip Version. Select RIP-2B or RIP-2M to enable Authentication\n")
            return false
    end
    if (configRow["Rip.AuthenticationType"] == "1") then
        if ((configRow["Rip.FirstKeyId"] == "" or configRow["Rip.SecondKeyId"] == "") or (configRow["Rip.FirstKeyId"] == nil or configRow["Rip.SecondKeyId"] == nil)) then
            printCLIError("Enter the unique MD-5 key id\n")
            return false
        end
        if ((configRow["Rip.SecondAuthenticationKeyId"] == "" or configRow["Rip.FirstAuthenticationKeyId"] == "") or (configRow["Rip.SecondAuthenticationKeyId"] == nil or configRow["Rip.FirstAuthenticationKeyId"] == nil)) then 
            printCLIError("Enter the auth key for this MD5 key\n")
            return false
        end
        if (configRow["Rip.FirstKeyFrom1"] == nil or configRow["Rip.FirstKeyTo1"] == nil 
            or configRow["Rip.FirstKeyFrom2"] == nil or configRow["Rip.FirstKeyTo2"] == nil 
            or configRow["Rip.FirstKeyFrom3"] == nil or configRow["Rip.FirstKeyTo3"] == nil 
            or configRow["Rip.FirstKeyFrom4"] == nil or configRow["Rip.FirstKeyTo4"] == nil 
            or configRow["Rip.FirstKeyFrom5"] == nil or configRow["Rip.FirstKeyTo5"] == nil 
            or configRow["Rip.FirstKeyFrom6"] == nil or configRow["Rip.FirstKeyTo6"] == nil 
            or configRow["Rip.SecondKeyFrom1"] == nil or configRow["Rip.SecondKeyTo1"] == nil
            or configRow["Rip.SecondKeyFrom2"] == nil or configRow["Rip.SecondKeyTo2"] == nil
            or configRow["Rip.SecondKeyFrom3"] == nil or configRow["Rip.SecondKeyTo3"] == nil
            or configRow["Rip.SecondKeyFrom4"] == nil or configRow["Rip.SecondKeyTo4"] == nil
            or configRow["Rip.SecondKeyFrom5"] == nil or configRow["Rip.SecondKeyTo5"] == nil
            or configRow["Rip.SecondKeyFrom6"] == nil or configRow["Rip.SecondKeyTo6"] == nil) then
            printCLIError("Enter the valid start date/end date of the First and Second Key for MD5 based authentication between routers.\n")
            return false
        end
        if (configRow["Rip.FirstKeyId"] ~= nil and configRow["Rip.SecondKeyId"] ~= nil) then 
            local firstKeyId = tonumber(configRow["Rip.FirstKeyId"])
            local secondKeyId = tonumber(configRow["Rip.SecondKeyId"])
            if((firstKeyId > 255) or (firstKeyId < 1) or (secondKeyId > 255) or (secondKeyId < 1))then
                printCLIError("enter value between 1-255\n")
                return false 
            end
        end
    end
    return true
end

function ripConfigGet()
    local resultTab = {}
    local resultTab1 = {}
    local ripTable = db.getRow("Rip", "_ROWID_", "1")
       local direction = "0"
    local version = "0"

    printLabel("Dynamic Routing")
    printLabel("RIP")
    if (ripTable ~= nil) then
        direction = tonumber(ripTable["Rip.Direction"])
        direction = direction + 1
        print ( "RIP Direction " ..  ripDirectionType[direction] .. "\t")
        version = tonumber(ripTable["Rip.Version"])
        version = version + 1 
        print ( "RIP Version " .. ripVersionType[version] .. "\t")
        if(ripTable["Rip.AuthenticationType"] == "1") then 
            print ("Authentication for RIP-2B/2M: Enabled\t")
            print ("First Key Parameters" .. "")
            print ("MD5 Key Id: " .. ripTable["Rip.FirstKeyId"] .. "\t")
            print ("MD5 Auth Key:  *****\t" )
            print ("Not Valid Before: " .. ripTable["Rip.FirstKeyFrom"] .. "\t")
            print ("Not Valid After: " ..  ripTable["Rip.FirstKeyTo"] .. "\t")
            print ("Second Key Parameters\t")
            print ("MD5 Key Id: " ..  ripTable["Rip.SecondKeyId"] .. "\t")
            print ("MD5 Auth Key: *****\t")
            print ("Not Valid Before: " ..  ripTable["Rip.SecondKeyFrom"] .. "\t")
            print ("Not Valid After: " ..  ripTable["Rip.SecondKeyTo"] .. "\n")
        elseif(ripTable["Rip.AuthenticationType"] == "0") then
            print ("Authentication for RIP-2B/2M: Disabled\n")
        end
   end
end
