--[[
		Copyright(c) 2008, 2009 - TeamF1, Inc.
		All rights reserved.

Ds.lua -- This file implements default methods for managed object
       --abstract class

 $Id: Ds.lua 2151 2011-05-23 00:15:01Z prasanna@teamf1.com $ 
]]--

require("oo/OoUtil")
require("util/strlib")
pcall(require, "teamf1luaUiLib/I18N")

Ds = OoUtil.inheritsFrom(nil)

-- Initializes an in-memory object. Does not load from or save to the
-- database.
function Ds:new(classId, instanceId, props)
   if (not self) then
      self = Ds.create()
   end
   self.classId = classId
   self.instanceId = instanceId
   self:_initProps() 
   if (props) then
      self:setProps(props)
   end
   return self
end

--Private method
function Ds:_initProps() 
   if (not self._props) then
      self._props = {}
   end
end



-- Returns database table name to be used for sql queries. Subclasses
-- can override this if they want to use a different table name other
-- than its "classId"
function Ds:getDbTableName()
   return self.classId
end

-- This function executes a query and returns set of objects matching
-- the query. The filter parameter is a SQL where clause without the
-- key workd "where"
function Ds:query(filter, options)
   local errCode, msg = "OK", ""
   local objList = {}
   local dbTblName = self:getDbTableName()
   if (self.classId == nil) then 
      return errCode, msg, objList
   end
   if (filter == "" or filter == nil) then
      query = string.format([[SELECT *, ROWID AS _ROWID_ FROM %s]],
			    dbTblName)
   elseif (type(filter)=="string") then
      query = string.format([[SELECT *, ROWID AS _ROWID_ FROM %s where %s]],
			    dbTblName, filter)
   end

   local rows = db.getTable(dbTblName, false, query)
   if (not rows) then 
      return errCode, msg, objList
   end

   local dsFactory = DsFactory.getFactory()
   local i, row = 0, nil
   for i,row in pairs(rows)
   do
      local newObj = dsFactory:newObject(self.classId, row._ROWID_, row)
      if (options and options.translate) then
	 newObject:translate(options.language)
      end
      table.insert(objList, newObj)
   end
   return errCode, msg, objList
end

-- Loads from DB, the object represented by self.classId, self.instanceId. 
-- treating self.instanceId as the ROW id
function Ds:load(classId, instanceId, options)
   if (self == nil) then 
      if (LOG) then LOG:info("Load creating DS class for: " .. classId) end
      self = Ds:new(classId, instanceId)
   end
   local errCode, msg = "OK",""

   if (classId) then self.classId = classId end
   if (instanceId) then self.instanceId = instanceId end
   if (not self.classId or not self.instanceId) then return nil end

   local rowId = tonumber(self.instanceId)
   if (rowId == nil or rowId <= 0) then
      -- can't the object from db
      if (LOG) then LOG:info("cannot create Ds. invalid instance ID=" .. rowId) end
      return errCode, msg, self
   end

   local dbTblName = self:getDbTableName()
   if (not dbTblName) then
      return "ERROR", "Table name not defined for class:"..tostring(self.classId), self
   end

   local query = "_ROWID_=" .. rowId
   local row_simple = db.getRowWhere(dbTblName, query, false)
   if (row_simple == nil) then
      return "ERROR", ("Load failed for table: ".. tostring(dbTblName).. 
	 ", row: " .. tostring(rowId)), self
   end

   --[[       
   -- SAM: Removed un-necessary prefix strip
   local row_fullKey = db.getRow(dbTblName, "ROWID", rowId)
   if (row_fullKey == nil) then
      return "ERROR", ("Load failed for table: ".. tostring(dbTblName).. 
	 ", row: " .. tostring(rowId)), self
   end

   local row_simple = {}
   -- get rid of the prefix set by db.lua
   for k,v in pairs(row_fullKey) do
      local parts = strlib.split(k,'.')
      local column = parts[2]
      row_simple[column] = v
   end
   ]]

   self:setProps( row_simple )

   if (options and options.translate) then
      self:translate(options.language)
   end
   return errCode, msg, self
end

-- Return a property of the object. The default implementation simply
-- returns the property by name 'prop' from its _props
-- table. Subclasses may implement additional lookup and translation
-- types of logic.
--
-- NOTE: This function does not load the object. The user is expected
-- to call the load function before calling this method.
function Ds:get(prop)
   if (not prop) then return nil end
   if (not self._props) then return nil end
   return self._props[prop]
end

-- Get all props
function Ds:getProps()
   return self._props
end


-- Set a property of the object. The default implementation simply
-- sets the property by name 'prop' in its _props table. Subclasses
-- may implement additional logic as needed.
--
-- NOTE: This function does not save the object. The user is expected
-- to call save explicitly.
function Ds:set(prop, value)
   if (not prop) then return end
   if (not self._props) then self:_initProps() end
   self._props[prop] = value
end

-- Sets an array of properties
function Ds:setProps(propTbl)
   if (not propTbl) then return end
   if (not self._props) then self:_initProps() end
   local k,v 
   for k,v in pairs(propTbl) do
      self:set(k,v)
   end
end

-- This function saves the object to the database. The default
-- implementation here maps each prop to a database column. More
-- complex setups where an object maps to multiple tables, the object
-- should implement its own save method and commit to multiple tables.
function Ds:save()
   local errCode, msg, results = "OK", nil, nil
   local fullKeyProps = {}
   local k,v
   local dbTblName = self:getDbTableName()
   for k,v in pairs(self._props) do
      fullKeyProps[dbTblName .. "." .. k] = v
   end

   local rowId = self._props._ROWID_ 
   local rowId = (rowId and tonumber(rowId)) or -1

   if (rowId < 0) then
      -- insert
      db.insert(dbTblName, fullKeyProps, true)
   else
      -- update
      db.update (dbTblName, fullKeyProps, self._props._ROWID_)
   end
   return errCode, msg, results
end


-- This function deletes the object from the database. The default
-- implementation here deletes one row from self.classId table, and
-- self.instanceId == ROWID. If different (or additional) logic is
-- needed, this method should be overridden by subclass.
-- 
function Ds:delete ()
   if (self.instanceId == nil) then
      return
   end
   db.delete(self:getDbTableName(), self._props)
end

-- This function is responsible for translating any strings and
-- generally setting up data for presentation to the user. The default
-- implementation (below) does not do much, but the sub classes are
-- expected to implement their own translations
function Ds:translate(prop)
   local value = self:get(prop)
   if (value) then
      return I18N.tr(value)
   end
   return nil
end

function Ds:getTranslatedProps()
   local props = self:getProps() or {}

   return props

   -- The logic below to translate all values will result in some side
   -- effects such as translations of user entered strings, as well as
   -- some numbers cuh as port numbers - incorrectly!

   -- local retProps = {}
   -- local k,v 
   -- for k,v in pairs(props) do
   --    if (v and type(v) == "string") then
   --       v = I18N.tr(v)
   --    end
   --    retProps[k] = v
   --  end

   --  return retProps

end


local function getPermissionProvider()
   local permProvFactoryClass, permProvFactory, permProvider = nil, nil, nil
   local conf = require("conf/DynamoConf")
   if (not permProvider and conf.permissionProviderFactory) then
      permProvFactoryClass = require(conf.permissionProviderFactory)
      permProvFactory = permProvFactoryClass.getFactory()
      permProvider = permProvFactory:getProvider()
   end
   return permProvider
end

Ds.getPermissionProvider = getPermissionProvider

function Ds:isEditableByClassId(propName) 
   return self:isEditableByOid(self.classId, nil, propName) 
end

function Ds:isEditable(propName) 
   local conf = require("conf/DynamoConf")
   local permProvider = getPermissionProvider()
   return permProvider:checkPermission(self.classId, 
                                       self.instanceId, 
                                       PermissionPolicyProvider.ACTION_ENUM.EDIT, propName)
end


-- Default method
function Ds:isDeleteAllowed()
   local conf = require("conf/DynamoConf")
   local permProvider = getPermissionProvider()
   return permProvider:checkPermission(self.classId, 
                                       self.instanceId, 
                                       PermissionPolicyProvider.ACTION_ENUM.DELETE_OBJECT, propName)
end

function Ds:isObjectEditable()
   local conf = require("conf/DynamoConf")
   local permProvider = getPermissionProvider()
   return permProvider:checkPermission(self.classId, 
                                       self.instanceId, 
                                       PermissionPolicyProvider.ACTION_ENUM.EDIT_OBJECT, propName)
end


-- Default method
function Ds:isEnableAllowed()
   return false
end

-- Default method
function Ds:isDisableAllowed()
   return false
end

--[[

                       Design Notes on Actions
                       -----------------------
     
Each DS will provide lists of actions to help in rendering HTML.  The
following methods are supported:

- Common action properties:
  - name - name of the action
  - label - Label for displaying to user. 
  - help  - brief help text to display as tooltip
  - enableIcon - Icon to use when the action is allowed
  - disableIcon - Icon to use when the action is NOT allowed
  - operation - Name of the operation to invoke user invokes the action
  - formUrl - If provided, used to render the input form for the
    action. If this exists, the form is retreieved and opened when the
    user invokes the action.  If the user clicks OK in the form, then
    the actual operation is invoked, passing in the form data.
  - cssClass CSS classes to be used

- The actions return the following upon success:
  - isRefresh - if true, this is a hint to UI to refresh the view
  - isDelete - if true, then the object on which the action has been
    taken, should be deleted from the UI front-end.
  - isEnable - if true, then the object on which the action should show enable button
  - isDisable - if true, then the object on which the action should show disable button

- getListActions()

  - This is a class level method and returns the list of actions
    supported at the class level. I.e., these are typically actions a
    user can take in list views. A common example is creation of a new
    object.

    This method can be invoked as <class>.getListActions() or
    <dsInstance>.getListActions(). Note the use of dot as opposed to a
    colon.

- getActions()
  
  - This is an instance level method and returns the list of actions
    supported on an object instance. I.e., these are actions to be
    performed on an objcet instance. Common examples are delete,
    enable, disable, etc.

    This method is invoked as <dsInstance>:getListActions(). Note the
    use of colon as opposed to a dot.


- isActionAllowed(actionName)

  - Support function that indicates whether the Ds class or instance
               supports a particular action. Use for non-standard
               actions only (like delete,save)


- Default list actions
  
  - create: To create a new object of this type

- Default object actions

  - delete: to delete this object. Note that the DS should not include
    this action in the action list if the deletion is not
    permitted. For example, default admin guest and admin users cant
    be deleted, so for those objects delete action should not be in
    the action list.
]]--


function Ds:getListActions(classId)
   local actionList = {}
   if (self:isActionAllowed("create")) then
      table.insert(actionList, 
                   {
                      name = "create", 
                      label = "New...",
                      help = "Create New",
                      cssClass = "newBtn",
                      operation = "Save",
                      formUrl = (self and string.format("%s/-1/0/edit", classId)) or nil,
                      refreshOnSuccess = true,
                   })
   elseif (self:isActionAllowed("delete")) then
      
   end

   return actionList
end

function Ds:getActions()
   local actionList = {}
--   table.insert(actionList, 
--                {
--                   name = "edit", 
--                   label = "Edit",
--                   cssClass = "editBtn",
--                   id = "editBtn",
--                   refreshOnSuccess = true,
--                })
--
   if (self:isDeleteAllowed()) then
      table.insert(actionList, 
                   {
                      name = "delete", 
                      label = "Delete",
                      help = "Delete",
                      cssClass = "deleteBtn",
                      id = "deleteBtn",
                      operation = "Delete",
                      formUrl = (self and string.format("%s/%s/%s/confirm-delete.htm", 
                                                        tostring(self.classId), 
                                                        tostring(self.instanceId), 
                                                        tostring(self.deviceId))) or nil,
                      deleteOnSuccess = true
                   })
   end

   return actionList
end

function Ds:isActionAllowed(actionName) 
   return true
end

function Ds:getTranslatedActions()
   local actions = self:getActions()
   for i, action in ipairs(actions) do
      action.label = I18N.tr(action.label)
   end
   return actions
end

-- Utility function
function Ds.getUserSessionId()
   local session = TeamF1MgmtController.getSessionInfo()
   return (session and session.sessionId) or nil
end

-- This function saves configurations to flash by calling db.save
function Ds:flashSave()
    tf1debug.trace("Saving to flash...")
    db.save()                
    tf1debug.trace("flash save done")
    return true
end

-- Utility function that returns properties with "<tablename>."
-- prefix. Useful when dealing with some backend code that expects
-- such prefixes
function Ds:getPropsWithPrefixes()
   local dbTblName = self:getDbTableName()
   if ( not dbTblName) then
      return
   end
   local props = self:getProps()
   local outPropsWithPrefixes = {}
   table.foreach(props, function(k,v)
                           k = dbTblName .."." .. k
                           outPropsWithPrefixes[k] = v
                        end)
   return outPropsWithPrefixes
end

-- Inverse of the getPropsWithPrefixes(). Receives a property table with
-- prefixes, strips the prefixes off and applies the props on self.
function Ds:setPropsWithPrefixes(inPropsWithPrefixes)
   local dbTblName = self:getDbTableName()
   if (not inPropsWithPrefixes or not dbTblName) then
      return
   end
   local props = {}
   table.foreach(inPropsWithPrefixes, function(k,v)
                                         k = k:gsub(dbTblName .. ".", "")
                                         props[k] = v
                                      end)
   self:setProps(props)
end


return Ds
