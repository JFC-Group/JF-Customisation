--[[
#### 
#### File: userdbTrExtn.lua
#### Description: 
#### TR-98 handlers for userdb. This file is included from
#### tr69Glue code.
####

#### Revisions:
01a,14jul10,sam  written
]]--

userdbTr = {}

--[[
--*****************************************************************************
-- userdbTr.setLANPassword - set the LAN administrative password.
-- 
-- This function is called to set the LAN administrative password for
-- the following tr69 Parameter -
-- InternetGatewayDevice.LANConfigSecurity.ConfigPassword
--
--RETURN: 
]]--

function userdbTr.setLANPassword (input, rowids)
	require "teamf1lualib/userdb"

	local query
	local row = {}

    for table,value in pairs (input) do
		query = "_ROWID_=" .. rowids[table]		
    	row = db.getRowWhere (table, query, true)
		if (row == nil) then
    		return "1" ,"DB_ERROR_TRY_AGAIN"
	    end

		row["users.password"] = value["users.password"]

		valid = db.update (table, row, row["users._ROWID_"]);
		if (valid) then
            os.execute ("/bin/fw_setenv admin_secret " .. row["users.password"]);
			status = 0
		else
			status = 1
		end	
	end

	db.save2()

	return status
end

--[[
--*****************************************************************************
-- userdbTr.webuiPasswordSet - set the webui admin password.
-- 
-- This function is called to set webui admin password for
-- the following tr69 Parameter - Device.Users.User.0.Password
--
--RETURN: on success returns 0, failure returns 1 
]]--

function userdbTr.webuiPasswordSet (input, rowids)
require "teamf1lualib/userdb"
    local status = OK 
    local index = 0
    local query = "_ROWID_='2'"
    local usersrow = {}
    local faultTbl = {}
    tr69Glue.tf1Dbg("Entering userdbTr.webuiPasswordSet..")

        usersRow = db.getRowWhere ("users", query, true);

        if (usersRow == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
	    end
    for table,value in pairs (input) do
    
    -- Verify the length of password
        if (util.verifyLength (value["users.Password"],
                userdb.propTbl["passwordMinLen"],
                userdb.propTbl["passwordSize"]) == false or value["users.Password"] == nil)
        then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, "Device.Users.User.0.Password", error_code.INVALID_PARAM_VALUE)
            return status, faultTbl    
        end
    -- Verify that the password doesn't contain space, single or double quotes.
        if (string.match (value["users.Password"], "^[^\"\'%s]*$") == nil)
        then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, "Device.Users.User.0.Password", error_code.INVALID_PARAM_VALUE)
            return status, faultTbl
        end

    --Verify that user password is not set to restricted password
        local error_msg = userdb.passwordCheck(value["users.Password"])
        if (error_msg) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, "Device.Users.User.0.Password", error_code.INVALID_PARAM_VALUE)
            return status, faultTbl
        end

    --Verify that user password is not set to non ascii characters
        local error_msg = util.validPasswordCheck(value["users.Password"])
        if (error_msg) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, "Device.Users.User.0.Password", error_code.INVALID_PARAM_VALUE)
            return status, faultTbl
        end
        usersRow["users.password"] = value["users.Password"]
        valid = db.update ("users", usersRow, usersRow["users._ROWID_"]);
        if (valid) then
			status = OK 
            if (util.fileExists("/tmp/FcDef") or util.fileExists("/flash/FcDef")) then
                os.execute("rm -rf /tmp/FcDef")
                os.execute("rm -rf /flash/FcDef")
            end
		else
			status = ERROR 
		end
    end

	db.save2()
    tr69Glue.tf1Dbg("Leaving userdbTr.webuiPasswordSet..")
    return status
end
