--[[
#### Adarsh Uppula
#### TeamF1
#### www.TeamF1.com
#### June 29, 2007

#### File: db.lua
#### Description: Library of functions that provide access
to SQLite3 database functionality.

#### Revisions:
01e,09Jul18,swr  changes for SPR 64269(Missing TR params)
01d,26aug09,pnm  added back db.import routine and modified db.save routine to
                 export old format configuration.
01c,20aug09,pnm  added back db.insertImport routine.
01b,16apr09,rks calling config.beginTransaction, commitTransaction
01a,29jan09,rks removed db.export/import. import/export configuration is now
               handled by config component.
]]--


--************* Requires *************

require "luasql.sqlite3"
require "teamf1lualib/config"
require "sqliteLib"

--************* Initial Code *************

--package db
db = {}

--create environment object
local _DB_env = luasql.sqlite3()
local _DB_con = nil

db.event =  {
    SQLITE_DELETE           = 9, 
    SQLITE_INSERT           = 18, 
    SQLITE_UPDATE           = 23, 
}

--************* Functions *************

--Connect to the given DB.
function db.connect (dbname)
	_DB_con = _DB_env:connect(dbname)
    return _DB_con
end

function db.set_connection (con)
    _DB_con = con
end

function db.get_connection()
    return _DB_con
end

--escape the input string
function db.escape (str)

	esc_txt, errorStr = _DB_con:escape(str)
	return esc_txt

        --return _DB_con:escape(str)
end


-- Checks for ' in input
-- Checks tables recursively
-- Returns true if ' is found
function db.sqlInjectionCheck(input, tableType)


    if (type(input) == "string") then
        if ((string.find(input,"'")) or (string.find(input,";")) or (string.find(input,"|"))) then
            return true
        end
    elseif (type(input) == "table") then
        for k,v in pairs (input) do
            local check = true
            if (tableType == "html") then -- user-input through GUI
                --[[ 
                local splitparts = util.split(k, ".")
                if (#splitparts ~= 2) then check = false end -- check only user-input values
                ]]-- 
            end
            if (check and db.sqlInjectionCheck(v)) then
                return true
            end
        end
    end
    return false
end

--Execute the given query and return the resulting cursor and error message.
function db.execute (query)
	cur, errorStr = _DB_con:execute(query)
	errorStr = errorStr or ""
	if (errorStr ~= "") then
		util.appendDebugOut("DBExecute error message: " .. errorStr .. "<br>")
	end
	if (statusMessage == "" and errorStr ~= "") then
		util.appendDebugOut("statusMessage old = " .. statusMessage .. ", new = " .. errorStr .. "<br>")
		statusMessage = errorStr
	end
	return cur, errorStr
end

--Close the database.
function db.close ()
	_DB_con:close()
	_DB_env:close()
end

----------------------------------------------------------

-- Convert given DB table to a LUA table (numerically indexed).
-- If -fullname- is true, fields will be indexed by <tablename>.<fieldname>
-- Returns nil on error.
function db.getTable (tablename, fullname, customQuery)
	-- query
    local query = ""
    if (customQuery == nil) then
        query = string.format([[
                                 SELECT *, _ROWID_ AS _ROWID_ FROM %s
	                          ]], tablename)
    else
        query = customQuery
    end
    local cur = db.execute(query)

	local rownum = 0
	local luaTable = {}
	-- get all rows, the rows will be indexed by field names
	if (cur) then
		local row = cur:fetch ({}, "a")
		while row do
			local rowTable = {}
			rownum = rownum + 1 --inc rownum
			for k,v in pairs(row) do
				if fullname or fullname == nil then
					rowTable[tablename .. "." .. k] = v
				else
					rowTable[k] = v
				end
			end
			luaTable[rownum] = rowTable
			-- get the next row
		  	row = cur:fetch (row, "a")
		end
		cur:close()
	else
		luaTable = nil
	end

	-- return
	return luaTable
end

-- Joins all the tables on the common join fields and returns a LUA table.
-- Example call: db.getTableWithJoin({"dot11VAP:dot11Profile:profileName"})
-- where a join will occur between dot11VAP and dot11Profile on field profileName.
-- Fields will be indexed by <tablename>.<fieldname>.
-- Returns nil on error.
function db.getTableWithJoin (tableJoinFieldPairs)
	local allTables = {}
	local fromString = ""
	local whereString = ""
	local luaTable = {}
	
	-- build where part
	for k,v in pairs(tableJoinFieldPairs) do
		local splitparts = util.split(v, ":")
		if (#splitparts == 3) then
			-- to use for from part
			allTables[splitparts[1]] = ""
			allTables[splitparts[2]] = ""
			whereString = whereString .. splitparts[1] .. "." .. splitparts[3] .. " = " .. splitparts[2] .. "." .. splitparts[3] .. " AND "
		end
	end
	
	-- build from part
	for k,v in pairs(allTables) do
		fromString = fromString .. k .. ", "
	end
	whereString:sub(1, whereString:len()-4) --shave last comma
	whereString = whereString:sub(1, whereString:len()-4) --shave last comma
	fromString = fromString:sub(1, fromString:len()-2) --shave last comma
	
	-- run query and get aliased columns from each table
	for k,v in pairs(allTables) do
		luaTable = db.getTableWithJoinHelper(luaTable, k, fromString, whereString)
	end

	-- return
	return luaTable
end

-- Join helper
function db.getTableWithJoinHelper (luaTable, tablename, fromString, whereString)
    -- query
    local cur = db.execute(string.format([[
		SELECT %s.*, %s.ROWID AS _ROWID_
		FROM %s
		WHERE %s
	]], tablename, tablename, fromString, whereString))

	local rownum = 0
	-- get all rows, the rows will be indexed by field names
	if (cur) then
		local row = cur:fetch ({}, "a")
		while row do
			rownum = rownum + 1 --inc rownum
			local rowTable = luaTable[rownum] or {} -- get existing if there
			for k,v in pairs(row) do
				rowTable[tablename .. "." .. k] = v
			end
			luaTable[rownum] = rowTable
			-- get the next row
		  	row = cur:fetch (row, "a")
		end
		cur:close()
	else
		luaTable = nil
	end

	-- return
	return luaTable
end

-- Join tables and returns one row.
-- Returns nil on error.
function db.getRowWithJoin (rowJoinFieldPairs, keyname, keyvalue)
	local fullTable = db.getTableWithJoin(rowJoinFieldPairs)

	-- search for key
	for k,v in pairs(fullTable) do
		if (v[keyname] == keyvalue) then
			return v
		end
	end

	-- none found
	return nil
end

-- Join tables and return all rows that match.
-- Returns nil on error.
function db.getRowsWithJoin (rowJoinFieldPairs, keyname, keyvalue)
	local fullTable = db.getTableWithJoin(rowJoinFieldPairs)
	local rows = {}
	
	-- search for key
	for k,v in pairs(fullTable) do
		if (v[keyname] == keyvalue) then
			table.insert(rows, v)
		end
	end

	-- return
	return rows
end

-- Checks if row in table with given keyname and value exists.
-- Returns _ROWID_ if exists, false if not or error. 
function db.existsRow (tablename, keyname, keyvalue)
	-- query
    local cur = db.execute(string.format([[
		SELECT *, ROWID AS _ROWID_ FROM %s
		WHERE %s = '%s'
	]], tablename, keyname, keyvalue))

	-- check for rows
	local result = false
	if (cur) then
		local row = cur:fetch ({}, "a")
		cur:close()
		if (row ~= nil) then
			result = row["_ROWID_"]
		end
	end
	return result
end

-- Checks if row in table where -where- (unique) is true from given DB table.
-- Returns _ROWID_ if exists, false if not or error. 
function db.existsRowWhere (tablename, where)
	-- query
    local cur = db.execute(string.format([[
		SELECT *, ROWID AS _ROWID_ FROM %s
		WHERE %s
	]], tablename, where))

	-- check for rows
	local result = false
	if (cur) then
		local row = cur:fetch ({}, "a")
		cur:close()
		if (row ~= nil) then
			result = row._ROWID_
		end
	end
	return result
end

-- Returns an equivalent LUA table for the row with the given
-- key from the the given DB table.
-- If keyvalue = -1, a skeleton table with values being empty strings
-- will be returned.
-- Returns nil on error.
function db.getRow (tablename, keyname, keyvalue)
	-- query
    local cur = db.execute(string.format([[
		SELECT *, ROWID AS _ROWID_ FROM %s
		WHERE %s = '%s'
	]], tablename, keyname, keyvalue))

 	-- check for rows
	local result = {}
	if (cur) then
		local row = cur:fetch ({}, "a")
		cur:close()
		if (row) then
			for k,v in pairs(row) do
				result[tablename .. "." .. k] = v
			end
		else
			result = nil
		end
	else
		result = nil
	end
	return result
end

-- Get row where -where- (unique) is true from given DB table.
-- Returns nil on error.
function db.getRowWhere (tablename, where,fullname)
	-- query
    local cur = db.execute(string.format([[
		SELECT *, ROWID AS _ROWID_ FROM %s
		WHERE %s
	]], tablename, where))

 	-- check for rows
	local result = {}
	if (cur) then
		local row = cur:fetch ({}, "a")
		cur:close()
		if (row) then
			for k,v in pairs(row) do
				if fullname or fullname == nil then
					result[tablename .. "." .. k] = v
				else
					result[k] = v
				end
			end
		else
			result = nil
		end
	else
		result = nil
	end
	return result
end

-- Get row -from- where -where- (unique) is true from given DB table.
-- Returns nil on error.
function db.getRowFromWhere (from, where)
	-- query
    local cur = db.execute(string.format([[
		SELECT *, ROWID AS _ROWID_ FROM %s
		WHERE %s
	]], from, where))

 	-- check for rows
	local result = {}
	if (cur) then
		local row = cur:fetch ({}, "a")
		cur:close()
		if (row) then
			for k,v in pairs(row) do
				result[tablename .. "." .. k] = v
			end
		else
			result = nil
		end
	else
		result = nil
	end
	return result
end

-- Returns an equivalent LUA table for the rows with the given keyname
-- and keyvalue from the the given DB table.
-- Returns nil on error.
function db.getRows (tablename, keyname, keyvalue)
	-- query
    local cur = db.execute(string.format([[
		SELECT *, ROWID AS _ROWID_ FROM %s
		WHERE %s = '%s'
	]], tablename, keyname, keyvalue))

	local rownum = 0
	local luaTable = {}
	-- get all rows, the rows will be indexed by field names
	if (cur) then
		local row = cur:fetch ({}, "a")
		while row do
			-- only if not default row
			if (tonumber(row._ROWID_) > 0) then
				local rowTable = {}
				rownum = rownum + 1 --inc rownum
				for k,v in pairs(row) do
					rowTable[tablename .. "." .. k] = v
				end
				luaTable[rownum] = rowTable
			end
			-- get the next row
		  	row = cur:fetch (row, "a")
		end
		cur:close()
	else
		luaTable = nil
	end

	-- return
	return luaTable
end

-- Get rows where -where- (unique) is true from given DB table.
-- Returns nil on error.
function db.getRowsWhere (tablename, where, fullname)
	-- query
    local cur = db.execute(string.format([[
		SELECT *, ROWID AS _ROWID_ FROM %s
		WHERE %s
	]], tablename, where))

	local rownum = 0
	local luaTable = {}
	-- get all rows, the rows will be indexed by field names
	if (cur) then
		local row = cur:fetch ({}, "a")
		while row do
			-- only if not default row
			if (tonumber(row._ROWID_) > 0) then
				local rowTable = {}
				rownum = rownum + 1 --inc rownum
				for k,v in pairs(row) do
				    if fullname or fullname == nil then
					    rowTable[tablename .. "." .. k] = v
				    else
					    rowTable[k] = v
				    end
				end
				luaTable[rownum] = rowTable
			end
			-- get the next row
		  	row = cur:fetch (row, "a")
		end
		cur:close()
	else
		luaTable = nil
	end

	-- return
	return luaTable
end

function db.getRowsWithCustomQuery(tablename, query)
	-- query
    local cur = db.execute(query)
 	local rownum = 0
	local luaTable = {}

    local cur = db.execute(string.format([[
		SELECT *, ROWID AS _ROWID_ FROM %s
		%s]], tablename, query))

	-- get all rows, the rows will be indexed by field names
	if (cur) then
		local row = cur:fetch ({}, "a")
		while row do
			-- only if not default row
			if (tonumber(row._ROWID_) > 0) then
				local rowTable = {}
				rownum = rownum + 1 --inc rownum
				for k,v in pairs(row) do
					rowTable[tablename .. "." .. k] = v
				end
				luaTable[rownum] = rowTable
			end
			-- get the next row
		  	row = cur:fetch (row, "a")
		end
		cur:close()
	else
		luaTable = nil
	end

	-- return
	return luaTable
end

-- Get Disticts values for a given column from given DB table.
-- Returns nil on error.
function db.getDistinctValues (tablename, columnName)
	-- query
    local cur = db.execute(string.format([[
		SELECT DISTINCT %s FROM %s]],
        columnName, tablename))

	local rownum = 0
	local luaTable = {}
	-- get all rows, the rows will be indexed by field names
	if (cur) then
		local row = cur:fetch ({}, "a")
		while row do
			local rowTable = {}
			rownum = rownum + 1 --inc rownum
			for k,v in pairs(row) do
				rowTable[tablename .. "." .. k] = v
			end
			luaTable[rownum] = rowTable
			-- get the next row
		  	row = cur:fetch (row, "a")
		end
		cur:close()
	else
		luaTable = nil
	end

	-- return
	return luaTable
end

-- Returns default row for given list of tables.
-- Returns empty table if no default.
function db.getDefaults (useEmpty, ...)
	local defaults = {}
	for i,v in pairs{...} do
		local defaultTable = db.getRows("tableDefaults", "tablename", v)
        if (defaultTable == nil or #defaultTable == 0) then
            return defaults
        end
		for a,b in pairs(defaultTable) do
			defaults[v .. "." .. b["tableDefaults.columnName"]] = b["tableDefaults.defValue"]
		end
		local allKeys = db.getColNames(v)
		-- add leftover defaults if no default exists
		for c,d in pairs(allKeys) do
			-- OID is treated specially to always set to
			-- 0. This value of 0 is ultimately ignored by
			-- db.insert but we need to set OID here to keep
			-- db.typeAndRangeValidate happy
			if (d == "_ROWID_") then 
			   defaults[v .. "." .. d] = "1"
			-- rest fields set as normal
			elseif not util.tableKeyExists(defaults, v .. "." .. d) then
				if (useEmpty) then
					defaults[v .. "." .. d] = ""
				else
					defaults[v .. "." .. d] = false
				end
			end
		end
	end
	return defaults
end

-- Returns default value for field.
function db.getDef (tablename, attributename)
	local defRow = db.getRowWhere("tableDefaults", "tableName = '" .. tablename .. "' AND columnName = '" .. attributename .. "'")
	if defRow then return defRow["tableDefaults.defValue"] else return "" end
end

-- Returns minimum value for field.
function db.getMin (tablename, attributename)
	local defRow = db.getRowWhere("tableDefaults", "tableName = '" .. tablename .. "' AND columnName = '" .. attributename .. "'")
	if defRow then return defRow["tableDefaults.minValue"] else return "" end
end

-- Returns maximum value for field.
function db.getMax (tablename, attributename)
	local defRow = db.getRowWhere("tableDefaults", "tableName = '" .. tablename .. "' AND columnName = '" .. attributename .. "'")
	if defRow then return defRow["tableDefaults.maxValue"] else return "" end
end

-- Returns def string
function db.getDefStr (tablename, attributename)
	return "(" .. db.getMin(tablename, attributename) .. "-" .. db.getMax(tablename, attributename) .. ", default " .. db.getDef(tablename, attributename) .. ")"
end

-- Get the value of the given attribute from the row with the given
-- primary key from the the given DB table. Returns nil on error.
function db.getAttribute (tablename, keyname, keyvalue, attributename)
	-- query
    local cur = db.execute(string.format([[
		SELECT %s, ROWID AS _ROWID_ FROM %s
		WHERE %s = '%s'
	]], attributename, tablename, keyname, keyvalue))

 	-- check for rows
	local result = nil
	if (cur) then
		local row = cur:fetch ({}, "a")
		cur:close()
		if (row) then result = row[attributename] end
	end
	return result
end

-- Set the value of the given attribute from the row with the given
-- primary key from the the given DB table. This routine also takes in
-- the the OID and objRevId for tables that have those fields
function db.setAttributeExt (tablename, keyname, keyvalue, attributename, attributevalue, oid, objRevId)

    local queryString = "UPDATE "..tablename.." SET "..attributename.."="..attributevalue
    if (oid ~= nil) then
	queryString = queryString..", OID="..oid
    end
    if (objRevId ~= nil) then
        queryString = queryString..", objRevId="..(objRevId+1).." "
    end
	       
    queryString = queryString.."WHERE "..keyname.."="..keyvalue

    if db.existsRow(tablename, keyname, keyvalue) then
    -- query
        local cur, errstr = db.execute(queryString)
	util.appendDebugOut(queryString .. "<br>")
	return cur, errstr
    else
	return false
    end
end

-- Set the value of the given attribute from the row with the given
-- primary key from the the given DB table.
function db.setAttribute (tablename, keyname, keyvalue, attributename, attributevalue)
	-- insert if new, update if not
	if db.existsRow(tablename, keyname, keyvalue) then
		-- query
		local queryString = string.format([[
			UPDATE %s
            SET %s = '%s'
			WHERE %s = '%s'
		]], tablename, attributename, attributevalue, keyname, keyvalue)
		
	    local cur, errstr = db.execute(queryString)
	    util.appendDebugOut(queryString .. "<br>")
	    
		return cur, errstr
	else
		return false
	end
end

-- Set the value of the given attribute where -where- is true (unique)
-- from the the given DB table.
function db.setAttributeWhere (tablename, where, attributename, attributevalue)
	-- insert if new, update if not
	if db.existsRowWhere(tablename, where) then
		-- query
	    local cur, errstr = db.execute(string.format([[
			UPDATE %s
            SET %s = '%s'
			WHERE %s
		]], tablename, attributename, attributevalue, where))
		
		return cur, errstr
	else
		return false
	end
end

-- Delete row in table with given keyname and value. 
function db.deleteRow (tablename, keyname, keyvalue)
	-- query
    local cur, errstr = db.execute(string.format([[
		DELETE FROM %s
		WHERE %s = '%s'
	]], tablename, keyname, keyvalue))
	
	return cur, errstr
end

-- Delete row in table given WHERE part. 
function db.deleteRowWhere (tablename, where)
	-- query
    local cur, errstr = db.execute(string.format([[
		DELETE FROM %s
		WHERE %s
	]], tablename, where))
	
	return cur, errstr
end

-- Insert into the DB table the name-value pairs from
-- the given LUA table.
function db.insert (tablename, tableInput, notFullKey)
	local queryString = ""
	local insertPart = "INSERT INTO " .. tablename .. " ("
	local valuesPart = ") VALUES ("
	local rowidExists  = 0
	
	-- get col names
	local allKeys = db.getColNames(tablename)

	-- check if the table has the rowid column
	if ((notFullKey and util.tableKeyExists(tableInput, "_ROWID_")) or 
		 (util.tableKeyExists(tableInput, tablename .. "._ROWID_"))) then
		local numKeys = #allKeys
		-- add rowid to the keys table
		allKeys[numKeys + 1] = "_ROWID_"		
	end

	-- get defaults
	local defaults = db.getDefaults(false, tablename)
	-- make strings
	for k,v in pairs(allKeys) do
			insertPart = insertPart .. "\'" .. v .. "\', "
			-- TODO:
			-- if post contained field already
			-- if (v == "_ROWID_") then
			--   valuesPart = valuesPart .. "(select OID from oidRecord where tableName=\"".. tablename .. "\"), "			
			-- else
			if notFullKey and util.tableKeyExists(tableInput, v) then
				valuesPart = valuesPart .. "\'" .. tableInput[v] .. "\', "
			elseif util.tableKeyExists(tableInput, tablename .. "." .. v) then
				valuesPart = valuesPart .. "\'" .. tableInput[tablename .. "." .. v] .. "\', "
			-- else if default exists, use it
			elseif defaults[tablename .. "." .. v] then
				valuesPart = valuesPart .. "\'" .. defaults[tablename .. "." .. v] .. "\', "
			-- else use empty string
			else
				valuesPart = valuesPart .. "NULL, "
			end
		end

	insertPart = insertPart:sub(1, insertPart:len()-2) --shave last comma
	valuesPart = valuesPart:sub(1, valuesPart:len()-2) --shave last comma
	valuesPart = valuesPart .. ")"
	
	-- execute it
	queryString = insertPart .. valuesPart
	local cur, errstr = db.execute(queryString)
	util.appendDebugOut(queryString .. "<br>\n")
    local lastrowid = _DB_con:getlastautoid()	
	return cur, errstr, lastrowid 
end

--
-- Update the DB table with the name-value pairs from the given LUA table,
-- for the given _ROWID_.
function db.update (tablename, tableInput, rowId)
	local queryString = "UPDATE " .. tablename .. " SET "
	local fieldsSetString = ""
	local oidVal = nil
	-- get col names
	local allKeys = db.getColNames(tablename)
	-- make strings
	for k,v in pairs(tableInput) do
		local splitparts = util.split(k, ".")
		-- if the column actually exists
		if (#splitparts == 2 and splitparts[1] == tablename and util.keyTableValueExists(allKeys, splitparts[2])) then
			local field = splitparts[2]
			-- check if field changed
            if (tablename == "NimfConf") then
                fieldsSetString = fieldsSetString .. splitparts[2] .. " = \'" .. v .. "\', "
            else
			if (field == "objRevId") then
			   fieldsSetString = fieldsSetString..field.."=\'"..v+1
			   fieldsSetString = fieldsSetString.."\', "
			elseif (db.getAttribute(tablename, "_ROWID_", rowId, field) == v) then
	    			util.appendOut("field " .. field .. " hasnt changed<br>")
		    	else
			    	fieldsSetString = fieldsSetString .. splitparts[2] .. " = \'" .. v .. "\', "
    			end
            end
		end
	end
	queryString = queryString .. fieldsSetString
	queryString = queryString:sub(1, queryString:len()-2) --shave last comma
	queryString = queryString .. " WHERE _ROWID_ = \'" .. rowId .. "\'"
	
	-- execute it if any updates
	if (fieldsSetString ~= "") then
		local cur, errstr = db.execute(queryString)
		util.appendDebugOut(queryString .. "<br>")
		return cur, errstr
	-- else no change
	else
		return true, ""
	end
end

-- Delete from the DB table all rows with the given ROWIDs
-- from the given LUA table of rows (key ignored, value is rowid).
function db.delete (tablename, tableInput)
	local queryString = "DELETE FROM " .. tablename .. " WHERE " 
	for k,v in pairs(tableInput) do
		queryString = queryString .. "_ROWID_ = \'" .. v .. "\' OR "
	end
	queryString = queryString:sub(1, queryString:len()-3) --shave last OR

	-- execute it
	local cur, errstr = db.execute(queryString)
	util.appendDebugOut(queryString .. "<br>")
	
	return cur, errstr
end

-- Get the column names of the given DB table.
-- Returns nil on error.
function db.getColNames (tablename)
	-- query
    local cur = db.execute(string.format([[
		SELECT * FROM %s
	]], tablename))

	-- return
	local results = {}
	if (cur) then
		results = cur:getcolnames()
		cur:close()
	else
		results = nil
	end
	return results
end

-- Get the number of columns of the given DB table.
-- Returns nil on error.
function db.numCols (tablename)
	return #db.getColNames(tablename)
end

-- Get the column types of the given DB table.
-- Returns nil on error.
function db.getColTypes (tablename)
	-- query
    local cur = db.execute(string.format([[
		SELECT * FROM %s
	]], tablename))

	-- return
	local results = {}
	if (cur) then
		results = cur:getcoltypes()
		cur:close()
	else
		results = nil
	end
	return results
end

-- Get the column type of the field from the given DB table.
-- Returns nil on error.
function db.getColType (tablename, field)
    local key = util.keyTableValueExists(db.getColNames(tablename), field)
    if (key) then
    	return db.getColTypes(tablename)[key]
    else return nil
   	end
end

-- Validate input based on type and range.
function db.typeAndRangeValidate (inputTable)
	util.appendOut("----------- Begin input validation -----------<br>")
	for k,v in pairs(inputTable) do
		local splitparts = util.split(k, ".")
		--for only table fields
		if (#splitparts == 2) then
			-- test if type is correct
			local ftype = db.getColType(splitparts[1], splitparts[2])
			-- if valid field
			if (ftype) then
				util.appendOut(splitparts[2] .. " is a " .. ftype .. "<br>")
				-- worry only for int fields
				if (ftype == "integer") then
					local inNum = tonumber(v)
					-- good int?
					if (type(inNum) == "number") then
						-- check whitespace
						local s_str = string.sub(v, 1, 1)
						local e_str = string.sub(v, -1, -1)
						if (s_str == " " or e_str == " ") then
							util.appendOut("Invalidation: unnecessary white space at beg or end<br>")
							return false
						end
						-- check range
						local min = tonumber(db.getMin(splitparts[1], splitparts[2]))
						local max = tonumber(db.getMax(splitparts[1], splitparts[2]))
						if min and max then
							util.appendOut("min = " .. min .. ", max = " .. max .. "<br>")
							if not (inNum >= min and inNum <= max) then
								util.appendOut("Invalidation: bad range<br>")
								return false
							end
						end
					-- not int
					else
						util.appendOut("Invalidation: not and integer<br>")
						return false
					end
				end
			end
		end
	end 
	return true
end

-- Print the table to a string and return it.
function db.printTable (tablename)
	-- query
    local cur = db.execute(string.format([[
		SELECT *, ROWID AS _ROWID_ FROM %s
	]], tablename))

	-- print all rows, the rows will be indexed by field names
	local toReturn = ""
	if (cur) then
		local row = cur:fetch ({}, "a")
		toReturn = "***** DB Table: " .. tablename .. " ****<br>"
		while row do
			local rowString = "ROW ::: "
			for k,v in pairs(row) do
				rowString = rowString .. k .. " = " .. v .. ", "
			end
			rowString = rowString:sub(1, rowString:len()-2) --shave last comma
			toReturn = toReturn .. rowString .. "<br>"
			-- get the next row
		  	row = cur:fetch (row, "a")
		end
		toReturn = toReturn .. "******* table end *******<br>"
		cur:close()
	else
        toReturn = "Empty table: " .. tablename .. "<br>"
	end

	-- return
	return toReturn
end

-- Get the number of entries in the table.
function db.tableSize (tablename)
	-- query
    local cur = db.execute(string.format([[
		SELECT COUNT(*) FROM %s
	]], tablename))

	-- print all rows, the rows will be indexed by field names
	if (cur) then
		local row = cur:fetch ({}, "n")
		cur:close()
		return row[1]
	else
		return 0
	end
end

-- Serialize o.
local function basicSerialize (o)
	if type(o) == "number" then
		return tostring(o)
	else   -- assume it is a string
		return string.format("%q", o)
	end
end

-- Save table to file in ascii format.
function db.saveTable (f, name, value, saved, rowid, topTable)
	local one, two = "", ""
	saved = saved or {}       -- initial value
	if type(value) == "number" or type(value) == "string" then
		one = name .. " = "
		two = basicSerialize(value) .. "\n"
		f:write(one, two)
	elseif type(value) == "table" then
        if (value["_metadata"] ~= nil) then
            if (string.find (value["_metadata"], "edit *= *0") ~= nil) then
                return 0; -- skip this row
            end
        end
		one = name .. " = "
		if saved[value] then    -- value already saved?
			f:write(one)
			f:write(saved[value], "\n")  -- use its previous name
		else
			f:write(one)
			f:write("{}\n")
			saved[value] = name   -- save name for next time
			for k,v in pairs(value) do      -- save its fields
                local fieldname;
                fieldname = string.format("%s[%s]", name, basicSerialize(k))
	            if type(v) ~= "table" then
                    rowid = rowid + db.saveTable(f, fieldname, v, saved, rowid, 0)
                end
            end
            -- save tables in the end
			for k,v in pairs(value) do      
                local fieldname;
                fieldname = string.format("%s[%s]", name, basicSerialize(k))
	            if type(v) == "table" then
                    rowid = rowid + db.saveTable(f, fieldname, v, saved, rowid, 0)
                end
            end
            
        end
	else
	-- function
	end
	f:flush()
    return 1;
end

-- Any changes needed in db.save(). Please make them in db.save2().
-- This function internally calls db.save().
function db.save()
    sqliteLib.saveConfig()
end

-- Export settings and flash it. 
function db.save2 ()
    -- Set the BOOTSTRAP value to 0 to indicate the box is not in factory reset
    -- state.
    if (SETTINGS_FILE == "/flash/teamf1.cfg.ascii" ) then
        if not (util.fileExists(SETTINGS_FILE)) then
            db.setAttribute("environment", "name", "BOOTSTRAP", "value", "0")
        end
    else
        if not (util.fileExists("/flash/teamf1.cfg.ascii")) then
            db.setAttribute("environment", "name", "BOOTSTRAP", "value", "0")
        end
    end

    -- Export old format configuration
    local file = io.open(SETTINGS_FILE .. "", "wb")
	if (file == nil) then
		util.appendDebugOut("Saving configuration failed<br>")
		return
	end

    local saveTables = db.getTable("saveTables", false)
    if (saveTables ~= nil) then
        for k,v in pairs(saveTables) do
            db.saveTable(file, v["tableName"], db.getTable(v["tableName"], false), false, 1, 1)
        end
    end
	
    -- export
	config.export(file)
    file:close()
	-- update checksum
	config.updateChecksum (SETTINGS_FILE)

    if(SETTINGS_FILE ~= "/flash/teamf1.cfg.ascii") then
        -- copy file to flash
        local writeprog = db.getAttribute("environment", "name", "CFG_WRITE_PROGRAM", "value")
        local configpart = db.getAttribute("environment", "name", "FLASH_CFG_PARTITION", "value")
        
        util.appendDebugOut("Exec = " .. os.execute(writeprog .. " " .. configpart .. " " .. SETTINGS_FILE))
    end
	util.appendDebugOut("Saved DB!<br>")

    -- Flush file system buffers so that configuration is written to flash
    -- synchronously as some filesystem write happens asynchronously.
    os.execute("/bin/sync")
end

-- Insert into the DB table the name-value pairs from
-- the given LUA table.
function db.insertImport (tablename, tableInput, notFullKey)
	local queryString = ""
	local insertPart = "INSERT INTO " .. tablename .. " ("
	local valuesPart = ") VALUES ("
	
	-- get col names
	local allKeys = db.getColNames(tablename)
	-- check if the table has the rowid column
	if ((notFullKey and util.tableKeyExists(tableInput, "_ROWID_")) or 
		 (util.tableKeyExists(tableInput, tablename .. "._ROWID_"))) then
		local numKeys = #allKeys
		-- add rowid to the keys table
		allKeys[numKeys + 1] = "_ROWID_"		
	end

	-- get defaults
	local defaults = db.getDefaults(false, tablename)
	-- make strings
	for k,v in pairs(allKeys) do
		-- skip rowid column
			insertPart = insertPart .. "\'" .. v .. "\', "
			-- if post contained field already
			if notFullKey and util.tableKeyExists(tableInput, v) then
				valuesPart = valuesPart .. "\'" .. tableInput[v] .. "\', "
			elseif util.tableKeyExists(tableInput, tablename .. "." .. v) then
				valuesPart = valuesPart .. "\'" .. tableInput[tablename .. "." .. v] .. "\', "
			-- else if default exists, use it
			elseif defaults[tablename .. "." .. v] then
				valuesPart = valuesPart .. "\'" .. defaults[tablename .. "." .. v] .. "\', "
			-- else use empty string
			else
				valuesPart = valuesPart .. "NULL, "
			end
	end

	insertPart = insertPart:sub(1, insertPart:len()-2) --shave last comma
	valuesPart = valuesPart:sub(1, valuesPart:len()-2) --shave last comma
	valuesPart = valuesPart .. ")"
	
	-- execute it
	queryString = insertPart .. valuesPart
	local cur, errstr = db.execute(queryString)
	util.appendDebugOut(queryString .. "<br>\n")

	return cur, errstr
end

-- db import routine
function db.import ()
    local valid = true
    local saveTables = db.getTable("saveTables", false)
	db.beginTransaction()
	
	-- for each dbTable
	for k,v in pairs(saveTables) do
		if (not valid) then break end
		local tableName = v["tableName"]
		local table = util.getLuaVariable(tableName)
        
        if (table == nil) then
            print ("no LUA variable:" .. tableName)            
        end
            
		if (table ~= nil and #table >= 1) then
			-- for each row
			for kk,vv in pairs(table) do
			    if (tableName == "oidRecord") then
			        -- We'll first have to modify the key
				-- values to add table name as db.update expects
			        local fixedTab = {}
				for tt, vv in pairs (table[kk]) do
				    fixedTab[tableName.."."..tt] = vv
                                end
				valid = db.update (tableName, fixedTab,table[kk]["_ROWID_"])
			    else   
			       valid = db.insertImport(tableName, table[kk], true, true)
                            end
				if (not valid) then 
			       print ("table insert/update failed for " .. tableName)
                    break 
                end
			end
		end
	end
	
	if (valid) then
		db.commitTransaction()
        return "imported successfully!"
	else
		db.rollback()
        return "import failed!"
	end
end

local beginTransaction = 0
-- Being transaction
function db.beginTransaction ()
	if (globalTransaction == true) then
        return
    end
	assert (beginTransaction == 0, "nested begin transaction")

	if (beginTransaction == 0) then
    	-- query
        queryString = "BEGIN TRANSACTION"
        local cur = db.execute(queryString)
        util.appendDebugOut(queryString .. "<br>")
        if (config.beginOperation) then
            config.beginOperation()
        end
        beginTransaction = 1
    end
end

-- Commit transaction
function db.commitTransaction ()
	if (globalTransaction == true) then
        return
    end
	if (beginTransaction) then
    	-- query
	    queryString = "COMMIT"
        local cur = db.execute(queryString)
        util.appendDebugOut(queryString .. "<br>")
        if (config.commitOperation) then
            config.commitOperation()
        end
        beginTransaction = 0
    end
end

-- Rollback transaction
function db.rollback ()
	if (globalTransaction == true) then
        return
    end
	if (beginTransaction) then
    	-- query
	    queryString = "ROLLBACK"
        local cur = db.execute(queryString)
        util.appendDebugOut(queryString .. "<br>")

        if (config.rollbackOperation) then
            config.rollbackOperation()
        end
        beginTransaction = 0
    end
end

function db.hasTransactionBegun()
	if (beginTransaction == 1) then
		return true
	else
		return false
	end
end

function db.markGlobalTransactionStart()
	globalTransaction = true
end

function db.markGlobalTransactionEnd()
	globalTransaction = false
end

function db.getMaxVal (tablename, attribute)
    local attr = "max(" .. attribute .. ")"
    local query = string.format([[SELECT max(%s) FROM %s ]], attribute, tablename)
    local cur = db.execute(query)
    local result = nil

    if (cur) then
        local row = cur:fetch ({}, "a")
        cur:close()
        if (row) then
	        result = row[attr] 
        end
    end

	return result
end

function db.gethandle()
    return _DB_con:gethandle()
end

