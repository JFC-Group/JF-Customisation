--[[
#### Chaitanya Dandamudi
#### TeamF1
#### www.TeamF1.com
#### December 12, 2007

#### File: x509.lua
#### Description: x509 functions

#### Revisions:
None
]]--


--************* Requires *************

require "x509Lib"

--************* Initial Code *************

--package x509
x509 = {}

--table packages
cert = {}

--************* Functions *************

-- x509 inputValidate
function x509.inputValidate (inputTable, operation)
        if (true) then
            return db.typeAndRangeValidate(inputTable)
        end
        return false
end
        
-- x509 configuration
function x509.uploadTrustedCACert (inputTable)
    -- if not allowed to edit
        if (ACCESS_LEVEL ~= 0) then
                NextPage = "uploadTrustedCertificate"
                return "ACCESS_DENIED", "ADMIN_REQD"
        end
        db.beginTransaction() --begin transaction
        local valid = false

        -- uploading Certificate
       	util.appendDebugOut(util.tableToStringRec(inputTable))
    	local fileSize = inputTable["file.upload"]["filesize"]
	local fileName = inputTable["file.upload"]["filename"]
    	local fileHandle =  inputTable["file.upload"]["file"]
	-- moving file to required path
	local fileName = cgilua.cookies.get("TeamF1Login")
	local valid = os.execute("mv" .. " " .. "/tmp/" .. 
                             fileName .. " /tmp/" .. "temp.crt")

    local certInputTable = {}
    local certData
    certData = util.fileToString("/tmp/temp.crt")
    
    local status,name,subjectName,issuerName,expiryTime,serialNumber,format =
                                                    x509Lib.certLoad(certData)
    
    if (status == -1) then
        return "ERROR", "X509_INVALID_CA"
    end 
 
    certInputTable["cert.name"] = name
    certInputTable["cert.subjectName"] = subjectName
    certInputTable["cert.issuerName"] = issuerName
    certInputTable["cert.expiryTime"] = expiryTime
    certInputTable["cert.serialNumber"] = serialNumber
    certInputTable["cert.format"] = format
    certInputTable["cert.certType"] = "ca"
    certInputTable["cert.certData"] = certData
    valid = db.insert("cert",certInputTable)
    -- return
	if (valid) then
		db.commitTransaction(true)		

		--copy CA cert in /var/certs dir
		k = db.getRowWhere("cert","certType='ca'",false)
		os.execute("mv" .. " /tmp/" .. "temp.crt" .. " /var/certs/ca/CA" .. k["_ROWID_"] .. ".crt")                                                
		return "OK", "X509_CA_ADD_SUCCESS"
	else
		db.rollback()
		return "ERROR", "X509_CA_ADD_FAILURE"
	end
end

--Trusted Cert Delete
function x509.trustedCACertDelete (rowIds)

	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end

	db.beginTransaction() --begin transactions

	-- delete Trusted Certificates
        for k,v in pairs(rowIds) do
            local inTable = {}
            inTable["cert._ROWID_"] = v;
         
            -- delete <hash_of_certificate>.0 file
           local status,subjectHash = x509Lib.getCertHash(v)
          
           if (status == -1) then
	       db.rollback()
               return "ERROR", "X509_CA_DEL_FAILURE"
           end     
           
           os.execute("rm" .. " /var/certs/ca/" .. subjectHash .. ".0" )
          
           -- delete CA<rowId>.crt file 
           os.execute("rm" .. " /var/certs/ca/" .. "CA" .. v .. ".crt" )
         
           valid = db.delete("cert", inTable)
	end

	-- return
	if (valid) then
		db.commitTransaction(true)
		return "OK", "X509_CA_DEL_SUCCESS"
	else
		db.rollback()
		return "ERROR", "X509_CA_DEL_FAILURE"
	end

end

--Active Self Cert Delete
function x509.activeSelfCertDelete (rowIds)
      
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end

	db.beginTransaction() --begin transactions

	-- delete Trusted Certificates
        for k,v in pairs(rowIds) do
            local inTable = {}
            inTable["cert._ROWID_"] = v;
		    valid = db.delete("cert", inTable)
        -- delete self<rowId>.crt file 
        os.execute("rm" .. " /var/certs/self/" .. "self" .. v .. ".crt" )
     	end

	-- return
	if (valid) then
		db.commitTransaction(true)
		return "OK", "X509_SELF_DEL_SUCCESS"
	else
		db.rollback()
		return "ERROR", "X509_SELF_DEL_FAILURE"
	end

end


-- Generate Self Certificate
function x509.genSelfCert (inputTable)
    -- if not allowed to edit
        if (ACCESS_LEVEL ~= 0) then
                NextPage = "generateSelfCertificateRequest"
                return "ACCESS_DENIED", "ADMIN_REQD"
        end
        db.beginTransaction() --begin transaction
        local valid = false
        -- overright with new certificate for same applications, currently
        -- it is supporting for https and ipsec, in future we may support more
        -- applications.	
        httpsConfigRow = db.getRow ("x509SelfCertReq","appType","https")
    	ipsecConfigRow = db.getRow ("x509SelfCertReq","appType","ipsec")
        if (inputTable["x509SelfCertReq.appType"] == "https") then
             if (httpsConfigRow) then
                 -- clear the existing table's hidden data before update. 
                 inputTable["x509SelfCertReq.selfCertData"] = ""
                 inputTable["x509SelfCertReq.selfKeyData"] = ""
                 valid = db.update("x509SelfCertReq",inputTable,
                          httpsConfigRow["x509SelfCertReq._ROWID_"])
             else             
	             valid = db.insert("x509SelfCertReq", inputTable)
             end              
        elseif (inputTable["x509SelfCertReq.appType"] == "ipsec") then
             if (ipsecConfigRow) then
                 -- clear the existing table's hidden data before update. 
                 inputTable["x509SelfCertReq.selfCertData"] = ""
                 inputTable["x509SelfCertReq.selfKeyData"] = ""
                valid = db.update("x509SelfCertReq",inputTable,
                          ipsecConfigRow["x509SelfCertReq._ROWID_"])
             else             
	             valid = db.insert("x509SelfCertReq", inputTable)
             end              
        end
    
     -- return
	if (valid) then
		db.commitTransaction(true)
		return "OK", "STATUS_OK"
	else
		db.rollback()
		return "ERROR", "X509_SELF_GEN_FAILURE"
	end
end
 

--Self Cert Delete
function x509.selfCertDelete (rowIds)

	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end

	db.beginTransaction() --begin transactions

	-- delete Self Certificates
        for k,v in pairs(rowIds) do
            local inTable = {}
            inTable["x509SelfCertReq._ROWID_"] = v;
		    valid = db.delete("x509SelfCertReq", inTable)
	end

    -- return
	if (valid) then
		db.commitTransaction(true)
		return "OK", "X509_SELF_DEL_SUCCESS"
	else
		db.rollback()
		return "ERROR", "X509_SELF_DEL_FAILURE"
	end

end


-- upload Active Self Certificates
function x509.uploadSelfCert (inputTable)
    -- if not allowed to edit
        if (ACCESS_LEVEL ~= 0) then
                NextPage = "uploadActiveSelfCertificate"
                return "ACCESS_DENIED", "ADMIN_REQD"
        end
        db.beginTransaction() --begin transaction
        local valid = false

        -- uploading Certificate
       	util.appendDebugOut(util.tableToStringRec(inputTable))
    	local fileSize = inputTable["file.upload"]["filesize"]
	local fileName = inputTable["file.upload"]["filename"]
    	local fileHandle =  inputTable["file.upload"]["file"]
	-- moving file to required path
	local fileName = cgilua.cookies.get("TeamF1Login")
	local valid = os.execute("mv" .. " " .. "/tmp/" .. 
                             fileName .. " /tmp/" .. "temp.crt")

    local certInputTable = {}
    local certData
    certData = util.fileToString("/tmp/temp.crt")
    
    local status,name,subjectName,issuerName,expiryTime,serialNumber,format =
                                                    x509Lib.certLoad(certData)
                                                    
    if (status == -1) then
        return "ERROR", "X509_INVALID_SELF"
    end 
 
    certInputTable["cert.name"] = name
    certInputTable["cert.subjectName"] = subjectName
    certInputTable["cert.issuerName"] = issuerName
    certInputTable["cert.expiryTime"] = expiryTime
    certInputTable["cert.serialNumber"] = serialNumber
    certInputTable["cert.format"] = format
    certInputTable["cert.certType"] = "self"
    certInputTable["cert.certData"] = certData
    valid = db.insert("cert",certInputTable)
    -- return
	if (valid) then
		db.commitTransaction(true)		
		--copy Device cert in /var/certs dir
	    k = db.getRowWhere("cert","certType='self'",false)
		os.execute("mv" .. " /tmp/" .. "temp.crt" .. " /var/certs/self/self" .. k["_ROWID_"] .. ".crt")                                                
		return "OK", "X509_SELF_ADD_SUCCESS"
	else
		db.rollback()
		return "ERROR", "X509_SELF_ADD_FAILURE"
	end
end

function cert.cert_config (inputTable, rowid, operation)
     -- validate
     if (cert.inputvalidate(inputTable, operation)) then
         if (operation == "add") then
              return db.insert("cert", inputTable)
         elseif (operation == "edit") then
              return db.update("cert", inputTable, rowid)
         elseif (operation == "delete") then
              for k,v in pairs(inputTable) do
                  valid  = db.deleteRow("cert", "_ROWID_", v)
                  if (not valid) then  return false end
                  end
              return true
         end
     end
     return false
end

function cert.inputvalidate(inputTable, operation)
   return true;
end

function cert.import (configTable, defaultConfigTable)

    if (configTable == nil) then
        configTable = defaultConfigTable
    end
 
    for i,v in ipairs (configTable) do
	v = util.addPrefix (v, "cert.")
        cert.cert_config (v, "-1", "add");
    end

end

function cert.export ()
    local cert = db.getTable ("cert", false)
    return cert
end


if (config.register) then
   config.register("cert", cert.import, cert.export, "1")
end

