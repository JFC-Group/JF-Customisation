--[[ easyMeshChangePassword.lua - Handler for Easy Mesh Login passord Change.
--
-- Copyright (c) 2008-2014, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: easyMeshChangePassword.lua
-- Description: Handler for Easy Mesh Login passord Change.
-- 
-- modification history
-- --------------------
-- 01a, 17Dec19, ar written.
--
--]]

require "easyMeshLib"
require "ifDevLib"

-- List of WiFi_AP Tags as defined by Customer Specification.
local WiFi_APobj = {
    ["Result"] = "Result"
}

-- Initialise the SSIDGetResponse_t Lua Table which will be coverted as JSON Object
local SSIDGetResponse_t = {
    ["Result"] = "ERROR",
    ["Response_Code"] = "400",
    ["Error_Message"] = "Failed to get WiFiSSID"
}

-- Supported Return Codes for "SSIDGetResponse"
local SSIDGetResponse_ReturnCodes = {
    ["OK"] = "OK",
    ["ERROR"] = "ERROR",
    ["SUCCESS"] = "Success",
    ["FAILED"]  = "Failed",
}

local WIFISON_NODE = "WIFISON_SSID"
local WIFISON_NUMBER = "WiFi_AP_Numbers"
local WIFISON_AP_ENABLE = "WiFi_AP_Enable"
local WIFISON_SSIDNAME = "WiFi_AP_SSID" 
local WIFISON_SSIDPASSWORD = "WiFi_AP_Password" 
local WIFISON_BSS_TYPE     = "WiFi_BSS_Type"

local WIFISON_NODE_DEVICE_MAC = "Device_MAC"
local WIFISON_NODE_COMMON_NODE = "Common"
local WIFISON_NODE_RADIO_NODE = "radios"
local WIFISON_NODE_RADIO_TYPE = "radio_type"
local WIFISON_NODE_RADIO_BASE_MAC = "base_mac"
local WIFISON_RADIO_24G_STR = "radio_24"
local WIFISON_RADIO_5G_STR = "radio_5"
----------------------------------------------
--SSID Get Request
--
-- @description This function Handles EasyMesh SSID Get Request Method.
--
--returns JSON response for EasyMesh SSID Get Request
--

function getEasyMeshDeviceSsidHandler(methodObj, meshRequestMethod)

    local status
    local WiFi_APobj = methodObj["WiFi_AP"]
    local dot11Profile_t
        
    if((WiFi_APobj == nil) or (type(WiFi_APobj) ~= "table"))then
        SSIDGetResponse_t["Result"] = SSIDGetResponse_ReturnCodes["FAILED"]  
        SSIDGetResponse_t["Response_Code"] = "400"
        SSIDGetResponse_t["Error_Message"] = "Bad Request"
        --mesh.sendResponse (SSIDGetResponse_t) 
        return "ERROR", "INVALID_METHOD", SSIDGetResponse_t
    end
   
    --Get the SSID Information from dot11VAP and dot11Profile Table
    dot11Profile_t = db.getTable("dot11Profile",false)

    if(dot11Profile_t == nil) then      
        SSIDGetResponse_t["Result"] = SSIDGetResponse_ReturnCodes["FAILED"]  
        SSIDGetResponse_t["Response_Code"] = "400"
        SSIDGetResponse_t["Error_Message"] = "Bad Request"
        --mesh.sendResponse (SSIDGetResponse_t) 
        return "ERROR", "INVALID_METHOD", SSIDGetResponse_t
    end    

    if(dot11Profile_t ~= nil) then

	SSIDGetResponse_t[WIFISON_NODE]={}

        for k,v in pairs(dot11Profile_t) do
	
		-- do not send BH AP profile to user
		if ( v["profileName"] ~= "Jio_5" ) then
			

	    local ssidNode = {}
            local vapEnabled = db.getAttribute("dot11VAP","profileName", v["profileName"],"vapEnabled")
            if(vapEnabled == "1") then
                ssidNode[WIFISON_AP_ENABLE] = "True"
            else   
                ssidNode[WIFISON_AP_ENABLE] = "False"
            end      
            ssidNode[WIFISON_SSIDNAME] = v["ssid"]   
            ssidNode[WIFISON_SSIDPASSWORD] = v["pskPassAscii"]
            ssidNode[WIFISON_BSS_TYPE] = "FH"

            ssidNode[WIFISON_NODE_COMMON_NODE] = {}
            ssidNode[WIFISON_NODE_COMMON_NODE][WIFISON_NODE_RADIO_NODE] = {}
    
            local vapName = db.getAttribute("dot11VAP","profileName", v["profileName"],"vapName")
            local radioNo = db.getAttribute("dot11Interface","vapName",vapName,"radioNo")
            local vapInterfaceName = db.getAttribute("dot11Interface","vapName",vapName,"interfaceName")     
            local baseMac = ifDevLib.getMac(vapInterfaceName)

	    local radioNode = {}
      
            if(radioNo == "1") then
                radioNode[WIFISON_NODE_RADIO_TYPE] = WIFISON_RADIO_24G_STR 
            else
                radioNode[WIFISON_NODE_RADIO_TYPE] = WIFISON_RADIO_5G_STR 
            end 

            radioNode[WIFISON_NODE_RADIO_BASE_MAC] = baseMac    
	    table.insert(ssidNode[WIFISON_NODE_COMMON_NODE][WIFISON_NODE_RADIO_NODE], radioNode)

	    table.insert(SSIDGetResponse_t[WIFISON_NODE], ssidNode)

		end
        end    
	
    end       
    SSIDGetResponse_t[WIFISON_NUMBER] = tostring(#SSIDGetResponse_t[WIFISON_NODE])
    SSIDGetResponse_t[WIFISON_NODE_DEVICE_MAC] = ifDevLib.getMac("bdg2")
    SSIDGetResponse_t["Result"] = SSIDGetResponse_ReturnCodes["OK"]  
    SSIDGetResponse_t["Error_Message"] = nil
    SSIDGetResponse_t["Response_Code"] = "200"
    --mesh.sendResponse (SSIDGetResponse_t) 
    return "OK", "SUCCESS", SSIDGetResponse_t

end

meshRequestMethodsList["SSIDGet"]["methodHandler"] = getEasyMeshDeviceSsidHandler

