--[[
#### Copyright (c) 2012, TeamF1, Inc.
#### File: qosBwTest.lua
#### Description: 
#### Revisions:
01a 03aug12, sam written
]]--

qos.bwTest = {}
-------------------------------------------------------------------------------
-- @name qos.bwTest.start
--
-- @description 
--
-- @param  
--
-- @return  status OK or ERROR
-- @return  errCode error code string
--

function qos.bwTest.start(LogicalIfName)

    if (LogicalIfName == nil) then
        return "ERROR", "QOS_ERR_BWTEST_IFNAME_NOT_SPECIFIED"
    end
            
    local status = qosLib.bwTestStart(LogicalIfName)
    if (not status or status < 0) then
        return "ERROR", "QOS_ERR_BWTEST_START_ERR"
    end        

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name qos.bwTest.stop
--
-- @description 
--
-- @param  
--
-- @return  status OK or ERROR
-- @return  errCode error code string
--

function qos.bwTest.stop()
    local status = qosLib.bwTestStop()
    if (not status or status < 0) then
        return "ERROR", "QOS_ERR_BWTEST_STOP_ERR"
    end        

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name qos.bwTest.ifaceSet
--
-- @description 
--
-- @param  
--
-- @return  status OK or ERROR
-- @return  errCode error code string
--

function qos.bwTest.ifaceSet(LogicalIfName)
    local valid, errstr = db.setAttribute("qosBwMtrConf", "_ROWID_", "1", 
                                          "LogicalIfName", LogicalIfName)
    if (not valid) then
        qos.dprintf("bwTest.ifaceSet: failed to configure bandwidth test " ..
                    "for:" .. LogicalIfName .. 
                    " Error: " .. (errstr or 'n/a'));
        return "ERROR", "QOS_ERR_BWTEST_DB_ERR"
    end       
    
    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name qos.bwTest.ifaceGet
--
-- @description 
--
-- @param  
--
-- @return  status OK or ERROR
-- @return  errCode error code string
--

function qos.bwTest.ifaceGet()
    local LogicalIfName = db.getAttribute("qosBwMtrConf", "_ROWID_", "1",
                                          "LogicalIfName")

    return LogicalIfName
end

-------------------------------------------------------------------------------
-- @name qos.bwTest.confGet
--
-- @description 
--
-- @param  
--
-- @return  status OK or ERROR
-- @return  errCode error code string
--

function qos.bwTest.confGet()
    local conf = {}
    local query = "_ROWID_=1"

    conf = db.getRowWhere("qosBwMtrConf", query, false)
    if (conf == nil) then
        return "ERROR", "QOS_ERR_BWMTR_QRY"
    end        

    return "OK", "STATUS_OK", conf
end

-------------------------------------------------------------------------------
-- @name qos.bwTest.configure
--
-- @description 
--
-- @param  
-- @param  
--
-- @return  status OK or ERROR
-- @return  errCode error code string
--

function qos.bwTest.configure (conf)
    local LogicalIfName  = nil
    local MeasureBandwidth = nil
    
    if (conf["LogicalIfName"] ~= nil) then
        LogicalIfName = conf["LogicalIfName"]
    end

    if (conf["MeasureBandwidth"] ~= nil) then
        MeasureBandwidth = tonumber(conf["MeasureBandwidth"])
    end        

    if ((LogicalIfName == nil) or (MeasureBandwidth == nil)) then
        return "ERROR", "QOS_ERR_BWTEST_INVALID_ARG"
    end        

    local status, errCode, bwMtrConf =  qos.bwTest.confGet()
    if (status ~= "OK") then
        return status, errCode
    end        

    bwMtrConf["LogicalIfName"] =  LogicalIfName
    bwMtrConf["MeasureBandwidth"] =  MeasureBandwidth

    bwMtrConf = util.addPrefix(bwMtrConf, "qosBwMtrConf.")
    local valid, errstr = db.update("qosBwMtrConf", bwMtrConf, bwMtrConf["qosBwMtrConf._ROWID_"])
    if (not valid) then
        qos.dprintf("bwTest.configure: failed to configure " ..
                    "bw meterconfiguration for:" .. LogicalIfName .. 
                    "Error: " .. (errstr or 'n/a'));
        return "ERROR", "QOS_ERR_BWM_DB_ERR"
    end        
    
    if (MeasureBandwidth == 1) then
        status, errCode = qos.bwTest.start(LogicalIfName)
        if (status ~= "OK") then
            qos.dprintf("failed to start bandwidth measurement")
        end            
    end
            
    return "OK", "STATUS_OK"    
end
