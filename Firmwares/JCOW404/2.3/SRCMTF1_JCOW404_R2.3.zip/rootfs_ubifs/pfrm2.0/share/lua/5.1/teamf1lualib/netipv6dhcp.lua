-- @copyright Copyright (c) 2013, TeamF1, Inc.
--
-- modification history
-- --------------------
-- 01d, 23Nov17, swr changes for spr 62635(XSS vulnerability) and 61441
-- 01c, 31Oct17, swr Changes for SPR 59254(radvd prefixes)
-- 01b, 08Sep17, swr Changes for SPR 62295
-- 01a, 10aug13, ash added support for dhcpv6relay
--
gui.networking.dhcpv6 ={}
gui.networking.dhcpv6.pool ={}
gui.networking.dhcpv6.pool.add ={}
gui.networking.dhcpv6.pool.edit ={}
gui.networking.dhcpv6.prefix ={}
gui.networking.dhcpv6.prefix.add ={}
gui.networking.dhcpv6.prefix.edit ={}
gui.networking.radvdPrefix ={}
gui.networking.radvdPrefix.add ={}
gui.networking.radvdPrefix.edit ={}
gui.networking.radvd ={}
gui.networking.network.sixToFour ={}
gui.networking.network.isatap = {}
gui.networking.network.isatap.add ={}
gui.networking.network.isatap.edit ={}
gui.networking.network.ipConf = {}
gui.networking.network.mldproxy = {}
gui.networking.network.maptConf = {}

-------------------------------------------------------------------------
-- @name gui.networking.ipv6DhcpConfGet
--
-- @description
--
-- @param conf
--
-- @return
--

function gui.networking.ipv6DhcpConfGet (conf)
    require "teamf1lualib/dhcpv6"
    local query = nil
    local dhcpv6mode = tostring(dhcpv6.mode.IPV6_DHCP_RELAY)
    conf["dhcpv6Mode"] = tostring(dhcpv6.mode.IPV6_DHCP_NONE)

    conf["dhcpEnable"] = "0"

    if (conf["LogicalIfName"] == nil) then
        gui.dprintf("ipv6DhcpConfGet: Invalid params")
        return "ERROR","DHCPV6D_INVALID_PARAMS"
    end

    -- Get the server configuration
    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "'"
    status, errCode, cfgTbl = dhcpv6.server.get(query)
    if ((cfgTbl ~= nil) and (util.tableSize(cfgTbl) > 0)) then
        row = cfgTbl[1]
        if (tonumber(row["isEnabled"]) > 0) then
            conf["dhcpv6Mode"] = tostring(dhcpv6.mode.IPV6_DHCP_SERVER)
        end
        conf["dhcpEnable"] = row["isEnabled"]
        conf["PrimaryDns"] = row["primaryDNSServer"]
        conf["SecondaryDns"] = row["secondaryDNSServer"]
        conf["StatelessMode"] = row["statelessMode"]
        conf["DNSServers"] = row["useDNSServersFrom"]
        conf["prefixDelegation"] = row["prefixDelegation"]
        conf["DomainName"] = row["domainName"]
        conf["sipServerType"] = row["sipServerType"]
        conf["sipServer"] = row["sipServer"]
        conf["dhcpLeaseTime"] = row["leaseTime"]
        conf["preference"] = row["serverPreference"]
        conf["dhcpMode"] = row["statelessMode"]
    end

    -- include the dhcpv6Relay table
    require "teamf1lualib/dhcpv6Relay"
    status, errCode, relayConf = dhcpv6Relay.confGet(conf["LogicalIfName"])
    -- if v6relay table is present for this logicalifname
    if(relayConf ~= nil) then
        if (tonumber(relayConf["dhcpv6RelayStatus"]) > 0) then
            conf["dhcpv6Mode"] = dhcpv6mode
            conf["relayGw"] = relayConf["relayGw"]
            conf["interfaceID"] = relayConf["interfaceID"]
        end
    end

    return "OK", "STATUS_OK", conf
end

-------------------------------------------------------------------------
-- @name gui.networking.ipv6DhcpConfigure
--
-- @description
--
-- @param conf
--
-- @return
--

function gui.networking.ipv6DhcpConfigure(conf, dbFlag)
    require "teamf1lualib/dhcpv6"
    require "teamf1lualib/radvd"
    require "teamf1lualib/dhcpv6Relay"
    local row = {}

    if (conf["LogicalIfName"] == nil) then
        gui.dprintf("ipv6DhcpConfigure: Invalid params")
        return "ERROR","DHCPV6D_INVALID_PARAMS"
    end

    if(conf["dhcpv6Mode"] == tostring (dhcpv6.mode.IPV6_DHCP_SERVER)) then
        conf["dhcpEnable"] = 1
    else
        conf["dhcpEnable"] = 0
    end

    if (tonumber(conf["dhcpv6Mode"]) == 2) then
        conf["dhcpv6RelayStatus"] = "1"
    else
        conf["dhcpv6RelayStatus"] = "0"
    end
 
    -- configure DHCPv6 server
    row["isEnabled"] = conf["dhcpEnable"] or 0
    row["useDNSServersFrom"] = conf["DNSServers"]
    row["primaryDNSServer"] = conf["PrimaryDns"]
    row["secondaryDNSServer"] = conf["SecondaryDns"]
    row["prefixDelegation"] = conf["prefixDelegation"] or 0
    row["statelessMode"] = conf["dhcpMode"]
    row["domainName"] = conf["DomainName"]
    row["sipServerType"] = conf["sipServerType"]
    row["sipServer"] = conf["sipServer"]
    row["leaseTime"] = conf["dhcpLeaseTime"]
    row["serverPreference"] = conf["preference"]
    row["LogicalIfName"] = conf["LogicalIfName"]

    -- port dependency handling the functions accordingly
    if (tonumber(conf["dhcpv6Mode"]) == 2) then
        status, errCode = dhcpv6.server.configure (row, dbFlag)
        if (status ~= "OK") then
            gui.dprintf("ipv6DhcpConfigure: DHCPv6 server configuration failed")
            return status, errCode
        end

        status, errCode = dhcpv6Relay.confEdit(conf)
        if (status ~= "OK") then
            gui.dprintf("ipv6DhcpConfigure: DHCPv6 relay configuration failed")
            return status, errCode
        end
    else
        status, errCode = dhcpv6Relay.confEdit(conf)
        if (status ~= "OK") then
            gui.dprintf("ipv6DhcpConfigure: DHCPv6 relay configuration failed")
            return status, errCode
        end

        status, errCode = dhcpv6.server.configure (row, dbFlag)
        if (status ~= "OK") then
            gui.dprintf("ipv6DhcpConfigure: DHCPv6 server configuration failed")
            return status, errCode
        end
    end
    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name gui.networking.dhcpv6.pool.get
--
-- @description
--
-- @return
--

function gui.networking.dhcpv6.pool.get(netName)
    require "teamf1lualib/dhcpv6"
    local pools = {}

    if (netName == nil) then
        gui.dprintf("dhcpv6.pool.get: Invalid params")
        return "ERROR","DHCPV6D_INVALID_PARAMS"
    end

    local networkTbl = {}
    networkTbl = db.getRowWhere ("networkInterface", "networkName='" .. netName .. "'", false)
    query = "LogicalIfName='" .. networkTbl.LogicalIfName .. "'"
    status, errCode, pools = dhcpv6.pool.get(query)

    if (status ~= "OK") then
        gui.dprintf("dhcpv6.pool.get: failed to get pool configuration")
        return status, errCode
    end

    for i,v in ipairs (pools) do
        pools[i] = {}
        pools[i] = v
        pools[i].startAddress = util.filterXSSChars(v["startAddress"])
        pools[i].endAddress = util.filterXSSChars(v["endAddress"])
        pools[i].prefixLength = util.filterXSSChars(v["prefixLength"])
    end

    return status, errCode, pools
end

-------------------------------------------------------------------------
-- @name gui.networking.dhcpv6.pool.add.get
--
-- @description
--
-- @return
--

function gui.networking.dhcpv6.pool.add.get (page)
    local conf = {}
    return "OK", "STATUS_OK", conf
end

-------------------------------------------------------------------------
-- @name gui.networking.dhcpv6.pool.add.set
--
-- @description
--
-- @return
--

function gui.networking.dhcpv6.pool.add.set (conf)
    require "teamf1lualib/dhcpv6"
    require "teamf1lualib/radvd"
    require "nimfLib"
 require "teamf1lualib/ifDev"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- check if the start ipv6 is a reserved address or multicast
    if (ifDevLib.isIpv6AddressReserved(conf["startAddr"]) > 0) then
  status = "ERROR"
  errCode = "RESERVED_IPV6_ADDRESS1"
  return status, errCode
     elseif(ifDevLib.isIpv6AddressMulticast(conf["startAddr"]) > 0) then
        status = "ERROR"
        errCode = "MULTICAST_IPV6_ADDRESS"
  return status, errCode
 end

    -- check if the start ipv6 is a reserved address or multicast
    if (ifDevLib.isIpv6AddressReserved(conf["endAddr"]) > 0) then
  status = "ERROR"
  errCode = "RESERVED_IPV6_ADDRESS1"
  return status, errCode
     elseif(ifDevLib.isIpv6AddressMulticast(conf["endAddr"]) > 0) then
        status = "ERROR"
        errCode = "MULTICAST_IPV6_ADDRESS"
  return status, errCode
 end

    conf["startAddress"] = conf["startAddr"]
    conf["endAddress"] = conf["endAddr"]
    conf["_ROWID_"] = "-1"

    if (conf["LogicalIfName"] == nil) then
        gui.dprintf("dhcpv6.pool.add.set: Invalid params")
        return "ERROR","DHCPV6D_INVALID_PARAMS"
    end
        -- GET prefix from the IPv6 addresses
    local prefix = nimfLib.prefixGet(conf["startAddress"], conf["prefixLength"])
    if (prefix == nil) then
        gui.dprintf("dhcpv6.pool.add.set: Invalid IPv6 address or prefixlength")
        return "ERROR", "DHCPV6_POOL_ADDR_INVALID"
    end

     local status, errCode, ifcfg = ifDev.cfgByNameGet(conf["LogicalIfName"])
     if (status == "OK") then
        conf["LogicalIfName"] = ifcfg["LogicalIfName"]
     end

    -- add DHCPv6 pool
    local status, errCode = dhcpv6.pool.configure(conf)
    if (status ~= "OK") then
        gui.dprintf("dhcpv6.pool.add.set: failed to add dhcpv6 pool")
        return status, errCode
    end

    db.save2()

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name gui.networking.dhcpv6.pool.edit.get
--
-- @description
--
-- @return
--

function gui.networking.dhcpv6.pool.edit.get (rowid)
    require "teamf1lualib/dhcpv6"
    local query = nil

    query = "_ROWID_=" .. rowid
    status, errCode, row = dhcpv6.pool.get(query)
    if ((status ~= "OK") or (row == nil) or (row[1] == nil)) then
        gui.dprintf("dhcpv6.pool.edit.get: failed to get dhcpv6 pool")
        return "ERROR", "DHCPV6D_POOL_GET_FAILED"
    end

    row[1]["startAddr"] = util.filterXSSChars(row[1]["startAddress"])
    row[1]["endAddr"] = util.filterXSSChars(row[1]["endAddress"])
    row[1]["prefixLength"] = util.filterXSSChars(row[1]["prefixLength"])

    return "OK", "STATUS_OK", row[1]
end

-------------------------------------------------------------------------
-- @name gui.networking.dhcpv6.pool.edit.set
--
-- @description
--
-- @return
--

function gui.networking.dhcpv6.pool.edit.set (netName, conf)
    require "teamf1lualib/dhcpv6"
    require "nimfLib"
 require "teamf1lualib/ifDev"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (netName == nil) then
        return "ERROR", "DHCPV6D_INVALID_PARAM"
    end
    util.appendDebugOut("Calling the ipv6 pool edit set function <br>")
    -- check if the start ipv6 is a reserved address or multicast
    if (ifDevLib.isIpv6AddressReserved(conf["startAddr"]) > 0) then
  status = "ERROR"
  errCode = "RESERVED_IPV6_ADDRESS1"
  return status, errCode
     elseif(ifDevLib.isIpv6AddressMulticast(conf["startAddr"]) > 0) then
        status = "ERROR"
        errCode = "MULTICAST_IPV6_ADDRESS"
  return status, errCode
 end

    -- check if the start ipv6 is a reserved address or multicast
    if (ifDevLib.isIpv6AddressReserved(conf["endAddr"]) > 0) then
  status = "ERROR"
  errCode = "RESERVED_IPV6_ADDRESS1"
  return status, errCode
     elseif(ifDevLib.isIpv6AddressMulticast(conf["endAddr"]) > 0) then
        status = "ERROR"
        errCode = "MULTICAST_IPV6_ADDRESS"
  return status, errCode
 end

    conf["startAddress"] = conf["startAddr"]
    conf["endAddress"] = conf["endAddr"]
    conf["_ROWID_"] = conf["_ROWID_"]

    -- local networkTbl = {}
    -- networkTbl = db.getRowWhere ("networkInterface", "networkName='" .. netName .. "'", false)

    local status, errCode, ifcfg = ifDev.cfgByNameGet(conf["LogicalIfName"])
    if (status == "OK") then
        conf["LogicalIfName"] = ifcfg["LogicalIfName"]
    end
    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "'"

    local status, errCode, row = dhcpv6.pool.get(query)
    if (row == nil) then
        gui.dprintf("dhcpv6.pool.edit.set: failed to get dhcpv6 pool")
        return "ERROR", "DHCPV6_POOL_GET_FAILED"
    end

    -- GET prefix from the IPv6 addresses
    local prefix = nimfLib.prefixGet(conf["startAddress"], conf["prefixLength"])
    if (prefix == nil) then
        gui.dprintf("dhcpv6.pool.edit.set: Invalid IPv6 address or prefixlength")
        return "ERROR", "DHCPV6_POOL_ADDR_INVALID"
    end

    -- configure the DHCP server pool
    local status, errCode = dhcpv6.pool.configure(conf)
    if (status ~= "OK") then
        gui.dprintf("dhcpv6.pool.edit.set: failed to edit dhcpv6 pool")
        return status, errCode
    end

    db.save2()

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name gui.networking.dhcpv6.pool.delete
--
-- @description
--
-- @return
--

function gui.networking.dhcpv6.pool.delete (IDList)
    require "teamf1lualib/dhcpv6"
    require "teamf1lualib/radvd"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (IDList == nil) then
        return "ERROR", "DHCPV6_INVALID_POOL_ID"
    end

    local status, errCode = dhcpv6.pool.delete(IDList)
    if (status ~= "OK") then
        gui.dprintf("dhcpv6.pool.delete: failed to delete dhcpv6 pool")
        return status, errCode
    end

    db.save2()

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name gui.networking.radvdPrefix.get
--
-- @description
--
-- @return
--

function gui.networking.radvdPrefix.get(netName)
    require "teamf1lualib/radvdPrefix"
    local prefix = {}

    if (netName == nil) then
        gui.dprintf("radvdPrefix.get: Invalid params")
        return "ERROR","RADVD_PREFIX_INVALID_PARAMS"
    end

    local networkTbl = {}
    networkTbl = db.getRowWhere ("networkInterface", "networkName='" .. netName .. "'", false)
    query = "LogicalIfName='" .. networkTbl.LogicalIfName .. "'"
    status, errCode, prefix = radvdPrefix.get(query)

    if (status ~= "OK") then
        gui.dprintf("radvdPrefix.get: failed to get prefix configuration")
        return status, errCode
    end

    for i,v in ipairs (prefix) do
        prefix[i] = {}
        prefix[i] = v
        prefix[i].radvdAdvPrefix = util.filterXSSChars(v["radvdAdvPrefix"])
        prefix[i].radvdAdvPrefixLength = util.filterXSSChars(v["radvdAdvPrefixLength"])
        prefix[i].radvdAdvPrefixLifetime = util.filterXSSChars(v["radvdAdvPrefixLifetime"])
    end

    return status, errCode, prefix
end

-------------------------------------------------------------------------
-- @name gui.networking.radvdPrefix.add.get
--
-- @description
--
-- @return
--

function gui.networking.radvdPrefix.add.get (page)
    local conf = {}
    return "OK", "STATUS_OK", conf
end

-------------------------------------------------------------------------
-- @name gui.networking.radvdPrefix.add.set
--
-- @description
--
-- @return
--

function gui.networking.radvdPrefix.add.set (conf, dbFlag)
    require "teamf1lualib/radvd"
    require "nimfLib"
    require "teamf1lualib/ifDev"

   if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
   end

    if(dbFlag == nil) then
        dbFlag = 1
    end

    if (conf["radvdPrefixType"] == "2") then
    -- check if the radvdAdvPrefix is a reserved address or multicast
        if (ifDevLib.isIpv6AddressReserved(conf["radvdAdvPrefix"]) > 0) then
            status = "ERROR"
            errCode = "RESERVED_IPV6_ADDRESS1"
            return status, errCode
        elseif(ifDevLib.isIpv6AddressMulticast(conf["radvdAdvPrefix"]) > 0) then
            status = "ERROR"
            errCode = "MULTICAST_IPV6_ADDRESS"
        return status, errCode
        end
    end
    
    conf["_ROWID_"] = "-1"

    if (conf["LogicalIfName"] == nil) then
        gui.dprintf("radvdPrefix.add.set: Invalid params")
        return "ERROR","RADVD_PREFIX_INVALID_PARAMS"
    end

     local status, errCode, ifcfg = ifDev.cfgByNameGet(conf["LogicalIfName"])
     if (status == "OK") then
        conf["LogicalIfName"] = ifcfg["LogicalIfName"]
     end

    -- add prefix to radvd

    local status, errCode = radvdPrefix.add(conf, dbFlag)
    if (status ~= "OK") then
        gui.dprintf("radvdPrefix.add.set: failed to add radvd prefix")
        return status, errCode
    end

    db.save2()

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name gui.networking.radvdPrefix.edit.get
--
-- @description
--
-- @return
--

function gui.networking.radvdPrefix.edit.get (rowid)
    require "teamf1lualib/radvdPrefix"
    local query = nil

    query = "_ROWID_=" .. rowid
    status, errCode, row = radvdPrefix.get(query)
    if ((status ~= "OK") or (row == nil) or (row[1] == nil)) then
        gui.dprintf("radvdPrefix.edit.get: failed to get radvd Prefix")
        return "ERROR", "RADVD_PREFIX_GET_FAILED"
    end

    row[1]["radvdAdvPrefix"] = util.filterXSSChars(row[1]["radvdAdvPrefix"])
    row[1]["radvdAdvPrefixLength"] = util.filterXSSChars(row[1]["radvdAdvPrefixLength"])
    row[1]["radvdAdvPrefixLifetime"] = util.filterXSSChars(row[1]["radvdAdvPrefixLifetime"])

    return "OK", "STATUS_OK", row[1]
end

-------------------------------------------------------------------------
-- @name gui.networking.radvdPrefix.edit.set
--
-- @description
--
-- @return
--

function gui.networking.radvdPrefix.edit.set (netName, conf, dbFlag)
    require "teamf1lualib/radvd"
    require "nimfLib"
    require "teamf1lualib/ifDev"
 
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (netName == nil) then
        return "ERROR", "RADVD_PREFIX_INVALID_PARAM"
    end
    util.appendDebugOut("Calling the radvd Prefix edit set function <br>")
    
    if(dbFlag == nil) then
        dbFlag = 1
    end

    if (conf["radvdPrefixType"] == "2") then
    -- check if the radvdAdvPrefix is a reserved address or multicast
        if (ifDevLib.isIpv6AddressReserved(conf["radvdAdvPrefix"]) > 0) then
            status = "ERROR"
            errCode = "RESERVED_IPV6_ADDRESS1"
            return status, errCode
        elseif(ifDevLib.isIpv6AddressMulticast(conf["radvdAdvPrefix"]) > 0) then
            status = "ERROR"
            errCode = "MULTICAST_IPV6_ADDRESS"
        return status, errCode
        end
    end

    -- local networkTbl = {}
    -- networkTbl = db.getRowWhere ("networkInterface", "networkName='" .. netName .. "'", false)

    local status, errCode, ifcfg = ifDev.cfgByNameGet(conf["LogicalIfName"])
    if (status == "OK") then
        conf["LogicalIfName"] = ifcfg["LogicalIfName"]
    end
    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "'"

    local status, errCode = radvdPrefix.edit(conf, dbFlag)
    if (status ~= "OK") then
        gui.dprintf("radvdPrefix.edit.set: failed to edit radvd prefix")
        return status, errCode
    end

    db.save2()

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name gui.networking.radvdPrefix.delete
--
-- @description
--
-- @return
--

function gui.networking.radvdPrefix.delete (IDList)
    require "teamf1lualib/radvd"

    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (IDList == nil) then
        return "ERROR", "RADVD_INVALID_PREFIX_ID"
    end

    local status, errCode = radvdPrefix.delete(IDList)
    if (status ~= "OK") then
        gui.dprintf("radvdPrefix.delete: failed to delete radvd prefix")
        return status, errCode
    end

    db.save2()

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name gui.networking.dhcpv6.prefix.get
--
-- @description
--
-- @return
--

function gui.networking.dhcpv6.prefix.get(netName)
    require "teamf1lualib/dhcpv6"
    local prefixes = {}

    if (netName == nil) then
        gui.dprintf("dhcpv6.prefix.get: Invalid params")
        return "ERROR","DHCPV6D_INVALID_PARAMS"
    end

    status, errCode, prefixes = dhcpv6.prefix.get()

    if (status ~= "OK") then
        gui.dprintf("dhcpv6.prefix.get: failed to get prefix configuration")
        return status, errCode
    end

    for i,v in ipairs (prefixes) do
        prefixes[i] = {}
        prefixes[i] = v
        prefixes[i].hostDuid = util.filterXSSChars(v["hostDuid"])
        prefixes[i].delegationPrefix = util.filterXSSChars(v["delegationPrefix"])
        prefixes[i].delegationPrefixLen = util.filterXSSChars(v["delegationPrefixLen"])
    end

    return status, errCode, prefixes
end

-------------------------------------------------------------------------
-- @name gui.networking.dhcpv6.prefix.add.get
--
-- @description
--
-- @return
--

function gui.networking.dhcpv6.prefix.add.get (page)
    local conf = {}
    return "OK", "STATUS_OK", conf
end

-------------------------------------------------------------------------
-- @name gui.networking.dhcpv6.prefix.add.set
--
-- @description
--
-- @return
--

function gui.networking.dhcpv6.prefix.add.set (conf)
    require "teamf1lualib/dhcpv6"
    require "teamf1lualib/radvd"
    require "nimfLib"
 require "teamf1lualib/ifDev"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
    
     -- check if the dhcpv6Prefix is a reserved address or multicast
        if (ifDevLib.isIpv6AddressReserved(conf["delegationPrefix"]) > 0) then
            status = "ERROR"
            errCode = "RESERVED_IPV6_ADDRESS1"
            return status, errCode
        elseif(ifDevLib.isIpv6AddressMulticast(conf["delegationPrefix"]) > 0) then
            status = "ERROR"
            errCode = "MULTICAST_IPV6_ADDRESS"
        return status, errCode
        end

    conf["_ROWID_"] = "-1"

    if (conf["LogicalIfName"] == nil) then
        gui.dprintf("dhcpv6.prefix.add.set: Invalid params")
        return "ERROR","DHCPV6D_INVALID_PARAMS"
    end

     local status, errCode, ifcfg = ifDev.cfgByNameGet(conf["LogicalIfName"])
     if (status == "OK") then
        conf["LogicalIfName"] = ifcfg["LogicalIfName"]
     end

    -- add DHCPv6 prefix
    local status, errCode = dhcpv6.prefix.configure(conf)
    if (status ~= "OK") then
        gui.dprintf("dhcpv6.prefix.add.set: failed to add dhcpv6 prefix")
        return status, errCode
    end

    db.save2()

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name gui.networking.dhcpv6.prefix.edit.get
--
-- @description
--
-- @return
--

function gui.networking.dhcpv6.prefix.edit.get (rowid)
    require "teamf1lualib/dhcpv6"
    local query = nil

    query = "_ROWID_=" .. rowid
    status, errCode, row = dhcpv6.prefix.get(query)
    if ((status ~= "OK") or (row == nil) or (row[1] == nil)) then
        gui.dprintf("dhcpv6.prefix.edit.get: failed to get dhcpv6 prefix")
        return "ERROR", "DHCPV6D_PREFIX_GET_FAILED"
    end

    row[1]["hostDuid"] = util.filterXSSChars(row[1]["hostDuid"])
    row[1]["delegationPrefix"] = util.filterXSSChars(row[1]["delegationPrefix"])
    row[1]["delegationPrefixLen"] = util.filterXSSChars(row[1]["delegationPrefixLen"])

    return "OK", "STATUS_OK", row[1]
end

-------------------------------------------------------------------------
-- @name gui.networking.dhcpv6.prefix.edit.set
--
-- @description
--
-- @return
--

function gui.networking.dhcpv6.prefix.edit.set (netName, conf)
    require "teamf1lualib/dhcpv6"
    require "nimfLib"
 require "teamf1lualib/ifDev"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
    
    if (netName == nil) then
        return "ERROR", "DHCPV6D_INVALID_PARAM"
    end
    util.appendDebugOut("Calling the ipv6 prefix edit set function <br>")
    
    conf["_ROWID_"] = conf["_ROWID_"]

    -- local networkTbl = {}
    -- networkTbl = db.getRowWhere ("networkInterface", "networkName='" .. netName .. "'", false)

    local status, errCode, ifcfg = ifDev.cfgByNameGet(conf["LogicalIfName"])
    if (status == "OK") then
        conf["LogicalIfName"] = ifcfg["LogicalIfName"]
    end
    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "'"

    local status, errCode, row = dhcpv6.prefix.get(query)
    if (row == nil) then
        gui.dprintf("dhcpv6.prefix.edit.set: failed to get dhcpv6 prefix")
        return "ERROR", "DHCPV6_PREFIX_GET_FAILED"
    end

    -- configure the DHCP server prefix
    local status, errCode = dhcpv6.prefix.configure(conf)
    if (status ~= "OK") then
        gui.dprintf("dhcpv6.prefix.edit.set: failed to edit dhcpv6 prefix")
        return status, errCode
    end

    db.save2()

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name gui.networking.dhcpv6.prefix.delete
--
-- @description
--
-- @return
--

function gui.networking.dhcpv6.prefix.delete (IDList)
    require "teamf1lualib/dhcpv6"
    require "teamf1lualib/radvd"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (IDList == nil) then
        return "ERROR", "DHCPV6_INVALID_PREFIX_ID"
    end

    local status, errCode = dhcpv6.prefix.delete(IDList)
    if (status ~= "OK") then
        gui.dprintf("dhcpv6.prefix.delete: failed to delete dhcpv6 prefix")
        return status, errCode
    end

    db.save2()

    return "OK", "STATUS_OK"
end
