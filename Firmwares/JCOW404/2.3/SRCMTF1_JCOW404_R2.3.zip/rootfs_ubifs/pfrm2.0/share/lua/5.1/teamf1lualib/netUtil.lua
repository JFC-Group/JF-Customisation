-- @copyright Copyright (c) 2013, TeamF1, Inc.
--
-- modification history
-- --------------------
-- 01a, 10aug13, ash added support for l2tp
--
-------------------------------------------------------------------------
-- @name gui.networking.networkTypeToZoneType
--
-- @description
--
-- @param
--
-- @return
--

function gui.networking.networkTypeToZoneType (networkType)

    if (networkType == "LAN") then
        return "secure"
    elseif (networkType == "WAN") then
        return "insecure"
    elseif (networkType == "VLANBridge") then
        return "bridge"
    else
        return networkType
    end
end

-------------------------------------------------------------------------
-- @name gui.networking.zoneTypeToNetworkType
--
-- @description
--
-- @param
--
-- @return
--

function gui.networking.zoneTypeToNetworkType (zoneType)

    if (zoneType == "insecure") then
        return "WAN"
    elseif (zoneType == "secure") then
        return "LAN"
    elseif (zoneType == "bridge") then
        return "VLANBridge"
    else
        return zoneType
    end
end

-------------------------------------------------------------------------
-- @name gui.networking.checkValidIPv4Addr
--
-- @description This routine check if an IPv4 address is valid.
--
-- @param ipaddr ipv4 address
--
-- @return nil if invalid else 1
--

function gui.networking.checkValidIPv4Addr (ipaddr)
    require "nimfLib"

    if (ipaddr == nil) then
        return nil
    end

    if (string.len(ipaddr) == 0) then
        return nil
    end

    if (ipaddr == "0.0.0.0") then
        return nil
    end

    if (nimfLib.ipv4AddrCheck(ipaddr) ~= 1) then
        return nil
    end

    return 1
end

-------------------------------------------------------------------------
-- @name gui.networking.getConnType
--
-- @description This routine gets the connection type from the GUI
-- configuration
--
-- @param conf
--
-- @return connType or nil
--

function gui.networking.getConnType (conf)
    local connType = nil

    if (tonumber(conf["requireLogin"]) == 0) then

        if (tonumber(conf["GetIpFromIsp"]) == 1) then
            if (conf["AddressFamily"] == "ipv4") then
                connType = "dhcpc"
            else
                connType = "dhcp6c"
            end
        elseif (tonumber(conf["GetIpFromIsp"]) == 0) then
            if (conf["AddressFamily"] == "ipv4") then
                connType = "ifStatic"
            else
                connType = "ifStatic6"
            end
        else
            gui.dprintf("getConnType: Invalid connection Type")
            return nil
        end

    elseif (tonumber(conf["requireLogin"]) == 1) then

        if (tonumber(conf["ConnectionType"]) == 2) then
            connType = "pppoe"
        elseif (tonumber(conf["ConnectionType"]) == 3) then
            connType = "pptp"
        elseif (tonumber(conf["ConnectionType"]) == 4) then
            connType = "l2tp"
        elseif (tonumber(conf["ConnectionType"]) == 5) then
            connType = "lte"            
        else
            gui.dprintf("getConnType: Invalid connection Type")
            return nil
        end
    else
        gui.dprintf("getConnType: Incorrect value for requireLogin")
        return nil
    end

    return connType
end

-------------------------------------------------------------------------
-- @name gui.networking.connUpTimeGet
--
-- @description
--
-- @param name
-- @param conf
--
-- @return
--

function gui.networking.connUpTimeGet(connstatus)
    local upTime = "N/A"

    if (connstatus["State"] == "NIMF_CONN_STATE_CONNECTED") then
        upTime = connstatus["Uptime"]
    end

    return upTime
end

-------------------------------------------------------------------------
-- @name gui.networking.connStateStrGet
--
-- @description
--
-- @param name
-- @param conf
--
-- @return
--

function gui.networking.connStateStrGet(connstatus)
    local status

    if (connstatus["State"] == "NIMF_CONN_STATE_CONNECTED") then
        status = "CONNECTED"
    elseif (connstatus["State"] == "NIMF_CONN_STATE_INIT") then
        status = "INITIALIZING"
    elseif (connstatus["State"] == "NIMF_CONN_STATE_SETUP") then
        status = "SETTING UP CONNECTION"
    elseif (connstatus["State"] == "NIMF_CONN_STATE_TEARDOWN") then
        status = "SHUTTING DOWN CONNECTION"
    elseif (connstatus["State"] == "NIMF_CONN_STATE_STOPPED") then
        status = "CONNECTION STOPPED"
    elseif (connstatus["State"] == "NIMF_CONN_STATE_STANDBY") then
        status = "NETWORK NOT READY"
    elseif (connstatus["State"] == "NIMF_CONN_STATE_WAIT") then
        status = "WAITING FOR NETWORK/USER COMMAND"
    elseif (connstatus["State"] == "NIMF_CONN_STATE_IDLE") then
        status = "CONNECTION IDLE"
    elseif (connstatus["State"] == "NIMF_CONN_STATE_FAIL") then
        status = "CONNECTION FAILED"
    else
        status = "N/A"
    end

    return status
end

-------------------------------------------------------------------------
-- @name gui.networking.connConfGet
--
-- @description
--
-- @param name
--
-- @return status
-- @return errCode
-- @return conf
--

function gui.networking.connConfGet(connID, conf)
    require "teamf1lualib/nimf"
    require "teamf1lualib/nimfConn"
    local nimfConf = {}

    status, errCode, nimfConf = nimfConn.confGet (connID)
    if (nimfConf == nil) then
        gui.dprintf("connection get failed for:" .. util.tableToStringRec(connID))
        return "ERROR","NET_ERR_CONF_GET"
    end

    conf["ConnectionType"] = nimfConf["ConnectionType"]
    conf["mtuType"] = nimfConf["mtuType"]
    conf["mtuSize"] = nimfConf["Mtu"]
    conf["Enable"] = nimfConf["Enable"]
    conf["subConnectionType"] = nimfConf["subConnectionType"]
    conf["StatelessMode"] = nimfConf["StatelessMode"]


    if (conf["ConnectionType"] == "ifStatic") then
        conf["GetIpFromIsp"] = "0"
        conf["requireLogin"] = "0"
        conf["GetDnsFromIsp"] = "0"
        conf["StaticIp"] = nimfConf["StaticIp"]
        conf["Gateway"] = nimfConf["Gateway"]
        conf["NetMask"] = nimfConf["NetMask"]
        conf["PrimaryDns"] = nimfConf["PrimaryDns"]
        conf["SecondaryDns"] = nimfConf["SecondaryDns"]
    elseif(conf["ConnectionType"] == "ifStatic6") then
        conf["GetIpFromIsp"] = "0"
        conf["requireLogin"] = "0"
        conf["GetDnsFromIsp"] = "0"
        conf["StaticIp"] = nimfConf["StaticIp"]
        conf["Gateway"] = nimfConf["Gateway"]
        conf["PrefixLength"] = nimfConf["PrefixLength"]
        conf["PrimaryDns"] = nimfConf["PrimaryDns"]
        conf["SecondaryDns"] = nimfConf["SecondaryDns"]
    elseif(conf["ConnectionType"] == "dhcp6c") then
        conf["StatelessMode"] = "0"
        conf["maptParams"] = "1"
--        conf["prefixDelegation"] = "0"
	conf["prefixDelegation"] = nimfConf["prefixDelegation"]
    elseif(conf["ConnectionType"] == "dhcp6c-stateless") then
        conf["StatelessMode"] = "1"
        conf["maptParams"] = "1"
        conf["prefixDelegation"] = nimfConf["prefixDelegation"]
    elseif(conf["ConnectionType"] == "ipv6-auto") then
        conf["GetDnsFromIsp"] = nimfConf["GetDnsFromIsp"]
        if (tonumber(nimfConf["GetDnsFromIsp"]) > 0) then
            conf["useDNS"] = "0"
        else
            conf["useDNS"] = "1"
        end
        conf["PrimaryDns"] = nimfConf["PrimaryDns"]
        conf["SecondaryDns"] = nimfConf["SecondaryDns"]
    elseif(conf["ConnectionType"] == "dhcpc") then
        conf["requireLogin"] = "0"
        conf["PrimaryDns"] = nimfConf["PrimaryDns"]
        conf["SecondaryDns"] = nimfConf["SecondaryDns"]
    elseif(conf["ConnectionType"] == "pppoe") then
        conf["requireLogin"] = "1"
        conf["IdleDisconnectTime"] = nimfConf["IdleDisconnectTime"]
        conf["IdleDisconnect"] = nimfConf["IdleDisconnect"]
        conf["Username"] = nimfConf["UserName"]
        conf["ServiceName"] = nimfConf["ServiceName"]
        conf["AccountName"] = nimfConf["AccountName"]
        conf["Password"] = nimfConf["Password"]
        conf["AuthOpt"] = nimfConf["AuthOpt"]
        conf["mtuSize"] = nimfConf["Mtu"]
        if ((conf["mtuSize"] == "") or (conf["mtuSize"] == "1492")) then
            conf["mtuType"] = "1" -- Default MTU
        else
            conf["mtuType"] = "0" -- custom MTU
        end
        conf["GetDnsFromIsp"] = nimfConf["GetDnsFromIsp"]
        conf["PrimaryDns"] = nimfConf["PrimaryDns"]
        conf["SecondaryDns"] = nimfConf["SecondaryDns"]
        if (UNIT_INFO == "ODU") then
            -- If APN is '0.0.0.0' Then its a MAGIC_APN
            -- return it as nil
            if (nimfConf["APN"] ~= "0.0.0.0") then
                conf["APN"] = nimfConf["APN"]            
            end
        end
    elseif(conf["ConnectionType"] == "pptp") then
        conf["requireLogin"] = "1"
        conf["IdleDisconnectTime"] = nimfConf["IdleDisconnectTime"]
        conf["IdleDisconnect"] = nimfConf["IdleDisconnect"]
        conf["Username"] = nimfConf["UserName"]
        conf["UserName"] = nimfConf["UserName"]
        conf["Password"] = nimfConf["Password"]
        conf["AuthOpt"] = nimfConf["AuthOpt"]
        conf["AccountName"] = nimfConf["AccountName"]
        conf["DomainName"] = nimfConf["DomainName"]
        conf["MyIPAddress"] = nimfConf["MyIPAddress"]
        conf["ServerIp"] = nimfConf["ServerIp"]
        conf["mtuSize"] = nimfConf["Mtu"]
        conf["mppe"] = nimfConf["MppeEncryptSupport"]
        if ((conf["mtuSize"] == nil) or (conf["mtuSize"] == "1492")) then
            conf["mtuType"] = "1" -- Default MTU
        else
            conf["mtuType"] = "0" -- custom MTU
        end
        conf["GetDnsFromIsp"] = nimfConf["GetDnsFromIsp"]
        conf["PrimaryDns"] = nimfConf["PrimaryDns"]
        conf["SecondaryDns"] = nimfConf["SecondaryDns"]
        if (UNIT_INFO == "ODU") then
            -- If APN is '0.0.0.0' Then its a MAGIC_APN
            -- return it as nil
            if (nimfConf["APN"] ~= "0.0.0.0") then
                conf["APN"] = nimfConf["APN"]            
            end
        end        
    elseif(conf["ConnectionType"] == "l2tp") then
        conf["requireLogin"] = "1"
        conf["IdleDisconnectTime"] = nimfConf["IdleDisconnectTime"]
        conf["IdleDisconnect"] = nimfConf["IdleDisconnect"]
        conf["Username"] = nimfConf["UserName"]
        conf["UserName"] = nimfConf["UserName"]
        conf["Password"] = nimfConf["Password"]
        conf["AuthOpt"] = nimfConf["AuthOpt"]
        conf["AccountName"] = nimfConf["AccountName"]
        conf["DomainName"] = nimfConf["DomainName"]
        conf["MyIPAddress"] = nimfConf["MyIPAddress"]
        conf["ServerIp"] = nimfConf["ServerIp"]
        conf["mtuSize"] = nimfConf["Mtu"]
        conf["Secret"] = nimfConf["Secret"]
        if ((conf["mtuSize"] == nil) or (conf["mtuSize"] == "1492")) then
            conf["mtuType"] = "1" -- Default MTU
        else
            conf["mtuType"] = "0" -- custom MTU
        end
        conf["GetDnsFromIsp"] = nimfConf["GetDnsFromIsp"]
        conf["PrimaryDns"] = nimfConf["PrimaryDns"]
        conf["SecondaryDns"] = nimfConf["SecondaryDns"]
        if (UNIT_INFO == "ODU") then
            -- If APN is '0.0.0.0' Then its a MAGIC_APN
            -- return it as nil
            if (nimfConf["APN"] ~= "0.0.0.0") then
                conf["APN"] = nimfConf["APN"]            
            end
        end
    elseif (conf["ConnectionType"] == "lte") then
        
        if (nimfConf["subConnectionType"] == "1") then
            conf["GetIpFromIsp"] = "0"
            conf["requireLogin"] = "0"
            conf["GetDnsFromIsp"] = "0"
            conf["StaticIp"] = nimfConf["StaticIp"]
            conf["Gateway"] = nimfConf["Gateway"]
            conf["NetMask"] = nimfConf["NetMask"]
            conf["PrimaryDns"] = nimfConf["PrimaryDns"]
            conf["SecondaryDns"] = nimfConf["SecondaryDns"]            
            -- If APN is '0.0.0.0' Then its a MAGIC_APN
            -- return it as nil
            if (nimfConf["APN"] ~= "0.0.0.0") then
                conf["APN"] = nimfConf["APN"]            
            end
            
            conf["subConnectionType"] = nimfConf["subConnectionType"]            
        else
            conf["StaticIp"] = "0.0.0.0"
            conf["Gateway"] = "0.0.0.0"
            conf["NetMask"] = "0.0.0.0"            
            conf["requireLogin"] = "0"
            conf["PrimaryDns"] = nimfConf["PrimaryDns"]
            conf["SecondaryDns"] = nimfConf["SecondaryDns"]
            -- If APN is '0.0.0.0' Then its a MAGIC_APN
            -- return it as nil
            if (nimfConf["APN"] ~= "0.0.0.0") then
                conf["APN"] = nimfConf["APN"]            
            end
            conf["subConnectionType"] = nimfConf["subConnectionType"]            
        end  


    elseif (conf["ConnectionType"] == "lte6") then

        if(conf["subConnectionType"] == "1") then
            conf["GetIpFromIsp"] = "0"
            conf["requireLogin"] = "0"
            conf["GetDnsFromIsp"] = "0"
            conf["StaticIp"] = nimfConf["StaticIp"]
            conf["Gateway"] = nimfConf["Gateway"]
            conf["PrefixLength"] = nimfConf["PrefixLength"]
            --nimfConf["PrefixLength"]
            conf["PrimaryDns"] = nimfConf["PrimaryDns"]
            conf["SecondaryDns"] = nimfConf["SecondaryDns"]
            if (nimfConf["APN"] ~= "0.0.0.0") then
                conf["APN"] = nimfConf["APN"]
            end

         elseif(conf["subConnectionType"] == "0") then
            
            if (conf["StatelessMode"] == "1" ) then
                conf["subConnectionType"] = "dhcp6c-stateless"
            else
               if(conf["StatelessMode"] == "0" ) then
                 conf["subConnectionType"] = "dhcp6c"
               else
                 conf["subConnectionType"] = "ipv6-auto"
               end
            end

            if(conf["subConnectionType"] == "dhcp6c") then
                   conf["StatelessMode"] = "0"
                   conf["maptParams"] = "1"
--                   conf["prefixDelegation"] = "0"
		   conf["prefixDelegation"] = nimfConf["prefixDelegation"]
                  if (nimfConf["APN"] ~= "0.0.0.0") then
                      conf["APN"] = nimfConf["APN"]
                  end

            elseif(conf["subConnectionType"] == "dhcp6c-stateless") then
                   conf["StatelessMode"] = "1"
                   conf["maptParams"] = "1"
                   conf["prefixDelegation"] = nimfConf["prefixDelegation"]
                   if (nimfConf["APN"] ~= "0.0.0.0") then
                       conf["APN"] = nimfConf["APN"]
                   end

             elseif(conf["subConnectionType"] == "ipv6-auto") then
                    conf["GetDnsFromIsp"] = nimfConf["GetDnsFromIsp"]
                    conf["PrimaryDns"] = nimfConf["PrimaryDns"]
                    conf["SecondaryDns"] = nimfConf["SecondaryDns"]
                     if (nimfConf["APN"] ~= "0.0.0.0") then
                       conf["APN"] = nimfConf["APN"]
                   end

             else
                     gui.dprintf("connection type not supported: " .. conf["ConnectionType"])
                     return "ERROR", "NET_ERR_CONNECTION_TYPE"
             end
        
          else
             gui.dprintf("connection type not supported: " .. conf["ConnectionType"])
             return "ERROR", "NET_ERR_CONNECTION_TYPE"
         end
      
    else
        gui.dprintf("connection type not supported: " .. conf["ConnectionType"])
        return "ERROR", "NET_ERR_CONNECTION_TYPE"
    end

    return "OK","STATUS_OK", conf
end

-------------------------------------------------------------------------
-- @name gui.networking.pppAuthOptGet
--
-- @description
--
-- @param authOpt
--
-- @return
--

function gui.networking.pppAuthOptGet (authOpt)
    if (tonumber(authOpt) == nimfConn.NIMF_PPPOE_AUTO_NEG) then
        authOpt = "1"
    end

    return authOpt
end

-------------------------------------------------------------------------
-- @name gui.networking.defIpv4Conf
--
-- @description
--
--
-- @return
--

function gui.networking.defIpv4Conf(connID, zoneType)
    require "teamf1lualib/nimf"
    require "teamf1lualib/nimfConn"
    local conf = {}
    local status
    local errCode

    if (platformLib.strcasecmp(zoneType, "secure") == 0) then
        connID["ConnectionType"] = "ifStatic"
    else
        connID["ConnectionType"] = "dhcpc"
    end

    status, errCode, conf = nimfConn.defConfGet(connID)
    if (status ~= "OK") then
        gui.dprintf("networking.defIpv4Conf: failed to get " ..
                   "default configuration for " .. connID["ConnectionType"])
    end

    return conf
end

-------------------------------------------------------------------------
-- @name gui.networking.defIpv6Conf
--
-- @description
--
--
-- @return
--

function gui.networking.defIpv6Conf(connID, zoneType)
    require "teamf1lualib/nimf"
    local conf = {}
    local status
    local errCode

    if (platformLib.strcasecmp(zoneType, "secure") == 0) then
       connID["ConnectionType"] = "ifStatic6"
    else
       connID["ConnectionType"] = "ipv6-auto"
    end

    status, errCode, conf = nimfConn.defConfGet(connID)
    if (status ~= "OK") then
       gui.dprintf("networking.defIpv6Conf: failed to get " ..
                   "default configuration for " .. connID["ConnectionType"])
    end

    return conf
end

-------------------------------------------------------------------------
-- @name gui.networking.lanIpValidation
--
-- @description - checks if lan ip falls in dhcp server pool 
--
--
-- @return
--

function gui.networking.lanIpValidation (ip1, ip2, ip3)

	local a1 = util.split(ip1,".")
	local b1 = util.split(ip2,".")
	local c1 = util.split(ip3,".")

	if (ip1 == ip2) or (ip1 == ip3) then
		return 1
	end

	for i = 1,4 do

		a2=tonumber(a1[i])
		b2=tonumber(b1[i])
		c2=tonumber(c1[i])

		if (b2 < a2) and (c2 > a2) then
			return 1
		elseif (b2 > a2) or (c2 < a2) then
			return 0
		end
	end

	return 0	

end


-------------------------------------------------------------------------
-- @name gui.networking.reserveIpValidation
--
-- @description
--
--
-- @return
--

function gui.networking.reserveIpValidation(conf)

    local status = "ERROR"
    local errCode = ""
    local ipAddressTbl = {}
    local dhcpClientTbl = {}

    status, errCode, dhcpClientTbl = gui.networking.ipv4DhcpConfGet(conf)
    if (status == "ERROR") then
   gui.dprintf("gui.networking.ipv4DhcpConfGet: Returned Error")
        return status, errCode
    end

    ipAddressTbl = db.getRows ("ipAddressTable", "LogicalIfName", conf["LogicalIfName"])
    status = "ERROR"
    for i,v in pairs (ipAddressTbl) do
        if (v["ipAddressTable.addressFamily"] == "2") then
            local tmp1 = util.split (v["ipAddressTable.ipAddress"], ".")
            local tmp2 = util.split (conf["startAddr"], ".")
            if ((tonumber(tmp1[1]) == tonumber(tmp2[1])) and (tonumber(tmp1[2]) == tonumber(tmp2[2])) and (tonumber(tmp1[3]) == tonumber(tmp2[3])) and (tonumber(tmp1[4]) == tonumber(tmp2[4]))) then
                return status, "RESERVED_DEVICE_IP"
            end
        end
    end

    --[[ UnComment this section to have Range validation for DHCP reserved IP
    --Address configuration.
    --
    local poolId = db.getAttribute ("DhcpServerPools", "LogicalIfName", conf["LogicalIfName"], "PoolID")
    require "dhcpLib"
    local value = dhcpLib.dhcpdIpValidate(dhcpClientTbl["dhcpStartIP"], dhcpClientTbl["dhcpStopIP"],
                                  poolId, dhcpClientTbl["LogicalIfName"], conf["startAddr"])
    if (value == 0) then
   gui.dprintf("gui.networking.reserveIpValidation: Address in Range")
  return "ERROR","IP_ADDRESS_IN_RANGE"
 end
    ]]--

    status = "OK"
    errCode = "STATUS_OK"

    return status, errCode

end
-------------------------------------------------------------------------
-- @name gui.networking.ipAddressSubnetValidation
--
-- @description
--
-- @return
--

function gui.networking.ipAddressSubnetValidation(logicalIfName, ipAddr)

    require "teamf1lualib/firewall"

    local status = "ERROR"
    local errCode = ""
    local subnet = ""

    status, errCode, subnet = firewall.getNetMask (logicalIfName, ipAddr)

    -- returning the status
    return status, errCode

end

-------------------------------------------------------------------------------
-- @name gui.networking.hiddenValuesGet ()
--
-- @description
--
-- @return
--

function gui.networking.hiddenValuesGet ()

    -- Getting the required hidden fields for all the networks.

    local cfgTbl = {}
    local confTmp = {}
    local query2 = "networkInterface:ifStatic:LogicalIfName"
    cfgTbl = db.getTableWithJoin ({query2})
    local lanTbl = {}
    local wanTbl = {}
    local dmzTable = {}
    local dmzTbl = {}

    for i,v in pairs (cfgTbl) do
        if ((v["networkInterface.zoneType"] == "secure") and (v["ifStatic.AddressFamily"] == "2")) then
            lanTbl[i] = {}
            lanTbl[i]["hdLanIp"] = v["ifStatic.StaticIp"]
            lanTbl[i]["hdLanSnet"] = v["ifStatic.NetMask"]
            lanTbl[i]["hdLanIfName"] = v["networkInterface.networkName"]
        end
        if ((v["networkInterface.zoneType"] == "insecure") and (v["ifStatic.AddressFamily"] == "2")) then
            wanTbl[i] = {}
            wanTbl[i]["hdWanIp"] = v["ifStatic.StaticIp"]
            wanTbl[i]["hdWanSnet"] = v["ifStatic.NetMask"]
            wanTbl[i]["hdWanIfName"] = v["networkInterface.networkName"]
        end
    end

    require "teamf1lualib/firewall"
    local query1 = "_ROWID_=1"
    dmzTable = db.getRowWhere("dmz",query1, false)
    if (dmzTable ~= nil) then
        dmzTbl["hdDmzIfName"] = db.getAttribute("networkInterface","LogicalIfName",dmzTable["LogicalIfName"],"networkName")
        if (dmzTable.ipAddr ~= nil) then
            dmzTbl["hdDmzIp"] = dmzTable.ipAddr or ""
            status, errCode,dmzTbl["hdDmzSnet"] = firewall.getNetMask(dmzTable["LogicalIfName"], dmzTable.ipAddr)
        end
    end

    confTmp.lanTbl = lanTbl
    confTmp.wanTbl = wanTbl
    confTmp.dmzTbl = dmzTbl

    return confTmp
end
-------------------------------------------------------------------------------
-- @name gui.networking.portSwap ()
--
-- @description
--
-- @return
--

function gui.networking.portSwap (inputTable)

 for i,v in pairs (inputTable) do
        if (v["LogicalIfName"] ~= nil) then
            v["LogicalIfName"] = v["LogicalIfName"]
        end
        if (v["ifname"] ~= nil) then
            v["ifname"] = v["ifname"]
        end
        if (v["type"] ~= nil) then
            v["type"] = v["type"]
        end
        if (v["name"] ~= nil) then
            v["name"] = v["name"]
        end
        if (v["default"] ~= nil) then
            v["default"] = v["default"]
        end

        if (tonumber(v["port"]) == 1) then
            v["port"] = "4"
        elseif (tonumber(v["port"]) == 2) then
            v["port"] = "3"
        elseif (tonumber(v["port"]) == 3) then
            v["port"] = "2"
        elseif (tonumber(v["port"]) == 4) then
            v["port"] = "1"
        elseif (tonumber(v["port"]) == 5) then
            v["port"] = "5"
        end

    end

    return inputTable
end

-------------------------------------------------------------------------------
-- @name gui.networking.rangeCheck ()
--
-- @description
--
-- @return
--

function gui.networking.rangeCheck (portStart, portEnd, portConf)

    local testPort
    if ((tonumber(portConf) == tonumber(portStart)) or (tonumber(portConf) == tonumber(portEnd))) then
        return "ERROR", "PORT_IN_RANGE"
    else
        if (tonumber(portStart) ~= tonumber(portEnd)) then
            if (tonumber(portConf) >= tonumber(portStart) and tonumber(portConf) <= tonumber(portEnd)) then
                return "ERROR", "PORT_IN_RANGE"
            end
        end
    end

    return "OK", "STATUS_OK"

end

-------------------------------------------------------------------------------
-- @name gui.networking.remoteMgmtportCheck ()
--
-- @description
--
-- @return
--
function gui.networking.remoteMgmtportCheck (port)

    require "teamf1lualib/httpsMgmt"
    local accessMgmtTbl = httpsMgmt.accessMgmtGet ()
    for i,v in pairs (accessMgmtTbl) do
        if (tonumber(port) == tonumber(v["port"])) then
            return "ERROR", "PORT_IN_USE_BY_HTTPS"
        end
    end

    return "OK", "STATUS_OK"
end
