-- @copyright Copyright (c) 2012, TeamF1, Inc. 

require "teamf1lualib/evtDsptch"
require "dhcpLib"
require "appExtn/AppExtn"

Dhcpv6sExtn = OoUtil.inheritsFrom(AppExtn)
Dhcpv6sExtn.name    = "IPv6 DHCP Server"
Dhcpv6sExtn.className = "Dhcpv6sExtn"
Dhcpv6sExtn.classId = "dhcpv6s"
Dhcpv6sExtn.dbTable = "dhcpv6s"
Dhcpv6sExtn.logger  = nil

local SUPER = require("appExtn.AppExtn")

local netEvents  = {}
netEvents[evtDsptch.event.IFDEV_EVENT_IP6_NET_UP] =  1
netEvents[evtDsptch.event.IFDEV_EVENT_IP6_NET_DOWN] =  1

local cfgEvents = {}
cfgEvents[db.event.SQLITE_INSERT] = 1
cfgEvents[db.event.SQLITE_UPDATE] = 1
cfgEvents[db.event.SQLITE_DELETE] = 1

-------------------------------------------------------------------------------
-- @name Dhcpv6sExtn:new
--
-- @description This function creates a new instance object for dhcpv6s 
--
-- @return  
--

function Dhcpv6sExtn:new(instanceId, props)

    assert(instanceId, "Instance ID must be specified")

    -- create a new instance
    self = Dhcpv6sExtn.create()

    SUPER.new(self, Dhcpv6sExtn.classId, instanceId, props)

    self.name  = Dhcpv6sExtn.name
    self.dbTable = Dhcpv6sExtn.dbTable
    self.dbconn = Dhcpv6sExtn.dbconn
    self.logger = Dhcpv6sExtn.logger

    -- initialize events for this instance
    self.netEvents = netEvents              
    self.cfgEvents = cfgEvents

    -- interfaces on which dhcpv6 is configured 
    self.ifTbl = {}
    
    -- 
    -- onCreate hook to initialize the backend
    -- for this instance of the application
    -- TODO: pass instanceId
    --
    local handle = db.gethandle(self.dbconn)
    dhcpLib.init(handle)

    -- Load DHCPv6 configuration
    if (self:load() < 0) then
        return nil
    end        

    -- register with appd
    appd.appExtnRegister(self)                    

    return self
end

-------------------------------------------------------------------------------
-- @name Dhcpv6sExtn:delete
--
-- @description This function deletes an instance of this extension
--
-- @return  
--

function Dhcpv6sExtn:delete() 
    appd.appExtnUnregister(self)
    return 
end        

-------------------------------------------------------------------------------
-- @name Dhcpv6sExtn:cfgFileWrite
--
-- @description This function re-writes the configuration file
--
-- @return  0 for success and -1 for error
--

function Dhcpv6sExtn:cfgFileWrite ()

    LOG:info("Re-writing configuration for " .. self.name ..  
             "(" ..  self.instanceId .. ")")

    local status = dhcpLib.v6CfgWrite()
    if (status < 0) then
        LOG:error(self.name .. " configuration re-write failed.")
        return status
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name Dhcpv6sIfacePoolsGet
--
-- @description This function gets all the IPv6 pools of this interface
--
-- @return  0 for success and -1 for error
--

local function Dhcpv6sIfacePoolsGet (LogicalIfName, poolTbl)
    local ifPools = {}

    for index, pool in pairs(poolTbl) do
        if (strlib.strcasecmp(pool.LogicalIfName, LogicalIfName) == 0) then
            table.insert(ifPools, pool)        
        end            
    end        

    return ifPools
end

-------------------------------------------------------------------------------
-- @name Dhcpv6sExtn:isEnabled
--
-- @description 
--
-- @return  0 for success and -1 for error
--

function Dhcpv6sExtn:isEnabled ()
    local ifTbl = self.ifTbl

    for index, ifcfg in pairs(ifTbl) do
        if (tonumber(ifcfg.isEnabled) > 0) then
            return true
        end            
    end        

    return false
end

-------------------------------------------------------------------------------
-- @name Dhcpv6sExtn:load
--
-- @description 
--
-- @return  0 for success and -1 for error
--

function Dhcpv6sExtn:load ()
    local ifTbl = {}  -- list of all DHCPv6 configured interfaces
    local poolTbl = {} -- list of all DHCPv6 pools 

    ifTbl = db.getTable("dhcpv6s", false)
    if (ifTbl == nil) then
        return -1        
    end        

    poolTbl = db.getTable("dhcpv6sLANAddrPool", false)
    if (poolTbl == nil) then
        return -1        
    end        

    for index, ifcfg in pairs (ifTbl) do
        ifcfg.pools = Dhcpv6sIfacePoolsGet(ifcfg.LogicalIfName, poolTbl)
        table.insert(self.ifTbl, ifcfg)
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name Dhcpv6sExtn:isDhcpv6sIfUp 
--
-- @description This function checks if IPv6 connection is UP on any of the
-- DHCPv6 enabled interfaces
--
-- @return  0 for success and -1 for error
--

function Dhcpv6sExtn:isDhcpv6sIfUp()
    require "teamf1lualib/nimf"
    local ifTbl = self.ifTbl

    for index, ifcfg in pairs(ifTbl) do
        if (nimfConn.isIPv6Up(ifcfg.LogicalIfName)) then
            return true
        end            
    end        

    return false
end

-------------------------------------------------------------------------------
-- @name Dhcpv6sExtn:start
--
-- @description This function re-writes the configuration file and 
-- restarts dhcpv6 server.
--
-- @return  0 for success and -1 for error
--

function Dhcpv6sExtn:start ()

    -- is configuration enabled
    if (not self:isEnabled()) then
        return 0
    end        

    -- is IPv6 network Up on dhcpv6 enabled interfaces
    if (not self:isDhcpv6sIfUp()) then
        LOG:debug("IPv6 network is not up for DHCPv6 server enabled interfaces")
        -- TODO: stop dhcpv6 server if it is running
        return 0
    end        

    -- write configuration
    local status = self:cfgFileWrite()
    if (status < 0) then
        return status
    end        
    
    -- start
    LOG:info("Starting " .. self.name ..  "(" ..  self.instanceId .. ")")
    local status = dhcpLib.v6Restart()
    if (status < 0) then
        LOG:error(self.name .. " start failed")
        return status
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name Dhcpv6sExtn:stop
--
-- @description This function stops dhcpv6 server.
--
-- @return  0 for success and -1 for error
--

function Dhcpv6sExtn:stop ()

    -- stop
    LOG:info("Stoping " .. self.name ..  "(" ..  self.instanceId .. ")")
    local status = dhcpLib.v6Stop()
    if (status < 0) then
        LOG:error(self.name .. " stop failed")
        return status
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name Dhcpv6sExtn:restart
--
-- @description This function re-writes the configuration file and 
-- restarts dhcpv6 server.
--
-- @return  0 for success and -1 for error
--

function Dhcpv6sExtn:restart ()

    local status = self:start()
    if (status < 0) then
        return -1
    end        
    
    return 0
end

-------------------------------------------------------------------------------
-- @name Dhcpv6sExtn:getAppName
--
-- @description This function gets the name of this extension
--
-- @return  
--

function Dhcpv6sExtn:getAppName()
   return self.name
end

-------------------------------------------------------------------------------
-- @name Dhcpv6sExtn:onNetEvent
--
-- @description This function handles network events for dhcpv6s
--
-- @param  netevent event info
--
-- @return  0 for success and -1 for error
--

function Dhcpv6sExtn:onNetEvent(netevent)

    if (self:isEventSubscribed(netevent) == false) then
        LOG:ddebug(self.classId .. " not subscribed to event: " ..
                  netevent.event .. " on " .. netevent.ifname)
        return 0
    end        

    self:restart()

    return 0
end

-------------------------------------------------------------------------------
-- @name Dhcpv6sExtn:isEventSubscribed
--
-- @description This function checks if the application is subcribed to
-- the event 
--
-- @param event event info
--
-- @return  0 for success and -1 for error
--

function Dhcpv6sExtn:isEventSubscribed(event)

    if (event.type == appd.eventType.APPD_EV_NET) then

        local evstate = self.netEvents[event.event]
        if (evstate == nil) then
            return false
        end            
                    
        if (evstate > 0) then
            return true
        end        

    elseif (event.type == appd.eventType.APPD_EV_CFG) then

        -- are we subscribed to this event                        
        local evstate = self.cfgEvents[event.event]
        if (evstate == nil) then
            return false
        end            

        if (evstate > 0) then
            return true
        end        
    end

    return false
end

-------------------------------------------------------------------------------
-- @name Dhcpv6sExtn:onCfgEvent
--
-- @description This function is called to handle configuration events
-- 
-- @param  cfgevent event information
--
-- @return  
--

function Dhcpv6sExtn:onCfgEvent(cfgevent)

    if (self:isEventSubscribed(cfgevent) == false) then
        LOG:ddebug(self.classId .. " not subscribed to event: " ..
                  cfgevent.event .. " on " .. cfgevent.dbTable)
        return
    end        

    -- load the configuration for the instance
    if (self:load() < 0) then
        return nil
    end        

    -- restart dhcpv6s
    self:restart()

    return
end

-------------------------------------------------------------------------------
-- @name Dhcpv6sExtn:print
--
-- @description This function is called by appd to bootstrap all instances of 
-- this application. 
--
-- @param  
--
-- @return  
--

function Dhcpv6sExtn:print()
    require "util/strlib"

    LOG:info("Class     : " .. self.classId)
    LOG:info("Instance  : " .. self.instanceId)
    LOG:info("App Name  : " .. self:getAppName())

    return
end

-------------------------------------------------------------------------------
-- @name Dhcpv6sExtn.cfgEventCallback
--
-- @description 
--
-- @return  
--

function Dhcpv6sExtn.cfgEventCallback(obj, info)

    LOG:ddebug(Dhcpv6sExtn.classId .. " configuration callback called  " .. 
              "for event: " ..  info.event .. " on rowId " .. info.rowId)

    obj:onCfgEvent(info) 

    return 0
end

-------------------------------------------------------------------------------
-- @name Dhcpv6sExtn.bootstrap
--
-- @description This function is called by appd on startup to bootstrap all 
-- instances of this application. 
--
-- @param  
--
-- @return  
--

function Dhcpv6sExtn.bootstrap()
    local instanceId="1"
    local callbackTable= {}

    local callback = {}
    callback.type = appd.eventType.APPD_EV_CFG
    callback.routine = Dhcpv6sExtn.cfgEventCallback
    callback.dbTable = "dhcpv6s"
    table.insert(callbackTable, callback)

    local callback = {}
    callback.type = appd.eventType.APPD_EV_CFG
    callback.routine = DhcpdExtn.cfgEventCallback
    callback.dbTable = "dhcpv6sLANAddrPool"
    table.insert(callbackTable, callback)

    appd.callbackRegister (Dhcpv6sExtn.classId, callbackTable)

    -- create an instance and restart it
    local obj = Dhcpv6sExtn:new(instanceId)
    if (obj) then
        obj:start()
    end                        

    return 0
end

return Dhcpv6sExtn
