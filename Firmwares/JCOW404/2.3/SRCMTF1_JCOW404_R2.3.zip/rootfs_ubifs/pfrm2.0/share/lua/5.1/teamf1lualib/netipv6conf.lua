-- Copyright (c) 2017, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]

--[[
#### modification history
--------------------
01d,09Jul18,swr  changes for SPR 64269(Missing TR params)
01c,07Feb18,sjr  changes for spr 63160
01b,23Nov17,swr  changes for spr 62635(XSS vulnerability) and 61441
01a,08Sep17,swr  Changes for SPR 62295
]]--

require "teamf1lualib/netipv6dhcp"

-------------------------------------------------------------------------
-- @name gui.networking.network.ipv6.get
--
-- @descrription This routine gets the connection configuration of this network
--
-- @param name network name
--
-- @return status
-- @return errCode
-- @return conf
--
function gui.networking.network.ipv6.get (name)
    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"
    local connID = {}
    local conf = {}
    local confTmp = {}
    local networkConf = {}

    require "teamf1lualib/network"
    status, errCode, networkConf = network.ifConfGet(name)
    if (status ~= "OK") then
        gui.dprintf("ipv6.get: failed to get network configuration for " .. name)
        return status, errCode
    end

    require "teamf1lualib/nimf"
    conf["networkName"] = networkConf["networkName"]
    conf["LogicalIfName"] = networkConf["LogicalIfName"]
    conf["networkType"] = gui.networking.zoneTypeToNetworkType (networkConf["zoneType"])
    conf["vlanId"] = networkConf["networkId"]
    conf["AddressFamily"] = "ipv6"

    connID["LogicalIfName"] = networkConf["LogicalIfName"]
    connID["AddressFamily"] = nimf.proto.NIMF_PROTO_TYPE_IPV6
    status, errCode, confTmp = gui.networking.connConfGet(connID, conf)
    if (status ~= "OK") then
        gui.dprintf("ipv6.get: failed to get ipv6 connection information " .. name)
        -- Do not return because just after creating the network. You may not
        -- have the connection params.
    else
        conf = confTmp
    end

    if(not(util.fileExists ("/pfrm2.0/HW_HG261GU"))) then
    	conf["ndppdStatus"] = db.getAttribute ("ndppd", "_ROWID_", 1, "ndppdStatus")
	end

    if (conf["networkType"] == "LAN") then
        status, errCode, conf = gui.networking.ipv6DhcpConfGet (conf)
        if (status ~= "OK") then
            gui.dprintf("ipv6.get: failed to get dhcpv6 information for " .. name)
            return status, errCode
        end
--[[
      if(name == "Guest") then
          conf.Wireless = gui.networking.network.guestVapSsidGet ()
      elseif(name == "Local") then
          conf.Wireless = gui.networking.network.adminVapSsidGet ()
      else
          conf.Wireless = "N/A"
      end
      if (conf.Wireless == nil) then
          return status, errCode
      end
--]]
    end

    conf["StaticIp"] = util.filterXSSChars(conf["StaticIp"])
    conf["PrefixLength"] = util.filterXSSChars(conf["PrefixLength"])
    conf["DomainName"] = util.filterXSSChars(conf["DomainName"])
    conf["preference"] = util.filterXSSChars(conf["preference"])
    conf["PrimaryDns"] = util.filterXSSChars(conf["PrimaryDns"])
    conf["SecondaryDns"] = util.filterXSSChars(conf["SecondaryDns"])
    conf["sipServer"] = util.filterXSSChars(conf["sipServer"])
    conf["dhcpLeaseTime"] = util.filterXSSChars(conf["dhcpLeaseTime"])
    conf["relayGw"] = util.filterXSSChars(conf["relayGw"])
    conf["Gateway"] = util.filterXSSChars(conf["Gateway"])

    return "OK","STATUS_OK", conf
end

-------------------------------------------------------------------------
-- @name gui.networking.network.ipv6.set
--
-- @descrription This routine configures for this network
--
-- @param name network name
-- @param conf
--
-- @return status
-- @return errCode
--
function gui.networking.network.ipv6.set (name, conf, dbFlag)

    -- include
 require "teamf1lualib/ifDev"

    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if(dbFlag == nil) then
        dbFlag = 1
    end
    if (name == nil) then
        return status, errCode
    end

    if (conf == nil) then
        return status, errCode
    end

    gui.dprintf("ipv6.set: INPUT " .. util.tableToStringRec(conf))

    -- check if the ipv6 is not a link-local address
    if (conf["StaticIp"] ~= nil) then
        if (string.match(conf["StaticIp"], '^fe80') or string.match(conf["StaticIp"], '^FE80')) then
            return status, "Cannot configure a Link-Local Address" 
        end
    end

    -- check if the ipv6 is a reserved address
    if (conf["StaticIp"] ~= nil) then
        if (ifDevLib.isIpv6AddressReserved(conf["StaticIp"]) > 0) then
            status = "ERROR"
            errCode = "RESERVED_IPV6_ADDRESS1"
            return status, errCode
        elseif(ifDevLib.isIpv6AddressMulticast(conf["StaticIp"]) > 0) then
            status = "ERROR"
            errCode = "MULTICAST_IPV6_ADDRESS"
            return status, errCode
        end
    end

    -- check if the ipv6 primary dns ipaddress is a reserved address
    if (conf["PrimaryDns"] ~= nil) then
        if (ifDevLib.isIpv6AddressReserved(conf["PrimaryDns"]) > 0) then
            status = "ERROR"
            errCode = "RESERVED_IPV6_ADDRESS1"
            return status, errCode
        elseif(ifDevLib.isIpv6AddressMulticast(conf["PrimaryDns"]) > 0) then
            status = "ERROR"
            errCode = "MULTICAST_IPV6_ADDRESS"
            return status, errCode
        elseif (string.match(conf["PrimaryDns"], '^fe80') or string.match(conf["PrimaryDns"], '^FE80')) then
            return status, "Cannot configure a Link-Local Address" 
        end
    end

    -- check if the ipv6 secondary dns ipaddress is a reserved address
    if (conf["SecondaryDns"] ~= nil and conf["SecondaryDns"] ~= "") then
        if (ifDevLib.isIpv6AddressReserved(conf["SecondaryDns"]) > 0) then
            status = "ERROR"
            errCode = "RESERVED_IPV6_ADDRESS1"
            return status, errCode
        elseif(ifDevLib.isIpv6AddressMulticast(conf["SecondaryDns"]) > 0) then
            status = "ERROR"
            errCode = "MULTICAST_IPV6_ADDRESS"
            return status, errCode
        elseif (string.match(conf["SecondaryDns"], '^fe80') or string.match(conf["SecondaryDns"], '^FE80')) then
            return status, "Cannot configure a Link-Local Address" 
        end
    end

    conf["Enable"] = "1"
    conf["requireLogin"] = 0
    conf["AddressFamily"] = "ipv6"
    conf["NetMask"] = "0"
    if (conf["Gateway"] == nil) then
        conf["Gateway"] = ""
    else
        local str = "ifconfig |grep -i inet6 |awk '{print $3}'|cut -d \"/\" -f 1 > /tmp/ipv6address.txt"
        os.execute(str)
        local contents = ""
        f = io.open ("/tmp/ipv6address.txt", "r")
        if(f ~= nil) then
            contents  = f:read("*all")
            f:close()
        else
            f:close()
            return "ERROR"
        end
        if(string.match(contents,conf["Gateway"])) then
            status = "ERROR"
            errCode = "IP_CONFIGURED_ON_SYSTEM"
            return status, errCode
        end
    end
    if (conf["networkType"] == "WAN") then
        conf["ConfigureDNS"] = "1"
        conf["ConfigureRoute"] = "1"
        conf["DefaultConnection"] = "0"
    end

    if (conf["ConnectionType"] == nil) then
        assert(nil, "Expecting connection type to be set")
    end

   if (UNIT_INFO == "ODU") then
    conf["MyIp"]    =""
    conf["Mtu"]     =""
    conf["WarnDisconnectDelay"] = ""
    conf["IspName"] =""
    conf["OID"]     =""
    conf["DefaultConnection"] = "0"
  
    conf["ConnectionKey"] = "0"
    if(conf["ConnectionType"] == "2" or conf["ConnectionType"] == "3"
       or conf["ConnectionType"] == "4" or conf["ConnectionType"] == "5" ) then
        conf["requireLogin"] = "1"
    else
        conf["requireLogin"] = "0"
    end
   end
     
    if (tonumber(conf["requireLogin"]) == 0) then
        if (conf["StatelessMode"] ~= nil) then
        if (conf["StatelessMode"] == "1" ) then
            conf["ConnectionType"] = "dhcp6c-stateless"
        else
            conf["ConnectionType"] = "dhcp6c"
        end
      end

        if (platformLib.strcasecmp(conf["ConnectionType"], "ifStatic6") == 0)then
            conf["GetIpFromIsp"] = "0"
             conf["GetDnsFromIsp"] = "0"
             if (conf["networkType"] == "WAN") then
                 conf["DefaultConnection"] = "1"
             end
        elseif (platformLib.strcasecmp(conf["ConnectionType"], "dhcp6c") == 0)then
             conf["GetIpFromIsp"] = "1"
             conf["GetDnsFromIsp"] = "1"
             conf["StatelessMode"] = "0"
--             conf["prefixDelegation"] = "0"
             conf["maptParams"] = "1"
        elseif (platformLib.strcasecmp(conf["ConnectionType"], "dhcp6c-stateless") == 0)then
             conf["GetIpFromIsp"] = "0"
             conf["GetDnsFromIsp"] = "1"
             conf["StatelessMode"] = "1"
             conf["maptParams"] = "1"
        elseif (platformLib.strcasecmp(conf["ConnectionType"], "ipv6-auto") == 0)then
             conf["GetIpFromIsp"] = "1"
             conf["GetDnsFromIsp"] = "1"
         else
             status = "ERROR"
             errCode = "NET_ERR_UNSUPPORTED_CONNTYPE"
             return status, errCode
         end

     elseif (tonumber(conf["requireLogin"]) == 1) then

        if (tonumber(conf["ConnectionType"]) == 2) then
            conf["ConnectionType"] = "pppoe"
        elseif (tonumber(conf["ConnectionType"]) == 3) then
            conf["ConnectionType"] = "pptp"
        elseif (tonumber(conf["ConnectionType"]) == 4) then
            conf["ConnectionType"] = "l2tp"
        elseif (tonumber(conf["ConnectionType"]) == 5) then
            conf["ConnectionType"] = "lte6"            
        else
            gui.dprintf("getConnType: Invalid connection Type")
         end
     else
        gui.dprintf("getConnType: Incorrect value for requireLogin")
        return nil
     end
 
     if (conf["ConnectionType"]=="lte6")then

        if (platformLib.strcasecmp(conf["subConnectionType"], "ifStatic6") == 0) then
           conf["subConnectionType"]= "ifStatic6"

        elseif (conf["StatelessMode"] ~= nil) then
             if (conf["StatelessMode"] == "1" ) then
                 conf["subConnectionType"] = "dhcp6c-stateless"
             else     
                 if (conf["StatelessMode"] == "0" ) then
                     conf["subConnectionType"] = "dhcp6c"
                 else             
                     conf["subConnectionType"] = "ipv6-auto"
                 end        
             end                                                                 
         else                 
            gui.dprintf("getConnType: Invalid connection Type")       
         end

         
         if (platformLib.strcasecmp(conf["subConnectionType"], "ifStatic6") == 0) then
             conf["GetIpFromIsp"] = "0"
             conf["GetDnsFromIsp"] = "0"
             conf["subConnectionType"]= "1"
             conf["StatelessMode"]= ""
        elseif (platformLib.strcasecmp(conf["subConnectionType"], "dhcp6c") == 0)then
             conf["GetIpFromIsp"] = "1"
             conf["GetDnsFromIsp"] = "1"
             conf["StatelessMode"] = "0"
--             conf["prefixDelegation"] = "0"
             conf["maptParams"] = "1"
             conf["subConnectionType"] = "0"
             conf["ConfigureDNS"]     ="1"                                              
             conf["ConfigureRoute"]   ="1"
        elseif (platformLib.strcasecmp(conf["subConnectionType"], "dhcp6c-stateless") == 0)then
             conf["GetIpFromIsp"] = "0"
             conf["GetDnsFromIsp"] = "1"
             conf["StatelessMode"] = "1"
             conf["maptParams"] = "1"
             conf["subConnectionType"]="0"
             conf["ConfigureDNS"]     ="1"                                        
             conf["ConfigureRoute"]   ="1"
        elseif (platformLib.strcasecmp(conf["subConnectionType"], "ipv6-auto") == 0)then
             conf["GetIpFromIsp"] = "1"
             conf["GetDnsFromIsp"] = "1"
             conf["ConfigureDNS"]     ="1"
             conf["ConfigureRoute"]   ="1"
             conf["subConnectionType"]="0"
        else
            status = "ERROR"
        errCode = "NET_ERR_UNSUPPORTED_CONNTYPE"
        return status, errCode
        end   
      end

    gui.dprintf("ipv6.set: " .. util.tableToStringRec(conf))

    require "teamf1lualib/network"
    status, errCode = network.configure (name, conf)
    if (status ~= "OK") then
        gui.dprintf("ipv6.set: failed to configure ipv6 network connection for " .. name)
        if (errCode == "") then
            errCode = "NET_ERR_NETWORK_IPV6_CONFIG_FAILED"
        end
        return status, errCode
    end

    if (conf["networkType"] == "LAN") then
        status, errCode = gui.networking.ipv6DhcpConfigure(conf, dbFlag)
        if (status ~= "OK") then
            gui.dprintf("ipv6.set: failed to configure dhcpv6 server for " .. name)
            return status, errCode
        end
    end

    -- If LAN mode changed from DHCPv6 Stateful to Static then RA should contain prefix
    if (conf["dhcpv6Mode"] ~= nil) then
	if (tonumber(conf["dhcpv6Mode"]) == 0) then
	    local query = "update radvdLANPrefixPool set Enable='1'"
	    db.execute(query)
        end
    end

    if (conf["dhcpMode"] ~= nil) then
        if (tonumber(conf["dhcpMode"]) == 1) then
        	-- As Per RJIL, In stateless mode send RA with prefix Infromation
		-- Moved code from 'c' to 'lua'
            db.setAttribute("radvdLANPrefixPool", "Enable", "0", "Enable", "1")
            db.setAttribute("radvd", "ROWID", "1", "AdvManagedFlag", "0")
        else
        	--- As Per RJIL, In statefull do not send RA with prefix Infromation 
		-- Moved code from 'c' to 'lua'
            db.setAttribute("radvdLANPrefixPool", "Enable", "1", "Enable", "0")
            db.setAttribute("radvd", "ROWID", "1", "AdvManagedFlag", "1")
        end
    end

    if (conf["prefixDelegation"] ~=nil and tonumber(conf["prefixDelegation"]) == 0) then
        local query1 = "delete from radvdLANPrefixPool where rowid=1"
        db.execute(query1)
    end

    if (conf["ndppdStatus"] ~= nil) then
            db.setAttribute("ndppd", "ROWID", "1", "ndppdStatus", conf["ndppdStatus"])
    end

    db.save2()
    if (platformLib.strcasecmp(name, "Internet") == 0)then
        if (platformLib.strcasecmp(conf["ConnectionType"], "ifStatic6") == 0)then
            os.execute("touch /tmp/wanStatic")
        else
            os.execute("rm -rf /tmp/wanStatic")
        end    
    end

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------
-- @name gui.networking.ipv6StatusGet
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--

function gui.networking.ipv6StatusGet (conf)
    local v6 = {}

    local ifconf = conf["ifconf"]
    local LogicalIfName = ifconf["LogicalIfName"]

    local ipv6conf = conf["ipv6"]

    v6.addrs = {}

    if (ipv6conf == nil) then
        return v6
    end

    local index = 1
    local ipv6status = ipv6conf["status"]
    local ipv6address = {}
    if (ipv6status ~= nil) then
        local ipv6addr = ipv6status["addrs"]
        if ((ipv6addr ~= nil) and (util.tableSize(ipv6addr) > 0)) then
            for k,v in pairs (ipv6addr) do
                if (v.ConnectionKey == "0") then
                    v6.addrs[index] = {}
                    v6.addrs[index]["StaticIp"] = v["ipAddress"] or "0::0"
                    v6.addrs[index]["Gateway"] = v["ipDstAddres"] or "0::0"
                    v6.addrs[index]["PrefixLength"] = v["ipv6PrefixLen"] or ""
                    v6.addrs[index]["AddressFamily"] = v["addressFamily"]
                    ipv6address[index] = {}
                    ipv6address[index] = v6.addrs[index]["StaticIp"] .. "/" .. v6.addrs[index]["PrefixLength"]
                    index = index + 1
                end
            end
        else
            v6.addrs[1] = {}
            v6.addrs[1]["StaticIp"] = "::"
            v6.addrs[1]["Gateway"] = "::"
            v6.addrs[1]["PrefixLength"] = ""
            v6.addrs[1]["AddressFamily"] = "10"
        end
    
        -- TODO correct this function and move this file back to guilua
        --[[local v6AddrList = nimfLib.getifaddrs(ifconf["interfaceName"], "10") or "0::0"
        if (v6AddrList ~= nil) then
            local v6AddrTbl = {}
            for k,v in pairs(v6AddrList) do
                table.insert(v6AddrTbl, v)
            end
            v6["ipv6address"] = v6AddrTbl
        else
            v6["ipv6address"] = ipv6address or "0::0"
        end]]--
            v6["ipv6address"] = ipv6address or "0::0"

        v6["rows"] = index

        if (ipv6status["Router"] == "") then
            v6["ipv6connectiongateway"] = "0::0"
        else
            if (ipv6conf["conf"]["Gateway"] == nil or ipv6conf["conf"]["Gateway"] == "") then
                v6["ipv6connectiongateway"] = ipv6status["Router"] or "0::0"
            else
                v6["ipv6connectiongateway"] = ipv6conf["conf"]["Gateway"] or "0::0"
            end
        end
        v6["connectiontimeipv6"] = ipv6status["Uptime"] or "Not Available"
     v6["ipv6connectionprimarydnsserver"] = ipv6status["dns"]["nameserver1"] or "0::0"
        v6["ipv6connectionsecondarydnsserver"] = ipv6status["dns"]["nameserver2"] or "0::0"
	if (ipv6status["dns"]["nameserver1"] == "") then
            v6["ipv6connectionprimarydnsserver"] = "0::0"
        end
        if (ipv6status["dns"]["nameserver2"] == "") then                                     
            v6["ipv6connectionsecondarydnsserver"] = "0::0"                                   
        end
        v6["ipv6connectionstatus"] = gui.networking.connStateStrGet(ipv6status)
        v6["connectiontimeipv6"] = gui.networking.connUpTimeGet(ipv6status)
        if (ipv6status["ConnectionType"] == "ifStatic6") then
            v6["ipv6connectionType"] = "IPv6 Manual Configuration"
        elseif (ipv6status["ConnectionType"] == "dhcp6c") then
            v6["ipv6connectionType"] = "IPv6 DHCP (Stateful)"
        elseif (ipv6status["ConnectionType"] == "dhcp6c-stateless") then
            v6["ipv6connectionType"] = "IPv6 DHCP (Stateless)"
        elseif (ipv6status["ConnectionType"] == "ipv6-auto") then
            v6["ipv6connectionType"] = "IPv6 Automatic (SLAAC)"
        elseif (ipv6status["ConnectionType"] == "lte6") then
            v6["ipv6connectionType"] = "LTE"
        else
            gui.dprintf ("IPv6 Status Get: Invalid conncection type")
        end
    else
        ipv6address[1] = "00::00"
        v6["ipv6address"] = ipv6address
        v6["ipv6connectiongateway"] = "00::00"
        v6["ipv6connectionprimarydnsserver"] = "0::0"
        v6["ipv6connectionsecondarydnsserver"] = "0::0"
        v6["ipv6connectionType"] = "Not Available"
        v6["connectiontimeipv6"] = "Not Available"

    end

    local ipv6connconf = ipv6conf["conf"]
    if (ipv6connconf ~= nil) then
        if (ipv6connconf["ConnectionType"] == "ifStatic6") then
            v6["ConnectionType"] = "IPv6 Manual Configuration"
        elseif (ipv6status["ConnectionType"] == "dhcp6c") then
            v6["ipv6connectionType"] = "IPv6 DHCP (Stateful)"
        elseif (ipv6status["ConnectionType"] == "dhcp6c-stateless") then
            v6["ipv6connectionType"] = "IPv6 DHCP (Stateless)"
        elseif (ipv6status["ConnectionType"] == "ipv6-auto") then
            v6["ipv6connectionType"] = "IPv6 Automatic (SLAAC)"
        elseif (ipv6status["ConnectionType"] == "lte6") then
            v6["ipv6connectionType"] = "LTE"
        else
            gui.dprintf ("IPv6 Status Get: Invalid conncection type")
        end
    end

    if (ifconf["zoneType"] == "secure") then
        require "teamf1lualib/dhcpv6"
        local status, errCode, dhcpConf = gui.networking.ipv6DhcpConfGet (conf)
        if (status == "OK") then
            if (tonumber(dhcpConf["dhcpEnable"]) == 1) then
                v6["dhcpv6Server"] = "Enabled"
            else
                v6["dhcpv6Server"] = "Disabled"
            end
        end
    end

    return v6
end

-------------------------------------------------------------------------
-- @name gui.networking.radvd.set
--
-- @descrription This routine configures radvd for this network
--
-- @param name network name
-- @param conf
--
-- @return status
-- @return errCode
--
function gui.networking.radvd.set (name, conf)

    -- include
    require "teamf1lualib/radvd"

    local row = {}
    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (name == nil) then
        return status, errCode
    end

    if (conf == nil) then
        return status, errCode
    end

    gui.dprintf("radvd.set: INPUT " .. util.tableToStringRec(conf))

    if(conf["AdvManagedFlag"] ~= nil) then  
        if(tonumber(conf["AdvManagedFlag"]) == 1) then                  
            db.setAttribute("dhcpv6s", "_ROWID_", 1, "statelessMode", "0")       
            local query = "update radvdLANPrefixPool set Enable='0'"
            db.execute(query)
        else                                                   
            db.setAttribute("dhcpv6s", "_ROWID_", 1, "statelessMode", "1")
            local query = "update radvdLANPrefixPool set Enable='1'"
            db.execute(query)
        end                                                               
    end

    -- configure RADVD
    status, errCode = radvd.configure (conf)
    if (status ~= "OK") then
        gui.dprintf("radvdConfigure: radvd configuration failed")
        return status, errCode
    end
    
    db.save2()

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------
-- @name gui.networking.radvd.get
--
-- @descrription This routine gets the radvd configuration of this network
--
-- @param name network name
--
-- @return status
-- @return errCode
-- @return conf
--
function gui.networking.radvd.get ()
    require "teamf1lualib/radvd"
    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"
    local conf = {}
       
    query = "_ROWID_='1'"
    status, errCode, conf = radvd.get(query)
    if ((status ~= "OK") or (conf == nil) or (conf[1] == nil)) then
        gui.dprintf("radvd.get: failed to get radvd configuration")
        return "ERROR", "RADVD_CONF_GET_FAILED"
    end

    conf[1]["MaxRtrAdvInterval"] = util.filterXSSChars(conf[1]["MaxRtrAdvInterval"])
    conf[1]["AdvLinkMTU"] = util.filterXSSChars(conf[1]["AdvLinkMTU"])
    conf[1]["AdvDefaultLifetime"] = util.filterXSSChars(conf[1]["AdvDefaultLifetime"])

    return "OK","STATUS_OK", conf[1]
end

-------------------------------------------------------------------------
-- @name gui.networking.network.sixToFour.set
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--
function gui.networking.network.sixToFour.set (conf)
    -- include
    require "teamf1lualib/6to4"
    require "teamf1lualib/iproute"

    local row = {}
    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    if (conf == nil) then
        return status, errCode
    end

    if (conf["tunnelStatus"] ~= nil) then
        row["active"] = conf["tunnelStatus"]
    end

    gui.dprintf("sixToFour.set: INPUT " .. util.tableToStringRec(conf))

    -- configure sixToFourTunnel
    status, errCode = sixToFour.configure (conf)
    if (status ~= "OK") then
        gui.dprintf("sixToFour: configuration failed")
        return status, errCode
    end
   
    --[[
    -- configure sixToFour Static route
    status, errCode = iproute.sixToFourStaticRouteConfigure (row)
    if (status ~= "OK") then
        gui.dprintf("sixToFour Route: configuration failed")
        return status, errCode
    end
    ]]--

    db.save2()

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------
-- @name gui.networking.network.sixToFour.get
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--

function gui.networking.network.sixToFour.get ()
    require "teamf1lualib/6to4"
    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"
    local conf = {}
       
    query = "_ROWID_='1'"
    status, errCode, conf = sixToFour.get(query)
    if ((status ~= "OK") or (conf == nil) or (conf[1] == nil)) then
        gui.dprintf("sixToFour.get: failed to get sixToFour configuration")
        return "ERROR", "6To4_CONF_GET_FAILED"
    end

    return "OK","STATUS_OK", conf[1]
end

-------------------------------------------------------------------------
-- @name gui.networking.network.sixToFour.tunStatGet
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--

function gui.networking.network.sixToFour.tunStatGet ()
    require "teamf1lualib/6to4"
    local tunnelRow = {}
    local ipaddrTbl = {}
    local page = {}
    local j
    local ipaddr
    page.tunnel = {}
       
    tunnelRow = sixToFour.tunnelGet()
    if (tunnelRow == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    for p,q in pairs (tunnelRow) do
        page.tunnel[p] = {}
        page.tunnel[p].tunnelName = q["LogicalIfName"]
      
        ipaddrTbl = sixToFour.tunnelIpaddr (q["LogicalIfName"])
        ipaddr = ""
        j = 0
        for k,v in pairs (ipaddrTbl) do
            j = j + 1
            local row1 = ipaddrTbl[j]
			if (ipaddr == "") then
                ipaddr = row1["ipAddress"] .. " / " .. row1["ipv6PrefixLen"]
            else
                ipaddr = ipaddr .. ", " .. row1["ipAddress"] .. " / " .. row1["ipv6PrefixLen"]
			end
        end
        page.tunnel[p].ipaddr = ipaddr or ''
        page.tunnel[p]._ROWID_ = q["_ROWID_"]
    end
       
    return "OK","STATUS_OK", page
end

-------------------------------------------------------------------------
-- @name gui.networking.network.isatap.edit.get
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--
function gui.networking.network.isatap.edit.get (rowid)
    require "teamf1lualib/isatap"
    local configRow = {} 

    configRow = isatap.tunnelEditGet(rowid)
   
    if (configRow == nil) then
        return "ERROR", "ISATAP_GET_FAILED"
    end

    return "OK", "OK", configRow
end

-------------------------------------------------------------------------
-- @name gui.networking.network.isatap.edit.set
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--
function gui.networking.network.isatap.edit.set (conf)

    -- require
    require "teamf1lualib/isatap"

	--locals
	local status, err

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    db.beginTransaction() --begin transactions
    
    -- configure isatap
    status, errCode = isatap.tunnelEditSet (conf)
    if (status ~= "OK") then
        gui.dprintf("isatap: configuration failed")
        db.rollback()
        return status, errCode
    end

    db.commitTransaction(true)
    db.save2()

    return "OK","STATUS_OK"
 
end

-------------------------------------------------------------------------
-- @name gui.networking.network.isatap.add.get
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--
function gui.networking.network.isatap.add.get ()
   
    local configTbl = {}

    return "OK", "STATUS_OK", configTbl
 
end

-------------------------------------------------------------------------
-- @name gui.networking.network.isatap.add.set
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--
function gui.networking.network.isatap.add.set (conf)

    -- require
    require "teamf1lualib/isatap"
    require "teamf1lualib/ifDev"
   
    local networkRow = {}
    local nimfConf = {}

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
    --locals
    local status, errMsg

    --setting the new configuration in the table
    --setting the new configuration in the table
    conf["transportIfName"] = "IF2"
    conf["isatapTunnelStatus"] = "1"
    if (conf["useLanAddress"] == "1") then
        conf["localIPv4Address"] = ""
    end

    db.beginTransaction() --begin transactions

    status, errMsg = isatap.tunnelAddSet(conf)

    if (status ~= "OK") then
        gui.dprintf("isatap: configuration failed")
        db.rollback()
        return status, errMsg
    end

    db.commitTransaction(true)
    db.save2()

    --return
    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name gui.networking.network.isatap.get
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--
function gui.networking.network.isatap.get ()
   
    -- require
    require "teamf1lualib/isatap"

    --locals
    local isatapTbl = {}
    local page = {}
    local lanIp = nil
    page.isatap = {}

    --getting the istap tunneling prefixes
    isatapTbl = isatap.tunnelGet()
    if (isatapTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    local query = "LogicalIfName = 'IF2' and addressFamily = 2"
	local lanConf = db.getRowWhere("ipAddressTable", query, false)
    if (lanConf ~= nil) then
        lanIp = lanConf["ipAddress"]
    end

    for i,v in pairs (isatapTbl) do
        page.isatap[i] = {}
        page.isatap[i].isatapPrefix = v["isatapPrefix"]
        if (v["useLanAddress"] == "1") then
            page.isatap[i].localIPv4Address = lanIp or ''
        else
            page.isatap[i].localIPv4Address = v["localIPv4Address"]
        end
        page.isatap[i]._ROWID_ = v["_ROWID_"]
    end

    --return
    return "OK", "STATUS_OK", page
end

-------------------------------------------------------------------------
-- @name gui.networking.network.isatap.delete
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--
function gui.networking.network.isatap.delete (rowIds)

    -- require
    require "teamf1lualib/isatap"

    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    db.beginTransaction() --begin transactions

    --delete each MAC filter rule
    for k,v in pairs(rowIds) do
        local inTable = {}
        inTable["isatapTunnel._ROWID_"] = v

        status, errMsg = isatap.tunnelDelete(inTable)
        if (status ~= "OK") then
            break
        end
    end

    if (status ~= "OK") then
        db.rollback()
        return status, errMsg
    end

    db.commitTransaction(true)
    db.save2()

    --return
    return "OK", "STATUS_OK"

end

-------------------------------------------------------------------------------
-- @name : gui.networking.network.ipConf.get
--
-- @description : This function fetches ipConf configuration
--
-- @return : status, errMsg, configTbl
--
function gui.networking.network.ipConf.get ()
    -- require
    require "teamf1lualib/ipConf"
    --locals
    local configTbl = {}

    --getting the values from ipConf table
    configTbl = ipConf.get()
    if(configTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    --return
    return "OK", "STATUS_OK", configTbl
end

-------------------------------------------------------------------------------
-- @name : gui.networking.network.ipConf.set
--
-- @description : This function sets ipConf configuration
--
-- @param : lua table containing ipConf configuraion set in webpage
--
-- @return : status, errMsg
--
function gui.networking.network.ipConf.set (InputTableCfg)
    -- require
    require "teamf1lualib/ipConf"
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    local ipConfRow = db.getRow ("ipConf", "_ROWID_", "1")
    if (ipConfRow == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    if (tonumber(ipConfRow ["ipConf.IPv6Enable"]) == tonumber(InputTableCfg["IPv6Enable"])) then
         return "ERROR", "SAME_IPMODE"
    end

    --setting the new configuration in the table
    status, errMsg = ipConf.set(InputTableCfg)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end

-------------------------------------------------------------------------------
-- @name : gui.networking.network.mldproxy.get
--
-- @description : This function fetches mldproxy configuration
--
-- @return : status, errMsg, configTbl
--
function gui.networking.network.mldproxy.get ()
    -- require
    require "teamf1lualib/mldproxy"
    --locals
    local configTbl = {}

    --getting the values from mldproxy table
    configTbl = mldproxy.get()
    if(configTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    configTbl["maxQueryResponseTime"] = util.filterXSSChars (configTbl["maxQueryResponseTime"])
    configTbl["queryTimeout"] = util.filterXSSChars (configTbl["queryTimeout"])
    configTbl["queryInterval"] = util.filterXSSChars (configTbl["queryInterval"])

    --return
    return "OK", "STATUS_OK", configTbl
end

-------------------------------------------------------------------------------
-- @name : gui.networking.network.mldproxy.set
--
-- @description : This function sets mldproxy configuration
--
-- @param : lua table containing mldproxy configuraion set in webpage
--
-- @return : status, errMsg
--
function gui.networking.network.mldproxy.set (InputTableCfg)
    -- require
    require "teamf1lualib/mldproxy"
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    --setting the new configuration in the table
    status, errMsg = mldproxy.configure(InputTableCfg)

    if (status == "OK") then
        db.save2()
    end

    --return
    return status, errMsg
end
-------------------------------------------------------------------------------
-- @name : gui.networking.network.ipConf.get
--
-- @description : This function fetches ipConf configuration
--
-- @return : status, errMsg, configTbl
--
function gui.networking.network.maptConf.get ()
    -- require
    require "teamf1lualib/maptConfig"
    --locals
    local configTbl = {}

    --getting the values from ipConf table
    configTbl = mapt.get()
    if(configTbl == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    configTbl["ipv4Prefix"] = util.filterXSSChars (configTbl["ipv4Prefix"])
    configTbl["ipv4PrefixLen"] = util.filterXSSChars (configTbl["ipv4PrefixLen"])
    configTbl["ipv6Prefix"] = util.filterXSSChars (configTbl["ipv6Prefix"])
    configTbl["ipv6PrefixLen"] = util.filterXSSChars (configTbl["ipv6PrefixLen"])
    configTbl["brIpv6Prefix"] = util.filterXSSChars (configTbl["brIpv6Prefix"])
    configTbl["brIpv6PrefixLen"] = util.filterXSSChars (configTbl["brIpv6PrefixLen"])
    configTbl["eabitsVal"] = util.filterXSSChars (configTbl["eabitsVal"])
    configTbl["eaLength"] = util.filterXSSChars (configTbl["eaLength"])
    configTbl["offset"] = util.filterXSSChars (configTbl["offset"])
    
    --return
    return "OK", "STATUS_OK", configTbl
end

-------------------------------------------------------------------------------
-- @name : gui.networking.network.ipConf.set
--
-- @description : This function sets ipConf configuration
--
-- @param : lua table containing ipConf configuraion set in webpage
--
-- @return : status, errMsg
--
function gui.networking.network.maptConf.set (InputTableCfg)
    -- require
    require "teamf1lualib/maptConfig"
    -- check for privileges
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    --locals
    local status, errMsg

    db.beginTransaction() --begin transactions

    --setting the new configuration in the table
    status, errMsg = mapt.configure(InputTableCfg)

    if (status ~= "OK") then
        gui.dprintf("maptConfig: configuration failed")
        db.rollback()
        return status, errMsg
    end

    db.commitTransaction(true)
    db.save2()

    --return
    return status, errMsg
end

