--[[
#### Mohan Kannekanti
#### TeamF1
#### www.TeamF1.com
#### Feb 10, 2012

#### File: swMgr.lua
#### Description: Switch Manager utility functions

#### Revisions:
None
]]--

require "swMgrLib"
require "teamf1lualib/db"
require "teamf1lualib/util"
require "teamf1lualib/switch"

swVlan  = {}
swVlan.debug = 0

-- VLAN properties
swVlan.prop = {}
swVlan.prop.vlanId           = "vlanId"
swVlan.prop.vlanName         = "vlanName"
swVlan.prop.interfaceName    = "interfaceName"
swVlan.prop.ingressMap       = "ingressMap"
swVlan.prop.egressMap        = "egressMap"
swVlan.prop.fwdMap           = "fwdMap"
swVlan.prop.untagMap         = "untagMap"
swVlan.prop.inSwitchOnly     = "inSwitchOnly"

--------------------------------------------------------------------------------------
-- Enumeration for VLAN property
-- @class table
-- @name swVlan.propType
--
-- @field  swVlan.propType.SWVLAN_PROP_TYPE_VLAN_ID             =   0,
-- @field  swVlan.propType.SWVLAN_PROP_TYPE_INTERFACE_NAME      =   1,
-- @field  swVlan.propType.SWVLAN_PROP_TYPE_INGRESS_MAP         =   2,
-- @field  swVlan.propType.SWVLAN_PROP_TYPE_EGRESS_MAP          =   3,
-- @field  swVlan.propType.SWVLAN_PROP_TYPE_FWD_MAP             =   4,
-- @field  swVlan.propType.SWVLAN_PROP_TYPE_UNTAG_MAP           =   5,
-- @field  swVlan.propType.SWVLAN_PROP_TYPE_IN_SWITCH_ONLY      =   6,
-- @field  swVlan.propType.SWVLAN_PROP_TYPE_VLAN_NAME           =   7,
--

swVlan.propType = {
      SWVLAN_PROP_TYPE_VLAN_ID              =   0,
      SWVLAN_PROP_TYPE_INTERFACE_NAME       =   1,
      SWVLAN_PROP_TYPE_INGRESS_MAP          =   2,
      SWVLAN_PROP_TYPE_EGRESS_MAP           =   3,
      SWVLAN_PROP_TYPE_FWD_MAP              =   4,
      SWVLAN_PROP_TYPE_UNTAG_MAP            =   5,
      SWVLAN_PROP_TYPE_IN_SWITCH_ONLY       =   6,
      SWVLAN_PROP_TYPE_VLAN_NAME            =   7,
}

-------------------------------------------------------------------------------
-- @name swVlan.add 
--
-- @description This function adds a VLAN in the device
--
-- @param switchName    Name of the switch
-- @param prop          vlan configuration Info table
--
-- The vlan configuration table contains the following fields
-- <ul>
-- <li><i> vlanName      Name of the VLAN. This field is mandatory
-- <li><i> vlanId        id of the VLAN. This field is mandatory
-- <li><i> inSwitchOnly  Flag to configure this VLAN only in SWITCH. Default is false. 
-- <li><i> interfaceName interface on which we need to create VLAN. If 'inSwitchOnly' 
-- flag is set to 'false' then this field is necessory.
--
-- <li><i> ingressMap    QoS Map for incoming packets on this VLAN. 
-- <li><i> egressMap     QoS Map for outgoing packets on this VLAN.
-- <li><i> fwdMap        Membership list of ports that can forward packets to
--                      this VLAN. Default is empty list.
-- <li><i> untagMap      Membership list of ports that can accept packet tagged
--                      with this VLAN. Default is empty list.    
-- </ul>
--
-- @return status OK or ERROR
-- @return errCode  error string
--

function swVlan.add (switchName, prop)
    local status = "ERROR"
    local errCode = "SWMGR_ERR_INVALID_ARG"
    local vlanTbl = {}
    
    -- validate input.
    if (prop == nil) then 
        return status, errCode
    end
   
    if (switchName == nil) then
        switchName = ""
    end

    vlanTbl = swVlan.vlanTblPrepare (prop)
    if (vlanTbl == nil) then 
        return status, errCode
    end
  --[[ 
    status, errCode = swMgrLib.vlanAdd (switchName, vlanTbl)
    if (status < 0) then 
        status = "ERROR"
        return status, errCode
    end
    ]]
    query = "vlanId = " .. vlanTbl["vlanId"] .. " and " .. 
            " interfaceName = '" .. vlanTbl["interfaceName"] .. "'"
    vlanTbl = util.addPrefix(vlanTbl, "vlanEncapIf.")

    row = db.existsRowWhere ("vlanEncapIf", query)
    if (row == false) then
        status,errCode = swMgr.dbConfig ("vlanEncapIf", vlanTbl, -1  , "add")
        if (status ~= "OK") then
            return "ERROR", "SW_MGR_DB_QRY_ERROR"
        else
            return "OK", "STATUS_OK"       
        end
    end
end

-------------------------------------------------------------------------------
-- @name swVlan.edit
--
-- @description This function Edit a VLAN in the device. It first deletes the
--              Old VLAN interface and creates new VLAN interface.
--
-- @param switchName    Name of the switch
-- @param prop          vlan configuration Info table
--
-- The vlan configuration table contains the following fields
-- <ul>
-- <li><i> vlanName      Name of the VLAN. This field is mandatory
-- <li><i> vlanId        id of the VLAN. This field is mandatory
-- <li><i> inSwitchOnly  Flag to configure this VLAN only in SWITCH. Default is false. 
-- <li><i> interfaceName interface on which we need to create VLAN. If 'inSwitchOnly' 
-- flag is set to 'false' then this field is necessory.
--
-- <li><i> ingressMap    QoS Map for incoming packets on this VLAN. 
-- <li><i> egressMap     QoS Map for outgoing packets on this VLAN.
-- <li><i> fwdMap        Membership list of ports that can forward packets to
--                      this VLAN. Default is empty list.
-- <li><i> untagMap      Membership list of ports that can accept packet tagged
--                      with this VLAN. Default is empty list.    
-- </ul>
--
-- @return status OK or ERROR
-- @return errCode  error string
--

function swVlan.edit (switchName, prop)
    local status = "ERROR"
    local errCode = "SWMGR_ERR_INVALID_ARG"
    local vlanTbl = {}
    
    -- validate input.
    if (prop == nil) then 
        return status, errCode
    end
    
    vlanTbl = swVlan.vlanTblPrepare (prop)
    if (vlanTbl == nil) then
        return status, errCode
    end

    --
    -- delete the vlan
    --[[ 
    local vlanIf = {}

    vlanIf[swVlan.prop.interfaceName] = prop["interfaceName"]
    vlanIf[swVlan.prop.vlanId] = ID
    status, errCode = swMgrLib.vlanDelete (switchName, vlanIf)
    if (status == "ERROR") then
        return status, errCode
    end
    ]]
    --
    -- add the vlan
    --[[
    status, errCode = swMgrLib.vlanAdd (switchName, vlanTbl)
    if (status < 0) then 
        status = "ERROR"
        return status, errCode
    end
    ]]

    query = "vlanId = " .. vlanTbl["vlanId"] .. " and " .. 
            " interfaceName = '" .. vlanTbl["interfaceName"] .. "'"
    vlanTbl = util.addPrefix(vlanTbl, "vlanEncapIf.")

    row = db.existsRowWhere ("vlanEncapIf", query)
    if (row ~= false) then
        status,errCode = swMgr.dbConfig ("vlanEncapIf", vlanTbl, 
                                         row["_ROWID_"]  , "edit")
        if (status ~= "OK") then
            return "ERROR", "SW_MGR_DB_QRY_ERROR"
        else
            return "OK", "STATUS_OK"       
        end
    end
end

-------------------------------------------------------------------------------
-- @name swVlan.membershipUpdate
--
-- @description This function Edit a VLAN membership with switch ports in the 
-- device.
--
-- @param switchName    Name of the switch
-- @param tagInfo    New vlan configuration table
--
-- <ul>
-- <li><i> vlanId        vlanId. This field is mandatory
-- <li><i> interfaceName interfaceName. This field is mandatory
-- <li><i> fwdMap        Membership list of ports that can forward packets to
-- this VLAN. Default is empty list.
-- <li><i> untagMap      Membership list of ports that can accept packet tagged 
-- with this VLAN. Default is empty list.    
-- </ul>
--
-- @return status OK or ERROR
-- @return errCode  error string
--

function swVlan.membershipUpdate (switchName, tagInfo)
    local status = "ERROR"
    local errCode = "SWMGR_ERR_INVALID_ARG"
    
    -- validate input.
    if (tagInfo == nil) then
        return status, errCode
    end
    
    if (tagInfo[swVlan.prop.fwdMap] == nil) then
        tagInfo[swVlan.prop.fwdMap] = ""
    end
    
    if (tagInfo[swVlan.prop.untagMap] == nil) then
        tagInfo[swVlan.prop.untagMap] = ""
    end

    vlanTbl = tagInfo
    --[[
    status,errCode = swMgrLib.vlanMembershipEdit (switchName, tagInfo)
    if (status < 0) then 
        status = "ERROR"
        return status, errCode
    end
    ]]
    query = "vlanId = " .. vlanTbl["vlanId"] .. " and " .. 
            " interfaceName = '" .. vlanTbl["interfaceName"] .. "'"
    vlanTbl = util.addPrefix(vlanTbl, "vlanEncapIf.")

    row = db.existsRowWhere ("vlanEncapIf", query)
    if (row ~= false) then
        status,errCode = swMgr.dbConfig ("vlanEncapIf", vlanTbl, row, "edit")
        if (status ~= "OK") then
            return "ERROR", "SW_MGR_DB_QRY_ERROR"
        else
            return "OK", "STATUS_OK"
        end
    end
end

-------------------------------------------------------------------------------
-- @name swVlan.delete 
--
-- @description This function deletes a VLAN in the device
--
-- @param ID            vlanId. 
-- @param prop          vlan configuration Info table
-- <ul>
-- <li><i> vlanId        vlanId. 
-- <li><i> interfaceName interfaceName. 
-- </ul>
--
-- @return status OK or ERROR
-- @return errCode  error string
--

function swVlan.delete (switchName, prop)
    local status = "ERROR"
    local errCode = "SWMGR_ERR_INVALID_ARG"
    local vlanTbl = {}

    vlanTbl[swVlan.prop.interfaceName] = prop["interfaceName"]
    vlanTbl[swVlan.prop.vlanId] = prop["vlanId"]

    --[[
    status,errCode = swMgrLib.vlanDelete (switchName, vlanTbl)
    if (status < 0) then 
        status = "ERROR"
        return status, errCode
    end
    ]]
    
    local query = "vlanId = " .. vlanTbl["vlanId"] .. " and " .. 
                  " interfaceName = '" .. vlanTbl["interfaceName"] .. "'"
    local row = db.existsRowWhere ("vlanEncapIf", query)

    if (row ~= false) then
        local rowTbl = {}
        rowTbl[1] = row
        
        status,errCode = swMgr.dbConfig ("vlanEncapIf", rowTbl, "" , "delete")
        if (status ~= "OK") then
            return "ERROR", "SW_MGR_DB_QRY_ERROR"
        else
            return "OK", "STATUS_OK"
        end
    end 

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name  swVlan.get
--
-- @description This function gets the VLAN property
--
-- @param ID            vlan ID 
-- @param property      property type
--
-- @return status   - OK or ERROR
-- @return errCode   
-- @return value    - the value of the property
--

function swVlan.get (name, property)
    local status = "ERROR"
    local errCode = "SWMGR_ERR_INVALID_ARG"
    local value = ""
    local whereStr = ""

    -- Input validation 
    if (property == nil) then
        return status, errCode
    end

    property = tonumber (property)

    if (name == nil) then
        return status, errCode
    end

    if (property == swVlan.propType.SWVLAN_PROP_TYPE_INTERFACE_NAME) then
        value = db.getAttribute (swMgr.SWITCHVLANTBL, 
                                 swVlan.prop.vlanId,
                                 ID, swVlan.prop.interfaceName)
        if (value == nil) then
            status = "ERROR"
            errCode = "SWMGR_ERR_INTERFACE_NAME"
            return status, errCode
        end 
    
    elseif (property == swVlan.propType.SWVLAN_PROP_TYPE_INGRESS_MAP) then
        value = db.getAttribute (swMgr.SWITCHVLANTBL, 
                                 swVlan.prop.vlanId,
                                 ID, swVlan.prop.ingressMap)
        if (value == nil) then
            status = "ERROR"
            errCode = "SWMGR_ERR_INGRESS_MAP"
            return status, errCode
        end 
    
    elseif (property == swVlan.propType.SWVLAN_PROP_TYPE_EGRESS_MAP) then
        value = db.getAttribute (swMgr.SWITCHVLANTBL, 
                                 swVlan.prop.vlanId,
                                 ID, swVlan.prop.ingressMap)
        if (value == nil) then
            status = "ERROR"
            errCode = "SWMGR_ERR_EGRESS_MAP"
            return status, errCode
        end 
    elseif (property == swVlan.propType.SWVLAN_PROP_TYPE_FWD_MAP) then
        value = db.getAttribute (swMgr.SWITCHVLANTBL, 
                                 swVlan.prop.vlanId,
                                 ID, swVlan.prop.fwdMap)
        if (value == nil) then
            status  = "ERROR"
            errCode = "SWMGR_ERR_FWD_MAP"
            return status, errCode
        end

    elseif (property == swVlan.propType.SWVLAN_PROP_TYPE_UNTAG_MAP) then
        value = db.getAttribute (swMgr.SWITCHVLANTBL, 
                                 swVlan.prop.vlanId,
                                 ID, swVlan.prop.untagMap)
        if (status == "ERROR" or value == nil) then
            status  = "ERROR"
            errCode = "SWMGR_ERR_UNTAG_MAP"
            return status, errCode
        end
    
    elseif (property == swVlan.propType.SWVLAN_PROP_TYPE_IN_SWITCH_ONLY) then
        value = db.getAttribute (swMgr.SWITCHVLANTBL, 
                                 swVlan.prop.vlanId,
                                 ID, swVlan.prop.inSwitchOnly)
        if (value == nil) then
            status = "ERROR"
            errCode = "SWMGR_ERR_IN_SWITCH_ONLY"
            return status, errCode
        end 

    else
        swMgr.dprintf("get: property: " .. property .. " not supported")
        return status, errCode
    end

    return "OK", "STATUS_OK", value
end

-------------------------------------------------------------------------------
-- @name   swVlan.set 
--
-- @description This function sets the VLAN property
--
-- @param ID        VLAN ID
-- @param property  property type 
-- @param value     property value
--
-- @return status   - OK or ERROR
-- @return errCode 
-- 

function swVlan.set (ID, property, value)
    local status = "ERROR"
    local errCode = "SWMGR_ERR_INVALID_ARG"
    local whereStr = ""


    if (name == nil) then
        return status, errCode
    end

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name swVlan.create 
--
-- @description This function creates a VLAN with the given membership 
-- information
--
-- @param ID            vlanId
-- @param mapTbl        port membership table for this VLAN.
-- The membership table has to have the following fields
-- <ul>
-- <li><i>name</i>      -  Device   
-- <li><i>ifname</i>    -  Device Interface name
-- <li><i>port</i>      -  port number of the device
-- <li><i>default</i>   -  Is this a native port for this VLAN
-- </ul>
--
-- @return status   - OK or ERROR
-- @return errCode 
-- @return vlanIf   - vlan that has been created
-- 

function swVlan.create (logicalIfName, ID, mapTbl)
    local status = "ERROR"
    local errCode = "SWMGR_ERR_INVALID_ARG"
    local vlanTbl = {}

    if (logicalIfName == nil) then
        return status, errCode
    end

    -- validate vlanID
    if ID and not swVlan.isValid(ID) then
        return status, errCode
    end

    -- validate mapTbl
    -- TODO This check should be removed as one can create a vlan with out any
    -- membership.  But then how to get interfaceName and switchName ?? 
    if (mapTbl == nil) then
        return status,errCode
    end

    --
    -- Convert membership into fwd/untag maps.
    --
    local vlanInfo = swVlan.mapToVlanInfoGet (mapTbl)

    swVlan.dprintf("Creating VLAN on " .. vlanInfo["switchName"] .. 
                   "with conf" .. util.tableToStringRec(vlanInfo))
    
    if ((vlanInfo["inSwitchOnly"] ~= nil) and
        (tonumber(vlanInfo["inSwitchOnly"]) == 0) and (vlanInfo["interfaceName"] == nil)) then
        return status, errCode
    end        

    -- prepare vlanTbl to configure
    vlanTbl["vlanName"]         =   logicalIfName
    vlanTbl["LogicalIfName"]    =   logicalIfName
    vlanTbl["vlanId"]           =   ID
    i1, i2, vlanTbl["interfaceName"] = 
            string.find(vlanInfo["interfaceName"], "(%w+)(%.?)(%w?)")
    vlanTbl["ingressMap"]       =   swVlan.defaultIngressMapGet()
    vlanTbl["egressMap"]        =   swVlan.defaultEgressMapGet()
    vlanTbl["fwdMap"]           =   vlanInfo["fwdMap"]
    vlanTbl["untagMap"]         =   vlanInfo["untagMap"]
    vlanTbl["inSwitchOnly"]         =   vlanInfo["inSwitchOnly"] or "0"

    swVlan.dprintf("Creating VLAN on " .. vlanInfo["switchName"] .. 
                   "with conf" .. util.tableToStringRec(vlanTbl))

    status, errCode = swVlan.add (vlanInfo["switchName"], vlanTbl)
    if status == "ERROR" then
        return status, errCode
    end

    return "OK", "STATUS_OK", vlanInfo["interfaceName"]
end

-------------------------------------------------------------------------------
-- @name   swVlan.defaultEgressMapGet
--
-- @description 
--
-- @param 
--
-- @return egressMap 
-- 

function swVlan.defaultEgressMapGet ()
    return ""
end

-------------------------------------------------------------------------------
-- @name   swVlan.defaultIngressMapGet
--
-- @description 
--
-- @param 
--
-- @return egressMap 
-- 

function swVlan.defaultIngressMapGet()
    return ""
end

-------------------------------------------------------------------------------
-- @name   swVlan.confsGet
--
-- @description This function gets list of VLAN for a given LogicalIfName
--
-- @param vlanIfName     LogicalIfName of the VLAN
--
-- @return status   - OK or ERROR
-- @return errCode 
-- @return vlanIf   table for vlans attached to this LogicalIfName
-- 

function swVlan.confsGet (vlanIfName)

	local vlanIf = {}
    if (vlanIfName == nil) then
        return "ERROR", "SWMGR_ERR_INVALID_ARG"
    end
	
	vlanIf = db.getRows("vlanEncapIf", "LogicalIfName", vlanIfName) or {}
	return "OK", "STATUS_OK", vlanIf
	
	
end

-------------------------------------------------------------------------------
-- @name   swVlan.confGet
--
-- @description This function gets the configuration of the given VLAN interface.
--
-- @param vlanIfName     interface name of the VLAN
--
-- @return status   - OK or ERROR
-- @return errCode 
-- @return conf     vlan configuration
-- 

function swVlan.confGet (vlanIfName)
    local status = "ERROR"
    local errCode = ""
    local query

    if (vlanIfName == nil) then
        return status, "SWMGR_ERR_INVALID_ARG"
    end        

    local parts =  util.split(vlanIfName, ".")
    if (parts == nil)  then
        return status, "SWMGR_ERR_INVALID_ARG"
    end        

    if (parts[2] == nil) then
        query = "vlanId='" .. parts[1]  .. "'" ..
                " or interfaceName='" .. parts[1] ..  "'" ..
                " or LogicalIfName='" .. parts[1] .. "'"
    else
        query = "interfaceName='" .. parts[1] .. "' and vlanId=" .. parts[2]
    end
    
    local vlanIf = db.getRowWhere("vlanEncapIf", query, false) 
    if (vlanIf == nil) then
        return status, "SWMGR_ERR_DB_QUERY_FAILED"
    end        
            
    -- 
    -- Get the membership information.
    --             
    status, errCode, vlanIf["map"] =  swVlan.mapGet(vlanIf)
    if (status ~= "OK") then
        return status, errCode
    end        
                    
    return "OK","STATUS_OK", vlanIf
end

-------------------------------------------------------------------------------
-- @name   swVlan.destroy 
--
-- @description This function destroys the given VLAN
--
-- @param vlanIf  vlan interface name of interface table. This interface table 
-- is returned by the call swVlan.confGet()
--
-- @return status   - OK or ERROR
-- @return errCode 
-- 

function swVlan.destroy (vlanIf)
    local status = "ERROR"
    local errCode = "SWMGR_ERR_INVALID_ARG"
    local vlanTbl = {}
    
    swVlan.dprintf("destroy:" .. util.tableToStringRec(vlanIf))
    
    if (vlanIf == nil) then
        return status, errCode
    end

    if ((type(vlanIf) ~= "table")  and ((type(vlanIf) ~= "string"))) then
        return status, errCode
    end
    
    if (type(vlanIf) == "string") then
        status, errCode, vlanTbl = swVlan.confGet(vlanIf)       
    elseif (type(vlanIf) == "table") then
        status, errCode, vlanTbl = swVlan.confGet(vlanIf["ifname"])
    end        
    if (status ~= "OK") then
        return status, errCode
    end

    switchName = ""

    status, errCode = swVlan.delete (switchName, vlanTbl)
    if (status == "ERROR") then
        return status,errCode
    end

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name   swVlan.mapGet
--
-- @description This function gets the VLAN membership information.
--
-- @param vlanIf  vlan interface table.
--
-- @return status   - OK or ERROR
-- @return errCode 
-- @return mapTbl   port membership list for this VLAN.
-- 

function swVlan.mapGet (vlanIf)
    local status = "ERROR"
    local errCode = "SWMGR_ERR_INVALID_ARG"
    local fwdMap 
    local untagMap
    local mapTbl = {}

    -- 
    -- Since we are not storing the switch information
    -- in the VLAN. We get the first switch in
    -- the configuration
    --           
    local switchName = db.getAttribute("swGlobalCfg", 
                                       "_ROWID_", "1", "switchName")
    if (switchName == nil) then
        return status, "SWMGR_ERR_SWITCH_NOT_FOUND"
    end        
        
    fwdMap = vlanIf["fwdMap"]
    untagMap =  vlanIf["untagMap"]

    local tag = util.split(fwdMap, ",")
    local untag = util.split(untagMap, ",")

    if ((tag == nil) and (untag == nil)) then
        return "OK", "STATUS_OK", mapTbl
    end        

    --
    -- prepare map table having the following fields
    -- name         -  Device   
    -- ifname       -  Device Interface name
    -- port         -  port number of the device
    -- default      -  Is this a native port for this VLAN
    --
    local index = 1
    for k,v in pairs(tag) do
        mapTbl[index] = {}
        mapTbl[index]["name"] =  switchName
        mapTbl[index]["ifname"] =  vlanIf["interfaceName"]
        mapTbl[index]["port"] = tonumber(v)
        if (swVlan.tagFind(untag, tonumber(v)) ~= nil)  then
            mapTbl[index]["default"] =  1
        else            
            mapTbl[index]["default"] =  0
        end
        index = index + 1
    end        

    return "OK", "STATUS_OK", mapTbl
end

-------------------------------------------------------------------------------
-- @name   swVlan.mapEdit 
--
-- @description This function updates the VLAN membership configuration
--
-- @param ID            vlanId
-- @param mapTbl        membership port list for this VLAN.
--
-- The mapTbl should contain the following fields:
-- <ul>
-- <li><i> name     switch device name
-- <li><i> ifname   device interface name
-- <li><i> port     port number
-- <li><i> default  default vlan flag
-- </ul>
--
-- @return status   - OK or ERROR
-- @return errCode 
-- 

function swVlan.mapEdit (ID, mapTbl)
    local status = "ERROR"
    local errCode = "SWMGR_ERR_INVALID_ARG"
    local vlanTbl = {}

    -- validate vlanID
    if ID and not swVlan.isValid(ID) then
        swVlan.dprintf ("mapEdit: invalid vlan ID")
        return status, errCode
    end

    -- validate mapTbl
    if (mapTbl == nil) then
        swVlan.dprintf ("mapEdit: invalid mapTbl")
        return status,errCode
    end

    --
    -- Convert membership into fwd/untag maps.
    --
    
    local vlanInfo = swVlan.mapToVlanInfoGet (mapTbl)

    swVlan.dprintf("mapEdit: " .. util.tableToStringRec(mapTbl))
    swVlan.dprintf("mapEdit: " .. util.tableToStringRec(vlanInfo))
    
    if (vlanInfo["interfaceName"] == nil) then
        swVlan.dprintf ("mapEdit: invalid interface name")
        return status, errCode
    end        

    -- prepare vlanTbl to configure
    vlanTbl["vlanId"]           =   ID
    i1, i2, vlanTbl["interfaceName"]    =   
                string.find(vlanInfo["interfaceName"], "(%w+)(%.?)(%w?)")

    vlanTbl["fwdMap"]           =   vlanInfo["fwdMap"]
    vlanTbl["untagMap"]         =   vlanInfo["untagMap"]


    local currTbl = db.getRowWhere ("vlanEncapIf", "vlanId = " .. ID .. 
                                    " and interfaceName = '" .. 
                                    vlanTbl["interfaceName"] .. "'")

    if (currTbl ~= nil and 
        (currTbl["fwdMap"] == vlanTbl["fwdMap"] and 
         currTbl["untagMap"] == vlanTbl["untagMap"])) then
        swVlan.dprintf ("mapEdit: Memebership isn't changed for vlanId (" .. ID .. ")")
        return "OK", "STATUS_OK"
    end

    --
    -- Update membership information into the switch
    --
    status,errCode = swVlan.membershipUpdate (switchName, vlanTbl)
    if status == "ERROR" then
        swVlan.dprintf ("mapEdit: failed to update membership")
        return status, errCode
    end

    return "OK", "STATUS_OK"
end

--[[
-------------------------------------------------------------------------------
-- @name swVlan.isValid
--
-- @description This function checks whether the given VLAN id is valid
--
-- @param vlanId  vlan id
--
-- @return true/false
--
--]]

function swVlan.isValid (vlanId)
    local id = tonumber (vlanId)

    if (id == nil) then return false end

    if (id >= 1 and id <= 4091) then 
        return true
    else
        return false
    end
end

--[[
*******************************************************************************
-- @name swVlan.vlanTblPrepare
--
-- @description This function will prepare the VLAN configuration table from
--              user configuration.
--
-- @param prop      user configuration table.
--
-- @return vlanTbl  vlan table configuration table.
--
--]]

function swVlan.vlanTblPrepare (prop)
    local vlanTbl = {}

    if (prop[swVlan.prop.vlanName] == nil) then
        return nil
    end

    vlanTbl[swVlan.prop.vlanName] = prop[swVlan.prop.vlanName]

    if (prop[swVlan.prop.vlanId] == nil) then 
        return nil
    end

    if (swVlan.isValid (prop[swVlan.prop.vlanId])) then 
        vlanTbl[swVlan.prop.vlanId] = prop[swVlan.prop.vlanId]
    else
        return nil
    end
    
    if (prop[swVlan.prop.inSwitchOnly] == nil) then
        vlanTbl[swVlan.prop.inSwitchOnly] = 0
    else
        vlanTbl[swVlan.prop.inSwitchOnly] = prop[swVlan.prop.inSwitchOnly]
    end
    
    if (vlanTbl[swVlan.prop.inSwitchOnly] == 0) then
        if (prop[swVlan.prop.interfaceName] == nil) then
            return nil
        end
        vlanTbl[swVlan.prop.interfaceName] = prop[swVlan.prop.interfaceName]
    else
        vlanTbl[swVlan.prop.interfaceName] = prop[swVlan.prop.interfaceName] or ''
    end

    if (prop[swVlan.prop.egressMap] == nil) then
        vlanTbl[swVlan.prop.egressMap] = ""
    else
        vlanTbl[swVlan.prop.egressMap] = prop[swVlan.prop.egressMap]
    end

    if (prop[swVlan.prop.ingressMap] == nil) then
        vlanTbl[swVlan.prop.ingressMap] = ""
    else
        vlanTbl[swVlan.prop.ingressMap] = prop[swVlan.prop.ingressMap]
    end

    if (prop[swVlan.prop.fwdMap] == nil) then
        vlanTbl[swVlan.prop.fwdMap] = ""
    else
        vlanTbl[swVlan.prop.fwdMap] = prop[swVlan.prop.fwdMap]
    end

    if (prop[swVlan.prop.untagMap] == nil) then
        vlanTbl[swVlan.prop.untagMap] = ""
    else
        vlanTbl[swVlan.prop.untagMap] = prop[swVlan.prop.untagMap]
    end

    if (prop["LogicalIfName"] == nil) then
        vlanTbl["LogicalIfName"] = ""
    else
        vlanTbl["LogicalIfName"] = prop["LogicalIfName"]
    end

    return vlanTbl
end

--[[
*******************************************************************************
-- @name swVlan.mapToVlanInfoGet
--
-- @description This function generates tag/fwd map from the mapTbl
--
-- @param mapTbl  vlan port membership information
--
-- @return vlanInfo
--
--]]

function swVlan.mapToVlanInfoGet (mapTbl)
    local fwdMap
    local untagMap
    local fwdTbl = {}
    local untagTbl = {}
    local index
    local port
    local vlanInfo = {}
    local interfaceName = ""

    -- prepare fwdMap and untagMap
    for index, port in pairs(mapTbl) do

        if (type (port) == "table") then

        if (interfaceName == nil or interfaceName == "") then 
            interfaceName = port["ifname"]
        end

        if (switchName == nil) then 
            switchName = port["name"]
        end

        if (fwdMap == nil) then
            fwdMap = port["port"]
        else
            fwdMap = fwdMap .. "," .. port["port"]
        end
       
        if (port["default"] ~= nil and tonumber(port["default"]) > 0) then
            if (untagMap == nil) then
                untagMap = port["port"]
            else
                untagMap = untagMap .. "," .. port["port"]
            end
        end

        end
    end

    vlanInfo["interfaceName"] = interfaceName
    vlanInfo["switchName"] = switchName or ""
    vlanInfo["inSwitchOnly"] = mapTbl["inSwitchOnly"] or "0"

    if (untagMap ~= nil) then
        untagTbl = util.split (untagMap, ",")
        table.sort (untagTbl)
        vlanInfo["untagMap"] = util.join (untagTbl, ",")
    else
        vlanInfo["untagMap"] = ""
    end


    if (fwdMap ~= nil) then
        fwdTbl = util.split (fwdMap, ",")
        table.sort (fwdTbl)
        vlanInfo["fwdMap"] = util.join (fwdTbl, ",")
    else
        vlanInfo["fwdMap"] = ""
    end

    return vlanInfo
end    

--[[
*******************************************************************************
-- @name swVlan.tagFind
--
-- @description This function find a given tag in the table.
--
-- @param tagTbl    table of tags
-- @param tag       tag
--
-- @return tag or nil
--]]

function swVlan.tagFind(tagTbl, tag)
    if ((tagTbl == nil) or (tag == nil)) then
        return nil            
    end        

    for k,v in pairs(tagTbl) do
        if (tonumber(v) == tonumber(tag)) then
            return v
        end                        
    end        
end

--[[
*******************************************************************************
-- @name  swVlan.dprintf
--
-- @description 
--
-- @param msg
--
-- @return N/A
--]]

function swVlan.dprintf (msg)

    if (msg == nil) then
        return
    end
            
    local blob = "SWVLAN:" .. msg .. " <br>"

    if (swVlan.debug == 1) then
        print(blob)
    end        

    if ((gui ~= nil) and (gui.debug == 1)) then
        util.appendDebugOut(blob)
    end        

    return
end
