--[[
#### Copyright (c) 2015, TeamF1 Networks Pvt. Ltd. 
#### (Subsidiary of D-Link India)
#### 
#### File: tr181_bridgeTrExtn.lua
#### Description: 
#### TR-181 handlers for bridgeMode. This file is included from tr181_tr69funcs.lua
####
#### Revisions:
01d,18Sep18,swr  Changes for SPR 63317(vlan membership conf support)
01c,31Jul17,swr  Changes for SPR 60117
01b,28Sep15,swr  Changes for SPR 52552
01a,11Aug15,swr  Changes for SPR 52552
]]--

bridgeTr = {}
local dbFlag = 0

--[[
--****************************************************************************
-- bridgeTr.vlanPortGet - get the port Number
--
-- RETURN: nil or portNumber
]]--

function bridgeTr.vlanPortGet (param, lkupstring)
    local startIdx
    local endIdx
    local portNumber
    startIdx, endIdx = string.find(param, lkupstring)
    portNumber = string.sub(param, startIdx-2, startIdx-2)
    portNumber = tonumber(portNumber) 
    return portNumber
end

--[[
--*****************************************************************************
-- bridgeTr.bridgePortCfgGet - get Bridge Port configuration
-- 
-- TR69 Parameter: Device.Bridging.Bridge.0.Port.0
--
]]--

function bridgeTr.bridgePortCfgGet (input)
    local status = "0"
    local value = "0"
    local portNumber
    local row = {}
    local query = nil
    local bridgeModeRow = {}
    local param = input["param"]
    local rowId
    local parentObjInstance = ""

    if(util.fileExists("/pfrm2.0/BRIDGE_MODE")) then
        --load instanceMap
        local instanceMap = tr69Glue.instanceMapLoad()
        if (instanceMap == nil) then
            return "1", "DB_ERROR_TRY_AGAIN"
        end

        --find the immediate parent object with instance number
        local startIdx, endIdx
        startIdx, endIdx = string.find(param, "Port.")
        parentObjInstance = string.sub(param, 1, endIdx+2)
    
        --read the rowId mapping to qosClassQueue
        rowId = instanceMap[parentObjInstance]
        if (rowId == nil) then
            return "1", "DB_ERROR_TRY_AGAIN"
        end

        local bridgePortsRow = db.getRowWhere("bridgePorts", "interfaceName='eth1'", false)
        local ethernetVLANRow = db.getTable("ethernetVLAN", false)
        local vlanEncapTbl = db.getTable("vlanEncapIf", false)

        if(string.find(input["param"], "Enable")) then
            -- Enable
            if(rowId == "4") then
                if(bridgePortsRow["portEnabled"] == "1") then
                    value = "1"
                else
                    value = "0"
                end
            else
                value = "0"
                for k,v in pairs (vlanEncapTbl) do
                    if(string.find(v["fwdMap"], rowId)) then
                        value = "1"
                        break;
                    end
                end
            end
        elseif(string.find(input["param"], "Status")) then
            -- Status
            if(rowId == "4") then
                if(bridgePortsRow["portEnabled"] == "1") then
                    value = "Up"
                else
                    value = "Down"
                end
            else
                value = "Down"
                for k,v in pairs (vlanEncapTbl) do
                    if(string.find(v["fwdMap"], rowId)) then
                        value = "Up"
                        break;
                    end
                end
            end
        elseif(string.find(input["param"], "Name")) then
            -- Name
            if(rowId == "4") then
                value = bridgePortsRow["interfaceName"]
                if(#ethernetVLANRow > 0) then
                    for k,v in pairs (ethernetVLANRow) do
                        value = value.."."..v["vlanId"]
                        break;
                    end
                end
            else
                value = "eth0"
                for k,v in pairs (vlanEncapTbl) do
                    if(string.find(v["fwdMap"], rowId)) then
                        value = v["interfaceName"].."."..v["vlanId"]
                        break;
                    end
                end
            end
        elseif(string.find(input["param"], "LowerLayers")) then
            -- LowerLayers
            if(rowId == "4") then
                value = "Device.Ethernet.Interface.3."
            else
                value = "Device.Ethernet.Interface.2."
            end
        elseif(string.find(input["param"], "ManagementPort")) then
            -- ManagementPort
            value = "0"
        elseif(string.find(input["param"], "PortState")) then
            -- PortState
            value = "Forwarding"
        elseif(string.find(input["param"], "PVID")) then
            -- PVID
            value = ""
            if(rowId == "4") then
                if(#ethernetVLANRow > 0) then
                    for k,v in pairs (ethernetVLANRow) do
                        value = v["vlanId"]
                        break;
                    end
                end
            else
                local untaggedFlag = 0
                for k,v in pairs (vlanEncapTbl) do
                    if(string.find(v["untagMap"], rowId)) then
                        value = v["vlanId"]
                        untaggedFlag = 1
                        break;
                    end
                end
                if(untaggedFlag == 0) then
                    for k,v in pairs (vlanEncapTbl) do
                        if(string.find(v["fwdMap"], rowId)) then
                            value = v["vlanId"]
                            break;
                        end
                    end
                end
            end
        elseif(string.find(input["param"], "AcceptableFrameTypes")) then
            -- AcceptableFrameTypes
            value = "AdmitAll"
        elseif(string.find(input["param"], "IngressFiltering")) then
            -- IngressFiltering
            value = "0"
        elseif(string.find(input["param"], "PriorityTagging")) then
            -- PriorityTagging
            if(rowId == "4") then
                if(#ethernetVLANRow > 0) then
                    value = "1"
                else
                    value = "0"
                end
            else
                value = "0"
                for k,v in pairs (vlanEncapTbl) do
                    if(string.find(v["fwdMap"], rowId)) then
                        value = "1"
                        break;
                    end
                end

                if(value == "1") then
                    for k,v in pairs (vlanEncapTbl) do
                        if(string.find(v["untagMap"], rowId)) then
                            value = "0"
                            break;
                        end
                    end
                end
            end
        else
            return "1", "DB_ERROR_TRY_AGAIN"
        end
    else
        bridgeModeRow = db.getRowWhere ("bridgeMode", "_ROWID_=1", false)
        chipsetInfo = db.getAttribute("chipsetInfo", "_ROWID_", "1", "Chipset")
        --find & return parameter values
        if(string.find(input["param"], "Enable")) then
            -- Enable
            portNumber = bridgeTr.vlanPortGet (param, "Enable") 

            if(bridgeModeRow["status"] == "1") then
                if(util.fileExists("/pfrm2.0/HW_HG260ES") or util.fileExists("/pfrm2.0/DUAL_ONLY")) then
                    if(bridgeModeRow["portNumber"] == "1") then
                        bridgeModeRow["portNumber"] = "3"
                    elseif(bridgeModeRow["portNumber"] == "2") then
                        bridgeModeRow["portNumber"] = "2"
                    elseif(bridgeModeRow["portNumber"] == "3") then
                        bridgeModeRow["portNumber"] = "1"
                    end
                end

                if(chipsetInfo == "econet" and (not (util.fileExists("/pfrm2.0/HW_JCO4032") or util.fileExists("/pfrm2.0/HW_JCOW407") or util.fileExists("/pfrm2.0/HW_JCOW402")))) then
                    bridgeModeRow["portNumber"] = tonumber(bridgeModeRow["portNumber"]) - 2
                end

                if(tonumber(bridgeModeRow["portNumber"]) == portNumber)then
                    value = "1"
                else
                    value = "0"
                end
            else
                value = "0"
            end
        elseif(string.find(input["param"], "Status")) then
            -- Status
            portNumber = bridgeTr.vlanPortGet (param, "Status")

            if(bridgeModeRow["status"] == "1") then
                if(util.fileExists("/pfrm2.0/HW_HG260ES") or util.fileExists("/pfrm2.0/DUAL_ONLY")) then
                    if(bridgeModeRow["portNumber"] == "1") then
                        bridgeModeRow["portNumber"] = "3"
                    elseif(bridgeModeRow["portNumber"] == "2") then
                        bridgeModeRow["portNumber"] = "2"
                    elseif(bridgeModeRow["portNumber"] == "3") then
                        bridgeModeRow["portNumber"] = "1"
                    end
                end

                if(chipsetInfo == "econet"  and (not (util.fileExists("/pfrm2.0/HW_JCO4032") or util.fileExists("/pfrm2.0/HW_JCOW407") or util.fileExists("/pfrm2.0/HW_JCOW402")))) then
                    bridgeModeRow["portNumber"] = tonumber(bridgeModeRow["portNumber"]) - 2
                end

                if(tonumber(bridgeModeRow["portNumber"]) == portNumber)then
                    value = "Up"
                else
                    value = "Down"
                end
            else
                value = "Down"
            end
        elseif(string.find(input["param"], "Name")) then
            -- Name
            portNumber = bridgeTr.vlanPortGet (param, "Name")

            if(bridgeModeRow["status"] == "1") then
                if(util.fileExists("/pfrm2.0/HW_HG260ES") or util.fileExists("/pfrm2.0/DUAL_ONLY")) then
                    if(bridgeModeRow["portNumber"] == "1") then
                        bridgeModeRow["portNumber"] = "3"
                    elseif(bridgeModeRow["portNumber"] == "2") then
                        bridgeModeRow["portNumber"] = "2"
                    elseif(bridgeModeRow["portNumber"] == "3") then
                        bridgeModeRow["portNumber"] = "1"
                    end
                end

                if(chipsetInfo == "econet"  and (not (util.fileExists("/pfrm2.0/HW_JCO4032") or util.fileExists("/pfrm2.0/HW_JCOW407") or util.fileExists("/pfrm2.0/HW_JCOW402")))) then
                    bridgeModeRow["portNumber"] = tonumber(bridgeModeRow["portNumber"]) - 2
                end

                if(tonumber(bridgeModeRow["portNumber"]) == portNumber)then
                    value = "eth0."..bridgeModeRow["vlanID"]
                else
                    value = ""
                end
            else
                value = ""
            end
        elseif(string.find(input["param"], "LowerLayers")) then
            -- LowerLayers
            value = "Device.Ethernet.Interface.2."
        elseif(string.find(input["param"], "ManagementPort")) then
            -- ManagementPort
            value = "0"
        elseif(string.find(input["param"], "PortState")) then
            -- PortState
            value = "Forwarding"
        elseif(string.find(input["param"], "PVID")) then
            -- PVID
            portNumber = bridgeTr.vlanPortGet (param, "PVID")

            if(bridgeModeRow["status"] == "1") then
                if(util.fileExists("/pfrm2.0/HW_HG260ES") or util.fileExists("/pfrm2.0/DUAL_ONLY")) then
                    if(bridgeModeRow["portNumber"] == "1") then
                        bridgeModeRow["portNumber"] = "3"
                    elseif(bridgeModeRow["portNumber"] == "2") then
                        bridgeModeRow["portNumber"] = "2"
                    elseif(bridgeModeRow["portNumber"] == "3") then
                        bridgeModeRow["portNumber"] = "1"
                    end
                end

                if(chipsetInfo == "econet"  and (not( util.fileExists("/pfrm2.0/HW_JCO4032") or util.fileExists("/pfrm2.0/HW_JCOW407") or util.fileExists("/pfrm2.0/HW_JCOW402")))) then
                    bridgeModeRow["portNumber"] = tonumber(bridgeModeRow["portNumber"]) - 2
                end

                if(tonumber(bridgeModeRow["portNumber"]) == portNumber)then
                    value = bridgeModeRow["vlanID"]
                else
                    value = ""
                end
            else
                value = ""
            end
        elseif(string.find(input["param"], "AcceptableFrameTypes")) then
            -- AcceptableFrameTypes
            value = "AdmitAll"
        elseif(string.find(input["param"], "IngressFiltering")) then
            -- IngressFiltering
            value = "0"
        elseif(string.find(input["param"], "PriorityTagging")) then
            -- PriorityTagging
            value = "0"
        else
            return "1", "DB_ERROR_TRY_AGAIN"
        end
    end

    return status, value
end

--[[
--*****************************************************************************
-- bridgeTr.bridgePortSet - set Port configuration
-- 
-- TR69 Parameter: Device.Bridging.Bridge.0.Port.0
--
]]--

function bridgeTr.bridgePortSet (input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering bridgePortSet..")

    if(util.fileExists("/pfrm2.0/BRIDGE_MODE") or util.fileExists("/pfrm2.0/GPON_ONLY") or util.fileExists("/pfrm2.0/GPON_ONLY_NEW")) then
        require "teamf1lualib/swVlan"
        require "teamf1lualib/ethernet"

        local status = OK
        local rowId = nil
        local query = nil
        local faultTbl = {}
        local index = 0
        local LogicalIfName = "IF1"
    
        --load instanceMap
        local instanceMap = tr69Glue.instanceMapLoad()
        if (instanceMap == nil) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl;
        end

        --read the rowId mapping to bridgeModePorts
        rowId = instanceMap[tr69Param]
        if (rowId == nil) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl;
        end

        --get correspnding db entry from bridgeModePorts 
        query = "_ROWID_=" .. rowId
        bridgingPortsRow = db.getRowWhere ("bridgeModePorts", query, false)
        if(bridgingPortsRow == nil) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl;
        end

        --get the db entry from bridgePorts 
        query = "interfaceName='eth1'"
        bridgePortsRow = db.getRowWhere ("bridgePorts", query, false)
        if(bridgePortsRow == nil) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl;
        end

        --get the db entry from vlanEncapIf and ethernetVLAN 
        local vlanRows = db.getRows ("vlanEncapIf", "LogicalIfName", LogicalIfName)
        local ethernetVLANRow = db.getTable ("ethernetVLAN", false)
                
        -- getting default values 
        local inputTableDefault = {}
        inputTableDefault["portMembers"] = {}

        -- for port 1/2/3
        for k,v in pairs(vlanRows) do
            if(string.find(v["vlanEncapIf.fwdMap"], "1")) then
                inputTableDefault["portAssoc1"] = "1"
                inputTableDefault["portMembers1"] = v["vlanEncapIf.vlanId"]
                inputTableDefault["portMembers"][1] = tonumber(v["vlanEncapIf.vlanId"])
            end
            if(string.find(v["vlanEncapIf.fwdMap"], "2")) then
                inputTableDefault["portAssoc2"] = "1"
                inputTableDefault["portMembers2"] = v["vlanEncapIf.vlanId"]
                inputTableDefault["portMembers"][2] = tonumber(v["vlanEncapIf.vlanId"])
            end
            if(string.find(v["vlanEncapIf.fwdMap"], "3")) then
                inputTableDefault["portAssoc3"] = "1"
                inputTableDefault["portMembers3"] = v["vlanEncapIf.vlanId"]
                inputTableDefault["portMembers"][3] = tonumber(v["vlanEncapIf.vlanId"])
            end
        end

        for k,v in pairs(vlanRows) do
            if(string.find(v["vlanEncapIf.untagMap"], "1")) then
                inputTableDefault["portDefault1"] = v["vlanEncapIf.vlanId"] 
            end
            if(string.find(v["vlanEncapIf.untagMap"], "2")) then
                inputTableDefault["portDefault2"] = v["vlanEncapIf.vlanId"]
            end
            if(string.find(v["vlanEncapIf.untagMap"], "3")) then
                inputTableDefault["portDefault3"] = v["vlanEncapIf.vlanId"]
            end
        end

        -- for port 4
        inputTableDefault["portAssoc4"] = bridgePortsRow["portEnabled"]
        if(#ethernetVLANRow == 0) then
            -- port 4 is untagged
            inputTableDefault["portDefault4"] = "0"
        else
            -- port 4 is tagged
            for k,v in pairs(ethernetVLANRow) do
                inputTableDefault["portDefault4"] = "1"
                inputTableDefault["portMembers4"] = v["vlanId"]
                inputTableDefault["portMembers"][4] = tonumber(v["vlanId"])
                break;
            end
        end

        local portMemRowId = tonumber(rowId)
        portAssoc = "portAssoc"..rowId
        portDefault = "portDefault"..rowId
        portMembers = "portMembers"..rowId

        -- get the user configured values and set the inputTable
        local inputTable = {}
        inputTable["portMembers"] = {}
        
        -- configure Enable
        if(util.fileExists("/pfrm2.0/BRIDGE_MODE")) then
            if(input["bridgeModePorts"]["bridgeModePorts.Enable"] == "1" and input["bridgeModePorts"]["bridgeModePorts.PVID"] == nil) then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Enable", error_code.REQUEST_DENIED)
                tr69Glue.tf1Dbg("cannot enable port without PVID..")
            end
        end

        inputTable[portAssoc] = input["bridgeModePorts"]["bridgeModePorts.Enable"] or inputTableDefault[portAssoc]

        if(inputTable[portAssoc] == "0") then
            for k,v in pairs(vlanRows) do
                if(string.find(v["vlanEncapIf.fwdMap"], "1") and rowId ~= "1") then
                    inputTable["portAssoc1"] = "1"
                    inputTable["portMembers1"] = v["vlanEncapIf.vlanId"]
                    inputTable["portMembers"][1] = tonumber(v["vlanEncapIf.vlanId"])
                end
                if(string.find(v["vlanEncapIf.fwdMap"], "2") and rowId ~= "2") then
                    inputTable["portAssoc2"] = "1"
                    inputTable["portMembers2"] = v["vlanEncapIf.vlanId"]
                    inputTable["portMembers"][2] = tonumber(v["vlanEncapIf.vlanId"])
                end
                if(string.find(v["vlanEncapIf.fwdMap"], "3") and rowId ~= "3") then
                    inputTable["portAssoc3"] = "1"
                    inputTable["portMembers3"] = v["vlanEncapIf.vlanId"]
                    inputTable["portMembers"][3] = tonumber(v["vlanEncapIf.vlanId"])
                end
            end
            
            for k,v in pairs(vlanRows) do
                if(string.find(v["vlanEncapIf.untagMap"], "1") and rowId ~= "1") then
                    inputTable["portDefault1"] = v["vlanEncapIf.vlanId"] 
                end
                if(string.find(v["vlanEncapIf.untagMap"], "2") and rowId ~= "2") then
                    inputTable["portDefault2"] = v["vlanEncapIf.vlanId"]
                end
                if(string.find(v["vlanEncapIf.untagMap"], "3") and rowId ~= "3") then
                    inputTable["portDefault3"] = v["vlanEncapIf.vlanId"]
                end
            end

            -- for port 4
            if(rowId ~= "4") then
                inputTable["portAssoc4"] = bridgePortsRow["portEnabled"]
            end
            if(#ethernetVLANRow == 0) then
                -- port 4 is untagged
                inputTable["portDefault4"] = "0"
            else
                -- port 4 is tagged
                for k,v in pairs(ethernetVLANRow) do
                    inputTable["portDefault4"] = "1"
                    inputTable["portMembers4"] = v["vlanId"]
                    inputTable["portMembers"][4] = tonumber(v["vlanId"])
                    break;
                end
            end
        else
            inputTable = inputTableDefault
            inputTable[portAssoc] = input["bridgeModePorts"]["bridgeModePorts.Enable"] or inputTableDefault[portAssoc]

            if(rowId ~= "4") then
                if(inputTable[portDefault] == nil or inputTable[portDefault] == "") then
                    inputTable[portDefault] = input["bridgeModePorts"]["bridgeModePorts.PVID"]
                end
            end
        end

        -- configure PVID
        if(input["bridgeModePorts"]["bridgeModePorts.PVID"] ~= nil) then
            -- return error if PVID is not present in vlanEncapIf tbl
            vlanFlag = 0
            for k,v in pairs (vlanRows) do
                if(tonumber(input["bridgeModePorts"]["bridgeModePorts.PVID"]) == tonumber(v["vlanEncapIf.vlanId"])) then
                    vlanFlag = 1
                end
            end

            if(vlanFlag == 0) then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."PVID", error_code.INVALID_PARAM_VALUE)
                tr69Glue.tf1Dbg("configured VLAN is not available")
            else
                -- As there is no support to configure multiple vlans for single port from
                -- ACS server, return error if port is associated with multiple vlans
                if(rowId == "4") then
                    -- for port 4
                    -- if ethernetVLAN has only one row, set PVID else return error
                    if(#ethernetVLANRow > 1) then
                        status = ERROR
                        index = index + 1
                        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."PVID", error_code.REQUEST_DENIED)
                        tr69Glue.tf1Dbg("port "..rowId.." is associated with multiple vlans..")
                    elseif(#ethernetVLANRow == 1 or (input["bridgeModePorts"]["bridgeModePorts.PriorityTagging"] ~= nil and input["bridgeModePorts"]["bridgeModePorts.PriorityTagging"] == "1")) then
                        inputTable[portDefault] = "1" 
                        inputTable[portMembers] = input["bridgeModePorts"]["bridgeModePorts.PVID"]
                        inputTable["portMembers"][portMemRowId] = tonumber(input["bridgeModePorts"]["bridgeModePorts.PVID"])
                    else
                        status = ERROR
                        index = index + 1
                        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."PVID", error_code.REQUEST_DENIED)
                        tr69Glue.tf1Dbg("cannot set pvid if PriorityTagging is not set to 1") 
                    end
                else
                    -- for port 1/2/3
                    -- if vlanEncapIf has one port associated with multiple vlans return error
                    local vlanCount = 0
                    for k,v in pairs(vlanRows) do
                        if(string.find(v["vlanEncapIf.fwdMap"], rowId)) then
                            vlanCount = vlanCount + 1
                        end
                    end
                    
                    if(vlanCount > 1) then
                        status = ERROR
                        index = index + 1
                        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."PVID", error_code.REQUEST_DENIED)
                        tr69Glue.tf1Dbg("port "..rowId.." is associated with multiple vlans..")
                    else
                        for k,v in pairs(vlanRows) do
                            if(string.find(v["vlanEncapIf.untagMap"], rowId)) then
                                inputTable[portDefault] = input["bridgeModePorts"]["bridgeModePorts.PVID"]
                                break;
                            end
                        end
                        inputTable[portMembers] = input["bridgeModePorts"]["bridgeModePorts.PVID"]
                        inputTable["portMembers"][portMemRowId] = tonumber(input["bridgeModePorts"]["bridgeModePorts.PVID"])
                    end
                end
            end
        end

        -- configure PriorityTagging
        -- return error if user is setting PriorityTagging as 0 without giving
        -- PVID
        if(input["bridgeModePorts"]["bridgeModePorts.PriorityTagging"] ~= nil) then
            if(input["bridgeModePorts"]["bridgeModePorts.PriorityTagging"] == "1") then
                inputTable[portDefault] = "0"
                if(rowId == "4") then
                    inputTable[portDefault] = "1"
                end
            else
                inputTable[portDefault] = input["bridgeModePorts"]["bridgeModePorts.PVID"] or inputTableDefault[portMembers]
                if(rowId == "4") then
                    inputTable[portDefault] = "0"
                end
            end
        end

        tr69Glue.tf1Dbg("inputTable to set vlan conf : " ..util.tableToStringRec(inputTable))

        if (status ~= OK) then
            tr69Glue.tf1Dbg("return error.. status = "..status)
            return status, faultTbl
        end
       
        -- to save the configuration
        local fwdMap = ""
        local unTagMap = ""
        
        for k,v in pairs (vlanRows) do
            v["vlanEncapIf.fwdMap"] = ""
            v["vlanEncapIf.untagMap"] = ""
            for i=1,3 do
                local portMembers = {}
                if (inputTable["portMembers"][i] ~= nil) then
                    portMembers = util.split (inputTable["portMembers"][i],",")
                    for kk,vv in pairs(portMembers) do
                        if (vv == v["vlanEncapIf.vlanId"]) then
                            if (v["vlanEncapIf.fwdMap"] == "") then
                                v["vlanEncapIf.fwdMap"] = i
                            else
                                v["vlanEncapIf.fwdMap"] = v["vlanEncapIf.fwdMap"]..","..i
                            end
                        end
                    end
                end
                if (inputTable["portDefault"..i] == v["vlanEncapIf.vlanId"]) then
                    if (v["vlanEncapIf.untagMap"] == "") then
                        v["vlanEncapIf.untagMap"] = i
                    else
                        v["vlanEncapIf.untagMap"] = v["vlanEncapIf.untagMap"]..","..i
                    end
                end
            end
           
            if(util.fileExists("/pfrm2.0/BRIDGE_MODE")) then
                if (v["vlanEncapIf.untagMap"] ~= "" and v["vlanEncapIf.untagMap"] ~= v["vlanEncapIf.fwdMap"]) then
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."PVID", error_code.REQUEST_DENIED)
                    tr69Glue.tf1Dbg("Individual port can not be associated differently from other ports for specific vlanId..")
                    break;
                end
            end
            
            statusCode, errCode = swMgr.dbConfig ("vlanEncapIf", v, v["vlanEncapIf._ROWID_"], "edit")
            
            if (statusCode == "OK") then
                statusCode = ethernetVLAN.lanPort4VLANUpdate (inputTable, nil, "edit")
            end
        end

        if (statusCode == "OK") then
            db.save()
        end
    else
        require "teamf1lualib/swVlan"

        local chipsetInfo = db.getAttribute("chipsetInfo", "_ROWID_", "1", "Chipset")

        local vlanIndex = 0 
        if (util.fileExists("/pfrm2.0/HW_FOXCONN_JCO500") or util.fileExists("/pfrm2.0/HW_FOXCONN") or util.fileExists("/pfrm2.0/HW_JCO110") or chipsetInfo == "Lantiq" or chipsetInfo == "Marvell") then

            vlanIndex = 3
        else
            vlanIndex = 4
        end

        local status = OK
        local rowId = nil
        local query = nil
        local faultTbl = {}
        local index = 0
        local LogicalIfName = "IF2"
    
        rowIdTbl = util.split(tr69Param, ".")
        rowId = rowIdTbl[6]

        --get the db entry from vlanEncapIf 
        local vlanRows = db.getRows ("vlanEncapIf", "LogicalIfName", LogicalIfName)
                
        -- getting default values 
        local inputTableDefault = {}
        inputTableDefault["portMembers"] = {}

        -- for port 1/2/3/4
        for k,v in pairs(vlanRows) do
            if(string.find(v["vlanEncapIf.fwdMap"], "1")) then
                inputTableDefault["portAssoc1"] = "1"
                inputTableDefault["portMembers1"] = v["vlanEncapIf.vlanId"]
                inputTableDefault["portMembers"][1] = tonumber(v["vlanEncapIf.vlanId"])
            end
            if(string.find(v["vlanEncapIf.fwdMap"], "2")) then
                inputTableDefault["portAssoc2"] = "1"
                inputTableDefault["portMembers2"] = v["vlanEncapIf.vlanId"]
                inputTableDefault["portMembers"][2] = tonumber(v["vlanEncapIf.vlanId"])
            end
            if(string.find(v["vlanEncapIf.fwdMap"], "3")) then
                inputTableDefault["portAssoc3"] = "1"
                inputTableDefault["portMembers3"] = v["vlanEncapIf.vlanId"]
                inputTableDefault["portMembers"][3] = tonumber(v["vlanEncapIf.vlanId"])
            end
            if(vlanIndex == 4) then
                if(string.find(v["vlanEncapIf.fwdMap"], "4")) then
                    inputTableDefault["portAssoc4"] = "1"
                    inputTableDefault["portMembers4"] = v["vlanEncapIf.vlanId"]
                    inputTableDefault["portMembers"][4] = tonumber(v["vlanEncapIf.vlanId"])
                end
            end
        end

        for k,v in pairs(vlanRows) do
            if(string.find(v["vlanEncapIf.untagMap"], "1")) then
                inputTableDefault["portDefault1"] = v["vlanEncapIf.vlanId"] 
            end
            if(string.find(v["vlanEncapIf.untagMap"], "2")) then
                inputTableDefault["portDefault2"] = v["vlanEncapIf.vlanId"]
            end
            if(string.find(v["vlanEncapIf.untagMap"], "3")) then
                inputTableDefault["portDefault3"] = v["vlanEncapIf.vlanId"]
            end
            if(vlanIndex == 4) then
                if(string.find(v["vlanEncapIf.untagMap"], "4")) then
                    inputTableDefault["portDefault4"] = v["vlanEncapIf.vlanId"]
                end
            end
        end

        portAssoc = "portAssoc"..rowId
        portDefault = "portDefault"..rowId
        portMembers = "portMembers"..rowId

        -- get the user configured values and set the inputTable
        local inputTable = {}
        inputTable["portMembers"] = {}
        
        -- configure Enable
        inputTable[portAssoc] = input["bridgeModePorts"]["bridgeModePorts.Enable"] or inputTableDefault[portAssoc]

        if(inputTable[portAssoc] == "0") then
            for k,v in pairs(vlanRows) do
                if(string.find(v["vlanEncapIf.fwdMap"], "1") and rowId ~= "1") then
                    inputTable["portAssoc1"] = "1"
                    inputTable["portMembers1"] = v["vlanEncapIf.vlanId"]
                    inputTable["portMembers"][1] = tonumber(v["vlanEncapIf.vlanId"])
                end
                if(string.find(v["vlanEncapIf.fwdMap"], "2") and rowId ~= "2") then
                    inputTable["portAssoc2"] = "1"
                    inputTable["portMembers2"] = v["vlanEncapIf.vlanId"]
                    inputTable["portMembers"][2] = tonumber(v["vlanEncapIf.vlanId"])
                end
                if(string.find(v["vlanEncapIf.fwdMap"], "3") and rowId ~= "3") then
                    inputTable["portAssoc3"] = "1"
                    inputTable["portMembers3"] = v["vlanEncapIf.vlanId"]
                    inputTable["portMembers"][3] = tonumber(v["vlanEncapIf.vlanId"])
                end
                if(vlanIndex == 4) then
                    if(string.find(v["vlanEncapIf.fwdMap"], "4") and rowId ~= "4") then
                        inputTable["portAssoc4"] = "1"
                        inputTable["portMembers4"] = v["vlanEncapIf.vlanId"]
                        inputTable["portMembers"][4] = tonumber(v["vlanEncapIf.vlanId"])
                    end
                end
            end
            
            for k,v in pairs(vlanRows) do
                if(string.find(v["vlanEncapIf.untagMap"], "1") and rowId ~= "1") then
                    inputTable["portDefault1"] = v["vlanEncapIf.vlanId"] 
                end
                if(string.find(v["vlanEncapIf.untagMap"], "2") and rowId ~= "2") then
                    inputTable["portDefault2"] = v["vlanEncapIf.vlanId"]
                end
                if(string.find(v["vlanEncapIf.untagMap"], "3") and rowId ~= "3") then
                    inputTable["portDefault3"] = v["vlanEncapIf.vlanId"]
                end
                if(vlanIndex == 4) then
                    if(string.find(v["vlanEncapIf.untagMap"], "4") and rowId ~= "4") then
                        inputTable["portDefault4"] = v["vlanEncapIf.vlanId"]
                    end
                end
            end
        else
            inputTable = inputTableDefault
            inputTable[portAssoc] = input["bridgeModePorts"]["bridgeModePorts.Enable"] or inputTableDefault[portAssoc]
        end

        tr69Glue.tf1Dbg("inputTable to set vlan conf : " ..util.tableToStringRec(inputTable))

        if (status ~= OK) then
            tr69Glue.tf1Dbg("return error.. status = "..status)
            return status, faultTbl
        end

        -- to save the configuration
        local WIFIPORT = "7,8,9"

        for k,v in pairs (vlanRows) do
            v["vlanEncapIf.fwdMap"] = ""
            v["vlanEncapIf.untagMap"] = ""
            local index = vlanIndex
            for i=1,index do
                local portMembers = {}
                if (inputTable["portMembers"][i] ~= nil) then
                    portMembers = util.split (inputTable["portMembers"][i],",")
                    for kk,vv in pairs(portMembers) do
                        if (vv == v["vlanEncapIf.vlanId"]) then
                            if (v["vlanEncapIf.fwdMap"] == "") then
                                v["vlanEncapIf.fwdMap"] = i
                            else
                                v["vlanEncapIf.fwdMap"] = v["vlanEncapIf.fwdMap"]..","..i
                            end
                        end
                    end
                end
                if (inputTable["portDefault"..i] == v["vlanEncapIf.vlanId"]) then
                    if (v["vlanEncapIf.untagMap"] == "") then
                        v["vlanEncapIf.untagMap"] = i
                    else
                        v["vlanEncapIf.untagMap"] = v["vlanEncapIf.untagMap"]..","..i
                    end
                end
            end

            if(chipsetInfo == "Lantiq") then
                if (v["vlanEncapIf.vlanId"] == "1")then
                    if (v["vlanEncapIf.fwdMap"] == "") then
                        v["vlanEncapIf.fwdMap"] = WIFIPORT
                    else
                        v["vlanEncapIf.fwdMap"] = v["vlanEncapIf.fwdMap"]..","..WIFIPORT
                    end
                    if (v["vlanEncapIf.untagMap"] == "") then
                        v["vlanEncapIf.untagMap"] = WIFIPORT
                    else            
                        v["vlanEncapIf.untagMap"] = v["vlanEncapIf.untagMap"]..","..WIFIPORT
                    end
                end
            end

            statusCode, errCode = swMgr.dbConfig ("vlanEncapIf", v, v["vlanEncapIf._ROWID_"], "edit")

            if(chipsetInfo == "Lantiq" or chipsetInfo == "Broadcom") then
                local cmd = "/pfrm2.0/bin/vlanUpdate.sh DEL " .. v["vlanEncapIf.vlanId"] .. " > /dev/null 2>&1"
                os.execute(cmd)
                local cmd = "/pfrm2.0/bin/vlanUpdate.sh ADD " .. v["vlanEncapIf.vlanId"] .. " " .. v["vlanEncapIf.fwdMap"] .. " " .. v["vlanEncapIf.untagMap"] .. " > /dev/null 2>&1"
                os.execute(cmd)
            end
        end

        if(statusCode == "OK") then
            db.save()
            if(chipsetInfo == "Broadcom") then
                swMgr.l2_vlan_rules_update(1)
            end
        end
    end
        
    tr69Glue.tf1Dbg("Leaving bridgePortSet..")
    return status, faultTbl;
end

--[[
--*****************************************************************************
-- bridgeTr.bridgeVlanAdd - Add VLAN for BridgeMode configuration
-- 
-- This function is called to set the following parameters
-- Device.Bridging.Bridge.0.VLAN.0.
--
-- Enable
-- vlanID
-- Name
--
-- Returns: status
]]--
function bridgeTr.bridgeVlanAdd(input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering bridgeVlanAdd..")

    local status = "0"
    local errorFlag
    local row = {}
    local query = nil
    local insertFlag = "1"

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = "1"
        return "1";
    end

    -- Filling the parameters of bridgeModeVlan when Add Object for bridgeModeVlan is called
    rows = db.getTable ("bridgeModeVlan", false)
    tr69Glue.tf1Dbg("Number of Rows Present .." ..#rows)

    input["bridgeModeVlan.Enable"] = "0" 
    input["bridgeModeVlan.vlanID"] = "0" 
    input["bridgeModeVlan.Name"] = "VLAN" 

    if(#rows >= 1) then
        for k,v in pairs (rows) do
            if(input["bridgeModeVlan.vlanID"] == v["vlanID"]) then
                insertFlag = "0"
            end
        end
    end

    if(insertFlag == "1")then
        status = db.insert("bridgeModeVlan", input)
        if (status) then
            db.save ()
        end
    elseif(insertFlag == "0") then
        tr69Glue.tf1Dbg("Dublicate VLANID..")
        return error_code.REQUEST_DENIED;
    end

    tr69Glue.tf1Dbg("Leaving bridgeVlanAdd..")
    return 0;
end

--[[
--*****************************************************************************
-- bridgeTr.bridgeModeVlanGet - get VLAN configuration
-- 
-- TR69 Parameter: Device.Bridging.Bridge.0.VLAN.0
--
]]--

function bridgeTr.bridgeModeVlanGet (input)
    local status = "0"
    local value = "0"
    local rowId
    local row = {}
    local query = nil

    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --read the rowId mapping to bridgeModeVlan
    rowId = instanceMap[param]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from bridgeModeVlan
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("bridgeModeVlan", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get db entry from bridgeMode
    brModeRow = db.getRowWhere ("bridgeMode", "_ROWID_=1", false)
    if(brModeRow == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        if (util.fileExists("/pfrm2.0/MULTI_VLAN_BRIDGE")) then
            value = brModeRow["status"]
	else
            value = row["Enable"]
	end
    elseif(string.find(input["param"], "Name")) then
        -- Name
        value = row["Name"]
    elseif(string.find(input["param"], "VLANID")) then
        -- VLANID
        value = row["vlanID"]
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- bridgeTr.bridgeModeVlanSet - set VLAN configuration
-- 
-- TR69 Parameter: Device.Bridging.Bridge.0.VLAN.0
--
]]--

function bridgeTr.bridgeModeVlanSet (input, rowids, actionType, tr69Param)
    require "teamf1lualib/gui"

    local status = OK
    local row = {}
    local rowId
    local query = nil
    local bridgeModeVlanRow = {}
    local faultTbl = {}
    local index = 0

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --read the rowId mapping to bridgeModeVlan
    rowId = instanceMap[tr69Param]
    if (rowId == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get corresponding db entry from bridgeModeVlan
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("bridgeModeVlan", query, false)
    if(row == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    bridgeModeVlanRow = row

    if (input["bridgeModeVlan"]["bridgeModeVlan.Enable"] ~= nil) then
        bridgeModeVlanRow["Enable"] = input["bridgeModeVlan"]["bridgeModeVlan.Enable"]
    end

    if (input["bridgeModeVlan"]["bridgeModeVlan.Name"] ~= nil) then
        bridgeModeVlanRow["Name"] = input["bridgeModeVlan"]["bridgeModeVlan.Name"]
    end

    if (input["bridgeModeVlan"]["bridgeModeVlan.vlanID"] ~= nil) then
        -- do the sanity checks
        local invalid_vlanId = OK
        local wanVlanRows = db.getRows ("ethernetVLAN", "vlanId", input["bridgeModeVlan"]["bridgeModeVlan.vlanID"])
        if (#wanVlanRows ~= 0) then
            tr69Glue.tf1Dbg("selected vlanID present on WAN..")
            invalid_vlanId = ERROR
            status = ERROR
        end
        
        local lanVlanRows = db.getRows ("vlanEncapIf", "vlanId", input["bridgeModeVlan"]["bridgeModeVlan.vlanID"])
        if (#lanVlanRows ~= 0) then
            tr69Glue.tf1Dbg("selected vlanID present on LAN..")
            status = ERROR
            invalid_vlanId = ERROR
        end

        -- Check Duplicate VlanIds in the given bridgeMode Vlans.
        local vlanRows = db.getTable("bridgeModeVlan", false)
        if(input["bridgeModeVlan"]["bridgeModeVlan.vlanID"] ~= "0") then
            for k,v in pairs (vlanRows) do
                if(input["bridgeModeVlan"]["bridgeModeVlan.vlanID"] == v["vlanID"]) then
                    tr69Glue.tf1Dbg("Dublicate VlanID..")
                    status = ERROR
                    invalid_vlanId = ERROR
                end
            end
        end

        local gponRow = db.getRow ("gpon", "_ROWID_", "1")
        if ((gponRow["gpon.status"] == "1") and gponRow ~= nil and (gponRow["gpon.vlanStatus"] == "1") and (gponRow["gpon.vlanID"] == input["bridgeModeVlan"]["bridgeModeVlan.vlanID"])) then
            tr69Glue.tf1Dbg("selected vlanID present on GPON..")
            status = ERROR 
            invalid_vlanId = ERROR
        end
        
        -- range check
        if (util.fileExists("/pfrm2.0/BRCMJCO300")) then
            if( (tonumber(input["bridgeModeVlan"]["bridgeModeVlan.vlanID"]) == 0) or ((tonumber(input["bridgeModeVlan"]["bridgeModeVlan.vlanID"]) > VLANID_MIN_VAL) and (tonumber(input["bridgeModeVlan"]["bridgeModeVlan.vlanID"]) < (VLANID_MAX_VAL - 1)))) then
                bridgeModeVlanRow["vlanID"] = input["bridgeModeVlan"]["bridgeModeVlan.vlanID"]
            else
                status = ERROR
                invalid_vlanId = ERROR
            end
        else
            if((tonumber(input["bridgeModeVlan"]["bridgeModeVlan.vlanID"]) > VLANID_MIN_VAL) and (tonumber(input["bridgeModeVlan"]["bridgeModeVlan.vlanID"]) < (VLANID_MAX_VAL - 1))) then
                bridgeModeVlanRow["vlanID"] = input["bridgeModeVlan"]["bridgeModeVlan.vlanID"]
            else
                status = ERROR
                invalid_vlanId = ERROR
            end
        end


        if(invalid_vlanId == ERROR) then
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."VLANID", error_code.INVALID_PARAM_VALUE)
            return status, faultTbl;
        end
    end

    if (util.fileExists("/pfrm2.0/BRCMJCO300")) then
        local inputTbl = {}

        --get db entry from bridgeMode
        local query = "_ROWID_=1"
        local bridgeModeRow = db.getRowWhere ("bridgeMode", query, false)

        if(bridgeModeRow == nil) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl;
        end
        if (bridgeModeRow["status"] ~= "1") then
            status = ERROR
            index = index + 1
            if (input["bridgeModeVlan"]["bridgeModeVlan.vlanID"] ~= nil) then
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."VLANID", error_code.REQUEST_DENIED)
            elseif (input["bridgeModeVlan"]["bridgeModeVlan.Name"] ~= nil) then
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Name", error_code.REQUEST_DENIED)
            end
            return status, faultTbl;
        end

        local rowVlan = db.getTable ("bridgeModeVlan", false)
    
        tr69Glue.tf1Dbg("rowVlan == " .. util.tableToStringRec(rowVlan))
        for k,v in pairs(rowVlan) do
            inputTbl["vlanId"..k] = v["vlanID"] 
            inputTbl["Name"..k] = v["Name"] 
        end

        inputTbl["portNumber"] = bridgeModeRow["portNumber"]
        inputTbl["bridgeModeStatus"] = bridgeModeRow["status"]
        inputTbl["vlanId"..rowId] = bridgeModeVlanRow["vlanID"]
        inputTbl["Name"..rowId] = bridgeModeVlanRow["Name"]

        tr69Glue.tf1Dbg("inputTbl == " .. util.tableToStringRec(inputTbl))

        local errMsg, statusMsg = gui.networking.bridgeModeAE.set (inputTbl, dbFlag)
        if (errMsg ~= "OK") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl;
        end
    else
        if (input["bridgeModeVlan"]["bridgeModeVlan.vlanID"] ~= nil) then
            --get db entry from bridgeMode
            local query = "_ROWID_=1"
            local bridgeModeRow = db.getRowWhere ("bridgeMode", query, false)

            local queryOld = "_ROWID_=" .. rowId
            local rowOld = db.getRowWhere ("bridgeModeVlan", queryOld, false)

            -- update the vlan ID in bridgeMode table
            if(rowOld["vlanID"] == bridgeModeRow["vlanID"]) then
                bridgeModeRow["vlanID"] = input["bridgeModeVlan"]["bridgeModeVlan.vlanID"]
                bridgeModeRow = util.addPrefix(bridgeModeRow, "bridgeMode.")
                valid, errstr = db.update("bridgeMode", bridgeModeRow, bridgeModeRow["bridgeMode._ROWID_"])
            end
        end

        -- update the vlan id in bridgeModeVlan table
        bridgeModeVlanRow = util.addPrefix(bridgeModeVlanRow, "bridgeModeVlan.")
        valid, errstr = db.update("bridgeModeVlan", bridgeModeVlanRow, bridgeModeVlanRow["bridgeModeVlan._ROWID_"])
        if (not valid) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl;
        end         
    end
 
    db.save()

    tr69Glue.tf1Dbg("Leaving bridgeModeSet..")
    return status, faultTbl;

end

--[[
--*****************************************************************************
-- bridgeTr.getVLANObj - get VLAN object instance name
-- 
-- Returns: VlanObjInstanceName or nil
]]--
function bridgeTr.getVLANObj(vlanID)
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return nil
    end
    local VlanObj = "Device.Bridging.Bridge.1.VLAN."

    --get correspnding db entry from bridgeModeVlan 
    local bridgeModeVlanRow = {}
    local query = nil
    local mainVal = nil

    query = "vlanID='" .. vlanID .. "'"
    bridgeModeVlanRow = db.getRowWhere ("bridgeModeVlan", query, false)
    if(bridgeModeVlanRow == nil) then
        return nil 
    end

    for name,val in pairs (instanceMap) do
        if(string.find(name, "Device.Bridging.Bridge.1.VLAN.") and (not(string.find(name, "VLANPort")))) then
            if(tonumber(val) == tonumber(bridgeModeVlanRow["_ROWID_"])) then
                local startIdx, endIdx
                startIdx, endIdx = string.find(name, "VLAN.")
                mainVal = string.sub(name, 1, endIdx+2)
                break ; 
            end
        end
    end

    return mainVal
end

--[[
--*****************************************************************************
-- bridgeTr.getVLANObjs - get VLAN object instance name
-- 
-- Returns: VlanObjInstanceName or nil
]]--
function bridgeTr.getVLANObjs(vlanID)
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return nil
    end

    local i = 1;
    for name,val in pairs (instanceMap) do
        if(string.find(name, "Device.Bridging.Bridge.1.VLAN.") and (not(string.find(name, "VLANPort")))) then
            if(string.find(name, "Name")) then
                mainVal = string.gsub(name, "Name", "")
                tr69Glue.tf1Dbg("i = " .. i)
                if(i == 1)then
                    value = mainVal
                    tr69Glue.tf1Dbg("val if = "..value)
                else
                    value = value..","..mainVal
                    tr69Glue.tf1Dbg("val else = "..value)
                end 
                i=1+1
            end
        end
    end
    
    tr69Glue.tf1Dbg("getVLANObjs val === " .. value)

    return value
end

--[[
--*****************************************************************************
-- bridgeTr.bridgeModeCfgGet - get bridgeMode configuration
-- 
-- TR69 Parameter: Device.Bridging.Bridge.0.VLANPort.0
--
]]--

function bridgeTr.bridgeModeCfgGet (input)
    local status = "0"
    local value = "0"
    local rowId
    local row = {}
    local query = nil
    local stat
    local errMsg

    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "VLANPort.")
    parentObjInstance = string.sub(param, 1, endIdx+2)

    --read the rowId mapping to bridgeMode
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from bridgeMode
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("bridgeMode", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    local chipsetInfo = db.getAttribute("chipsetInfo", "_ROWID_", "1", "Chipset")

    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = row["status"]
    elseif(string.find(input["param"], "Untagged")) then
        -- Untagged
        value = 1
    elseif(string.sub(input["param"], 37,40) == "VLAN") then
        -- VLAN
        local vlanRefObj = ""
        if (util.fileExists("/pfrm2.0/BRCMJCO300")) then
            vlanRefObj = bridgeTr.getVLANObjs(row["vlanID"])
        else
            vlanRefObj = bridgeTr.getVLANObj(row["vlanID"])
        end
        
        if(vlanRefObj ~= nil) then
            value = vlanRefObj
        else
            value = ""
        end
    elseif(string.sub(input["param"], 37,40) == "Port") then
        -- Port
        if(util.fileExists("/pfrm2.0/BRIDGE_MODE")) then
            local bridgePortsRow = db.getRowWhere("bridgePorts", "interfaceName='eth1'", false)
            local vlanEncapTbl = db.getTable("vlanEncapIf", false)
            local portTbl = {}
            for k,v in pairs (vlanEncapTbl) do
                if(string.find(v["fwdMap"], "1")) then
                    portTbl[1] = "Device.Bridging.Bridge.1.Port.1."
                end
                if(string.find(v["fwdMap"], "2")) then
                    portTbl[2] = "Device.Bridging.Bridge.1.Port.2."
                end
                if(string.find(v["fwdMap"], "3")) then
                    portTbl[3] = "Device.Bridging.Bridge.1.Port.3."
                end
            end
            for k,v in pairs (portTbl) do
                if(k == 1) then
                    value = v
                else
                    value = value..","..v
                end
            end
            if(bridgePortsRow["portEnabled"] == "1") then
                value = value..",".."Device.Bridging.Bridge.1.Port.4."
            end
        else
            if(row["status"] == "1") then
                local port = row["portNumber"]
                if(util.fileExists("/pfrm2.0/HW_HG260ES") or util.fileExists("/pfrm2.0/DUAL_ONLY")) then
                    if(port == "1") then
                        value = "Device.Bridging.Bridge.1.Port.3."
                    elseif(port == "2") then
                        value = "Device.Bridging.Bridge.1.Port.2."
                    elseif(port == "3") then
                        value = "Device.Bridging.Bridge.1.Port.1."
                    end
                elseif(chipsetInfo == "econet" and (not (util.fileExists("/pfrm2.0/HW_JCO4032") or util.fileExists("/pfrm2.0/HW_JCOW407") or util.fileExists("/pfrm2.0/HW_JCOW402")))) then
                    if(port == "4") then
                        value = "Device.Bridging.Bridge.1.Port.1."
                    elseif(port == "3") then
                        value = "Device.Bridging.Bridge.1.Port.2."
                    end
                else
                    value = "Device.Bridging.Bridge.1.Port."..port.."."
                end
            else
                value = ""
            end
        end
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- bridgeTr.bridgeModeCfgSet - set bridgeMode configuration
-- 
-- TR69 Parameter: Device.Bridging.Bridge.0.VLANPort.0
--
]]--

function bridgeTr.bridgeModeCfgSet (input, rowids, actionType, tr69Param)
    require "teamf1lualib/gui"

    local status = OK
    local faultTbl = {}
    local index = 0
    local rowId
    local query = nil
    local row = {}
    local bridgeModeRow = {}
    local bridgeModeRowOld = {}
    local bridgeModeVlanRow = {}
    local bridgeModeVlanRowId = ""
    local vlanTr69Param = ""
    local disableVlanMem = 0

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --read the rowId mapping to Device.Bridging.Bridge.0.VLANPort.0.
    rowId = instanceMap[tr69Param]
    if (rowId == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    local chipsetInfo = db.getAttribute("chipsetInfo", "_ROWID_", "1", "Chipset")
    --get corresponding db entry from bridgeMode
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("bridgeMode", query, false)
    bridgeModeRowOld = db.getRowWhere ("bridgeMode", query, false)
    if(row == nil or bridgeModeRowOld == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    bridgeModeRow = row

    if (util.fileExists("/pfrm2.0/BRCMJCO300")) then
        rowVlan = db.getTable ("bridgeModeVlan", false)
    
        tr69Glue.tf1Dbg("rowVlan == " .. util.tableToStringRec(rowVlan))
        for k,v in pairs(rowVlan) do
            bridgeModeRow["vlanId"..k] = v["vlanID"] 
        end
    end
    
    tr69Glue.tf1Dbg("bridgeModeRow == " .. util.tableToStringRec(bridgeModeRow))

    -- Enable
    if (input["bridgeMode"]["bridgeMode.status"] ~= nil) then
        bridgeModeRow["status"] = input["bridgeMode"]["bridgeMode.status"]
        if(input["bridgeMode"]["bridgeMode.status"] == "0") then
            bridgeModeRow["portNumber"] = "1"
            bridgeModeRow["vlanID"] = "0"
        end
    end

    -- VLAN
    if(input["bridgeMode"]["bridgeMode.vlanID"] ~= nil) then
        if(bridgeModeRow["status"] == "1")then
            bridgeModeVlanRowId = instanceMap[input["bridgeMode"]["bridgeMode.vlanID"]]
            if (bridgeModeVlanRowId == nil) then
                tr69Glue.tf1Dbg("No instance found for vlanID -- " .. input["bridgeMode"]["bridgeMode.vlanID"])
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."VLAN", error_code.INVALID_PARAM_VALUE)
            else
                --get corresponding db entry from bridgeModeVlan
                query = "_ROWID_=" .. bridgeModeVlanRowId
                bridgeModeVlanRow = db.getRowWhere ("bridgeModeVlan", query, false)
                if(bridgeModeVlanRow == nil) then
                    tr69Glue.tf1Dbg("No entry in bridgeModeVlan with rowId -- " .. bridgeModeVlanRowId)
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."VLAN", error_code.INVALID_PARAM_VALUE)
                end
            end

            if(status == OK) then
                if(bridgeModeVlanRow["Enable"] == "1" and ((tonumber(bridgeModeVlanRow["vlanID"]) > VLANID_MIN_VAL) and (tonumber(bridgeModeVlanRow["vlanID"]) < (VLANID_MAX_VAL - 1)))) then
                    bridgeModeRow["vlanID"] = bridgeModeVlanRow["vlanID"]
                else
                    tr69Glue.tf1Dbg("Invalid VlanID..")
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."VLAN", error_code.INVALID_PARAM_VALUE)
                end
            end
        else
            tr69Glue.tf1Dbg("BridgeMode is disabled..")
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."VLAN", error_code.REQUEST_DENIED)
        end
    end

    -- Port
    if (input["bridgeMode"]["bridgeMode.portNumber"] ~= nil) then
        if(bridgeModeRow["status"] == "1") then
            if(util.fileExists("/pfrm2.0/HW_HG260ES") or util.fileExists("/pfrm2.0/DUAL_ONLY")) then
                if(input["bridgeMode"]["bridgeMode.portNumber"] == "Device.Bridging.Bridge.1.Port.1.") then
                    bridgeModeRow["portNumber"] = "3"
                elseif(input["bridgeMode"]["bridgeMode.portNumber"] == "Device.Bridging.Bridge.1.Port.2.") then
                    bridgeModeRow["portNumber"] = "2"
                elseif(input["bridgeMode"]["bridgeMode.portNumber"] == "Device.Bridging.Bridge.1.Port.3.") then
                    bridgeModeRow["portNumber"] = "1"
                else
                    tr69Glue.tf1Dbg("Invalid portNumber..")
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Port", error_code.INVALID_PARAM_VALUE)
                end
            elseif(chipsetInfo == "econet" and (not (util.fileExists("/pfrm2.0/HW_JCO4032") or util.fileExists("/pfrm2.0/HW_JCOW407") or util.fileExists("/pfrm2.0/HW_JCOW402")))) then
                if(input["bridgeMode"]["bridgeMode.portNumber"] == "Device.Bridging.Bridge.1.Port.1.") then
                    bridgeModeRow["portNumber"] = "4"
                elseif(input["bridgeMode"]["bridgeMode.portNumber"] == "Device.Bridging.Bridge.1.Port.2.") then
                    bridgeModeRow["portNumber"] = "3"
                else
                    tr69Glue.tf1Dbg("Invalid portNumber..")
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Port", error_code.INVALID_PARAM_VALUE)
                end
            else
                if(input["bridgeMode"]["bridgeMode.portNumber"] == "Device.Bridging.Bridge.1.Port.1.") then
                    bridgeModeRow["portNumber"] = "1"
                elseif(input["bridgeMode"]["bridgeMode.portNumber"] == "Device.Bridging.Bridge.1.Port.2.") then
                    bridgeModeRow["portNumber"] = "2"
                elseif(input["bridgeMode"]["bridgeMode.portNumber"] == "Device.Bridging.Bridge.1.Port.3.") then
                    bridgeModeRow["portNumber"] = "3"
                elseif(input["bridgeMode"]["bridgeMode.portNumber"] == "Device.Bridging.Bridge.1.Port.4.") then
                    bridgeModeRow["portNumber"] = "4"
                else
                    tr69Glue.tf1Dbg("Invalid portNumber..")
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Port", error_code.INVALID_PARAM_VALUE)
                end
            end

            if((not util.fileExists("/pfrm2.0/BRIDGE_MODE")) and status == OK) then
                lanVlanRows = db.getTable("vlanEncapIf")
                for k,v in pairs (lanVlanRows) do
                    if ((string.find (v["vlanEncapIf.fwdMap"], bridgeModeRow["portNumber"]) ~= nil) or (bridgeModeRow["portNumber"] == "0")) then
                        tr69Glue.tf1Dbg("configured port present in fwd map, so disable it..")
                        disableVlanMem = 1
                        break;
                    end
                end

                if(disableVlanMem == 1) then
                    -- disable vlan membership
                    inTbl = {}
                    inTbl["vlanMembershipPort"] = {}
                    inTbl["vlanMembershipPort"]["vlanMembershipPort.PortEnable"] = "0" 
                        
                    tmpTbl = util.split(input["bridgeMode"]["bridgeMode.portNumber"], ".")
                    vlanTr69Param = "Device.Ethernet.X_RJIL_COM_VLANMembership."..tmpTbl[6].."."
                    
                    portSetStatus, portFaultTbl = nimfTr.VLANMembershipPortCfgSet (inTbl, nil, nil, vlanTr69Param)
                end
            end
        else
            tr69Glue.tf1Dbg("BridgeMode is disabled..")
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Port", error_code.REQUEST_DENIED)
        end
    end

    if(status == ERROR)then
        return status, faultTbl;
    end

    if (util.fileExists("/pfrm2.0/BRCMJCO300")) then
        bridgeModeRow["bridgeModeStatus"] = bridgeModeRow["status"]

        tr69Glue.tf1Dbg("bridgeModeRow == " .. util.tableToStringRec(bridgeModeRow))

        local errMsg, statusMsg = gui.networking.bridgeModeAE.set (bridgeModeRow, dbFlag)
        if (errMsg ~= "OK") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl;
        end
    else
        bridgeModeRow = util.addPrefix(bridgeModeRow, "bridgeMode.")
        local valid, errstr = db.update("bridgeMode", bridgeModeRow, bridgeModeRow["bridgeMode._ROWID_"])
        if (not valid) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl;
        end 
    end
 

    -- if bridge mode is disabled, then Enable vlan association for disabled
    -- port 
    if(input["bridgeMode"]["bridgeMode.status"] == "0") then
        if(util.fileExists("/pfrm2.0/HW_HG260ES") or util.fileExists("/pfrm2.0/DUAL_ONLY")) then
            if(bridgeModeRowOld["portNumber"] == "1")then
                bridgeModeRowOld["portNumber"] = "3"
            elseif(bridgeModeRowOld["portNumber"] == "3")then
                bridgeModeRowOld["portNumber"] = "1"
            end
        elseif(chipsetInfo == "econet"  and (not( util.fileExists("/pfrm2.0/HW_JCO4032") or util.fileExists("/pfrm2.0/HW_JCOW407") or util.fileExists("/pfrm2.0/HW_JCOW402"))) ) then
            if(bridgeModeRowOld["portNumber"] == "3")then
                bridgeModeRowOld["portNumber"] = "2"
            elseif(bridgeModeRowOld["portNumber"] == "4")then
                bridgeModeRowOld["portNumber"] = "1"
            end
        end

        inTbl = {}
        inTbl["vlanMembershipPort"] = {}
        inTbl["vlanMembershipPort"]["vlanMembershipPort.PortEnable"] = "1" 
        
        vlanTr69Param = "Device.Ethernet.X_RJIL_COM_VLANMembership."..bridgeModeRowOld["portNumber"].."."
        
        portSetStatus, portFaultTbl = nimfTr.VLANMembershipPortCfgSet (inTbl, nil, nil, vlanTr69Param)
    end

    db.save()
    
    tr69Glue.tf1Dbg("Leaving bridgeModeSet..")
    return status, faultTbl;
end

--[[
--*****************************************************************************
-- bridgeTr.bridgingGet- get Bridging configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.Bridging.
--
-- MaxBridgeEntries
-- MaxDBridgeEntrie
-- MaxQBridgeEntrie
--
-- Returns: status, value
]]--
function bridgeTr.bridgingGet(input)
    local status = "0"
    local value = "0"

    if(string.find(input["param"], "MaxBridgeEntries")) then
        -- MaxBridgeEntries
        value = "1" 
    elseif(string.find(input["param"], "MaxDBridgeEntries")) then
        -- MaxDBridgeEntrie
        value = "0" 
    elseif(string.find(input["param"], "MaxQBridgeEntries")) then
        -- MaxQBridgeEntries
        value = "1" 
    elseif(string.find(input["param"], "MaxVLANEntries")) then
        -- MaxVLANEntries
        value = "1" 
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- bridgeTr.bridgeCfgGet- get Bridge configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.Bridging.Bridge.0.
--
-- Enable
-- Status
-- Standard
--
-- Returns: status, value
]]--

function bridgeTr.bridgeCfgGet(input)
    local status = "0"
    local value = "0"

    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = "1" 
    elseif(string.find(input["param"], "Status")) then
        -- Status
        value = "Enabled"
    elseif(string.find(input["param"], "Standard")) then
        -- Standard
        value = "802.1Q-2011"
    else
         return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end
