-- utilsCLI.lua
-- Gaurav Mathur
-- TeamF1
-- www.TeamF1.com
--
-- Copyright (c) 2017, TeamF1 Networks Pvt. Ltd. 
-- (Subsidiary of D-Link India)
--
-- Modification History
-- 01d,08Aug17,swr  Changes for SPR 60819(health monitoring)
-- 01c,12dec16,asv  added changes for spr#54886
-- 01b,13feb07,ss   modified wepKeyGenerate() routine with higher level digest routine call.
-- 01a,23oct07,gnm  written
--
-- Description
-- Utility routines for CLI operation
--

--require "adpLuaLib"


USCORSTR="__________________________________________________"
SPACESTR="                              "

resTab = {}

function wepKeyLenGet(args)
    local encrMethod = args[1]
    local keyLen = 10 -- 10 HEX character

    if encrMethod == "152" then
	keyLen = 32 -- 32 HEX characters
    elseif encrMethod == "128" then
	keyLen = 26 -- 26 HEX characters
    elseif encrMethod == "64" then
	keyLen = 10 -- 10 HEX characters
    end
    return keyLen
end

--
-- Routine to generate a WEP key from a passphrase
-- Arguments: In table format..
-- <passphrase>: Passphrase to generate the key from
-- <keyLen>: Length of the key to return
function wepKeyGenerate (args)
    local retVal = nil
    local digestCtxId = nil
    
    local passphrase = args[1] -- passphrase argument value
    local keyLen = args[2] -- key length argument value

    adpLuaLib.lua_adpMD5Init()

    local retVal, digest, len = adpLuaLib.lua_adpDigest (passphrase, string.len(passphrase), "md5")
    local len, digest_hex = adpLuaLib.lua_adpBin2hex (digest, len)

    if (digest_hex == nil) then return "" end -- sanity check
    
    return string.sub (digest_hex, 1, keyLen)
end

--print a label with an underline
function printCLIError (errString)
    print (errString)
end

--print a label with an underline
function printLabel (lblString)
    print ("\n"..lblString)
    print (string.sub(USCORSTR, 0, string.len (lblString)))
end

--add a field to the result table
function resTab.insertField (resultTab, field, value)
   local found = 0

   -- find the row in resultTab that holds field values
   for i,v in pairs (resultTab) do
       if v[1] == field then
	  found = 1
	  table.insert (v, value)
       end
   end
   if found == 0 then 
      local num = table.maxn (resultTab)
      num = num + 1	    
      resultTab[num] = {}
      table.insert (resultTab[num], field)
      table.insert (resultTab[num], value)
   end
end

--add a field to the result table
function resTab.insertYNField (resultTab, exp, fldLbl, yesLbl, noLbl)
   if (fldLbl == nil) then return -1 end
   if (yesLbl == nil) then yesLbl = "Y" end
   if (noLbl == nil) then noLbl = "N" end
   if (exp == true) then 
        resTab.insertField (resultTab, fldLbl, yesLbl)
   elseif (exp == false) then
	resTab.insertField (resultTab, fldLbl, noLbl)
   else
	return -1
   end
   return 0
end

--create a result table with row labels
function resTab.createRowLbl (...)
    local resultTab = {}
	 
    for i,v in pairs{...} do
	resTab.insertField (resultTab, "ROW_LABEL", v)
    end
    return resultTab
end

--create a result table
function resTab.create ()
	 local resultTab = {}
	 return resultTab
end
	 
--Print a table with multiple rows
function printMR (printTab, numFields)
    local idx = 1
    local lstUSC = ""
    local fieldWidthTab = {}

    for i, v in pairs (printTab) do
        fieldWidthTab[i] = 0
	for ii,vv in pairs (v) do
	    if (string.len (vv) > fieldWidthTab[i]) then
	        fieldWidthTab[i] = string.len (vv)
	    end
	end
    end

    while (idx <= numFields) do
	local row = ""
	local fVal = ""
	for i,v in pairs (printTab) do
	    local lenDiff = fieldWidthTab[i] - string.len (v[idx])
	    fVal = v[idx] .. string.sub(SPACESTR, 0, lenDiff)
	    row = row .. " " .. fVal
	    --the first colum of printTab has the field labels. If
	    --we are dealing with that in this iteration we'll build
	    --the label underlines now
	    if (idx == 1) then 
	       lstUSC = lstUSC .. " " .. string.sub(USCORSTR, 0, fieldWidthTab[i])
	    end
	end
	print (row)
	--print label underlines
	if (idx == 1) then print (lstUSC) end
	idx = idx + 1
    end
end

--Print a table with a single row
function printSRFmt (printTab, Fmt)
      local row = ""
      
      for i,v in pairs (printTab) do
	  row = v[1] .. ": " .. v[2]
	  print (row)
      end
end

--Print a table with a single row
function printSR (printTab, width)
      local row = ""

      for i,v in pairs (printTab) do
	  row = v[1] .. ": " .. v[2]
	  print (row)
      end
end

--Print a table
function resTab.print (printTab, width)
    if printTab == nil then return -1 end --something wrong
    if printTab[1] == nil then return -1 end --something very wrong 

    local numFields = table.maxn (printTab[1])
    print () --display candy
    if (numFields == 2) then 
       printSR(printTab, width) --the print table has info one entity of an
			 --object type e.g a profile, an access points etc.
    else
       printMR(printTab, numFields) --the print table has info on a
				    --list of specific object types.
    end
    print () --display candy
end

