--[[
#### Sat
#### TeamF1
#### www.TeamF1.com
#### Jan 22, 2008

#### File: tcpdump.lua
#### Description: tcpdump functions

#### Revisions:
None
]]--

-- if not allowed to edit
--
if (ACCESS_LEVEL ~= 0 and ACCESS_LEVEL ~= 3) then
	errorFlag, statusMessage = -1, "Administrator Privileges Are Required"
	Page = "diagnosticsPtrace"
	web.goToPage(Page, true, true)
else

	if (util.fileExists ("/pfrm2.0/HW_HG261GU")) then
	status, freeMem = util.freeMemGet ()
	 if (freeMem ~= nil and tonumber (freeMem) < 20480 ) then

		-- user started packet capture when free was above 20 MB , but now it has fallen below 20 MB , so gracefully show error , do not start downlaod , as it can lead to oom panic 
        errorFlag, statusMessage = -1, "Device low on free memory . Please try after sometime"
	    Page = "diagnosticsPtrace"
		os.execute("/bin/rm -rf /var/pkt.cap");

		-- generate token 
    	os.execute("/pfrm2.0/bin/pwgen 64 1 > /tmp/htmlToken")
    	local tokenFile = io.open("/tmp/htmlToken", "r")             
    	if (tokenFile ~= nil) then                                              
        	token = tokenFile:read()                                               
        	if (token ~= nil) then
            	util.appendDebugOut("Token: " .. token)
        	end
    	end
    	tokenFile:close()
	    web.goToPage(Page, true, true)
	end
	end

    if (util.fileExists("/var/pkt.cap")) then
	    web.download("/var/pkt.cap","pkt.cap")
    else
        errorFlag, statusMessage = -1, "Packets are not captured. Please Try after some time."
	    Page = "diagnosticsPtrace"
	    web.goToPage(Page, true, true)
    end
end
