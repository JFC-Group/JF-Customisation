--[[
#### 
#### TeamF1
#### www.TeamF1.com
#### Mar 11, 2008
#### File: rip.lua
#### Description: RIP configuration functions
#### Revisions:
#### 01a,04may11,bng added config import/export for rip
]]--

--************* Requires *************

--************* Initial Code *************

--package RIP Configuration
rip = {}

--************* Functions *************
-- RIP Configuration
function rip.config (inputTable, rowid, operation)
    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
    	return "ACCESS_DENIED", "ADMIN_REQD"
    end

    -- Date Formatting
    if(inputTable["Rip.AuthenticationType"] == "1") then
        local dateRange = {"FirstKeyFrom","FirstKeyTo","SecondKeyFrom","SecondKeyTo"}
    	for k,v in pairs(dateRange) do
            local dateFormat = inputTable["Rip." .. v .. "3"] .. "/" .. inputTable["Rip." .. v .. "1"] .. "/" .. inputTable['Rip.' .. v .. '2']
            dateFormat = dateFormat .. "@" .. inputTable['Rip.'.. v .. '4'] .. ":" .. inputTable['Rip.'.. v .. '5'] .. ":" .. inputTable['Rip.'.. v .. '6']
    	    inputTable['Rip.' .. v] =  dateFormat
	    end
    end
		
    db.beginTransaction() --begin transaction
    local valid = false

    local Rowid = db.existsRow ("Rip", "_ROWID_", rowid)
    if(Rowid) then
 	    valid = rip.dbconfig(inputTable, rowid, "edit")
    else
    	valid = rip.dbconfig(inputTable, rowid, "add")
    end

    if(valid) then
 	    db.commitTransaction(true)
    	return "OK", "STATUS_OK"
    else
	    db.rollback()
    	return "ERROR", "RIP_CONFIG_FAILED"
    end
end

function rip.dbconfig(inputTable, rowid, operation)
    -- validate
    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
        	return db.insert("Rip", inputTable)
        elseif (operation == "edit") then
        	return db.update("Rip", inputTable, rowid)
        elseif (operation == "delete") then
   	        return db.delete("Rip", inputTable)
        end
    else
        return false
    end
end

function rip.configGet()

    --locals
	local ripTbl = {}
	local localTable = {}

	--getting the ipv6 info from the route6 table
	ripTbl = db.getTable("Rip", false)
	if (ripTbl == nil) then
		return localTable
	end

	--return
	return ripTbl

end


function rip.configurationGet()

     local FirstKeyFrom = {}
    local FirstKeyTo = {}
    local SecondKeyFrom = {}
    local SecondKeyTo = {}
    local RipTable = {}
    
    RipTable = db.getRowWhere("Rip", " _ROWID_=1", false)
    if(RipTable) then
        if(RipTable["FirstKeyFrom"] ~= nil and RipTable["FirstKeyFrom"] ~= "") then
            FirstKeyFrom = util.splitDateTime(RipTable["FirstKeyFrom"])

            RipTable.FirstKeyFrom1 = FirstKeyFrom[1]
            RipTable.FirstKeyFrom2 = FirstKeyFrom[2]
            RipTable.FirstKeyFrom3 = FirstKeyFrom[3]
            RipTable.FirstKeyFrom4 = FirstKeyFrom[4]
            RipTable.FirstKeyFrom5 = FirstKeyFrom[5]
            RipTable.FirstKeyFrom6 = FirstKeyFrom[6]
        end
        if(RipTable["FirstKeyTo"] ~= nil and RipTable["FirstKeyTo"] ~= "") then        
            FirstKeyTo = util.splitDateTime(RipTable["FirstKeyTo"])

            RipTable.FirstKeyTo1 = FirstKeyTo[1]
            RipTable.FirstKeyTo2 = FirstKeyTo[2]
            RipTable.FirstKeyTo3 = FirstKeyTo[3]
            RipTable.FirstKeyTo4 = FirstKeyTo[4]
            RipTable.FirstKeyTo5 = FirstKeyTo[5]
            RipTable.FirstKeyTo6 = FirstKeyTo[6]
        end
        if(RipTable["SecondKeyFrom"] ~= nil and RipTable["SecondKeyFrom"] ~= "") then        
            SecondKeyFrom = util.splitDateTime(RipTable["SecondKeyFrom"])

            RipTable.SecondKeyFrom1 = SecondKeyFrom[1]
            RipTable.SecondKeyFrom2 = SecondKeyFrom[2]
            RipTable.SecondKeyFrom3 = SecondKeyFrom[3]
            RipTable.SecondKeyFrom4 = SecondKeyFrom[4]
            RipTable.SecondKeyFrom5 = SecondKeyFrom[5]
            RipTable.SecondKeyFrom6 = SecondKeyFrom[6]
        end
        if(RipTable["SecondKeyTo"] ~= nil and RipTable["SecondKeyTo"] ~= "") then        
            SecondKeyTo = util.splitDateTime(RipTable["SecondKeyTo"])

            RipTable.SecondKeyTo1 = SecondKeyTo[1]
            RipTable.SecondKeyTo2 = SecondKeyTo[2]
            RipTable.SecondKeyTo3 = SecondKeyTo[3]
            RipTable.SecondKeyTo4 = SecondKeyTo[4]
            RipTable.SecondKeyTo5 = SecondKeyTo[5]
            RipTable.SecondKeyTo6 = SecondKeyTo[6]
        end            
    else
        tmpTbl = db.getDefaults(true, "Rip")
        RipTable = util.removePrefix (tmpTbl, "Rip.")
    end
    
    if(RipTable["FirstAuthenticationKeyId"] ~= nil) then
        RipTable["FirstAuthenticationKeyId"] = util.mask(RipTable["FirstAuthenticationKeyId"])
    end

    if(RipTable["SecondAuthenticationKeyId"] ~= nil) then
        RipTable["SecondAuthenticationKeyId"] = util.mask(RipTable["SecondAuthenticationKeyId"])
    end

    return RipTable
end

function rip.import (RipCfg, defaultCfg, removeCfg)
    if (RipCfg == nil) then
        RipCfg = defaultCfg
    end

    local ripTbl = {}

    if (RipCfg ~= nil) then
        ripTbl = config.update (RipCfg, defaultCfg, removeCfg)
	    for k,v in pairs (ripTbl) do
            if (v ~= nil) then
                v = util.addPrefix (v, "Rip.")
                db.insert("Rip", v)
			end
	    end
	end

end

function rip.export ()
    return db.getTable ("Rip", false)
end

if (config.register) then
   config.register("Rip", rip.import, rip.export, "2")
end

