--[[
#### Adarsh Uppula
#### TeamF1
#### www.TeamF1.com
#### June 29, 2007
-- Copyright (c) 2016, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
#### File: dot11.lua
#### Description: dot11 functions

#### Revisions:
01x,11Jul18,sen One time enforcing dscp -> 802.1P mapping
01w,10Nov17,sjr Changes for SPR#62585
01v,29Aug17,sjr changes for WIFI optimization
01u,26May17,sjr Added support for multiple subnet for WLAN. 
01t,10May17,aks fix for SPR #60651
01s,18Apr17,sjr fix for SPR #59793, modified import logic for dot11Profile table
01r,07Feb17,sjr added changes to remove the entries from dot11STA for wl0/wl1 when configure radio page. 
01q,21jul16,sjr added changes to mask WPA password 
010,11jul16,sjr added WPS led related changes when WPS session is on
01o,18sep14, sjr added logic to set ssid & password info from devdata partition
01n,26Oct13,sen Add some delay between enabling WPS and creating bridge interface.
01m,08Oct13,ash Changes for password encryption/decryption
01l,19nov12,abr removed code of enabling/disabling rogueAP at the time of calling import function.Added that code in seperate function which is being called from GUI and in case of reboot/upgrade rogueAPEnable.lua will call that function indirectly.
01k,24han12,nrb added dot11interface table entries from ascii file
01j,22jan11,bng  changed dot11profile input validate for radius auth mode
01i,14sep09,pnm  added logic to bring up monitor mode VAP
01h,16apr09,rks  config.recOp change to hold off calling operations till
                 config is validated for all comps.
01g,14Apr09,sar  Fixed SPR 11284(Hide SSID issue).
01f,16mar09,sam  calling pnacIfAuthorize in case of repeater.This
                 would allow data packets in the kernel module in case
                 of WDS.
01e,28jan09,rks merged dot11View.lua to dot11.lua. views are not treated slution
                specific and will be implemented in solution lua files.
01d,16jan09,rks changes to move from db update based event handling to direct
                calls. cleanup to keep only dot11 related code here
01c,11Sep08,shv changes with respect to radio configuration.
01b,23dec07,sdk modified set BSSID secret function.
01a,07nov07,sdk added functions for IAPP.
]]--

--package dot11
dot11 = {}
dscpToQueueMapping = {}
dscpToCosMapping = {}
cosToQueueMapping = {}

--[[
-- C dot11 library adds an _index function to dot11
require "dot11Lib"
require "teamf1lualib/ifDev"
require "teamf1lualib/config"
require "passwdSecureLib"
]]--
-- helper funcs

local dscpCosMaps = {}
dscpCosMaps["Best Effort"] = 2
dscpCosMaps["Background"] = 3
dscpCosMaps["Video"] = 1
dscpCosMaps["Voice"] = 0

local dscpToCosMaps = {}
dscpToCosMaps[0] = 0
dscpToCosMaps[1] = 1
dscpToCosMaps[2] = 2 
dscpToCosMaps[3] = 3
dscpToCosMaps[4] = 4
dscpToCosMaps[5] = 5
dscpToCosMaps[6] = 6
dscpToCosMaps[7] = 7 

--As per request from reliance changing all default values
DEFAULT_RADIO_MAX_CLIENT = "24"
DEFAULT_MAX_CLIENT = "8"
DEFAULT_MAX_CLIENT_PRIMARY_AP = "22"
DEFAULT_MAX_CLIENT_GUEST_AP = "1"
DEFAULT_MAX_CLIENT_BH_AP = "8"
DEFAULT_2_4_AP_NAME="ap1"
DEFAULT_5_AP_NAME="ap4"
local NVRAM_CMD_BINARY = "/bin/nvram"
local WLCONF_CMD_BINARY = "/bin/wlconf"
local WL_CMD_BINARY = "/bin/wl"
local IFCONFIG_CMD_BINARY = "/sbin/ifconfig "
local WL_SUB_CMD_AP_MODE = "ap"
local WL_SUB_CMD_SSID = "ssid"
local WL_SUB_CMD_WSEC = "wsec"
local WL_SUB_CMD_ADDWEP = "addwep"
local WL_SUB_CMD_REMWEP = "rmwep"
local WL_SUB_CMD_CHAN_SPEC = "chanspec"
local WPS_MONITOR_PORT = 40500
local GUEST_ZONE_BRIDGE_NAME = "bdg4"
local NVRAM_CHANNEL_BW_20 = "1"
local NVRAM_CHANNEL_BW_40 = "3"
local NVRAM_CHANNEL_BW_80 = "7"
local BDMF_COMMAND="/bin/bdmf_shell"

local dcspTo8021P56="6"	
local dcspTo8021P34="4"	
local dcspTo8021P20="4"	
local dcspTo8021P40="7"	
local dcspTo8021P46="6"	
local dcspTo8021P26="5"
local CMD_EXEC_SCRIPT = "/tmp/cmdExecscript.sh"
DSCP_PBIT_FLASH_FILE="/flash/dscpTo8021Pconfig.lua"
DSCP_PBIT_ONE_TIME_ENFORCE_FILE="/flash/dscpTo8021POneTimeEnforce"
dot11.LAN_IFNAME = "bdg2"
dot11.LAN4_IFNAME = "bdg4"
dot11.LAN5_IFNAME = "bdg5"
dot11.LAN6_IFNAME = "bdg6"
dot11.LAN7_IFNAME = "bdg7"


--  Mesh related global variables
local MESH_SCRIPT="/pfrm2.0/bin/mesh.sh"
local fh2SSID=""
local fh5SSID=""
local bhSSID=""
local fh2PSK=""
local fh5PSK=""
local bhPSK=""
local guest1pskPassAscii=""
local guest1SSID=""
local guest1broadcastSSID=""
local guest1Security=""
local BH_AP_NAME="ap5"
local BH_PROFILE_NAME="Jio_5" 
local FH_2_4_PROFILE_NAME="Jio_1" 
local FH_5_0_PROFILE_NAME="Jio_4"
local AP7_PROFILE_NAME="Jio_7"
local BH_VAP_NAME="ap5" 
local FH_2_4_VAP_NAME="ap1" 
local FH_5_0_VAP_NAME="ap4"
local BHRowToRemove=""


function nvramSetCmdExecute(interfaceName, variable, value)

   local NVRAM_SET_CMD_BINARY = "/bin/nvram set "
   local cmdStr = NVRAM_SET_CMD_BINARY ..interfaceName.. "_" ..variable.. "='" ..value.. "'"
   os.execute(cmdStr)

end

function wlCmdExecute(interfaceName, variable, value)

   local WL_CMD_BINARY = "/bin/wl -i "
   local cmdStr = WL_CMD_BINARY ..interfaceName.. " " ..variable.. " '" ..value.."'"
   os.execute(cmdStr)

end

function nvramSetCmdWrite(interfaceName, variable, value)

   local NVRAM_SET_CMD_BINARY = "/bin/nvram set "
   local cmdStr = NVRAM_SET_CMD_BINARY..interfaceName.."_"..variable.."='"..value.."'"
   util.fileAppend(CMD_EXEC_SCRIPT,cmdStr)

end

function wlCmdWrite(interfaceName, variable, value)
   local WL_CMD_BINARY = "/bin/wl -i "
   if ((util.fileExists("/pfrm2.0/HW_JCO110"))) then
        local cmdStr = ''
        cmdStr = WL_CMD_BINARY ..interfaceName.. " " ..variable.. " " ..value
        util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)
    else
	    local cmdStr1 = WL_CMD_BINARY ..interfaceName.. " " ..variable.. " " ..value
        util.fileAppend(CMD_EXEC_SCRIPT, cmdStr1)
    end
end

function wlconfExclude (fileName, cmdStr)

    local tmpFile="/tmp/tmpCmds.txt"
    local filp1 = nil
    local filp2 = nil
    local data

    os.execute ("cat "..fileName.." | grep -v \""..cmdStr.."\" > "..tmpFile)

    filp1 = io.open (tmpFile,"r")
    filp2 = io.open (fileName,"w")
    if (filp1 and filp2) then
        data = filp1:read ("*a")
        if (string.find(cmdStr,"down") ~=nil)then
            filp2:write(cmdStr.."\n")
        end
        filp2:write (data)
        if (string.find(cmdStr,"up") ~=nil or string.find(cmdStr,"start") ~= nil)then
            filp2:write(cmdStr.."\n")
        end
        filp1:close()
        filp2:close()
    end

    os.execute ("rm -rf "..tmpFile)

end

if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then	

function dot11meshInit()
    local cmd = "/bin/sh " .. MESH_SCRIPT .." startmesh"
	util.runShellCmd (cmd , "/tmp/dot11meshInit.txt")
end

function dot11meshReStart()
    local cmd = "/bin/sh " .. MESH_SCRIPT .." restartmesh"
	os.execute ("/bin/echo " .. cmd .. " > /dev/console") 
	util.runShellCmd (cmd , "/tmp/dot11meshRestart.txt")
end

function dot11meshReStartChannelChange(wlstr)
    local cmd = "/bin/sh " .. MESH_SCRIPT .." restartmeshChannelChange " .. "'" .. wlstr .. "'"
	util.runShellCmd (cmd , "/tmp/dot11meshRestart.txt")
end

function dot11SetFHSSID ( ssid, psk )
	local cmd="/bin/sh " .. MESH_SCRIPT .." setFH " .. "'" .. ssid .. "' '" .. psk .. "'"
	os.execute (cmd)
end

function dot11SetFHSSIDOnly (ssid, band)
	local cmd="/bin/sh " .. MESH_SCRIPT .." setFHSSID " .. "'" .. ssid .. "'" .. " " .. band
	os.execute (cmd)
end

function dot11SetFHPSKOnly (psk , band)
	local cmd="/bin/sh " .. MESH_SCRIPT .." setFHPSK " .. "'" .. psk .. "'" .. " " .. band
	os.execute (cmd)
end

function dot11SetFHHideSSID (action , band)
	local cmd="/bin/sh " .. MESH_SCRIPT .." setFHHIDE " .. "'" .. action .. "'" .. " " .. band
	os.execute (cmd)
end

function dot11SetBHSSID (ssid , psk)
	local cmd = "/bin/sh " .. MESH_SCRIPT .." setBH " .. "'" .. ssid .. "' '" .. psk .. "'"
	util.runShellCmd (cmd , "/tmp/dot11meshSetBH.txt")
end

function dot11SetWPSMode ()
	local cmd = "/bin/sh " .. MESH_SCRIPT .." setWPSMode"
    --os.execute ("/bin/echo " .. cmd .. " > /dev/console")
    util.runShellCmd (cmd , "/tmp/dot11wpsstart.txt")
end

function dot11ReSetWPSMode ()
    local cmd = "/bin/sh " .. MESH_SCRIPT .." resetWPSMode"
    --os.execute ("/bin/echo " .. cmd .. " > /dev/console")
    util.runShellCmd (cmd , "/tmp/dot11wpsstart.txt")
end

function dot11meshDisable()
    local cmd = "/bin/sh " .. MESH_SCRIPT .." disablemesh"
    --os.execute ("/bin/echo " .. cmd .. " > /dev/console")
    util.runShellCmd (cmd , "/tmp/dot11meshDisable.txt")
end

end

function getDscpMapStr (dot11Profile)
    local qosLimit = 63
    local dscpMapStr = ""

    if(not(dot11Profile)) then
        return nil
    end

    for i=0,qosLimit do
        indexStr = dot11Profile["dscpCosMap" .. i]
        if(indexStr == "Default") then
            indexStr = dot11Profile["defaultCos"]
        end
        dscpMapStr = dscpMapStr .. dscpCosMaps[indexStr]
    end

    return dscpMapStr
end


--table packages
dot11Interface = {}
dot11Card = {}
dot11ACL = {}
dot11AuthorizedAP = {}
dot11RogueAP = {}
dot11Radio = {}
dot11Profile = {}
dot11VAP = {}
dot11IAPP = {}
dot11IAPPRemoteAP = {}
dot11WPS = {}
dot11WPSStations = {}
dot11InterfaceToBridge = {}
apGroupName = {}

-- locals
local currentVersion = "1.0.0"

--************* Functions *************
--apGroupName.config
function apGroupName.config (inputTable, rowid, operation)
 
    -- validate
    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
            return db.insert("apGroupName", inputTable)
        elseif (operation == "edit") then
            return db.update("apGroupName", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("apGroupName", inputTable)
        end
    end
    return false

end

-- dot11Interface config
function dot11Interface.config (inputTable, rowid, operation)
    -- validate
    if (dot11Interface.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("dot11Interface", inputTable)
        elseif (operation == "edit") then
            return db.setAttribute("dot11Interface", "_ROWID_", rowid, "vapName", inputTable["dot11Interface.vapName"])
        elseif (operation == "delete") then
            return nil
        end
    end
    return false
end

-- dot11Interface inputvalidate
function dot11Interface.inputvalidate (inputTable, operation)
    if (true) then
        return db.typeAndRangeValidate(inputTable)
    end
    return false
end

-- dot11Profile config
function dot11Profile.config (inputTable, rowid, operation)
    -- validate
    if (dot11Profile.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("dot11Profile", inputTable)
        elseif (operation == "edit") then
            return db.update("dot11Profile", inputTable, rowid)
        elseif (operation == "delete") then
            for k,v in pairs(inputTable) do
                valid = db.deleteRow ("dot11Profile", "_ROWID_", v)
                if (not valid) then return false end
            end
            return true
        end
    end
    return false
end

-- dot11Profile inputvalidate
function dot11Profile.inputvalidate (inputTable, operation)

    -- check wep key length ... (hex length)
    if (inputTable["dot11Profile.security"] == "WEP" and inputTable["dot11Profile.wepKeyLength"]) then
        local wepKeyLength = inputTable["dot11Profile.wepKeyLength"]
        if (inputTable["dot11Profile.wepkey0"] and
            string.len (inputTable["dot11Profile.wepkey0"]) ~= (wepKeyLength-24)/4 and
            string.len (inputTable["dot11Profile.wepkey0"]) ~= (wepKeyLength)/4) then
            return false
        elseif (inputTable["dot11Profile.wepkey1"] and
            string.len (inputTable["dot11Profile.wepkey1"]) ~= (wepKeyLength-24)/4 and
            string.len (inputTable["dot11Profile.wepkey1"]) ~= (wepKeyLength)/4) then
            return false
        elseif (inputTable["dot11Profile.wepkey2"] and
            string.len (inputTable["dot11Profile.wepkey2"]) ~= (wepKeyLength-24)/4 and
            string.len (inputTable["dot11Profile.wepkey2"]) ~= (wepKeyLength)/4) then
            return false
        elseif (inputTable["dot11Profile.wepkey3"] and
            string.len (inputTable["dot11Profile.wepkey3"]) ~= (wepKeyLength-24)/4 and
            string.len (inputTable["dot11Profile.wepkey3"]) ~= (wepKeyLength)/4) then
            return false
        end
    elseif((inputTable["dot11Profile.security"] == "WPA") or 
          (inputTable["dot11Profile.security"] == "WPA2") or 
          (inputTable["dot11Profile.security"] == "WPA+WPA2")) then
           if ((inputTable["dot11Profile.authMethods"] == "PSK" or inputTable["dot11Profile.authMethods"] == "RADIUS")) then
              return true
            end

           if(inputTable["dot11Profile.pskPassAscii"] and
              (( string.len (inputTable["dot11Profile.pskPassAscii"]) < 8) or
              ( string.len (inputTable["dot11Profile.pskPassAscii"]) > 63))) then
              return false
          end
      elseif(inputTable["dot11Profile.security"] == "OPEN") then
          return true
      end

    if (true) then
        return db.typeAndRangeValidate(inputTable)
    end

    return false
end

-- dot11Radio config
function dot11Radio.config (inputTable, rowid, operation)
    -- validate
    if (dot11Radio.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("dot11Radio", inputTable)
        elseif (operation == "edit") then
            return db.update("dot11Radio", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("dot11Radio", inputTable)
        end
    end
    return false
end

-- dot11Radio inputvalidate
function dot11Radio.inputvalidate (inputTable, operation)

    if (inputTable ["dot11Radio.configuredChannel"]) then
        local channel = tonumber(inputTable ["dot11Radio.configuredChannel"])
        if ((inputTable["dot11Radio.subband_515_525"] == "0" and (channel >= 36  and channel <= 48 )) or
            (inputTable["dot11Radio.subband_525_535"] == "0" and (channel >= 52  and channel <= 64)) or
            (inputTable["dot11Radio.subband_547_572"] == "0" and (channel >= 100 and channel <= 140)) or
            (inputTable["dot11Radio.subband_572_586"] == "0" and (channel >= 149 and channel <= 165)) ) then
            return false
        end
    end
 
    if (true) then
        return db.typeAndRangeValidate(inputTable)
    end
    return false
end

-- dot11Card config
function dot11Card.config (inputTable, rowid, operation)
    -- validate
    if (dot11Card.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("dot11Card", inputTable)
        elseif (operation == "edit") then
            return db.update("dot11Card", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("dot11Card", inputTable)
        end
    end
    return false
end

-- dot11Card inputvalidate
function dot11Card.inputvalidate (inputTable, operation)
    if (true) then
        return db.typeAndRangeValidate(inputTable)
    end
    return false
end

-- dot11ACL config
function dot11ACL.config (inputTable, rowid, operation)
    -- validate
    if (dot11ACL.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("dot11ACL", inputTable)
        elseif (operation == "edit") then
            return db.update("dot11ACL", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("dot11ACL", inputTable)
        end
    end
    return false
end

-- dot11ACL inputvalidate
function dot11ACL.inputvalidate (inputTable, operation)
    if (true) then
        return db.typeAndRangeValidate(inputTable)
    end
    return false
end

-- dot11WPS config
function dot11WPS.config (inputTable, rowid, operation)
    -- validate
    if (dot11WPS.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("dot11WPS", inputTable)
        elseif (operation == "edit") then
            return db.update("dot11WPS", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("dot11WPS", inputTable)
        end
    end
    return false
end

-- dot11WPS inputvalidate
function dot11WPS.inputvalidate (inputTable, operation)
    if (true) then
        return db.typeAndRangeValidate(inputTable)
    end
    return false
end

-- dot11WPSStations config
function dot11WPSStations.config (inputTable, rowid, operation)
    -- validate
    if (dot11WPSStations.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("dot11WPSStation", inputTable)
        elseif (operation == "edit") then
            return false
        elseif (operation == "delete") then
            return false
        end
    end
    return false
end

-- dot11WPSStations inputvalidate
function dot11WPSStations.inputvalidate (inputTable, operation)
    if (true) then
        return db.typeAndRangeValidate(inputTable)
    end
    return false
end

-- dot11AuthorizedAP config
function dot11AuthorizedAP.config (inputTable, rowid, operation)
    -- validate
    if (dot11AuthorizedAP.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("dot11AuthorizedAP", inputTable)
        elseif (operation == "edit") then
            return db.update("dot11AuthorizedAP", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("dot11AuthorizedAP", inputTable)
        end
    end
    return false
end

-- dot11AuthorizedAP inputvalidate
function dot11AuthorizedAP.inputvalidate (inputTable, operation)
    if (true) then
        return db.typeAndRangeValidate(inputTable)
    end
    return false
end

-- dot11RogueAP config
function dot11RogueAP.config (inputTable, rowid, operation)
    -- validate
    if (dot11RogueAP.inputvalidate(inputTable, operation)) then
        if (operation == "delete") then
            return db.delete("dot11RogueAP", inputTable)
        end
    end
    return false
end

-- dot11RogueAP inputvalidate
function dot11RogueAP.inputvalidate (inputTable, operation)
    if (true) then
        return db.typeAndRangeValidate(inputTable)
    end
    return false
end

function dscpToQueueMapping.config (inputTable, rowid, operation)
    -- validate
    if (dscpToQueueMapping.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("dscpToQueueMapping", inputTable)
        elseif (operation == "edit") then
            return db.update("dscpToQueueMapping", inputTable, rowid)
        end
    end
    return false
end

function dscpToCosMapping.config (inputTable, rowid, operation)
    -- validate
   if (dscpToCosMapping.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("dscpToCosMapping", inputTable)
        elseif (operation == "edit") then
            return db.update("dscpToCosMapping", inputTable, rowid)
       end
    end
    return false
end

function cosToQueueMapping.config (inputTable, rowid, operation)
    -- validate
    if (cosToQueueMapping.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("cosToQueueMapping", inputTable)
        elseif (operation == "edit") then
            return db.update("cosToQueueMapping", inputTable, rowid)
        end
    end
    return false
end

-- dot11VAP config
function dot11VAP.config (inputTable, rowid, operation)
    -- validate
    if (dot11VAP.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("dot11VAP", inputTable)
        elseif (operation == "edit") then
            return db.update("dot11VAP", inputTable, rowid)
        elseif (operation == "delete") then
            for k,v in pairs(inputTable) do
                valid = db.deleteRow("dot11VAP", "_ROWID_", v)
                if (not valid) then  return false end
            end
            return true
        end
    end
    return false
end

function dscpToQueueMapping.inputvalidate (inputTable, operation)
	local valid = db.typeAndRangeValidate(util.tableSplit(inputTable, ".", "dscpToQueueMapping"))
    if (valid == false) then 
        return false
    end
	return true

end

function dscpToCosMapping.inputvalidate (inputTable, operation)
	local valid = db.typeAndRangeValidate(util.tableSplit(inputTable, ".", "dscpToCosMapping"))
    if (valid == false) then 
        return false
   end
	return true

end

function cosToQueueMapping.inputvalidate (inputTable, operation)
	local valid = db.typeAndRangeValidate(util.tableSplit(inputTable, ".", "cosToQueueMapping"))
    if (valid == false) then 
        return false
    end
	return true

end

-- dot11VAP inputvalidate
function dot11VAP.inputvalidate (inputTable, operation)
    local valid = db.typeAndRangeValidate(util.tableSplit(inputTable, ".", "dot11VAP"))

    if (valid == false) then 
        return false
    end

    local maxAllowableClients = tonumber(db.getAttribute("environment", "name", "DOT11_MAX_ASSOC_CLIENTS", "value"))

    if (maxAllowableClients == nil) then
        return true
    end

    -- Check for the max number of associated clients. This number should not
    -- exceed a certain value across all AP's combined. Also make sure that the
    -- maxClients are greater than 0
    local maxClientsCount = 0;
    local vapRadios = util.tableSplit(inputTable, ".", "vapRadio")

    for k,v in pairs(vapRadios) do
        local splitparts = util.split(k, ".")
        local radioNo = splitparts[2]
        local assocRows = db.getRows("dot11Interface", "radioNo", radioNo);

        for kk,vv in pairs(assocRows) do
            local vapName = vv["dot11Interface.vapName"];
            local maxClients = db.getAttribute("dot11VAP", "vapName", vapName, "maxClients") or 0;
        
            -- update with the latest value for the vap edited ..
            if (vapName == inputTable["dot11VAP.vapName"]) then
                maxClients = inputTable["dot11VAP.maxClients"];
            end
            
            if (tonumber(maxClients) == 0) then
                return false;
            end

            maxClientsCount = maxClientsCount + maxClients;
            
            -- break if there are any 'unused' slot entries in dot11Interface tbl ... 
            if (vapName == 'unused') then 
                break
            end
        end
    end  


    if (maxClientsCount > maxAllowableClients) then
        return false; 
    end

    return true
end

-- dot11IAPP enable
function dot11IAPP.enable (rowids, enable)
    local valid = true
    -- enable IAPP on each AP checked
    for k,v in pairs(rowids) do
        local enStr = ""
        if (enable) then 
            enStr = "1" 
        else 
            enStr = "0" 
        end
        -- set iappEnabled
        valid = db.setAttribute("dot11VAP", "_ROWID_", v, "iappEnabled", enStr)

        if(valid == false) then
            return valid
        end
    end

    return valid
end

-- dot11IAPP set bssid secret
function dot11IAPP.setBssidSecret (secret)
    local valid = true

    valid = db.setAttribute("dot11GlobalConfig", "_ROWID_", "1", "iappBssidSecret", secret) 

    return valid
end

-- dot11IAPPRemoteAP config
function dot11IAPPRemoteAP.config (inputTable, rowid, operation)
    -- validate
    if (dot11IAPPRemoteAP.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("dot11IAPPRemoteAP", inputTable)
        elseif (operation == "edit") then
            return db.update("dot11IAPPRemoteAP", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("dot11IAPPRemoteAP", inputTable)
        end
    end
    return false
end

-- dot11IAPPRemoteAP inputvalidate
function dot11IAPPRemoteAP.inputvalidate (inputTable, operation)
    return db.typeAndRangeValidate(inputTable)
end

-- dot11Radio 11n config
function dot11Radio.config11n (inputTable, rowid, operation)
    if (operation == "add") then
       return db.insert("dot11Radio11n", inputTable)
    elseif (operation == "edit") then
       return db.update("dot11Radio11n", inputTable, rowid)
    elseif (operation == "delete") then
       return db.delete("dot11Radio11n", inputTable)
    end
    return false
end

function dot11.dscpMapApply (inputTable)

    local qosLimit = 63
    local dscpMapStr = ""
    local pBit
    for i=0,qosLimit do
        indexStr = inputTable["dscpToQueueMapping.dscpCosMap" .. i]
        dscpMapStr = dscpCosMaps[indexStr]
        pBit = i % 8
        os.execute(BDMF_COMMAND .." -c `/bin/cat /var/bdmf_sh_id` -cmd /b/c dscp_to_pbit/table=0 dscp_map[" .. i.. "]=" .. pBit)
        os.execute(BDMF_COMMAND .. " -c `/bin/cat /var/bdmf_sh_id` -cmd /b/c pbit_to_queue/table=0 pbit_map[" .. pBit .."]=" .. dscpMapStr)
    end
    -- call lualib api with this string
--	dot11.dscpToQueueMapSet (dscpMapStr)
end

function dot11.dscpToCosMapApply (inputTable)

    local qosLimit = 63
    local dscpMapStr = ""
    --File containing all dscpToCos rules


	local  wanPhyInterface = "veip0"
	if(util.fileExists("/pfrm2.0/ae_wan_type") == true) then

		wanPhyInterface = "eth4"

	else

		wanPhyInterface = "veip0"

	end

		
	dofile (DSCP_PBIT_FLASH_FILE)
	
    io.output("/tmp/dscpToCos.sh") 
   
    for i=0,qosLimit do
        indexStr = tonumber(dscp1P["dscpToCosMapping.dscpCosMap" .. i])
        dscpMapStr = dscpToCosMaps[indexStr]
        local rule = "/bin/vlanctl --if " .. wanPhyInterface .. " --cfg-dscp2pbits " .. i .." " .. dscpMapStr
        io.write(rule, "\n")
    end
	   io.close ()
       local cmd_rule = "/bin/sh /tmp/dscpToCos.sh > /dev/null &"
       os.execute(cmd_rule)
	-- call lualib api with this string
	--dot11.dscpToCosQueueMapSet (dscpMapStr)
end

function dot11.cosMapApply (inputTable)

    local cosLimit = 7
    local cosMapStr = ""
    for i=0,cosLimit do
        indexStr = inputTable["cosToQueueMapping.cosMap" .. i]
        cosMapStr = dscpCosMaps[indexStr]
         os.execute(BDMF_COMMAND .. " -c `/bin/cat /var/bdmf_sh_id` -cmd /b/c pbit_to_queue/table=0 pbit_map[" .. i .."]=" .. cosMapStr)
    end
	-- call lualib api with this string
--	dot11.cosToQueueMapSet (cosMapStr)
end

--dscpToQueueMapping_config
function dot11.dscpToQueueMapping_config (inputTable, rowid, operation)

    local valid = true
	valid = dscpToQueueMapping.config (inputTable, rowid, operation)
	config.recOp(dot11.dscpMapApply,inputTable)

    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DOT11_AP_CONFIG_FAILED"
    end	
end

--dscpToCosMapping_config
function dot11.dscpToCosMapping_config (inputTable, rowid, operation)

    local valid = true
	valid = dscpToCosMapping.config (inputTable, rowid, operation)

	if (operation == "edit") then
	
		-- remove exsisting file in flash and create fresh file
		os.remove (DSCP_PBIT_FLASH_FILE)
		dot11.dscpToCosMappingFlashConfigCreate (inputTable)
	end

	config.recOp(dot11.dscpToCosMapApply,inputTable)
    if (valid) then
        return "OK", "STATUS_OK"
    else
       return "ERROR", "DOT11_AP_CONFIG_FAILED"
    end	

end

--cosToQueueMapping_config
function dot11.cosToQueueMapping_config (inputTable, rowid, operation)

    local valid = true
	valid = cosToQueueMapping.config (inputTable, rowid, operation)
	config.recOp(dot11.cosMapApply,inputTable)

    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DOT11_AP_CONFIG_FAILED"
    end	
end
--dot11InterfaceToBridge.config
function dot11InterfaceToBridge.config (inputTable, rowid, operation)
 
    -- validate
    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
            return db.insert("dot11InterfaceToBridge", inputTable)
        elseif (operation == "edit") then
            return db.update("dot11InterfaceToBridge", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("dot11InterfaceToBridge", inputTable)
        end
    end
    return false

end
--
-- dot11VAP config
function dot11.VAP_config (inputTable, rowid, operation)

    local valid = true
    local vapStatusFlag
    local aprow = {}
    
    -- build aprow
    if (rowid == "-1") then
        aprow = inputTable -- add so get new data
    else
		if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then
			if (inputTable["dot11VAP.vapName"]  == BH_AP_NAME ) then
				return "ERROR" , "VAP_EDIT_NOT_ALLOWED__MESH_AP"
			end
		end

        aprow = db.getRow("dot11VAP", "dot11VAP._ROWID_", rowid) -- edit so get old data
    end

    --Updating dot11VAP configuration.
    if (valid) then
        local inTable = util.tableAdd(util.tableSplit(inputTable, ".", "dot11VAP"), util.tableSplit(inputTable, ".", "vapRadio"))
        valid = dot11VAP.config (inTable, rowid, operation)
        
        --add setting will be applied only in import function
        if(valid and operation == "add") then
            return "OK", "STATUS_OK"	
        end
    end

    if (valid) then
        if (operation == "edit" and inputTable["dot11VAP.defaultSubnet"] ~= nil and inputTable["dot11VAP.vapName"] ~= "ap1" and inputTable["dot11VAP.vapName"] ~= "ap4") then
            local vapInterfaceName = db.getAttribute("dot11Interface", "vapName", inputTable["dot11VAP.vapName"],"interfaceName") or ''
            if(inputTable["dot11VAP.defaultSubnet"] == "2")then
                valid = db.setAttribute ("dot11Interface", "interfaceName", vapInterfaceName, "LogicalIfName", "IF8")
            else
                valid = db.setAttribute ("dot11Interface", "interfaceName", vapInterfaceName, "LogicalIfName", "IF2")
            end
            dot11.nvramIfnamesSet ()
        end
        dot11.AP_start( inputTable, inputTable["dot11VAP.vapEnabled"])

        if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then
        	dot11meshReStart ()
        end
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DOT11_AP_CONFIG_FAILED"
    end
end

-- dot11VAP enable
function dot11.VAP_enable (rowids, enable)
    local valid = true
    
    -- enable/disable each AP checked
    for k,v in pairs(rowids) do
        if (enable) then enStr = "1" else enStr = "0" end
        local row = db.getRow("dot11VAP", "dot11VAP._ROWID_", v)
        if (row["dot11VAP.vapEnabled"] ~= enStr) then
            valid = db.setAttribute("dot11VAP", "_ROWID_", v, "vapEnabled", enStr)  
            local vaprows = db.getRowsWithJoin({"dot11VAP:dot11Interface:vapName"}, "dot11VAP.vapName",row["dot11VAP.vapName"])
            for k,v in pairs(vaprows) do
                -- apply the settings on vap
                dot11.VAP_start (row["dot11VAP.vapName"] , enable)
            end
        end
    end
    
    -- return
    if (valid) then
        return "OK", "STATUS_OK"
    else
        if (enable) then
            return "ERROR", "DOT11_AP_ENABLE_FAILED"
        else
            return "ERROR", "DOT11_AP_DISABLE_FAILED"
        end
    end
end

-- dot11VAP start 
function dot11.VAP_start (vapname, enable)
    local vaprows = db.getRowsWithJoin({"dot11VAP:dot11Interface:vapName"}, "dot11VAP.vapName", vapname)

    for k,v in pairs(vaprows) do
        dot11.AP_start (v, enable)
    end 
    return true
end


--[[ dot11Profile helper
function dot11.VapsOnProfile_start (profileName, enable)
	--TODO need to put check only to put on Enabled VAP. Right Now we have to call VAP_start as
	--in Access Points we are not updating any profile changes
    local vapEntries = db.getRowsWhere("dot11VAP", "profileName = '" .. profileName .. "'",false)
    local rows = {}
    for k,v in pairs (vapEntries) do
        dot11.VAP_start (v["vapName"], enable)
    end
end
]]--

-- dot11Profile config
function dot11.profile_config (inputTable, rowid, operation)

    local valid = false
    local profileName
    local radioInterfaceName
    local vapInterfaceName
    local profileNamequery = "profileName='"
    local vapNamequery = "vapName='"
    local radioNoquery = "radioNo='"
    local vapRow = {}
    local interfaceRow = {}
    local radioRow = {}
    local oldProfileRow = {}

    if(operation == "delete") then
        for k,v in pairs(inputTable) do
            profileName = db.getAttribute("dot11Profile","_ROWID_",v,"profileName")
            vapRow = db.getRow("dot11VAP","profileName",profileName)
            if(vapRow ~= nil) then
                return "ERROR", "AP_USING_PROFILE"
            end
            valid = db.deleteRow ("dot11Profile", "_ROWID_", v)
        end
    end

    if (operation == "edit") then
        oldProfileRow = db.getRowWhere ("dot11Profile", "_ROWID_='"..rowid.."'", false)
    end

    if ((operation == "add") or (operation == "edit")) then
        -- config dot11Profile
        valid = dot11Profile.config(inputTable, rowid, operation)

        if (valid and operation == "edit") then

			if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then

				-- for Mesh , no not allow profile update on 5 GHz FH and BH
				if (oldProfileRow["profileName"] == BH_PROFILE_NAME) then
					return "ERROR" , "DOT11_BH_PROFILE_CONFIG_NOT_ALLOWED"
				end


				-- if edit operation for 2.4 MESH FH SSID ,  validate the input
				if ((oldProfileRow["profileName"] == FH_2_4_PROFILE_NAME) or (oldProfileRow["profileName"] == FH_5_0_PROFILE_NAME)) then
					-- FH SSID to  be WPA2 PSK only
					if(inputTable["dot11Profile.security"] =="OPEN" or inputTable["dot11Profile.security"] == "WEP" or inputTable["dot11Profile.authMethods"] == "RADIUS")then
						return "ERROR" , "DOT11_2_4_PROFILE_CONFIG_NOT_ALLOWED"
					end
				end	
			end

            if(oldProfileRow ~= nil)then
                local profileName = oldProfileRow["profileName"]
                local vapName= db.getAttribute("dot11VAP","profileName",profileName,"vapName")
                local vapInterfaceName = db.getAttribute("dot11Interface","vapName",vapName,"interfaceName")
                local radioNo = db.getAttribute("dot11VAP", "vapName", vapName, "radioList")
                local radioInterfaceName = db.getAttribute("dot11Radio", "radioNo", radioNo, "interfaceName")
                local cmd = "/bin/wlconf " ..radioInterfaceName.." down"
                wlconfExclude(CMD_EXEC_SCRIPT, cmd)
                --ssid settings updation
                if(oldProfileRow["ssid"] ~= inputTable["dot11Profile.ssid"])then
                    if(inputTable["dot11Profile.ssid"] == nil)then                                                     
                        inputTable["dot11Profile.ssid"] = oldProfileRow["ssid"]                                            
                    end
                    nvramSetCmdWrite(vapInterfaceName, "ssid", inputTable["dot11Profile.ssid"])                   

					if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then
						-- If this is SSID change on 2.4 FH or 5 GHz FH
						-- Update the same to mesh scripts
						if (profileName == FH_2_4_PROFILE_NAME) then
							dot11SetFHSSIDOnly (inputTable["dot11Profile.ssid"], "b")
						end

						if (profileName == FH_5_0_PROFILE_NAME) then
							dot11SetFHSSIDOnly (inputTable["dot11Profile.ssid"], "a")
						end						
					end
					                   
                end

                -- LAN interface update is required if there is another profile
                -- with same SSID name
                if (profileTmp ~= nil and inputTable["dot11Profile.profileName"] ~= "Jio_1" and inputTable["dot11Profile.profileName"] ~= "Jio_4") then
                     dot11.nvramIfnamesSet ()
                end

                --hide ssid settings updation
                if(tonumber(oldProfileRow["broadcastSSID"]) ~= tonumber(inputTable ["dot11Profile.broadcastSSID"]))then
					if((util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) and ((profileName == FH_2_4_PROFILE_NAME) or (profileName == FH_5_0_PROFILE_NAME))) then
						if (profileName == FH_2_4_PROFILE_NAME) then
							-- Hide SSID changed  for  2.4 FH
							if(tonumber(inputTable ["dot11Profile.broadcastSSID"]) == 1 ) then dot11SetFHHideSSID ( "0",  "b") else dot11SetFHHideSSID ( "1",  "b") end
						end

						if (profileName == FH_5_0_PROFILE_NAME) then
							-- Hide SSID changed  for  5.0 FH
							if(tonumber(inputTable ["dot11Profile.broadcastSSID"]) == 1 ) then dot11SetFHHideSSID ( "0",  "a") else dot11SetFHHideSSID ( "1",  "a") end
						end

					else

                    if(tonumber(inputTable ["dot11Profile.broadcastSSID"]) == 1 )then
                        nvramSetCmdWrite(vapInterfaceName, "closed", 0)     
                        wlCmdWrite(vapInterfaceName, "closed", "0")
                    else
                        nvramSetCmdWrite(vapInterfaceName, "closed", 1)     
                        wlCmdWrite (vapInterfaceName, "closed", "1")
                    end
					end
                end
                wlCmdWrite (vapInterfaceName, "bss", "down")
                os.execute ("echo \'"..IFCONFIG_CMD_BINARY..vapInterfaceName.." down".."\'".." >> "..CMD_EXEC_SCRIPT)
                --security settings updation

                -- disable the wep
                nvramSetCmdWrite(vapInterfaceName, "wep", "disabled")     
                wlCmdWrite (vapInterfaceName, "wepstatus", "0")
                for i=1,4 do
                    cmdStr = "echo \'"..NVRAM_CMD_BINARY .. " unset '"..vapInterfaceName.."_key"..i.."'".."\'".." >> "..CMD_EXEC_SCRIPT
                    os.execute(cmdStr)
                end

                --open mode security settings
                if(inputTable["dot11Profile.security"] =="OPEN" or inputTable["dot11Profile.security"] == "WEP")then
                    nvramSetCmdWrite(vapInterfaceName, "auth", "0")     
                    nvramSetCmdWrite(vapInterfaceName, "akm", "*DEL*")     
                    nvramSetCmdWrite(vapInterfaceName, "wpa_psk", "")     
                    wlCmdWrite (vapInterfaceName, "wsec", "0")
                    wlCmdWrite (vapInterfaceName, "wpa_auth", "0")
                    wlCmdWrite (vapInterfaceName, "auth", "0")
                    wlCmdWrite (vapInterfaceName, "wsec_restrict", "0")
                    cmdStr = "echo \'"..WLCONF_CMD_BINARY .." "..vapInterfaceName.. " security".."\'".." >> "..CMD_EXEC_SCRIPT
                    os.execute(cmdStr)
                end

                --wpa+wpa2 security settings
                if(inputTable["dot11Profile.security"] == "WPA+WPA2" or inputTable["dot11Profile.security"] == "WPA" or inputTable["dot11Profile.security"] == "WPA2")then
                    if (inputTable["dot11Profile.pairwiseCiphers"] == "TKIP+CCMP") then
                        wlCmdWrite (vapInterfaceName, "wsec", "6")
                        nvramSetCmdWrite(vapInterfaceName, "crypto", "tkip+aes")     
                    elseif (inputTable["dot11Profile.pairwiseCiphers"] == "TKIP") then
                        wlCmdWrite (vapInterfaceName, "wsec", "2")
                        nvramSetCmdWrite(vapInterfaceName, "crypto", "tkip")     
                    elseif (inputTable["dot11Profile.pairwiseCiphers"] == "CCMP") then
                        wlCmdWrite (vapInterfaceName, "wsec", "4")
                        nvramSetCmdWrite(vapInterfaceName, "crypto", "aes")     
                    end

                    if(inputTable["dot11Profile.authMethods"] == "PSK")then
                        if (inputTable["dot11Profile.security"] == "WPA+WPA2") then
                            nvramSetCmdWrite(vapInterfaceName, "akm", "psk psk2")     
                            wlCmdWrite (vapInterfaceName, "wpa_auth", "132")
                        end			
                        if (inputTable["dot11Profile.security"] == "WPA") then
                            nvramSetCmdWrite(vapInterfaceName, "akm", "psk")     
                            wlCmdWrite (vapInterfaceName, "wpa_auth", "4")
                        end			
                        if (inputTable["dot11Profile.security"] == "WPA2") then
                            nvramSetCmdWrite(vapInterfaceName, "akm", "psk2")     
                            wlCmdWrite (vapInterfaceName, "wpa_auth", "128")
                        end
                    else
                        if (inputTable["dot11Profile.security"] == "WPA+WPA2") then
                            nvramSetCmdWrite(vapInterfaceName, "akm", "wpa wpa2")     
                            wlCmdWrite (vapInterfaceName, "wpa_auth", "66")
                        end			
                        if (inputTable["dot11Profile.security"] == "WPA") then
                            nvramSetCmdWrite(vapInterfaceName, "akm", "wpa")     
                            wlCmdWrite (vapInterfaceName, "wpa_auth", "2")
                        end			
                        if (inputTable["dot11Profile.security"] == "WPA2") then
                            nvramSetCmdWrite(vapInterfaceName, "akm", "wpa2")     
                            wlCmdWrite (vapInterfaceName, "wpa_auth", "64")
                        end
                    end
                    if (inputTable["dot11Profile.pskPassAscii"]) then
                        nvramSetCmdWrite(vapInterfaceName, "wpa_psk", inputTable["dot11Profile.pskPassAscii"])     
						if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then
							if (profileName == FH_2_4_PROFILE_NAME) then
								-- PSK changed  for  2.4 FH
								dot11SetFHPSKOnly (inputTable["dot11Profile.pskPassAscii"] , "b")
							end

							if (profileName == FH_5_0_PROFILE_NAME) then
								-- PSK changed  for  5 GHz FH
								dot11SetFHPSKOnly (inputTable["dot11Profile.pskPassAscii"] , "a")
							end
						end
                    end
                    nvramSetCmdWrite(vapInterfaceName, "auth", "0")     
                    wlCmdWrite (vapInterfaceName, "auth", "0")
                    wlCmdWrite (vapInterfaceName, "wsec_restrict", "1")
	        end --wpa+wpa2/wpa/wpa2 security changes
                --wep setting updation
                if (inputTable["dot11Profile.security"] == "WEP") then
                    nvramSetCmdWrite(vapInterfaceName, "akm", "*DEL*")     
                    -- set WEP in driver
                    local keyIndex = tonumber(inputTable["dot11Profile.defWepkeyIdx"]) + 1
                    nvramSetCmdWrite(vapInterfaceName, "wep", "enabled")     
                    nvramSetCmdWrite(vapInterfaceName, "key", keyIndex)     
                    nvramSetCmdWrite(vapInterfaceName, "key"..keyIndex, inputTable["dot11Profile.wepkey"..inputTable["dot11Profile.defWepkeyIdx"]])     
                    wlCmdWrite (vapInterfaceName, "wpa_auth", "0")
                end --wep security settings
                os.execute ("echo \'/bin/nvram commit".."\'".." >> "..CMD_EXEC_SCRIPT)


				if((util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) and ((profileName == FH_2_4_PROFILE_NAME) or (profileName == FH_5_0_PROFILE_NAME))) then
					--dot11meshReStart ()
					os.remove(CMD_EXEC_SCRIPT)
				else
                cmd = "/bin/wlconf " ..radioInterfaceName.." up"
                wlconfExclude(CMD_EXEC_SCRIPT,cmd)
                dot11.ServiceStopStart2 (false)
                dot11.ServiceStopStart2 (true)
                cmd = "/bin/wlconf " ..radioInterfaceName.." start"
                wlconfExclude(CMD_EXEC_SCRIPT,cmd)

                local vapEnabled = db.getAttribute("dot11VAP","profileName",profileName,"vapEnabled")
                if(tonumber(vapEnabled) == tonumber(1))then
                    -- set SSID on the interface
                    cmdStr = WL_CMD_BINARY .. " -i " .. vapInterfaceName .. " ssid " .. "'" .. inputTable["dot11Profile.ssid"] .. "'"
                    util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)
                    wlCmdWrite (vapInterfaceName, "bss", "up")
                    os.execute ("echo \'"..IFCONFIG_CMD_BINARY..vapInterfaceName.." up".."\'".." >> "..CMD_EXEC_SCRIPT)
                end
                if (inputTable["dot11Profile.security"] == "WEP") then
                    wlCmdWrite (vapInterfaceName, "wepstatus", "1")
                    if (inputTable["dot11Profile.wepAuth"]== "Shared") then
                        nvramSetCmdWrite(vapInterfaceName, "auth", "1")
                        wlCmdWrite (vapInterfaceName, "auth", "1")
                    else
                        nvramSetCmdWrite(vapInterfaceName, "auth", "0")
                        wlCmdWrite (vapInterfaceName, "auth", "0")
                    end
                    wlCmdWrite (vapInterfaceName, "wsec", "1")
                    wlCmdWrite (vapInterfaceName, "wsec_restrict", "1")
                    wlCmdWrite (vapInterfaceName, "addwep", inputTable["dot11Profile.defWepkeyIdx"] .." "..inputTable["dot11Profile.wepkey"..inputTable["dot11Profile.defWepkeyIdx"]])
                end
				end
            end -- oldProfileRow nil check
        end
    end

    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DOT11_PROFILE_CONFIG_FAILED"
    end

end

-- dot11Card config
function dot11.card_config (inputTable, rowid, operation)
    -- config dot11Card
    local valid = dot11Card.config(inputTable, rowid, operation)
    
    -- return
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DOT11_CARD_CONFIG_FAILED"
    end
end

-- dot11AuthorizedAP config
function dot11.authorizedap_config (inputTable, rowid, operation)
   
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end

    -- config dot11AuthorizedAP
    valid = dot11AuthorizedAP.config(inputTable, rowid, operation)
    
    -- return
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DOT11_AUTH_AP_CONFIG_FAILED"
    end
end

-- dot11RogueAP move
function dot11.rogueap_move (rowids)
    local valid = false

    -- add to dot11AuthorizedAP first

    for k,v in pairs(rowids) do
        local row = db.getRow("dot11RogueAP", "dot11RogueAP._ROWID_", v)
        if (row) then 
            local inputTable = {}
            inputTable ["dot11AuthorizedAP.macAddress"] = row["dot11RogueAP.macAddress"]
            inputTable ["dot11AuthorizedAP.SSID"] = row["dot11RogueAP.SSID"]
            inputTable ["dot11AuthorizedAP.security"] = row["dot11RogueAP.security"]
            inputTable ["dot11AuthorizedAP.pairwiseCiphers"] = row["dot11RogueAP.pairwiseCiphers"]
            inputTable ["dot11AuthorizedAP.authMethods"] = row["dot11RogueAP.authMethods"]
            inputTable ["dot11AuthorizedAP.channelNumber"] = row["dot11RogueAP.channelNumber"]
            inputTable ["dot11AuthorizedAP.apmode"] = row["dot11RogueAP.apmode"]

            valid = dot11AuthorizedAP.config(inputTable, "-1", "add")
            if (not valid) then
                break;
            end
        end
    end

    -- return
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DOT11_ROGUE_AP_MOVE_FAILED"
    end

       
end

-- dot11ACL config
function dot11.ACL_config (inputTable, rowid, operation)
    local valid = false 

    vaprow = {}

    -- if operation is delete get the vapName and macaddress to delete the 
    -- corresponding entry from the dot11 also.
    if(operation == "delete") then
        for k,v in pairs (inputTable) do
        	vaprow = db.getRow ("dot11ACL", "_ROWID_", v)
			local name = vaprow["dot11ACL.vapName"]
			local vapInterface = db.getAttribute ("dot11Interface", "vapName", vaprow["dot11ACL.vapName"], "interfaceName")
			valid = db.deleteRow ("dot11ACL", "_ROWID_", v)
        end
    	valid = dot11.ACL_Add(vaprow["dot11ACL.vapName"], rowid, operation)
    end


    -- config dot11ACL
	if (operation == "add") then
    	valid = dot11ACL.config(inputTable, rowid, operation)
	end

    -- return
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DOT11_ACL_CONFIG_FAILED"
    end
end

-- WPS config
function dot11.WPS_config (inputTable, rowid, operation)

    local valid = false
    local vapIfname 

    if (operation == "edit") then
        local oldConfig = db.getRowWhere ("dot11WPS", "_ROWID_='1'", false)
        vapIfname = oldConfig["vapName"]
        -- disable in nvram
        nvramSetCmdWrite(vapIfname, "wps_mode", "disabled")
    end

    vapIfname = inputTable["dot11WPS.vapName"]
    if (vapIfname == nil) then 
        vapIfname = inputTable["dot11WPS.vapName"] 
    end

    -- update the database
    valid = dot11WPS.config(inputTable, rowid, operation)
  
    if (operation == "edit") then
        if (inputTable["dot11WPS.wpsEnabled"] == "1") then
			if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then
				if ((vapIfname  == "wl0" ) or (vapIfname  == "wl1")) then    
                        dot11SetWPSMode ()                                 
                        dot11meshReStart ()                                
               	end
                if (not((vapIfname  == "wl1" ) or (vapIfname  == "wl0"))) then
                        dot11ReSetWPSMode ()
                        dot11meshReStart ()
                    end

			end
            nvramSetCmdWrite(vapIfname, "wps_mode", "enabled")
        end
    end
    
    -- commit nvram changes
    os.execute ("echo \'/bin/nvram commit".."\'".." >> "..CMD_EXEC_SCRIPT)

    --restart wps_monitor
    if(operation == "edit") then
        os.execute ("echo \'kill `cat /tmp/wps_monitor.pid`\' >> "..CMD_EXEC_SCRIPT)
        -- wpsSession update script may still be running from last session
        os.execute ("echo \'pgrep -f wpsSessionUpdate.lua | xargs kill -9\' >> "..CMD_EXEC_SCRIPT)
        os.execute ("echo \'/bin/rm -rf /tmp/wpsON\' >> "..CMD_EXEC_SCRIPT)
        dot11.ServiceStopStart2 (false)
        dot11.ServiceStopStart2 (true)
        if ((util.fileExists("/pfrm2.0/HW_JCO110"))) then
            wlCmdWrite(vapIfname, "phy_ed_thresh", "-30")
        else
            wlCmdWrite(vapIfname, "phy_ed_thresh", "-50")
        end
    end

    --os.execute ("/pfrm2.0/bin/ledControl power green on")
    db.execute ("update dot11WPSSessStatus set sessionMsg='', sessionStatus='0'") 

    -- return
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DOT11_WPS_CONFIG_FAILED"
    end

end

-- WPS_Station config
function dot11.WPS_Station_config (inputTable, rowid, operation)
    
    -- config dot11ACL
    local valid = dot11WPSStations.config(inputTable, rowid, operation)
    
    -- return
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DOT11_WPS_CONFIG_FAILED"
    end
end

-- apGroupName config
function dot11.apGroupName_config (inputTable, rowid, operation)

    local valid = false
    if (operation == "add") then
        bootFlag = "1"
    else
        bootFlag = "0"
    end
    -- update the database
    valid = apGroupName.config(inputTable, rowid, operation)
    if(valid)then
        if(bootFlag == "0")then
            local vapTable = db.getTable("dot11VAP", true)
            if (vapTable == nil) then
                return "ERROR","DB_ERROR_TRY_AGAIN",nilTable
            end
            for k,v in pairs (vapTable) do
                errMsg, status = dot11.VAP_config (v, v["dot11VAP._ROWID_"], "edit")
            end
            return errMsg, status
        end
        return "OK", "STATUS_OK"
    else
        return "ERROR", "AP_GROUPNAME_CONFIG_FAILED"
    end

end

-- dot11Radio config
function dot11.radio_config (inputTable, rowid, operation)

    -- locals
    local channel 
    if (operation == "delete") then
        return false
    end

    if (operation == "edit" and inputTable["dot11Radio.radioNo"] == nil) then
        inputTable["dot11Radio.radioNo"] = db.getAttribute ("dot11Radio", "_ROWID_", rowid, "radioNo");
    end

    -- Updating dot11 Radio configuration.
    local valid = dot11Radio.config (inputTable, rowid, operation)
    
    if (valid and operation ~= "add") then
        config.recOp (dot11.radio_config_apply ,inputTable)
    end
    
    -- return
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DOT11_RADIO_CONFIG_FAILED"
    end
end

-- dot11countries config
function dot11.country_config (inputTable, rowid, operation)
    
    -- config dot11 country
    local valid = db.update ("dot11GlobalConfig", inputTable, 1)
    
    -- return
    if (valid) then
        rebootFlag=1
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DOT11_RADIO_CONFIG_FAILED"
    end
end


-- IAPP enable
function dot11.IAPP_enable (rowids, enable)

    local valid = false
    local action = "disable" 

    if(enable) then
        action = "enable"
    end

    -- config dot11Radio
    valid = dot11IAPP.enable(rowids, enable)

    -- return
    if (valid) then
        return "OK", "STATUS_OK"
    else
        if (enable) then 
            return "ERROR", "DOT11_IAPP_ENABLE_FAILED" 
        else 
            return "ERROR", "DOT11_IAPP_DISABLE_FAILED" 
        end 
    end
end

-- dot11IAPPRemoteAP config
function dot11.IAPPRemoteAP_config (inputTable, rowid, operation)

    -- config dot11Profile
    local valid = dot11IAPPRemoteAP.config(inputTable, rowid, operation)

    -- return
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DOT11_IAPP_CONFIG_FAILED_REMOTE"
    end
end

-- Set IAPP Bssid Secret 
function dot11.IAPP_setBssidSecret (secret)

    -- config dot11Profile
    local valid = dot11IAPP.setBssidSecret(secret)

    -- return
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "DOT11_IAPP_CONFIG_FAILED_BSSID"
    end
end

-- dot11VAP ACL mode config
function dot11.VAP_aclConfig (dot11VAP, policy)

    --locals
    local enabled = nil
    local radioInterfaceName=nil
    local profileName=nil
    local ssidName = nil
    local vapInterfaceName = nil
    local radioNo
    local vapInterfacerows = {}
    local cmd
    
    enabled = tonumber(dot11VAP["vapEnabled"])
    profileName = dot11VAP["profileName"]
    
    if(profileName ~= nil) then
        ssidName = db.getAttribute("dot11Profile","profileName",profileName,"ssid")
    end

    vapInterfaceName = db.getAttribute("dot11Interface","vapName",dot11VAP["vapName"],"interfaceName")
    if(enabled == 1) then
        --bring the bss down
        wlCmdWrite(vapInterfaceName, "bss", "down")
        os.execute ("echo \'"..IFCONFIG_CMD_BINARY..vapInterfaceName.." down".."\'".." >> "..CMD_EXEC_SCRIPT)        
    end

    vapInterfacerows = db.getRowsWithJoin({"dot11VAP:dot11Interface:vapName"}, "dot11VAP.vapName",dot11VAP["vapName"])
    radioNo = db.getAttribute("dot11VAP", "vapName", dot11VAP["vapName"], "radioList")
    radioInterfaceName = db.getAttribute("dot11Radio", "radioNo", radioNo, "interfaceName")
    cmd = "/bin/wlconf " ..radioInterfaceName.." down"
    wlconfExclude(CMD_EXEC_SCRIPT, cmd)
    for k,v in pairs(vapInterfacerows) do
        if (policy["dot11VAP.defACLPolicy"] == "Allow") then
            wlCmdWrite(v["dot11Interface.interfaceName"], "macmode", "2")
            nvramSetCmdWrite(v["dot11Interface.interfaceName"], "macmode", "allow")
        elseif (policy["dot11VAP.defACLPolicy"] == "Deny") then
            wlCmdWrite(v["dot11Interface.interfaceName"], "macmode", "1")
            nvramSetCmdWrite(v["dot11Interface.interfaceName"], "macmode", "deny")
        elseif (policy["dot11VAP.defACLPolicy"] == "Disable") then
            wlCmdWrite(v["dot11Interface.interfaceName"], "macmode", "0")
            nvramSetCmdWrite(v["dot11Interface.interfaceName"], "macmode", "disabled")
        end
    end
    os.execute ("echo \'/bin/nvram commit".."\'".." >> "..CMD_EXEC_SCRIPT)
    cmd = "/bin/wlconf " ..radioInterfaceName.." up"
    wlconfExclude(CMD_EXEC_SCRIPT,cmd)
    dot11.ServiceStopStart2 (false)
    dot11.ServiceStopStart2 (true)
    cmd = "/bin/wlconf " ..radioInterfaceName.." start"
    wlconfExclude(CMD_EXEC_SCRIPT,cmd)
    
    if(enabled == 1) then
        --bring the bss up
        if(ssidName ~= nil)then
            cmdStr = WL_CMD_BINARY .. " -i " .. vapInterfaceName .. " ssid " .. "'" .. ssidName .. "'"
            util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)
        end
        wlCmdWrite(vapInterfaceName, "bss", "up")
        os.execute ("echo \'"..IFCONFIG_CMD_BINARY..vapInterfaceName.." up".."\'".." >> "..CMD_EXEC_SCRIPT)
    end

    if(radioInterfaceName ~= nil) then
        dot11.SetWep(radioInterfaceName)
        if ((util.fileExists("/pfrm2.0/HW_JCO110"))) then
            wlCmdWrite(radioInterfaceName, "phy_ed_thresh", "-30")
        else
            wlCmdWrite(radioInterfaceName, "phy_ed_thresh", "-50")
        end
    end

    return "OK", "STATUS_OK"
end

function dot11.VAP_aclMacConfig (dot11VAP)

    -- locals
    local enabled = nil
    local vapInterfaceName
    local vaprows
    local radioNo
    local radioInterfaceName
    local profileName
    local ssidName = nil
    local cmd
    
    profileName = dot11VAP["profileName"]
    if(profileName ~= nil) then
        ssidName = db.getAttribute("dot11Profile","profileName",profileName,"ssid")
    end
    vapInterfaceName = db.getAttribute("dot11Interface","vapName",dot11VAP["vapName"],"interfaceName")
    enabled = tonumber(dot11VAP["vapEnabled"])
    if(enabled == 1) then
        --bring the bss down
        wlCmdWrite(vapInterfaceName, "bss", "down")
        os.execute ("echo \'"..IFCONFIG_CMD_BINARY..vapInterfaceName.." down".."\'".." >> "..CMD_EXEC_SCRIPT)
    end
    vaprows = db.getRowsWithJoin({"dot11VAP:dot11Interface:vapName"}, "dot11VAP.vapName", dot11VAP["vapName"])
    radioNo = db.getAttribute("dot11VAP", "vapName", dot11VAP["vapName"], "radioList")
    radioInterfaceName = db.getAttribute("dot11Radio", "radioNo", radioNo, "interfaceName")
    cmd = "/bin/wlconf " ..radioInterfaceName.." down"
    wlconfExclude(CMD_EXEC_SCRIPT, cmd)
    if(vaprows ~= nil ) then
        for i,j in pairs(vaprows) do
            local maclist = ""
            if(j["dot11Interface.interfaceName"] ~= nil) then
                ACLrows = db.getRowsWhere ("dot11ACL", "vapName='".. dot11VAP["vapName"] .."'", false)
                if ACLrows[1] == nil then 
                    maclist = "*DEL*"
                    nvramSetCmdWrite(j["dot11Interface.interfaceName"], "maclist", maclist)
                    os.execute ("echo \'/bin/nvram commit".."\'".." >> "..CMD_EXEC_SCRIPT)
                    maclist = "none"
                    wlCmdWrite(j["dot11Interface.interfaceName"], "mac", maclist)
                else
                    for kk,vv in pairs (ACLrows) do
                        maclist = maclist .." ".. vv["macAddress"]
                    end
                    nvramSetCmdWrite(j["dot11Interface.interfaceName"], "maclist", maclist)
                    os.execute ("echo \'/bin/nvram commit".."\'".." >> "..CMD_EXEC_SCRIPT)
                    --use wl command so it will not affect other interfaces
                    wlCmdWrite(j["dot11Interface.interfaceName"], "mac", "none")
                    wlCmdWrite(j["dot11Interface.interfaceName"], "mac", maclist)
                end
            end
        end --end of vaprows for loop
        cmd = "/bin/wlconf " ..radioInterfaceName.." up"
        wlconfExclude(CMD_EXEC_SCRIPT,cmd)
        dot11.ServiceStopStart2 (false)
        dot11.ServiceStopStart2 (true)
        cmd = "/bin/wlconf " ..radioInterfaceName.." start"
        wlconfExclude(CMD_EXEC_SCRIPT,cmd)
    end

    if(enabled == 1) then
        --bring the bss up
        if(ssidName ~= nil)then
            cmdStr = WL_CMD_BINARY .. " -i " .. vapInterfaceName .. " ssid " .. "'" .. ssidName .. "'"
            util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)
        end
        wlCmdWrite(vapInterfaceName, "bss", "up")
        os.execute ("echo \'"..IFCONFIG_CMD_BINARY..vapInterfaceName.." up".."\'".." >> "..CMD_EXEC_SCRIPT)
    end

    if(radioInterfaceName ~= nil) then
        dot11.SetWep(radioInterfaceName)
        if ((util.fileExists("/pfrm2.0/HW_JCO110"))) then
            wlCmdWrite(radioInterfaceName, "phy_ed_thresh", "-30")
        else
            wlCmdWrite(radioInterfaceName, "phy_ed_thresh", "-50")
        end
    end
    return 
end

-- dot11STA connected time
function dot11.STA_connectedTime (macAddr)
    joinTimeStr = db.getAttribute("dot11STA", "macAddress", macAddr, "timeConnected")

    if (joinTimeStr == nil) then
        joinTime = 0
    else
        joinTime = tonumber(joinTimeStr)
    end

    -- if join time is zero then return '-'
    if (joinTime == 0) then
        return "-"
    end

    local status, uptime = timeLib.uptime()

    local timeElapsed = uptime - joinTime

    local mins = math.floor(timeElapsed / 60)
    local sec = timeElapsed % 60
    local hours = math.floor (mins / 60)
    mins = mins % 60
    local days = math.floor (hours / 24)
    hours = hours % 24

    timeElapsed = days .. " days, " .. hours .. " hours, " .. mins .. " minutes, " .. sec .. " seconds"

    return timeElapsed
end

-- dot11 stop start services
function dot11.ServiceStopStart2 (start)


    if (start) then
        -- start all services
        os.execute ("echo \'rm -rf /tmp/wps_monitor.pid  > /dev/null\' >> "..CMD_EXEC_SCRIPT)
        os.execute ("echo \'/bin/eapd > /dev/null\' >> "..CMD_EXEC_SCRIPT)
        os.execute ("echo \'/bin/nas > /dev/null\' >> "..CMD_EXEC_SCRIPT)
        os.execute ("echo \'/bin/wps_monitor > /dev/null & \' >> "..CMD_EXEC_SCRIPT)
    else
        -- unsetting the wps pin for generating random pin every time
        cmdStr = "echo \'"..NVRAM_CMD_BINARY .. " unset wps_device_pin\'".." >> "..CMD_EXEC_SCRIPT
        os.execute(cmdStr)
        -- kill all the services
        os.execute ("echo \'killall -9 wps_monitor\' >> "..CMD_EXEC_SCRIPT)
        os.execute ("echo \'killall -9 nas\' >> "..CMD_EXEC_SCRIPT)
        os.execute ("echo \'killall -9 eapd\' >> "..CMD_EXEC_SCRIPT)
    end

end

-- dot11 stop start services
function dot11.ServiceStopStart (start)

    nvramSetCmdWrite("br1", "ifname", GUEST_ZONE_BRIDGE_NAME)
    nvramSetCmdWrite("lan1", "ifname", GUEST_ZONE_BRIDGE_NAME)
    if ((util.fileExists("/pfrm2.0/HW_JCO110")) or (util.fileExists ("/pfrm2.0/HW_HG260ES")) or (util.fileExists ("/pfrm2.0/HW_ALU")))then
        nvramSetCmdWrite("acs", "ifnames", "wl0")
    else
        nvramSetCmdWrite("acs", "ifnames", "wl0 wl1")
    end
    --os.execute(cmdStr)	
    os.execute ("echo \'/bin/nvram commit".."\'".." >> "..CMD_EXEC_SCRIPT)	

    if (start) then
        -- start all services
		if (util.fileExists("/pfrm2.0/BRCM_SDK_5_02_L05P1")) then
        os.execute ("echo \'/bin/ceventd > /dev/null\' >> "..CMD_EXEC_SCRIPT)
		end
        os.execute ("echo \'rm -rf /tmp/wps_monitor.pid  > /dev/null\' >> "..CMD_EXEC_SCRIPT)
        os.execute ("echo \'/bin/eapd > /dev/null\' >> "..CMD_EXEC_SCRIPT)
        os.execute ("echo \'/bin/nas > /dev/null\' >> "..CMD_EXEC_SCRIPT)
        os.execute ("echo \'/bin/wps_monitor > /dev/null & \' >> "..CMD_EXEC_SCRIPT)
        nvramSetCmdWrite("acs", "2g_ch_no_restrict", "1")
		if (util.fileExists("/pfrm2.0/BRCM_SDK_5_02_L05P1")) then
        os.execute ("echo \'/bin/acsd2 > /dev/null & \' >> "..CMD_EXEC_SCRIPT)
		else
        os.execute ("echo \'/bin/acsd > /dev/null & \' >> "..CMD_EXEC_SCRIPT)
		end
        --acs needs 4 seconds to scan whole channel list
        os.execute ("echo \'sleep 4\' >> "..CMD_EXEC_SCRIPT)
    else
        -- unsetting the wps pin for generating random pin every time
        cmdStr = "echo \'"..NVRAM_CMD_BINARY .. " unset wps_device_pin\'".." >> "..CMD_EXEC_SCRIPT
        os.execute(cmdStr)
        -- kill all the services
		if (util.fileExists("/pfrm2.0/BRCM_SDK_5_02_L05P1")) then
        os.execute ("echo \'killall -9 acsd2\' >> "..CMD_EXEC_SCRIPT)
		end
        os.execute ("echo \'killall -9 acsd\' >> "..CMD_EXEC_SCRIPT)
        os.execute ("echo \'killall -9 wps_monitor\' >> "..CMD_EXEC_SCRIPT)
        os.execute ("echo \'killall -9 nas\' >> "..CMD_EXEC_SCRIPT)
        os.execute ("echo \'killall -9 eapd\' >> "..CMD_EXEC_SCRIPT)
		if (util.fileExists("/pfrm2.0/BRCM_SDK_5_02_L05P1")) then
        os.execute ("echo \'killall -9 ceventd\' >> "..CMD_EXEC_SCRIPT)
		end
    end

end

-- dot11 stop start services
function dot11.ServiceStopStartBoot (start)

    cmdStr = NVRAM_CMD_BINARY .. " set br1_ifname='"..GUEST_ZONE_BRIDGE_NAME.."'"
    os.execute(cmdStr)	
    cmdStr = NVRAM_CMD_BINARY .. " set lan1_ifname='"..GUEST_ZONE_BRIDGE_NAME.."'"
    os.execute(cmdStr)
    if ((util.fileExists("/pfrm2.0/HW_JCO110")) or (util.fileExists ("/pfrm2.0/HW_HG260ES")) or (util.fileExists ("/pfrm2.0/HW_ALU")))then
        cmdStr = NVRAM_CMD_BINARY .. " set acs_ifnames='wl0'"
    else
        cmdStr = NVRAM_CMD_BINARY .. " set acs_ifnames='wl0 wl1'"
    end
    os.execute(cmdStr)	
    os.execute("nvram commit")	

	--for Mesh we already have restart of these apps in mesh restart
	if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == false) then	
    if (start) then
        -- start all services
		if (util.fileExists("/pfrm2.0/BRCM_SDK_5_02_L05P1")) then
        os.execute ("/bin/ceventd > /dev/null")
		end
        os.execute ("rm -rf /tmp/wps_monitor.pid  > /dev/null")
        os.execute ("/bin/eapd > /dev/null")
        os.execute ("/bin/nas > /dev/null")
        os.execute ("/bin/wps_monitor > /dev/null & ")
        os.execute ("/bin/nvram set acs_2g_ch_no_restrict='1'")
		if (util.fileExists("/pfrm2.0/BRCM_SDK_5_02_L05P1")) then
        os.execute ("/bin/acsd2 > /dev/null & ")
		else	
        os.execute ("/bin/acsd > /dev/null & ")
		end
        --acs needs 4 seconds to scan whole channel list
        os.execute ("sleep 4")
    else
        -- unsetting the wps pin for generating random pin every time
        cmdStr = NVRAM_CMD_BINARY .. " unset wps_device_pin"
        os.execute(cmdStr)
        -- kill all the services
		if (util.fileExists("/pfrm2.0/BRCM_SDK_5_02_L05P1")) then
        os.execute ("killall -9 acsd2")
		end
        os.execute ("killall -9 acsd")
        os.execute ("killall -9 wps_monitor")
        os.execute ("killall -9 nas")
        os.execute ("killall -9 eapd")
		if (util.fileExists("/pfrm2.0/BRCM_SDK_5_02_L05P1")) then
        os.execute ("killall -9 ceventd")
		end
    end
	end

end


-- dot11 ap start/stop
function dot11.AP_start (aptable, enable)
    --nil check if passed aptable is nil
    if (aptable == nil) then
        return false
    end

    local dot11VAP
    --local dot11VAP = util.tableSplit(aptable, ".", "dot11VAP")
    dot11VAP = util.removePrefix (aptable, "dot11VAP.")

    local vapInterfaceName = db.getAttribute("dot11Interface", "vapName", dot11VAP["vapName"],"interfaceName")
    local radioNo = db.getAttribute("dot11Interface", "vapName", dot11VAP["vapName"],"radioNo")
    local radio = db.getRowWhere ("dot11Radio","radioNo='"..radioNo.."'", false)
    local radioInterfaceName = radio["interfaceName"]
    local cmdStr
    local vapEnabled
    local cmd
   
    -- before doing any operation on the ap , bring down the interface
    wlCmdWrite(vapInterfaceName, "bss", "down")
    os.execute ("echo \'"..IFCONFIG_CMD_BINARY..vapInterfaceName.." down".."\'".." >> "..CMD_EXEC_SCRIPT)
    dot11.ServiceStopStart2 (false)
    local profileRow = db.getRow ("dot11Profile", "profileName", dot11VAP["profileName"])
    -- max clients
    nvramSetCmdWrite(vapInterfaceName, "bss_maxassoc", dot11VAP["maxClients"])

    wlCmdWrite(vapInterfaceName, "bss_maxassoc", dot11VAP["maxClients"])

    nvramSetCmdWrite(vapInterfaceName, "ap_isolate", dot11VAP["apIsolation"])

    wlCmdWrite(vapInterfaceName, "ap_isolate", dot11VAP["apIsolation"])

    nvramSetCmdWrite(vapInterfaceName, "bss_enabled", enable)

    --bring up the interface
    if (enable ==  "0") then
        wlCmdWrite(vapInterfaceName, "bss", "down")
        os.execute ("echo \'"..IFCONFIG_CMD_BINARY..vapInterfaceName.." down".."\'".." >> "..CMD_EXEC_SCRIPT)
    else
        if (profileRow ~= nil) then
            -- set SSID on the interface
            cmdStr = WL_CMD_BINARY .. " -i " .. vapInterfaceName .. " ssid " .. "'" .. profileRow["dot11Profile.ssid"] .. "'"
            util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)
        end
        wlCmdWrite(vapInterfaceName, "bss", "up")
        os.execute ("echo \'"..IFCONFIG_CMD_BINARY..vapInterfaceName.." up".."\'".." >> "..CMD_EXEC_SCRIPT)
    end

    local query = "_ROWID_='1'"
    local apGroupNameRow = db.getRowWhere("apGroupName", query, false)
    if(apGroupNameRow ~= nil and apGroupNameRow["apGroupName"] ~= nil)then
        nvramSetCmdWrite(vapInterfaceName, "apgroup_name", apGroupNameRow["apGroupName"])
    end
 
    -- save the changes
    os.execute ("echo \'/bin/nvram commit".."\'".." >> "..CMD_EXEC_SCRIPT)
    
    cmd = "/bin/wlconf " ..radioInterfaceName.." up"
    wlconfExclude(CMD_EXEC_SCRIPT, cmd)
    dot11.ServiceStopStart2 (true)
    cmd = "/bin/wlconf " ..radioInterfaceName.." start"
    wlconfExclude(CMD_EXEC_SCRIPT, cmd)

    -- calling wep setting again.
    dot11.SetWep (radioInterfaceName)

    return true
end
-------------------------------------------------------------------------------
-- @name dot11.AP_config(rowid, interfaceName, operation)
--
-- @description This function configure DB and  will enable/disable AP on the system.
--
-- @return true on Success and false on Failure.
-------------------------------------------------------------------------------
function dot11.AP_config(rowid, interfaceName, operation)
  
    --locals 

    local NVRAM_CMD_COMMIT = "/bin/nvram commit"
    local valid = false 
    local enStr = "up"
    local enable = "1"
    local radioNo
    local profileName
    local ssid
    local radioInterfaceName
    local cmd

    -- mapping based on the operation string
    if (operation == "enable") then 
        enStr = "up"
        enable = "1" 
    else 
        enStr = "down"
        enable = "0" 
    end


	if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then
		local vapName =  db.getAttribute ("dot11VAP" , "_ROWID_" , rowid , "vapName")
		if (vapName  == BH_AP_NAME ) then
			return valid
		end
        if (vapName  == FH_2_4_VAP_NAME )  or (vapName  == FH_5_0_VAP_NAME) then
            if (vapName  == FH_2_4_VAP_NAME ) then
                band = "b"
            elseif (vapName  == FH_5_0_VAP_NAME) then
                band = "a"
            end
            if (enable == "1") then
                dot11SetFHHideSSID ( "0",  band)
            elseif (enable == "0") then
                dot11SetFHHideSSID ( "1",  band)
            end
        end

	end

    if(interfaceName ~= nil and interfaceName ~= '' and interfaceName ~= " ") then
        radioNo = db.getAttribute("dot11VAP", "_ROWID_", rowid, "radioList")
        profileName = db.getAttribute("dot11VAP", "_ROWID_", rowid, "profileName")
        ssid = db.getAttribute("dot11Profile", "profileName", profileName, "ssid")
        radioInterfaceName = db.getAttribute("dot11Radio", "radioNo", radioNo, "interfaceName")
        --Updating the DB.
        valid = db.setAttribute("dot11VAP", "_ROWID_", rowid, "vapEnabled", enable)
        if (valid == false) then
            --here is the Fail case, db update is failed. Returning from here
            return valid
        end
        local cmd = "/bin/wlconf " ..radioInterfaceName.." down"
        wlconfExclude(CMD_EXEC_SCRIPT, cmd)
        -- nvram, wl settings and starting the (V)AP's
        if(util.fileExists("/flash/BRCM_MESH_ENABLED") == true) then
			--for mesh enabled c ase , dont do bss down for FH APs same as in ECNT
            if(not((interfaceName == "wl0") or (interfaceName  == "wl1" ))) then
                nvramSetCmdWrite(interfaceName, "bss_enabled", enable)
            end
            if((interfaceName == "wl0") or (interfaceName  == "wl1" )) then
                valid = db.setAttribute("dot11Profile",  "_ROWID_", rowid, "broadcastSSID",enable)
            end
        end
        os.execute ("echo \'/bin/nvram commit".."\'".." >> "..CMD_EXEC_SCRIPT)
        if(ssid ~= nil)then
            cmdStr = WL_CMD_BINARY .. " -i " .. interfaceName .. " ssid " .. "'" .. ssid .. "'"
            util.fileAppend(CMD_EXEC_SCRIPT, cmdStr)
        end
        wlCmdWrite(interfaceName, "bss", enStr)
        os.execute ("echo \'"..IFCONFIG_CMD_BINARY..interfaceName.." "..enStr.."\'".." >> "..CMD_EXEC_SCRIPT)
        cmd = "/bin/wlconf " ..radioInterfaceName.." up"
        wlconfExclude(CMD_EXEC_SCRIPT,cmd)
        dot11.ServiceStopStart2 (false)
        dot11.ServiceStopStart2 (true)
        cmd = "/bin/wlconf " ..radioInterfaceName.." start"
        wlconfExclude(CMD_EXEC_SCRIPT,cmd)
        if ((util.fileExists("/pfrm2.0/HW_JCO110"))) then
            wlCmdWrite(radioInterfaceName, "phy_ed_thresh", "-30")
        else
            wlCmdWrite(radioInterfaceName, "phy_ed_thresh", "-50")
        end
    end

    --returning the status
    return valid
end

function dot11.SetWlConf(acsdRestart)

    local cmd = ""
    local radioTable = db.getTable("dot11Radio",true)
    if(radioTable ~= nil)then
        for k,v in pairs(radioTable)do
            local inputTable = v
            local dot11Radios = db.getRowsWhere ("dot11Radio", "radioNo = " .. inputTable["dot11Radio.radioNo"], false)
            local radioInterface = dot11Radios[1]["interfaceName"]
            cmd = WLCONF_CMD_BINARY .." "..radioInterface.. " up"
            os.execute (cmd)
        end
    end

    if(acsdRestart)then
        dot11.ServiceStopStart (false)
        dot11.ServiceStopStart (true)
    else
        dot11.ServiceStopStart2 (false)
        dot11.ServiceStopStart2 (true)
    end

    if(radioTable ~= nil)then
        for k,v in pairs(radioTable)do
            local inputTable = v
            local dot11Radios = db.getRowsWhere ("dot11Radio", "radioNo = " .. inputTable["dot11Radio.radioNo"], false)
            local radioInterface = dot11Radios[1]["interfaceName"]
            cmd = WLCONF_CMD_BINARY .." "..radioInterface.. " start"
            os.execute (cmd)
        end
    end

    local ifTbl = db.getTable("dot11Interface", false)
    for k,v in pairs(ifTbl)do
        local inputTable = v
        if ((util.fileExists("/pfrm2.0/HW_JCO110"))) then
            local cmd = "wl -i " ..inputTable["interfaceName"].. " phy_ed_thresh -30 "
            os.execute(cmd)
        else
            local cmd = "wl -i " ..inputTable["interfaceName"].. " phy_ed_thresh -50 "
            os.execute(cmd)
        end
    end

end

---------------------------------------------------------------------------------
--@name dot11.setWepBoot
--
--@description this function set WEP parameter on AP
--
--@return 
---------------------------------------------------------------------------------
function dot11.SetWep (radioName)

    local radioNo = db.getAttribute ("dot11Radio", "interfaceName", radioName, "radioNo")
    local vaps = db.getRowsWhere ("dot11Interface", "radioNo='"..radioNo.."'", false)
    for k, v in pairs (vaps) do
	    local vaprow = db.getRowWhere ("dot11VAP", "vapName='"..v["vapName"].."'", false)
        local profile = db.getRowWhere ("dot11Profile", "profileName='"..vaprow["profileName"].."'")
        if (profile and profile["dot11Profile.security"] == "WEP") then
            local vapInterface = v["interfaceName"]
            cmdStr = "echo \'"..WL_CMD_BINARY .. " -i " .. vapInterface .. " " .. WL_SUB_CMD_WSEC .. " 1\'".." >> "..CMD_EXEC_SCRIPT
            os.execute(cmdStr)
            cmdStr = "echo \'"..WL_CMD_BINARY .. " -i " .. vapInterface .. " " .. WL_SUB_CMD_ADDWEP .. " " .. profile["dot11Profile.defWepkeyIdx"] .. " " .. profile["dot11Profile.wepkey"..profile["dot11Profile.defWepkeyIdx"]].."\' >> "..CMD_EXEC_SCRIPT
            os.execute(cmdStr)
        end        
    end
end

---------------------------------------------------------------------------------
--@name dot11.setWepBoot
--
--@description this function set WEP parameter on AP on reboot
--
--@return 
---------------------------------------------------------------------------------
function dot11.setWepBoot (radioName)
    local radioNo = db.getAttribute ("dot11Radio", "interfaceName", radioName, "radioNo")
    local vaps = db.getRowsWhere ("dot11Interface", "radioNo='"..radioNo.."'", false)
    for k, v in pairs (vaps) do
	    local vaprow = db.getRowWhere ("dot11VAP", "vapName='"..v["vapName"].."'", false)
        local profile = db.getRowWhere ("dot11Profile", "profileName='"..vaprow["profileName"].."'")
        if (profile and profile["dot11Profile.security"] == "WEP") then
            local vapInterface = v["interfaceName"]
            cmdStr = WL_CMD_BINARY .. " -i " .. vapInterface .. " " .. WL_SUB_CMD_WSEC .. " 1"
            os.execute(cmdStr)
            cmdStr = WL_CMD_BINARY .. " -i " .. vapInterface .. " " .. WL_SUB_CMD_ADDWEP .. " " .. profile["dot11Profile.defWepkeyIdx"] .. " " .. profile["dot11Profile.wepkey"..profile["dot11Profile.defWepkeyIdx"]]
            os.execute(cmdStr)
        end        
    end
end

local function getStaConfig (security)
    local staConfig = 0

    if (security == "OPEN") then
        staConfig = 1;
    elseif (security == "WEP") then
        staConfig = 2;
    elseif (security == "WPA") then
        staConfig = 32;
    elseif (security == "WPA2") then
        staConfig = 64;
    elseif (security == "WPA+WPA2") then
        staConfig = 96;
    elseif (security == "WEP+WPA") then
        staConfig = 34;
    elseif (security == "WEP+WPA+WPA2") then
        staConfig = 98;
    end
    return staConfig
end


-- acl add
function dot11.ACL_Add (vapName, macAddress, operation)

    local vaprows = db.getRowsWithJoin({"dot11VAP:dot11Interface:vapName"}, "dot11VAP.vapName", vapName)

    
    for k,v in pairs(vaprows) do
        if (operation == "add" or operation == "delete") then
            local cmdStr
            local maclist = ""
            rows = db.getRowsWhere ("dot11ACL", "vapName='".. vapName .."'", false)
            cmdStr = "echo \'"..NVRAM_CMD_BINARY .. " set ".. v["dot11Interface.interfaceName"] .."_maclist="
            for k,v in pairs (rows) do
                maclist = maclist .." ".. v["macAddress"]
            end
            if rows[1] == nil then maclist = "*DEL*" end
            cmdStr = cmdStr .. "'"..maclist.."'".."\'".." >> "..CMD_EXEC_SCRIPT
            os.execute (cmdStr)
        else
            -- edit not expected
            return "ERROR", "DOT11_ACL_CONFIG_FAILED"
        end

    end
    return "OK", "STATUS_OK"
end

function dot11.ConvertRate (dot11Rate)

    local txRate 
    if (tonumber (dot11Rate) > 127) then        --HT rates
        if (tonumber (dot11Rate) > 151) then    --vht rates
            txRate = tonumber (dot11Rate) - 152
            if txRate > 9 then txRate = "-1" end
        else                                    -- mcs rate
            txRate = tonumber (dot11Rate) - 128
        end
    else -- legacy rate
        -- converting the rates to correct value as js is passing values according to atheros
        if dot11Rate == "11" then
            txRate = 6
        elseif dot11Rate == "15" then
            txRate = 9
        elseif dot11Rate == "10" then
            txRate = 12
        elseif dot11Rate == "14" then
            txRate = 18
        elseif dot11Rate == "9" then
            txRate = 24
        elseif dot11Rate == "13" then
            txRate = 36
        elseif dot11Rate == "8" then
            txRate = 48
        elseif dot11Rate == "12" then
            txRate = 54
        elseif dot11Rate == "25" then
            txRate = 5.5
        elseif dot11Rate == "26" then
            txRate = 2
        elseif dot11Rate == "27" then
            txRate = 1
        else
            txRate = "-1"
        end
    end
    return txRate
end

-- radio settings apply
function dot11.radio_config_apply (inputTable)

    if (inputTable == nil or inputTable["dot11Radio.radioNo"] == nil) then
        return false
    end

    local cmdStr
    local channel_sideband
    local rate = 0
    local sideband = ""
    local sideBandFlag = 0
    local txPower
    local maxClientsPerRadio
    local maxClientdot11Radio
    local wl_cmd_cspec
    local vapInterfaceName1
    local vapInterfaceName2
    local vapInterfaceName3
    local radioInterfaceName
    local dot11Radios = db.getRowsWhere ("dot11Radio", "radioNo = " .. inputTable["dot11Radio.radioNo"], false) 
    local dot11Interfaces = db.getRowsWhere ("dot11Interface", "radioNo = " .. inputTable["dot11Radio.radioNo"], false) 
    -- no interface corresponding to the radio
    if (dot11Interfaces == nil or dot11Interfaces[1] == nil) then
       return false
    end

    radioInterfaceName = dot11Radios[1]["interfaceName"]
    vapInterfaceName1 = dot11Interfaces[1]["interfaceName"]
    vapInterfaceName2 = dot11Interfaces[2]["interfaceName"]
    vapInterfaceName3 = dot11Interfaces[3]["interfaceName"]
    local rateBw = "20"
    -- bring down the radio interface
    os.execute ("echo \'"..IFCONFIG_CMD_BINARY..radioInterfaceName.." down".."\'".." >> "..CMD_EXEC_SCRIPT)
    os.execute ("echo \'/bin/wl -i "..radioInterfaceName.." down".."\'".." >> "..CMD_EXEC_SCRIPT)
    --dot11.if_up ( radioInterfaceName, 0)
    dot11.ServiceStopStart (false)

    -- Set the radio to AP mode
    wlCmdWrite(radioInterfaceName, WL_SUB_CMD_AP_MODE, "1")

    -- Set the txPower of the radio
    txPower = dot11Radios[1]["txPower"]
    wlCmdWrite(radioInterfaceName, "txpwr1 -d", txPower)

    --set the maxassoc value for radios
    maxClientsPerRadio = db.getAttribute ("environment", "name", "MAX_CLIENTS_PER_RADIO", "value")
    maxClientdot11Radio = dot11Radios[1]["maxClientsPerRadio"]

    if(tonumber(maxClientdot11Radio) < tonumber(maxClientsPerRadio))then
        nvramSetCmdWrite(radioInterfaceName, "maxassoc", maxClientdot11Radio)
    else
        nvramSetCmdWrite(radioInterfaceName, "maxassoc", maxClientsPerRadio)
    end

    if (inputTable["dot11Radio.radioCountry"]~= nil) then
        nvramSetCmdWrite(radioInterfaceName, "country_code", inputTable["dot11Radio.radioCountry"])
    end

    if(inputTable["dot11Radio.radioCountryRev"] ~= nil and tonumber(inputTable["dot11Radio.radioCountryRev"]) ~= 0) then
        nvramSetCmdWrite(radioInterfaceName, "country_rev", inputTable["dot11Radio.radioCountryRev"])
	if(util.fileExists("/pfrm2.0/HW_JCOW401") == true ) then 
            if(inputTable["dot11Radio.band"] == "b")then 
                if(tonumber(inputTable["dot11Radio.radioCountryRev"]) == 987)then
                    nvramSetCmdWrite(radioInterfaceName, "country_rev", 995)
                    os.execute("echo /bin/wl -i " ..radioInterfaceName.. " down >>" .. CMD_EXEC_SCRIPT)
                    os.execute("echo /bin/wl -i " ..radioInterfaceName.. " country IN/995 >>" .. CMD_EXEC_SCRIPT)
                    os.execute("echo /bin/wl -i " ..radioInterfaceName.. " up >>" .. CMD_EXEC_SCRIPT)
                    
                elseif(tonumber(inputTable["dot11Radio.radioCountryRev"]) == 991)then
                    nvramSetCmdWrite(radioInterfaceName, "country_rev", 988)
                    os.execute("echo /bin/wl -i " ..radioInterfaceName.. " down >>" .. CMD_EXEC_SCRIPT)
                    os.execute("echo /bin/wl -i " ..radioInterfaceName.. " country IN/988 >>" .. CMD_EXEC_SCRIPT)
                    os.execute("echo /bin/wl -i " ..radioInterfaceName.. " up >>" .. CMD_EXEC_SCRIPT)
                    
                end
	      end
	  end 

      if(util.fileExists("/pfrm2.0/HW_JCOW403") == true ) then
            if(inputTable["dot11Radio.band"] == "b")then 
                if(tonumber(inputTable["dot11Radio.radioCountryRev"]) == 987)then
                    nvramSetCmdWrite(radioInterfaceName, "country_rev", 2)
                    os.execute("echo /bin/wl -i " ..radioInterfaceName.. " down >>" .. CMD_EXEC_SCRIPT)
                    os.execute("echo /bin/wl -i " ..radioInterfaceName.. " country IN/2 >>" .. CMD_EXEC_SCRIPT)
                    os.execute("echo /bin/wl -i " ..radioInterfaceName.. " up >>" .. CMD_EXEC_SCRIPT)
                elseif(tonumber(inputTable["dot11Radio.radioCountryRev"]) == 991)then
                    nvramSetCmdWrite(radioInterfaceName, "country_rev", 1)
                    os.execute("echo /bin/wl -i " ..radioInterfaceName.. " down >>" .. CMD_EXEC_SCRIPT)
                    os.execute("echo /bin/wl -i " ..radioInterfaceName.. " country IN/1 >>" .. CMD_EXEC_SCRIPT)
                    os.execute("echo /bin/wl -i " ..radioInterfaceName.. " up >>" .. CMD_EXEC_SCRIPT)
                    
                end
	      end
	  end
      if(util.fileExists("/pfrm2.0/HW_JCOW404") == true ) then 
            if(inputTable["dot11Radio.band"] == "b")then 
                if(tonumber(inputTable["dot11Radio.radioCountryRev"]) == 987)then
                    nvramSetCmdWrite(radioInterfaceName, "country_rev", 1)
                    os.execute("echo /bin/wl -i " ..radioInterfaceName.. " down >>" .. CMD_EXEC_SCRIPT)
                    os.execute("echo /bin/wl -i " ..radioInterfaceName.. " country IN/1 >>" .. CMD_EXEC_SCRIPT)
                    os.execute("echo /bin/wl -i " ..radioInterfaceName.. " up >>" .. CMD_EXEC_SCRIPT)
                elseif(tonumber(inputTable["dot11Radio.radioCountryRev"]) == 991)then
                    nvramSetCmdWrite(radioInterfaceName, "country_rev", 0)
                    os.execute("echo /bin/wl -i " ..radioInterfaceName.. " down >>" .. CMD_EXEC_SCRIPT)
                    os.execute("echo /bin/wl -i " ..radioInterfaceName.. " country IN/0 >>" .. CMD_EXEC_SCRIPT)
                    os.execute("echo /bin/wl -i " ..radioInterfaceName.. " up >>" .. CMD_EXEC_SCRIPT)
                    
                end
	      end
	  end

        if(util.fileExists("/pfrm2.0/HW_FIBERHOME_JCO300") == true ) then 
            if(inputTable["dot11Radio.band"] == "b")then 
                if(tonumber(inputTable["dot11Radio.radioCountryRev"]) == 987)then
                    nvramSetCmdWrite(radioInterfaceName, "country_rev", 978)
                elseif(tonumber(inputTable["dot11Radio.radioCountryRev"]) == 991)then
                    nvramSetCmdWrite(radioInterfaceName, "country_rev", 979)
                end
            else
                local f = io.open("/tmp/hwVersion","r")
                local hwVersion = f:read ("*line")
                f:close()
                if (hwVersion and hwVersion == "2.0") then
                    nvramSetCmdWrite(radioInterfaceName, "country_rev", 979)
                else
                    nvramSetCmdWrite(radioInterfaceName, "country_rev", 991)
                end
            end
        end 
    end

    --build chspec command to execute in the end if nvram fails
    wl_cmd_cspec = "echo \'"..WL_CMD_BINARY .. " -i "..radioInterfaceName.." chanspec "

    if (inputTable["dot11Radio.configuredChannel"]~= nil and inputTable["dot11Radio.configuredChannel"] ~= "0") then
        wl_cmd_cspec = wl_cmd_cspec..inputTable["dot11Radio.configuredChannel"]
        if ((inputTable["dot11Radio.chanWidth"] == "40" or inputTable["dot11Radio.chanWidth"] == "2040")) then
            if (tonumber(inputTable["dot11Radio.sideBand"]) == 0) then
                inputTable["dot11Radio.sideBand"] = "l"
                channel_sideband = "l"
                wl_cmd_cspec = wl_cmd_cspec.."l"
            else
	    	inputTable["dot11Radio.sideBand"] = "u"
                channel_sideband = "u"
                wl_cmd_cspec = wl_cmd_cspec.."u"
            end
                sideband = "40"..inputTable["dot11Radio.sideBand"]
        elseif (inputTable["dot11Radio.chanWidth"] == "80" or inputTable["dot11Radio.chanWidth"] == "4080") then
            sideband = "80"
            wl_cmd_cspec = wl_cmd_cspec.."/80"
        elseif (inputTable["dot11Radio.chanWidth"] == "20")then
            sideband = "20"
        end
    else
        sideband = ""
    end
    if(inputTable["dot11Radio.configuredChannel"] ~= nil and tonumber(inputTable["dot11Radio.configuredChannel"]) ~= tonumber(0))then
        if(inputTable["dot11Radio.band"] == "a")then
            -- nvram set for channel and sideband
            nvramSetCmdWrite(radioInterfaceName, "chanspec", "5g"..inputTable["dot11Radio.configuredChannel"].."/"..sideband)
        else
            -- nvram set for channel and sideband
            nvramSetCmdWrite(radioInterfaceName, "chanspec", "2g"..inputTable["dot11Radio.configuredChannel"].."/"..sideband)
        end
        -- nvram set for channel and sideband
        if (inputTable["dot11Radio.chanWidth"] == "80" or inputTable["dot11Radio.chanWidth"] == "4080") then
            nvramSetCmdWrite(radioInterfaceName, "channel", inputTable["dot11Radio.configuredChannel"].."/80")
			if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then
            	nvramSetCmdWrite(radioInterfaceName, "chanspec", inputTable["dot11Radio.configuredChannel"].."/80")
			end	
        elseif (inputTable["dot11Radio.chanWidth"] == "20") then
            nvramSetCmdWrite(radioInterfaceName, "channel", inputTable["dot11Radio.configuredChannel"])
        elseif (inputTable["dot11Radio.chanWidth"] == "40" or inputTable["dot11Radio.chanWidth"] == "2040") then
            nvramSetCmdWrite(radioInterfaceName, "channel", inputTable["dot11Radio.configuredChannel"]..""..channel_sideband)
        end
    else
        -- nvram set for channel and sideband
        nvramSetCmdWrite(radioInterfaceName, "chanspec", "0")
        nvramSetCmdWrite(radioInterfaceName, "channel", "0")
    end

    local nvramBw = NVRAM_CHANNEL_BW_80
    if (inputTable["dot11Radio.chanWidth"] == "80" or inputTable["dot11Radio.chanWidth"] == "4080") then
        nvramBw = NVRAM_CHANNEL_BW_80
        rateBw = "80"
    elseif (inputTable["dot11Radio.chanWidth"] == "40" or inputTable["dot11Radio.chanWidth"] == "2040") then
        nvramBw = NVRAM_CHANNEL_BW_40
        rateBw = "40"
    else
        nvramBw = NVRAM_CHANNEL_BW_20
    end
    nvramSetCmdWrite(radioInterfaceName, "bw_cap", nvramBw)

    -- turn off/on the coexistance
    if (inputTable["dot11Radio.chanWidth"] == "80" or inputTable["dot11Radio.chanWidth"] == "40") then
        -- turn of the coexistance
        nvramSetCmdWrite(radioInterfaceName, "obss_coex", "0")
    else
        -- turn on the coexistance
        nvramSetCmdWrite(radioInterfaceName, "obss_coex", "1")
    end

    local radioNo = db.getAttribute ("dot11Radio", "interfaceName", radioInterfaceName, "radioNo")

    -- client capability start
    if (inputTable["dot11Radio.opMode"] == '4' or (inputTable["dot11Radio.band"] == "a" and inputTable["dot11Radio.opMode"] == '6')) then --n only and n/ac mode
        nvramSetCmdWrite(radioInterfaceName, "bss_opmode_cap_reqd", "2")            
    elseif(inputTable["dot11Radio.band"] == "a" and inputTable["dot11Radio.opMode"] == '3')then --ac only
        nvramSetCmdWrite(radioInterfaceName, "bss_opmode_cap_reqd", "3")            
    elseif(inputTable["dot11Radio.band"] == "b" and (inputTable["dot11Radio.opMode"] == '1' or inputTable["dot11Radio.opMode"] == '2' or inputTable["dot11Radio.opMode"] == '3' or inputTable["dot11Radio.opMode"] == '5'))then --rest of 2.4GHz modes
        nvramSetCmdWrite(radioInterfaceName, "bss_opmode_cap_reqd", "0")            
    elseif(inputTable["dot11Radio.band"] == "a" and (inputTable["dot11Radio.opMode"] == '1' or inputTable["dot11Radio.opMode"] == '2' or inputTable["dot11Radio.opMode"] == '5')) then --a/n/ac , a/n and a modes
        nvramSetCmdWrite(radioInterfaceName, "bss_opmode_cap_reqd", "0")            
    end  -- client capability end 
	
    local nmode = false
    if ((inputTable["dot11Radio.band"] == "a" and tonumber(inputTable["dot11Radio.opMode"]) ~= tonumber(1)) or (inputTable["dot11Radio.band"] == "b" and(tonumber(inputTable["dot11Radio.opMode"]) == tonumber(3) or tonumber(inputTable["dot11Radio.opMode"]) == tonumber(4) or tonumber(inputTable["dot11Radio.opMode"]) == tonumber(5)))) then
            nmode = true
    end
    if (nmode) then
        --enabling or disabling wme
        if(tonumber(inputTable["dot11Radio.txRate"]) < tonumber(127)) then
            nvramSetCmdWrite(radioInterfaceName, "nmode", "-1") -- auto
            if(tonumber(inputTable["dot11Radio.txRate"]) == tonumber(0))then
                nvramSetCmdWrite(radioInterfaceName, "nmcsidx", "-1")
            end
        else
            nvramSetCmdWrite(radioInterfaceName, "nmode", "1") -- n mode on
        end
        nvramSetCmdWrite(radioInterfaceName, "nmode_protection", "auto") -- n mode off         
    else
        nvramSetCmdWrite(radioInterfaceName, "nmode", "0")-- n mode off
        nvramSetCmdWrite(radioInterfaceName, "nmode_protection", "off")        
    end
    nvramSetCmdWrite(radioInterfaceName, "wme", "on")
 
    nvramSetCmdWrite(radioInterfaceName, "rts", inputTable["dot11Radio.rtsThreshold"])

    nvramSetCmdWrite(radioInterfaceName, "bcn", inputTable["dot11Radio.beaconInterval"])

    nvramSetCmdWrite(radioInterfaceName, "dtim", inputTable["dot11Radio.dtimInterval"])
    --802.11g protection mode
    if(tonumber(inputTable["dot11Radio.rtsCtsProtect"]) == 1)then
        wlCmdWrite(radioInterfaceName, "gmode_protection_override", "-1")
        nvramSetCmdWrite(radioInterfaceName, "gmode_protection", "auto")
        wlCmdWrite(vapInterfaceName1, "gmode_protection_override", "-1")
        nvramSetCmdWrite(vapInterfaceName1, "gmode_protection", "auto")
        wlCmdWrite(vapInterfaceName2, "gmode_protection_override", "-1")
        nvramSetCmdWrite(vapInterfaceName2, "gmode_protection", "auto")
        wlCmdWrite(vapInterfaceName3, "gmode_protection_override", "-1")
        nvramSetCmdWrite(vapInterfaceName3, "gmode_protection", "auto")
    else
        wlCmdWrite(radioInterfaceName, "gmode_protection_override", "0")
        nvramSetCmdWrite(radioInterfaceName, "gmode_protection", "off")
        wlCmdWrite(vapInterfaceName1, "gmode_protection_override", "0")
        nvramSetCmdWrite(vapInterfaceName1, "gmode_protection", "off")
        wlCmdWrite(vapInterfaceName2, "gmode_protection_override", "0")
        nvramSetCmdWrite(vapInterfaceName2, "gmode_protection", "off")
        wlCmdWrite(vapInterfaceName3, "gmode_protection_override", "0")
        nvramSetCmdWrite(vapInterfaceName3, "gmode_protection", "off")
    end

    --preamble mode[BRCM values Auto(-1),Short(0),Long(1)]
    if(inputTable["dot11Radio.preambleMode"] == "Short")then
        nvramSetCmdWrite(radioInterfaceName, "plcphdr", "auto")
        nvramSetCmdWrite(vapInterfaceName1, "plcphdr", "auto")
        nvramSetCmdWrite(vapInterfaceName2, "plcphdr", "auto")
        nvramSetCmdWrite(vapInterfaceName3, "plcphdr", "auto")
    elseif(inputTable["dot11Radio.preambleMode"] == "Long")then
        nvramSetCmdWrite(radioInterfaceName, "plcphdr", "debug")
        nvramSetCmdWrite(vapInterfaceName1, "plcphdr", "debug")
        nvramSetCmdWrite(vapInterfaceName2, "plcphdr", "debug")
        nvramSetCmdWrite(vapInterfaceName3, "plcphdr", "debug")
    else
        nvramSetCmdWrite(radioInterfaceName, "plcphdr", "long")
        nvramSetCmdWrite(vapInterfaceName1, "plcphdr", "long")
        nvramSetCmdWrite(vapInterfaceName2, "plcphdr", "long")
        nvramSetCmdWrite(vapInterfaceName3, "plcphdr", "long")
    end
    

    -- apply the configurations
    os.execute ("echo \'nvram commit >> "..CMD_EXEC_SCRIPT)
    --Removing the entries from connected clients for wl0/1 when user configure radio page
    db.execute ("delete from dot11STA where interfaceName='"..radioInterfaceName.."'")

	if (util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == false) then
    os.execute ("echo \'"..IFCONFIG_CMD_BINARY..radioInterfaceName.." up".."\'".." >> "..CMD_EXEC_SCRIPT)
    os.execute ("echo \'/bin/wl -i "..radioInterfaceName.." up".."\'".." >> "..CMD_EXEC_SCRIPT)
    cmd = "/bin/wlconf " ..radioInterfaceName.." up"
    wlconfExclude(CMD_EXEC_SCRIPT,cmd)
    dot11.ServiceStopStart (true)
    if (inputTable["dot11Radio.configuredChannel"]~= nil and inputTable["dot11Radio.configuredChannel"] ~= "0") then
        os.execute (wl_cmd_cspec.. " > /dev/null".."\'".." >> "..CMD_EXEC_SCRIPT)
    end
    cmd = "/bin/wlconf " ..radioInterfaceName.." start"
    wlconfExclude(CMD_EXEC_SCRIPT,cmd)
	else
    	if (inputTable["dot11Radio.configuredChannel"]~= nil and inputTable["dot11Radio.configuredChannel"] ~= "0") then
			wl_cmd_cspec = wl_cmd_cspec:gsub ("echo \'","")
			dot11meshReStartChannelChange (wl_cmd_cspec)
            os.execute("sleep 2")
            wlCmdWrite (radioInterfaceName, "bss", "up")
    	else
			dot11meshReStart ()
		end
	end

    -- rate start
    if (inputTable["dot11Radio.txRate"] ~= "0") then -- custom rate
        local txRate = dot11.ConvertRate (inputTable["dot11Radio.txRate"]) 
        if (tonumber(inputTable["dot11Radio.txRate"]) < tonumber(127)) then --legacy rates
            -- set mcs index to -2
            nvramSetCmdWrite(radioInterfaceName, "nmcsidx", "-2")
            -- set the rate
            if(inputTable["dot11Radio.band"] == "a")then
                wlCmdWrite(radioInterfaceName, "5g_rate -r", dot11.ConvertRate(inputTable["dot11Radio.txRate"]))
	    	else
                wlCmdWrite(radioInterfaceName, "2g_rate -r", dot11.ConvertRate(inputTable["dot11Radio.txRate"]))
	    	end
        else
            if (tonumber(inputTable["dot11Radio.txRate"]) > tonumber(151)) then --vht rates
                if(inputTable["dot11Radio.band"] == "a")then                    
                    wlCmdWrite(radioInterfaceName, "5g_rate -v", dot11.ConvertRate(inputTable["dot11Radio.txRate"]).." -b "..rateBw.." -s 3")
				end
            else
                nvramSetCmdWrite(radioInterfaceName, "nmcsidx", txRate)
                if(inputTable["dot11Radio.band"] == "a")then  --ht rates
                    wlCmdWrite(radioInterfaceName, "5g_rate -h", dot11.ConvertRate(inputTable["dot11Radio.txRate"]).. " -b "..rateBw)
				else
                    wlCmdWrite(radioInterfaceName, "2g_rate -h", dot11.ConvertRate(inputTable["dot11Radio.txRate"]).. " -b "..rateBw)
				end
	    	end
        end
    end -- rate end
    if(inputTable["dot11Radio.preambleMode"] == "Short")then
        wlCmdWrite(radioInterfaceName, "plcphdr", "auto")
        wlCmdWrite(vapInterfaceName1, "plcphdr", "auto")
        wlCmdWrite(vapInterfaceName2, "plcphdr", "auto")
        wlCmdWrite(vapInterfaceName3, "plcphdr", "auto")
    elseif(inputTable["dot11Radio.preambleMode"] == "Long")then
        wlCmdWrite(radioInterfaceName, "plcphdr", "debug")
        wlCmdWrite(vapInterfaceName1, "plcphdr", "debug")
        wlCmdWrite(vapInterfaceName2, "plcphdr", "debug")
        wlCmdWrite(vapInterfaceName3, "plcphdr", "debug")
    else
        wlCmdWrite(radioInterfaceName, "plcphdr", "long")
        wlCmdWrite(vapInterfaceName1, "plcphdr", "long")
        wlCmdWrite(vapInterfaceName2, "plcphdr", "long")
        wlCmdWrite(vapInterfaceName3, "plcphdr", "long")
    end
    if ((util.fileExists("/pfrm2.0/HW_JCO110"))) then
        wlCmdWrite(radioInterfaceName, "phy_ed_thresh", "-30")
    else
        wlCmdWrite(radioInterfaceName, "phy_ed_thresh", "-50")
    end

    -- change the wps state to configured mode
    db.setAttribute("dot11WPSState", "_ROWID_", 1, "wpsState", "1")
    return true
end 

function dot11.dscpToCosMappingFlashConfigCreate (inputTable)

	--print ("Creating ".. DSCP_PBIT_FLASH_FILE .. " from current settings")

	io.output(DSCP_PBIT_FLASH_FILE)
	io.write ("dscp1P = {}\n")
	io.write ("dscp1PMapSetFromAcs = {}\n")
	for k,v in pairs (inputTable) do
		if (k ~= "dscpToCosMapping._ROWID_") then
			io.write("dscp1P[\""..k.."\"] = \""..v.. "\"\n")
		end
	end
	if (inputTable["dscpToCosMapping.dscpMapSetFromTr"] == "1") then
		io.write("dscp1PMapSetFromAcs[\"mapSet\"] = \"1\"\n")
	else
		io.write("dscp1PMapSetFromAcs[\"mapSet\"] = \"0\"\n")
	end
	io.close ()

	--print ("printing file content as a string")
	--print (util.fileToString (DSCP_PBIT_FLASH_FILE))

end

function dot11.import (dot11Config, defaultConfig, removeConfig)
    --if dot11Config comes nil fill with default configuration
    if (dot11Config == nil) then
        dot11Config = defaultConfig
    end

	--moved to bridge import
    --os.execute ("/pfrm2.0/bin/customSSIDAdd.sh &")
    local interfaceTmp = {}
    local vapTmp = {}
    local radioTmp = {}
    local cardTmp = {}
    local profileTmp = {}
    local aclTmp = {}
    local wpsTmp = {}
    local dot11ScheduleTmp = {}
    local globalTmp = {}
    local authorizedTmp = {}
    local dscpMappingTmp = {}
    local dscpToCosMappingTmp = {}
    local cosMappingTmp = {}
    local interfaceToBridgeTmp = {}
    local apGroupNameTmp = {}
    local status
    local qosLimit = 63

    for i,v in ipairs (dot11Config.profile) do
        if (v["pskPassAscii"] ~= nil and v["pskPassAscii"] ~= "") then
            status, v["pskPassAscii"] = passwdSecureLib.decryptData (v["pskPassAscii"], "")
        end
        if((string.find(dot11Config.radio[1]["opMode"],"ng")) and (dot11Config.radio[1]["puren"] == "1")) then
            if(v["security"] == "WEP" or v["security"] == "WPA" or v["security"] == "WPA+WPA2") then
                v["security"] = "WPA2"
                v["pairwiseCiphers"] = "CCMP"
            end
        end
        if(v["security"] == "WPA2") then
            v["pairwiseCiphers"] = "CCMP"
        end
    end
    interfaceTmp = config.update (dot11Config.interface, defaultConfig.interface, removeConfig.interface)
    vapTmp = config.update (dot11Config.vap, defaultConfig.vap, removeConfig.vap)
    radioTmp = config.update (dot11Config.radio, defaultConfig.radio, removeConfig.radio)
    cardTmp = config.update (dot11Config.card, defaultConfig.card, removeConfig.card)
    profileTmp = config.update (dot11Config.profile, defaultConfig.profile, removeConfig.profile)
    aclTmp = config.update (dot11Config.acl, defaultConfig.acl, removeConfig.acl)
    wpsTmp = config.update (dot11Config.wps, defaultConfig.wps, removeConfig.wps)
    globalTmp = config.update (dot11Config.global, defaultConfig.global, removeConfig.global)
    guestTmp = config.update (dot11Config.guestZone, defaultConfig.guestZone, removeConfig.guestZone)
    authorizedTmp = config.update (dot11Config.authorizedAP, defaultConfig.authorizedAP, removeConfig.authorizedAP)
    dscpMappingTmp = config.update (dot11Config.dscpToQueueMapping, defaultConfig.dscpToQueueMapping, removeConfig.dscpToQueueMapping)
    dscpToCosMappingTmp= config.update (dot11Config.dscpToCosMapping, defaultConfig.dscpToCosMapping, removeConfig.dscpToCosMapping)
    cosMappingTmp = config.update (dot11Config.cosToQueueMapping, defaultConfig.cosToQueueMapping, removeConfig.cosToQueueMapping)
    interfaceToBridgeTmp = config.update (dot11Config.dot11InterfaceToBridge, defaultConfig.dot11InterfaceToBridge, removeConfig.dot11InterfaceToBridge)
    apGroupNameTmp = config.update (dot11Config.apGroupName, defaultConfig.apGroupName, removeConfig.apGroupName)
    
    local dot11If = {}
    local changeWPSvapName=0

    
    --create interfaces from ascii file
    if (interfaceTmp ~= nil and #interfaceTmp ~= 0) then
        local wpsTable = db.getRowWhere("dot11WPS", "rowid =1" , false)
        for i,v in ipairs (interfaceTmp) do
            if (v["interfaceName"] == "wl0.1" and tonumber(v["_ROWID_"])== tonumber(1)) then
                v["interfaceName"] = "wl0"
                changeWPSvapName=1
            end
            if(v["interfaceName"] == "wl0.2" and tonumber(v["_ROWID_"])== tonumber(2)) then
                v["interfaceName"] = "wl0.1"
                changeWPSvapName=1
            end
            if(v["interfaceName"] == "wl0.3" and tonumber(v["_ROWID_"])== tonumber(3))then
                v["interfaceName"] = "wl0.2"
                changeWPSvapName=1
            end
            if (v["interfaceName"] == "wl1.1" and tonumber(v["_ROWID_"])== tonumber(4)) then
                v["interfaceName"] = "wl1"
                changeWPSvapName=1
            end
            if(v["interfaceName"] == "wl1.2" and tonumber(v["_ROWID_"])== tonumber(5)) then
                v["interfaceName"] = "wl1.1"
                changeWPSvapName=1
            end
            if(v["interfaceName"] == "wl1.3" and tonumber(v["_ROWID_"])== tonumber(6))then
                v["interfaceName"] = "wl1.2"
                changeWPSvapName=1
            end
            dot11If[i]=v
            v = util.addPrefix (v, "dot11Interface.")
            if (v["dot11Interface.LogicalIfName"] == "IF4" or v["dot11Interface.LogicalIfName"] == "IF5" or v["dot11Interface.LogicalIfName"] == "IF6" or v["dot11Interface.LogicalIfName"] == "IF7") then
                v["dot11Interface.LogicalIfName"] = 'IF2'
                v["dot11Interface.defaultLANSubnet"] = '1'
            end
            status, message = dot11Interface.config (v, "-1", "add")
            util.appendDebugOut ("dot11Interface.config(" .. i .. ") returned " .. status .. "," .. message .. "\n")
        end
    end


        
    --local dot11If = db.getTable ("dot11Interface", false)
    local inputTable = {}
    local enablevaps = {} 

    
    -- create vaps first
    for i,v in ipairs (dot11If) do
        vapIfName = v["interfaceName"] or "NONE"
        vapMode = "NONE"
        radioIfName = "NONE"

		-- initialize vap name to interface name mapping
		enablevaps[i] = {}
		enablevaps[i]["vapName"] = v["vapName"]
		enablevaps[i]["interfaceName"] = v["interfaceName"]
		enablevaps[i]["vapEnabled"] = "0"
        
        if (vapTmp ~= nil and #vapTmp ~= 0) then
            for ii,vv in ipairs (vapTmp) do
                if (vv["vapName"] == v["vapName"]) then
                    vapMode = vv["dot11Mode"] 
                    enablevaps[i]["vapEnabled"] = vv["vapEnabled"]
                    break
                end
            end
        end
        
        if (radioTmp ~= nil and #radioTmp ~= 0) then
            for ii,vv in ipairs (radioTmp) do
                if (vv["radioNo"] == v["radioNo"]) then
                    radioIfName = vv["interfaceName"]
                    break
                end
            end
        end
        
        inputTable["dot11Interface.macAddress"] = ifDevLib.getMac (vapIfName)
        db.update ("dot11Interface", inputTable, i);
    end

    local status = "ERROR"
    local message = ""

    --global settings
    local globalConfig = util.addPrefix (globalTmp, "dot11GlobalConfig.");
    db.insert ("dot11GlobalConfig", globalConfig);
    
    --apply card settings
    if (cardTmp ~= nil and #cardTmp ~= 0) then
        for i,v in ipairs (cardTmp) do
            v = util.addPrefix (v, "dot11Card.")
            status ,message = dot11.card_config (v, "-1", "add");
            util.appendDebugOut ("dot11.card_config(" .. i .. ") returned " .. status .. "," .. message .. "\n")
        end
    end

    --apply radio settings
    if (radioTmp ~= nil and #radioTmp ~= 0) then
        for i,v in ipairs (radioTmp) do
            --merge the default table with flash config to add missing new fields
            local mergedTbl = util.tableAdd (defaultConfig.radio[i], v)
            v = util.addPrefix (mergedTbl, "dot11Radio.")
            local   configMergeRadio24GZDone = "0"
            local   configMergeRadio5GZDone = "0"
            local configMergeCountryCodeDone = "0"
            if(util.fileExists("/flash/configMerge/radioMode5GZChanges") == false) then
                 if (v["dot11Radio.band"] == "a" ) then
                     if (v["dot11Radio.opMode"] == "1") then
                        v["dot11Radio.opMode"] = "2"
                        configMergeRadio5GZDone = "1"
                     end
                 end
             end
             if(util.fileExists("/flash/configMerge/radioMode24GZChanges") == false) then
                 if (v["dot11Radio.band"] == "b" ) then 
                     if (v["dot11Radio.opMode"] == "1") then
                        v["dot11Radio.opMode"] = "5"
				        configMergeRadio24GZDone = "1"
                     end
                 end
			end

            if(util.fileExists("/flash/configMerge/configMergeCountryCodeDone") == false) then
                if (v["dot11Radio.band"] == "b" ) then 
                    v["dot11Radio.radioCountryRev"] = 987
                    configMergeCountryCodeDone = "1"
                end
            end
			if(util.fileExists("/pfrm2.0/HW_JCOW403") == true) then
				if (util.fileExists("/flash/configMerge/countryCodeMergeDone") == false ) then
                    if(v["dot11Radio.band"] == "b")then
                        v["dot11Radio.radioCountryRev"] = 987
                    else
                        v["dot11Radio.radioCountryRev"] = 1
                        local countryCodeMergeDone = io.open("/flash/configMerge/countryCodeMergeDone", "w")                                   
                        if(countryCodeMergeDone ~= nil) then
                            countryCodeMergeDone:close()
                        end
                        -- touch saveDB flag to do a DB export to flash after import is complete
                        local saveDBFile  = io.open("/tmp/callDbSave", "w")
                        if(saveDBFile ~= nil) then
                            saveDBFile:close()
                        end
                    end
            	end
            end

            if (configMergeRadio5GZDone == "1") then
			    local radioMode5GZChanges = io.open("/flash/configMerge/radioMode5GZChanges", "w")                                                          
                if(radioMode5GZChanges ~= nil) then                                                                       
                	radioMode5GZChanges:close()                                                                           
                end
			    -- touch saveDB flag to do a DB export to flash after import is complete
			    local saveDBFile  = io.open("/tmp/callDbSave", "w")                                                          
                if(saveDBFile ~= nil) then                                                                       
            	    saveDBFile:close()                                                                           
           	    end	
		    end

            if (configMergeRadio24GZDone == "1") then
			    local configMergeRadio24GZDone = io.open("/flash/configMerge/radioMode24GZChanges", "w") 
                if(configMergeRadio24GZDone ~= nil) then                                                                       
                	configMergeRadio24GZDone:close()                                                                           
                end
			    -- touch saveDB flag to do a DB export to flash after import is complete
			    local saveDBFile  = io.open("/tmp/callDbSave", "w")                                                          
                if(saveDBFile ~= nil) then                                                                       
            	    saveDBFile:close()                                                                           
           	    end	
		    end

            if (configMergeCountryCodeDone == "1") then
                local configMergeCountryCodeDone = io.open("/flash/configMerge/configMergeCountryCodeDone", "w") 
                if(configMergeCountryCodeDone ~= nil) then                                                                       
                    configMergeCountryCodeDone:close()                                                                           
                end
            end

            status, message = dot11.radio_config (v, "-1", "add");

            util.appendDebugOut ("dot11.radio_config(" .. i .. ") returned " .. status .. "," .. message .. "\n")
        end
    end

    --create profiles
    if (profileTmp ~= nil and #profileTmp ~= 0) then
		local wpaPsk = ""
		local ssidRandomString = ""
		local ssidRandomString2 = ""
		local ssidRandomString5HZ = ""
		if (util.fileExists("/flash/teamf1.cfg.ascii") == false) then
			wpaPsk = util.fileToString ("/tmp/randPasswordWifi")
			ssidRandomString = util.fileToString ("/tmp/ssidRandom")
			ssidRandomString2 = util.fileToString ("/tmp/ssidRandom2")
		end
        for i,v in ipairs (profileTmp) do
            v = util.addPrefix (v, "dot11Profile.")
			if (wpaPsk ~= "") then
				print ("Setting random WPA PSK")
				v["dot11Profile.pskPassAscii"] = wpaPsk
			end
            local   configMergeDone = "0"
			if (ssidRandomString ~= "") then
				-- set ssid as per ssid string from flash + JioFibre concatenated
				if (v["dot11Profile.profileName"] == "Jio_1" ) then v["dot11Profile.ssid"] = ssidRandomString end
				if (v["dot11Profile.profileName"] == "Jio_4" ) then v["dot11Profile.ssid"] = ssidRandomString2 .. "_5G" end
            else
            if(util.fileExists("/flash/configMerge/default5GSsid") == false) then
                 ssidRandomString5HZ = util.fileToString ("/tmp/ssidRandom2")
                 if (v["dot11Profile.profileName"] == "Jio_4" and v["dot11Profile.ssid"] == ssidRandomString5HZ) then 
                     v["dot11Profile.ssid"] = v["dot11Profile.ssid"] .. "_5G" 
				     configMergeDone = "1"
                 end
			end
            end

			if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then	
			--[[ for mesh case we need to do the following:
				1. Make 5GHz SSID  same as 2.4 GHz ssid
				2. prepare and store BH SSID .  set later
				3. Set BH ssid and BH PSK  in Profile_5  
 			]]--

				if (util.fileExists("/flash/configMerge/meshOnOffMergeDone") == false) then
				-- this is first moving from firmware without mesh on/off support to firmare with mesh on/off support.  so  touch mesh enable file to let system start mesh
					os.execute("touch /flash/BRCM_MESH_ENABLED")
			    	local meshOnOffMergeDone = io.open("/flash/configMerge/meshOnOffMergeDone", "w")                                                          
                	if(meshOnOffMergeDone ~= nil) then                                                                       
                		meshOnOffMergeDone:close()                                                                           
                	end

				end
				

				if (v["dot11Profile.profileName"] == "Jio_1" ) then
					if ((v["dot11Profile.security"] == "OPEN") or (v["dot11Profile.authMethods"] == "RADIUS") ) then
						wpaPskFH = util.fileToString ("/tmp/randPasswordWifi")
						v["dot11Profile.security"] = "WPA2"
						v["dot11Profile.authMethods"] = "PSK"
						v["dot11Profile.pairwiseCiphers"] = "CCMP"
						v["dot11Profile.pskPassAscii"] = wpaPskFH
					end
					fh2SSID = v["dot11Profile.ssid"]
					fh2PSK = v["dot11Profile.pskPassAscii"]
					
				end

				if (v["dot11Profile.profileName"] == "Jio_4" ) then
					if ((v["dot11Profile.security"] == "OPEN") or (v["dot11Profile.authMethods"] == "RADIUS") ) then
						wpaPskFH = util.fileToString ("/tmp/randPasswordWifi")
						v["dot11Profile.security"] = "WPA2"
						v["dot11Profile.authMethods"] = "PSK"
						v["dot11Profile.pairwiseCiphers"] = "CCMP"
						v["dot11Profile.pskPassAscii"] = wpaPskFH
					end
					fh5SSID = v["dot11Profile.ssid"]
					fh5PSK = v["dot11Profile.pskPassAscii"]

				end

				ssidRandomStringBH = util.fileToString ("/tmp/ssidRandom")

				if (v["dot11Profile.profileName"] == BH_PROFILE_NAME ) then
					-- if this is first upgrade from old firmware to mesh enabled image . Copy Profile5 to Profile7
					if (util.fileExists("/flash/configMerge/meshMergeDone") == false) then
					
						guest1SSID=v["dot11Profile.ssid"]
						guest1broadcastSSID=v["dot11Profile.broadcastSSID"]
						if (v["dot11Profile.security"] == "OPEN") then
							guest1Security="OPEN"
						else
							guest1pskPassAscii=v["dot11Profile.pskPassAscii"]
						end
					end
					v["dot11Profile.ssid"]=ssidRandomStringBH.."-BH" 
					wpaPskBH = util.fileToString ("/tmp/BHPassword")
					v["dot11Profile.pskPassAscii"] = wpaPskBH
					-- for BH disable broadcast SSID
					v["dot11Profile.broadcastSSID"] = "0"
				end

				if (v["dot11Profile.profileName"] == AP7_PROFILE_NAME) then
					if (util.fileExists("/flash/configMerge/meshMergeDone") == false ) then
						v["dot11Profile.ssid"] = guest1SSID
						v["dot11Profile.broadcastSSID"] = guest1broadcastSSID
						if (guest1Security == "OPEN") then
							v["dot11Profile.security"] = "OPEN"
						else
							v["dot11Profile.pskPassAscii"]=guest1pskPassAscii
						end
					end

			    	local meshMergeDone = io.open("/flash/configMerge/meshMergeDone", "w")                                                          
                	if(meshMergeDone ~= nil) then                                                                       
                		meshMergeDone:close()                                                                           
                	end
				end
				bhSSID = ssidRandomStringBH.."-BH"
				bhPSK = wpaPskBH
				
			end
				
            if (configMergeDone == "1") then
			    local default5GSsid = io.open("/flash/configMerge/default5GSsid", "w")                                                          
                if(default5GSsid ~= nil) then                                                                       
                	default5GSsid:close()                                                                           
                end
			    -- touch saveDB flag to do a DB export to flash after import is complete
			    local saveDBFile  = io.open("/tmp/callDbSave", "w")                                                          
                if(saveDBFile ~= nil) then                                                                       
            	    saveDBFile:close()                                                                           
           	    end	
		    end

            -- Making the security as WPA2 if previous security is WPA or
            -- WPA+WPA2
            if (v["dot11Profile.security"] == "WPA" or v["dot11Profile.security"] == "WPA+WPA2")then
                v["dot11Profile.security"] = "WPA2"
                v["dot11Profile.pairwiseCiphers"] = "CCMP"
            -- Making the security as WPA2 if previous security is WEP
            elseif(v["dot11Profile.security"] == "WEP")then
                v["dot11Profile.security"] = "WPA2"
                v["dot11Profile.authMethods"] = "PSK"
                v["dot11Profile.pairwiseCiphers"] = "CCMP"
                v["dot11Profile.pskPassAscii"] = util.fileToString ("/tmp/randPasswordWifi")
            end
            brcmDefaultdscpWmmMap(v)
            status, message = dot11.profile_config (v, "-1", "add");
            util.appendDebugOut ("dot11.profile_config(" .. i .. ") returned " .. status .. "," .. message .. "\n")
        end
    end

    --configure vaps
    local maxClients = 0
    local maxClients2 = 0
    local resetClientLimit = false
    local resetClientLimit2 = false
    local maxClientsPerRadio = db.getAttribute ("environment", "name", "MAX_CLIENTS_PER_RADIO", "value")

    if (vapTmp ~= nil and #vapTmp ~= 0) then
        for i,v in ipairs (vapTmp) do
			if (v["radioList"] == "1") then
            	maxClients = maxClients + tonumber (v["maxClients"])
			else
				maxClients2 = maxClients2 + tonumber (v["maxClients"])
			end
            if (maxClients > tonumber(maxClientsPerRadio)) then
                resetClientLimit = true
            end
            if((util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED")) and (v["radioList"] == "2") ) then
                maxClientsPerRadio = maxClientsPerRadio + DEFAULT_MAX_CLIENT_BH_AP
            end 
            if (maxClients2 > tonumber(maxClientsPerRadio)) then
                resetClientLimit2 = true
            end

        end
    end

    if (vapTmp ~= nil and #vapTmp ~= 0) then
        for i,v in ipairs (vapTmp) do
            v = util.addPrefix (v, "dot11VAP.")
            if (resetClientLimit) then
                -- reset the max clients value to 8
                if (v["dot11VAP.vapName"] == DEFAULT_2_4_AP_NAME) then
		            v["dot11VAP.maxClients"] = DEFAULT_MAX_CLIENT_PRIMARY_AP
	            else
		            if (v["dot11VAP.radioList"] == "1") then
		                v["dot11VAP.maxClients"] = DEFAULT_MAX_CLIENT_GUEST_AP
		            end
		        end
            end
            if (resetClientLimit2) then
                -- reset the max clients value to 8
                if (v["dot11VAP.vapName"] == DEFAULT_5_AP_NAME) then
		            v["dot11VAP.maxClients"] = DEFAULT_MAX_CLIENT_PRIMARY_AP
		        else
		            if (v["dot11VAP.radioList"] == "2") then
		                v["dot11VAP.maxClients"] = DEFAULT_MAX_CLIENT_GUEST_AP
		            end
		        end
            end

			-- for mesh , always enable BH AP
			if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then
				if (v["dot11VAP.vapName"] == BH_AP_NAME) then
					v["dot11VAP.vapEnabled"] =  "1"
					v["dot11VAP.maxClients"] = "8"
				end
			end
			
            status,message = dot11.VAP_config (v, "-1", "add");
            util.appendDebugOut ("dot11.VAP_config(" .. i .. ") returned " .. status .. "," .. message .. "\n")
        end
    end

	    -- configure ACL
    if (aclTmp ~= nil and #aclTmp ~= 0) then
        for i,v in ipairs (aclTmp) do
            v = util.addPrefix (v, "dot11ACL.")
            status,message = dot11.ACL_config (v, "-1", "add");
            util.appendDebugOut ("dot11.ACL_config(" .. i .. ") returned " .. status .. "," .. message .. "\n")
        end
    end

	--configure switch dscp to queue mapping
    if (dscpMappingTmp ~= nil and #dscpMappingTmp ~= 0) then
        for i,v in ipairs (dscpMappingTmp) do
            v = util.addPrefix (v, "dscpToQueueMapping.")
            status,message = dot11.dscpToQueueMapping_config (v, "-1", "add");
            util.appendDebugOut ("dot11.dscpToQueueMapping_config(" .. i .. ") returned " .. status .. "," .. message .. "\n")
        end
    end

   	--configure switch dscp to queue mapping
    if (dscpToCosMappingTmp ~= nil and #dscpToCosMappingTmp ~= 0) then
        for i,v in ipairs (dscpToCosMappingTmp) do
            v = util.addPrefix (v, "dscpToCosMapping.")

			if (util.fileExists (DSCP_PBIT_ONE_TIME_ENFORCE_FILE) == false) then

				-- one time enforcing RJIL defaults.First set all to 0.
				-- Then set the following
				-- DSCP value 56 - P-BIT 6
				-- DSCP value 34 - P-BIT 4
				-- DSCP value 20 - P-BIT 4
				-- DSCP value 40 - P-BIT 7
				-- DSCP value 46 - P-BIT 6
				-- DSCP value 26 - P-BIT 5
				-- all other values set to zero
				for i=0,qosLimit do
					v["dscpToCosMapping.dscpCosMap"..i] = "0"
				end
				v["dscpToCosMapping.dscpCosMap56"] = dcspTo8021P56
				v["dscpToCosMapping.dscpCosMap34"] = dcspTo8021P34
				v["dscpToCosMapping.dscpCosMap20"] = dcspTo8021P20
				v["dscpToCosMapping.dscpCosMap40"] = dcspTo8021P40
				v["dscpToCosMapping.dscpCosMap46"] = dcspTo8021P46
				v["dscpToCosMapping.dscpCosMap26"] = dcspTo8021P26

				print ("Enforcing one time default RJIL dscp -> 802.1P mappings...")

				if (util.fileExists (DSCP_PBIT_FLASH_FILE) == true) then
					os.remove (DSCP_PBIT_FLASH_FILE)
				end
				dot11.dscpToCosMappingFlashConfigCreate (v)

				local filep = io.open (DSCP_PBIT_ONE_TIME_ENFORCE_FILE, "w")
				if (filep) then
					filep:write("\n")
					filep:close()
				end
				
			end

			if (util.fileExists (DSCP_PBIT_FLASH_FILE) == false) then
				
				print (DSCP_PBIT_FLASH_FILE .. " file is not present") 
				--create the flash dscp p-bit config file from current settings
				dot11.dscpToCosMappingFlashConfigCreate (v)

			else
				-- flash already has lua conf file , import the same into DB
				dofile (DSCP_PBIT_FLASH_FILE)
				for i=0,qosLimit do
					v["dscpToCosMapping.dscpCosMap"..i] = dscp1P["dscpToCosMapping.dscpCosMap" .. i]
				end
	
			end


            status,message = dot11.dscpToCosMapping_config (v, "-1", "add");
            util.appendDebugOut ("dot11.dscpToCosMapping_config(" .. i .. ") returned " .. status .. "," .. message .. "\n")
        end
    end

	--configure switch cos to queue mapping
    if (cosMappingTmp ~= nil and #cosMappingTmp ~= 0) then
        for i,v in ipairs (cosMappingTmp) do
            v = util.addPrefix (v, "cosToQueueMapping.")
            status,message = dot11.cosToQueueMapping_config (v, "-1", "add");
            util.appendDebugOut ("dot11.cosToQueueMapping_config(" .. i .. ") returned " .. status .. "," .. message .. "\n")
        end
    end

	--configure switch cos to queue mapping
    if (interfaceToBridgeTmp ~= nil and #interfaceToBridgeTmp ~= 0) then
        for i,v in ipairs (interfaceToBridgeTmp) do
            v = util.addPrefix (v, "dot11InterfaceToBridge.")
            v["dot11InterfaceToBridge.bridgeInterface"] = dot11.LAN_IFNAME
            status,message = dot11InterfaceToBridge.config (v, "-1", "add");
            util.appendDebugOut ("dot11InterfaceToBridge.config(" .. i .. ") returned " .. status .. "," .. message .. "\n")
        end
    end

    -- configure apGroupName
    if (apGroupNameTmp ~= nil and #apGroupNameTmp ~= 0) then
        for i,v in ipairs (apGroupNameTmp) do
            v = util.addPrefix (v, "apGroupName.")
            status,message = dot11.apGroupName_config (v, "-1", "add");
            util.appendDebugOut ("dot11.apGroupName_config(" .. i .. ") returned " .. status .. "," .. message .. "\n")
        end
    end

    -- configure WPS
    if (wpsTmp ~= nil and #wpsTmp ~= 0) then
        for i,v in ipairs (wpsTmp) do
            if(changeWPSvapName==1)then
                if (v["vapName"] == "wl0.1") then
                    v["vapName"]="wl0" 
                elseif(v["vapName"] == "wl0.2") then
                    v["vapName"]="wl0.1" 
                elseif(v["vapName"] == "wl0.3") then
                    v["vapName"]="wl0.2" 
                elseif(v["vapName"] == "wl1.1") then
                    v["vapName"]="wl1" 
                elseif(v["vapName"] == "wl1.2") then
                    v["vapName"]="wl1.1" 
                elseif(v["vapName"] == "wl1.3") then
                    v["vapName"]="wl1.2"
                end 
            end
            v = util.addPrefix (v, "dot11WPS.")
            dot11WPS.config(v, "-1", "add")            
            if (v["dot11WPS.wpsEnabled"] == "1") then
                --enable in nvram 
                cmdStr = NVRAM_CMD_BINARY .. " set "..v["dot11WPS.vapName"].."_wps_mode='enabled'"
                os.execute(cmdStr)
                -- commit nvram changes
                os.execute ("nvram commit")
            end
            db.execute ("update dot11WPSSessStatus set sessionMsg='', sessionStatus='0'")
        end
    end

    -- stop the services
    -- dot11.ServiceStopStart (false)
    local radioTable = db.getTable("dot11Radio",true)
    local rateBw = "20"
    local query = "_ROWID_='1'"
    local apGroupNameRow = db.getRowWhere("apGroupName", query, false)
    if(radioTable ~= nil)then
        --radio settings apply
        for k,v in pairs(radioTable)do
            local radioIfname
            local cmdStr
            local rate = 0
            local sideband = ""
            local sideBandFlag = 0
            local inputTable = v
            local dot11Radios = db.getRowsWhere ("dot11Radio", "radioNo = " .. inputTable["dot11Radio.radioNo"], false) 
            local dot11Interfaces = db.getRowsWhere ("dot11Interface", "radioNo = " .. inputTable["dot11Radio.radioNo"], false) 
            -- no interface corresponding to the radio
            if (dot11Interfaces == nil or dot11Interfaces[1] == nil) then
                return false
            end
            local radioInterfaceName = dot11Radios[1]["interfaceName"]
            local vapInterfaceName1 = dot11Interfaces[1]["interfaceName"]
            local vapInterfaceName2 = dot11Interfaces[2]["interfaceName"]
            local vapInterfaceName3 = dot11Interfaces[3]["interfaceName"]
            
            -- bring down the radio interface
            dot11.if_up ( radioInterfaceName, 0)
            if(radioInterfaceName == "wl0")then
                wlCmdExecute(radioInterfaceName, "dontbufbcmc", "1")
            end

            -- Set the radio to AP mode
            wlCmdExecute(radioInterfaceName, WL_SUB_CMD_AP_MODE, "1")

            -- Set the txPower of the radio
            local txPower = dot11Radios[1]["txPower"]
            wlCmdExecute(radioInterfaceName, "txpwr1 -d", txPower)

            --set the maxassoc value for radios
            local maxClientsPerRadio = db.getAttribute ("environment", "name", "MAX_CLIENTS_PER_RADIO", "value")
            local maxClientdot11Radio = dot11Radios[1]["maxClientsPerRadio"]
            if(tonumber(maxClientdot11Radio) < tonumber(maxClientsPerRadio))then
                nvramSetCmdExecute(radioInterfaceName, "maxassoc", maxClientdot11Radio)
            else
                nvramSetCmdExecute(radioInterfaceName, "maxassoc", maxClientsPerRadio)
            end

            if (inputTable["dot11Radio.radioCountry"]~= nil) then
                nvramSetCmdExecute(radioInterfaceName, "country_code", inputTable["dot11Radio.radioCountry"])
            end

            if(inputTable["dot11Radio.radioCountryRev"] ~= nil and tonumber(inputTable["dot11Radio.radioCountryRev"]) ~= 0) then
              nvramSetCmdExecute(radioInterfaceName, "country_rev", inputTable["dot11Radio.radioCountryRev"])
	       if(util.fileExists("/pfrm2.0/HW_JCOW401") == true ) then 
            if(inputTable["dot11Radio.band"] == "b")then 
                if(tonumber(inputTable["dot11Radio.radioCountryRev"]) == 987)then
                    nvramSetCmdExecute(radioInterfaceName, "country_rev", 995)
                    os.execute("/bin/wl -i " ..radioInterfaceName.. " down")                                                                       
                    os.execute("/bin/wl -i " ..radioInterfaceName.. " country IN/995")                                                 
                    os.execute("/bin/wl -i " ..radioInterfaceName.. " up")
                elseif(tonumber(inputTable["dot11Radio.radioCountryRev"]) == 991)then
                    nvramSetCmdExecute(radioInterfaceName, "country_rev", 988)
                    os.execute("/bin/wl -i " ..radioInterfaceName.. " down")                                                                       
                    os.execute("/bin/wl -i " ..radioInterfaceName.. " country IN/988")                                                 
                    os.execute("/bin/wl -i " ..radioInterfaceName.. " up")
                end
	      end
	  end
            if(util.fileExists("/pfrm2.0/HW_JCOW403") == true ) then
				if(inputTable["dot11Radio.band"] == "b")then 
                    if(tonumber(inputTable["dot11Radio.radioCountryRev"]) == 987)then
                        nvramSetCmdExecute(radioInterfaceName, "country_rev", 2)
                        os.execute("/bin/wl -i " ..radioInterfaceName.. " down")                                                                       
                        os.execute("/bin/wl -i " ..radioInterfaceName.. " country IN/2")                                                 
                        os.execute("/bin/wl -i " ..radioInterfaceName.. " up")
                    elseif(tonumber(inputTable["dot11Radio.radioCountryRev"]) == 991)then
                        nvramSetCmdExecute(radioInterfaceName, "country_rev", 1)
                        os.execute("/bin/wl -i " ..radioInterfaceName.. " down")                                                                       
                        os.execute("/bin/wl -i " ..radioInterfaceName.. " country IN/1")                                                 
                        os.execute("/bin/wl -i " ..radioInterfaceName.. " up")
                    end
	            end
	        end
            if(util.fileExists("/pfrm2.0/HW_JCOW404") == true ) then 
                if(inputTable["dot11Radio.band"] == "b")then 
                    if(tonumber(inputTable["dot11Radio.radioCountryRev"]) == 987)then
                        nvramSetCmdExecute(radioInterfaceName, "country_rev", 1)
                        os.execute("/bin/wl -i " ..radioInterfaceName.. " down")                                                                       
                        os.execute("/bin/wl -i " ..radioInterfaceName.. " country IN/1")                                                 
                        os.execute("/bin/wl -i " ..radioInterfaceName.. " up")
                    elseif(tonumber(inputTable["dot11Radio.radioCountryRev"]) == 991)then
                        nvramSetCmdExecute(radioInterfaceName, "country_rev", 0)
                        os.execute("/bin/wl -i " ..radioInterfaceName.. " down")                                                                       
                        os.execute("/bin/wl -i " ..radioInterfaceName.. " country IN/0")                                                 
                        os.execute("/bin/wl -i " ..radioInterfaceName.. " up")
                    end
	            end
	        end



                if(util.fileExists("/pfrm2.0/HW_FIBERHOME_JCO300") == true) then
                    if(inputTable["dot11Radio.band"] == "b")then 
                        if(tonumber(inputTable["dot11Radio.radioCountryRev"]) == 987)then
                            nvramSetCmdExecute(radioInterfaceName, "country_rev", 978)
                        elseif(tonumber(inputTable["dot11Radio.radioCountryRev"]) == 991)then
                            nvramSetCmdExecute(radioInterfaceName, "country_rev", 979)
                        end
                    else
                        local f = io.open("/tmp/hwVersion","r")
                        local hwVersion = f:read ("*line")
                        f:close()
                        if (hwVersion and hwVersion == "2.0") then
                            nvramSetCmdExecute(radioInterfaceName, "country_rev", 979)
                        else
                            nvramSetCmdExecute(radioInterfaceName, "country_rev", 991)
                        end
                    end
                end
            end

            if (inputTable["dot11Radio.configuredChannel"]~= nil and inputTable["dot11Radio.configuredChannel"] ~= "0") then
                if ((inputTable["dot11Radio.chanWidth"] == "40" or inputTable["dot11Radio.chanWidth"] == "2040")) then
                    if (inputTable["dot11Radio.band"] == "a" ) then
                        -- selecting lower/uuper according to  channel number
                        if (inputTable["dot11Radio.sideBand"] == "0" or tonumber(inputTable["dot11Radio.configuredChannel"]) < 160 ) then
                            inputTable["dot11Radio.sideBand"] = "l"
                        else
                            inputTable["dot11Radio.sideBand"] = "u"
                        end
                    else
                        if (inputTable["dot11Radio.sideBand"] == "0" or tonumber(inputTable["dot11Radio.configuredChannel"]) < 5) then
                            inputTable["dot11Radio.sideBand"] = "l"
                        else
                            inputTable["dot11Radio.sideBand"] = "u"
                        end
                    end
                    sideband = "40"..inputTable["dot11Radio.sideBand"]
                elseif (inputTable["dot11Radio.chanWidth"] == "80" or inputTable["dot11Radio.chanWidth"] == "4080") then
                    sideband = "80"
                elseif (inputTable["dot11Radio.chanWidth"] == "20")then
                    sideband = "20"
                end
            else
                sideband = ""
            end
            if(inputTable["dot11Radio.configuredChannel"]~= nil and tonumber(inputTable["dot11Radio.configuredChannel"]) ~= tonumber(0))then
                if(inputTable["dot11Radio.band"] == "a")then
                    -- nvram set for channel and sideband
					if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then	
                    	nvramSetCmdWrite(radioInterfaceName, "channel", inputTable["dot11Radio.configuredChannel"])
                    	nvramSetCmdExecute(radioInterfaceName, "channel", inputTable["dot11Radio.configuredChannel"])
					end
                    nvramSetCmdExecute(radioInterfaceName, "chanspec", "5g"..inputTable["dot11Radio.configuredChannel"].."/"..sideband)
                else
                    -- nvram set for channel and sideband
					if(util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then	
                    	nvramSetCmdWrite(radioInterfaceName, "channel", inputTable["dot11Radio.configuredChannel"])
                    	nvramSetCmdExecute(radioInterfaceName, "channel", inputTable["dot11Radio.configuredChannel"])
					end
                    nvramSetCmdExecute(radioInterfaceName, "chanspec", "2g"..inputTable["dot11Radio.configuredChannel"].."/"..sideband)
                end
            else
                -- nvram set for channel and sideband
                nvramSetCmdExecute(radioInterfaceName, "chanspec", "0")
            end

            local nvramBw = NVRAM_CHANNEL_BW_80
            if (inputTable["dot11Radio.chanWidth"] == "80" or inputTable["dot11Radio.chanWidth"] == "4080") then
                nvramBw = NVRAM_CHANNEL_BW_80
                rateBw = "80"
            elseif (inputTable["dot11Radio.chanWidth"] == "40" or inputTable["dot11Radio.chanWidth"] == "2040") then
                nvramBw = NVRAM_CHANNEL_BW_40
                rateBw = "40"
            else
                nvramBw = NVRAM_CHANNEL_BW_20
            end
            nvramSetCmdExecute(radioInterfaceName, "bw_cap", nvramBw)
            -- turn off/on the coexistance
            if (inputTable["dot11Radio.chanWidth"] == "80" or inputTable["dot11Radio.chanWidth"] == "40") then
                -- turn of the coexistance
                nvramSetCmdExecute(radioInterfaceName, "obss_coex", "0")
            else
                -- turn on the coexistance
                nvramSetCmdExecute(radioInterfaceName, "obss_coex", "1")
            end
            -- client capability start
            if (inputTable["dot11Radio.opMode"] == '4' or (inputTable["dot11Radio.band"] == "a" and inputTable["dot11Radio.opMode"] == '6')) then --n only and n/ac mode
                nvramSetCmdExecute(radioInterfaceName, "bss_opmode_cap_reqd", "2")
            elseif(inputTable["dot11Radio.band"] == "a" and inputTable["dot11Radio.opMode"] == '3')then --ac only
                nvramSetCmdExecute(radioInterfaceName, "bss_opmode_cap_reqd", "3")
            elseif(inputTable["dot11Radio.band"] == "b" and (inputTable["dot11Radio.opMode"] == '1' or inputTable["dot11Radio.opMode"] == '2' or inputTable["dot11Radio.opMode"] == '3' or inputTable["dot11Radio.opMode"] == '5'))then --rest of 2.4GHz modes
                nvramSetCmdExecute(radioInterfaceName, "bss_opmode_cap_reqd", "0")
            elseif(inputTable["dot11Radio.band"] == "a" and (inputTable["dot11Radio.opMode"] == '1' or inputTable["dot11Radio.opMode"] == '2' or inputTable["dot11Radio.opMode"] == '5')) then --a/n/ac , a/n and a modes
                nvramSetCmdExecute(radioInterfaceName, "bss_opmode_cap_reqd", "0")
            end  -- client capability end 
            local nmode = false
            if ((inputTable["dot11Radio.band"] == "a" and tonumber(inputTable["dot11Radio.opMode"]) ~= tonumber(1)) or (inputTable["dot11Radio.band"] == "b" and(tonumber(inputTable["dot11Radio.opMode"]) == tonumber(3) or tonumber(inputTable["dot11Radio.opMode"]) == tonumber(4) or tonumber(inputTable["dot11Radio.opMode"]) == tonumber(5)))) then
                nmode = true
            end
        if (nmode) then
            --enabling or disabling wme
            if(tonumber(inputTable["dot11Radio.txRate"]) < tonumber(127)) then
                nvramSetCmdExecute(radioInterfaceName, "nmode", "-1")-- auto
                if(tonumber(inputTable["dot11Radio.txRate"]) == tonumber(0))then
                    nvramSetCmdExecute(radioInterfaceName, "nmcsidx", "-1")
                end
            else
                nvramSetCmdExecute(radioInterfaceName, "nmode", "1") -- n mode on
            end
            nvramSetCmdExecute(radioInterfaceName, "nmode_protection", "auto") -- n mode off            
        else
            nvramSetCmdExecute(radioInterfaceName, "nmode", "0")-- n mode off 
            nvramSetCmdExecute(radioInterfaceName, "nmode_protection", "off")-- n mode off            
       end
       nvramSetCmdExecute(radioInterfaceName, "wme", "on")
            --rts threshold
            nvramSetCmdExecute(radioInterfaceName, "rts", inputTable["dot11Radio.rtsThreshold"])
            --beacon interval
            nvramSetCmdExecute(radioInterfaceName, "bcn", inputTable["dot11Radio.beaconInterval"])
            --dtim interval
            nvramSetCmdExecute(radioInterfaceName, "dtim", inputTable["dot11Radio.dtimInterval"])

            --802.11g protection mode
            if(tonumber(inputTable["dot11Radio.rtsCtsProtect"]) == 1)then
                wlCmdExecute(radioInterfaceName, "gmode_protection_override", "-1")
                nvramSetCmdExecute(radioInterfaceName, "gmode_protection", "auto")
                wlCmdExecute(vapInterfaceName1, "gmode_protection_override", "-1")
                nvramSetCmdExecute(vapInterfaceName1, "gmode_protection", "auto")
                wlCmdExecute(vapInterfaceName2, "gmode_protection_override", "-1")
                nvramSetCmdExecute(vapInterfaceName2, "gmode_protection", "auto")
                wlCmdExecute(vapInterfaceName3, "gmode_protection_override", "-1")
                nvramSetCmdExecute(vapInterfaceName3, "gmode_protection", "auto")
            else
                wlCmdExecute(radioInterfaceName, "gmode_protection_override", "0")
                nvramSetCmdExecute(radioInterfaceName, "gmode_protection", "off")
                wlCmdExecute(vapInterfaceName1, "gmode_protection_override", "0")
                nvramSetCmdExecute(vapInterfaceName1, "gmode_protection", "off")
                wlCmdExecute(vapInterfaceName2, "gmode_protection_override", "0")
                nvramSetCmdExecute(vapInterfaceName2, "gmode_protection", "off")
                wlCmdExecute(vapInterfaceName3, "gmode_protection_override", "0")
                nvramSetCmdExecute(vapInterfaceName3, "gmode_protection", "off")
            end

            --preamble mode
            if(inputTable["dot11Radio.preambleMode"] == "Short")then
                nvramSetCmdExecute(radioInterfaceName, "plcphdr", "auto")
                nvramSetCmdExecute(vapInterfaceName1, "plcphdr", "auto")
                nvramSetCmdExecute(vapInterfaceName2, "plcphdr", "auto")
                nvramSetCmdExecute(vapInterfaceName3, "plcphdr", "auto")
            elseif(inputTable["dot11Radio.preambleMode"] == "Long")then
                nvramSetCmdExecute(radioInterfaceName, "plcphdr", "debug")
                nvramSetCmdExecute(vapInterfaceName1, "plcphdr", "debug")
                nvramSetCmdExecute(vapInterfaceName2, "plcphdr", "debug")
                nvramSetCmdExecute(vapInterfaceName3, "plcphdr", "debug")
            else
                nvramSetCmdExecute(radioInterfaceName, "plcphdr", "long")
                nvramSetCmdExecute(vapInterfaceName1, "plcphdr", "long")
                nvramSetCmdExecute(vapInterfaceName2, "plcphdr", "long")
                nvramSetCmdExecute(vapInterfaceName3, "plcphdr", "long")
            end
            --apply the VAP setting from here now
            for kk,vv in pairs(dot11Interfaces)do
                local dot11VAP = db.getRowWhere("dot11VAP", "vapName ='" ..vv["vapName"].."'" , false)
                local dot11ACL = db.getRowsWhere("dot11ACL", "vapName ='" ..vv["vapName"].."'" , false)
                local profileRow = db.getRow ("dot11Profile", "profileName", dot11VAP["profileName"])
                local vapInterfaceName = vv["interfaceName"]
                --bring down interface
                dot11.if_up ( vapInterfaceName, 0)
                os.execute ("/sbin/ifconfig "..vapInterfaceName.." up")
                -- max clients
                nvramSetCmdExecute(vapInterfaceName, "bss_maxassoc", dot11VAP["maxClients"])
                --ap isolation
                nvramSetCmdExecute(vapInterfaceName, "ap_isolate", dot11VAP["apIsolation"])
                --bss enabled
                if((util.fileExists("/flash/BRCM_MESH_ENABLED")) and (vapInterfaceName == "wl0" or vapInterfaceName == "wl1"))then
                    nvramSetCmdExecute(vapInterfaceName, "bss_enabled", "1")
                else
                    nvramSetCmdExecute(vapInterfaceName, "bss_enabled", dot11VAP["vapEnabled"])
                end
                --acl policy set
                nvramSetCmdExecute(vapInterfaceName, "macmode", "disabled")
                
                if(dot11VAP["defACLPolicy"] == "Allow")then
                    nvramSetCmdExecute(vapInterfaceName, "macmode", "allow")                    
                elseif(dot11VAP["defACLPolicy"] == "Deny")then
                    nvramSetCmdExecute(vapInterfaceName, "macmode", "deny")                    
                end
                --acl mac configuration
                if(dot11ACL ~= nil)then
                    local maclist = ""
                    for a,b in pairs(dot11ACL)do
                        maclist = maclist .." ".. b["macAddress"]
                    end
                    nvramSetCmdExecute(vapInterfaceName, "maclist", maclist)                    
                else
                    nvramSetCmdExecute(vapInterfaceName, "maclist", "")                    
                end

                if(apGroupNameRow ~= nil and apGroupNameRow["apGroupName"] ~= nil)then
                    nvramSetCmdExecute(vapInterfaceName, "apgroup_name", apGroupNameRow["apGroupName"])
                end

                --profile settings
                if (profileRow ~= nil) then
                    -- set SSID on the interface
                    wlCmdExecute(vapInterfaceName, WL_SUB_CMD_SSID, profileRow["dot11Profile.ssid"])
                    --set ssid
                    nvramSetCmdExecute(vapInterfaceName, "ssid", profileRow["dot11Profile.ssid"])
                    -- disable the wep
                    nvramSetCmdExecute(vapInterfaceName, "wep", "disabled")
                    for i =1, 4 do
                        cmdStr = NVRAM_CMD_BINARY .. " unset '"..vapInterfaceName.."_key"..i.."'"
                        os.execute(cmdStr)
                    end
                    --broadcast ssid settings
                    if (profileRow["dot11Profile.broadcastSSID"] == "1") then
                        nvramSetCmdExecute(vapInterfaceName, "closed", "0")
                    else
                        nvramSetCmdExecute(vapInterfaceName, "closed", "1")
                    end

                    --[[enabling or disabling wme
                    if(profileRow["dot11Profile.qosEnable"] == "1" or (inputTable["dot11Radio.band"] == "a" and (tonumber(inputTable["dot11Radio.opMode"]) ~= tonumber(1))) or (inputTable["dot11Radio.band"] == "b" and (tonumber(inputTable["dot11Radio.opMode"]) == tonumber(3) or tonumber(inputTable["dot11Radio.opMode"]) == tonumber(4) or tonumber(inputTable["dot11Radio.opMode"]) == tonumber(5)))) then
                        profileRow["dot11Profile.qosEnable"] = "on"
                    else
                        profileRow["dot11Profile.qosEnable"] = "off"
                    end
                    cmdStr = NVRAM_CMD_BINARY .. " set "..vapInterface.."_wme='"..profileRow["dot11Profile.qosEnable"].."'"]]--
                    nvramSetCmdExecute(vapInterfaceName, "wme", "on")

                    if (profileRow["dot11Profile.authMethods"] == "PSK") then
                        if (profileRow["dot11Profile.security"] == "WPA+WPA2") then
                            nvramSetCmdExecute(vapInterfaceName, "akm", "psk psk2")
                        end			
                        if (profileRow["dot11Profile.security"] == "WPA") then
                            nvramSetCmdExecute(vapInterfaceName, "akm", "psk")
                        end			
                        if (profileRow["dot11Profile.security"] == "WPA2") then
                            nvramSetCmdExecute(vapInterfaceName, "akm", "psk2")
                        end
                    else
                        if (profileRow["dot11Profile.security"] == "WPA+WPA2") then
                            nvramSetCmdExecute(vapInterfaceName, "akm", "wpa wpa2")
                        end			
                        if (profileRow["dot11Profile.security"] == "WPA") then
                            nvramSetCmdExecute(vapInterfaceName, "akm", "wpa")
                        end			
                        if (profileRow["dot11Profile.security"] == "WPA2") then
                            nvramSetCmdExecute(vapInterfaceName, "akm", "wpa2")
                        end
                    end	

                    if ( profileRow["dot11Profile.pskPassAscii"]) then
                        nvramSetCmdExecute(vapInterfaceName, "wpa_psk", profileRow["dot11Profile.pskPassAscii"])
                    end
                    if ( profileRow["dot11Profile.pairwiseCiphers"]) then
                        if (profileRow["dot11Profile.pairwiseCiphers"] == "TKIP+CCMP") then
                            nvramSetCmdExecute(vapInterfaceName, "crypto", "tkip+aes")
                        elseif (profileRow["dot11Profile.pairwiseCiphers"] == "TKIP") then
                            nvramSetCmdExecute(vapInterfaceName, "crypto", "tkip")
                        elseif (profileRow["dot11Profile.pairwiseCiphers"] == "CCMP") then
                            --return "ERROR", "CCMP is not allowed"
                            nvramSetCmdExecute(vapInterfaceName, "crypto", "aes")
                        end
                    end
                    if (profileRow["dot11Profile.security"] == "WEP") then
                        nvramSetCmdExecute(vapInterfaceName, "akm", "*DEL*")
                        -- set WEP in driver
                        local keyIndex = tonumber(profileRow["dot11Profile.defWepkeyIdx"]) + 1
                        nvramSetCmdExecute(vapInterfaceName, "wep", "enabled")
                        nvramSetCmdExecute(vapInterfaceName, "key", keyIndex)
                        nvramSetCmdExecute(vapInterfaceName, "key"..keyIndex, profileRow["dot11Profile.wepkey"..profileRow["dot11Profile.defWepkeyIdx"]])
                        if (profileRow["dot11Profile.wepAuth"]== "Shared") then
                            nvramSetCmdExecute(vapInterfaceName, "auth", "1")
                        else
                            nvramSetCmdExecute(vapInterfaceName, "auth", "0")
                        end
                    else
                        nvramSetCmdExecute(vapInterfaceName, "auth", "0")
                    end			
                    if (profileRow["dot11Profile.security"] == "OPEN") then
                        nvramSetCmdExecute(vapInterfaceName, "akm", "*DEL*")
                    end			
                end -- profileRow nil check
                --bring up the enabled interface
                if(tonumber(dot11VAP["vapEnabled"]) == tonumber(1)) then
                    -- set SSID on the interface
                    wlCmdExecute(vapInterfaceName, WL_SUB_CMD_SSID, profileRow["dot11Profile.ssid"])
                  
                    dot11.if_up ( vapInterfaceName, 1)
                end
            end --vap setting apply loop ends
            os.execute ("nvram commit")
            dot11.if_up ( radioInterfaceName, 1)
            cmdStr = WLCONF_CMD_BINARY .." "..radioInterfaceName.. " up"
            os.execute (cmdStr)
        end --radio settings apply loop ends
    end--radio table nil check
    -- change the wps state to configured mode
    db.setAttribute("dot11WPSState", "_ROWID_", 1, "wpsState", "1")

    dot11.nvramIfnamesSetBoot () --sets the wireless interface names in the nvram
    dot11.ServiceStopStartBoot (false)
    dot11.ServiceStopStartBoot (true)
    if(radioTable ~= nil)then
        --radio settings apply
        for k,v in pairs(radioTable)do
            local inputTable = v
            local dot11Radios = db.getRowsWhere ("dot11Radio", "radioNo = " .. inputTable["dot11Radio.radioNo"], false) 
            local dot11Interfaces = db.getRowsWhere ("dot11Interface", "radioNo = " .. inputTable["dot11Radio.radioNo"], false) 
            -- no interface corresponding to the radio
            if (dot11Interfaces == nil or dot11Interfaces[1] == nil) then
                return false
            end
            local radioInterfaceName = dot11Radios[1]["interfaceName"]
            local vapInterfaceName1 = dot11Interfaces[1]["interfaceName"]
            local vapInterfaceName2 = dot11Interfaces[2]["interfaceName"]
            local vapInterfaceName3 = dot11Interfaces[3]["interfaceName"]

            if (inputTable["dot11Radio.txRate"] ~= "0") then -- custom rate
                local txRate = dot11.ConvertRate (inputTable["dot11Radio.txRate"]) 
                if (tonumber(inputTable["dot11Radio.txRate"]) < tonumber(127)) then
                    -- set mcs index to -2
                    nvramSetCmdExecute(radioInterfaceName, "nmcsidx", "-2")
                    -- set the rate
                    if(inputTable["dot11Radio.band"] == "a")then
                        wlCmdExecute(radioInterfaceName, "5g_rate -r", dot11.ConvertRate(inputTable["dot11Radio.txRate"]))
                    else
                        wlCmdExecute(radioInterfaceName, "2g_rate -r", dot11.ConvertRate(inputTable["dot11Radio.txRate"]))
                    end
                else
                    if (tonumber(inputTable["dot11Radio.txRate"]) > tonumber(151)) then
                        if(inputTable["dot11Radio.band"] == "a")then
                            wlCmdExecute(radioInterfaceName, "5g_rate -v", dot11.ConvertRate(inputTable["dot11Radio.txRate"]).. " -b "..rateBw.." -s 3")
                        end
                    else
                        nvramSetCmdExecute(radioInterfaceName, "nmcsidx", txRate)
                        if(inputTable["dot11Radio.band"] == "a")then
                            wlCmdExecute(radioInterfaceName, "5g_rate -h", dot11.ConvertRate(inputTable["dot11Radio.txRate"]).. " -b "..rateBw)
                        else
                            wlCmdExecute(radioInterfaceName, "2g_rate -h", dot11.ConvertRate(inputTable["dot11Radio.txRate"]).. " -b "..rateBw)
                        end
                    end
                end
                os.execute ("nvram commit")
            end-- rate end

            -- calling wep setting again.
            dot11.setWepBoot (radioInterfaceName)
            if(inputTable["dot11Radio.preambleMode"] == "Short")then
                wlCmdExecute(radioInterfaceName, "plcphdr", "auto")
                wlCmdExecute(vapInterfaceName1, "plcphdr", "auto")
                wlCmdExecute(vapInterfaceName2, "plcphdr", "auto")
                wlCmdExecute(vapInterfaceName3, "plcphdr", "auto")
            elseif(inputTable["dot11Radio.preambleMode"] == "Long")then
                wlCmdExecute(radioInterfaceName, "plcphdr", "debug")
                wlCmdExecute(vapInterfaceName1, "plcphdr", "debug")
                wlCmdExecute(vapInterfaceName2, "plcphdr", "debug")
                wlCmdExecute(vapInterfaceName3, "plcphdr", "debug")
            else
                wlCmdExecute(radioInterfaceName, "plcphdr", "long")
                wlCmdExecute(vapInterfaceName1, "plcphdr", "long")
                wlCmdExecute(vapInterfaceName2, "plcphdr", "long")
                wlCmdExecute(vapInterfaceName3, "plcphdr", "long")
            end
            cmdStr = WLCONF_CMD_BINARY .." "..radioInterfaceName.. " start"
            os.execute (cmdStr)
        end --radio settings apply loop ends
    end--radio table nil check

	if (util.fileExists("/pfrm2.0/BRCM_SDK_5_02_L05P1")) then
    os.execute ("/bin/wlevt2 > /dev/null")
	else
    os.execute ("/bin/wlevt > /dev/null")
	end

	if(util.fileExists("/flash/BRCM_MESH_ENABLED") == true) then	
	
    	os.execute ("echo Start MESH > /dev/console")
		dot11meshInit ()
		dot11SetFHSSIDOnly (fh2SSID , "b")
		dot11SetFHSSIDOnly (fh5SSID , "a")
		dot11SetFHPSKOnly (	fh2PSK , "b")
		dot11SetFHPSKOnly (fh5PSK , "a")
		dot11SetBHSSID (bhSSID, bhPSK)
		dot11meshReStart ()
	end

   -- As Per RJIL Request Setting lrl and srl to 15
    wlCmdExecute("wl1","lrl",15)
    wlCmdExecute("wl1","srl",15)
end


function dot11.export ()
    local status
    local dot11Config =  {};
    local globalConfig = db.getTable("dot11GlobalConfig", false) 
    dot11Config["global"] = globalConfig[1]
    dot11Config["version"] = currentVersion
    dot11Config["card"] = db.getTable ("dot11Card", false)
    dot11Config["radio"] = db.getTable("dot11Radio", false) 
    dot11Config["vap"] = db.getTable("dot11VAP", false) 
    dot11Config["profile"] = db.getTable ("dot11Profile", false)
    dot11Config["authorizedAP"] = db.getTable ("dot11AuthorizedAP", false)
    dot11Config["acl"] = db.getTable ("dot11ACL", false) 
    dot11Config["wps"] = db.getTable ("dot11WPS", false)
    dot11Config["dot11Schedule"] = db.getTable ("dot11Schedule", false)
    dot11Config["interface"] = db.getTable ("dot11Interface", false)
    dot11Config["dscpToQueueMapping"] = db.getTable ("dscpToQueueMapping", false)
    dot11Config["dscpToCosMapping"] = db.getTable ("dscpToCosMapping", false)
    dot11Config["cosToQueueMapping"] = db.getTable ("cosToQueueMapping", false)
    dot11Config["dot11InterfaceToBridge"] = db.getTable ("dot11InterfaceToBridge", false)
    dot11Config["apGroupName"] = db.getTable("apGroupName", false)
    		
    for i, v in ipairs (dot11Config["profile"]) do
        if (v["pskPassAscii"] ~= nil and v["pskPassAscii"] ~= "") then
            status, dot11Config["profile"][i].pskPassAscii = passwdSecureLib.encryptData (v["pskPassAscii"], "")
        end
    end
    return dot11Config
end

if (config.register) then
   config.register("dot11", dot11.import, dot11.export, "2")
end

--[[
*******************************************************************************
-- @name dot11VAP.confGet
--
-- @description This function returns the configuration of the given
-- dot11 interface.
--
-- @param vapIfName interface name of the VAP
--
-- @return conf or nil
--]]

function dot11VAP.confGet(vapIfName)
    local query = ""
    local record = {}

    query = "interfaceName='" .. vapIfName .. "'"
    record  = db.getRowWhere("dot11Interface", query, false) 
    if (record == nil) then
        return nil
    end        

    return record
end

------------------------------------------------------------------------------
-- @name dot11.ProfileGet ()
--
-- @description This function will get the information about one profile based on rowID
-- in system.
--
-- @return 
--
function dot11.ProfileGet(rowid)
	local profileRow = {}
	profileRow = db.getRow ("dot11Profile","_ROWID_", rowid)
	local v = {}
	v["profileName"] = profileRow["dot11Profile.profileName"]
	v["ssid"] = profileRow["dot11Profile.ssid"]
	v["broadcastSSID"] = profileRow["dot11Profile.broadcastSSID"]
	v["security"] = profileRow["dot11Profile.security"]
    v["pairwiseCiphers"] = profileRow["dot11Profile.pairwiseCiphers"]
	v["authMethods"] = profileRow["dot11Profile.authMethods"]
	if (profileRow["dot11Profile.pskPassAscii"] ~= nil) then
		v["pskPassAscii"] = util.mask (profileRow["dot11Profile.pskPassAscii"])
	end
	v["wepAuth"] = profileRow["dot11Profile.wepAuth"]
	v["groupCipher"] = profileRow["dot11Profile.groupCipher"]
	v["pskPassHex"] = profileRow["dot11Profile.pskPassHex"]
	v["wepkeyPassphrase"] = profileRow["dot11Profile.wepkeyPassphrase"]
	v["defWepkeyIdx"] = profileRow["dot11Profile.defWepkeyIdx"]
	v["wepkey0"] = profileRow["dot11Profile.wepkey0"]
	v["wepkey1"] = profileRow["dot11Profile.wepkey1"]
	v["wepkey2"] = profileRow["dot11Profile.wepkey2"]
	v["wepkey3"] = profileRow["dot11Profile.wepkey3"]
	v["editProfileNameStatus"] = "DISABLED"
	
    if (v == nil) then
        return nil, "DB_ERROR_TRY_AGAIN"
    end

    --return
    return v
	
	
	
end
------------------------------------------------------------------------------
-- @name dot11.accessPointGet ()
--
-- @description This function will get the information about dot11Profiles
-- in system.
--
-- @return 
--
function dot11.ProfilesGet()
    local apInfoTbl = {}
    apInfoTbl = db.getTable ("dot11Profile",false)
	for i,v in pairs(apInfoTbl) do
        if(v["broadcastSSID"] == "1") then
            v["broadcastSSID"] = "Enabled"
        else
            v["broadcastSSID"] = "Disabled"
        end
        if(v["pairwiseCiphers"] == "TKIP+CCMP") then
            v["pairwiseCiphers"] = "TKIP+CCMP"
        elseif(v["pairwiseCiphers"] == "CCMP") then
            v["pairwiseCiphers"] = "CCMP"
        elseif(v["pairwiseCiphers"] == "TKIP") then
            v["pairwiseCiphers"] = "TKIP"
            -- for WEP, encryption value is stored in groupCipher
        elseif(v["security"] == "WEP") then
            v["pairwiseCiphers"] =  v["groupCipher"] .. "-bit"
        elseif(v["pairwiseCiphers"] == "") then
            v["pairwiseCiphers"] = "None"
        end
         -- for WEP, authentication value is stored in wepAuth
        if(v["security"] == "WEP") then
            v["authMethods"] = v["wepAuth"]
        elseif(v["authMethods"] == "") then
            v["authMethods"] = "None"
        end
        if(v["pskPassAscii"] ~= nil ) then
            v["pskPassAscii"] = util.mask (v["pskPassAscii"])
        end
		
		if (util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then	
			-- do not display BH row in UI 
			if (v["profileName"] == BH_PROFILE_NAME ) then
				BHRowToRemove=i
			end
		end

	end

	if (util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then	
		table.remove (apInfoTbl , BHRowToRemove)
	end

    if (apInfoTbl == nil) then
        return nil, "DB_ERROR_TRY_AGAIN"
    end

    --return
    return apInfoTbl
	
end


------------------------------------------------------------------------------
-- @name dot11.accessPointGet ()
--
-- @description This function will get the information about dot11Profiles
-- in system.
--
-- @return 
--
function dot11.accessPointGet()


    --locals
    local apInfoTbl = {}
    apInfoTbl = db.getTable ("dot11Profile",false)

    local vapInfoTbl = db.getTable ("dot11VAP",false)
    local accessPoint= {}
    local count = 1
    local macAddress = {}

    for i,v in pairs(vapInfoTbl) do
        local dot11InterfaceRow = db.getRow ("dot11Interface", "vapName", v["vapName"])
        accessPoint[count] = {}
        accessPoint[count]["_ROWID_"] = v["_ROWID_"]
		if (dot11InterfaceRow["dot11Interface.radioNo"] == "1") then
			accessPoint[count]["band"] = "2.4 GHz"
		else
			accessPoint[count]["band"] = "5 GHz"
		end

        for ii,vv in pairs (apInfoTbl) do
            if (v["profileName"] == vv["profileName"]) then
                if (tonumber(v["vapEnabled"]) == 1) then
                    accessPoint[count]["vapEnabled"] = "Enabled"
                else
                    accessPoint[count]["vapEnabled"] = "Disabled"
                end
				if (vv["broadcastSSID"] == "1") then
					accessPoint[count]["broadcastSSID"] = "Enabled"
				else
					accessPoint[count]["broadcastSSID"] = "Disabled"
				end
				accessPoint[count]["ssid"] = vv["ssid"]
				accessPoint[count]["security"] = vv["security"]
        		if(vv["pairwiseCiphers"] == "TKIP+CCMP") then
            		accessPoint[count]["pairwiseCiphers"] = "TKIP+CCMP"
        		elseif(vv["pairwiseCiphers"] == "CCMP") then
            		accessPoint[count]["pairwiseCiphers"] = "CCMP"
        		elseif(vv["pairwiseCiphers"] == "TKIP") then
            		accessPoint[count]["pairwiseCiphers"] = "TKIP"
            	-- for WEP, encryption value is stored in groupCipher
        		elseif(vv["security"] == "WEP") then
            		accessPoint[count]["pairwiseCiphers"] =  vv["groupCipher"] .. "-bit"
        		elseif(vv["pairwiseCiphers"] == "") then
            		accessPoint[count]["pairwiseCiphers"] = "None"
        		end
         		-- for WEP, authentication value is stored in wepAuth
       			 if(vv["security"] == "WEP") then
            		accessPoint[count]["authMethods"] = vv["wepAuth"]
        		elseif(vv["authMethods"] == "") then
            		accessPoint[count]["authMethods"] = "None"
				else
					accessPoint[count]["authMethods"] = vv["authMethods"]
        		end
                accessPoint[count]["profileName"] = v["profileName"]
                accessPoint[count]["vapName"] = v["vapName"]
				
            end
        end
		if (util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then	
			-- do not display BH row in UI 
			if (v["vapName"] == BH_AP_NAME ) then
				BHRowToRemove=i
			end
		end
      count = count+1
    end

    if (accessPoint == nil) then
        return nil, "DB_ERROR_TRY_AGAIN"
    end

	if (util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED") == true) then
		table.remove (accessPoint , BHRowToRemove )
	end

    --return
    return accessPoint
end

function dot11.guestAccessPointGet()

    --locals
    local apInfoTbl = {}
    apInfoTbl = db.getTable ("dot11Profile",false)

    local vapInfoTbl = db.getTable ("dot11VAP",false)
    local accessPoint= {}
    local count = 1
    local macAddress = {}

    for i,v in pairs(vapInfoTbl) do

      local dot11InterfaceRow = db.getRow ("dot11Interface", "vapName", v["vapName"])

      if (dot11InterfaceRow["dot11Interface.LogicalIfName"] == 'IF4') then
        accessPoint[count] = {}
        accessPoint[count]["_ROWID_"] = v["_ROWID_"]
		if (dot11InterfaceRow["dot11Interface.radioNo"] == "1") then
			accessPoint[count]["band"] = "2.4 GHz"
		else
			accessPoint[count]["band"] = "5 GHz"
		end

        for ii,vv in pairs (apInfoTbl) do
            if (v["profileName"] == vv["profileName"]) then
                if (tonumber(v["vapEnabled"]) == 1) then
                    accessPoint[count]["vapEnabled"] = "Enabled"
                else
                    accessPoint[count]["vapEnabled"] = "Disabled"
                end
				if (vv["broadcastSSID"] == "1") then
					accessPoint[count]["broadcastSSID"] = "Enabled"
				else
					accessPoint[count]["broadcastSSID"] = "Disabled"
				end
				accessPoint[count]["ssid"] = vv["ssid"]
				accessPoint[count]["security"] = vv["security"]
        		if(vv["pairwiseCiphers"] == "TKIP+CCMP") then
            		accessPoint[count]["pairwiseCiphers"] = "TKIP+CCMP"
        		elseif(vv["pairwiseCiphers"] == "CCMP") then
            		accessPoint[count]["pairwiseCiphers"] = "CCMP"
        		elseif(vv["pairwiseCiphers"] == "TKIP") then
            		accessPoint[count]["pairwiseCiphers"] = "TKIP"
            	-- for WEP, encryption value is stored in groupCipher
        		elseif(vv["security"] == "WEP") then
            		accessPoint[count]["pairwiseCiphers"] =  vv["groupCipher"] .. "-bit"
        		elseif(vv["pairwiseCiphers"] == "") then
            		accessPoint[count]["pairwiseCiphers"] = "None"
        		end
         		-- for WEP, authentication value is stored in wepAuth
       			 if(vv["security"] == "WEP") then
            		accessPoint[count]["authMethods"] = vv["wepAuth"]
        		elseif(vv["authMethods"] == "") then
            		accessPoint[count]["authMethods"] = "None"
				else
					accessPoint[count]["authMethods"] = vv["authMethods"]
        		end
                accessPoint[count]["profileName"] = v["profileName"]
                accessPoint[count]["vapName"] = v["vapName"]
				
            end
        end
      count = count+1
      end
    end

    if (accessPoint == nil) then
        return nil, "DB_ERROR_TRY_AGAIN"
    end

    --return
    return accessPoint
end


--------------------------------------------------------------------------------
-- @name dot11.accessPointEditGet ()
--
-- @description This function will get the information about dot11Profiles
-- in system which is going to be edited.
--
-- @return 
function dot11.accessPointEditGet (rowid)
    
    
    --locals
    local query = nil
    local vapInfoTbl = {}
    local wpsEnabled,interfaceName
    local apInfoTbl = {}
    local radioTable = {}
    query = "_ROWID_=" .. rowid
    local query2 = "_ROWID_=1"
    apInfoTbl = db.getRowWhere ("dot11Profile", query, false)
    vapInfoTbl = db.getRowWhere ("dot11VAP","profileName = '" .. apInfoTbl["profileName"] .. "'",false)
    interfaceName = db.getAttribute ("dot11Interface" ,"vapName",vapInfoTbl["vapName"],"interfaceName")
    wpsEnabled = db.getAttribute ("dot11WPS","vapName", interfaceName,"wpsEnabled")
    radioTable= db.getRowWhere ("dot11Radio",query2,false)
    apInfoTbl["vapEnabled"] = vapInfoTbl["vapEnabled"]
    apInfoTbl["wpsEnabled"] = wpsEnabled
    if(apInfoTbl["pskPassAscii"] ~= nil) then
		apInfoTbl["pskPassAscii"] = util.mask (apInfoTbl["pskPassAscii"])
    end
    if (string.find(radioTable["opMode"], "g and b")) then 
        apInfoTbl["opMode"] = "212992"
    end
    if (string.find(radioTable["opMode"], "g only")) then 
        apInfoTbl ["opMode"] = "196608"
    end
    if (string.find(radioTable["opMode"], "ng")) then
        apInfoTbl["opMode"] = "475136"
    end
    if(radioTable["puren"] == "1") then
        apInfoTbl["opMode"] = "131072"
    end
    if (apInfoTbl == nil) then
		return "ERROR", "DB_ERROR_TRY_AGAIN"
    end
    --return
    return apInfoTbl

end

-------------------------------------------------------------------------------
--@name  dot11.getDefWifiCfg ()
--
--@description The function will get the wireless info from the dot11 table
--
--@return

function dot11.getDefWifiCfg ()

	--locals
	local wirelessTbl = {}
    local query1  = "_ROWID_=1" -- getting the first row
    local vapTbl = {}
    local profileTbl = {}

    -- querying the 1st Row of dot11VAP
    vapTbl = db.getRowWhere("dot11VAP", query1, false)
    local query2 = "profileName='"..vapTbl["profileName"] .. "'"

    -- querying the dot11Profile table 
    profileTbl = db.getRowWhere("dot11Profile", query2, false)

	wirelessTbl["wstatus"] = vapTbl["vapEnabled"]
	wirelessTbl["wname"] =  profileTbl["ssid"]

    if ((profileTbl["security"] == "WPA") or(profileTbl["security"] == "WPA2") or (profileTbl["security"] == "WPA+WPA2")) then
        wirelessTbl["wpassword"] = profileTbl["pskPassAscii"]
    elseif (profileTbl["security"] == "WEP") then
        wirelessTbl["wpassword"] = ""
    end

    -- return
    return wirelessTbl

end

-------------------------------------------------------------------------------
--@name dot11.if_up()
--
--@description this function will enable/disable vaps
--
--@return
--
function dot11.if_up (ifName, enable)
    local upstr = " up"
    if (enable == 0) then
        upstr = " down"
    end
    util.appendDebugOut ("executing ifconfig ".. ifName .. upstr .. " <br>")
    local status = os.execute ("/sbin/ifconfig " .. ifName .. upstr)
    -- call wl to stop AP
    cmdStr = WL_CMD_BINARY .. " -i " .. ifName .. " ".. upstr
    os.execute(cmdStr)
end




-------------------------------------------------------------------------------
--@name dot11.WpsConfigPbc()
--
--@description this function will execute dot11WpsConfigPbc for PBC connection
--
--@return
--
function dot11.WpsConfigPbc()

    local cmdStr = "SET wps_action=\"3\" "
    
    local interfaceName = db.getAttribute("dot11WPS", "_ROWID_", 1, "vapName")
    local vapName = db.getAttribute("dot11Interface", "interfaceName", interfaceName, "vapName")
    local vapEnabled = db.getAttribute("dot11VAP", "vapName", vapName, "vapEnabled")

    if(vapEnabled == 0)then
        return "ERROR", "Selected AP is disabled"
    end

    local profileName = db.getAttribute("dot11VAP", "vapName", vapName, "profileName")
    local profile = db.getRowWhere ("dot11Profile", "profileName='"..profileName.."'",false)

    cmdStr = cmdStr .. "wps_ssid=\""..profile["ssid"].."\" "
    -- adding the security mode 
    if (profile["security"] == "WPA+WPA2") then
        cmdStr = cmdStr .. "wps_akm=\"psk psk2\" "
    elseif(profile["security"] == "WPA2") then
        cmdStr = cmdStr .. "wps_akm=\"psk2\" "
    else
        cmdStr = cmdStr .. "wps_akm=\"psk\" "
    end
    
    -- adding encryption
    if (profile["pairwiseCiphers"] == "TKIP+CCMP") then
        cmdStr = cmdStr .. "wps_crypto=\"tkip+aes\" "
    elseif (profile["pairwiseCiphers"] == "TKIP") then
        cmdStr = cmdStr .. "wps_crypto=\"tkip\" "
    end

    -- adding psk info
    if (profile["pskPassAscii"]) then
        cmdStr = cmdStr .."wps_psk=\""..profile["pskPassAscii"].."\" "
    end
    -- adding rest of the things
    cmdStr = cmdStr .. "wps_pbc_method=\"2\" wps_sta_pin=\"00000000\" wps_method=\"2\" wps_config_command=\"1\" "
    
    -- adding interface name
    cmdStr = cmdStr .."wps_ifname=\""..interfaceName.."\""

    local host, port = "localhost", WPS_MONITOR_PORT

    local socket = require("socket")

    local ip = "127.0.0.1"
    -- create a UDP object
    local udp = assert(socket.udp())
    --send the data
    assert(udp:sendto(cmdStr, ip, port))

    -- update the wps session 
    db.execute ("update dot11WPSSessStatus set sessionStatus='1'") 
    os.execute ("/pfrm2.0/bin/lua /pfrm2.0/bin/wpsSessionUpdate.lua  > /dev/null &")

    return "OK","STATUS_OK"
end




-------------------------------------------------------------------------------
--@name dot11.WpsConfigPin()
--
--@description this function will execute dot11WpsConfigPbc for PIN connection
--
--@return
--
function dot11.WpsConfigPin(pinNumber)

    local cmdStr = "SET wps_action=\"3\" "
    
    local interfaceName = db.getAttribute("dot11WPS", "_ROWID_", 1, "vapName")
    local vapName = db.getAttribute("dot11Interface", "interfaceName", interfaceName, "vapName")
    local vapEnabled = db.getAttribute("dot11VAP", "vapName", vapName, "vapEnabled")

    if(vapEnabled == 0)then
        return "ERROR", "Selected AP is disabled"
    end

    local profileName = db.getAttribute("dot11VAP", "vapName", vapName, "profileName")
    local profile = db.getRowWhere ("dot11Profile", "profileName='"..profileName.."'",false)

    cmdStr = cmdStr .. "wps_ssid=\""..profile["ssid"].."\" "
  

    -- adding the security mode 
    if (profile["security"] == "WPA+WPA2") then
        cmdStr = cmdStr .. "wps_akm=\"psk psk2\" "
    elseif(profile["security"] == "WPA2") then
        cmdStr = cmdStr .. "wps_akm=\"psk2\" "
    else
        cmdStr = cmdStr .. "wps_akm=\"psk\" "
    end
    
    -- adding encryption
    if (profile["pairwiseCiphers"] == "TKIP+CCMP") then
        cmdStr = cmdStr .. "wps_crypto=\"tkip+aes\" "
    elseif (profile["pairwiseCiphers"] == "TKIP") then
        cmdStr = cmdStr .. "wps_crypto=\"tkip\" "
    end

    -- adding psk info
    if (profile["pskPassAscii"]) then
        cmdStr = cmdStr .."wps_psk=\""..profile["pskPassAscii"].."\" "
    end

    -- adding station pin
    cmdStr = cmdStr .. "wps_sta_pin=\""..pinNumber.."\" " 
    -- adding rest of the things
    cmdStr = cmdStr .. "wps_method=\"1\" wps_config_command=\"1\" "
    
    -- adding interface name
    cmdStr = cmdStr .."wps_ifname=\""..interfaceName.."\""

    local host, port = "localhost", WPS_MONITOR_PORT

    local socket = require("socket")

    local ip = "127.0.0.1"
    -- create a UDP object
    local udp = assert(socket.udp())
    --send the data
    assert(udp:sendto(cmdStr, ip, port))
    
    -- update the wps session
    db.execute ("update dot11WPSSessStatus set sessionStatus='1'") 
    os.execute ("/pfrm2.0/bin/lua /pfrm2.0/bin/wpsSessionUpdate.lua  > /dev/null &")

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
--@name dot11.wifiMacGet()
--
--@description this function will returns the mac address of wifi0 interface.
--
--@return
--

function dot11.wifiMacGet()
    local cmd = "/sbin/ifconfig wifi0 | grep 'HWaddr' | cut -d' ' -f 10 > /tmp/wifiMac.txt"
    os.execute(cmd)
    local f = io.open("/tmp/wifiMac.txt","r")
    local macAddr = f:read ("*line")
    f:close()
    if (macAddr) then
        return macAddr
    else
        return ""
    end
end

-------------------------------------------------------------------------------
-- @name dot11.confGet
--
-- @description This function returns dot11 configuration from the database
--
-- @param query
--
-- @return conf or nil
--

function dot11.confGet(dbtable, query)
    local records = {}

    if (query ~= nil) then
        records = db.getRowsWhere (dbtable, query, false)
        if (records == nil) then
            return nil
        end        
    else
        records = db.getTable (dbtable, false)
        if (records == nil) then
            return nil
        end        
    end        

    return records
end

-------------------------------------------------------------------------------
-- @name dot11.confSet
--
-- @description This function returns dot11 configuration from the database
--
-- @param query
--
-- @return conf or nil
--

function dot11.confSet(dbtable, cfg)

    if ((dbtable == nil) or 
        (cfg == nil) or (cfg["_ROWID_"] == nil)) then
        return false, "DOT11_ERR_INVALID_ARG"
    end        

    cfg = util.addPrefix(cfg, dbtable .. ".")

    util.appendDebugOut("dot11If: " .. util.tableToStringRec(cfg))

    local valid, errStr = db.update(dbtable, cfg, cfg["" .. dbtable .. "._ROWID_"])

    return valid, errStr
end

-------------------------------------------------------------------------------
-- @name dot11VAP.ifstateConfigure
--
-- @description This function commits the interface state changes to the
-- system and the database
--
-- @param ifTbl list of VAP interfaces
-- @param ifstate 1 for enable else  0
--
-- @return status
-- @return errCode
--

function dot11VAP.ifstateConfigure (ifTbl, ifstate)

    for k,v in pairs(ifTbl) do
        local valid = db.setAttribute("dot11VAP", "vapName", 
                                      v["vapName"], "vapEnabled", ifstate)  
        if (valid) then
            dot11.if_up (v["interfaceName"], tonumber(ifstate))
        else
            return "ERROR", "DOT11_ERR_VAP_IFSTATE"            
        end    
    end        

    return "OK", "STATUS_OK"
end    

-------------------------------------------------------------------------------
-- @name dot11VAP.ifstateSet
--
-- @description The function changes the interface state of the given vap.
--
-- @param vapTbl   table of vap interfaces
-- @param ifstate  1 for enable else 0
--
-- @return status
-- @return errCode
--

function dot11VAP.ifstateSet (vapTbl, ifstate)
    local query = nil
    local wherePart = nil

    if (vapTbl == nil) then
        return "ERROR", "DOT11_ERR_INVALID_ARG"
    end
            
    if (ifstate == nil) then
        ifstate = 1
    end        
    
    if (tonumber(ifstate) > 0 ) then
        ifstate =1
    else        
        ifstate =0
    end        

    for k,v in pairs(vapTbl) do
        wherePart  ="interfaceName='" .. v["ifname"] .. "'"

        if (query == nil) then
            query = wherePart
        else
            query = query .. " or " ..  wherePart .. " "            
        end            
    end

    local ifTbl = dot11.confGet("dot11Interface", query)
    if (ifTbl == nil) then
        return "ERROR",  "NET_ERR_DB_NOENT"
    end        

    status, errCode = dot11VAP.ifstateConfigure (ifTbl, ifstate)
    if (status ~= "OK") then
        return "ERROR", errCode
    end        

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name dot11Profile.ifNameGet
--
-- @description The function gets the ifname on which the profile is set
--
-- @param profile name of the profile
--
-- @return ifname or nil
--

function dot11Profile.ifNameGet(profileName)
    local vapName = nil
    local query  = nil

    if (profileName == nil) then
        return profileName            
    end
            
    local vaprows = db.getRowsWithJoin({"dot11Profile:dot11VAP:profileName"}, 
                                        "dot11Profile.profileName", 
                                        profileName)
    for k,v in pairs(vaprows) do
        vapName = v["dot11VAP.vapName"]
    end        

    if (vapName == nil) then
        return nil
    end        

    query = "vapName='" .. vapName .. "'"
    local row = db.getRowWhere("dot11Interface", query, false)
    if (row == nil) then
        return nil
    end        

    return row["interfaceName"]
end

-------------------------------------------------------------------------------
--@name  dot11.getDefWifi5Cfg ()
--
--@description The function will get the wireless info from the dot11 table
--
--@return

function dot11.getDefWifi5Cfg ()

    --locals
    local wirelessTbl = {}
    local query1  = "_ROWID_=2" -- getting the second row
    local vapTbl = {}
    local profileTbl = {}

    -- querying the 1st Row of dot11VAP
    vapTbl = db.getRowWhere("dot11VAP", query1, false)
    local query2 = "profileName='"..vapTbl["profileName"] .. "'"

    -- querying the dot11Profile table 
    profileTbl = db.getRowWhere("dot11Profile", query2, false)

    wirelessTbl["wstatus"] = vapTbl["vapEnabled"]
    wirelessTbl["wname"] =  profileTbl["ssid"]

    if ((profileTbl["security"] == "WPA") or(profileTbl["security"] == "WPA2") or (profileTbl["security"] == "WPA+WPA2")) then
        wirelessTbl["wpassword"] = profileTbl["pskPassAscii"]
    elseif (profileTbl["security"] == "WEP") then
        wirelessTbl["wpassword"] = ""
    end

    -- return
    return wirelessTbl

end

function brcmDefaultdscpWmmMap(v)

    -- Mapping of BRCM default values of WMM and DSCP.
    v["dot11Profile.dscpCosMap0"]  = "Best Effort"
    v["dot11Profile.dscpCosMap1"]  = "Best Effort"
    v["dot11Profile.dscpCosMap2"]  = "Best Effort"
    v["dot11Profile.dscpCosMap3"]  = "Best Effort"
    v["dot11Profile.dscpCosMap4"]  = "Best Effort"
    v["dot11Profile.dscpCosMap5"]  = "Best Effort"
    v["dot11Profile.dscpCosMap6"]  = "Best Effort"
    v["dot11Profile.dscpCosMap7"]  = "Best Effort"
    v["dot11Profile.dscpCosMap8"]  = "Background"
    v["dot11Profile.dscpCosMap9"]  = "Background"
    v["dot11Profile.dscpCosMap10"] = "Best Effort"
    v["dot11Profile.dscpCosMap11"] = "Background"
    v["dot11Profile.dscpCosMap12"] = "Best Effort"
    v["dot11Profile.dscpCosMap13"] = "Background"
    v["dot11Profile.dscpCosMap14"] = "Best Effort"
    v["dot11Profile.dscpCosMap15"] = "Background"
    v["dot11Profile.dscpCosMap16"] = "Background"
    v["dot11Profile.dscpCosMap17"] = "Background"
    v["dot11Profile.dscpCosMap18"] = "Best Effort"
    v["dot11Profile.dscpCosMap19"] = "Background"
    v["dot11Profile.dscpCosMap20"] = "Best Effort"
    v["dot11Profile.dscpCosMap21"] = "Background"
    v["dot11Profile.dscpCosMap22"] = "Best Effort"
    v["dot11Profile.dscpCosMap23"] = "Background"
    v["dot11Profile.dscpCosMap24"] = "Best Effort"
    v["dot11Profile.dscpCosMap25"] = "Best Effort"
    v["dot11Profile.dscpCosMap26"] = "Video"
    v["dot11Profile.dscpCosMap27"] = "Best Effort"
    v["dot11Profile.dscpCosMap28"] = "Video"
    v["dot11Profile.dscpCosMap29"] = "Best Effort"
    v["dot11Profile.dscpCosMap30"] = "Video"
    v["dot11Profile.dscpCosMap31"] = "Best Effort"
    v["dot11Profile.dscpCosMap32"] = "Video"
    v["dot11Profile.dscpCosMap33"] = "Video"
    v["dot11Profile.dscpCosMap34"] = "Video"
    v["dot11Profile.dscpCosMap35"] = "Video"
    v["dot11Profile.dscpCosMap36"] = "Video"
    v["dot11Profile.dscpCosMap37"] = "Video"
    v["dot11Profile.dscpCosMap38"] = "Video"
    v["dot11Profile.dscpCosMap39"] = "Video"
    v["dot11Profile.dscpCosMap40"] = "Video"
    v["dot11Profile.dscpCosMap41"] = "Video"
    v["dot11Profile.dscpCosMap42"] = "Video"
    v["dot11Profile.dscpCosMap43"] = "Video"
    v["dot11Profile.dscpCosMap44"] = "Video"
    v["dot11Profile.dscpCosMap45"] = "Video"
    v["dot11Profile.dscpCosMap46"] = "Voice"
    v["dot11Profile.dscpCosMap47"] = "Video" 
    v["dot11Profile.dscpCosMap48"] = "Voice"
    v["dot11Profile.dscpCosMap49"] = "Voice"
    v["dot11Profile.dscpCosMap50"] = "Voice"
    v["dot11Profile.dscpCosMap51"] = "Voice"
    v["dot11Profile.dscpCosMap52"] = "Voice"
    v["dot11Profile.dscpCosMap53"] = "Voice"
    v["dot11Profile.dscpCosMap54"] = "Voice"
    v["dot11Profile.dscpCosMap55"] = "Voice"
    v["dot11Profile.dscpCosMap56"] = "Voice"
    v["dot11Profile.dscpCosMap57"] = "Voice"
    v["dot11Profile.dscpCosMap58"] = "Voice"
    v["dot11Profile.dscpCosMap59"] = "Voice"
    v["dot11Profile.dscpCosMap60"] = "Voice"
    v["dot11Profile.dscpCosMap61"] = "Voice"
    v["dot11Profile.dscpCosMap62"] = "Voice"
    v["dot11Profile.dscpCosMap63"] = "Voice"
end

function dot11.nvramIfnamesSetBoot ()

    --locals
    local LAN_IFNAMES = "eth0 eth1 eth2 eth3"
    local LAN1_IFNAMES = ""
    local LAN2_IFNAMES = ""
    local LAN3_IFNAMES = ""
    local LAN4_IFNAMES = ""
    local LAN5_IFNAMES = ""
    local interfaceTbl = {}
    local cmd=nil

    interfaceTbl = db.getTable ("dot11Interface", false)

    -- unsetting the ifnames in nvram.
    if (interfaceTbl ~= nil and #interfaceTbl ~= 0) then
        os.execute ("nvram unset lan_ifnames")
        os.execute ("nvram unset lan1_ifnames")
        os.execute ("nvram unset lan2_ifnames")
        os.execute ("nvram unset lan3_ifnames")
        os.execute ("nvram unset lan4_ifnames")
        os.execute ("nvram unset lan5_ifnames")
        os.execute ("nvram unset br_ifnames")
        os.execute ("nvram unset br1_ifnames")
        os.execute ("nvram unset br2_ifnames")
        os.execute ("nvram unset br3_ifnames")
        os.execute ("nvram unset br4_ifnames")
        os.execute ("nvram unset br5_ifnames")
    end
    for k,v in pairs (interfaceTbl) do
        if (v["LogicalIfName"]== "IF2") then
            LAN_IFNAMES=LAN_IFNAMES.." "..v["interfaceName"]
            cmd = "nvram set lan_ifnames='"..LAN_IFNAMES.."'"
            os.execute (cmd)
            cmd = "nvram set br_ifnames='"..LAN_IFNAMES.."'"
            os.execute (cmd)
        elseif (v["LogicalIfName"]== "IF4")then
            LAN1_IFNAMES=LAN1_IFNAMES.." "..v["interfaceName"]
            cmd = "nvram set lan1_ifnames='"..LAN1_IFNAMES.."'"
            os.execute (cmd)
            cmd = "nvram set br1_ifnames='"..LAN1_IFNAMES.."'"
            os.execute (cmd)
        elseif (v["LogicalIfName"]== "IF5")then
            LAN2_IFNAMES=LAN2_IFNAMES.." "..v["interfaceName"]
            cmd = "nvram set lan2_ifnames='"..LAN2_IFNAMES.."'"
            os.execute (cmd)
            cmd = "nvram set br2_ifnames='"..LAN2_IFNAMES.."'"
            os.execute (cmd)
        elseif (v["LogicalIfName"]== "IF6")then
            LAN3_IFNAMES=LAN3_IFNAMES.." "..v["interfaceName"]
            cmd = "nvram set lan3_ifnames='"..LAN3_IFNAMES.."'"
            os.execute (cmd)
            cmd = "nvram set br3_ifnames='"..LAN3_IFNAMES.."'"
            os.execute (cmd)
        elseif (v["LogicalIfName"]== "IF7")then
            LAN4_IFNAMES=LAN4_IFNAMES.." "..v["interfaceName"]
            cmd = "nvram set lan4_ifnames='"..LAN4_IFNAMES.."'"
            os.execute (cmd)
            cmd = "nvram set br4_ifnames='"..LAN4_IFNAMES.."'"
            os.execute (cmd)
        elseif (v["LogicalIfName"]== "IF8")then
            LAN5_IFNAMES=LAN5_IFNAMES.." "..v["interfaceName"]
            cmd = "nvram set lan5_ifnames='"..LAN5_IFNAMES.."'"
            os.execute (cmd)
            cmd = "nvram set br5_ifnames='"..LAN5_IFNAMES.."'"
            os.execute (cmd)
        end
    end

end

function dot11.dot11InterfaceGet (profileTmp)

   --locals
   local vapName =nil
   local vapLogicalInterfaceName = nil

   vapName                 = db.getAttribute ("dot11VAP", "profileName", profileTmp["dot11Profile.profileName"],"vapName")
   vapLogicalInterfaceName = db.getAttribute ("dot11Interface", "vapName", vapName,"LogicalIfName")
   return vapLogicalInterfaceName

end

function dot11.nvramIfnamesSet ()

    --locals
    local LAN_IFNAMES = "eth0 eth1 eth2 eth3"
    local LAN1_IFNAMES = ""
    local LAN2_IFNAMES = ""
    local LAN3_IFNAMES = ""
    local LAN4_IFNAMES = ""
    local LAN5_IFNAMES = ""
    local interfaceTbl = {}
    local cmd=nil

    interfaceTbl = db.getTable ("dot11Interface", false)

    -- unsetting the ifnames in nvram.
    if (interfaceTbl ~= nil and #interfaceTbl ~= 0) then
        util.fileAppend(CMD_EXEC_SCRIPT, "nvram unset lan_ifnames")
        util.fileAppend(CMD_EXEC_SCRIPT, "nvram unset lan1_ifnames")
        util.fileAppend(CMD_EXEC_SCRIPT, "nvram unset lan2_ifnames")
        util.fileAppend(CMD_EXEC_SCRIPT, "nvram unset lan3_ifnames")
        util.fileAppend(CMD_EXEC_SCRIPT, "nvram unset lan4_ifnames")
        util.fileAppend(CMD_EXEC_SCRIPT, "nvram unset lan5_ifnames")
        util.fileAppend(CMD_EXEC_SCRIPT, "nvram unset br_ifnames")
        util.fileAppend(CMD_EXEC_SCRIPT, "nvram unset br1_ifnames")
        util.fileAppend(CMD_EXEC_SCRIPT, "nvram unset br2_ifnames")
        util.fileAppend(CMD_EXEC_SCRIPT, "nvram unset br3_ifnames")
        util.fileAppend(CMD_EXEC_SCRIPT, "nvram unset br4_ifnames")
        util.fileAppend(CMD_EXEC_SCRIPT, "nvram unset br5_ifnames")
    end
    for k,v in pairs (interfaceTbl) do
        if (v["LogicalIfName"]== "IF2") then
            LAN_IFNAMES=LAN_IFNAMES.." "..v["interfaceName"]
            cmd = "nvram set lan_ifnames='"..LAN_IFNAMES.."'"
            util.fileAppend(CMD_EXEC_SCRIPT, cmd)
            cmd = "nvram set br_ifnames='"..LAN_IFNAMES.."'"
            util.fileAppend(CMD_EXEC_SCRIPT, cmd)
        elseif (v["LogicalIfName"]== "IF4")then
            LAN1_IFNAMES=LAN1_IFNAMES.." "..v["interfaceName"]
            cmd = "nvram set lan1_ifnames='"..LAN1_IFNAMES.."'"
            util.fileAppend(CMD_EXEC_SCRIPT, cmd)
            cmd = "nvram set br1_ifnames='"..LAN1_IFNAMES.."'"
            util.fileAppend(CMD_EXEC_SCRIPT, cmd)
        elseif (v["LogicalIfName"]== "IF5")then
            LAN2_IFNAMES=LAN2_IFNAMES.." "..v["interfaceName"]
            cmd = "nvram set lan2_ifnames='"..LAN2_IFNAMES.."'"
            util.fileAppend(CMD_EXEC_SCRIPT, cmd)
            cmd = "nvram set br2_ifnames='"..LAN2_IFNAMES.."'"
            util.fileAppend(CMD_EXEC_SCRIPT, cmd)
        elseif (v["LogicalIfName"]== "IF6")then
            LAN3_IFNAMES=LAN3_IFNAMES.." "..v["interfaceName"]
            cmd = "nvram set lan3_ifnames='"..LAN3_IFNAMES.."'"
            util.fileAppend(CMD_EXEC_SCRIPT, cmd)
            cmd = "nvram set br3_ifnames='"..LAN3_IFNAMES.."'"
            util.fileAppend(CMD_EXEC_SCRIPT, cmd)
        elseif (v["LogicalIfName"]== "IF7")then
            LAN4_IFNAMES=LAN4_IFNAMES.." "..v["interfaceName"]
            cmd = "nvram set lan4_ifnames='"..LAN4_IFNAMES.."'"
            util.fileAppend(CMD_EXEC_SCRIPT, cmd)
            cmd = "nvram set br4_ifnames='"..LAN4_IFNAMES.."'"
            util.fileAppend(CMD_EXEC_SCRIPT, cmd)
        elseif (v["LogicalIfName"]== "IF8")then
            LAN5_IFNAMES=LAN5_IFNAMES.." "..v["interfaceName"]
            cmd = "nvram set lan5_ifnames='"..LAN5_IFNAMES.."'"
            util.fileAppend(CMD_EXEC_SCRIPT, cmd)
            cmd = "nvram set br5_ifnames='"..LAN5_IFNAMES.."'"
            util.fileAppend(CMD_EXEC_SCRIPT, cmd)
        end
    end

end
