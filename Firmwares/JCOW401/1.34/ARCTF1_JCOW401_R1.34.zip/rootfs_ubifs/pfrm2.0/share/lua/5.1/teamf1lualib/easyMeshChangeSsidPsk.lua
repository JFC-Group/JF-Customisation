--[[ easyMeshChangePassword.lua - Handler for Easy Mesh Login passord Change.
--
-- Copyright (c) 2008-2014, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: easyMeshChangePassword.lua
-- Description: Handler for Easy Mesh Login passord Change.
-- 
-- modification history
-- --------------------
-- 01a, 31Dec19, ar written.
--
--]]

require "easyMeshLib"
require "ifDevLib"
require "teamf1lualib/dot11"
require "teamf1lualib/dot11_ul"
require "teamf1lualib/gui"


local CMD_EXEC_SCRIPT = "/tmp/cmdExecscript.sh"
local SH_BIN          = "/bin/sh "

-- List of WiFi_AP Tags as defined by Customer Specification.
local WiFi_APobj = {
    ["Result"] = "Result"
}

-- Initialise the SSIDGetResponse_t Lua Table which will be coverted as JSON Object
local SSIDSetResponse_t = {
    ["Result"] = "ERROR",
    ["Response_Code"] = "400",
    ["Error_Message"] = "Failed to Set WiFiSSID"
}

-- Supported Return Codes for "SSIDGetResponse"
local SSIDSetResponse_ReturnCodes = {
    ["OK"] = "OK",
    ["ERROR"] = "ERROR",
    ["SUCCESS"] = "Success",
    ["FAILED"]  = "Failed",
}

local WIFISON_NODE = "WIFISON_SSID"
local WIFISON_NUMBER = "WiFi_AP_Numbers"
local WIFISON_AP_ENABLE = "WiFi_AP_Enable"
local WIFISON_SSIDNAME = "WiFi_AP_SSID" 
local WIFISON_SSIDPASSWORD = "WiFi_AP_Password" 
local WIFISON_BSS_TYPE     = "WiFi_BSS_Type"
local WIFISON_APNO = "WiFi_AP" 

local WIFISON_NODE_DEVICE_MAC = "Device_MAC"
local WIFISON_NODE_COMMON_NODE = "Common"
local WIFISON_NODE_RADIO_NODE = "radios"
local WIFISON_NODE_RADIO_TYPE = "radio_type"
local WIFISON_NODE_RADIO_BASE_MAC = "base_mac"
local WIFISON_RADIO_24G_STR = "radio_24"
local WIFISON_RADIO_5G_STR = "radio_5"
local WIFISON_RADIO_STR = "radio_0"


------------------------------------------------
--SET SSID Function
--
function setSsidPsk(inputTable)
    
    local status
    local errorFlag

    if(inputTable["radioType"] == "radio_24" and inputTable["apNo"] == "0") then
        inputTable["dot11Profile.profileName"] = "Jio_1"
        inputTable["_ROWID_"] = "1"
    elseif(inputTable["radioType"] == "radio_24" and inputTable["apNo"] == "1") then
        inputTable["dot11Profile.profileName"] = "Jio_2"
        inputTable["_ROWID_"] = "2"
    elseif(inputTable["radioType"] == "radio_24" and inputTable["apNo"] == "2") then
        inputTable["dot11Profile.profileName"] = "Jio_3"
        inputTable["_ROWID_"] = "3"
    elseif(inputTable["radioType"] == "radio_5" and inputTable["apNo"] == "0") then
        inputTable["dot11Profile.profileName"] = "Jio_4"
        inputTable["_ROWID_"] = "4"
    elseif(inputTable["radioType"] == "radio_5" and inputTable["apNo"] == "1") then
        inputTable["dot11Profile.profileName"] = "Jio_5"
        inputTable["_ROWID_"] = "5"
    elseif(inputTable["radioType"] == "radio_5" and inputTable["apNo"] == "2") then
        inputTable["dot11Profile.profileName"] = "Jio_6"
        inputTable["_ROWID_"] = "6"
    else
        inputTable["dot11Profile.profileName"] = "Jio_1"
        inputTable["_ROWID_"] = "1"
    end

    local profileTbl = db.getRowWhere("dot11Profile","profileName='"..inputTable["dot11Profile.profileName"] .. "'" , true)
    
    if(profileTbl["dot11Profile.broadcastSSID"] == "1") then
        inputTable["dot11Profile.broadcastSSID"] = "1"
    else
        inputTable["dot11Profile.broadcastSSID"] = "0"
    end
 
    if(profileTbl["dot11Profile.security"] == "WPA2") then
        inputTable["dot11Profile.security"]  = "WPA2"
        inputTable["dot11Profile.pairwiseCiphers"] = "CCMP"
        inputTable["dot11Profile.authMethods"] = "PSK"
    else
        inputTable["dot11Profile.security"]  = "OPEN"
        inputTable["dot11Profile.pairwiseCiphers"] = "NONE"
        inputTable["dot11Profile.authMethods"] = "OPEN"
    end

    status,errorFlag = ul_dot11.ProfileInfo.set(inputTable,"edit")

    return status
end

----------------------------------------------
--SSID Set Request
--
-- @description This function Handles EasyMesh SSID Set Request Method.
--
--returns JSON response for EasyMesh SSID Set Request
--
function changeEasyMeshSsidPskHandler(methodObj, meshRequestMethod)

    local status = "ERROR"
    local errorFlag
    local inputTable = {}
    local rowid
  
    inputTable["apNo"] = methodObj[WIFISON_APNO]
    inputTable["dot11Profile.ssid"]= methodObj[WIFISON_SSIDNAME]
    inputTable["dot11Profile.pskPassAscii"]= methodObj[WIFISON_SSIDPASSWORD]
    inputTable["Device_Mac"] = methodObj[WIFISON_NODE_DEVICE_MAC]
    inputTable["radioType"] = methodObj[WIFISON_NODE_COMMON_NODE][WIFISON_NODE_RADIO_NODE][1][WIFISON_NODE_RADIO_TYPE]

    --sanity Check
    
    if((inputTable["apNo"] == nil) or (inputTable["radioType"] == nil) or (inputTable["Device_Mac"] == nil) or (string.upper(inputTable["Device_Mac"]) ~= ifDevLib.getMac("bdg2")) or (inputTable["dot11Profile.ssid"] == nil)) then
        SSIDSetResponse_t["Result"] = SSIDSetResponse_ReturnCodes["FAILED"]  
        SSIDSetResponse_t["Response_Code"] = "400"
        SSIDSetResponse_t["Error_Message"] = "Bad Request"
        --mesh.sendResponse (SSIDSetResponse_t) 
        return "ERROR", "INVALID_METHOD", SSIDSetResponse_t
    end

    if((inputTable["dot11Profile.ssid"] == nil) and (inputTable["dot11Profile.pskPassAscii"] == nil)) then
        SSIDSetResponse_t["Result"] = SSIDSetResponse_ReturnCodes["FAILED"]  
        SSIDSetResponse_t["Response_Code"] = "400"
        SSIDSetResponse_t["Error_Message"] = "Bad Request"
        --mesh.sendResponse (SSIDSetResponse_t) 
        return "ERROR", "INVALID_METHOD", SSIDSetResponse_t
    end

    --Checking the Same SSID Password is as input
    if((inputTable["radioType"] == "radio_24") and (inputTable["apNo"] == "0")) then
        rowid = "1"
    elseif((inputTable["radioType"] == "radio_24") and (inputTable["apNo"] == "1")) then
        rowid = "2"
    elseif((inputTable["radioType"] == "radio_24") and (inputTable["apNo"] == "2")) then
        rowid = "3"
    elseif((inputTable["radioType"] == "radio_5") and (inputTable["apNo"] == "0")) then
        rowid = "4"
    elseif((inputTable["radioType"] == "radio_5") and (inputTable["apNo"] == "1")) then
        rowid = "5"
    elseif((inputTable["radioType"] == "radio_5") and (inputTable["apNo"] == "2")) then
        rowid = "6"
    else
        rowid = "1"
    end

    
    local profileRow = db.getRowWhere("dot11Profile", "_ROWID_ ='" ..rowid.."'" , false)
    
    if(profileRow["ssid"] == inputTable["dot11Profile.ssid"]) then
        if((inputTable["dot11Profile.pskPassAscii"] ~= nil) and (inputTable["dot11Profile.pskPassAscii"] == profileRow["pskPassAscii"])) then
            status = "OK"
        end
    end
    if(inputTable["radioType"] == "radio_0") then
        status = "ERROR"
        rowid = rowid + 3
        profileRow = db.getRowWhere("dot11Profile", "_ROWID_ ='" ..rowid.."'" , false)
        if(profileRow["ssid"] == inputTable["dot11Profile.ssid"]) then
            if((inputTable["dot11Profile.pskPassAscii"] ~= nil) and (inputTable["dot11Profile.pskPassAscii"] == profileRow["pskPassAscii"])) then
                status = "OK"
            end
        end
    end

    if(status == "OK") then
        SSIDSetResponse_t["Result"] = SSIDSetResponse_ReturnCodes["OK"]  
        SSIDSetResponse_t["Error_Message"] = nil
        SSIDSetResponse_t["Response_Code"] = "200"
        SSIDSetResponse_t[WIFISON_NODE_DEVICE_MAC] = inputTable["Device_Mac"]
        --mesh.sendResponse (SSIDSetResponse_t) 
        return "OK", "SUCCESS", SSIDSetResponse_t
    end

    db.beginTransaction() -- begin transcation

    if(inputTable["radioType"] == "radio_0") then
        inputTable["radioType"] = "radio_24"
        status=setSsidPsk(inputTable)
        if(status == "OK") then
            inputTable["radioType"] = "radio_5"
            status=setSsidPsk(inputTable)
        end
    else
        status=setSsidPsk(inputTable)
    end 

    if (status == "OK") then
            db.commitTransaction()
            db.save2()
            util.runShellCmd (SH_BIN..CMD_EXEC_SCRIPT)
            os.remove (CMD_EXEC_SCRIPT)
    else
            db.rollback()
            os.remove (CMD_EXEC_SCRIPT)
    end

    if(util.fileExists("/flash/BRCM_MESH_ENABLED") == true) then
        dot11meshReStart()
    end


    if(status ~= "OK") then
        SSIDSetResponse_t["Result"] = SSIDSetResponse_ReturnCodes["FAILED"]  
        SSIDSetResponse_t["Response_Code"] = "400"
        SSIDSetResponse_t["Error_Message"] = "Bad Request"
        mesh.sendResponse (SSIDSetResponse_t) 
        return "ERROR", "INVALID_METHOD"
    end    
 
    SSIDSetResponse_t["Result"] = SSIDSetResponse_ReturnCodes["OK"]  
    SSIDSetResponse_t["Error_Message"] = nil
    SSIDSetResponse_t["Response_Code"] = "200"
    SSIDSetResponse_t[WIFISON_NODE_DEVICE_MAC] = inputTable["Device_Mac"]
    --mesh.sendResponse (SSIDSetResponse_t) 
    return "OK", "SUCCESS", SSIDSetResponse_t

end

meshRequestMethodsList["SSIDPSKSet"]["methodHandler"] = changeEasyMeshSsidPskHandler

