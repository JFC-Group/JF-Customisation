--[[
#### Hussain Vali.
#### TeamF1
#### Copyright (c) 2008 TeamF1, Inc.
#### Oct 22, 2008
#### File: nas.lua
#### Description: NAS core routines and API
#### Revisions:
None.
]]--


--************* Requires *************

--************* Initial Code *************
--package nas
nas = {}
--************* Functions *************
-- NAS Configuration
function nas.config (inputTable, rowid, operation)
    -- validate
    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
            return db.insert(DBTable,inputTable)
        elseif (operation == "edit") then
            return db.update(DBTable,inputTable,rowid)
        elseif (operation == "delete") then
            return db.delete(DBTable,inputTable)
        end
    else
        return false
    end
end

function nas.shareConfig(inputTable, rowId, operation)
	-- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end
	db.beginTransaction() --begin transaction
	local valid = false

    -- Remove leading and trailing white spaces and "/" from the "path" variable
    inputTable["nasShare.path"] = string.gsub (inputTable["nasShare.path"], "^[%s/]+", "")
    inputTable["nasShare.path"] = string.gsub (inputTable["nasShare.path"], "[%s/]+$", "")

    -- Check if the user has entered "/" only. If so, the previous statements
    -- will remove that that "/".
    if (string.len(inputTable["nasShare.path"]) == 0) then
        inputTable["nasShare.path"] = "/"
    end

    -- Updating Share protocol configuration
    local potoInfo = ""
    local table = db.getTable ("nasProtocol")
    local shareName = inputTable["nasShare.name"]
    if (operation == "edit") then
        shareName = db.getAttribute ("nasShare", "_ROWID_", rowId, "name") or ''
    end

    for k,v in pairs (table) do
        local row = db.getRowWhere ("nasShareProtocol", "shareId = '" ..
                                     shareName .. "' and protocol = '" ..
                                     v["nasProtocol.protocol"] .. "'")
        local fieldname = "nasShareProtocol.protocol_" .. v["nasProtocol.protocol"]
        potoInfo = potoInfo .. v["nasProtocol.protocol"] .. ":" .. inputTable[fieldname]

        -- Add new entry into the protocol table
        if (inputTable[fieldname] ~= nil and
            inputTable[fieldname] == "1" and
            row == nil) then
            local inTable = {}
            inTable["nasShareProtocol.shareId"] = inputTable["nasShare.name"]
            inTable["nasShareProtocol.protocol"] = v["nasProtocol.protocol"]
            DBTable = "nasShareProtocol"
            valid = nas.config (inTable, "-1", "add")
        -- Remote an entry from the protocol table as the user has unchecked a
        -- protocol.
        elseif (inputTable[fieldname] ~= nil and
                inputTable[fieldname] == "0" and
                row ~= nil) then
            DBTable = "nasShareProtocol"
            valid = nas.config (row, "-1", "delete")
        -- Update an entry in the protocol table.
        elseif (inputTable[fieldname] ~= nil and
                inputTable[fieldname] == "1" and
                row ~= nil) then
            DBTable = "nasShareProtocol"
            local inTable = {}
            inTable["nasShareProtocol.shareId"] = inputTable["nasShare.name"]
            inTable["nasShareProtocol.protocol"] = v["nasProtocol.protocol"]
            valid = nas.config (inTable, row["nasShareProtocol._ROWID_"], "edit")
        else
            valid = true
        end

        if (not valid) then break end
    end

    if (valid) then
        DBTable = "nasShare"
        valid = nas.config (inputTable, rowId, operation)
    end
	
    if (valid) then
		db.commitTransaction(true)
        return "OK", "STATUS_OK"
	else
		db.rollback()
		return "ERROR", "NAS_SHARE_CONFIG_FAILED"
	end
end

function nas.shareDelete(rowids)
	-- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end

	db.beginTransaction() --begin transaction
	local valid = false
    local partIdTbl = {}
    local index = 0

	for k,v in pairs(rowids) do
        -- get partition id of the share
        partIdTbl[index] = db.getAttribute ("nasShare", "_ROWID_", v, "partitionId") or ''
        index = index + 1

        -- Updating Share protocol configuration
        local shareName = db.getAttribute ("nasShare", "_ROWID_", v, "name") or ''
        local table = db.getRowsWhere ("nasShareProtocol", "shareId = '" .. shareName .. "'")
        for m,n in pairs (table) do
            valid = db.deleteRow("nasShareProtocol", "_ROWID_", n["nasShareProtocol._ROWID_"])
            if (not valid) then break end
        end

        if (valid) then
	        valid = db.deleteRow("nasShare", "_ROWID_", v)
            if (not valid) then break end
        end
    end

    if (valid) then
		db.commitTransaction(true)
		return "OK", "STATUS_OK"
	else
		db.rollback()
		return "ERROR", "NAS_SHARE_DEL_FAILED"
	end
end

--*****************************************************************************
-- nas.userTblHandler - user table handler
--
-- This function handles user table update. If the user issues delete
-- operation and the user is being used by one of the share, an error is
-- returned. In case the user name is updated, updates the nas user owner with
-- updated username.
function nas.userTblHandler (tbl, operation)
    local status = "OK"
    local statusStr = "STATUS_OK"
    local valid = true

    if (operation ~= "add") then
        local nasTbl = db.getTable ("nasShare", false)
        local username = db.getAttribute ("users", "_ROWID_",
        tbl["users._ROWID_"], "username")

        db.beginTransaction()
        for k,v in ipairs (nasTbl) do
            if (v["nasShare.userOwner"] ~= nil and 
                string.find (v["nasShare.userOwner"], username) ~= nil) then
                if (operation == "delete") then
                    return "ERROR", "USER_IN_USE"
                else
                    v["nasShare.userOwner"] = string.gsub (v["nasShare.userOwner"], username, tbl["users.username"])
                    valid = db.update ("nasShare", v, v["nasShare._ROWID_"])
                    if (valid == false) then
                        break
                    end
                end
            end
        end
        if (valid) then
            db.commitTransaction()
        else
            db.rollback()
            status = "ERROR"
            statusStr = "NAS_FAILED_TO_UPDATE_USER"
        end
    end
    return status, statusStr   
end

--*****************************************************************************
-- nas.groupTblHandler - group table handler
--
-- This function handles group table update. If the user issues delete
-- operation and the group is being used by one of the share, an error is
-- returned. In case the group name is updated, updates the nas group owner
-- with updated name.
function nas.groupTblHandler (tbl, operation)
    local status = "OK"
    local statusStr = "STATUS_OK"
    local valid = true

    if (operation ~= "add") then
        local nasTbl = db.getTable ("nasShare", false)
        local groupname = db.getAttribute ("groups", "_ROWID_",
        tbl["groups._ROWID_"], "name")

        db.beginTransaction()
        for k,v in ipairs (nasTbl) do
            if (v["nasShare.groupOwner"] ~= nil and
                string.find (v["nasShare.groupOwner"], groupname) ~= nil) then
                if (operation == "delete") then
                    return "ERROR", "GROUP_IN_USE"
                else
                    v["nasShare.groupOwner"] = string.gsub (v["nasShare.groupOwner"], groupname, tbl["groups.name"])
                    valid = db.update ("nasShare", v, v["nasShare._ROWID_"])
                    if (valid == false) then
                        break
                    end
                end
            end
        end
        if (valid) then
            db.commitTransaction()
        else
            db.rollback()
            status = "ERROR"
            statusStr = "NAS_FAILED_TO_UPDATE_USER"
        end
    end
    return status, statusStr   
end

