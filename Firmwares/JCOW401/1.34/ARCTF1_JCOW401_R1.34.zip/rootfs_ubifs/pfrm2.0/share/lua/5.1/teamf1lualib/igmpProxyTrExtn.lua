--[[
#### Copyright (c) 2020, TeamF1 Networks Pvt. Ltd. 
#### (Subsidiary of D-Link India)

#### 
#### File: tr181_igmpProxyTrExtn.lua
#### Description: 
#### TR-181 handlers for igmp. This file is included from tr181_tr69funcs.lua
####

#### Revisions:
01a,14Jul2020,swr written 
]]--

igmpProxyTr = {}

--[[
--*****************************************************************************
-- igmpProxyTr.igmpCfgSet: set igmp parameters.
--
-- This function is called to set the following parameters in
-- Device.X_RJIL_COM_IGMPProxy.
-- 
-- Enable
--
-- Returns: status
-- 
]]--
function igmpProxyTr.igmpCfgSet(input, rowids, actionType, tr69Param)
    
    local status = OK
    local faultTbl = {}
    local index = 0
    local row = {}
  
    -- get corresponding db entry from 'Igmp'
    row = db.getRowWhere ("Igmp","_ROWID_=1",false)
    if (row == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    if (input["Igmp"]["Igmp.IgmpEnable"] ~= nil) then    
        row["IgmpEnable"] = input["Igmp"]["Igmp.IgmpEnable"]
    end
    
    row = util.addPrefix (row,"Igmp.")
    local valid, errstr = db.update("Igmp", row, "1")
    if (not valid) then
        sstatus = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end
    
    -- saving DB
    db.save()

    return status, faultTbl;
end

