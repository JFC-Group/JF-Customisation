debug = {}
--*********** Functions ***********--

--- @description To assist in debugging
function debug.Debugger(dbgMessage) 
   local dbgfile = ""
   dbgfile = io.open("/var/debug.log","a")
   if dbgfile~=nil then 
       dbgfile:write(dbgMessage .. "\n")
       io.close(dbgfile) 
   end
end
