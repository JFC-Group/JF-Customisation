-- radiusCLI.lua
-- Gaurav Mathur
-- TeamF1
-- www.TeamF1.com

-- Modification History
-- 28jan08,gnm modified error message text in radiusCfgInputVal() 
-- 15nov07 gnm written
--
-- Description
-- CLI Radius routines

require "teamf1lualib/radius"

--
--
function radiusCfgInputVal (configRow)
    if (configRow["radiusClient.authsecret"] == nil) then
        printCLIError ("Invalid RADIUS secret.")
	return FALSE
    end
    return TRUE
end

--
--
function radiusCfgDel (configRow)
    local errorFlag = "ERROR"
    local statusCode = ""
    local statusMessage = ""

    errorFlag, statusCode = radius.radius_config(configRow, "-1",
	       "delete")

    if (errorFlag == "OK") then db.save() end
    statusMessage = db.getAttribute("stringsMap", "stringId", statusCode, LANGUAGE)
    return errorFlag, statusMessage
end

--
--
function radiusCfgSave (configRow)
    local errorFlag = "ERROR"
    local statusCode = ""
    local statusMessage = ""

    -- Check if the row id field exists. If it does not then we are
    -- adding a new row.
    if (configRow["radiusClient._ROWID_"] == nil) then
        errorFlag, statusCode = radius.radius_config (configRow, "-1", "add")
	-- Update the RowId
	configRow["radiusClient._ROWID_"] = 
	    db.getAttribute("radiusClient", "radiusClient.authserver", 
	        configRow["radiusClient.authserver"], "_ROWID_")
    else
        errorFlag, statusCode = radius.radius_config (configRow,
		   configRow["radiusClient._ROWID_"], "edit")
    end
    -- Save db if no error
    if (errorFlag == "OK") then db.save() end
    statusMessage = db.getAttribute("stringsMap", "stringId", statusCode, LANGUAGE)

    return errorFlag, statusMessage
end

--
--
function radiusCfgInit (args)
    local primKey = args[1] -- Profile name

    local configRow = db.getRow("radiusClient", "radiusClient.authserver", 
		    primKey)
    if configRow == nil then
        configRow = {} --db.getDefaults (true, "radiusClient")
        configRow["radiusClient.authport"] = db.getAttribute ("environment", 
            "name", "RADIUS_DEF_PORT", "value")
        configRow["radiusClient.authtimeout"] = db.getAttribute ("environment", 
            "name", "RADIUS_DEF_TIMEOUT", "value")
        configRow["radiusClient.authretries"] = db.getAttribute ("environment", 
            "name", "RADIUS_DEF_RETRIES", "value")
        configRow["radiusClient.authserver"] = primKey
    end

    return rowId, configRow
end


--
-- get configuration details for the specified RADIUS server
-- 
local function radiusGetSingle (serverIP)
    local resultTab = {}

    row = db.getRow ("radiusClient", "radiusClient.authserver",
		     serverIP)
    if (row == nil) then --sanity check
       resTab.insertField (resultTab, "", "No such Radius server")
       return resultTab
    end

    resTab.insertField (resultTab, "Auth Server IP Address",
	row["radiusClient.authserver"])
    resTab.insertField (resultTab, "Auth Port", row["radiusClient.authport"])			   
    resTab.insertField (resultTab, "Timeout (in seconds)", 
		       row["radiusClient.authtimeout"])
    resTab.insertField (resultTab, "Retries", row["radiusClient.authretries"])
    resTab.insertField (resultTab, "Secret", row["radiusClient.authsecret"])
    return resultTab
end

--
-- get configuration details for all configured RADIUS servers
-- 
local function radiusGetAll ()
    local i = 0
    local resultTab = {}

    radiusTab = db.getTable("radiusClient")
    for k,v in pairs(radiusTab) do
	resTab.insertField (resultTab, "Server IP",
	    v["radiusClient.authserver"])
	resTab.insertField (resultTab, "Server Port", v["radiusClient.authport"])			   
	resTab.insertField (resultTab, "Timeout", v["radiusClient.authtimeout"])
	resTab.insertField (resultTab, "Retries", v["radiusClient.authretries"])
    end
    return resultTab
end

--
-- main function for radius get
-- 
function radiusGet (args)
    local serverIP = args[1]
    
    if (serverIP == "all") then	
       printLabel ("Configured RADIUS Servers")
       resultTab = radiusGetAll()
    else
       printLabel ("RADIUS Configuration")
       resultTab = radiusGetSingle(serverIP)
    end
    resTab.print (resultTab, 0)
end   
