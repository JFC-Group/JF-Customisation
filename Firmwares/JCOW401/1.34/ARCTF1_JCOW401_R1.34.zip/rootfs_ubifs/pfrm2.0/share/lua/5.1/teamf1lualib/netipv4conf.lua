-- @copyright Copyright (c) 2013, TeamF1, Inc.
--
-- modification history
-- --------------------
-- 01f, 29Jan18, swr changes for spr 63134
-- 01e, 23Nov17, swr changes for spr 62635(XSS vulnerability) and 61441
-- 01d, 29Aug17, sjr changes for WIFI optimization
-- 01c, 26May17, sjr Added changes related to EoGRE as part of WLAN multiple
--                   subnet
-- 01b, 23Nov16, sjr Added changes for ALU project
-- 01a, 10aug13, ash added support for l2tp
--
require "teamf1lualib/netipv4dhcp"

-------------------------------------------------------------------------
-- @name gui.networking.network.ipv4.get
--
-- @descrription This routine gets the connection configuration of this network
--
-- @param name network name
--
-- @return status
-- @return errCode
-- @return conf
--

function gui.networking.network.ipv4.get (name)
    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"
    local conf = {}
    local networkConf = {}
    local connID = {}
    local confTmp = {}

    require "teamf1lualib/network"
    status, errCode, networkConf = network.ifConfGet(name)
    if (status ~= "OK") then
        gui.dprintf("ipv4.get: failed to get interface configuration")
        return status, errCode
    end

    require "teamf1lualib/nimf"
    conf["networkName"] = networkConf["networkName"]
    conf["LogicalIfName"] = networkConf["LogicalIfName"]
    conf["networkType"] = gui.networking.zoneTypeToNetworkType (networkConf["zoneType"])
    conf["vlanId"] = networkConf["networkId"]
    conf["AddressFamily"] = "ipv4"

    connID["LogicalIfName"] = networkConf["LogicalIfName"]
    connID["AddressFamily"] = nimf.proto.NIMF_PROTO_TYPE_IPV4
    status, errCode, confTmp = gui.networking.connConfGet(connID, conf)
    if (status ~= "OK") then
        gui.dprintf("ipv4.get: failed to get connection configuration")
        -- Do not return because just after creating the network. You may not
        -- have the connection params.
    else
        conf = confTmp
    end

    if (conf["networkType"] == "WAN") then

        --
        -- Check if it is a valid DNS server
        --
        if ((gui.networking.checkValidIPv4Addr(conf["PrimaryDns"]) ~= nil) or
            (gui.networking.checkValidIPv4Addr(conf["SecondaryDns"]) ~= nil)) then
            conf["GetDnsFromIsp"] = "0"
        else
            conf["GetDnsFromIsp"] = "1"
        end

        --
        -- Set the connection type as the UI expects.
        -- If connection type is pppoe, then reset value to "1"
        -- If connection type is pptp, then reset value to "2"
        --
        if (conf["ConnectionType"] == "pppoe") then
            conf["ConnectionType"] = "2"
        elseif (conf["ConnectionType"] == "pptp") then
            conf["ConnectionType"] = "3"
        elseif (conf["ConnectionType"] == "l2tp") then
            conf["ConnectionType"] = "4"
	    elseif (conf["ConnectionType"] == "dhcpc") then
            conf["ConnectionType"] = "0"
	    elseif (conf["ConnectionType"] == "ifStatic") then
            conf["ConnectionType"] = "1"
	    elseif (conf["ConnectionType"] == "lte") then
            conf["ConnectionType"] = "5"
        end
	
        --[[
        if (conf["ConnectionType"] == "2") then
            if ((tonumber(conf["mtuSize"]) == 1492) or (conf["mtuSize"] == nil)) then
                conf["mtuType"] = "1" -- Default
            else
                conf["mtuType"] = "0" -- custom
            end
        elseif (conf["ConnectionType"] == "1") then
            if ((tonumber(conf["mtuSize"]) == "0") or (conf["mtuSize"] == nil)) then
                conf["mtuType"] = "1" -- Default
                conf["mtuSize"] = ""
            else
                conf["mtuType"] = "0" -- custom
            end
        end
        ]]--
        --
        -- Set PPP Authentication type
        --
        conf["AuthOpt"] = gui.networking.pppAuthOptGet(conf["AuthOpt"])

    elseif (conf["networkType"] == "LAN") then
        status, errCode, conf = gui.networking.ipv4DhcpConfGet(conf)

        require "teamf1lualib/firewall"

        conf["securityLevel"] = firewall.securityLevelGet (networkConf["LogicalIfName"])
        --
        -- for a new network we need to show 'typical' security level as default
        -- level
        if (conf["securityLevel"] == nil) then
            conf["securityLevel"] = "1"
        end

--[[
        conf["fullConeNat"] = gui.security.full_cone_nat.statusGet (networkConf["networkName"])
        util.appendDebugOut ("fullConeNatstatusget " .. conf["fullConeNat"])
        conf["nat"] = "2"
        if(name == "Guest") then
            conf.Wireless = gui.networking.network.guestVapSsidGet ()
        elseif(name == "Local") then
            conf.Wireless = gui.networking.network.adminVapSsidGet ()
        else
            conf.Wireless = "N/A"
        end
        if (conf.Wireless == nil) then
            return status, errCode
        end
--]]

    end
--[[
        -- Getting the required hidden fields .

        local cfgTbl = {}
        local query2 = "networkInterface:ipAddressTable:LogicalIfName"
        cfgTbl = db.getTableWithJoin ({query2})
        local lanTbl = {}
        local wanTbl = {}
        local dmzTable = {}
        local dmzTbl = {}

        for i,v in pairs (cfgTbl) do
            if (v["networkInterface.networkName"] ~= name) then -- Adding a check to return ipAddress and subnet only for networks
                                                                      -- other than the network used .(name)
                if ((v["networkInterface.zoneType"] == "secure") and (v["ipAddressTable.addressFamily"] == "2")) then
                    lanTbl[i] = {}
                    lanTbl[i]["hdLanIp"] = v["ipAddressTable.ipAddress"]
                    lanTbl[i]["hdLanSnet"] = v["ipAddressTable.subnetMask"]
                    lanTbl[i]["hdLanIfName"] = v["networkInterface.networkName"]
                end
                if ((v["networkInterface.zoneType"] == "insecure") and (v["ipAddressTable.addressFamily"] == "2")) then
                    wanTbl[i] = {}
                    wanTbl[i]["hdWanIp"] = v["ipAddressTable.ipAddress"]
                    wanTbl[i]["hdWanSnet"] = v["ipAddressTable.subnetMask"]
                    wanTbl[i]["hdWanIfName"] = v["networkInterface.networkName"]
                end
            end
        end

--]]
--[[
        require "teamf1lualib/firewall"
        local query1 = "_ROWID_=1"
        dmzTable = db.getRowWhere("dmz",query1, false)
        if (dmzTable ~= nil) then
            dmzTbl["hdDmzIfName"] = db.getAttribute("networkInterface","LogicalIfName",dmzTable["LogicalIfName"],"networkName")
            if (dmzTable.ipAddr ~= nil) then
                dmzTbl["hdDmzIp"] = dmzTable.ipAddr or ""
                status, errCode,dmzTbl["hdDmzSnet"] = firewall.getNetMask(dmzTable["LogicalIfName"], dmzTable.ipAddr)
            end
        end
--]]
        --conf.lanTbl = lanTbl
        --conf.wanTbl = wanTbl
        --conf.dmzTbl = dmzTbl

    conf["StaticIp"] = util.filterXSSChars(conf["StaticIp"])
    conf["NetMask"] = util.filterXSSChars(conf["NetMask"])
    conf["dhcpStartIP"] = util.filterXSSChars(conf["dhcpStartIP"])
    conf["dhcpStopIP"] = util.filterXSSChars(conf["dhcpStopIP"])
    conf["PrimaryDns"] = util.filterXSSChars(conf["PrimaryDns"])
    conf["SecondaryDns"] = util.filterXSSChars(conf["SecondaryDns"])
    conf["DomainName"] = util.filterXSSChars(conf["DomainName"])
    conf["dhcpLeaseTime"] = util.filterXSSChars(conf["dhcpLeaseTime"])
    conf["relayGw"] = util.filterXSSChars(conf["relayGw"])
    conf["Gateway"] = util.filterXSSChars(conf["Gateway"])
    conf["MyIPAddress"] = util.filterXSSChars(conf["MyIPAddress"])
    conf["ServerIp"] = util.filterXSSChars(conf["ServerIp"])
    conf["Username"] = util.filterXSSChars(conf["Username"])
    conf["Password"] = util.filterXSSChars(conf["Password"])
    conf["ServiceName"] = util.filterXSSChars(conf["ServiceName"])
    conf["Secret"] = util.filterXSSChars(conf["Secret"])
    conf["IdleDisconnectTime"] = util.filterXSSChars(conf["IdleDisconnectTime"])


    gui.dprintf("ipv4.get: " .. util.tableToStringRec(conf))
    return "OK", "STATUS_OK", conf
end

-------------------------------------------------------------------------
-- @name gui.networking.network.ipv4.setapp
--
-- @descrription This routine configures for this network through app
--
-- @param name network name
-- @param conf
--
-- @return status
-- @return errCode
--
function gui.networking.network.ipv4.setapp (name, conf)
    require "teamf1lualib/validations"

    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"
    local rangeCheck = 0
    local DEFAULT_LOGICAL_IFNAME = "IF2"
    local query = "LogicalIfName!='" .. DEFAULT_LOGICAL_IFNAME .. "' and LogicalIfName!= 'IF1' and AddressFamily=2"
    local ifStaticRows   = {}
    local userIpTbl      = {}
    local userIpStartTbl = {} 
    local userIpEndTbl   = {} 
    local dbIpTbl        = {}

    

    gui.dprintf("ipv4.set: INPUT:" .. util.tableToStringRec(conf))
    gui.dprintf("ipv4.set: INPUT:" .. name)

    if (name == nil) then
        gui.dprintf("ipv4.set: network name not provided")
        return status, errCode
    end

    if (conf == nil) then
        gui.dprintf("ipv4.set: configuration data not provided")
        return status, errCode
    end

    -- ip address validation
    if((validations.ipAddressValidate(conf["StaticIp"], "","","")) ~= "OK") then
        return "ERROR", "IP_ADDRESS_INVALID"
    end

    if (conf["networkType"] == "LAN" and conf["dhcpMode"] == "1") then 
        if(conf["dhcpStartIP"] and 	conf["dhcpStopIP"] and conf["StaticIp"]) then
            rangeCheck = gui.networking.lanIpValidation (conf["StaticIp"], conf["dhcpStartIP"], conf["dhcpStopIP"])
            if (rangeCheck == 1) then
                return "ERROR", "LAN_IP_IN_DHCP_RANGE"
            end
        end
    end
    
    if (conf["networkType"] == "LAN") then
        ifStaticRows=db.getRowsWhere("ifStatic", query, false)
        userIpTbl      = util.split (conf["StaticIp"], '.')
        if (conf["dhcpMode"] == "1") then
            userIpStartTbl = util.split (conf["dhcpStartIP"], '.')
            userIpEndTbl   = util.split (conf["dhcpStopIP"], '.')
        end
        for i,v in pairs(ifStaticRows) do
            dbIpTbl   = util.split (v["StaticIp"],'.')
            --comparing first 3 octets same or not
            if (((userIpTbl[1] == dbIpTbl[1]) and (userIpTbl[2] == dbIpTbl[2]) and (userIpTbl[3] == dbIpTbl[3])) or (conf["dhcpMode"] == "1" and  (((userIpStartTbl[1] == dbIpTbl[1]) and (userIpStartTbl[2] == dbIpTbl[2]) and (userIpStartTbl[3] == dbIpTbl[3])) or ((userIpEndTbl[1] == dbIpTbl[1]) and (userIpEndTbl[2] == dbIpTbl[2]) and (userIpEndTbl[3] == dbIpTbl[3]))))) then
                return "ERROR", "LAN IP address is in the range of Custom LAN"
            end
        end
    end


    -- default(s)
    conf["AddressFamily"] = "ipv4"
    conf["Enable"] = "1"
    conf["ConfigureRoute"] = "1"

    if (conf["networkType"] == "LAN") then
        conf["ConfigureDNS"] = "0"
    else
        conf["ConfigureDNS"] = "1"
    end

    --
    -- Add missing fields expected by the
    -- backend.
    --
    if (conf["GetDnsFromIsp"] == nil) then
        if ((gui.networking.checkValidIPv4Addr(conf["PrimaryDns"]) == nil) and
            (gui.networking.checkValidIPv4Addr(conf["SecondaryDns"]) == nil)) then
            conf["GetDnsFromIsp"] = 1
        else
            conf["GetDnsFromIsp"] = 0
        end
    end

    if (tonumber(conf["GetDnsFromIsp"]) == 1) then
        if (conf["PrimaryDns"] == nil) then
            conf["PrimaryDns"] = "0.0.0.0"
        end
        if (conf["SecondaryDns"] == nil) then
            conf["SecondaryDns"] = "0.0.0.0"
        end
    end

    if (conf["GetIpFromIsp"] == nil) then
        if (gui.networking.checkValidIPv4Addr(conf["StaticIp"]) == nil) then
            conf["GetIpFromIsp"] = 1
        else
            conf["GetIpFromIsp"] = 0
        end
    end

    --[[
    if (conf["requireLogin"] == nil) then
        conf["requireLogin"] = 0
    end
    --]]

    if(conf["ConnectionType"] == "2" or conf["ConnectionType"] == "3"
       or conf["ConnectionType"] == "4" or conf["ConnectionType"] == "5" ) then
        conf["requireLogin"] = "1"
    else
        conf["requireLogin"] = "0"
    end

    conf["ConnectionType"] = gui.networking.getConnType (conf)
    if (conf["ConnectionType"] == nil) then
        gui.dprintf("ipv4.set: connection type not provided<br>")
        return status, errCode
    end


    if (conf["Gateway"] == nil) then
        conf["Gateway"] = "0.0.0.0"
    end

    if (conf["ConnectionType"] == "pppoe") then
        if (tonumber(conf["mtuType"]) == 1) then
            conf["Mtu"] = "1492" -- default
        else
            conf["Mtu"] = conf["mtuSize"]
        end
    end


    if (conf["ConnectionType"] == "pptp") then
        if (tonumber(conf["mtuType"]) == 1) then
            conf["Mtu"] = "1492" -- default
        else
            conf["Mtu"] = conf["mtuSize"]
        end
    end

    if (conf["ConnectionType"] == "l2tp") then
        if (tonumber(conf["mtuType"]) == 1) then
            conf["Mtu"] = "1492" -- default
        else
            conf["Mtu"] = conf["mtuSize"]
        end
    end

    --[[ TODO: In case of LTE, If we need specific MTU
    if (conf["ConnectionType"] == "lte") then
        if (tonumber(conf["mtuType"]) == 1) then
            conf["Mtu"] = "1492" -- default
        else
            conf["Mtu"] = conf["mtuSize"]
        end
    end
]]--    

    conf["Secret"] = conf["Secret"]
    conf["MppeEncryptSupport"] = conf["mppe"]
    gui.dprintf("confLoad: " .. util.tableToStringRec(conf))

    --
    -- Configure the Connection
    --
    require "teamf1lualib/network"
    status, errCode = network.configure (name, conf)
    if (status ~= "OK") then
        if (errCode == nil or errCode == "") then
            errCode = "NET_ERR_IPV4_CONFIG"
        end
        gui.dprintf("ipv4.set: network configuration failed with error:" .. errCode)
        return status, errCode
    end

    --
    -- If this is a LAN type connection, the configure DHCP
    --
    if (conf["networkType"] == "LAN") then
        status, errCode = gui.networking.ipv4DhcpConfigure(conf)
        if (status ~= "OK") then
            gui.dprintf ("ipv4.set: network DHCP server configuration failed:" .. errCode)
            return status, errCode
        end
--[[
        -- configure security level
        require "teamf1lualib/firewall"
        status, errCode = firewall.securityLevelSet (name, conf["securityLevel"])
        if (status ~= "OK") then
            gui.dprintf ("ipv4.set: network security level configuration failed:" .. errCode)
            return status, errCode
        end

        -- configure full cone nat
        status, errCode = gui.security.full_cone_nat.manage (name, conf["fullConeNat"])
        if (status ~= "OK") then
            gui.dprintf ("ipv4.set: network security level configuration failed:" .. errCode)
            return status, errCode
        end

        require "teamf1lualib/bonjour"
        -- configure the Bonjour Settings
        local associatedTbl = {}
        local query = "vlanName='"..name.."'"
        associatedTbl = db.getRowWhere ("bonjourAssociatedVlans", query, false)
        if (associatedTbl == nil) then
            status, errCode = bonjour.associatedVlansSet(name)
            if (status ~= "OK") then
                gui.dprintf ("ipv4.set: bonjour associated vlans configuration failed:" .. errCode)
                return status, errCode
            end
        else
            status, errCode = bonjour.associatedVlansEditSet(name, associatedTbl["status"])
            if (status ~= "OK") then
                gui.dprintf ("ipv4.set: bonjour associated vlans configuration failed:" .. errCode)
                return status, errCode
            end
        end
--]]
    end

    db.save2()

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------
-- @name gui.networking.network.ipv4.set
--
-- @descrription This routine configures for this network
--
-- @param name network name
-- @param conf
--
-- @return status
-- @return errCode
--
function gui.networking.network.ipv4.set (name, conf)
    require "teamf1lualib/validations"

    local status = "ERROR"
    local errCode = "NET_ERR_INVALID_PARAMS"
	local rangeCheck = 0
    local DEFAULT_LOGICAL_IFNAME = "IF2"
    local query = "LogicalIfName!='" .. DEFAULT_LOGICAL_IFNAME .. "' and LogicalIfName!= 'IF1' and AddressFamily=2"
    local ifStaticRows   = {}
    local userIpTbl      = {}
    local userIpStartTbl = {} 
    local userIpEndTbl   = {} 
    local dbIpTbl        = {}

    -- Sanity for privilages
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    gui.dprintf("ipv4.set: INPUT:" .. util.tableToStringRec(conf))
    gui.dprintf("ipv4.set: INPUT:" .. name)

    if (name == nil) then
        gui.dprintf("ipv4.set: network name not provided")
        return status, errCode
    end

    if (conf == nil) then
        gui.dprintf("ipv4.set: configuration data not provided")
        return status, errCode
    end

    -- ip address validation
    if((validations.ipAddressValidate(conf["StaticIp"], "","","")) ~= "OK") then
        return "ERROR", "IP_ADDRESS_INVALID"
    end

	if (conf["networkType"] == "LAN" and conf["dhcpMode"] == "1") then

		if(conf["dhcpStartIP"] and 	conf["dhcpStopIP"] and conf["StaticIp"]) then
			rangeCheck = gui.networking.lanIpValidation (conf["StaticIp"], conf["dhcpStartIP"], conf["dhcpStopIP"])
			if (rangeCheck == 1) then
				return "ERROR", "LAN_IP_IN_DHCP_RANGE"
			end
		end
	end

    if (conf["networkType"] == "LAN") then
        ifStaticRows=db.getRowsWhere("ifStatic", query, false)
        userIpTbl      = util.split (conf["StaticIp"], '.')
        if (conf["dhcpMode"] == "1") then
            userIpStartTbl = util.split (conf["dhcpStartIP"], '.')
            userIpEndTbl   = util.split (conf["dhcpStopIP"], '.')
        end
        for i,v in pairs(ifStaticRows) do
            dbIpTbl   = util.split (v["StaticIp"],'.')
            --comparing first 3 octets same or not
            if (((userIpTbl[1] == dbIpTbl[1]) and (userIpTbl[2] == dbIpTbl[2]) and (userIpTbl[3] == dbIpTbl[3])) or (conf["dhcpMode"] == "1" and  (((userIpStartTbl[1] == dbIpTbl[1]) and (userIpStartTbl[2] == dbIpTbl[2]) and (userIpStartTbl[3] == dbIpTbl[3])) or ((userIpEndTbl[1] == dbIpTbl[1]) and (userIpEndTbl[2] == dbIpTbl[2]) and (userIpEndTbl[3] == dbIpTbl[3]))))) then
                return "ERROR", "LAN IP address is in the range of Custom LAN"
            end
        end

        reserverdLanSubnetRows=db.getTable("LanReservedSubnets",false)
        if (reserverdLanSubnetRows ~= nil ) then
            for j,k in pairs(reserverdLanSubnetRows) do
                dbIpStaticTbl   = util.split (k["IPRouter"],'.')
                --comparing first 3 octets same or not
                if (((userIpTbl[1] == dbIpStaticTbl[1]) and (userIpTbl[2] == dbIpStaticTbl[2]) and (userIpTbl[3] == dbIpStaticTbl[3])) ) then
                    return "ERROR", "LAN IP address is in the range of Custom LAN"
                end
            end
        end
    end


    -- default(s)
    conf["AddressFamily"] = "ipv4"
    conf["Enable"] = "1"
    conf["ConfigureRoute"] = "1"

    if (conf["networkType"] == "LAN") then
        conf["ConfigureDNS"] = "0"
    else
        conf["ConfigureDNS"] = "1"
    end

    --
    -- Add missing fields expected by the
    -- backend.
    --
    if (conf["GetDnsFromIsp"] == nil) then
        if ((gui.networking.checkValidIPv4Addr(conf["PrimaryDns"]) == nil) and
            (gui.networking.checkValidIPv4Addr(conf["SecondaryDns"]) == nil)) then
            conf["GetDnsFromIsp"] = 1
        else
            conf["GetDnsFromIsp"] = 0
        end
    end

    if (tonumber(conf["GetDnsFromIsp"]) == 1) then
        if (conf["PrimaryDns"] == nil) then
            conf["PrimaryDns"] = "0.0.0.0"
        end
        if (conf["SecondaryDns"] == nil) then
            conf["SecondaryDns"] = "0.0.0.0"
        end
    end

    if (conf["GetIpFromIsp"] == nil) then
        if (gui.networking.checkValidIPv4Addr(conf["StaticIp"]) == nil) then
            conf["GetIpFromIsp"] = 1
        else
            conf["GetIpFromIsp"] = 0
        end
    end

    --[[
    if (conf["requireLogin"] == nil) then
        conf["requireLogin"] = 0
    end
    --]]

    if(conf["ConnectionType"] == "2" or conf["ConnectionType"] == "3"
       or conf["ConnectionType"] == "4" or conf["ConnectionType"] == "5" ) then
        conf["requireLogin"] = "1"
    else
        conf["requireLogin"] = "0"
    end

    conf["ConnectionType"] = gui.networking.getConnType (conf)
    if (conf["ConnectionType"] == nil) then
        gui.dprintf("ipv4.set: connection type not provided<br>")
        return status, errCode
    end


    if (conf["Gateway"] == nil) then
        conf["Gateway"] = "0.0.0.0"
    end

    if (conf["ConnectionType"] == "pppoe") then
        if (tonumber(conf["mtuType"]) == 1) then
            conf["Mtu"] = "1492" -- default
        else
            conf["Mtu"] = conf["mtuSize"]
        end
    end


    if (conf["ConnectionType"] == "pptp") then
        if (tonumber(conf["mtuType"]) == 1) then
            conf["Mtu"] = "1492" -- default
        else
            conf["Mtu"] = conf["mtuSize"]
        end
    end

    if (conf["ConnectionType"] == "l2tp") then
        if (tonumber(conf["mtuType"]) == 1) then
            conf["Mtu"] = "1492" -- default
        else
            conf["Mtu"] = conf["mtuSize"]
        end
    end

    --[[ TODO: In case of LTE, If we need specific MTU
    if (conf["ConnectionType"] == "lte") then
        if (tonumber(conf["mtuType"]) == 1) then
            conf["Mtu"] = "1492" -- default
        else
            conf["Mtu"] = conf["mtuSize"]
        end
    end
]]--    

    conf["Secret"] = conf["Secret"]
    conf["MppeEncryptSupport"] = conf["mppe"]
    gui.dprintf("confLoad: " .. util.tableToStringRec(conf))

    --
    -- Configure the Connection
    --
    require "teamf1lualib/network"
    status, errCode = network.configure (name, conf)
    if (status ~= "OK") then
        if (errCode == nil or errCode == "") then
            errCode = "NET_ERR_IPV4_CONFIG"
        end
        gui.dprintf("ipv4.set: network configuration failed with error:" .. errCode)
        return status, errCode
    end

    --
    -- If this is a LAN type connection, the configure DHCP
    --
    if (conf["networkType"] == "LAN") then
        status, errCode = gui.networking.ipv4DhcpConfigure(conf)
        if (status ~= "OK") then
            gui.dprintf ("ipv4.set: network DHCP server configuration failed:" .. errCode)
            return status, errCode
        end
--[[
        -- configure security level
        require "teamf1lualib/firewall"
        status, errCode = firewall.securityLevelSet (name, conf["securityLevel"])
        if (status ~= "OK") then
            gui.dprintf ("ipv4.set: network security level configuration failed:" .. errCode)
            return status, errCode
        end

        -- configure full cone nat
        status, errCode = gui.security.full_cone_nat.manage (name, conf["fullConeNat"])
        if (status ~= "OK") then
            gui.dprintf ("ipv4.set: network security level configuration failed:" .. errCode)
            return status, errCode
        end

        require "teamf1lualib/bonjour"
        -- configure the Bonjour Settings
        local associatedTbl = {}
        local query = "vlanName='"..name.."'"
        associatedTbl = db.getRowWhere ("bonjourAssociatedVlans", query, false)
        if (associatedTbl == nil) then
            status, errCode = bonjour.associatedVlansSet(name)
            if (status ~= "OK") then
                gui.dprintf ("ipv4.set: bonjour associated vlans configuration failed:" .. errCode)
                return status, errCode
            end
        else
            status, errCode = bonjour.associatedVlansEditSet(name, associatedTbl["status"])
            if (status ~= "OK") then
                gui.dprintf ("ipv4.set: bonjour associated vlans configuration failed:" .. errCode)
                return status, errCode
            end
        end
--]]
    end

    db.save2()

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------
-- @name gui.networking.ipv4StatusGet
--
-- @descrription
--
-- @param name
-- @param conf
--
-- @return
--

function gui.networking.ipv4StatusGet(conf)
    local v4 = {}

    local ifconf = conf["ifconf"]
    local LogicalIfName = ifconf["LogicalIfName"]

    local ipv4conf = conf["ipv4"]
    if (ipv4conf == nil) then
        return v4
    end

    util.appendDebugOut("The conf table - " .. util.tableToStringRec(conf))
    v4.addrs = {}
    local ipv4status = ipv4conf["status"]
    local rowVal = 1
    if (ipv4status ~= nil) then
        local ipv4addr = ipv4status["addrs"]
        if ((ipv4addr ~= nil) and (util.tableSize(ipv4addr) > 0)) then
            for k,v in pairs (ipv4addr) do
                v4.addrs[rowVal] = {}
                if (v["ConnectionKey"] == "0") then
                    v4.addrs[rowVal]["StaticIp"] = v["ipAddress"] or "0.0.0.0"
                    if ((ipv4conf.conf.ConnectionType == "pptp") or (ipv4conf.conf.ConnectionType == "l2tp") 
                        or (ipv4conf.conf.ConnectionType == "pppoe")) then
                        v4.addrs[rowVal]["Gateway"] = v["ipDstAddres"] or "0.0.0.0"
                    else
                        v4.addrs[rowVal]["Gateway"] = ipv4status["Router"] or "0.0.0.0"
                    end
                    v4.addrs[rowVal]["NetMask"] = v["subnetMask"] or "0.0.0.0"
                    v4.addrs[rowVal]["AddressFamily"] = v["addressFamily"]
                    rowVal = rowVal + 1
                end
            end
        else
            v4.addrs[1] = {}
            v4.addrs[1]["StaticIp"] = "0.0.0.0"
            v4.addrs[1]["Gateway"] = "0.0.0.0"
            v4.addrs[1]["NetMask"] = "0.0.0.0"
            v4.addrs[1]["AddressFamily"] = "2"
        end

        v4["ConnectionStatus"] = gui.networking.connStateStrGet(ipv4status)
        v4["ConnectionTime"] = gui.networking.connUpTimeGet(ipv4status)
        v4["State"] = ipv4status["State"]
     v4["PrimaryDns"] = ipv4status ["dns"]["nameserver1"] or "0.0.0.0"
        v4["SecondaryDns"] = ipv4status ["dns"]["nameserver2"] or "0.0.0.0"
     else
         v4.addrs[1] = {}
         v4.addrs[1]["StaticIp"] = "0.0.0.0"
         v4.addrs[1]["Gateway"] = "0.0.0.0"
         v4.addrs[1]["NetMask"] = "0.0.0.0"
         v4.addrs[1]["AddressFamily"] = "2"
    end

    if ((v4["PrimaryDns"] == nil) or (v4["PrimaryDns"] == "")) then
        v4["PrimaryDns"] = "0.0.0.0"
    end
    if ((v4["SecondaryDns"] == nil) or (v4["SecondaryDns"] == ""))then
        v4["SecondaryDns"] = "0.0.0.0"
    end

    local ipv4connconf = ipv4conf["conf"]
    if (ipv4connconf ~= nil) then
        if (ipv4connconf["ConnectionType"] == "ifStatic") then
            v4["ConnectionType"] = "IPv4 Manual Configuration(Static)"
        elseif (ipv4connconf["ConnectionType"] == "dhcpc") then
            v4["ConnectionType"] = "IPv4 Automatic (DHCP)"
        elseif (ipv4connconf["ConnectionType"] == "pptp") then
            v4["ConnectionType"] = "PPTP"
        elseif (ipv4connconf["ConnectionType"] == "l2tp") then
            v4["ConnectionType"] = "L2TP"
        elseif (ipv4connconf["ConnectionType"] == "pppoe") then
            v4["ConnectionType"] = "PPPoE"
        elseif (ipv4connconf["ConnectionType"] == "lte") then
            v4["ConnectionType"] = "LTE"            
        else
            gui.dprintf ("IPv4 Status Get: Invalid conncection type")
        end
    end

    if ((ipv4connconf ["ConnectionType"] == "ifStatic") or (ipv4connconf ["ConnectionType"] == "dhcpc")) then
        v4["mtu"] = conf["ifMtu"]
    else
        v4["mtu"] = ipv4connconf["Mtu"]
    end

    v4["nat"] = "Symmetric NAT"

    if (ifconf["zoneType"] == "secure") then
        require "teamf1lualib/dhcp"
        status, errCode, dhcpConf = dhcp.poolConfGet(LogicalIfName, 1)
        if (status == "OK") then
            if (tonumber(dhcpConf["Enable"]) == 1) then
                v4["dhcpServer"] = "Enabled"
            else
                v4["dhcpServer"] = "Disabled"
            end
        else
            v4["dhcpServer"] = "None"
        end
    end

    return v4
end

-------------------------------------------------------------------------
-- @name gui.networking.network.eogre.set
--
-- @descrription This routine configures eogre for this network
--
-- @param name network name
-- @param conf
--
-- @return status
-- @return errCode
--
function gui.networking.network.eogre.set (conf, dbFlag)

    require "teamf1lualib/wireless"
    require "teamf1lualib/dot11"
    require "teamf1lualib/gpon"

    -- Making dbFlag 1, to perform db transactions
    if (dbFlag == nil) then
        dbFlag = 1
    end

    local status = ""
    local eogreTmp = {}
    local query = "_ROWID_=1"    
    
    eogreTmp = firewall.eogreGet(query)
    if (eogreTmp == nil) then
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end

    if (conf ~= nil) then
        if (conf["Enable"] ~= nil) then
            if (tonumber(eogreTmp["Enable"]) == 0)then
               if (tonumber(eogreTmp["Enable"]) == tonumber(conf["Enable"]) and tonumber(eogreTmp["secEnable"]) == tonumber(conf["Enable"]))then
                   return "OK", "STATUS_OK"
               end
            end
            eogreTmp["Enable"] = conf["Enable"]
            eogreTmp["secEnable"] = 0            
        end
        if (conf["ipType"] ~= nil) then
            eogreTmp["ipType"] = conf["ipType"]
        end

        if (conf["TunnelKey"] ~= nil) then
            eogreTmp["TunnelKey"] = conf["TunnelKey"]
        end
        if (conf["RemoteIP"] ~= nil) then
            eogreTmp["RemoteIP"] = conf["RemoteIP"]
        end
        if (conf["RemoteIP6"] ~= nil) then
            eogreTmp["RemoteIP6"] = conf["RemoteIP6"]
        end

        if (conf["EnableOffloadFallBack"] ~= nil) then
            eogreTmp["EnableOffloadFallBack"] = conf["EnableOffloadFallBack"]
        end

        if (conf["FallBackTime"] ~= nil) then
            eogreTmp["FallBackTime"] = conf["FallBackTime"]
        end
       
        if (conf["secRemoteIP"] ~= nil) then
            eogreTmp["secRemoteIP"] = conf["secRemoteIP"]
        end
        if (conf["secRemoteIP6"] ~= nil) then
            eogreTmp["secRemoteIP6"] = conf["secRemoteIP6"]
        end

        if (conf["ModeOfOperation"] ~= nil) then
            eogreTmp["ModeOfOperation"] = conf["ModeOfOperation"]
        end

        if(eogreTmp["Enable"] == "0" or eogreTmp["ModeOfOperation"] == "2") then
            eogreTmp["EnableOffloadFallBack"] = "0"
        end

        if (conf["vlanId"] ~= nil) then
            eogreTmp["vlanId"] = conf["vlanId"]
        else
            eogreTmp["vlanId"] = 0
        end

        if (conf["dataRate"] ~= nil) then
            eogreTmp["dataRate"] = conf["dataRate"]
        else
            eogreTmp["dataRate"] = 0
        end
    end

    local eogreOldRow = db.getRowWhere ("Eogre",  "_ROWID_=1", false)
   
    local jioPrivateNetSupport = "0"
    jioPrivateNetSupport = db.getAttribute ("Eogre", "_ROWID_", 1, "jioPrivateNet")
    --jioPrivateNetSupport = db.getAttribute ("environment", "name", "JIO_PRIVATE_NET" ,"value")

    if ((tonumber(eogreTmp["Enable"])== 1) and (tonumber(eogreTmp["ModeOfOperation"])== 1))then
        if ((tonumber(eogreOldRow["Enable"]) == 0 and tonumber(eogreOldRow["secEnable"]) == 0) or (tonumber(eogreOldRow["ModeOfOperation"])== 2))then
            --ap2 eogre settings
            local wlProfiles = {}
            local accesspoint
            if(jioPrivateNetSupport == "1")then
                accesspoint = "ap3"
                --[[
                eogreWanRow = db.getRow ("gpon","_ROWID_","2")
                eogreWanRow["gpon.status"] = "1"
                --eogreWanRow["gpon.vlanStatus"] = "1"
                local valid = gpon.eogreWanconfigure(eogreWanRow, "2", "edit")
                if(not(valid))then
                    return "ERROR", "Enable WAN on Eogre Failed"
                end
                ]]--
                local valid = db.setAttribute ("NimfConf", "LogicalIfName","IF10","Enable","1")
                if(not(valid))then
                    return "ERROR", "Enable NimfConf Failed"
                end
                local valid = db.setAttribute ("networkInterface", "LogicalIfName","IF10","enable","1")
                if(not(valid))then
                    return "ERROR", "Enable networkInterface Failed"
                end
            else
                accesspoint = "ap2"
            end
            local query = "vapName= '" .. accesspoint .. "'"
            local dot11vapTbl = db.getRowWhere ("dot11VAP",query, false)
            if (dot11vapTbl == nil) then
                return "ERROR", "DB_ERROR_TRY_AGAIN"
            end

            local profilename = dot11vapTbl["profileName"]
            query = "profileName= '" .. profilename .. "'"
            local dot11profileTbl = db.getRowWhere ("dot11Profile",query, false)
            if (dot11profileTbl == nil) then
                return "ERROR", "DB_ERROR_TRY_AGAIN"
            end
			
            local inputTable = {}
            inputTable["_ROWID_"] = dot11vapTbl["_ROWID_"]
            inputTable["dot11VAP.maxClients"] = dot11vapTbl["maxClients"]
            inputTable["dot11VAP.apIsolation"] = 1
            inputTable["dot11VAP.profileName"] = dot11vapTbl["profileName"]
            inputTable["dot11VAP.vapName"] = dot11vapTbl["vapName"]
            inputTable["dot11VAP.vapEnabled"] = "1"
            inputTable["dot11VAP.eogreCall"] = "1"
            if(jioPrivateNetSupport == "1")then
                inputTable["dot11VAP.defaultSubnet"] = "2"
            else
                inputTable["dot11VAP.defaultSubnet"] = "1"
            end

            errorFlag, statusCode = gui.wireless.apProfileInfo.edit.set (inputTable, "edit", dbFlag)
            if (errorFlag == "ERROR")then
                return "ERROR", "Failed to edit wireless accesspoint"..accesspoint
            end
            --[[
            local rows = {}
            rows["1"] = dot11vapTbl["_ROWID_"]
            errorFlag, statusCode = gui.wireless.apProfileInfo.status(rows,"enable", dbFlag)
            if (errorFlag == "ERROR")then
                return "ERROR", "Failed to enable wireless accesspoint"
            end
            ]]--
            if (jioPrivateNetSupport == "1" and (util.fileExists ("/pfrm2.0/JIO_PRIVATE_NET"))) then
                wlProfiles["dot11Profile.ssid"] = "JioPrivateNet"
            else		
                wlProfiles["dot11Profile.ssid"] = "Jionet"
            end
            wlProfiles["dot11Profile.profileName"] = dot11profileTbl["profileName"]
            wlProfiles["dot11Profile.broadcastSSID"] = 1
            if(jioPrivateNetSupport == "1")then
                wlProfiles["dot11Profile.security"] = "WPA2"
                wlProfiles["dot11Profile.authMethods"] = "RADIUS"
                wlProfiles["dot11Profile.pairwiseCiphers"] = "CCMP"
            else
                wlProfiles["dot11Profile.security"] = "OPEN"
            end
            wlProfiles["dot11Profile.eogre"] = "1"
            wlProfiles["_ROWID_"] = dot11profileTbl["_ROWID_"]

            local errorFlag, statusCode = gui.wireless.profileInfoeogre.set (wlProfiles, "edit", dbFlag)
            if (errorFlag == "ERROR")then
                return "ERROR", "Failed to edit wireless profile for"..profilename
            end
            --some products support only a single radio.Putting product specific check 
            if((not(util.fileExists("/pfrm2.0/HW_JCO110"))) and (not(util.fileExists("/pfrm2.0/HW_HG260ES"))) and (not(util.fileExists("/pfrm2.0/HW_ALU"))))then
                --ap5 eogre settings
                local wlProfiles5 = {}
                local accesspoint5
                if(jioPrivateNetSupport == "1")then
                    accesspoint5 = "ap6"
                else
                    accesspoint5 = "ap5"
                end
                local query5 = "vapName= '" .. accesspoint5 .. "'"
                local dot11vapTbl5 = db.getRowWhere ("dot11VAP",query5, false)
                if (dot11vapTbl5 == nil) then
                    return "ERROR", "DB_ERROR_TRY_AGAIN"
                end

                local profilename5 = dot11vapTbl5["profileName"]
                query5 = "profileName= '" .. profilename5 .. "'"
                local dot11profileTbl5 = db.getRowWhere ("dot11Profile",query5, false)
                if (dot11profileTbl5 == nil) then
                    return "ERROR", "DB_ERROR_TRY_AGAIN"
                end

                local inputTable5 = {}
                inputTable5["_ROWID_"] = dot11vapTbl5["_ROWID_"]
                inputTable5["dot11VAP.maxClients"] = dot11vapTbl5["maxClients"]
                inputTable5["dot11VAP.apIsolation"] = 1
                inputTable5["dot11VAP.profileName"] = dot11vapTbl5["profileName"]
                inputTable5["dot11VAP.vapName"] = dot11vapTbl5["vapName"]
                inputTable5["dot11VAP.vapEnabled"] = "1"
                inputTable5["dot11VAP.eogreCall"] = "1"
                if(jioPrivateNetSupport == "1")then
                    inputTable5["dot11VAP.defaultSubnet"] = "2"
                else
                    inputTable5["dot11VAP.defaultSubnet"] = "1"
                end
                errorFlag, statusCode = gui.wireless.apProfileInfo.edit.set (inputTable5, "edit", dbFlag)
                if (errorFlag == "ERROR")then
                    return "ERROR", "Failed to edit wireless accesspoint "..accesspoint5
                end
                --[[
                local rows5 = {}
                rows5["1"] = dot11vapTbl5["_ROWID_"]
                errorFlag, statusCode = gui.wireless.apProfileInfo.status(rows5,"enable",dbFlag)
                if (errorFlag == "ERROR")then
                    return "ERROR", "Failed to enable wireless accesspoint"
                end
                ]]--
                if (jioPrivateNetSupport == "1" and (util.fileExists ("/pfrm2.0/JIO_PRIVATE_NET"))) then
                    wlProfiles5["dot11Profile.ssid"] = "JioPrivateNet"
                else		
                    wlProfiles5["dot11Profile.ssid"] = "Jionet"
                end
                wlProfiles5["dot11Profile.profileName"] = dot11profileTbl5["profileName"]
                wlProfiles5["dot11Profile.broadcastSSID"] = 1
                if(jioPrivateNetSupport == "1")then
                    wlProfiles5["dot11Profile.security"] = "WPA2"
                    wlProfiles5["dot11Profile.authMethods"] = "RADIUS"
                    wlProfiles5["dot11Profile.pairwiseCiphers"] = "CCMP"
                else
                    wlProfiles5["dot11Profile.security"] = "OPEN"
                end
                wlProfiles5["dot11Profile.eogre"] = "1"
                wlProfiles5["_ROWID_"] = dot11profileTbl5["_ROWID_"]

                local errorFlag, statusCode = gui.wireless.profileInfoeogre.set (wlProfiles5, "edit", dbFlag)
                if (errorFlag == "ERROR")then
                    return "ERROR", "Failed to edit wireless profile for"..profilename5
                end
            end
        end --product specific check
    end

    if (((tonumber(eogreTmp["Enable"])== 0) and (tonumber(eogreTmp["ModeOfOperation"])== 1)) or ((tonumber(eogreOldRow["Enable"])== 1 or tonumber(eogreOldRow["secEnable"])== 1) and (tonumber(eogreOldRow["ModeOfOperation"])== 1) and (tonumber(eogreTmp["Enable"])== 1) and (tonumber(eogreTmp["ModeOfOperation"])== 2)))then
        local passwrd
        local fname = "/tmp/randPassword"
        if (util.fileExists (fname)) then
            local pfile = io.open(fname,"r")
            passwrd = pfile:read("*line")
            pfile:close()
        else
            return "ERROR", "Failed to get pskPassAscii"
        end

        -- edit ap2 eogre settings
        local wlProfile = {}
        local accesspoint
        if(jioPrivateNetSupport == "1")then
            accesspoint = "ap3"
            --[[
            eogreWanRow = db.getRow ("gpon","_ROWID_","2")
            eogreWanRow["gpon.status"] = "0"
            --eogreWanRow["gpon.vlanStatus"] = "1"
            local valid = gpon.eogreWanconfigure(eogreWanRow, "2", "edit")
            if(not(valid))then
                return "ERROR", "Enable WAN on Eogre Failed"
            end
            ]]--
            local valid = db.setAttribute ("NimfConf", "LogicalIfName","IF10","Enable","0")
            if(not(valid))then
                return "ERROR", "Enable NimfConf Failed"
            end
            local valid = db.setAttribute ("networkInterface", "LogicalIfName","IF10","enable","0")
            if(not(valid))then
                return "ERROR", "Enable networkInterface Failed"
            end
        else
            accesspoint = "ap2"
        end
        local query = "vapName= '" .. accesspoint .. "'"
 
        local dot11vapTbl = db.getRowWhere ("dot11VAP",query, false)
        if (dot11vapTbl == nil) then
            return "ERROR", "DB_ERROR_TRY_AGAIN"
        end

        local profilename = dot11vapTbl["profileName"]
        query = "profileName= '" .. profilename .. "'"
        local dot11profileTbll = db.getRowWhere ("dot11Profile",query, false)
        if (dot11profileTbll == nil) then
            return "ERROR", "DB_ERROR_TRY_AGAIN"
        end

        local dot11profileTbl = db.getRowWhere ("dot11ProfileDef",query, false)
        if (dot11profileTbl == nil) then
            return "ERROR", "DB_ERROR_TRY_AGAIN"
        end

        if(jioPrivateNetSupport == "1" and dot11profileTbl["ssid"] == "Jio_2")then
            wlProfile["dot11Profile.ssid"] = "Jio_3"
        else
            wlProfile["dot11Profile.ssid"] = dot11profileTbl["ssid"]
        end
        if(jioPrivateNetSupport == "1" and dot11profileTbl["profileName"] == "Jio_2")then
            wlProfile["dot11Profile.profileName"] = "Jio_3"
        else
            wlProfile["dot11Profile.profileName"] =  dot11profileTbl["profileName"]
        end
        wlProfile["dot11Profile.broadcastSSID"] =  dot11profileTbl["broadcastSSID"]
        wlProfile["dot11Profile.security"] = dot11profileTbl["security"]
        wlProfile["_ROWID_"] = dot11profileTbll["_ROWID_"]
        wlProfile["dot11Profile.authMethods"] = dot11profileTbl["authMethods"]
        wlProfile["dot11Profile.pairwiseCiphers"] = dot11profileTbl["pairwiseCiphers"]
        wlProfile["dot11Profile.pskPassAscii"] = passwrd
        wlProfile["dot11Profile.eogre"] = "1"

        local errorFlag, statusCode = gui.wireless.profileInfoeogre.set (wlProfile, "edit", dbFlag)
        if (errorFlag == "ERROR")then
            return "ERROR", "Failed to edit wireless profile for "..profilename
        end

        local inputTable = {}
        inputTable["_ROWID_"] = dot11vapTbl["_ROWID_"]
        inputTable["dot11VAP.maxClients"] = dot11vapTbl["maxClients"]
        inputTable["dot11VAP.apIsolation"] = 0
        inputTable["dot11VAP.profileName"] = dot11vapTbl["profileName"]
        inputTable["dot11VAP.vapName"] = dot11vapTbl["vapName"]
        inputTable["dot11VAP.defaultSubnet"] = "0"
        inputTable["dot11VAP.vapEnabled"] = "0"
        inputTable["dot11VAP.eogreCall"] = "1"

        errorFlag, statusCode = gui.wireless.apProfileInfo.edit.set (inputTable, "edit", dbFlag)
        if (errorFlag == "ERROR")then
            return "ERROR", "Failed to edit wireless accesspoint "..accesspoint
        end
        --[[
        local rows = {}
        rows["1"] = dot11vapTbl["_ROWID_"]
        errorFlag, statusCode = gui.wireless.apProfileInfo.status(rows,"disable", dbFlag)
        if (errorFlag == "ERROR")then
            return "ERROR", "Failed to disable wireless accesspoint"
        end
        ]]--    
        --some products support only a single radio.Putting product specific check 
        if((not(util.fileExists("/pfrm2.0/HW_JCO110"))) and (not(util.fileExists("/pfrm2.0/HW_HG260ES"))) and (not(util.fileExists("/pfrm2.0/HW_ALU"))))then
            -- edit ap5 eogre settings
            local wlProfile5 = {}
            local accesspoint5
            if(jioPrivateNetSupport == "1")then
                accesspoint5 = "ap6"
            else
                accesspoint5 = "ap5"
            end
            local query5 = "vapName= '" .. accesspoint5 .. "'"
            local dot11vapTbl5 = db.getRowWhere ("dot11VAP",query5, false)
            if (dot11vapTbl5 == nil) then
                return "ERROR", "DB_ERROR_TRY_AGAIN"
            end

            local profilename5 = dot11vapTbl5["profileName"]
            query5 = "profileName= '" .. profilename5 .. "'"
            local dot11profileTbll5 = db.getRowWhere ("dot11Profile",query5, false)
            if (dot11profileTbll5 == nil) then
                return "ERROR", "DB_ERROR_TRY_AGAIN"
            end

            if(jioPrivateNetSupport == "1" and dot11profileTbl["ssid"] == "Jio_2")then
                wlProfile5["dot11Profile.ssid"] = "Jio_3"
            else
                wlProfile5["dot11Profile.ssid"] = dot11profileTbl["ssid"]
            end
            if(jioPrivateNetSupport == "1" and dot11profileTbll5["profileName"] == "Jio_5")then
                wlProfile5["dot11Profile.profileName"] =  "Jio_6"
            else
                wlProfile5["dot11Profile.profileName"] =  dot11profileTbll5["profileName"]
            end
            wlProfile5["dot11Profile.broadcastSSID"] =  dot11profileTbl["broadcastSSID"]
            wlProfile5["dot11Profile.security"] = dot11profileTbl["security"]
            wlProfile5["_ROWID_"] = dot11profileTbll5["_ROWID_"]
            wlProfile5["dot11Profile.authMethods"] = dot11profileTbl["authMethods"]
            wlProfile5["dot11Profile.pairwiseCiphers"] = dot11profileTbl["pairwiseCiphers"]
            wlProfile5["dot11Profile.pskPassAscii"] = passwrd
            wlProfile5["dot11Profile.eogre"] = "1"

            local errorFlag, statusCode = gui.wireless.profileInfoeogre.set (wlProfile5, "edit", dbFlag)
            if (errorFlag == "ERROR")then
                return "ERROR", "Failed to edit wireless profile for "..profilename5
            end

            local inputTable5 = {}
            inputTable5["_ROWID_"] = dot11vapTbl5["_ROWID_"]
            inputTable5["dot11VAP.maxClients"] = dot11vapTbl5["maxClients"]
            inputTable5["dot11VAP.apIsolation"] = 0
            inputTable5["dot11VAP.profileName"] = dot11vapTbl5["profileName"]
            inputTable5["dot11VAP.vapName"] = dot11vapTbl5["vapName"]
            inputTable5["dot11VAP.defaultSubnet"] = "0"
            inputTable5["dot11VAP.vapEnabled"] = "0"
            inputTable5["dot11VAP.eogreCall"] = "1"

            errorFlag, statusCode = gui.wireless.apProfileInfo.edit.set (inputTable5, "edit", dbFlag)
            if (errorFlag == "ERROR")then
                return "ERROR", "Failed to edit wireless accesspoint "..accesspoint5
            end
            --[[
            local rows5 = {}
            rows5["1"] = dot11vapTbl5["_ROWID_"]
            errorFlag, statusCode = gui.wireless.apProfileInfo.status(rows5,"disable", dbFlag)
            if (errorFlag == "ERROR")then
                return "ERROR", "Failed to disable wireless accesspoint"
            end
            ]]--
        end --product specific check
    end

    -- save settings
    status, errCode = firewall.eogreSet (eogreTmp)
    if (status ~= "OK") then
        gui.dprintf ("ipv4.set: eogre configuration failed:" .. errCode)
        return status, errCode
    end
    
    --return
    return "OK", "STATUS_OK"

end
-------------------------------------------------------------------------
-- @name gui.networking.network.eogre.get
--
-- @descrription This routine configures eogre for this network
--
-- @param name network name
-- @param conf
--
-- @return status
-- @return errCode
--
function gui.networking.network.eogre.get ()

    local eogreTmp = {}
    local query = "_ROWID_=1"

    eogreTmp = firewall.eogreGet(query)

    if ( tonumber(eogreTmp["vlanId"]) == 0 ) then
        eogreTmp["vlanId"] = ''
    end
    if ( tonumber(eogreTmp["dataRate"]) == 0 ) then
        eogreTmp["dataRate"] = ''
    end
    if ( eogreTmp["TunnelKey"] == "NOKEY" ) then
        eogreTmp ["TunnelKey"] = ''
    end

    if(tonumber(eogreTmp["Enable"]) == 1 or tonumber(eogreTmp["secEnable"]) == 1 ) then                             
    	eogreTmp ["Enable"] = "1"                    
    end

    eogreTmp ["TunnelKey"] = util.filterXSSChars (eogreTmp["TunnelKey"])
    eogreTmp ["RemoteIP"] = util.filterXSSChars (eogreTmp["RemoteIP"])
    eogreTmp ["RemoteIP6"] = util.filterXSSChars (eogreTmp["RemoteIP6"])
    eogreTmp ["vlanId"] = util.filterXSSChars (eogreTmp["vlanId"])
    eogreTmp ["dataRate"] = util.filterXSSChars (eogreTmp["dataRate"])
    eogreTmp ["secRemoteIP"] = util.filterXSSChars (eogreTmp["secRemoteIP"])
    eogreTmp ["secRemoteIP6"] = util.filterXSSChars (eogreTmp["secRemoteIP6"])

    return "OK", "STATUS_OK", eogreTmp
end
