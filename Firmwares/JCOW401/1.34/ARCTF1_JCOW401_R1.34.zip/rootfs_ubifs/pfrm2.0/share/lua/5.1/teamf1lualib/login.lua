--[[
#### Adarsh Uppula
#### TeamF1
#### www.TeamF1.com
#### June 29, 2007

####Copyright (c) 2014, TeamF1 Networks Pvt. Ltd.
####(Subsidiary of D-Link India)

####modification history
####--------------------
####01a,06dec14,mmk  Added logs related to icsa support.

#### File: login.lua
#### Description: Login functions.

#### Revisions:
None
--
-- modification history
-- --------------------
-- 01e, 16Jan18, ar Fixed SPR#62553
-- 01d, 02Mar15, vik Added check for deleting cookieVal mapping
-- 01c, 07feb15, vik Added check for CSRF attack (SPR#49220)
-- 01b, 16oct13, ash changes for logging login events
-- 01a, 16jul13, ash changes for external authentication
--
]]--


--************* Requires *************

require "teamf1lualib/db"
require "loginLib"
require "timeLib"
pcall (require , "captivePortalLib")

--************* Initial Code *************

--package login
login = {}

-- path for cookie and referer Ip Address
local REFERER_PATH = "/tmp/referer/"
local REMOVE = os.remove
--************* Functions *************

--Authenticate with given account data and account table.
--Returns true if account with matching info exists, else false.
function login.authenticate (tablename, tableInput)
	local username = tableInput["users.username"]
	local password = tableInput["users.password"]
	
	--Escape user input strings to avoid Sql Injections effect
	username = db.escape(username) 
	password = db.escape(password) 
    ipaddr = SAPI.Request.servervariable("REMOTE_ADDR")
    ipaddr = string.gsub (ipaddr, "(%a*:)", "")
	-- encrypt password
	local encryptedPassword = loginLib.encryptPassword(password)
	

    	-- query
        local query = "username = '" .. username .. "' and enableAccess= '1'" 
    	local usrRow =  db.existsRowWhere (tablename, query)
   
	--- check for rows
	local result = false
    	local statusCode = "NONE"

    if(usrRow) then
            if (loginLib.userExists(username,encryptedPassword) == "0") then
if (UNIT_INFO ~= "ODU") then
                loginLib.logLoginEvent (1,username,ipaddr)
end
        	    statusCode = "LOGIN_INVALID_PASSWORD"
			    result = false
		    else
			-- query
    			local cur = db.execute(string.format([[
                		SELECT *, ROWID AS _ROWID_ FROM %s
				WHERE %s = '%s' AND %s = '%s'
				]], tablename, "username", username, "password", encryptedPassword))

            		local row = cur:fetch ({}, "a")
		    	cur:close()
			    for k,v in pairs(row) do
				    -- The user must belong to either admin or
				    -- guest group inorder to access the web 
				    -- management interface.
            	    		if ((k == "groupname") and
                	    	((string.find(v,"admin",1,true) ~= nil) or
                	    	(string.find(v,"mesh",1,true) ~= nil) or
	                    	(string.find(v,"guest",1,true) ~= nil))) then
	                    	result = true
    	            		end
	            	    end
			 if (result == false) then
if (UNIT_INFO ~= "ODU") then
                 loginLib.logLoginEvent (2,username,ipaddr)
end
        		 statusCode = "LOGIN_PERMISSION_DENIED"
			 end
            end
    else
        if (UNIT_INFO ~= "ODU") then
            -- user does not exist in local database
            -- so check for radius external authentication for the user.
--            local authType = db.getAttribute ("radiusClient", "_ROWID_", "1", "authType")
		local authType = nil
            if (authType ~= nil) then
                local ret, timeOut, sessionTimeOut = captivePortalLib.authenticate (username, password, authType)
                if(ret == 0) then
                    result = true
                else
if (UNIT_INFO ~= "ODU") then
                    loginLib.logLoginEvent (2,username,ipaddr)
end
                    statusCode = "LOGIN_INVALID_CREDENTIALS"
                end
            else
if (UNIT_INFO ~= "ODU") then
                loginLib.logLoginEvent (3,username,ipaddr)
end
                statusCode = "LOGIN_INVALID_CREDENTIALS"
            end
        else
if (UNIT_INFO ~= "ODU") then
            loginLib.logLoginEvent (2,username,ipaddr)
end
            statusCode = "LOGIN_INVALID_CREDENTIALS"
        end
    end
    
    if (result == false) then
        local ipAddr = SAPI.Request.servervariable("REMOTE_ADDR")
        ipAddr = string.gsub (ipAddr, "(%a*:)", "")

        if (UNIT_INFO ~= "ODU") then
            local macAddr = captivePortalLib.macAddrGet(ipAddr)
        end
   
        if (macAddr ~= "0") then
            login.Log (macAddr, "login failed")
        end
    end

	return result, statusCode
end

function login.IsUserGroupMember (username, group)
	local groupList = db.getAttribute("users", "username", username, "groupname")
    if (groupList ~= nil) then
	    if (string.find(groupList, group,1,true) ~= nil) then
		    return true
	    end
        return false
    else
        -- setting external user as Admin
        return true
    end
end

--Get logged-in user.
--Returns user LoginSession row if exists, else nil.
function login.getUserLogin (givenusername)
	-- find username in logged-in users
    --allow forced login only for userType "admin"
    local userType = db.getAttribute("users", "username", givenusername, "groupname") or ''
	for k,v in pairs(db.getTable("loginSession")) do
		if ((v["loginSession.username"] == givenusername) and (v["loginSession.loginState"] == "LOGGED_IN") and (userType == "admin")) then
			return v
		end
	end
	return nil
end

-- Revalidate current login before proceeding.
-- Returns 0 if login ok, 1 if no cookie
-- 2 if cookie but no session, 3 if cookie but
-- expired session, and 4 if only authenticated, not logged in.
function login.revalidate (cookieVal, ipaddr)
	-- if no cookie, go to login page
	if (cookieVal == nil) then
		util.appendDebugOut("PLEASE LOGIN - NOT LOGGED IN YET! - no cookie<br>")
		return "NO_COOKIE"
	else
		cookieVal = db.escape(cookieVal)

        -- validate the cookie
        local valid = util.cookieValidate (cookieVal) 
        if (valid == 1) then
            return "NO_COOKIE"
        end

		local wherePart = "ipaddr = '" .. ipaddr .. "' AND cookie = '" .. cookieVal .. "'"
		local row = db.getRowWhere("loginSession", wherePart)
        local status,upTime = timeLib.uptime()
        local userInfo = nil
        if (row ~= nil) then
            userInfo = db.getRow ("users", "username", row["loginSession.username"])
        end

        -- external Authentication user
        if (row ~= nil and userInfo == nil) then
            userInfo = {}
            userInfo["users.loginTimeout"] = 30
        end

		-- if no matching session
		if (row == nil) then
			util.appendDebugOut("PLEASE RELOGIN - LOGIN EXPIRED! - someone else killed your expired session<br>")
			--statusMessage = db.getAttribute("stringsMap", "stringId", "LOGIN_SESSION_EXPIRED", LANGUAGE)
			return "NO_SESSION"
		-- if disconnected, not logged in
		elseif (row["loginSession.loginState"] == "DISCONNECTED" or userInfo == nil) then
			util.appendDebugOut("YOU ARE DISCONNECTED!<br>")
			statusMessage = db.getAttribute("stringsMap", "stringId", "LOGIN_SESSION_TERMINATED", LANGUAGE)
		--	statusMessage = statusMessage .. " Terminator: " .. row["loginSession.loginMessage"]
			return "DISCONNECTED"
		-- if authenticated, not logged in
		elseif (row["loginSession.loginState"] == "AUTHENTICATED") then
			util.appendDebugOut("YOU ARE AUTHENTICATED!<br>")
			return "AUTHENTICATED"
		-- if expired login
		elseif (tonumber(userInfo["users.loginTimeout"]) * 60 < (upTime - tonumber(row["loginSession.lastAccessTime"]))) then
			-- delete session
			local tempTable = {}
			tempTable["redirectPageInfo.username"] = row["loginSession.username"]
			tempTable["redirectPageInfo.ipaddress"] = row["loginSession.ipaddr"]
			tempTable["redirectPageInfo.redirectpage"] = Page
			db.insert("redirectPageInfo", tempTable)
			util.appendDebugOut("*******  User name and Ip address values Inserted in the Table  *******<br>")
			local errMsg, delStatus = db.deleteRowWhere("loginSession", wherePart)
            -- if the cookieVal is found in db then only delete the mapping
            if (errMsg == 1) then
                -- remove the mapping
                REMOVE(REFERER_PATH .. cookieVal)
            end
			util.appendDebugOut("PLEASE RELOGIN - LOGIN EXPIRED! - you waited too long<br>")
			statusMessage = db.getAttribute("stringsMap", "stringId", "LOGIN_SESSION_EXPIRED", LANGUAGE)
            local loginTimeout = db.getAttribute("users", "username", row["loginSession.username"], "loginTimeout") or ''
            if (loginTimeout ~= nil and loginTimeout ~= "") then
                statusMessage = string.gsub(statusMessage, "30", loginTimeout)
            end
			return "EXPIRED_SESSION"
		-- logged in, so reset time
		else
			util.appendDebugOut("YOU ARE ALREADY LOGGED IN!<br>")
			db.setAttributeWhere("loginSession", wherePart, "lastAccessTime", upTime)
			-- set access level
			if (login.IsUserGroupMember(row["loginSession.username"], "admin") == true) then
				ACCESS_LEVEL = 0
                        elseif (login.IsUserGroupMember(row["loginSession.username"], "mesh") == true) then
				ACCESS_LEVEL = 3
			else
				ACCESS_LEVEL = 1
			end
			return "OK"
		end
	end
end

-- Log in user. Creates entry in Referrer.
function creatRefEntry (uniqueVal)

    -- check referer Url and extract the IP Address    
    local refererVal = os.getenv("HTTP_REFERER")
    local ipAddr2 = {}
    if (refererVal == nil) then
			    pageToGoTo = ERROR_PAGE
        elseif (refererVal~=nil) then
            
            --compare cookies and referer
            local splitRefVal = util.split(refererVal,"//" )
            if (splitRefVal~=false) then
                if (splitRefVal[2]~=nil) then
                    local networkName = util.split(splitRefVal[2],"/" )
					-- Check if port is present in URL , this is the case when doing remote mgmt with custom ports
				     local index = string.find(networkName[1],'%]')
                     -- Check if port is present in URL , this is the case when doing remote mgmt with custom ports
                     -- if the given address is IPv4 
                     if( index == nil) then  
                         -- We got IPv4 address in referer value
                         portPresent = string.find (networkName[1] , ":")
	                     if (portPresent ~= nil and portPresent > 0 ) then 
    	                     ipAddr2 = 	util.split(networkName[1],":")
	 	                 else
	    	                 ipAddr2 = networkName
		                 end
		             else
		                  -- We got ipv6 address in referer value
                		  portPresent = string.find(networkName[1],':', index)
                    		if (portPresent ~= nil and portPresent > 0 ) then 
                        		ipAddr2 = 	util.split(networkName[1],"]")
                        		else
                            		ipAddr2 = networkName
                          		end
                       	end
                end
            end
        end
            local ipAddr  = string.gsub (ipAddr2[1],'%[','')
            local ipAddr1  = string.gsub (ipAddr,'%]','')

            -- create referer file
            local file = io.open(REFERER_PATH .. uniqueVal, "w")
            file:write(ipAddr1)
            file:close()
 end

function login.deleteMeshAppSession(loginUserNameStr)

    require "easyMeshLib"

    -- LOGOUT the user's existing EasyMesh session if any.
    local query = "username='" .. loginUserNameStr .. "'"
    local usrRow =  db.getRowWhere ("users", query, true)
    if (usrRow == nil) then
        mesh.dprintf("User does not Exists; Unable to get User Details")
        return "OK", "SUCCESS"
    end

    -- Send Login Request details for easyMesh store.
    easyMeshLib.SessionLogout(loginUserNameStr, usrRow["users.groupname"])
    return
end


-- Log in user. Creates session.
function login.login (givenusername, uniqueVal, ipaddr)

    if(util.fileExists(("/pfrm2.0/MESH_ENABLED")) or (util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED"))) then
        require "easyMeshLib"
    end
	-- initially set access level as guest
	ACCESS_LEVEL = 1

	-- clean up expired
	login.cleanUpExpired()
	
	local loginState = "LOGGED_IN" --default
	local returnVal = 0 --default
	local returnRow = nil
    	local statusCode = "NONE"

	-- check if user has already logged in
	local userRow = login.getUserLogin(givenusername)
	if (userRow) then
		-- user has already logged in.
		-- create a new session for this user and mark as "AUTHENTICATED"
		-- This user will be provided an option to
		-- forcefully logout the other user who is already logged in.
		loginState = "AUTHENTICATED"
		returnVal = 1
		returnRow = userRow
         	statusCode = "LOGIN_USER_ALREADY_LOGGED_IN"
	end
    ---Mesh APPP
    if(util.fileExists(("/pfrm2.0/MESH_ENABLED")) or (util.fileExists("/pfrm2.0/BRCM_MESH_ENABLED"))) then
        local query = "username='" .. givenusername .. "'"
        local usrRow =  db.getRowWhere ("users", query, true)
        
        local status=easyMeshLib.SessionExists( 
                            givenusername, 
                            usrRow["users.groupname"]
                          )
        if(status == 2) then
            local meshUserRow = {}
            meshUserRow["loginSession.username"] = givenusername
		    loginState = "AUTHENTICATED"
		    returnVal = 1
		    returnRow = meshUserRow
         	statusCode = "LOGIN_USER_ALREADY_LOGGED_IN"
        end
    end

	-- upgrade access level to admin
    if (login.verifyUserType (givenusername, "3") or (not login.verifyUserType (givenusername, "4"))) then
        local wherePart = " capabilities = '3'"
        local adminGrp = db.getRowsWhere("groups", wherePart)
        for k,v in pairs (adminGrp) do
            local query = " groupname = '" .. v["groups.name"] .. "'"
            local adminRow = db.getRowsWhere("users", query)
            for kk, vv in pairs (adminRow) do
                if (vv["users.username"] ~= givenusername) then
                    db.setAttribute("loginSession", "username", vv["users.username"], "loginState", "DISCONNECTED")
			    end
            end
        end

        -- any external user is logged in then disconnect session
        login.extUserSessionDisconnect ()

		ACCESS_LEVEL = 0
    end

    if (login.verifyUserType (givenusername, "10") and givenusername == "meshadmin")  then
		ACCESS_LEVEL = 3
    end 
	-- set session
    local status,upTime = timeLib.uptime()
	local tempTable = {}
	tempTable["loginSession.username"] = givenusername
	tempTable["loginSession.ipaddr"] = ipaddr
	tempTable["loginSession.cookie"] = uniqueVal
	tempTable["loginSession.loginTime"] = upTime
	tempTable["loginSession.lastAccessTime"] = upTime
	tempTable["loginSession.loginState"] = loginState
if (UNIT_INFO ~= "ODU") then
    if (loginState == "LOGGED_IN") then
        local ipaddrtmp = string.gsub (ipaddr, "(%a*:)", "")
            loginLib.logLoginEvent (4, givenusername,ipaddrtmp);
    end
end
	local wherePart = "ipaddr = '" .. ipaddr .. "' AND cookie = '" .. uniqueVal .. "'"
	local oldRow = db.existsRowWhere("loginSession", wherePart)
	if (oldRow) then
		db.update("loginSession", tempTable, oldRow)
        -- create the referer entry
        creatRefEntry (uniqueVal)
	else
		db.insert("loginSession", tempTable)
        -- create the referer entry
        creatRefEntry (uniqueVal)
	end

    --log the event
    local ipAddr = string.gsub (ipaddr, "(%a*:)", "")
	local macAddr = 0
	if (UNIT_INFO ~= "ODU") then
    	macAddr = captivePortalLib.macAddrGet(ipAddr)
	end
   
    if (macAddr ~= "0") then
        login.Log (macAddr, "logged in")
    end

	return returnVal, returnRow, statusCode -- success
end

-- Log out current user. Deletes session.
function login.logout (cookieVal, ipaddr)
	if (cookieVal ~= nil) then
		cookieVal = db.escape(cookieVal)
      
        -- validate the cookie
        local valid = util.cookieValidate (cookieVal) 
        if (valid == 1) then
            return 1
        end

		local wherePart = "ipaddr = '" .. ipaddr .. "' AND cookie = '" .. cookieVal .. "'"
		-- delete session
        local errMsg, status = db.deleteRowWhere("loginSession", wherePart)
        -- if the cookieVal is found in db then only delete the mapping
        if (errMsg == 1) then
            -- remove the mapping
            REMOVE(REFERER_PATH .. cookieVal)
        end

        local ipAddr = string.gsub (ipaddr, "(%a*:)", "")
		local macAddr = 0
		if (UNIT_INFO ~= "ODU") then
    		macAddr = captivePortalLib.macAddrGet(ipAddr)
		end
    
        if (macAddr ~= "0") then
            login.Log (macAddr, "logged out")
        end

		return 0 --success
	else
		return 1
	end
end
		
-- Clean up expired users from session table.
function login.cleanUpExpired ()
	local timeOut = 0
	local lastAccessTime = 0
	local upTime = 0
	
	local sesTable = db.getTable("loginSession")

	-- loop and delete
	for k,v in pairs(sesTable) do
		local rowid = v["loginSession._ROWID_"]
		local cookieVal = v["loginSession.cookie"]
		local row = db.getRow("users", "username", v["loginSession.username"])

		if (row ~= nil) then
			local timeOut = tonumber(row["users.loginTimeout"]) * 60 --in seconds
			local lastAccessTime = tonumber(v["loginSession.lastAccessTime"])
            local ipAddr = string.gsub (v["loginSession.ipaddr"], "(%a*:)", "")
			local macAddr = 0
			if (UNIT_INFO ~= "ODU") then
    			macAddr =  captivePortalLib.macAddrGet(ipAddr)
			end
			
            -- expired
			local status, upTime = timeLib.uptime()
			if (lastAccessTime < (upTime - timeOut)) then
				local errMsg, delStatus = db.deleteRow("loginSession", "_ROWID_", rowid)
                -- if the cookieVal is found in db then only delete the mapping
                if (errMsg == 1) then
                    -- remove the mapping
                    REMOVE(REFERER_PATH .. cookieVal)
                end
                if (macAddr ~= "0") then
                    login.Log (macAddr, "logged out")
                end
			end
         -- commented this as this is remove session entry for external users..
         --[[   
		else
			db.deleteRow("loginSession", "_ROWID_", rowid)
            ]]--
		end
	end
end

--[[
******************************************************************** 
* login.verifyUserType -  verify if user is of a particular userType
* 
* RETURNS: true or false 
*
 --]]
function login.verifyUserType (userName, userType)
    local groupname = db.getAttribute ("users","username", userName, "groupname")
    if (groupname ~= nil) then
        local row = db.getRow("groups","name",groupname)
        if (row ~= nil) then
            local table = util.split (row["groups.capabilities"],",")
            for k,v in pairs (table) do
                if (v == userType) then
                    -- User has privileges for this usertype
                    return true
                end
            end
        end
    else
        return false
    end
end

--[[
******************************************************************** 
* login.extUserSessionDisconnect -  disconnect external user's session
* 
* RETURNS: true or false 
*
 --]]
function login.extUserSessionDisconnect ()

    local loggedInUser = db.getTable ("loginSession", false)
    if (loggedInUser ~= nil) then
        for k,v in pairs (loggedInUser) do
            if ((not login.verifyUserType (v["username"], "3")) and (not login.verifyUserType (v["username"], "4"))) then
                db.setAttribute("loginSession", "username", v["username"], "loginState", "DISCONNECTED")
            end
        end
    end
end

-------------------------------------------------------------------------------
-- @name : login.ssidGet()
--
-- @description : Get ssid from which wireless client is connected 
-- 
-- @return : status
--
function login.ssidGet(mac)
    local status = "ERROR"
    local query = nil
    local ifRow = {}
    local apRow = {}
    local profileRow = {}

    if (mac == nil) then
        return "ERROR", "INVALID_MAC_ADDR"
    end

    -- getting interface name
    query = "macAddress= '" .. mac .. "'"
    ifRow = db.getRowWhere ("dot11STA", query, false)
    if (ifRow == nil) then
        return "ERROR", "IF_NOT_EXIST"
    end

    local ifName = ifRow["interfaceName"]
    
    --getting ap name
    query = "interfaceName= '" .. ifName .. "'"
    apRow = db.getRowWhere ("dot11Interface", query, false)
    if (apRow == nil) then
        return "ERROR", "AP_NOT_EXIST"
    end

    local apName = apRow["vapName"]

    -- getting profile name
    query = "vapName= '" .. apName .. "'"
    profileRow = db.getRowWhere ("dot11vap", query, false)
    if (profileRow == nil) then
        return "ERROR", "PROFILE_NOT_EXIST"
    end

    local profileName = profileRow["profileName"]

    -- getting ssid name
    query = "profileName= '" .. profileName .. "'"
    ssidRow = db.getRowWhere ("dot11profile", query, false)
    if (ssidRow == nil) then
        return "ERROR", "SSID_NOT_EXIST"
    end

    local ssidName = ssidRow["ssid"]
    return "OK", ssidName
end

-------------------------------------------------------------------------------
-- @name : login.Log()
--
-- @description : Log the lan client events
-- 
-- @return : status
--
function login.Log(mac, message)

    local status = "ERROR"
    local ssid = nil
    local logStr = nil

    if (mac == nil) then
        return "ERROR", "INVALID_MAC"
    end
    
    logStr = "Lan client with mac = ".. mac ..""
    --get ssid for wireless client

    -- ODU dont have any wireless clients
    if (UNIT_INFO ~= "ODU" ) then
        status, ssid = login.ssidGet(mac)
        if (status == "OK") then
            logStr = logStr .. " connected to ssid = " .. ssid .. ""
        end
    end

    logStr = logStr .. " " .. message
    stat = loginLib.log (logStr)
    return stat
end
