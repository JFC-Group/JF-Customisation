--[[
#### Hussain Vali.
#### TeamF1
#### www.TeamF1.com
#### Feb 06, 2008
#### Copyright (c) 2017, TeamF1 Networks Pvt. Ltd.
#### (Subsidiary of D-Link India)

#### File: upnp.lua
#### Description: upnp functions

#### Revisions:
01d,11Sep17,ash  Fix for SPR#59195
01c,15dec11,adk  adding the routine to get table upnpPortMap
01b,26aug10,pnm  adding import/export routines
None
]]--


--************* Requires *************

--************* Initial Code *************
--package upnp
upnp = {}
--************* Functions *************
-- upnp config
function upnp.config (inputTable, rowid, operation)
        -- if not allowed to edit
        if (ACCESS_LEVEL ~= 0) then
                return "ACCESS_DENIED", "ADMIN_REQD"
        end
        db.beginTransaction() --begin transaction
        local valid = false

        -- validate
        if (db.typeAndRangeValidate(inputTable)) then
                if (operation == "add") then
                        return nil
                elseif (operation == "edit") then
                        valid = db.update(DBTable,inputTable,rowid)
                elseif (operation == "delete") then
                        return nil
                end
        end

        -- return
        if (valid) then
                db.commitTransaction()
                return "OK", "Operation Succeeded"
        else
                db.rollback()
                return "ERROR", "Configuration Update Failed"
        end
end


--****************************************************************************
	--Function to get the table upnpPortMap
--****************************************************************************
--@name  upnp.openPortsGet2()
--
--@description The function get the table upnpPortMap from the database 
--
--@return

function upnp.openPortsGet2()
	
	--locals
	local localTbl = {}	--local table contaning the table upnpPortMap
	local upnpTbl = {}	--local table contaning the fields to be passed
	local upnpTable = {}
    local portTbl = {}

    local DB_FILE_NAME = "/tmp/system.db"
    local prog = db.getAttribute("environment", "name", "UPNP_REFRESH_PROGRAM", "value");
    util.shellCmdOutput(prog .. " " .. DB_FILE_NAME)

	--get the table upnpPortMap
	upnpTbl = db.getTable("upnpPortMap", false)
	if (upnpTbl == nil) then
		return "ERROR", "DB_ERROR_TRY_AGAIN", localTbl
	end
        
    local query = "_ROWID_=1"
    upnpTable = db.getRowWhere("upnp", query, false);
	if (upnpTable) then
    local networkName = db.getAttribute("networkInterface", "LogicalIfName", upnpTable["LogicalIfName"], "networkName")
    
    portTbl.portMap = {}

    for i,v in pairs (upnpTbl) do
        portTbl.portMap[i] ={}
        portTbl.portMap[i]["active"] = v.active
        portTbl.portMap[i]["protocol"] = v.protocol
        portTbl.portMap[i]["intPort"] = v.intPort
        portTbl.portMap[i]["extPort"] = v.extPort
        portTbl.portMap[i]["ipAddr"] = v.ipAddr
        portTbl.portMap[i]["networkName"] = networkName
    end
	end
    
    local err = "OK" 
    local status = ""
	
    --return
	return err, status, portTbl
end

--****************************************************************************
	--Function to get the table upnpPortMap
--****************************************************************************
--@name  upnp.openPortsGet()
--
--@description The function get the table upnpPortMap from the database 
--
--@return

function upnp.openPortsGet()
	
	--locals
	local localTbl = {}	--local table contaning the table upnpPortMap
	local upnpTbl = {}	--local table contaning the fields to be passed
	local upnpTable = {}
    local portTbl = {}
    local row = {}

    local DB_FILE_NAME = "/tmp/system.db"
    local UPNP_PORT_FILE_NAME = "/tmp/upnpPorts"
    local prog = db.getAttribute("environment", "name", "UPNP_REFRESH_PROGRAM", "value");
    util.shellCmdOutput(prog .. " " .. DB_FILE_NAME)

    local query = "_ROWID_=1"
    upnpTable = db.getRowWhere("upnp", query, false);
	if (upnpTable) then
    local networkName = db.getAttribute("networkInterface", "LogicalIfName", upnpTable["LogicalIfName"], "networkName")
   
    local file = io.open(UPNP_PORT_FILE_NAME)
    i = 0
    if file then
        for line in file:lines() do
            row = util.split(line, " ")
            i = i + 1
            upnpTbl[i]={}
            upnpTbl[i]["active"] = row[1]
            upnpTbl[i]["protocol"] = row[2]
            upnpTbl[i]["intPort"] = row[3]
            upnpTbl[i]["extPort"] = row[4]
            upnpTbl[i]["ipAddr"] = row[5]
        end
    end
    portTbl.portMap = {}

    for i,v in pairs (upnpTbl) do
        portTbl.portMap[i] ={}
        portTbl.portMap[i]["active"] = v.active
        portTbl.portMap[i]["protocol"] = v.protocol
        portTbl.portMap[i]["intPort"] = v.intPort
        portTbl.portMap[i]["extPort"] = v.extPort
        portTbl.portMap[i]["ipAddr"] = v.ipAddr
        portTbl.portMap[i]["networkName"] = networkName
    end
	end
    
    local err = "OK" 
    local status = ""
	
    --return
	return err, status, portTbl
end

--***************************************************************************
--@name  upnp.upnpGet()
--
--@description The function will get the upnp table
--
--@return

function upnp.upnpGet()

	-- locals	
	local upnpTbl = {}
	local localTbl ={}	
    local query = nil

	-- getting the upnp table
    query = "_ROWID_=1"
	upnpTbl = db.getRowWhere("upnp", query, false)
	if (upnpTbl == nil) then
		return "ERROR", "DB_ERROR_TRY_AGAIN", localTbl
	end 

    local err = "OK"
    local status = ""

	--return
	return err, status, upnpTbl
end

--****************************************************************************
--@name upnp.upnpSet(inputTable)
--
--@description The function will enable/disable the upnp
--
--@return

function upnp.upnpSet(inputTable)

	--locals
	local statusMsg, errMsg 
	local upnpTbl = {}
    local query = nil

	-- getting the upnp table
    query = "_ROWID_=1"
	upnpTbl = db.getRowWhere("upnp", query, false)
	if (upnpTbl ~= nil) then
		upnpTbl["upnpEnable"] =  tonumber(inputTable["upnpEnable"])
		upnpTbl["advPeriod"] =  tonumber(inputTable["advPeriod"])
		upnpTbl["advTimeToLive"] =  tonumber(inputTable["advTimeToLive"])

    --[[    if (inputTable["networkName"] ~= nil) then
            local logicalName = db.getAttribute("networkInterface", "networkName", inputTable["networkName"], "LogicalIfName")
            upnpTbl["LogicalIfName"] = logicalName
        end
        --]]
		-- adding the prefix 
		upnpTbl = util.addPrefix (upnpTbl, "upnp.")
		local DBTable = "upnp"
		errMsg, statusMsg = upnp.config(upnpTbl, upnpTbl["upnp._ROWID_"], "edit")
		return errMsg, statusMsg
	else
		statusMsg = "DB_ERROR_TRY_AGAIN"
		errMsg = "ERROR"
		return errMsg, statusMsg
	end			

end
--****************************************************************************
	--END
--****************************************************************************

function upnp.import (configTable, defaultCfg, removeCfg)
	if (configTable == nil) then
		configTable = defaultCfg
	end

    --Note :- The code is added to load the user configuration when trying to
    --load the image from 1.0.40 to 1.0.42.
    if (configTable.upnp == nil) then
        configTable.upnp = {}
        configTable.upnp[1] = {}
        configTable.upnp[1]["upnpEnable"]      = configTable ["upnpEnable"] 
        configTable.upnp[1]["advPeriod"]       = configTable ["advPeriod"] 
        configTable.upnp[1]["advTimeToLive"]   = configTable ["advTimeToLive"] 
        configTable.upnp[1]["LogicalIfName"]   = configTable ["LogicalIfName"] 
    end

	local upnpTmp = {}
	upnpTmp = config.update (configTable.upnp, defaultCfg.upnp, removeCfg.upnp)

    if (upnpTmp ~= nil and #upnpTmp ~= 0) then
        for i,v in ipairs (upnpTmp) do
            v = util.addPrefix (v, "upnp.");
            db.insert  ("upnp", v)
        end
    end
end

function upnp.export ()
    local upnpTbl = {}
    upnpTbl["upnp"] = db.getTable ("upnp", false)
    return upnpTbl
end

if (config.register) then
   config.register("upnp", upnp.import, upnp.export, "2")
end

