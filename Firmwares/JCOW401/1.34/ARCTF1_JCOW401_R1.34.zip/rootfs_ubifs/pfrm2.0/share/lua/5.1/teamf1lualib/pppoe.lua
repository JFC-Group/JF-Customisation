--[[
#### Hussain Vali.
#### TeamF1
#### www.TeamF1.com
#### Mar 14, 2008
#### File: pppoe.lua
#### Description: PPPOE Setup functions
#### Revisions:
01a, 08oct13, ash changes for password encryption/descryption
]]--

--************* Requires *************
require "passwdSecureLib"

--************* Initial Code *************

--package PPPOE Configurations
pppoe = {}

--************* Functions *************
-- PPPOE config
function pppoe.config (inputTable, rowid, operation)
    -- validate
    local valid = db.typeAndRangeValidate(inputTable)
    if (valid == true) then
        if (operation == "add") then
            return db.insert("Pppoe", inputTable)
        elseif (operation == "edit") then
            return db.update("Pppoe", inputTable, rowid)
        elseif (operation == "delete") then
            return nil
        end
    end
    return false, "PPPOE_TYPE_RANGE_VALIDATE_ERR"
end

function pppoe.profileConfig (inputTable, rowid, operation)
    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end
    
    db.beginTransaction() --begin transaction
    local valid = false

    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
            valid = db.insert("PppoeProfile", inputTable)
        elseif (operation == "edit") then
            valid = db.update("PppoeProfile", inputTable, rowid)
        elseif (operation == "delete") then
            valid = db.delete("PppoeProfile", inputTable)
        end
    end

    -- return
    if (valid) then
        db.commitTransaction()
        return "OK", "STATUS_OK"
    else
        db.rollback()
        return "ERROR", "PPPOE_PROFILE_CONFIG_FAILED"
    end
end


function pppoe.import (inputTable, defaultCfg, remCfg)
    local status
    if (inputTable == nil) then
        inputTable = defaultCfg
    end

    --initializing a temp table
    local configTable = {}

    configTable = config.update (inputTable, defaultCfg, remCfg)

    if (configTable ~= nil and #configTable ~= 0) then
        for i,v in ipairs (configTable) do
            if (v["Password"] ~= nil and v["Password"] ~= "") then
                status, v["Password"] = passwdSecureLib.decryptData (v["Password"], "")
            end
            v = util.addPrefix (v, "Pppoe.");
            db.insert ("Pppoe", v)
        end
    end
end

function pppoe.export ()
    local status
    local pppoe = db.getTable ("Pppoe", false)
    for i, v in ipairs (pppoe) do
        if (v["Password"] ~= nil and v["Password"] ~= "") then
            status, pppoe[i].Password = passwdSecureLib.encryptData (v["Password"], "")
        end
    end
    return pppoe
end

if (config.register) then
   config.register("pppoe", pppoe.import, pppoe.export, "1")
end
