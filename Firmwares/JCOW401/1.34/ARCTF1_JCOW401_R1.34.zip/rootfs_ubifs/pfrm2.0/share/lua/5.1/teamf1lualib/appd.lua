
-- @copyright Copyright (c) 2012, TeamF1, Inc. 

appd = {}
appd.eventType = {
    APPD_EV_NET = 1,
    APPD_EV_CFG = 2,
} 

local umiId =108
LOG = nil

require "teamf1lualib/config"
require "teamf1lualib/evtDsptch"
require "appExtn/AppExtnFactory"
require "util/strlib"

require "lualogging/adplog"
require "lualogging/lsyslog"

 -- List of all application instances that are being managed.
local appExtnInstanceTbl = {}

 -- List of cfg event subscriptions indexed by db table.
local cfgEventSubscrTbl = {}

 -- List of network event subscriptions indexed by event type.
local netEventSubscrTbl = {}

-------------------------------------------------------------------------------
-- @name appd.init
--
-- @description  This function is called by appd at startup to initialize the
-- AppExtn framework. The framework constitutes a factory which is used to
-- create and manage AppExtn instances.
--
-- @param  dbFile database file name
--
-- @return  0
--

function appd.init(dbFile)

    -- initialize logger
    if (LOG == nil) then
      --LOG = logging.syslog("APPD")
        LOG = logging.adplog(umiId)
    end

    -- connection to the database
    db.connect(dbFile)

    -- Initialize factory
    AppExtnFactory:init()

    return 0
end

-------------------------------------------------------------------------------
-- @name appd.appExtnRegister - register application instance
--
-- @description  This function registers the AppExtn object to appd. The
-- object is added to its internal database.
-- 
-- @return 0
--

function appd.appExtnRegister (appExtnObj)

    assert(appExtnObj, "Invalid AppExtn Object")        
    assert(appExtnObj.classId, "classId not set for AppExtn Object")        

    local classId = appExtnObj.classId

    if (appExtnInstanceTbl[classId] == nil) then
        appExtnInstanceTbl[classId] = {}        
    end
            
    LOG:ddebug("Adding AppExtn instance for class: " .. classId)
    table.insert(appExtnInstanceTbl[classId], appExtnObj)

    return 0
end

-------------------------------------------------------------------------------
-- @name appd.appExtnUnregister - unregister application instance
--
-- @description  This function un-registers the AppExtn object from appd. The
-- object is deleted to its internal database.
-- 
-- @return 0
--

function appd.appExtnUnregister (appExtnObj)

    assert(appExtnObj, "Invalid AppExtn Object")        
    assert(appExtnObj.classId, "classId not set for AppExtn Object")        

    local appInstanceList = {}

    appInstanceList = appExtnInstanceTbl[classId] 
    if (appInstanceList == nil) then
        return 0
    end
            
    for index, classObj in pairs(appInstanceList) do
        if (classObj.instanceId  == appExtnObj.instanceId) then
            LOG:debug("appExtnUnregister: unregistering class " .. classId .. 
                      "(" .. instanceId .. ")")
            table.remove(appInstanceList, index)
        end            
    end        
    appExtnInstanceTbl[classId] = appInstanceList

    return 0
end
    
-------------------------------------------------------------------------------
-- @name appd.appExtnCreate - create application instance
--
-- @description  This function called after receiving a configuration 
-- insert/update event to create AppExtn objects.
--
-- @return  
--

function appd.appExtnCreate(classId, instanceId)

    if (classId == nil) then
        return nil
    end
            
    local factory = AppExtnFactory.getFactory()

    local dsClassObj =  factory:getClass(classId)
    if (dsClassObj == nil) then
        LOG:error("appExtnCreate: " .. classId .. " not registered")
        return nil
    end

    local appExtnObj = dsClassObj:new(instanceId)
    if (appExtnObj == nil) then
        LOG:error("appExtnCreate: failed to create an instance of " .. classId)
        return nil
    end        
            
    return appExtnObj
end

-------------------------------------------------------------------------------
-- @name appd.appExtnDestroy - destroy application instance
--
-- @description  This function is called by the app extension after
-- processing a configuration delete event
--
-- @return  
--

function appd.appExtnDestroy(classId, instanceId)
    local appExtnObj = nil

    -- find the AppExtn instance
    appExtnObj = appd.appExtnFind(classId, instanceId)
    if (appExtnObj == nil) then
        return -1
    end        

    -- invoke delete
    appExtnObj:delete()

    return 0
end

-------------------------------------------------------------------------------
-- @name appd.appExtnFind  - find application instance
--
-- @description  This function finds an instance of an application that is 
-- being managed by appd
--
-- @return application instance or nil 
--

function appd.appExtnFind(classId, instanceId)
    local appInstanceList = {}

    appInstanceList = appExtnInstanceTbl[classId] 
    if (appInstanceList == nil) then
        LOG:error("appFind: Instance " .. instanceId .. " of "  .. 
                   classId .. " not found")
        return nil
    end        

    for index, appExtnObj in pairs(appInstanceList) do
        if (appExtnObj.instanceId  == instanceId) then
            return appExtnObj
        end            
    end        

    return nil
end

-------------------------------------------------------------------------------
-- @name netCallbackRegister - register network event callback
--
-- @description  This function registers network event callback for the given
-- class. The callback is invoked when the registered network event is
-- received.
--
-- @return  
--

local function netCallbackRegister (classId, callback)
    local subcr = {}
    local netevent = tonumber(callback.netevent)

    assert(callback.netevent, "callback:event required")
    assert(callback.routine,  "callback:routine not specified")

    if (netEventSubscrTbl[netevent] == nil) then
        netEventSubscrTbl[netevent] = {}
    end        

    subcr.netevent = netevent
    subcr.classId = classId
    subcr.callback = callback.routine

    table.insert(netEventSubscrTbl[netevent], subcr)    

    return 
end

-------------------------------------------------------------------------------
-- @name cfgCallbackRegister - register configuration callback
--
-- @description  This function registers configuration callback for the given
-- class. The callback is invoked when a configuration event is received
-- on the given database table.
--
-- @return  
--

local function cfgCallbackRegister (classId, callback)
    local subcr = {}
    local dbTable = callback.dbTable

    assert(callback.dbTable, "callback:DB table name required")
    assert(callback.routine, "callback:routine not specified")

    if (cfgEventSubscrTbl[dbTable] == nil) then
        cfgEventSubscrTbl[dbTable] = {}
    end        

    subcr.dbTable = dbTable
    subcr.classId = classId
    subcr.callback = callback.routine

    table.insert(cfgEventSubscrTbl[dbTable], subcr)    

    return 
end

-------------------------------------------------------------------------------
-- @name appd.callbackRegister - register callback
--
-- @description  This function registers callbacks for a given class. This
-- registration is done during the bootstrap of application
--
-- @return  
--

function appd.callbackRegister (classId, callbackTable)

    if (type(callbackTable) ~= "table") then
        assert(nil, "callback register: callback table required")
    end

    for index, callback in pairs(callbackTable) do
        if (callback.type == appd.eventType.APPD_EV_NET) then
            netCallbackRegister(classId, callback)
        elseif (callback.type == appd.eventType.APPD_EV_CFG) then
            cfgCallbackRegister(classId, callback)
        end
    end
            
    return 0
end

-------------------------------------------------------------------------------
-- @name appd.onCfgEvent
--
-- @description  This function sends configuration event to the registered 
--               applications
-- 
-- @param  event   type of network event
-- @param  info    event information
--
-- @return  
--

function appd.onCfgEvent (dbTable, event, rowId, oparams)
    local status = 0
    local logprefix = "Received Configuration Event=" .. event .. " " ..
                      "table=" .. dbTable 

    LOG:ddebug(logprefix)

    local subcrList = cfgEventSubscrTbl[dbTable]
    if (subcrList == nil) then
        LOG:ddebug(logprefix .. " : No subscribers")
        return
    end        

    local info = {}
    info.type = appd.eventType.APPD_EV_CFG
    info.event = tonumber(event)
    info.dbTable = dbTable          -- database table name
    info.rowId = tostring(rowId)    -- row id of the record
    info.oparams = oparams          -- old values of this record

    for index, subcr in pairs(subcrList) do
        logprefix = logprefix ..  " classId=" .. subcr.classId
        local appExtnObj = appd.appExtnFind(subcr.classId, info.rowId)
        local valid, status = pcall(subcr.callback, appExtnObj, info)
        if (not valid) then
            LOG:error(logprefix .. " returned lua error:" .. status)
        elseif (status < 0) then
            LOG:error(logprefix .. " returned error=" .. status)
        else                
            LOG:ddebug(logprefix .. " returned status=" .. status)
        end                
    end
end

-------------------------------------------------------------------------------
-- @name appd.onNetEvent
--
-- @description  This function sends the network event to the registered 
--               applications
-- 
-- @param  LogicalIfName   LogicalIfName of the network
-- @param  eventType       type of network event
-- @param  params          new interface parameters
-- @param  oparams         old interface parameters
--
-- @return  
--

function appd.onNetEvent(LogicalIfName, event, params, oparams)
    local status = 0

    local logprefix="Received network Event=" .. event .. " " ..
                 "ifname='" .. LogicalIfName .. "' "
    LOG:ddebug(logprefix)

    local info = {}
    info.type = appd.eventType.APPD_EV_NET
    info.event = tonumber(event)
    info.ifname = LogicalIfName -- interface or logical name
    info.params = params    -- new params
    info.oparams = oparams  -- old params

    -- dispatch event to all the instances
    for classId, instanceList in pairs(appExtnInstanceTbl) do
        for index, appExtnObj in pairs(instanceList) do
            local appName = appExtnObj:getAppName()
            local valid, status = pcall(appExtnObj.onNetEvent, appExtnObj, info)
            if (not valid) then
                LOG:error(logprefix .. appName  .. " returned lua error:" .. status)
            elseif (status < 0) then
                LOG:error(logprefix .. appName  .. " returned status=" .. status)
            else                
                LOG:ddebug(logprefix .. appName  .. " returned status=" .. status)
            end                
        end
    end

    -- dispatch event to all the registered callbacks
    local subcrList = netEventSubscrTbl[info.event]
    if (subcrList == nil) then
        return
    end        

    for index, subcr in pairs(subcrList) do
        local valid, status = pcall(subcr.callback, info)
        if (not valid) then
            LOG:error(logprefix .. subcr.classId .. " returned lua error:" .. status)
        elseif (status < 0) then
            LOG:error(logprefix .. subcr.classId .. " returned status=" .. status)
        else                
            LOG:ddebug(logprefix .. subcr.classId .. " returned status=" .. status)
        end                
    end        

    return
end

-------------------------------------------------------------------------------
-- @name appd.classNameGet - get class name
--
-- @description  This function gets the class name for the given class Id
--
-- @return  
--

function appd.classNameGet(classId)
    local factory = nil

    factory = AppExtnFactory.getFactory()

    local dsClassObj =  factory:getClass(classId)
    if (dsClassObj == nil) then
        LOG:error("classNameGet: " .. classId .. " not registered")
        return nil
    end

    return dsClassObj.className
end

-------------------------------------------------------------------------------
-- @name appd.appExtnMethodCall - 
--
-- @description  
--
-- @return  
--

function appd.appExtnMethodCall(classId, instanceId, method)
    local appExtnObj = nil

    assert(classId      , "appExtnMethodCall: Class ID not provided")
    assert(instanceId   , "appExtnMethodCall: instance ID not provided")
    assert(method       , "appExtnMethodCall: method not provided")

    local logprefix="appExtnMethodCall: class=" .. classId .. " instance=" .. 
                    instanceId ..  " Method=" .. method

    LOG:ddebug(logprefix)

    appExtnObj = appd.appExtnFind(classId, instanceId)
    if (appExtnObj == nil) then
        LOG:error(logprefix .. " instance not found")
        return -4
    end
            
    local methodName = appExtnObj[method] 
    if (methodName == nil) then
        LOG:error(logprefix .. " method not found")
        return -3
    end        
                    
    local valid, status, errCode, output = pcall(methodName, appExtnObj)
    if (not valid) then
        LOG:error(logprefix .. " returned lua error:" .. status)
        return -2
    elseif (status < 0) then
        LOG:error(logprefix .. " returned status=" .. status)
        return status , errCode, output 
    else                
        LOG:ddebug(classId ..  " returned status=" .. status)
        return status , errCode, output
    end                
end

-------------------------------------------------------------------------------
-- @name appd.dump - dump all registered applications
--
-- @description  This function dumps all the information about all registered
-- applications
--
-- @return  
--

function appd.dump()
    local classId

    for classId, appInstanceList in pairs(appExtnInstanceTbl) do
        for index, appExtnObj in pairs(appInstanceList) do
            if (appExtnObj.print ~= nil) then
                appExtnObj:print()                
            end                    
        end        
    end                    

    return 0
end

-------------------------------------------------------------------------------
-- @name appd.appExtnPrint - dump application
--
-- @description  This function dumps all the information about a given instance 
-- of the application
--
-- @return  
--

function appd.appExtnPrint(classId, instanceId)

    local appExtnObj = appd.appFind(classId, instanceId)
    if (appExtnObj == nil) then
        return 
    end
            
    if (appExtnObj.print ~= nil) then
        appExtnObj:print()                
    end

    return 0
end

-------------------------------------------------------------------------------
-- @name appd.devDebugEnable - enable dev debugs
--
-- @description  This function enables dev debugs in the logger object.
--
-- @return  
--

function appd.devDebugEnable()
    LOG:setDevDebug(1)
    return 
end
