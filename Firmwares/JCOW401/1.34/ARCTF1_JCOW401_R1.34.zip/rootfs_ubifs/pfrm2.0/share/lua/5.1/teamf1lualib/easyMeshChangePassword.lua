--[[ easyMeshChangePassword.lua - Handler for Easy Mesh Login passord Change.
--
-- Copyright (c) 2008-2014, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: easyMeshChangePassword.lua
-- Description: Handler for Easy Mesh Login passord Change.
-- 
-- modification history
-- --------------------
-- 01a, 09Dec19, ar written.
--
--]]

require "easyMeshLib"
require "teamf1lualib/dot11_ul"

-- path for cookie and referer Ip Address
local REFERER_PATH = "/tmp/referer/"
local REMOVE = os.remove

-- ChangePassword Object as defined by Customer Specification.
local ChangePasswordRequestObj = {
    ["Admin_Name"]      = "Admin_Name",
    ["Admin_Password"]  = "Admin_Password",
}

-- List of ChangePassword Tags as defined by Customer Specification.
local ChangePasswordResObj = {
    ["Result"] = "Result"
}

-- Initialise the changePasswordRespose_t Lua Table which will be coverted as JSON Object
local ChangePasswordResponse_t = {
    ["Result"] = "ERROR",
    ["Response_Code"] = "400",
    ["Error_Message"] = "Failed to Change Password"
}

-- Supported Return Codes for "LoginResponse"
local ChangePasswordResponse_ReturnCodes = {
    ["OK"] = "OK",
    ["ERROR"] = "ERROR",
    ["SUCCESS"] = "Success",
    ["FAILED"]  = "Failed",
}


----------------------------------------------------------------------------------
-- @name easyMeshPasswordChange
--
-- @description This function changes EasyMesh Login Password.
--
-- @return OK on Success
--         ERROR on Failure
--
function easyMeshPasswordChange(loginUserNameStr, loginPasswordStr)

    --include
    require "teamf1lualib/userdb"

    local MinLength = "8"
    local MaxLength = "32"

    if (loginUserNameStr == nil or loginPasswordStr == nil) then
        mesh.dprintf("User name or login Password are nil")
        return "ERROR", "Invalid Login Credentials"
    end
    
    local error_msg = userdb.passwordCheck(loginPasswordStr)
    if (error_msg) then
        mesh.dprintf("Password check failed")
        return "ERROR", error_msg
    end
        
    local error_msg = util.validPasswordCheck(loginPasswordStr)
    if (error_msg) then
        return "ERROR", "PASSWORD contain non ASCII Characters"
    end

    local status = LengthCheck (MinLength, MaxLength,loginPasswordStr, "Password")
    if(status == "ERROR") then
        return "ERROR" ,"Password Length Should be in 8-32 characters"
    end


    local valid = db.setAttribute("users", "username", loginUserNameStr, "password", loginPasswordStr)
    if(tostring(valid) ~= "1") then
        mesh.dprintf("User Session does not Exists")
        return "ERROR", "DB_ERROR_TRY_AGAIN"
    end
    
    db.save2()
            
    -- Removing below files in the system to suggest that after the password
    -- change, the device is no more in Factory State.
    os.execute("rm -rf /tmp/FcDef")
    os.execute("rm -rf /flash/FcDef")
        
    -- LOGOUT user's existing Web Session, if any, on password change.
    local query = "username='" .. loginUserNameStr .. "'"
    local usrSessionRow =  db.getRowWhere ("loginSession", query, true)
    if (usrSessionRow ~= nil) then
        
        mesh.dprintf("Deleting user web-session with username: " .. loginUserNameStr .. " and Cookie: " .. usrSessionRow["loginSession.cookie"] )
        
        local wherePart = "username = '" .. loginUserNameStr .. "' AND cookie = '" .. usrSessionRow["loginSession.cookie"] .. "'"
        -- delete session
        local errMsg, status = db.deleteRowWhere("loginSession", wherePart)
        -- if the cookieVal is found in db then only delete the mapping
        if (errMsg == 1) then
            -- remove the mapping
            REMOVE(REFERER_PATH .. usrSessionRow["loginSession.cookie"])
        end
    end
        mesh.dprintf("User Web-Session does not Exists")

    -- LOGOUT the user's existing EasyMesh session if any.
    local query = "username='" .. loginUserNameStr .. "'"
    local usrRow =  db.getRowWhere ("users", query, true)
    if (usrRow == nil) then
        mesh.dprintf("User does not Exists; Unable to get User Details")
        return "OK", ChangePasswordResponse_ReturnCodes["SUCCESS"]
    end

    mesh.dprintf("Deleting mesh session for user: " .. loginUserNameStr .. " group: " .. usrRow["users.groupname"])
    -- Send Login Request details for easyMesh store.
    easyMeshLib.SessionLogout(loginUserNameStr, usrRow["users.groupname"])
    
    return "OK", ChangePasswordResponse_ReturnCodes["SUCCESS"]
end

----------------------------------------------------------------------------------
-- @name passwdChangeHandler
--
-- @description This function Handles EasyMesh Login Password Changes Request Method.
--
-- @return JSON responses to EasyMesh Login password change requests
--
function passwdChangeHandler(methodObj, meshRequestMethod)
    
    local loginUserNameStr    = methodObj["Admin_Name"]
    local loginPasswordStr    = methodObj["Admin_Password"]

    if (loginUserNameStr == nil or loginPasswordStr == nil) then
        ChangePasswordResponse_t["Result"] = ChangePasswordResponse_ReturnCodes["FAILED"]
        ChangePasswordResponse_t["Response_Code"] = "400"
        ChangePasswordResponse_t["Error_Message"] = "Bad Request"
        --mesh.sendResponse (ChangePasswordResponse_t) 
        return "ERROR", "INVALID_METHOD",ChangePasswordResponse_t
    end

    mesh.dprintf("loginUserNameStr: " .. loginUserNameStr)
    mesh.dprintf("loginPasswordStr: " .. loginPasswordStr)


    status, errorCode = easyMeshPasswordChange(loginUserNameStr, loginPasswordStr)
    if(status == "OK") then
        ChangePasswordResponse_t["Result"]           = ChangePasswordResponse_ReturnCodes["OK"]
        ChangePasswordResponse_t["Response_Code"]    = "200"
        ChangePasswordResponse_t["Error_Message"]    = nil
    else
        ChangePasswordResponse_t["Result"] = ChangePasswordResponse_ReturnCodes["FAILED"]
        ChangePasswordResponse_t["Response_Code"]    = "400"
        ChangePasswordResponse_t["Error_Message"]    = errorCode
    end
       

    --mesh.sendResponse (ChangePasswordResponse_t) 
    return "OK", "SUCCESS", ChangePasswordResponse_t
end

meshRequestMethodsList["Change_Password"]["methodHandler"] = passwdChangeHandler
