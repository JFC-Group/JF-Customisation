--[[ easyMeshForcedLogin.lua - Handler for Easy Mesh Login Request Method.
--
-- Copyright (c) 2008-2014, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: easyMeshLogin.lua
-- Description: Handler for Easy Mesh ForcedLogin Request Method.
-- 
-- modification history
-- --------------------
-- 01a, 05Jun2020, vin written.
--
--]]

require "easyMeshLib"
require "teamf1lualib/db"


-- path for cookie and referer Ip Address
local REFERER_PATH = "/tmp/referer/"
local REMOVE = os.remove

local COOKIE_LENGTH         = 10

-- ForcedLoginRequest Object as defined by Customer Specification.
local ForcedLoginRequestObj = {
    ["ForcedLogin"]          = "ForcedLogin",
}

-- List of ForcedLoginResponse Tags as defined by Customer Specification.
local ForcedLoginResObj = {
    "DeviceState",
    "uid",
    "Result",
    "Response_Code"
}

-- Initialise the LoginRespose_t Lua Table which will be coverted as JSON Object
local ForcedLoginRespose_t = {
    ["DeviceState"] = "N/A",
    ["uid"] = "N/A",
    ["Result"] = "ERROR",
    ["Response_Code"] = "401",
    ["Error_Message"] = "Login Failed"
}

-- Supported Return Codes for "ForcedLoginResponse"
local ForcedLoginResponse_ReturnCodes = {
    ["OK"] = "OK",
    ["ERROR"] = "ERROR",
    ["SUCCESS"] = "Success",
    ["FAILED"]  = "Failed",
}
------------------------------------------------------
--Deleting the Mesh APP user
 
function deleteMeshAppSession(loginUserNameStr)

    -- LOGOUT the user's existing EasyMesh session if any.
    local query = "username='" .. loginUserNameStr .. "'"
    local usrRow =  db.getRowWhere ("users", query, true)
    if (usrRow == nil) then
        mesh.dprintf("User does not Exists; Unable to get User Details")
        return "OK", "SUCCESS"
    end

    -- Send Login Request details for easyMesh store.
    easyMeshLib.SessionLogout(loginUserNameStr, usrRow["users.groupname"])
    return
end


----------------------------------------------------------
--@name delete Existing UserSession 


function deleteExistingUserSession (loginUserNameStr)

    local userType = db.getAttribute("users", "username",loginUserNameStr , "groupname") or ''
	for k,v in pairs(db.getTable("loginSession")) do
		if ((v["loginSession.username"] == loginUserNameStr) and (v["loginSession.loginState"] == "LOGGED_IN") and (userType == "admin")) then
	      db.setAttribute("loginSession", "_ROWID_", v["loginSession._ROWID_"], "loginState", "DISCONNECTED")
        end
    end
    --[[ 
    -- LOGOUT user's existing Web Session, if any.
    local query = "username='" .. loginUserNameStr .. "'"
    local usrSessionRow =  db.getRowWhere ("loginSession", query, true)
    if (usrSessionRow ~= nil) then
        
        mesh.dprintf("Deleting user web-session with username: " .. loginUserNameStr .. " and Cookie: " .. usrSessionRow["loginSession.cookie"] )
        
        local wherePart = "username = '" .. loginUserNameStr .. "' AND cookie = '" .. usrSessionRow["loginSession.cookie"] .. "'"
        -- delete session
        local errMsg, status = db.deleteRowWhere("loginSession", wherePart)
        -- if the cookieVal is found in db then only delete the mapping
        if (errMsg == 1) then
            -- remove the mapping
            REMOVE(REFERER_PATH .. usrSessionRow["loginSession.cookie"])
        end
    end]]--
end


----------------------------------------------------------------------------------
-- @name easyMeshUserInfoGet
--
-- @description This function gets userinformation from system database for the
-- given username.
--
-- @return OK, userinfo (on Success)
--         ERROR, nil (on Failure)
--
function easyMeshUserInfoGet(easyMeshUsername)

    local query = "username='" .. easyMeshUsername .. "'"
    local usrRow =  db.getRowWhere ("users", query, true)
    if (usrRow == nil) then
        mesh.dprintf("User does not Exists")
        return "ERROR", usrRow
    end
    
   return "OK", usrRow 
end


----------------------------------------------------------------------------------
-- @name focedLoginHandler
--
-- @description This function Handles EasyMesh Login Request Methods.
--
-- @return JSON responses to EasyMesh Login requests
--
function forcedLoginHandler(methodObj, meshRequestMethod)

    local uniqueVal = nil
    local loginUserNameStr    = methodObj["Admin_Name"]
    local loginPasswordStr    = methodObj["Admin_Password"]
    local loginUserName = nil
    local loginPassword = nil
   
    if ((loginUserNameStr == nil) or (loginPasswordStr == nil)) then
        LoginRespose_t["DeviceState"]   = nil
        LoginRespose_t["uid"]           = nil
        LoginRespose_t["Result"]        = LoginResponse_ReturnCodes["FAILED"]
        LoginRespose_t["Response_Code"] = "400"
        LoginRespose_t["Error_Message"] = "Bad Request"
        --mesh.sendResponse (ForcedLoginRespose_t) 
        return "ERROR", "INVALID_METHOD", ForcedLoginRespose_t
    end

    mesh.dprintf("loginUserNameStr: " .. loginUserNameStr)
    mesh.dprintf("loginPasswordStr: " .. loginPasswordStr)

    loginUserName = db.escape(loginUserNameStr)
    loginPassword = loginPasswordStr

    -- Validate EASY MESH User with System user database.
    -- EasyMesh user should be a system user also.
    status, userInfo = easyMeshUserInfoGet(loginUserName)
    if (status ~= "OK") then
        ForcedLoginRespose_t["DeviceState"]   = nil
        ForcedLoginRespose_t["uid"]           = nil
        ForcedLoginRespose_t["Result"]        = ForcedLoginResponse_ReturnCodes["FAILED"]
        ForcedLoginRespose_t["Response_Code"] = "401"
        ForcedLoginRespose_t["Error_Message"] = "Unauthorized"
        mesh.dprintf("Invalid User")
        --mesh.sendResponse (ForcedLoginRespose_t) 
        return "ERROR", "INVALID_LOGIN_CREDENTIALS", ForcedLoginRespose_t
    end

    if (loginPassword ~= userInfo["users.password"]) then
        ForcedLoginRespose_t["DeviceState"]   = nil
        ForcedLoginRespose_t["uid"]           = nil
        ForcedLoginRespose_t["Result"]        = ForcedLoginResponse_ReturnCodes["FAILED"]
        ForcedLoginRespose_t["Response_Code"] = "401"
        ForcedLoginRespose_t["Error_Message"] = "Unauthorized"
        mesh.dprintf("Password Not Matched")
        --mesh.sendResponse (ForcedLoginRespose_t) 
        return "ERROR", "INVALID_LOGIN_CREDENTIALS", ForcedLoginRespose_t
    end

    local loginGroupName = userInfo["users.groupname"] 

    -- generate cookie
    uniqueVal = easyMeshLib.getRandom(COOKIE_LENGTH)
    mesh.dprintf("Unique Cookie: " .. uniqueVal)
    
    ForcedLoginRespose_t["uid"] = uniqueVal

   -- delete any existing WebSessions for this logged in user.
   deleteExistingUserSession(loginUserName)

   -- delete existing mesh app user session.
    deleteMeshAppSession(loginUserName) 

    -- Send Login Request details for easyMesh store.
    easyMeshLib.LoginReqUpdate( 
                            loginUserName, 
                            ForcedLoginRespose_t["uid"],
                            loginPassword, 
                            loginGroupName
                          )

    if (util.fileExists ("/flash/FcDef")) then
        ForcedLoginRespose_t["DeviceState"] = "1"
    else
        ForcedLoginRespose_t["DeviceState"] = "0"
    end
    
    ForcedLoginRespose_t["Result"] = ForcedLoginResponse_ReturnCodes["OK"]
    ForcedLoginRespose_t["Response_Code"] = "200"
    ForcedLoginRespose_t["Error_Message"] = nil

    --mesh.sendResponse (ForcedLoginRespose_t) 
    
    return "OK", "SUCCESS", ForcedLoginRespose_t
end

meshRequestMethodsList["ForcedLogin"]["methodHandler"] = forcedLoginHandler
