-- Copyright (c) 2017, TeamF1 Networks Pvt. Ltd. 
-- (Subsidiary of D-Link India)

-- modification history
-- --------------------
-- 01a, 31Oct17, swr Changes for SPR 59254(radvd prefixes)

radvdPrefix = {} 

-------------------------------------------------------------------------
-- @name radvdPrefix.cfgInit
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function radvdPrefix.cfgInit(row, conf)

    if (conf["LogicalIfName"] ~= nil) then
        row["LogicalIfName"] = conf["LogicalIfName"]
    end

    if (conf["radvdPrefixType"] ~= nil) then
        row["radvdPrefixType"] = conf["radvdPrefixType"]
    end

    if (conf["radvdAdvPrefixLifetime"] ~= nil) then
        row["radvdAdvPrefixLifetime"] = conf["radvdAdvPrefixLifetime"]
    end
            
    if (conf["radvdAdvPrefix"] ~= nil) then
        row["radvdAdvPrefix"] = conf["radvdAdvPrefix"]
    end        

    if (conf["radvdAdvPrefixLength"] ~= nil) then
        row["radvdAdvPrefixLength"] = conf["radvdAdvPrefixLength"]
    end        

    if (conf["SLAIdentifier"] ~= nil) then
        row["SLAIdentifier"] = conf["SLAIdentifier"]
    end        

    if (conf["Base6to4Interface"] ~= nil) then
        row["Base6to4Interface"] = conf["Base6to4Interface"]
    end

    if (conf["Enable"] ~= nil) then
        row["Enable"] = conf["Enable"]
    end

    return row
end

-------------------------------------------------------------------------
-- @name radvdPrefix.delete
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function radvdPrefix.delete(IDList)

    require "radvdLib"
    local oldPrefixTbl = {}
    local query
    local index = 1
    if (IDList == nil) then
        radvd.dprintf("radvdPrefix.delete: invalid arguments")        
        return "ERROR", "DHCPV6D_INVALID_ARG"
    end

    for k, v in pairs (IDList) do
        query = "_ROWID_='" .. v .. "'"
        local row = db.getRowWhere("radvdLANPrefixPool", query, false)
        --oldPrefixTbl[i] = {}
        oldPrefixTbl["radvdAdvPrefix"] = row["radvdAdvPrefix"]
        oldPrefixTbl["LogicalIfName"]  = row["LogicalIfName"]
        oldPrefixTbl["radvdAdvPrefixLength"]  = row["radvdAdvPrefixLength"]
        oldPrefixTbl["radvdAdvPrefixLifetime"]  = row["radvdAdvPrefixLifetime"]
        radvdLib.prefixDeconfigure(oldPrefixTbl["radvdAdvPrefix"], oldPrefixTbl["LogicalIfName"], oldPrefixTbl["radvdAdvPrefixLength"],oldPrefixTbl["radvdAdvPrefixLifetime"])
    end

    -- delete all the prefixes from the pool
    local valid, errstr = db.delete ("radvdLANPrefixPool", IDList)
    if (not valid) then
        radvd.dprintf("radvdPrefix.delete: " ..
                      "failed to delete bindings from db. Err:" .. errstr)
        radvd.dprintf("IDList: " .. util.tableToStringRec(IDList))
        return "ERROR","RADVD_DB_ERR"
    end        

    -- Handled by db update handler, because it requires deletion of
    -- prefixes on interface.
--    radvd.restart()

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name radvdPrefix.validate
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function radvdPrefix.validate(conf)
    require "nimfLib"

    if (conf["radvdPrefixType"] == "2") then
        local prefix = nimfLib.prefixGet(conf["radvdAdvPrefix"], 
                                        conf["radvdAdvPrefixLength"])
        if (prefix == nil) then
            radvd.dprintf("radvdPrefix.validate: Invalid IPv6 prefix or prefixlength")
            return "ERROR", "RADVD_INVALID_PREFIX,Prefix length must be a multiple of 8"
        end
    end

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name radvdPrefix.defCfgGet
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function radvdPrefix.defCfgGet()
    local row = {}
    local dhcpv6sTbl = {}
    local chipSet

    chipSet = db.getAttribute("chipsetInfo", "_ROWID_", 1, "Chipset")
    dhcpv6sTbl = db.getRowWhere ("dhcpv6s", "_ROWID_=1", false)

    row["radvdPrefixType"] = "2"
    row["radvdAdvPrefixLifetime"] = "86400"
    row["Base6to4Interface"] = "IF1"
    row["SLAIdentifier"] = ""
    -- As Per RJIL, advertise prefix information through RA only in case of statelessMode
    if(((chipSet ~= nil) and (chipSet ~= "Marvell_ODU")) and (tonumber(dhcpv6sTbl["isEnabled"]) == 1) and 
        (tonumber(dhcpv6sTbl["statelessMode"]) == 0)) then
        row["Enable"] = "0"
    else
        row["Enable"] = "1"
    end

    return row
end

-------------------------------------------------------------------------
-- @name radvdPrefix.add
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function radvdPrefix.add(conf, dbFlag)
    local query=""

    local status, errCode = radvdPrefix.validate(conf) 
    if (status ~= "OK") then
        return status, errCode
    end                        

    if (conf["radvdPrefixType"] == "2") then
        query = "radvdAdvPrefix='" .. conf["radvdAdvPrefix"] .. "'"
    else
        query = "SLAIdentifier='" .. conf["SLAIdentifier"] .. "'"
    end
    local row = db.getRowWhere("radvdLANPrefixPool", query, false)
    if (row ~= nil) then
        return "ERROR", "RADVD_PREFIX_EXISTS"
    end
            
    row = radvdPrefix.defCfgGet()
    row = radvdPrefix.cfgInit(row, conf)
    row = util.addPrefix(row, "radvdLANPrefixPool.")
    local valid, errstr, rowid  = db.insert("radvdLANPrefixPool", row)
    if (not valid) then
        radvd.dprintf("radvdPrefix.configure: failed to add radvd configuration")
        return "ERROR", "RADVD_ADD_FAILED"
    end            

    if(dbFlag == 1) then
        radvd.restart()
    end

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name radvdPrefix.edit
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function radvdPrefix.edit(conf, dbFlag)

    require "radvdLib"
    local query=""
    local oldPrefixTbl = {}

    local status, errCode = radvdPrefix.validate(conf) 
    if (status ~= "OK") then
        return status, errCode
    end                        

    query = "_ROWID_='" .. conf["_ROWID_"] .. "'"
    local row = db.getRowWhere("radvdLANPrefixPool", query, false)
    if (row == nil) then
        return "ERROR", "RADVD_PREFIX_NOT_EXISTS"
    end

    oldPrefixTbl["radvdAdvPrefix"] = row["radvdAdvPrefix"]
    oldPrefixTbl["LogicalIfName"]  = row["LogicalIfName"]
    oldPrefixTbl["radvdAdvPrefixLength"]  = row["radvdAdvPrefixLength"]
    oldPrefixTbl["radvdAdvPrefixLifetime"]  = row["radvdAdvPrefixLifetime"]

	-- check if the edited prefix or SLA ID already exsists.
    if (conf["radvdPrefixType"] == "2") then
        query = "radvdAdvPrefix='" .. conf["radvdAdvPrefix"] .. "'"
    else
        query = "SLAIdentifier='" .. conf["SLAIdentifier"] .. "'"
    end
    local rowDuplicate = db.getRowWhere("radvdLANPrefixPool", query, false)
    if (rowDuplicate ~= nil and rowDuplicate["_ROWID_"] ~= conf["_ROWID_"]) then
        return "ERROR", "RADVD_PREFIX_EXISTS"
    end
            
    row = radvdPrefix.cfgInit(row, conf)
    row = util.addPrefix(row, "radvdLANPrefixPool.")
    local valid, errstr = db.update("radvdLANPrefixPool", row,
                                    row["radvdLANPrefixPool._ROWID_"])
    if (not valid) then
        radvd.dprintf("radvdPrefix.configure: failed to update radvd configuration")
        return "ERROR", "RADVD_UPDATE_FAILED"
    end            

    radvdLib.prefixDeconfigure(oldPrefixTbl["radvdAdvPrefix"], oldPrefixTbl["LogicalIfName"], oldPrefixTbl["radvdAdvPrefixLength"],oldPrefixTbl["radvdAdvPrefixLifetime"])
    -- Handled by db update handler, because it requires deletion of
    -- prefixes on interface.
--    if(dbFlag == 1) then
 --       radvd.restart()
 --   end

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name radvdPrefix.configure
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function radvdPrefix.configure(conf)
    local query=""

    local status, errCode = radvdPrefix.validate(conf) 
    if (status ~= "OK") then
        return status, errCode
    end                        

    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "'"
    local row = db.getRowWhere("radvdLANPrefixPool", query, false)
    if (row ~= nil) then
        row = radvdPrefix.cfgInit(row, conf)
        row = util.addPrefix(row, "radvdLANPrefixPool.")
        local valid, errstr = db.update("radvdLANPrefixPool", row,
                                         row["radvdLANPrefixPool._ROWID_"])
        if (not valid) then
            radvd.dprintf("radvdPrefix.configure: failed to update radvd configuration")
            return "ERROR", "RADVD_UPDATE_FAILED"
        end            
    else
        row = radvdPrefix.defCfgGet()
        row = radvdPrefix.cfgInit(row, conf)
        row = util.addPrefix(row, "radvdLANPrefixPool.")
        local valid, errstr, rowid  = db.insert("radvdLANPrefixPool", row)
        if (not valid) then
            radvd.dprintf("radvdPrefix.configure: failed to add radvd configuration")
            return "ERROR", "RADVD_ADD_FAILED"
        end            
    end                

    radvd.restart()

    return "OK", "STATUS_OK"
end

-------------------------------------------------------------------------
-- @name radvdPrefix.config
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function radvdPrefix.config (inputTable, rowid, operation)
    -- validate
    if (db.typeAndRangeValidate(inputTable)) then
        if (operation == "add") then
            return db.insert("radvdLANPrefixPool", inputTable)
        elseif (operation == "edit") then
            return db.update("radvdLANPrefixPool", inputTable, rowid)
        elseif (operation == "delete") then
            return db.delete("radvdLANPrefixPool", inputTable)
        end
    end
    return false
end

-------------------------------------------------------------------------
-- @name radvdPrefix.profileConfig
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function radvdPrefix.profileConfig (inputTable, rowid, operation)
    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    db.beginTransaction() --begin transaction
    local valid = false
    
    valid = radvdPrefix.config(inputTable, rowid, operation)

    -- return
    if (valid) then
    	db.commitTransaction(true)
    	return "OK", "STATUS_OK"
    else
    	db.rollback()
	    return "ERROR", "RADVD_PREFIX_CONFIG_FAILED"    	
    end
end

-------------------------------------------------------------------------
-- @name radvdPrefix.deleteProfiles
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function radvdPrefix.deleteProfiles (rowIds)
    -- if not allowed to edit
    if (ACCESS_LEVEL ~= 0) then
        return "ACCESS_DENIED", "ADMIN_REQD"
    end

    db.beginTransaction() --begin transaction
    local valid = false

    -- delete rows
    for k,v in pairs(rowIds) do
        local inTable = {}
        inTable["radvdLANPrefixPool._ROWID_"] = v;
	    valid = db.delete("radvdLANPrefixPool" , inTable)
    	if (not valid) then
	        break
    	end
    end

    -- return
    if (valid) then
        db.commitTransaction(true)
        return "OK", "STATUS_OK"
    else
        db.rollback()
        return "ERROR", "RADVD_PREFIX_DELETE_FAILED"
    end
end

-------------------------------------------------------------------------
-- @name radvdPrefix.get
--
-- @description 
--
-- @param conf
--                  
-- @return 
--

function radvdPrefix.get (query)
    local rows = {}
    local index = 1
    local cfgTbl = {}

    if (query ~= nil) then
        rows = db.getRowsWhere("radvdLANPrefixPool", query, false)
    else
        rows = db.getTable("radvdLANPrefixPool", false)
    end        
    
    if (rows ~= nil) then
        for k,v in pairs(rows) do
            cfgTbl[index] = {}                
            cfgTbl[index] = v
            index = index + 1
        end            
    end

    return "OK","STATUS_OK", cfgTbl
end

