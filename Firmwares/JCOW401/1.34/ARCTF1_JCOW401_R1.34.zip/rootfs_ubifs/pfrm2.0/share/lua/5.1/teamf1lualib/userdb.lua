--[[
#### Adarsh Uppula
#### TeamF1
#### www.TeamF1.com
#### June 29, 2007

#### File: userdb.lua
#### Description: userdb functions

#### Revisions:
01k,08oct12,ash  changes for password encryption/decryption
01j,16juk13,ash  changes for user access portal 
01i,13apr10,pnm  made modification not to change previous groups of default user
01h,12apr10,pnm  added back the code that gets the db user info.
01g,09apr10,pnm  added addition check to ensure certain parameters in default
                 user and default group are not modified.
01f,02apr10,pnm  updated functions as per GUI testing
01e,31mar10,pnm  made description field optional
01d,02mar10,pnm  added editUser,editGroup, deleteUser, deleteGroup
01c,26feb10,pnm  added logic to strip leading and trailing spaces from groups
01b,23feb10,pnm  added userAdd and verifyUserInput functions
01a,19feb10,pnm  adding groups and related function
]]--


--************* Requires *************
require "teamf1lualib/util"
require "passwdSecureLib"
require "teamf1lualib/passwordStrengthChecker"

--************* Initial Code *************

--package userdb
userdb = {}

-- This properties table contains information about the size and min support
-- length for certain fields.
userdb.propTbl = {}
userdb.propTbl["nameSize"] = 32
userdb.propTbl["nameMinLen"] = 1
userdb.propTbl["descrMinLen"] = 0
userdb.propTbl["descrSize"] = 128
userdb.propTbl["passwordSize"] = 32
userdb.propTbl["passwordMinLen"] = 8

--table packages
users = {}

--************* Functions *************

-- userdb config
function userdb.users_config (inputTable, rowid, operation)
	-- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end

    --[[
	-- Check for old password
	if (not inputTable["users.loginTimeout"]) then
		local correctOldPwd = db.getAttribute("users", "users.groupname", inputTable["users.groupname"], "password")
		if (inputTable["users.oldpassword"] ~= correctOldPwd) then
    		return "ERROR", "INVALID_OLD_PASSWORD"
		end
	end
    ]]--

    db.beginTransaction() --begin transaction
	local valid = false
	
	-- config users
	rowid = db.getAttribute("users", "groupname", inputTable["users.groupname"], "_ROWID_")
	valid = users.config(inputTable, rowid, operation)
    
    if (valid and inputTable["users.username"] ~= nil) then
        if (inputTable["users.groupname"] == "admin") then
            db.setAttribute("environment", "name", "DEFAULT_SYSTEM_USER", "value", inputTable["users.username"]) 
		    db.setAttribute("snmpv3Users", "_ROWID_", "1", "userName", inputTable["users.username"])
        else
            db.setAttribute("snmpv3Users", "_ROWID_", "2", "userName", inputTable["users.username"])
        end
    end

    -- return
	if (valid) then
		db.commitTransaction(true)
		return "OK", "STATUS_OK"
	else
		db.rollback()
		return "ERROR", "USERDB_CONFIG_FAILED"
	end
end

-- radius config
function users.config (inputTable, rowid, operation)
	-- validate
	if (db.typeAndRangeValidate(inputTable)) then
		if (operation == "add") then
			return db.insert("users", inputTable)
		elseif (operation == "edit") then
			return db.update("users", inputTable, rowid)
		elseif (operation == "delete") then
			return db.delete("users", inputTable)
		end
	end
	return false
end

function userdb.passwordComplixityConfig (inputTable, rowid, operation)
	-- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end

    db.beginTransaction() --begin transaction
	local valid = false
	
    if (db.typeAndRangeValidate(inputTable)) then
        valid = db.update("passwordComplixity", inputTable, rowid)
    end

    -- return
	if (valid) then
		db.commitTransaction(true)
		return "OK", "STATUS_OK"
	else
		db.rollback()
		return "ERROR", "USERDB_CONFIG_FAILED"

	end
end

--[[
--*****************************************************************************
--userdb.verifyName - verifies if the given name is valid
--
--This routine checks for any special characters in the name provided.
--The name can have characters a-z, 0-9, _, - where the name should not
--start with _ or -. If it doesn't match this criteria, it returns an error.
--It also checks if there is already an entry in the database with this
--name given the database table name, and key, if so, it returns an error
--
--RETURN:   status - OK or ERROR
--          errorString - USERDB_INVALID_NAME - if the name contains
--                                  unsupported characters or if the
--                                  name starts with _ or -.
]]--
function userdb.verifyName (name)
    -- Verify that the name doesn't contain unsupported characters.
    if (string.match (name, "^[^\-^_^%p^%s^%c][a-zA-Z0-9\-_]*$") == nil) then
        return "ERROR", "USERDB_INVALID_NAME"
    end

	return "OK","STATUS_OK"
end

--[[
--*****************************************************************************
--userdb.verifyGroupsLength - verify length of the strings
--
--This routine verified that the send of the strings in the groupTbl are
--within the expected range.
--
--RETURN: status - OK or ERROR
--        errorString - USERDB_INVALID_NAME_LENGTH - return this if the length
--                          of group is less or more than max allow characters.
--                      USERDB_INVALID_DESCRIPTION_LENGTH - returns this if
--                          the length of the description is more than max
--                          allowed characters
]]--
function userdb.verifyGroupsLength (groupName, description)
    
    -- Verify the groupName length
    if (util.verifyLength (groupName, userdb.propTbl["nameMinLen"],
                                userdb.propTbl["nameSize"]) == false)
    then
        return "ERROR", "USERDB_INVALID_NAME_LENGTH"
    end

    -- Verify the description length
    if (description ~= nil) then
        if (util.verifyLength (description, userdb.propTbl["descrMinLen"],
            userdb.propTbl["descrSize"]) == false) then
            return "ERROR", "USERDB_INVALID_DESCRIPTION_LENGTH"
        end
    end

    return "OK", "STATUS_OK"
end

--[[
--*****************************************************************************
--userdb.verifyGroup - verifies the group input
--
--This function verifies that provided input meets the requirement given the
--group info
--
--RETURNS: status - OK or ERROR
--         errorString - USERDB_INVALID_NAME - return this value if it is
--                          invalid group name.
--                      USERDB_INVALID_NAME_LENGTH - return this if the length
--                          of group is less or more than max allow characters.
--                      USERDB_INVALID_DESCRIPTION_LENGTH - returns this if
--                          the length of the description is more than max
--                          allowed characters
--                      USERDB_INVALID_INPUT - return this when the input
--                          read/write is not valid.
]]--
function userdb.verifyGroup (groupname)
    --[[if( groupname ~= "admin" and groupname ~= "guest" ) then
        return "ERROR", "USERDB_INVALID_NAME"
    end
    ]]--
    return "OK", "USERDB_VALID_NAME"
end

--[[
--*****************************************************************************
--userd.verifyGroupInput - verifies the group input
--
--This function verifies that provided input meets the requirement given the
--group info
--
--RETURNS: status - OK or ERROR
--         errorString - USERDB_INVALID_NAME - return this value if it is
--                          invalid group name.
--                      USERDB_INVALID_NAME_LENGTH - return this if the length
--                          of group is less or more than max allow characters.
--                      USERDB_INVALID_DESCRIPTION_LENGTH - returns this if
--                          the length of the description is more than max
--                          allowed characters
--                      USERDB_INVALID_INPUT - return this when the input
--                          read/write is not valid.
--        groupTbl - updated group table.
]]--
function userdb.verifyGroupInput (tblName, groupTbl)
    local status
    local errorString
    
    -- Verify group and description length
    status, errorString = userdb.verifyGroupsLength (groupTbl["groups.name"],
                                        groupTbl["groups.descr"])
    if (status == "ERROR")
    then
        return groupTbl, status, errorString
    end

    -- Verify that groupName doesn't contain any special characters
    status, errorString = userdb.verifyName (groupTbl["groups.name"])
    if (status == "ERROR")
    then
        return groupTbl, status, errorString
    end
    
    -- Remove leading and trailing spaces
    groupTbl["groups.name"] = string.gsub (groupTbl["groups.name"],
                                        "^%s*(.-)%s*$", "%1")
    if (groupTbl["groups.descr"] ~= nil) then
        groupTbl["groups.descr"] = string.gsub (groupTbl["groups.descr"],
        "^%s*(.-)%s*$", "%1")
    end

    return groupTbl, "OK", "STATUS_OK"
end
--[[
--*****************************************************************************
--userdb.addGroup - add group to db
--
--This routine verifies the group name and adds a group to the db given the
--group table.
--
--RETURN: status - OK or ERROR
--        errorString - SYSTEM_ERROR - there are certain variables to be set
--                          by the system, but they are not set.
--                      USERDB_MAX_ERROR - there are already MAX number of
--                          groups added.
--                      USERDB_DUPLICATE_NAME - return this value if this
--                          group already exist in the db.
]]--
function userdb.addGroup (groupTbl)
    -- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end

    local tblName = "groups"
    local status = "OK"
    local errorString = "STATUS_OK"
    -- get the number of MAX groups supported by the solution
    local maxGroups = db.getAttribute ("environment", "name", "MAX_GROUPS",
                                "value")
    -- verify that the environment variable is set
    if (maxGroups == nil)
    then
        -- There is no environment variable name MAX_GROUPS. This need to be
        -- set in the solution sql file.
        return "ERROR","SYSTEM_ERROR"
    end
    
    -- Check if max entry has been reached
    if (db.tableSize (tblName) == maxGroups)
    then
        return "ERROR", "USERDB_MAX_ERROR"
    end
    
    -- Verify that the group inputs is valid
    groupTbl, status, errorString = userdb.verifyGroupInput (tblName,
                                            groupTbl)
    if (status == "ERROR")
    then
        return status, errorString
    end

    -- Verify that this name is not duplicate entry
    if (db.getRow (tblName, "name", groupTbl["groups.name"]) ~= nil)
    then
        return groupTbl, "ERROR", "USERDB_DUPLICATE_NAME"
    end

    -- add the data to db
    db.beginTransaction ()
    status, errorString = db.insert (tblName, groupTbl)
    if (status)
    then
        db.commitTransaction (true)
        return "OK", "STATUS_OK"
    else
        db.rollback()
        return "ERROR", "USERDB_CONFIG_FAILED"
    end
end

--[[
--*****************************************************************************
--userdb.deleteGroup - deletes list of group(s) from the database
--
--This routine deletes the groups from the database, given the group name list.
--If it is a default groups(s), the group cannot be deleted.
--
--RETURN: status - OK or ERROR
--        errorString - SYSTEM_ERROR - report this error when certain
--                          variables that should be set by the system are not
--                          available.
--                      USERDB_DEFAULT_GROUP - the group cannot be deleted as
--                          it is a default group.
--                      USERDB_GROUPS_BEING_USED - report this error when the
--                          group being deleted is used by a user
]]--
function userdb.deleteGroup (groupTbl)
    -- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end

    local status = "OK"
    local errorString = "STATUS_OK"
    local valid = true
    local defaultGroups = db.getAttribute ("environment", "name",
                            "DEFAULT_GROUPS", "value")
    -- verify that the environment variable is set
    if (defaultGroups == nil)
    then
        -- There is no environment variable name DEFAULT_GROUPS. This need to be
        -- set in the solution sql file.
        return "ERROR","SYSTEM_ERROR"
    end

    -- Get list of groups assign to the users
    local custQuery = "SELECT users.groupname from users"
    userGroupsList  = db.getTable ("users", false, custQuery)

    db.beginTransaction() --begin transaction

    -- Iterate through passed in groups list and find out if any of the
    -- group(s) is/are being used.
    local groupUsed
    local defaultGroup
    defaultGroups = util.split (defaultGroups, ",")
    for k,v in pairs (groupTbl)
    do
        -- Check if the given group name is being used
        groupUsed = false
        if (userGroupsList ~= nil)
        then
            for kk,vv in pairs (userGroupsList)
            do
                if (string.find (vv["groupname"], db.getAttribute ("groups", "_ROWID_", v["groups._ROWID_"], "name")) ~= nil)
                then
                    groupUsed = true
                end
            end
        end

        -- Check if the group is default
        defaultGroup = false
        for kk, vv in pairs (defaultGroups)
        do
            if (vv == v["groups.name"])
            then
                defaultGroup = true
            end
        end

        -- If the groups is not being used or not a default group, then delete
        -- the group.
        if (groupUsed == false and defaultGroup == false)
        then
            valid = db.deleteRow ("groups", "name", db.getAttribute ("groups", "_ROWID_", v["groups._ROWID_"], "name"))
        else
            status = "ERROR"
            if (groupUsed == true)
            then
                errorString = "USERDB_GROUPS_BEING_USED"
            elseif (defaultGroup == true)
            then
                errorString = "USERDB_DEFAULT_GROUP"
            end
        end
    end
    -- return
	if (valid) then
		db.commitTransaction(true)
        return status, errorString
	else
		db.rollback()
        return "ERROR", "USERDB_CONFIG_FAILED"
    end

end

--[[
--*****************************************************************************
--userdb.checkDefaultGroup - check if the given group name is default group
--
--This routine checks if the given group name is one of the default groups.
--
--RETURN: status - OK or ERROR
]]--
function userdb.checkDefaultGroup (groupTbl)
    -- get the group info to be updated from the database
    local dbGroup = db.getRow ("groups", "_ROWID_",
                    groupTbl["groups._ROWID_"])

    -- Check if the username has changed
    local defaultGroups = db.getAttribute ("environment", "name",
    "DEFAULT_GROUPS", "value")
    -- Convert the comma separated list into table. Here we are assuming
    -- that the list doesn't contain any spaces between the comma and new
    -- username
    defaultGroups = util.split (defaultGroups, ",")
    if (defaultGroups == nil) then
        return "ERROR","SYSTEM_ERROR"
    end
    
    -- iterate through default groups list and see if the name being
    -- edited match that.
    for k,v in pairs (defaultGroups) do
        util.appendDebugOut ("Default group being processed ".. v .. "<br>")
        if ((v == dbGroup["groups.name"]) and
            ((dbGroup["groups.name"] ~= groupTbl["groups.name"]) or
            (groupTbl["groups.accessLevel"] ~=
            dbGroup["groups.accessLevel"]))) then
            return "ERROR","USERDB_DEFAULT_GROUP"
        end
    end
    return "OK", "STATUS_OK"
end

--[[
--*****************************************************************************
--userdb.editGroup - updates a group into in the database
--
--This routine updates the group info in the database, given the group name info.
--If it is a default group, the user name cannot be updated.
--
--RETURN: status - OK or ERROR
--        errorString - SYSTEM_ERROR - report this error when certain
--                          variables that should be set by the system are not
--                          available.
--                      USERDB_DEFAULT_GROUP - the group cannot be deleted as
--                          it is a default group.
]]--
function userdb.editGroup (groupTbl)
    -- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end

    local status
    local errorStr

    -- Verify that the group inputs is valid
    groupTbl, status, errorString = userdb.verifyGroupInput ("groups",
                                            groupTbl)
    if (status == "ERROR")
    then
        return status, errorString
    end

    status, errorString = userdb.checkDefaultGroup (groupTbl)
    if (status == "ERROR") then
        return status, errorString
    end

    -- get the user name to be updated from the database
    local dbGroup = db.getAttribute ("groups", "_ROWID_",
                        groupTbl["groups._ROWID_"], "name")
    
    db.beginTransaction ()
    -- add the data to db
    status, errorString = db.update ("groups", groupTbl,
                                groupTbl["groups._ROWID_"])

    -- Update the group membership of the users
    local customQuery = "SELECT users.username,users.groupname from users"
    local userList = db.getTable ("users", false, customQuery)
    local count
    for k,v in pairs (userList)
    do
        v["groupname"], count = string.gsub (v["groupname"], dbGroup,
                                    groupTbl["groups.name"])
        if (count > 0)
        then
            status = db.setAttribute ("users", "username", v["username"],
                                "groupname", v["groupname"])
        end
    end

    if (status)
    then
        db.commitTransaction (true)
        return "OK", "STATUS_OK"
    else
        db.rollback()
        return "ERROR", "USERDB_CONFIG_FAILED"
    end
end

--[[
--*****************************************************************************
--userdb.verifyGroupList - verifies if the group list provided is correct
--
--This routine verifies if the group in the given group list is valid (meaning
--already added in the database).
--
--RETURN: status - OK or ERROR
--        errorString - USERDB_GROUP_NOT_FOUND - report this error, if the
--                                  a group name is not there in the database.
--                      USERDB_GROUP_INVALID - report this if the group name
--                                  is not valid.
]]--
function userdb.verifyGroupList (groupList)
    -- Convert comma separate list of groups to table
    local div = ",[ \t]*"
    local newGroupList = ""
    if (groupList == "")
    then
        return "ERROR", "USERDB_INVALID_GROUP", newGroupList
    end
    local pos,groupsTbl = 0,{}
    -- for each divider found
    for st,sp in function() return string.find(groupList,div,pos) end do
	    table.insert(groupsTbl,string.sub(groupList,pos,st-1)) -- Attach chars left of current divider
	    pos = sp + 1 -- Jump past current divider
    end
    local lastStr = string.sub(groupList, pos)
    if (lastStr ~= "")
    then
        table.insert(groupsTbl,lastStr) -- Attach chars right of last divider
    end

    -- Verify that the provide groups doesn't contain any invalid characters
    -- and that the group name provided does exist in the database.
    local allGroups = db.getTable ("groups", false)
    local foundGroup
    for k, v in pairs (groupsTbl)
    do
        -- Verify the group name
        status, errorString = userdb.verifyName (v)
        if (status == "ERROR")
        then
            return status, errorString, newGroupList
        else
            -- Group name is valid. Now let's check if the group name exist in
            -- the database.
            if (k == 1)
            then
                newGroupList = v
            else
                newGroupList = newGroupList..","..v
            end
            foundGroup = false
            for kk,vv in pairs (allGroups)
            do
                if (vv["name"] == v)
                then
                    foundGroup = true
                    break
                end
            end
            if (foundGroup == false)
            then
                return "ERROR", "USERDB_GROUP_NOT_FOUND", newGroupList
            end
        end
    end

    return "OK", "STATUS_OK", newGroupList
end


--[[
--*****************************************************************************
--userdb.verifyUserInput - validates the user info
--
--This routine verifies if the given user information provided matches the
--criteria specified. The function will verify that the length of username and
--password falls in correct range. It also verifies that username and password
--does not contain any unsupported characters. It then finally verifies that
--the list of groups associated with this user do exist in the database.
--
--RETURN: status - OK or ERROR
--        errorString - USERDB_INVALID_NAME_LENGTH - report this error
--                              message when the name is not between 1 - MAX
--                              support characters
--                      USERDB_INVALID_PASSWORD_LENGTH - report this error
--                              message when the password is not between min-
--                              MAX support characters.
--                      USERDB_INVALID_LOGINTIMEOUT - report this error if
--                              login timeout is not within a range.
--                      USERDB_INVALID_PASSWORD - password contains invalid
--                              characters
--                      USERDB_DUPLICATE_NAME - return this value if this
--                          group already exist in the db.

]]--
function userdb.verifyUserInput (userTbl)
    local status
    local errorString

    -- Verify the length of user name
    if (util.verifyLength (userTbl["users.username"], userdb.propTbl["nameMinLen"],
                                userdb.propTbl["nameSize"]) == false)
    then
        return "ERROR", "USERDB_INVALID_NAME_LENGTH"
    end
    
    -- Verify the length of password
    if (util.verifyLength (userTbl["users.password"],
                userdb.propTbl["passwordMinLen"],
                userdb.propTbl["passwordSize"]) == false)
    then
        return "ERROR", "USERDB_INVALID_PASSWORD_LENGTH"
    end

    -- Verify that the username doesn't contain any invalid characters
    status,errorString = userdb.verifyName (userTbl["users.username"])
    if (status == "ERROR")
    then
        return status, errorString
    end

    -- Verify that the password doesn't contain space, single or double quotes.
    if (string.match (userTbl["users.password"], "^[^\"\'%s]*$") == nil)
    then
        return "ERROR", "USERDB_INVALID_PASSWORD"
    end

   --verify that password doesn't contain non ascii characters
    status,errorString = util.validPasswordCheck(userTbl["users.password"])
    if (status == "ERROR") then
        return "ERROR", errorString
    end

    --Verify that user password is not set to restricted password
    local error_msg = userdb.passwordCheck(userTbl["users.password"])
    if (error_msg) then
        return "ERROR", error_msg
    end
    --status,errorString, userTbl["users.groupname"] = userdb.verifyGroupList (userTbl["users.groupname"])
    status,errorString = userdb.verifyGroup (userTbl["users.groupname"])

    return status, errorString, userTbl
end

--[[
--*****************************************************************************
--userdb.addUser - adds the user to the database
--
--This routine verifies the given input and then add the user to the database.
--
--RETURN: status - OK or ERROR
--        errorString - SYSTEM_ERROR - report this error when certain
--                          variables that should be set by the system are not
--                          available.
--                        USERDB_MAX_ERROR - there are already MAX number of
--                          users entered into the database.
]]--
function userdb.addUser (userTbl)
    -- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end

    local status
    local errorString

    status, errorString = userdb.verifyUserInput (userTbl)
    if (status == "ERROR")
    then
        return status, errorString
    end
    
    --TODO: encrypt the password and update the password entry
    return userdb.users_config (userTbl, -1, "add")
end

--[[
--*****************************************************************************
--userdb.deleteUser - deletes list of user(s) from the database
--
--This routine deletes the users from the database, given the user name list.
--If it is a default user(s), the user cannot be deleted.
--
--RETURN: status - OK or ERROR
--        errorString - SYSTEM_ERROR - report this error when certain
--                          variables that should be set by the system are not
--                          available.
--                        USERDB_DEFAULT_USER - the user cannot be deleted as
--                          it is a default user.
]]--
function userdb.deleteUser (userTbl)
    -- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end

    local username = nil
    local status = "OK"
    local errorString = "STATUS_OK"
    local defaultUsers = db.getAttribute ("environment", "name",
                            "DEFAULT_USERS", "value")
    -- verify that the environment variable is set
    if (defaultUsers == nil)
    then
        -- There is no environment variable name DEFAULT_USERS. This need to be
        -- set in the solution sql file.
        return "ERROR","SYSTEM_ERROR"
    end

    -- Convert the comma separated list into table. Here we are assuming that
    -- the list doesn't contain any spaces between the comma and new username
    defaultUsers = util.split (defaultUsers, ",")
    db.beginTransaction() --begin transaction
    local valid = false
    local defaultUser = false
    for k,v in pairs (userTbl)
    do
        for kk,vv in pairs (defaultUsers)
        do
            if (vv == db.getAttribute ("users", "_ROWID_", v["users._ROWID_"],
                "username")) then
                defaultUser = true
            end
        end
        -- Given user is not default user, then delete the user
        if (defaultUser == false)
        then
            username = db.getAttribute ("users", "_ROWID_", v["users._ROWID_"],"username")
            if (username ~= nil) then
                if (db.existsRow("loginSession", "username", username)) then
                    return "ERROR", "USERDB_USER_LOGGED_IN"
                end
            end
            valid = users.config (v,v["users._ROWID_"], "delete")
           
        else
            return "ERROR", "USERDB_DEFAULT_USER"
        end
    end

    -- return
	if (valid) then
		db.commitTransaction(true)
        return status, errorString
	else
		db.rollback()
        return "ERROR", "USERDB_CONFIG_FAILED"
    end

end

--[[
--*****************************************************************************
--userdb.checkDefaultUser - check if the given user name is default user
--
--This routine checks if the given user name is one of the default users.
--
--RETURN: status - OK or ERROR
]]--
function userdb.checkDefaultUser (userTbl)
    -- get the user info to be updated from the database
    local dbUser = db.getRow ("users", "_ROWID_",
                    userTbl["users._ROWID_"])

    -- Check if the username has changed
    local defaultUsers = db.getAttribute ("environment", "name",
    "DEFAULT_USERS", "value")
    -- Convert the comma separated list into table. Here we are assuming
    -- that the list doesn't contain any spaces between the comma and new
    -- username
    defaultUsers = util.split (defaultUsers, ",")
    if (defaultUsers == nil) then
        return "ERROR","SYSTEM_ERROR"
    end
    
    -- iterate through default users list and see if the name being
    -- edited match that.
    local defaultGroups = db.getAttribute ("environment", "name",
    "DEFAULT_GROUPS", "value")
    if (defaultGroups == nil) then
        return "ERROR","SYSTEM_ERROR"
    end

    local oldGroups = util.split (dbUser["users.groupname"], ",")
    local oldGroupRemoved = true
    defaultGroups = util.split (defaultGroups, ",")
    local defaultGroupRemoved = true
    for k,v in pairs (defaultUsers) do
        if (v == dbUser["users.username"]) then

            -- check if the user name is modified
            if (dbUser["users.username"] ~= userTbl["users.username"]) then
                return "ERROR","USERDB_DEFAULT_USER"
            end

            -- check if the default group is removed
            defaultGroupRemoved = true
            for kk,vv in pairs (defaultGroups) do
                util.appendDebugOut ("Progressing default group " .. vv ..
                "<br>")
                if (string.find (userTbl["users.groupname"], vv) ~= nil) then
                    defaultGroupRemoved = false
                    break
                end
            end
            if (defaultGroupRemoved == true) then
                return "ERROR","USERDB_DEFAULT_USER"
            end
            
            -- Check if the old group assigned is removed 
            oldGroupRemoved = false
            for kk,vv in pairs (oldGroups) do
                util.appendDebugOut ("Processing old group " .. vv .. "<br>")
                if (string.find (userTbl["users.groupname"], vv) == nil) then
                    oldGroupRemoved =true
                end
            end
            if (oldGroupRemoved == true) then
                return "ERROR","USERDB_DEFAULT_GROUP"
            end

        end
    end
    return "OK", "STATUS_OK"
end

--[[
--*****************************************************************************
--userdb.editUser - updates a user into in the database
--
--This routine updates the users info in the database, given the user name info.
--If it is a default user, the user name cannot be updated.
--
--RETURN: status - OK or ERROR
--        errorString - SYSTEM_ERROR - report this error when certain
--                          variables that should be set by the system are not
--                          available.
--                      USERDB_DEFAULT_USER - the user cannot be deleted as
--                          it is a default user.
]]--
function userdb.editUser (userTbl)
    -- if not allowed to edit
	if (ACCESS_LEVEL ~= 0) then
		return "ACCESS_DENIED", "ADMIN_REQD"
	end

    local status
    local errorString
	local valid

    -- Verify the user input 
    status, errorString = userdb.verifyUserInput (userTbl)
    if (status == "ERROR")
    then
        return status, errorString
    end

    status, errorString = userdb.checkDefaultUser (userTbl)
    if (status == "ERROR") then
        return status, errorString
    end

    valid = users.config (userTbl, userTbl["users._ROWID_"], "edit")
    if (valid) then
        return "OK", "STATUS_OK"
    else
        return "ERROR", "USERDB_CONFIG_FAILED"
    end
end

function userdb.isUserAdmin(username)
	if (username == "admin") then
		return true
	end

	return false
end

--*****************************************************************************
	--Component specific functions
--******************************************************************************
--@name  userdb.setPasswd
--
--@description The function set the password for the admin
--
--@return

function userdb.setPasswd(inputTable)
	
	--local 
	local query = {}
	local passwordTbl = {}

	--setting up the password
	query = "username='admin'"
	passwordTbl = db.getRowWhere("users", query, true)
	if (passwordTbl ~= nil) then
		passwordTbl["users.password"] = inputTable["password"]
		users.config(passwordTbl, passwordTbl["users._ROWID_"], "edit")
	end

end

--*****************************************************************************
--@name userdb.usersGet()
--
--@description This routine makes db call to extract the information about table "users".
--It then iterate through the list and provide table output in form expected
--by the gui.
--
--@return

function userdb.usersGet()

	--locals
    local inputTable = {}
	local userTbl = {}    	
    
	-- Get the list of users from db
	local userTbl = db.getTable ("users", false)
	if (userTbl == nil) then
		return  inputTable
	end 
 
	--return
	return userTbl

end
--*******************************************************************************
--@name userdb.usersAddGet()
--
--@description This routine makes db call to get list of groups in the database. It then
--converts the list in form that is expected by the gui.
--
--@return

function userdb.usersAddGet()

	--locals
	local inputTable = {}
	local userTbl = {}   
    userTbl.groupname = {}
    
    userTbl.groupname = db.getDistinctValues ("groups", "name")

    util.appendDebugOut (util.tableToStringRec (userTbl, 1))
    
	--return
	return userTbl
end

--*********************************************************************************
--@name userdb.usersAddSet(inputTable)
--
--@description This routine takes the info provided and set the data in the backend by
--calling appropriate routine.
--
--@return

function userdb.usersAddSet(inputTable)

	--locals 			
	local userTbl = {}
    local statusMsg = nil
	local errMsg = nil
  
    -- Assign values to userTbl as expected by the backend routine
    userTbl["users.username"] = inputTable["username"]
    userTbl["users.password"] = inputTable["password"]
    userTbl["users.descr"] = inputTable["descr"]
    userTbl["users.groupname"] = inputTable["groupname"]
    userTbl["users.enableAccess"] = inputTable["enableAccess"]
    userTbl["users.loginTimeout"] = inputTable["loginTimeout"]
    
	statusMsg, errMsg = userdb.addUser (userTbl)

    -- save db if no error
    if (statusMsg == "OK") then db.save() end
    
    --return
	return statusMsg, errMsg

end	

--******************************************************************************
--@name userdb.usersEditGet(rowid)
--
--@description This routine makes db call to extract a user from db given the rowid of the
--row. It will also extract all the groups from the groups table and convert
--that into a table form indicating which groups are selected and which are
--not selected. It then converts the user info into the form expected by the gui.
--
--@return 

function userdb.usersEditGet(rowid) 

	-- Local 
    local inputTable = {}
	local userTbl = {}   
    userTbl.groups = {}
    
    userTbl.groups = db.getDistinctValues ("groups", "name")

	-- get the row from db
    inputTable = db.getRow ("users", "_ROWID_", rowid)
    
	-- Assign value to page table.
    userTbl["username"] = inputTable["users.username"]
    userTbl["password"] = util.mask (inputTable["users.password"])
	userTbl["descr"] = inputTable["users.descr"]
    userTbl["_ROWID_"] = inputTable["users._ROWID_"]
	userTbl["groupname"] = inputTable["users.groupname"]
	userTbl["enableAccess"] = inputTable["users.enableAccess"]
	userTbl["loginTimeout"] = inputTable["users.loginTimeout"]

    util.appendDebugOut (util.tableToStringRec (userTbl, 1))
    
	--return
	return userTbl
end

--******************************************************************************
--@name userdb.usersEditSet(inputTable)
--
--@description This routine takes the info provided and set the data in the backend by
--calling appropriate routine.
--
--@return

function userdb.usersEditSet(inputTable) 

	-- Locals
    local userTbl = {}
    local oldUserTbl = {}
    local newUserTbl = {}
	local statusMsg = nil
	local errMsg = nil  
	local retVal = nil 
    local isPasswdChanged = false
 
    -- gets the old row in "users" table for the given rowid
    oldUserTbl = db.getRow("Users", "_ROWID_", inputTable["_ROWID_"])

    -- Assign values to userTbl as expected by the backend routine
    userTbl["users.username"] = inputTable["username"]
    if (inputTable["password"] ~= nil) then
        if (util.isAllMasked (inputTable["password"])) then
            userTbl["users.password"] = db.getAttribute ("users","username",inputTable["username"],"password")
        else
            userTbl["users.password"] = inputTable["password"]
        end
    end    
    userTbl["users._ROWID_"] = inputTable["_ROWID_"]
    userTbl["users.groupname"] = inputTable["groupname"]
    userTbl["users.descr"] = inputTable["descr"]
    userTbl["users.enableAccess"] = inputTable["enableAccess"]
    userTbl["users.loginTimeout"] = inputTable["loginTimeout"]
   
	 util.appendDebugOut (util.tableToStringRec (inputTable, 1))
	statusMsg, errMsg = userdb.editUser (userTbl)

    -- gets the old row in "users" table for the given rowid
    newUserTbl = db.getRow("Users", "_ROWID_", inputTable["_ROWID_"])

    if (oldUserTbl ~= nil and newUserTbl ~= nil) then
        isPasswdChanged, retVal = userdb.userLoginCredChanged (oldUserTbl, newUserTbl)
    end

    -- save db if no error
    if (statusMsg == "OK") then db.save() end

    if (isPasswdChanged) then
 
        require "loginLib"
	-- logout
	local result = login.logout(cgilua.cookies.get("TeamF1Login"), SAPI.Request.servervariable("REMOTE_ADDR"))
	--if success, delete cookie
	if (result == 0) then
            cgilua.cookies.set("TeamF1Login", cgilua.cookies.get("TeamF1Login"), {expires=-1})
            util.appendDebugOut("SUCCESSFULLY LOGGED OUT!<br>")
        end

        NextPage = "index"
        errMsg = retVal
    end

    --return
	return statusMsg, errMsg

end

--******************************************************************************
--@name userdb.usersDelete(rowids)
--
--@description -This routine takes a entry with list of users to be deleted. It then
--converts that list into form expected by the backend mgmt code to delete the
--user from the db and also the backend.
--
--@return


function userdb.usersDelete(rowids)

	-- locals
    local usersTbl = {}
	local statusMsg = nil
	local errMsg = nil  
	
 
    for i,v in pairs (rowids) do
        usersTbl[i] = {}
        usersTbl[i]["users._ROWID_"] = v
    end

	statusMsg, errMsg = userdb.deleteUser (usersTbl)
	if (statusMsg ~= "OK") then
		return statusMsg, errMsg
	end

    -- save the database
    if (statusMsg == "OK") then db.save() end

	-- delete quota for this user
	--return
	return statusMsg, errMsg
end

--*****************************************************************************
--@name userdb.groupsGet()
--
--@description This routine makes db call to extract the information about table "groups".
--It then iterate through the list and provide table output in form expected
--by the gui.
--
--@return

function userdb.groupsGet()

	--locals
    local inputTable = {}
	local groupTbl = {}    	
    
	-- Get the list of users from db
	local groupTbl = db.getTable ("groups", false)
	if (groupTbl == nil) then
		return  inputTable
	end 
 
	--return
	return groupTbl

end
--*******************************************************************************
--@name userdb.groupsAddGet()
--
--@description This routine makes db call to get list of groups in the database. It then
--converts the list in form that is expected by the gui.
--
--@return

function userdb.groupsAddGet()

	--locals
	local inputTable = {}
	local groupTbl = {}   

    -- setting default groupname, just for displaying purpose.
    groupTbl.name = "admin"
	
    util.appendDebugOut (util.tableToStringRec (groupTbl, 1))
    
	--return
	return groupTbl
end

--*********************************************************************************
--@name userdb.groupsAddSet(inputTable)
--
--@description This routine takes the info provided and set the data in the backend by
--calling appropriate routine.
--
--@return

function userdb.groupsAddSet(inputTable)

	--locals 			
	local groupTbl = {}
    local statusMsg = nil
	local errMsg = nil
  
    -- Assign values to userTbl as expected by the backend routine
    groupTbl["groups.name"] = inputTable["name"]
    groupTbl["groups.descr"] = inputTable["descr"]
    groupTbl["groups.capabilities"] = inputTable["capabilities"]
    if(inputTable["capabilities"] == "3" or inputTable["capabilities"] == "10") then
        groupTbl["groups.accessLevel"] = "1"
    else
        groupTbl["groups.accessLevel"] = "0"
    end
    
	statusMsg, errMsg = userdb.addGroup (groupTbl)

    -- save db if no error
    if (statusMsg == "OK") then db.save() end
    
    --return
	return statusMsg, errMsg

end	

--******************************************************************************
--@name userdb.groupsEditGet(rowid)
--
--@description This routine makes db call to extract a group from db given the rowid of the
--row. It will also extract all the groups from the groups table and convert
--that into a table form indicating which groups are selected and which are
--not selected. It then converts the user info into the form expected by the gui.
--
--@return 

function userdb.groupsEditGet(rowid) 

	-- Local 
    local inputTable = {}
	local groupTbl = {}   
 
	-- get the row from db
    inputTable = db.getRow ("groups", "_ROWID_", rowid)
    
	-- Assign value to page table.
    groupTbl["name"] = inputTable["groups.name"]
	groupTbl["descr"] = inputTable["groups.descr"]
    groupTbl["_ROWID_"] = inputTable["groups._ROWID_"]
	groupTbl["accessLevel"] = inputTable["groups.accessLevel"]
	groupTbl["capabilities"] = inputTable["groups.capabilities"]

    util.appendDebugOut (util.tableToStringRec (groupTbl, 1))
    
	--return
	return groupTbl
end

--******************************************************************************
--@name userdb.groupsEditSet(inputTable)
--
--@description This routine takes the info provided and set the data in the backend by
--calling appropriate routine.
--
--@return

function userdb.groupsEditSet(inputTable) 

	-- Locals
    local groupTbl = {}
    local oldGroupTbl = {}
    local newGroupTbl = {}
	local statusMsg = nil
	local errMsg = nil  
	local retVal = nil 
 
    -- gets the old row in "groups" table for the given rowid
    oldGroupTbl = db.getRow("groups", "_ROWID_", inputTable["_ROWID_"])

    -- Assign values to groupTbl as expected by the backend routine
    groupTbl["groups.name"] = inputTable["name"]    
    groupTbl["groups._ROWID_"] = inputTable["_ROWID_"]
    groupTbl["groups.descr"] = inputTable["descr"]
    groupTbl["groups.accessLevel"] = inputTable["accessLevel"]
    groupTbl["groups.capabilities"] = inputTable["capabilities"]
   
	 util.appendDebugOut (util.tableToStringRec (inputTable, 1))
	statusMsg, errMsg = userdb.editGroup (groupTbl)

    -- save db if no error
    if (statusMsg == "OK") then db.save() end

    --return
	return statusMsg, errMsg

end

--******************************************************************************
--@name userdb.groupsDelete(rowids)
--
--@description -This routine takes a entry with list of groups to be deleted. It then
--converts that list into form expected by the backend mgmt code to delete the
--groups from the db and also the backend.
--
--@return


function userdb.groupsDelete(rowids)

	-- locals
    local groupsTbl = {}
	local statusMsg = nil
	local errMsg = nil  
	
 
    for i,v in pairs (rowids) do
        groupsTbl[i] = {}
        groupsTbl[i]["groups._ROWID_"] = v
    end

	statusMsg, errMsg = userdb.deleteGroup (groupsTbl)
	if (statusMsg ~= "OK") then
		return statusMsg, errMsg
	end

    -- save the database
    if (statusMsg == "OK") then db.save() end

	-- delete quota for this user
	--return
	return statusMsg, errMsg
end

--******************************************************************************
	--End
--*****************************************************************************
function userdb.import (configTable, defaultCfg, removeCfg)
    if (configTable == nil) then
        configTable = defaultCfg
    end

    local groupTbl = {}
    local usersTbl = {}
    local status

    groupTbl = config.update (configTable.groups, defaultCfg.groups, removeCfg.groups)
    usersTbl = config.update (configTable.users, defaultCfg.users, removeCfg.users)
   
    if (groupTbl ~= nil and #groupTbl ~= 0) then
        for i,v in ipairs (groupTbl) do
            if (v["name"] == "guest") then
                v["capabilities"] = "4"
            elseif (v["name"] == "admin") then
                v["capabilities"] = "3"
            else
                v["capabilities"] = "10"
            end
            v = util.addPrefix (v, "groups.");
            userdb.addGroup (v);
        end
    end

    if (usersTbl ~= nil and #usersTbl ~= 0) then
        for i,v in ipairs (usersTbl) do
            if (v["password"] ~= nil and v["password"] ~= "") then
                status, v["password"] = passwdSecureLib.decryptData (v["password"], "")
            end
            if (v["username"] == "guest") then
                if(v["enableAccess"] == nil) then
                    v["enableAccess"] = "0"
                end
            elseif (v["username"] == "admin") then
                    v["enableAccess"] = "1"
                    if ( util.fileExists("/pfrm2.0/DEVICE_REPEATER")) then
                    	if (not(util.fileExists("/flash/updatePasswd"))) then
                        	local file = io.open("/flash/updatePasswd","w")
                        	if (file ~= nil) then
                            	file:close()
                        	end
    						local cmdStr = "/userfs/bin/tcapi get Account.Entry.2 web_passwd > /tmp/adminPasswd"
                        	os.execute(cmdStr)
                        	local adminpasswd = util.fileToString("/tmp/adminPasswd")
                        	adminpasswd=adminpasswd:sub(1,(#adminpasswd -1))
                        	v["password"] = adminpasswd
                    	end
                    end
            elseif (v["username"] == "meshadmin") then
                    v["enableAccess"] = "1"
                    v["password"] = util.fileToString("/tmp/deviceSerial")
            else
                if(v["enableAccess"] == nil) then
                    v["enableAccess"] = "1"
                end
            end

            v = util.addPrefix (v, "users.");
            userdb.users_config (v, -1, "add");
        end
    end
end

function userdb.export ()
    local userdbConfig = {}
    local status
    userdbConfig["users"] = db.getTable ("users", false)
    for i, v in ipairs (userdbConfig["users"]) do
        if (v["password"] ~= nil and v["password"] ~= "") then
            status, userdbConfig["users"][i].password = passwdSecureLib.encryptData (v["password"], "")
        end
    end
    userdbConfig["groups"] = db.getTable ("groups", false)
    return userdbConfig
end

if (config.register) then
    config.register("userdb", userdb.import, userdb.export, "1")
end

--[[
***************************************************************************
* userdb.userLoginCredChanged - checks if login credentials of the currently
* logged in user has changed.
*
* Returns: true or false
--]]
function userdb.userLoginCredChanged(oldTbl, newTbl)
    
    local myCookie = cgilua.cookies.get("TeamF1Login")
    local loggedinUser = db.getAttribute ("loginSession", "Cookie", myCookie, "username") or ''
    local oldPwd = oldTbl["Users.password"]
    local oldUname = oldTbl["Users.username"]
    local newPwd = newTbl["Users.password"]
    local newUname = newTbl["Users.username"]
    if (oldUname == loggedinUser and (oldPwd ~= newPwd or oldUname ~= newUname)) then
        if(oldPwd ~= newPwd) then
            return true, "PASSWORD_CHANGED"
        end
        if (oldUname ~= newUname) then
            return true, "USERNAME_CHANGED"
        end
    end
    -- if user's credentials are changed by administrator, make sure he is logged out
    -- and he has to login again with new credentials
    if (db.existsRow("loginSession", "username", oldUname)) then
        if (oldUname ~= loggedinUser and oldPwd ~= newPwd) then
            db.setAttribute("loginSession", "username", oldUname, "loginState", "EXPIRED_PWD_CHANGED")
        end
    end
    
    return false, "CREDENTIALS_UNCHANGE"
end
--***************************************************************************
--userdb.passwordCheck - Verify whether password is not restricted password.
--
--Returns: error message or nil
function userdb.passwordCheck(inputPassword)
    if (inputPassword ~= nil) then
        -- Verify that user password is not set to restricted password
        local lowerPassword = string.lower(inputPassword)
        -- set restricted password always in lower
        local restrictedPasswordList = {'jio', 'ril', 'reliance', 'rjil', 'jiocentrum'}
        for _, restrictedPassword in pairs(restrictedPasswordList) do 
            if (string.match (lowerPassword, restrictedPassword)) then 
                return "PASSWORD_NOT_ALLOWED"
            end 
        end
        -- Check password strength
        strongPassword="strong"
        reasonablePassword="reasonable"
        passwd_strength_info = passwdStrChk.passwd_Status(inputPassword)
        if not (string.match ( string.lower (passwd_strength_info), strongPassword)) then
            if not (string.match ( string.lower (passwd_strength_info), reasonablePassword)) then
                return passwd_strength_info
            end
        end
    end
end
--***************************************************************************
