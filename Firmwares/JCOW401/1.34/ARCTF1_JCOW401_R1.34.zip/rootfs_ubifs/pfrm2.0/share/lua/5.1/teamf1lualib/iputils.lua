--[[
#### Copyright (c) 2014-2015, TeamF1 Networks Pvt. Ltd. 
#### (Subsidiary of D-Link India)
#### 
#### File: iputils.lua
####
#### Revisions:
01a,02Nov15,swr  Changes for SPR 53930.
]]--

require "teamf1lualib/db"
require "teamf1lualib/util"

function systemDBConnect ()
    db.connect("/tmp/system.db")
end

function RouteHopsUpdate (tableName)
    if (tableName ~= "RouteHops") then
        return
    end

    -- connect to system.db
    systemDBConnect()

    os.execute ("sleep 2")

    -- delete all existing rows
    local query = "delete from RouteHops where Enable='1'"
    db.execute(query)

    sval,serrcode = pcall (loadfile ("/var/doTraceRoute.out"))
    if (sval) then
        dofile ("/var/doTraceRoute.out")
        local diagTbl = util.getLuaVariable("diag")
        if (diagTbl ~= nil) then
            for k,v in pairs (diagTbl) do
                local confRow = v
                confRow["Enable"] = 1
                confRow = util.addPrefix(confRow, "RouteHops.")
                db.insert("RouteHops",confRow)
            end
        end
    end
end

function ResultUpdate (tableName)
    if (tableName ~= "Result") then
        return
    end
    local confRow = {}
    -- connect to system.db
    systemDBConnect()

    os.execute ("sleep 2")

    -- delete all existing rows
    local query = "delete from Result where rowid=1"
    db.execute(query)

    sval,serrcode = pcall (loadfile ("/var/nsLookUp.out"))
    if (sval) then
        dofile ("/var/nsLookUp.out")
        local nslookTbl = util.getLuaVariable("nslook")
        if (nslookTbl ~= nil) then
            if(nslook["AnswerType"] ~= nil and nslook["HostNameReturned"] ~= nil and nslook["DNSServerIP"] ~= nil) then
                confRow ["Result.Status"] = "Success"
                confRow ["Result.AnswerType"] = nslook["AnswerType"]
            elseif(nslook["AnswerType"] == nil and nslook["IPAddresses"] == nil and nslook["HostNameReturned"] == nil) then
                confRow ["Result.Status"] = "Error_HostNameNotResolved"
                confRow ["Result.AnswerType"] = "None"
            else
                confRow ["Result.Status"] = "Error_Other"
                confRow ["Result.AnswerType"] = "None"
            end
        else
            confRow ["Result.Status"] = "Error_Other"
        end
            
        confRow ["Result.HostNameReturned"] = nslook["HostNameReturned"] or ''
        confRow ["Result.IPAddresses"] = nslook["IPAddresses"] or ''
        confRow ["Result.DNSServerIP"] = nslook["DNSServerIP"] or ''
            
        if(confRow ["Result.Status"] == "Success") then
            local file = io.open("/var/nsRespTime.txt", "r") 
            if(file ~= nil) then
                local line = file:read()
                local resTime, tmp = string.sub(line, 6)
                local time = util.split(resTime, " ")
                local min = string.gsub(time[1],'m', '')
                local sec = string.gsub(time[2],'s', '')
                local responseTime = (min*60000) + (sec*1000)
                confRow ["Result.ResponseTime"] = responseTime or "0"
                file:close()
            else
                confRow ["Result.ResponseTime"] = "0"
            end
        else
            confRow ["Result.ResponseTime"] = "0"
        end

        db.insert("Result",confRow)
    else
        confRow ["Result.Status"] = "Error_DNSServerNotAvailable"
        confRow ["Result.AnswerType"] = "None"
        confRow ["Result.HostNameReturned"] = ''
        confRow ["Result.IPAddresses"] = ''
        confRow ["Result.DNSServerIP"] = ''
        confRow ["Result.ResponseTime"] = "0"
        db.insert("Result",confRow)
    end
end
