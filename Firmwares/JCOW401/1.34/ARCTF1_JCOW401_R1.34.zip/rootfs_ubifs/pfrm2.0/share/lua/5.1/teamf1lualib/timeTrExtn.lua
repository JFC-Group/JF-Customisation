--[[
#### 
#### File: tr181_timeTrExtn.lua
#### Description: 
#### TR-181 handlers for time. This file is included from tr181_tr69funcs.lua
####
]]--

timeTr = {}

--Map supported timeZones according to POSIX format. Refer 'man 3 tzset'.
--Here, keys determine value of ntp.timezone.
local timeZoneMapping = {
    [0]={["tzposix"]="GMT", ["tzoff"]="00:00"},
    [1]={["tzposix"]="Y+12:00", ["tzoff"]="-12:00"},
    [2]={["tzposix"]="SST+11:00",   ["tzoff"]="-11:00"},
    [3]={["tzposix"]="HAST+10:00",  ["tzoff"]="-10:00"},
    [4]={["tzposix"]="MART+09:30",  ["tzoff"]="-09:30"},
    [5]={["tzposix"]="AKST+09:00AKDT+08:00,M3.2.0,M11.1.0", ["tzoff"]="-09:00"},
    [6]={["tzposix"]="PST+08:00PDT+07:00,M3.2.0,M11.1.0",   ["tzoff"]="-08:00"},
    [10]={["tzposix"]="MST+07:00MDT+06:00,M3.2.0,M11.1.0",  ["tzoff"]="-07:00"},
    [12]={["tzposix"]="CST+06:00CDT+05:00,M4.1.0,M10.4.0",  ["tzoff"]="-06:00"},
    [12]={["tzposix"]="CST+06:00CDT+05:00,M3.2.0,M11.1.0",  ["tzoff"]="-06:00"},
    [13]={["tzposix"]="EST+05:00EDT+04:00,M3.2.0,M11.1.0",  ["tzoff"]="-05:00"},
    [15]={["tzposix"]="VET+04:30",  ["tzoff"]="-04:30"},
    [16]={["tzposix"]="AST+04:00ADT+03:00,M3.2.0,M11.1.0",  ["tzoff"]="-04:00"},
    [17]={["tzposix"]="NST+03:30NDT+02:30,M3.2.0,M11.1.0",  ["tzoff"]="-03:30"},
    [18]={["tzposix"]="BRT+03:00BRST+02:00,M2.3.0/00:00:00,M10.3.0/00:00:00",   ["tzoff"]="-03:00"},
    [19]={["tzposix"]="O+02:00",    ["tzoff"]="-02:00"},
    [20]={["tzposix"]="AZOT+01:00AZOST,M3.5.0/01:00:00,M10.4.0/01:00:00",   ["tzoff"]="-01:00"},
    [21]={["tzposix"]="CET-01:00CEST-02:00,M10.4.0/01:00:00,M3.5.0/01:00:00",   ["tzoff"]="+01:00"},
    [22]={["tzposix"]="EET-02:00EEST-03:00,M10.4.0/01:00:00,M3.5.0/01:00:00",   ["tzoff"]="+02:00"},
    [23]={["tzposix"]="AST-03:00",  ["tzoff"]="+03:00"},
    [25]={["tzposix"]="GST-04:00",  ["tzoff"]="+04:00"},
    [26]={["tzposix"]="AFT-04:30",  ["tzoff"]="+04:30"},
    [27]={["tzposix"]="PKT-05:00PKT-06:00,M10.1.0/00:00:00,M4.1.0/00:00:00",    ["tzoff"]="+05:00"},
    [28]={["tzposix"]="IST-05:30",  ["tzoff"]="+05:30"},
    [29]={["tzposix"]="BST-06:00",  ["tzoff"]="+06:00"},
    [30]={["tzposix"]="MMT-06:30",  ["tzoff"]="+06:30"},
    [31]={["tzposix"]="WIB-07:00",  ["tzoff"]="+07:00"},
    [32]={["tzposix"]="CST-08:00",  ["tzoff"]="+08:00"},
    [33]={["tzposix"]="JST-09:00",  ["tzoff"]="+09:00"},
    [34]={["tzposix"]="ACST-09:30ACDT-10:30,M10.1.0,M4.1.0/03:00:00",   ["tzoff"]="+09:30"},
    [35]={["tzposix"]="AEST-10:00AEDT-11:00",   ["tzoff"]="+10:00"},
    [36]={["tzposix"]="LHST-10:30LHDT-11:00,M10.1.0,M4.1.0",    ["tzoff"]="+10:30"},
    [37]={["tzposix"]="NCT-11:00NCT-12:00,M10.1.0,M4.1.0",  ["tzoff"]="+11:00"},
    [38]={["tzposix"]="NFT-11:30",  ["tzoff"]="+11:30"},
    [39]={["tzposix"]="NZST-12:00NZDT-13:00,M9.5.0,M4.1.0/03:00:00",    ["tzoff"]="+12:00"},
    [40]={["tzposix"]="WST-13:00",  ["tzoff"]="+13:00"},
    [41]={["tzposix"]="LINT-14:00", ["tzoff"]="+14:00"}
}

local MonthInInt = {
    "01",
    "02",
    "03",
    "04",    
    "05",    
    "06",    
    "07",    
    "08",    
    "09",    
    "10",    
    "11",    
    "12"    
}
local MonthInStr = {
    "Jan" ,
    "Feb" ,
    "Mar" ,
    "Apr" ,
    "May" ,
    "Jun" ,
    "Jul" ,
    "Aug" ,
    "Sep" ,
    "Oct" ,
    "Nov" ,
    "Dec"
}


--[[
--*****************************************************************************
--  timeTr.CurrentLocalTimeGet: get the current local time.
--
--  TR69 parameter: "Device.Time.CurrentLocalTime"
--
--  RETURN: status (OK or ERROR) and tr69 parameter
]]--
function timeTr.CurrentLocalTimeGet(input)
    local status = "0"
	local value 
    local rowId="1"
    local row={}

    row = db.getRow ("ntp", "_ROWID_",rowId)
    if(row == nil) then
        return "1" ,"DB_ERROR_TRY_AGAIN"
    end

    value = os.date("%Y-%m-%d %H:%M:%S.%Z")

    return status, value
end

--[[
--*****************************************************************************
--  timeTr.LocalTimeZoneGet: get the local time zone.
--                  
--  TR69 parameter: "Device.Time.LocalTimeZone"
-- 
--  RETURN: status (OK or ERROR) and tr69 parameter value
]]--
function timeTr.LocalTimeZoneGet(input)
    local status = "0"
	local value = "+00:00"
    local rowId="1"
    local timeZone
    local row={}

    local instanceMap =  tr69Glue.instanceMapLoad()
    row = db.getRow ("ntp", "_ROWID_",rowId)
    if(row == nil) then
        return "1" ,"DB_ERROR_TRY_AGAIN"
    end
    if(row["ntp.timezone"]) then        
		timezone=row["ntp.timezone"]
    else
        return "1" ,"DB_ERROR_TRY_AGAIN"
    end

    --check ntp.timezone agaisnt keys of timeZoneMapping lua tbl and
    --return value of timeZoneMapping[k].["tzoff"]
    for k,v in pairs(timeZoneMapping) do
        if(k == tonumber(timezone)) then
            value = v["tzposix"]
            break
        end
    end

    return status, value
end

--[[
--*****************************************************************************
--  timeTr.LocalTimeZoneNameSet: set local timezone name.
--
--  TR69 Parameter: Device.Time.LocalTimeZone
-- 
]]--
function timeTr.LocalTimeZoneSet(input)
    local inTable = {}
    local value = {}
    local status = "0"
    local inTzPosixStr = ""
    local timeZone = ""

    inTable = input["ntp"]
    if(inTable == nil) then
       return
    end

    inTzPosixStr = inTable["ntp.timezone"]

    for k,v in pairs(timeZoneMapping) do
        if(v["tzposix"] == inTzPosixStr) then
            timeZone = tostring(k)
            break
        end
    end

    if(timeZone == "") then 
        return
    end

    value["ntp.timezone"] = timeZone
    status = db.update ("ntp", value, "1")
    if (status == nil) then
        status = 1
        return;
    end
    status = "0"    

    return 
end

--[[
--*****************************************************************************
-- timeTr.UpTimeGet - get system uptime
-- 
-- TR69 Parameter: Device.DeviceInfo.UpTime
--
]]--

function timeTr.UpTimeGet (input)
	require "timeLib"

	local status = "0"
	local value = " "
	local value1 
	
	value1, value2 = timeLib.uptime()
	if (value1 == "uptime") then
		value = value2
		return status, value
	else
		value = "failed to get UpTime"
		return status, value
	end
end

--[[
--*****************************************************************************
-- timeTr.FirstUseDate - get first use date
-- 
-- TR69 Parameter: Device.DeviceInfo.FirstUseDate
--
-- Date and time in UTC that the CPE first both successfully established an 
-- IP-layer network connection and acquired an absolute time reference 
-- using NTP or equivalent over that network connection.
--
]]--
function timeTr.FirstUseDateGet (input)
	require "timeLib"
	local status = "0"
	local value = " "
    local timeVal = {}
    local newtimeVal = " "
    local MonthInIntVal
    local rowId = "1"
    local row={}
    local value1 = " "

	value = timeLib.firstSyncTime()
	row = db.getRow ("ntp", "_ROWID_",rowId)
	if(row ~= nil and row["ntp.timezone"]) then        
        timezone=row["ntp.timezone"]
	else
        return "1" ,"DB_ERROR_TRY_AGAIN"
	end
	for k,v in pairs(timeZoneMapping) do
        if(k == tonumber(timezone)) then
            value1 = v["tzoff"]
            break
        end
	end
    if (value == " " or value == "" or value == nil) then
        newtimeVal = "1970-01-01T" .. value1 .. ":00.000000"        
    end
    timeVal = util.split(value, " ")
    for m=1,12 do
        if (timeVal[2] == MonthInStr[m]) then
            MonthInIntVal = MonthInInt[m]
        end
    end

    if (timeVal[6] ~= nil and MonthInIntVal ~= nil and timeVal[3] ~= nil and timeVal[4] ~= nil) then
        newtimeVal = timeVal[6] .. "-" .. MonthInIntVal .. "-" .. timeVal[3] .. "T" .. timeVal[4] .. ".000000" .. value1
    end

	return status, newtimeVal
end

-------------------------------------------------------------------------------
-- @name : timeTr.timeCfgSet
--
-- @description : generic set function for updating a field in a table
--
-- @return : 
--
function timeTr.timeCfgSet (input, rowids, actionType, tr69Param)
    local row    = {}
    local rowId  = "1"
    local status = OK
    local faultTbl = {}
    local index = 0
   
    -- get corresponding db entry from 'ntp'
    query = "_ROWID_='" .. rowId .. "'"
    row = db.getRowWhere ("ntp",query,false)

    if (row == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    if (input["ntp"]["ntp.enabled"] ~= nil) then    
        row["enabled"] = input["ntp"]["ntp.enabled"]
    end

    if (input["ntp"]["ntp.server1"] ~= nil) then
        row["useDefServers"] = "0"
        row["server1"] = input["ntp"]["ntp.server1"]
        if (timeTr.serverNameValidate (row["server1"]) ~= "OK") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."NTPServer1", error_code.INVALID_PARAM_VALUE)
        end
    end

    if (input["ntp"]["ntp.server2"] ~= nil) then
        row["useDefServers"] = "0"
        row["server2"] = input["ntp"]["ntp.server2"]
        if (timeTr.serverNameValidate (row["server2"]) ~= "OK") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."NTPServer2", error_code.INVALID_PARAM_VALUE)
        end
    end
    if(status ~= OK) then
        return status, faultTbl
    end

    row = util.addPrefix (row,"ntp.")
    local valid, errstr = db.update("ntp",row, "1")
    if (not valid) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end
    
    -- saving DB
    db.save()

    return status, faultTbl
end



----------------------------------------------------------------------
-- @name : timeTr.serverNameValidate
--
-- @description : generic function for validating the domain name 
--
-- @return : 
--

function timeTr.serverNameValidate (ipAddr)
    require "teamf1lualib/ifDev"

    local lastOctateVal = ""
    local ipAddTbl = {}
    local status = "ERROR"
    local i= 0

    if (ipAddr == "" or ipAddr == '' or  (string.find(ipAddr,".") == nil and string.find(ipAddr,":") == nil)) then
         return status
    end

    ipAddTbl= util.split(ipAddr, ".")
    -- Get the last octet
    if (util.tableSize(ipAddTbl)) then
        lastOctateVal = ipAddTbl[util.tableSize(ipAddTbl)]
    end
    
    -- check whether the last octet is an empty value
    if (lastOctateVal == "") then 
        return status
    end

    -- if it is string it will return nil otherwise it gives number
    if (tonumber(lastOctateVal)) then
        --ipv4 validate    if it is OK on success and otherwise error
        if (tr69Glue.tf1IpAddressValidate(ipAddr,"","","") ~= "OK" or (#(ipAddTbl)) ~= 4) then
            tr69Glue.tf1Dbg("In ipv4 code ..")                                      
            return status
        end
    elseif(string.find(ipAddr, ":")) then
        --ipv6 validate
        -- check if the ipv6 is not a link-local address
        if (ipAddr ~= nil) then
            if (string.match(ipAddr, '^fe80') or string.match(ipAddr, '^FE80')) then
                tr69Glue.tf1Dbg("ipv6 address is link local failed..")
                return status
            end
        end

        -- check if the ipv6 is a reserved or multicast address
        if (ifDevLib.isIpv6AddressReserved(ipAddr) > 0) then
            tr69Glue.tf1Dbg("ipv6 address is reserved failed..")
            return status
        elseif(ifDevLib.isIpv6AddressMulticast(ipAddr) > 0) then
            tr69Glue.tf1Dbg("ipv6 address is Multicast failed..")
            return status
        end

        if (tr69Glue.tf1ValidateIpv6Address(ipAddr,"", "") ~= 0) then
            tr69Glue.tf1Dbg("In ipv6 code fail ..")
            return status
        end
    elseif(tr69Glue.tf1domainNameValidate(ipAddr,lastOctateVal) ~= "OK") then
        --domain name validate
        tr69Glue.tf1Dbg("DNS main ..")
        return status
    end

    

    return "OK"
end

----------------------------------------------------------------------

