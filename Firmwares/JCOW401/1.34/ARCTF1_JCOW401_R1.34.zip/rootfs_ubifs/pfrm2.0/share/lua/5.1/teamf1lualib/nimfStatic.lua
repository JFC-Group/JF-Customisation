-- @copyright Copyright (c) 2012, TeamF1, Inc. 

require "teamf1lualib/ifStatic"

--[[
*******************************************************************************
-- @name nimfConn.ipv4StaticConfValidate
--
-- @description This function validates static IPv4 parameters
--
-- @param conf configuration table with the following fields
-- <ul>
-- <li><i> LogicalIfName</i>     Logical name of the network.
-- <li><i> AddressFamily</i>     network protocol of the connection
-- <li><i> ConnectionKey</i>     enable/disable connection
-- <li><i> ConnectionType</i>    type of the network connection. see nimf.method table   
-- <li><i> StaticIp</i>          static IP address to be configured for this network
-- <li><i> PrefixLength</i>      prefix length if static IP address is an IPv6 address.
-- <li><i> NetMask</i>           netmask if static IP address is an IPv4 address
-- <li><i> Gateway</i>           Gateway router IP address of this network
-- <li><i> PrimaryDns</i>        Primary DNS server IP address of this network
-- <li><i> SecondaryDns</i>      Secondary DNS server IP address of this network
-- </ul>
--
-- @return  OK or ERROR
-- @errCode error string.
--]]

function nimfConn.ipv4StaticConfValidate(conf)
    local ipAddr

    -- check if IP is valid
    ipAddr = conf["StaticIp"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv4AddrCheck(ipAddr) == nil)) then
        return "ERROR", "NIMF_ERR_INVALID_IP"
    end        

    -- TODO: check if the address belongs to any other network

    -- check if Gateway is valid
    ipAddr = conf["Gateway"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv4AddrCheck(ipAddr) == nil)) then
        return "ERROR", "NIMF_ERR_INVALID_GATEWAY"
    end        

    -- check if primary DNS is valid
    ipAddr = conf["PrimaryDns"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv4AddrCheck(ipAddr) == nil)) then
        return "ERROR", "NIMF_ERR_INVALID_PRIMARY_DNS"
    end        

    -- check if secondary DNS is valid
    ipAddr = conf["SecondaryDns"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv4AddrCheck(ipAddr) == nil)) then
        return "ERROR", "NIMF_ERR_INVALID_SECONDARY_DNS"
    end        

    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- @name nimfConn.ipv6StaticConfValidate
--
-- @description This function validates static IPv6 parameters
--
-- @param conf configuration table with the following fields
-- <ul>
-- <li><i> LogicalIfName</i>     Logical name of the network.
-- <li><i> AddressFamily</i>     network protocol of the connection
-- <li><i> ConnectionKey</i>     enable/disable connection
-- <li><i> ConnectionType</i>    type of the network connection. see nimf.method table   
-- <li><i> StaticIp</i>          static IP address to be configured for this network
-- <li><i> PrefixLength</i>      prefix length if static IP address is an IPv6 address.
-- <li><i> Gateway</i>           Gateway router IP address of this network
-- <li><i> PrimaryDns</i>        Primary DNS server IP address of this network
-- <li><i> SecondaryDns</i>      Secondary DNS server IP address of this network
-- </ul>
--
-- @return  OK or ERROR
-- @errCode error string.
--]]

function nimfConn.ipv6StaticConfValidate(conf)
    local ipAddr

    -- check if IP is valid
    ipAddr = conf["StaticIp"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv6AddrCheck(ipAddr) == nil)) then
        return "ERROR", "NIMF_ERR_INVALID_IP"
    end        

    -- TODO: check if the address belongs to any other network

    -- check prefix length
    if ((tonumber(conf["PrefixLength"]) < 0) or 
        (tonumber(conf["PrefixLength"]) > 128)) then
        return "ERROR", "NIMF_ERR_INVALID_PREFIX_LENGTH"
    end        

    -- check if Gateway is valid
    ipAddr = conf["Gateway"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv6AddrCheck(ipAddr) == nil)) then
        return "ERROR", "NIMF_ERR_INVALID_GATEWAY"
    end        

    -- check if primary DNS is valid
    ipAddr = conf["PrimaryDns"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv6AddrCheck(ipAddr) == nil)) then
        return "ERROR", "NIMF_ERR_INVALID_PRIMARY_DNS"
    end        

    -- check if secondary DNS is valid
    ipAddr = conf["SecondaryDns"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv6AddrCheck(ipAddr) == nil)) then
        return "ERROR", "NIMF_ERR_INVALID_SECONDARY_DNS"
    end        

    return "OK", "STATUS_OK"
end


--[[
*******************************************************************************
-- @name nimfConn.staticCfgInit
--
-- @description The function initialises the static configuration.
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.staticCfgInit(cur, conf)
    local cfg = {}
    local ConnectionKey = conf["ConnectionKey"]

    if (ConnectionKey == nil) then
        ConnectionKey = "0"
    end        

    if (cur ==  nil) then
        cfg["LogicalIfName"] = conf["LogicalIfName"]
        cfg["AddressFamily"] = conf["AddressFamily"]
        cfg["ConnectionKey"] = ConnectionKey
        cfg["StaticIp"] = conf["StaticIp"]
        cfg["PrefixLength"] = conf["PrefixLength"]
        cfg["NetMask"] = conf["NetMask"]
        cfg["Gateway"] = conf["Gateway"]
        cfg["PrimaryDns"] = conf["PrimaryDns"]
        cfg["SecondaryDns"] = conf["SecondaryDns"]
    else
        cfg = cur
        cfg["StaticIp"] = conf["StaticIp"]
        cfg["PrefixLength"] = conf["PrefixLength"]
        cfg["NetMask"] = conf["NetMask"]
        cfg["Gateway"] = conf["Gateway"]
        cfg["PrimaryDns"] = conf["PrimaryDns"]
        cfg["SecondaryDns"] = conf["SecondaryDns"]
    end                

    return cfg
end

--[[
*******************************************************************************
-- @name nimfConn.staticConfigure
--
-- @description The function adds/updates the static configuration.
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.staticConfigure(conf)
    local query = nil
    local record = {}
    local cfg = {}
    local errstr = ""
    local valid
    local rowid

    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "' AND " ..
            "AddressFamily='" .. conf["AddressFamily"] .. "'"

    if (conf["ConnectionKey"] ~= nil) then
        query = query .. " AND ConnectionKey=" .. conf["ConnectionKey"]
    end

    nimf.dprintf ("Configuring Static connection for " ..  conf["LogicalIfName"])

    record = db.getRowWhere("ifStatic", query, false)
    if (record == nil) then
        -- initialize configuration
        cfg = nimfConn.staticCfgInit(record, conf)
            
        -- add configuration
        cfg = util.addPrefix(cfg, "ifStatic.")

        nimf.dprintf ("Static connection " ..  util.tableToStringRec(cfg))

        valid, errstr, rowid = ifStatic.config (cfg, nil, "add")
    else        
        -- initialize configuration
        cfg = nimfConn.staticCfgInit(record, conf)

        local changed = nimf.hasTableChanged("ifStatic", cfg, cfg["_ROWID_"])
        if (not changed) then
            return "OK","STATUS_OK", false
        end            

        --
        -- Set this to true to indicate configuration has changed
        --
        rowid = true

        -- update configuration
        cfg = util.addPrefix(cfg, "ifStatic.")
        valid, errstr = ifStatic.config (cfg, cfg["ifStatic._ROWID_"], "edit")
    end        

    if (not valid) then
        nimf.dprintf("nimfConn.staticConfigure: " ..
                     "Static Connection configuration failed")
        return "ERROR", errstr or ""
    end
            
    return "OK", "STATUS_OK", rowid
end

--[[
*******************************************************************************
-- @name nimfConn.staticConfGet
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.staticConfGet(conf)
    local query = nil
    local record = {}
    local cfg = {}

    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "' AND " ..
            "AddressFamily='" .. conf["AddressFamily"] .. "'"

    if (conf["ConnectionKey"] ~= nil) then
        query = query .. " AND ConnectionKey=" .. conf["ConnectionKey"]
    end

    record = db.getRowWhere("ifStatic", query, false)
    if (record ~= nil) then
        cfg["LogicalIfName"] = record["LogicalIfName"]
        cfg["AddressFamily"] = record["AddressFamily"]
        cfg["ConnectionKey"] = record["ConnectionKey"]
        cfg["StaticIp"] = record["StaticIp"]
        cfg["PrefixLength"] = record["PrefixLength"]
        cfg["NetMask"] = record["NetMask"]
        cfg["Gateway"] = record["Gateway"]
        cfg["PrimaryDns"] = record["PrimaryDns"]
        cfg["SecondaryDns"] = record["SecondaryDns"]
    end        

    return "OK", "STATUS_OK", cfg
end

--[[
*******************************************************************************
-- @name nimfConn.staticDeconfigure
--
-- @description The function adds/updates the static configuration.
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.staticDeconfigure(conf)
    local query = nil
    local errstr = ""
    local valid

    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "' AND " ..
            "AddressFamily='" .. conf["AddressFamily"] .. "'"

    if (conf["ConnectionKey"] ~= nil) then
        query = query .. " AND ConnectionKey=" .. conf["ConnectionKey"]
    end

    nimf.dprintf ("Deleting Static connection for " ..  conf["LogicalIfName"])

    valid, errstr = db.deleteRowWhere("ifStatic", query)
    if (not valid) then

        return "ERROR", errstr
    end
            
    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- @name  nimfConn.ipv4StaticConfigure
--
-- @description The function adds/updates the IPv4 static configuration.
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv4StaticConfigure(conf)
    return nimfConn.staticConfigure(conf)
end

--[[
*******************************************************************************
-- @name  nimfConn.ipv6StaticConfigure
--
-- @description The function adds/updates the IPv6 static configuration.
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv6StaticConfigure(conf)
    return nimfConn.staticConfigure(conf)
end


--[[
*******************************************************************************
-- @name nimfConn.ipv4StaticDeconfigure
--
-- @description This function deletes the static configuration
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv4StaticDeconfigure(conf)
    return nimfConn.staticDeconfigure(conf)
end

--[[
*******************************************************************************
-- @name nimfConn.ipv6StaticDeconfigure
--
-- @description This function deletes the static configuration
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv6StaticDeconfigure(conf)
    return nimfConn.staticDeconfigure(conf)
end

--[[
*******************************************************************************
-- @name nimfConn.ipv4StaticConfGet
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv4StaticConfGet(conf)
    return nimfConn.staticConfGet(conf)
end

--[[
*******************************************************************************
-- @name nimfConn.ipv6StaticConfGet
--
-- @description 
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv6StaticConfGet(conf)
    return nimfConn.staticConfGet(conf)
end

-------------------------------------------------------------------------
-- @name nimfConn.ipv6StaticDefConfGet 
--
-- @description 
--
--                  
-- @return 
--

function nimfConn.ipv6StaticDefConfGet (connID)
    local cfg = {}

    cfg["LogicalIfName"] = connID["LogicalIfName"]
    cfg["AddressFamily"] = connID["AddressFamily"]
    cfg["ConnectionKey"] = connID["ConnectionKey"] or "0"
    cfg["StaticIp"] = ''
    cfg["PrefixLength"] = 64
    cfg["NetMask"] = ''
    cfg["Gateway"] = ''
    cfg["PrimaryDns"] = ''
    cfg["SecondaryDns"] = ''

    return cfg
end

-------------------------------------------------------------------------
-- @name nimfConn.ipv4StaticDefConfGet 
--
-- @description 
--
--                  
-- @return 
--

function nimfConn.ipv4StaticDefConfGet (connID)
    local cfg = {}

    cfg["LogicalIfName"] = connID["LogicalIfName"]
    cfg["AddressFamily"] = connID["AddressFamily"]
    cfg["ConnectionKey"] = connID["ConnectionKey"] or "0"
    cfg["StaticIp"] = '0.0.0.0'
    cfg["PrefixLength"] = ''
    cfg["NetMask"] = '255.255.255.0'
    cfg["Gateway"] = ''
    cfg["PrimaryDns"] = ''
    cfg["SecondaryDns"] = ''

    return cfg
end
