--[[ easyMeshMethodProcessLib.lua - Process the JSON data to get the Mesh Method info.
--
-- Copyright (c) 2008-2019, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: easyMeshMethodProcessLib.lua
-- Description: Process the JSON data to get the Mesh Method info.
-- 
-- modification history
-- --------------------
-- 01a, 26Nov19, ar written.
--
--]]

require "easyMeshLib"
require "teamf1lualib/easyMeshDebug"
require "teamf1lualib/easyMeshResponses"

-- GLobal LUA Table List for Supported easy mesh request methods.
-- Add the supported easyMesh Request Methods in this list.
-- Following is the format for Addition in here.
-- --------------------------------------------------------------------------------------------
-- ["<REQUEST_METHOD_STRING>"] = {
--                                      ["methodName"]      =   "<REQUEST_METHOD_STRING>",
--                                      ["methodHandler"]   =   <REQUEST_METHOD_LUA_HANDLER>,
--                                      ["requirefile"]     =   "<SRC_FILE_OF_THIS_METHOD>",
--                                      ["methodAction"]    =   "SET_CGI" or "GET_CGI"
--                                  },
-- --------------------------------------------------------------------------------------------
--
--
meshRequestMethodsList = {

    ["Login"] = {
        ["methodName"]      =   "Login", 
        ["methodHandler"]   =   loginHandler,
        ["requirefile"]     =   "easyMeshLogin",
        ["methodAction"]    =   "SET_CGI"
    },

    ["Change_Password"] = {
        ["methodName"]      =   "Change_Password", 
        ["methodHandler"]   =   passwdChangeHandler,
        ["requirefile"]     =   "easyMeshChangePassword",
        ["methodAction"]    =   "SET_CGI"
    },

    ["WiFiSON"] = {
        ["methodName"]      =   "WiFiSON", 
        ["methodHandler"]   =   getEasyMeshTopologyHandler,
        ["requirefile"]     =   "easyMeshTopology",
        ["methodAction"]    =   "GET_CGI"
    },
    ["Client"] = {
        ["methodName"]      =   "Client", 
        ["methodHandler"]   =   getEasyMeshClientsInfoHandler,
        ["requirefile"]     =   "easyMeshClientsInfo",
        ["methodAction"]    =   "GET_CGI"
    },

    ["Device"] = {
        ["methodName"]      =   "Device", 
        ["methodHandler"]   =   getEasyMeshDevicesInfoHandler,
        ["requirefile"]     =   "easyMeshDevicesInfo",
        ["methodAction"]    =   "GET_CGI"
    },

    ["Rename"] = {
        ["methodName"]      =   "Rename", 
        ["methodHandler"]   =   renameEasyMeshDeviceHandler,
        ["requirefile"]     =   "easyMeshDeviceRename",
        ["methodAction"]    =   "SET_CGI"
    },
    ["SSIDGet"] = {
        ["methodName"]      =   "SSIDGet", 
        ["methodHandler"]   =   getEasyMeshDeviceSsidHandler,
        ["requirefile"]     =   "easyMeshSsidRequest",
        ["methodAction"]    =   "GET_CGI"
    },

    ["SSIDPSKSet"] = {
        ["methodName"]      =   "SSIDPSKSet", 
        ["methodHandler"]   =   changeEasyMeshSsidPskHandler,
        ["requirefile"]     =   "easyMeshChangeSsidPsk",
        ["methodAction"]    =   "SET_CGI"
    },


    ["Topology"] = {
        ["methodName"]      =   "Topology", 
        ["methodHandler"]   =   getEasyMeshTopologyInfoHandler,
        ["requirefile"]     =   "easyMeshTopologyInfo",
        ["methodAction"]    =   "GET_CGI"
    },


    ["ForcedLogin"] = {
        ["methodName"]      =   "ForcedLogin", 
        ["methodHandler"]   =   forcedLoginHandler,
        ["requirefile"]     =   "easyMeshForcedLogin",
        ["methodAction"]    =   "SET_CGI"
    },


    ["ONTDC"] = {
        ["methodName"]      =   "ONTDC", 
        ["methodHandler"]   =   getEasyMeshOntdcInfoHandler,
        ["requirefile"]     =   "easyMeshOntdcInfo",
        ["methodAction"]    =   "GET_CGI"
    },


}

function meshSessionActiveTimeUpdate()

    require "cgilua.cookies"

    local updateStatus
    -- Get Session cookie
    sessionCookie = cgilua.cookies.get("uid")

    if (sessionCookie == nil) then
        mesh.dprintf("sessionCookie is NIL")
        return "ERROR"
    end
    mesh.dprintf("sesionCookie : " .. sessionCookie)
    
    -- Get Private key for this session
    updateStatus = easyMeshLib.easyMeshSessionActivityUpdate(sessionCookie)
    if (updateStatus == nil) then
        mesh.dprintf("Error Updating Session Active Time")
        return "ERROR"
    end

    return "OK"
end

----------------------------------------------------------------------------------
-- @name GetGroupname_Session
--
-- @description This function is used to get the Group Name of the Session.
--
-- @return 
--
function GetGroupname_Session()
	
    require "cgilua.cookies"

    local sessionCookie = nil
    local groupName = nil 

    -- Get Session cookie
    sessionCookie = cgilua.cookies.get("uid")

    if (sessionCookie == nil) then
        mesh.dprintf("sessionCookie is NIL")
        return "ERROR", "Error-Auth"
    end
    
    -- Get Groupname for this session
    groupName = easyMeshLib.easyMeshGnameGet(sessionCookie)
    if (groupName == nil) then
        mesh.dprintf("Groupname is NIL")
        return "ERROR", "Error-Auth"
    end
    mesh.dprintf ("GroupName: " .. groupName)
    
    return "OK", "GET_GROUPNAME_SUCCEEDED", groupName
end

----------------------------------------------------------------------------------
-- @name mesh.requestMethodProcess
--
-- @description This function checks the Mesh Api Request support and invoke
-- respective Handler if the requested Mesh Api is supported.
--
-- @return 
--
function mesh.requestMethodProcess(jsonData, meshApiReqAction, meshRequestMethod)

    local status , errorCode , methodResponse_t
    
    if (jsonData == nil or meshRequestMethod == nil) then

        mesh.dprintf("ERROR: Invalid Mesh API Request.")
        return "ERROR", "INVALID_MESH_METHOD"
    end

    -- Convert JSON String to Lua Table Object.
    local methodObj = json.decode(jsonData);

    --[[ The requested Method is supported if it is listed in the Mesh
    -- RequestMethod List.
    --]]
    if (meshRequestMethodsList[meshRequestMethod] == nil or
        meshRequestMethodsList[meshRequestMethod]["methodName"] == nil or
       -- meshRequestMethodsList[meshRequestMethod]["methodHandler"] == nil or
        meshRequestMethodsList[meshRequestMethod]["methodAction"] == nil) then

        mesh.dprintf("ERROR: Requested Mesh Method Not Supported.")
        return "ERROR", "INVALID_MESH_METHOD"
    end
        
    if (meshRequestMethodsList[meshRequestMethod]["methodAction"] ~= "SET_CGI" and 
        meshRequestMethodsList[meshRequestMethod]["methodAction"] ~= "GET_CGI") then

        mesh.dprintf("ERROR: Requested Mesh Method ACTION Not Supported.")
        return "ERROR", "INVALID_MESH_METHOD_ACTION"
    end

    if (meshRequestMethodsList[meshRequestMethod]["methodAction"] ~= meshApiReqAction) then
        mesh.dprintf("ERROR: Requested Mesh Method ACTION Not Supported.")
        return "ERROR", "INVALID_MESH_METHOD_ACTION"
    end

    if (meshRequestMethod ~= "Login" and meshRequestMethod ~= "ForcedLogin" ) then
        -- For SET methods, check the Session GroupName.
        -- If Session GroupName is "admin", then only, the SET Operations are allowed
        local groupName = nil
        local errorCode = nil
        local status = nil
        -- Get the Session GroupName Info
        errorCode, status, groupName = GetGroupname_Session()
        
        if (errorCode ~= "OK") then
            -- Return Error, if Unable to get Session GroupName
            mesh.dprintf("ERROR: Unable to get the Session GroupName.")
            mesh.sendResponse(result401Error)
            return "OK", status
        end
        
        if (meshRequestMethodsList[meshRequestMethod]["methodAction"] == "SET_CGI") then
            if (groupName ~= "admin") then
                -- Return Error, if GroupName is not equal to admin
                mesh.dprintf("SET Operations not allowed for Group: " .. groupName)
                return "ERROR", "SET_CGI_NOT_ALLOWED"
            else
                ACCESS_LEVEL = 0
            end
        end
        
        status = meshSessionActiveTimeUpdate()
        if (status ~= "OK") then
            mesh.dprintf("ERROR: Unable to KeepAlive Session.")
            return "ERROR", "SESSION_KEEPALIVE_FAILED"
        end
    end
    if(util.fileExists("/pfrm2.0/DEVICE_REPEATER")) then
            
        if (meshRequestMethodsList[meshRequestMethod]["methodHandler"] == "changeEasyMeshSsidPskHandler") then
            if (groupName ~= "admin") then
                -- Return Error, if GroupName is not equal to admin
                mesh.dprintf("SET Operations not allowed for Group: " .. groupName)
                return "ERROR", "SET_CGI_NOT_ALLOWED"
            else
                ACCESS_LEVEL = 0
            end
        end
    end
    mesh.dprintf("Requiring teamf1lualib/" .. meshRequestMethodsList[meshRequestMethod]["requirefile"] .. " for " .. meshRequestMethod )
    require('teamf1lualib/' .. meshRequestMethodsList[meshRequestMethod]["requirefile"])

    mesh.dprintf("Handling MESH Method for: " .. meshRequestMethodsList[meshRequestMethod]["methodName"])
    status, errorCode,methodResponse_t = meshRequestMethodsList[meshRequestMethod]["methodHandler"](methodObj, meshRequestMethod)
    mesh.sendResponse (methodResponse_t)

    return "OK", "SUCCESS" 

end
