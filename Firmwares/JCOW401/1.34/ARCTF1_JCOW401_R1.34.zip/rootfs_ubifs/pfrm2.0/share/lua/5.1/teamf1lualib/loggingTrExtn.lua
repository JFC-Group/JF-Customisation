--[[
#### 
#### File: loggingTrExtn.lua
#### Description: 
#### TR-98 handlers for loggingTr.sysLogInfoGet. This file is included from
#### tr69Glue code.
####

#### Revisions:
01a,06sep12,bng  written
]]--

loggingTr = {}

--[[
--*****************************************************************************
-- loggingTr.sysLogInfoGet - get loggingTr.sysLogInfoGet parameters.
-- 
-- This function is called to get the following parameters in
-- InternetGatewayDevice.X_PINGCOM-NET.Syslog.Severity
--
--RETURN: 
]]--

function loggingTr.sysLogInfoGet (input)

   local status = "0"
   local value = "0"
   local sysLogInfoRow = db.getRowWhere ("sysLogInfo", "ROWID=1", false);

   if (string.find (input["param"], "Severity")) then
       if (sysLogInfoRow["severity"] == "debug") then
           value = "1"
       elseif (sysLogInfoRow["severity"] == "information") then
           value = "2"
       elseif (sysLogInfoRow["severity"] == "notice") then
           value = "3"
       elseif (sysLogInfoRow["severity"] == "warning") then
           value = "4"
       elseif (sysLogInfoRow["severity"] == "error") then
           value = "5"
       elseif (sysLogInfoRow["severity"] == "critical") then
           value = "6"
       elseif (sysLogInfoRow["severity"] == "alert") then
           value = "7"
       elseif (sysLogInfoRow["severity"] == "emergency") then
           value = "8"
       end
   end

   return status, value
end


--[[
--*****************************************************************************
-- loggingTr.sysLogInfoSet - set loggingTr.sysLogInfoGet parameters.
-- 
-- This function is called to set the following parameters in
-- InternetGatewayDevice.X_PINGCOM-NET.Syslog.Enable
-- InternetGatewayDevice.X_PINGCOM-NET.Syslog.Server
-- InternetGatewayDevice.X_PINGCOM-NET.Syslog.ServerPort
-- InternetGatewayDevice.X_PINGCOM-NET.Syslog.Severity
--
--RETURN: 
]]--
function loggingTr.sysLogInfoSet (input)

    local status = "0"
    local sysLogInfoRow = db.getRowWhere ("sysLogInfo", "ROWID=1", false);

    for table,value in pairs (input) do
        if (value["sysLogInfo.Enable"] ~= nil) then
            sysLogInfoRow ["Enable"] = value["sysLogInfo.Enable"]
        end

        if (value["sysLogInfo.serverName"] ~= nil) then
            sysLogInfoRow ["serverName"] = value["sysLogInfo.serverName"]
        end

        if (value["sysLogInfo.serverPort"] ~= nil) then
            sysLogInfoRow ["serverPort"] = value["sysLogInfo.serverPort"]
        end

        if (value["sysLogInfo.selSeverity"] ~= nil) then
            sysLogInfoRow ["selSeverity"] = value["sysLogInfo.selSeverity"]
        end

        --[[
        if (value["sysLogInfo.selSeverity"] ~= nil) then
            if (value["sysLogInfo.selSeverity"] == "1") then
                sysLogInfoRow ["selSeverity"] = "debug"
            elseif (value["sysLogInfo.selSeverity"] == "2") then
                sysLogInfoRow ["selSeverity"] = "information"
            elseif (value["sysLogInfo.selSeverity"] == "3") then
                sysLogInfoRow ["selSeverity"] = "notice"
            elseif (value["sysLogInfo.selSeverity"] == "4") then
                sysLogInfoRow ["selSeverity"] = "warning"
            elseif (value["sysLogInfo.selSeverity"] == "5") then
                sysLogInfoRow ["selSeverity"] = "error"
            elseif (value["sysLogInfo.selSeverity"] == "6") then
                sysLogInfoRow ["selSeverity"] = "critical"
            elseif (value["sysLogInfo.selSeverity"] == "7") then
                sysLogInfoRow ["selSeverity"] = "alert"
            elseif (value["sysLogInfo.selSeverity"] == "8") then
                sysLogInfoRow ["selSeverity"] = "emergency"
            end
        end
        ]]--
    end

    sysLogInfoRow = util.addPrefix(sysLogInfoRow, "sysLogInfo.")
    local valid = db.update("sysLogInfo", sysLogInfoRow, sysLogInfoRow["sysLogInfo._ROWID_"])

    if (valid) then
        db.save ();
        return 0;
    else
        return 1;
    end
end
