require "teamf1lualib/dhcpc"

--[[
*******************************************************************************
-- @name nimfConn.ipv4DhcpConfValidate
--
-- @description This function validates IPv4 DHCP parameters
--
-- @param conf configuration table with the following fields
-- <ul>
-- <li><i> LogicalIfName</i>     Logical name of the network.
-- <li><i> PrimaryDns</i>        Primary DNS server IP address of this network
-- <li><i> SecondaryDns</i>      Secondary DNS server IP address of this network
-- </ul>
--
-- @return  OK or ERROR
-- @errCode error string.
--]]

function nimfConn.ipv4DhcpConfValidate(conf)
    local ipAddr

    -- check if primary DNS is valid
    ipAddr = conf["PrimaryDns"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv4AddrCheck(ipAddr) == nil)) then
        return "ERROR", "NIMF_ERR_INVALID_PRIMARY_DNS"
    end        

    -- check if secondary DNS is valid
    ipAddr = conf["SecondaryDns"]
    if ((ipAddr ~= nil) and (string.len(ipAddr) > 0) and
        (nimfLib.ipv4AddrCheck(ipAddr) == nil)) then
        return "ERROR", "NIMF_ERR_INVALID_SECONDARY_DNS"
    end        

    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- @name nimfConn.ipv4DhcpCfgInit
--
-- @description  This function initialises the configuration.
--
-- @param cur   existing configuration
-- @param conf  new configuration
--
-- @return  cfg
--]]

function nimfConn.ipv4DhcpCfgInit(cur, conf)
    local cfg = {}

    if (cur == nil) then
        cfg["LogicalIfName"] = conf["LogicalIfName"]
        cfg["IspName"] = conf["IspName"] 
        cfg["ReleaseLease"] = 0
        cfg["PrimaryDns"] = conf["PrimaryDns"]
        cfg["SecondaryDns"] = conf["SecondaryDns"]
    else        
        cfg = cur
        cfg["IspName"] = conf["IspName"] 
        cfg["ReleaseLease"] = 0
        cfg["PrimaryDns"] = conf["PrimaryDns"]
        cfg["SecondaryDns"] = conf["SecondaryDns"]
    end
            
    return cfg            
end

--[[
*******************************************************************************
-- @name nimfConn.ipv4DhcpConfigure
--
-- @description The function adds/updates the static configuration.
--
-- @param conf IPv4 DHCP configuration
--
-- @return status
-- @return errCode
--]]

function nimfConn.ipv4DhcpConfigure(conf)
    local query = nil
    local record = {}
    local cfg = {}
    local errstr = ""
    local valid
    local rowid

    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "'"
    record = db.getRowWhere("Dhcpc", query, false)
    if (record == nil) then
        -- initialize configuration
        cfg = nimfConn.ipv4DhcpCfgInit(record, conf)
            
        -- add configuration
        cfg = util.addPrefix(cfg, "Dhcpc.")
        valid, errstr, rowid = dhcpc.config ("Dhcpc", cfg, nil, "add")
    else        
        -- initialize configuration
        cfg = nimfConn.ipv4DhcpCfgInit(record, conf)

        local changed = nimf.hasTableChanged("Dhcpc", cfg, cfg["_ROWID_"])
        if (not changed) then
            return "OK","STATUS_OK", false
        end            

        --
        -- Set this to true to indicate configuration has changed
        --
        rowid =  true

        -- update configuration
        cfg = util.addPrefix(cfg, "Dhcpc.")
        valid, errstr = dhcpc.config ("Dhcpc", cfg, cfg["Dhcpc._ROWID_"], "edit")
    end        

    if (not valid) then
        return "ERROR", errstr
    end
            
    return "OK", "STATUS_OK", rowid
end

--[[
*******************************************************************************
-- @name nimfConn.ipv4DhcpDeconfigure
--
-- @description This function deletes the IPv4 DHCP configuration
--
-- @param conf IPv4 DHCP configuration
--
-- @return status
-- @return errCode
--]]

function nimfConn.ipv4DhcpDeconfigure(conf)
    local query = nil
    local errstr = ""
    local valid

    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "'"
    valid, errstr = db.deleteRowWhere("Dhcpc", query)
    if (not valid) then
        return "ERROR", errstr
    end
            
    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- @name nimfConn.ipv4DhcpConfGet
--
-- @description This function gets the IPv4 DHCP configuration for the
-- given network.
--
-- @param 
--
-- @return status
-- @return errCode
--]]

function  nimfConn.ipv4DhcpConfGet(conf)
    local query = nil
    local record = {}
    local cfg = {}

    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "'"
    record = db.getRowWhere("Dhcpc", query, false)
    if (record ~= nil) then
        cfg["LogicalIfName"] = record["LogicalIfName"]
        cfg["IspName"] = conf["IspName"] 
        cfg["ReleaseLease"] = conf["ReleaseLease"]
        cfg["PrimaryDns"] = record["PrimaryDns"]
        cfg["SecondaryDns"] = record["SecondaryDns"]
    end        

    return "OK", "STATUS_OK", cfg
end

--[[
*******************************************************************************
-- @name nimfConn.ipv6DhcpCfgInit
--
-- @description This function initialises the configuration
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv6DhcpCfgInit(cur, conf)
    local cfg = {}

    if (conf["StatelessMode"] ~= nil) then
        conf["statelessMode"] = conf["StatelessMode"]
    end

    if (conf["Enable"] ~= nil) then
        conf["isEnabled"] = conf["Enable"]
    end

    if (conf["GetDnsFromIsp"] ~= nil) then
        conf["requestDNS"] = conf["GetDnsFromIsp"]
    end

    if (conf["connectionKey"] == nil) then
        conf["connectionKey"] = "0"
    end

    if (cur == nil) then
        cfg["LogicalIfName"] = conf["LogicalIfName"]
        cfg["connectionKey"] = conf["connectionKey"] 
        cfg["isEnabled"] = conf["isEnabled"] 
        cfg["statelessMode"] = conf["statelessMode"] 
        cfg["requestPreferredAddress"] = conf["requestPreferredAddress"] or "0"
        cfg["preferredAddress"] = conf["preferredAddress"]  or ""
        cfg["preferredAddressPrefixLength"] = conf["preferredAddressPrefixLength"] or "0"
        cfg["requestDNS"] = conf["requestDNS"]  or "1"
        cfg["requestDNSSearchList"] = conf["requestDNSSearchList"] or "1"
        cfg["prefixDelegation"] = conf["prefixDelegation"] or "0"
        cfg["requestPreferredPrefix"] = conf["requestPreferredPrefix"] or "0"
        cfg["preferredPrefix"] = conf["preferredPrefix"] or ""
        cfg["preferredPrefixPrefixLength"] = conf["preferredPrefixPrefixLength"] or "0"
        cfg["renewTime"] = conf["renewTime"]  or "3600"
        cfg["sendRapidCommit"] = conf["sendRapidCommit"] or "0"
        cfg["maptParams"] = conf["maptParams"] or "1"
    else
        cfg = cur
        if (conf["isEnabled"] ~= nil) then
            cfg["isEnabled"] = conf["isEnabled"] 
        end

        if (conf["statelessMode"] ~= nil) then
            cfg["statelessMode"] = conf["statelessMode"] 
        end

        if (conf["requestPreferredAddress"] ~= nil) then
            cfg["requestPreferredAddress"] = conf["requestPreferredAddress"] 
        end

        if (conf["preferredAddress"] ~= nil) then
            cfg["preferredAddress"] = conf["preferredAddress"] 
        end

        if (conf["preferredAddressPrefixLength"] ~= nil) then
            cfg["preferredAddressPrefixLength"] = conf["preferredAddressPrefixLength"]
        end

        if (conf["requestDNS"] ~= nil) then
            cfg["requestDNS"] = conf["requestDNS"]
        end

        if (conf["requestDNSSearchList"] ~= nil) then
            cfg["requestDNSSearchList"] = conf["requestDNSSearchList"] 
        end

        if (conf["prefixDelegation"] ~= nil) then
            cfg["prefixDelegation"] = conf["prefixDelegation"] 
        end

        if (conf["requestPreferredPrefix"] ~= nil) then
            cfg["requestPreferredPrefix"] = conf["requestPreferredPrefix"] 
        end

        if (conf["preferredPrefix"] ~= nil) then
            cfg["preferredPrefix"] = conf["preferredPrefix"] 
        end

        if (conf["preferredAddressPrefixLength"] ~= nil) then
            cfg["preferredPrefixPrefixLength"] = conf["preferredPrefixPrefixLength"] 
        end

        if (conf["renewTime"] ~= nil) then
            cfg["renewTime"] = conf["renewTime"] 
        end

        if (conf["sendRapidCommit"] ~= nil) then
            cfg["sendRapidCommit"] = conf["sendRapidCommit"]
        end
        if (conf["maptParams"] ~= nil) then
            cfg["maptParams"] = conf["maptParams"]
        end
    end                

    return cfg
end

--[[
*******************************************************************************
-- @name nimfConn.ipv6DhcpDeconfigure
--
-- @description This function deletes the IPv6 DHCP configuration
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv6DhcpDeconfigure(conf)
    local query = nil
    local errstr = ""
    local valid

    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "'"
    valid, errstr = db.deleteRowWhere("dhcpv6c", query)
    if (not valid) then
        return "ERROR", errstr
    end
            
    -- de-configure slaac on this interface
    local status, errCode = nimfConn.ipv6AutoDeconfigure(conf)
    if (status ~= "OK") then
        nimf.dprintf("ipv6DhcpDeconfigure: failed to de-configure slaac") 
    end            

    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- @name nimfConn.ipv6DhcpConfValidate
--
-- @description This function validates the IPv6 DHCP configuration
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv6DhcpConfValidate(conf)
    return "OK", "STATUS_OK"
end

--[[
*******************************************************************************
-- @name nimfConn.ipv6DhcpConfigure
--
-- @description This function configures IPv6 DHCP for the given network
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv6DhcpConfigure(conf)
    require "teamf1lualib/dhcpv6"
    local query = nil
    local record = {}
    local cfg = {}
    local errstr = ""
    local valid
    local rowid

    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "'"
    record = db.getRowWhere("dhcpv6c", query, false)
    if (record == nil) then
        -- initialize configuration
        cfg = nimfConn.ipv6DhcpCfgInit(record, conf)
            
        -- add configuration
        cfg = util.addPrefix(cfg, "dhcpv6c.")
        valid, errstr, rowid = dhcpv6.config ("dhcpv6c", cfg, nil, "add")
    else
        -- Add file check if pd is changed
        if (util.fileExists("/pfrm2.0/ETHERNET_ONLY") or util.fileExists("/pfrm2.0/HW_HG260ES") or
            util.fileExists("/pfrm2.0/HW_JCE410") or util.fileExists("/pfrm2.0/DEVICE_REPEATER") ) then
            if (record["prefixDelegation"] ~= conf["prefixDelegation"]) then
                -- Add file to identify file to know pd has changed
                if(util.fileExists("/flash/configMerge/pdChange") == false) then
                    local pdChange = io.open("/flash/configMerge/pdChange", "w")                                                          
                    if(pdChange ~= nil) then
                        pdChange:close()         
                    end  
                end
            end
        end

        -- initialize configuration
        cfg = nimfConn.ipv6DhcpCfgInit(record, conf)
        nimf.dprintf("ipv6DhcpConfigure: conf:" .. util.tableToStringRec(cfg))

        local changed = nimf.hasTableChanged("dhcpv6c", cfg, cfg["_ROWID_"])
        if (not changed) then
            valid = true
            rowid =  false
        else
            --
            -- Set this to true to indicate configuration has changed
            --
            rowid =  true

            -- update configuration
            cfg = util.addPrefix(cfg, "dhcpv6c.")
            valid, errstr = dhcpv6.config ("dhcpv6c", cfg, cfg["dhcpv6c._ROWID_"], "edit")
        end            
    end        

    if (not valid) then
        return "ERROR", errstr
    end
            
    cfg = util.removePrefix(cfg, "dhcpv6c.")
    if (tonumber(cfg["statelessMode"]) > 0) then
        -- configure slaacd for IP and default route configuration
        cfg["GetIpFromIsp"] =  "1"
        cfg["GetDnsFromIsp"] = "0"
        cfg["ConfigureDNS"] =  "0"

        local status, errCode = nimfConn.ipv6AutoConfigure(cfg)
        if (status ~= "OK") then
            nimf.dprintf("ipv6DhcpConfigure: failed to configure slaac") 
        end            
    else
        -- configure slaacd for default route configuration.
        cfg["GetIpFromIsp"] =  "0"
        cfg["GetDnsFromIsp"] = "0"
        cfg["ConfigureDNS"] =  "0"

        local status, errCode = nimfConn.ipv6AutoConfigure(cfg)
        if (status ~= "OK") then
            nimf.dprintf("ipv6DhcpConfigure: failed to configure slaac") 
        end            
    end        
                
    return "OK", "STATUS_OK", rowid
end

--[[
*******************************************************************************
-- @name nimfConn.ipv6DhcpConfGet
--
-- @description  This function gets the IPv6 DHCP configuration for the
-- given network
--
-- @param 
--
-- @return  status, errCode
--]]

function nimfConn.ipv6DhcpConfGet(conf)
    require "teamf1lualib/dhcpv6"
    local query = nil
    local record = {}
    local cfg = {}

    query = "LogicalIfName='" .. conf["LogicalIfName"] .. "'"
    record = db.getRowWhere("dhcpv6c", query, false)
    if (record ~= nil) then
        cfg["isEnabled"] = record["isEnabled"] 
        cfg["StatelessMode"] = record["statelessMode"] 
        cfg["requestPreferredAddress"] = record["requestPreferredAddress"] 
        cfg["preferredAddress"] = record["preferredAddress"] 
        cfg["preferredAddressPrefixLength"] = record["preferredAddressPrefixLength"]
        cfg["requestDNS"] = record["requestDNS"]
        cfg["requestDNSSearchList"] = record["requestDNSSearchList"]
        cfg["prefixDelegation"] = record["prefixDelegation"] 
        cfg["requestPreferredPrefix"] = record["requestPreferredPrefix"] 
        cfg["preferredPrefix"] = record["preferredPrefix"] 
        cfg["preferredPrefixPrefixLength"] = record["preferredPrefixPrefixLength"] 
        cfg["renewTime"] = record["renewTime"] 
        cfg["sendRapidCommit"] = record["sendRapidCommit"]
    end        

    return "OK", "STATUS_OK", cfg
end

-------------------------------------------------------------------------
-- @name nimfConn.ipv6DhcpDefConfGet 
--
-- @description 
--
--                  
-- @return 
--

function nimfConn.ipv6DhcpDefConfGet (connID)
    local cfg = {}

    cfg["LogicalIfName"] = connID["LogicalIfName"]
    cfg["connectionKey"] = "0"
    cfg["isEnabled"] = "1"
    cfg["statelessMode"] = "0"
    cfg["requestPreferredAddress"] = "0"
    cfg["preferredAddress"] = ""
    cfg["preferredPrefixPrefixLength"] = "0"
    cfg["requestDNS"] = "1"
    cfg["requestDNSSearchList"] = "0"
    cfg["prefixDelegation"] = "0"
    cfg["requestPreferredPrefix"] = "0"
    cfg["preferredPrefix"] = ""
    cfg["preferredPrefixPrefixLength"] = "0"
    cfg["renewTime"] = "3600"
    cfg["sendRapidCommit"] = "0"

    return cfg
end

-------------------------------------------------------------------------
-- @name nimfConn.ipv4DhcpDefConfGet 
--
-- @description 
--
--                  
-- @return 
--

function nimfConn.ipv4DhcpDefConfGet (connID)
    local cfg = {}

    cfg["LogicalIfName"] = connID["LogicalIfName"]
    cfg["GetDnsFromIsp"] = "1"
    cfg["ReleaseLease"] = "0"
    cfg["IspName"] = "0"
    cfg["PrimaryDns"] = "0.0.0.0"
    cfg["SecondaryDns"] = "0.0.0.0"

    return cfg
end

-------------------------------------------------------------------------
-- @name nimfConn.ipv6DhcpStatelessDefConfGet
--
-- @description 
--
--                  
-- @return 
--

function nimfConn.ipv6DhcpStatelessDefConfGet (connID)
    local cfg = {}

    cfg["LogicalIfName"] = connID["LogicalIfName"]
    cfg["connectionKey"] = "0"
    cfg["isEnabled"] = "1"
    cfg["statelessMode"] = "1"
    cfg["requestPreferredAddress"] = "0"
    cfg["preferredAddress"] = ""
    cfg["preferredPrefixPrefixLength"] = "0"
    cfg["requestDNS"] = "1"
    cfg["requestDNSSearchList"] = "0"
    cfg["prefixDelegation"] = "0"
    cfg["requestPreferredPrefix"] = "0"
    cfg["preferredPrefix"] = ""
    cfg["preferredPrefixPrefixLength"] = "0"
    cfg["renewTime"] = "3600"
    cfg["sendRapidCommit"] = "0"

    return cfg
end

