-- ifStatic.lua : 

-- Copyright (c) 2011, TeamF1, Inc

ifStatic = {}

-- C ifStatic library
require "ifStaticLib"
    
local LAN_IF_NAME

-- Changes to remove bridges in ODU
if (util.fileExists ("/pfrm2.0/FXN_ODU")) then
    LAN_IF_NAME = "unm"
else
    LAN_IF_NAME = "bdg2"
end

local LAN_LOGICAL_NAME = "IF2"
local LAN_IF_GROUP = 1

function ifStatic.config (inputTable, rowid, operation)
    if (operation == "add") then
        return db.insert("ifStatic", inputTable)
    elseif (operation == "edit") then
        return db.update("ifStatic", inputTable, rowid)
    elseif (operation == "delete") then
        return nil
    end
end

function ifStatic.import (configTable, defaultConfigTable, removeConfig)

    local ifStaticTable = {}
    local singleApSupport = "0"
    singleApSupport = db.getAttribute ("environment", "name", "SINGLE_AP_SUPPORT" ,"value")

    if (configTable ~= nil) then
        ifStaticTable = config.update (configTable, defaultConfigTable, removeConfig)
        if (ifStaticTable ~= nil and #ifStaticTable ~= 0) then 
            for i,v in ipairs (ifStaticTable) do

                -- Made changes for Default subnet modification to 43.x as per RJIL
                if(util.fileExists("/pfrm2.0/ETHERNET_ONLY") or util.fileExists("/pfrm2.0/HW_HG260ES") or
                    util.fileExists("/pfrm2.0/HW_JCE410")) then

                    if(util.fileExists("/flash/configMerge/ipChange") == false) then
                        if(v["LogicalIfName"] == LAN_LOGICAL_NAME  and v["AddressFamily"] == "2") then
                            if((defaultConfigTable ~= nil) and (#defaultConfigTable ~= 0)) then
                                for p,q in pairs (defaultConfigTable) do
                                    if(q["LogicalIfName"] == LAN_LOGICAL_NAME and q["AddressFamily"] == "2") then
                                        v=q
                                    end
                                end
                            end
                        end
                    end
                end
                v = util.addPrefix (v, "ifStatic.");
                if (singleApSupport ~= nil and singleApSupport ==  "1")then
                    if (v["ifStatic.LogicalIfName"] ~= "IF4" and v["ifStatic.LogicalIfName"] ~= "IF5")then
                        ifStatic.config (v, -1, "add")
                    end
                else
                    if (v["ifStatic.LogicalIfName"] ~= "IF4" and v["ifStatic.LogicalIfName"] ~= "IF5" and v["ifStatic.LogicalIfName"] ~= "IF6" and v["ifStatic.LogicalIfName"] ~= "IF7")then
                        ifStatic.config (v, -1, "add")
                    end
                end
				if (util.fileExists("/pfrm2.0/BRCMJCO300")) then
                	if(v["ifStatic.LogicalIfName"] == LAN_LOGICAL_NAME  and v["ifStatic.AddressFamily"] == "2") then
						-- this is the row for IPv4 LAN , apply IP now instead of waiting for handler to trigger
                		os.execute("/bin/brctl addbr " .. LAN_IF_NAME)
                		os.execute("/sbin/ifconfig ".. LAN_IF_NAME .. " " ..  v["ifStatic.StaticIp"] .. " netmask " .. v["ifStatic.NetMask"])
                		os.execute("/pfrm2.0/bin/ifgroup -j -d ".. LAN_IF_NAME .. " -G " .. LAN_IF_GROUP)
                	end
				end
            end
        end
    end
end

function ifStatic.export ()
    return db.getTable ("ifStatic", false)
end

if (config.register) then
   config.register("ifStatic", ifStatic.import, ifStatic.export, "1")
end

