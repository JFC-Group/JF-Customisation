--[[
#### Copyright (c) 2017, TeamF1 Networks Pvt. Ltd. 
#### (Subsidiary of D-Link India)

#### 
#### File: nimfTrExtn.lua
#### Description: 
#### TR-181 handlers for LANDevice/WANDevice. This file is included from tr69funcs.lua.
####

#### Revisions:
02g,09Nov18,swr  Changes for SPR 64806(vlan membership issue)
02f,18Sep18,swr  Changes for SPR 63317(vlan membership conf support)
02e,14Mar18,swr  Changes for SPR 63316(added params for Hosts. profile)
02d,31Oct17,swr  Changes for SPR 59254(radvd prefixes)
02c,08Sep17,swr  Changes for SPR 62295 and 62317
02b,31Jul17,swr  Changes for SPR 60117
02a,07Jun17,swr  Changes for SPR 60349
01z,30May17,swr  Changes for SPR 61006
01y,20Mar17,MSV  Made changes to display IPv6 LAN clients in ACS, SPR#60146.
01x,12May17,swr  Changes for 60750
01w,21Apr17,swr  Changes for SPR 59537.
01v,18Apr17,swr  added nil checks
01u,06Feb17,sda  Changes for SPR 59250
01t,11Jan17,swr  Changes for SPR 58560
01s,23Dec16,swr  Changes for SPR 58673.
01r,14Dec16,sda  Changes for SPR 58673.
01q,25Nov16,swr  Changes for SPR 58176.
01p,20Sep16,swr  Changes for SPR 57364.
01o,12Sep16,swr  Changes for SPR 54182.
01n,01Apr16,swr  Changes for SPR 55686.
01m,22Jan16,swr  Changes for SPR 52759.
01l,11Dec15,swr  Changes for SPR 53601.
01k,28oct15,swr  Changes for SPR 52736.
01j,13oct15,swr  Changes for SPR 53898.
01i,08oct15,swr  Fix for SPR 53606.
01h,27Aug14,swr  Changes for SPR 53057
01g,23Jul14,swr  Changes for SPR 52532
01f,15jul15,swr  Changes for SPR 51314
01e,14jul15,swr  Changes for SPR 49945
01d,13jul15,swr  Changes to get/set only one DNS Server address  
01c,29jun15,swr  Changes for SPR 52009
01b,06mar15,swr  Changes for SPR 49978
01a,01dec14,swr  changes to reboot if VLANID is changed for gpon.
]]--

nimfTr = {}

-- locals
local dbFlag = 0

--[[
--*****************************************************************************
-- nimfTr.ethCfgGet- get ethernet configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.Ethernet.Interface.0.
--
-- Enable
-- Status
-- Name
-- Upstream
-- MACAddress
-- MaxBitRate
-- DuplexMode
--
-- Returns: status, value
]]--
function nimfTr.ethCfgGet (input)

    local status = "0"
    local value = "0"
    local row = {}
    local rowId
    local query = nil
    local ethRow = {}
    local nwRow = {}
    local param = input["param"]
    local parentObjInstance = ""

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", value
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "Interface.")
    parentObjInstance = string.sub(param, 1, endIdx+2)

    --read the rowId mapping to bridgeTable
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", value
    end

    --get corresponding db entry from ethernet
    query = "_ROWID_=" .. rowId
    ethRow = db.getRowWhere ("ethernet", query, false)
    if (ethRow == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    
    --get correspnding db entry from bridgeTable 
    query = "LogicalIfName='" .. ethRow["LogicalIfName"] .. "'"
    row = db.getRowWhere ("bridgeTable", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    
    --get corresponding db entry from networkInterface
    query = "interfaceName='" .. row["interfaceName"] .. "'"
    nwRow = db.getRowWhere ("networkInterface", query, false)
    if (nwRow == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = nwRow["enable"]
    elseif(string.find(input["param"], "Status")) then
        -- Status
		if (nwRow["enable"] == "1" or "3") then
			value="Up"
		else
			value="Down"
		end
    elseif(string.find(input["param"], "Name")) then
        -- Name
        if((ethRow["interfaceName"] == "eth1") and (ethRow["LogicalIfName"] == "IF2")) then
            value = ethRow["interfaceName"]
        else
            value = row["interfaceName"]
        end
    elseif(string.find(input["param"], "Upstream")) then
        -- Upstream
        if(nwRow["zoneType"] == "secure") then
            value = "0"
        else
            value = "1"
        end
    elseif(string.find(input["param"], "MACAddress")) then
        -- MAC address
        if ((ethRow["interfaceName"] == "eth1") 
            and (ethRow["LogicalIfName"] == "IF2")) then

            local file
            local chipset = db.getAttribute("chipsetInfo", "_ROWID_", "1", "Chipset")
        
            if (chipset == "Marvell"  ) then
                file = io.open ("/tmp/lan4MAC", "r")
            else
                file = io.open ("/tmp/lanMAC1", "r")
            end
            if (file ~= nil) then
                value = file:read ("*line")
            end
        else
            require "ifDevLib"
            local conf = ifDevLib.netIfInfoGet (nwRow["LogicalIfName"])
            if (conf == nil) then
                return "1" ,"DB_ERROR_TRY_AGAIN"
            end
            value = conf["ifHwAddr"]
        end
    elseif(string.find(input["param"], "MaxBitRate")) then
        -- MaxBitRate
        value = "1000" --both lan & wan are 1000Mbps ports
    elseif(string.find(input["param"], "DuplexMode")) then
        -- DuplexMode
        value = ethRow["duplex"]
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- nimfTr.ethCfgSet- set ethernet configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.Ethernet.Interface.0.
--
-- Enable
-- MaxBitRate
-- DuplexMode
--
-- Returns: status
]]--
function nimfTr.ethCfgSet(input, rowids, actionType, tr69Param)
    --Setting of any of these values is currently not supported in this device
    local status = "0"
    tr69Glue.tf1Dbg("Entering & Leaving nimfTr.ethCfgSet..")
    return 0;
end

--[[
--*****************************************************************************
-- nimfTr.ipCfgGet- get ip configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.IP.Interface.0.
--
-- Enable
-- IPv4Enable
-- Status
-- Name
-- Type
--
-- Returns: status, value
]]--
function nimfTr.ipCfgGet (input)

    local status = "0"
    local value = "0"
    local row = {}
    local rowId
    local query = nil
    local nwRow = {}
    local nimfRow = {}
    local ipConfRow = {}
    local param = input["param"]
    local parentObjInstance = ""

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", value
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "Interface.")
    parentObjInstance = string.sub(param, 1, endIdx+2)

    --read the rowId mapping to bridgeTable
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", value
    end

    --get correspnding db entry from bridgeTable 
    query = "_ROWID_=" .. rowId
    nwRow = db.getRowWhere ("networkInterface", query, false)
    if (nwRow == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get correspnding db entry from ipConf Table 
    query = "_ROWID_=1"
    ipConfRow = db.getRowWhere ("ipConf", query, false)
    if(ipConfRow == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    -- For Last Change parameter
    require "nimfLib"
    local connID = {}
    connID["LogicalIfName"] = nwRow["LogicalIfName"]
    if(connID["LogicalIfName"] == "sit0-WAN") then
        connID["AddressFamily"] = "10"
    else
        connID["AddressFamily"] = "2"
    end
    connID["ConnectionKey"] = "0"

    --if wan iface then get corresponding row from NimfConf tbl
    --and check connection type
    if(nwRow["zoneType"] == "insecure" and nwRow["LogicalIfName"] == "IF1") then

        --get corresponding db entry from NimfConf
        query = "LogicalIfName='" .. nwRow["LogicalIfName"] .. "'"
        query = query .. " and " .. "AddressFamily='2'"
        nimfRow = db.getRowWhere ("NimfConf", query, false)
        if(nimfRow == nil) then
            return "1", "DB_ERROR_TRY_AGAIN"
        end

        --possible connection types: dhcpc,ifStatic,pppoe,pptp,l2tp
        if(nimfRow["ConnectionType"] ~= "dhcpc" and nimfRow["ConnectionType"] ~= "ifStatic" and nimfRow["ConnectionType"] ~= "pppoe" and nimfRow["ConnectionType"] ~= "pptp" and nimfRow["ConnectionType"] ~= "l2tp") then
            if(string.find(input["param"], "Enable")) then
                -- Enable
                value = "0"
            elseif(string.find(input["param"], "IPv4Enable")) then
                -- IPv4Enable
                value = ipConfRow["IPv4Enable"]
            elseif(string.find(input["param"], "IPv6Enable")) then
                -- IPv6Enable
                value = ipConfRow["IPv6Enable"]
            elseif(string.find(input["param"], "Status")) then
                -- Status
    			value="Down"
            elseif(string.find(input["param"], "Name")) then
                -- Name
                value = nwRow["interfaceName"]
            elseif(string.find(input["param"], "LowerLayers")) then
                -- LowerLayers
                if (nwRow["LogicalIfName"] == "IF1") then
                    value = "WAN"
                else
                    value = "LAN"
                end
            elseif(string.find (input["param"], "LastChange")) then
                require "teamf1lualib/ifDevTrExtn"
                local lastChange = ""
                local conn = nimfLib.connGet (connID)
                if (conn ~= nil) then
                    if (string.find(conn["Uptime"], "N/A")) then
                        value = "0"
                    else
                        lastChange = ifDevTr.timeInSecs(conn["Uptime"])
                        value = tostring(lastChange)
                    end
                end
            elseif(string.find(input["param"], "Type")) then
                -- Type
                value = "Normal"
            elseif(string.find(input["param"], "Reset")) then
                -- Reset
                value = 0
            elseif(string.find(input["param"], "MaxMTUSize")) then
                -- MaxMTUSize
                value = nwRow["mtu"]
            else
                return "1", "DB_ERROR_TRY_AGAIN"
            end

            return status, value
        end
    end

    --find & return parameter values
    if(string.find(input["param"], "IPv4Enable")) then
        -- IPv4Enable
        value = ipConfRow["IPv4Enable"]
    elseif(string.find(input["param"], "IPv6Enable")) then
        -- IPv6Enable
        value = ipConfRow["IPv6Enable"]
    elseif(string.find(input["param"], "Enable")) then
        -- Enable
        value = nwRow["enable"]
    elseif(string.find(input["param"], "Status")) then
        -- Status
		if (nwRow["enable"] == "1") then
			value="Up"
		else
			value="Down"
		end
    elseif(string.find(input["param"], "Name")) then
        -- Name
        value = nwRow["interfaceName"]
    elseif(string.find(input["param"], "Type")) then
        -- Type
        value = "Normal"
    elseif(string.find(input["param"], "Reset")) then
        -- Reset
        value = 0
    elseif(string.find(input["param"], "LowerLayers")) then
        -- LowerLayers
        local queryGre = "_ROWID_=" .. rowId
        local eogreRow = db.getRowWhere ("Eogre", queryGre, false)
        if (nwRow["LogicalIfName"] == "IF1") then
            -- WAN
            local gponStatus = db.getAttribute("gpon", "_ROWID_", "1", "status")

            if(nimfRow["ConnectionType"] == "pppoe" or nimfRow["ConnectionType"] == "pptp" or nimfRow["ConnectionType"] == "l2tp") then
                value = "Device.PPP.Interface.1."
            elseif(gponStatus == "0" and (nimfRow["ConnectionType"] == "dhcpc" or nimfRow["ConnectionType"] == "ifStatic")) then
                value = "Device.Ethernet.Interface.1."
            elseif(gponStatus == "1" and (nimfRow["ConnectionType"] == "dhcpc" or nimfRow["ConnectionType"] == "ifStatic")) then
                value = "Device.Optical.Interface.1."
            else
                value = ""
            end
            if(eogreRow ~= nil and eogreRow["Enable"] == "1") then
                value = value..",".."Device.GRE.Tunnel.1.Interface.1."
            end
        elseif (nwRow["LogicalIfName"] == "IF2") then
            -- LAN
            value = "Device.Ethernet.Interface.2."
            local vapTbl = db.getTable("dot11VAP", false)
            for k,v in pairs (vapTbl) do
                if(v["vapEnabled"] == "1") then
                    value = value..",".."Device.WiFi.SSID."..k.."."
                end
            end
        else
            value = ""
        end
    elseif(string.find(input["param"], "MaxMTUSize")) then
        -- MaxMTUSize
        if (nwRow["mtu"] == nil or nwRow["mtu"] == "" ) then
            value = 1500
        else
            value = nwRow["mtu"]
        end
    elseif(string.find (input["param"], "LastChange")) then
        require "teamf1lualib/ifDevTrExtn"
        local lastChange = ""
        local conn = nimfLib.connGet (connID)
        if (conn ~= nil) then
            if (string.find(conn["Uptime"], "N/A")) then
                value = "0"
            else
                lastChange = ifDevTr.timeInSecs(conn["Uptime"])
                value = tostring(lastChange)
            end
        end
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- nimfTr.ipCfgSet- set ip configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.IP.Interface.0.
--
-- Enable
-- IPv4Enable
--
-- Returns: status
]]--
function nimfTr.ipCfgSet (input, rowids, actionType, tr69Param)
    local status = OK
    local confTbl = {}
    local resetFlg = "0"
    local mtuFlag = "0"
    local faultTbl = {}
    local index = 0

    tr69Glue.tf1Dbg("Entering nimfTr.ipCfgSet..")
   
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(tr69Param, "Interface.")
    parentObjInstance = string.sub(tr69Param, 1, endIdx+2)

    --read the rowId mapping to networkInterface
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get correspnding db entry from networkInterface 
    query = "_ROWID_=" .. rowId
    nwRow = db.getRowWhere ("networkInterface", query, false)
    if (nwRow == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    if(input["bridgeTable"]["bridgeTable.Reset"] ~= nil and input["bridgeTable"]["bridgeTable.Reset"] == "1") then
        resetFlg = "1"
    end

    if(input["bridgeTable"]["bridgeTable.MaxMTUSize"] ~= nil) then
        if(tonumber(input["bridgeTable"]["bridgeTable.MaxMTUSize"]) >= MTU_MIN_VAL and tonumber(input["bridgeTable"]["bridgeTable.MaxMTUSize"]) <= MTU_MAX_VAL) then
            nwRow["mtu"] = input["bridgeTable"]["bridgeTable.MaxMTUSize"]
            mtuFlg = "1"
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."MaxMTUSize", error_code.INVALID_PARAM_VALUE)
        end
    end

    nwRow = util.addPrefix(nwRow, "networkInterface.")
    if(mtuFlg == "1") then
        local valid, errstr = db.update("networkInterface", nwRow, nwRow["networkInterface._ROWID_"])
        if (not valid) then
           status = ERROR
           index = index + 1
           faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
           return status, faultTbl;
        end
    end

    if(status == ERROR) then 
        return status, faultTbl
    end

    if (resetFlg == "1") then
        db.setAttribute("NimfConf", "NimfConf.LogicalIfName", nwRow["networkInterface.LogicalIfName"], "Enable", "0")
        db.setAttribute("NimfConf", "NimfConf.LogicalIfName", nwRow["networkInterface.LogicalIfName"], "Enable", "1")
    end

    db.save()
    return 0;
end

--[[
--*****************************************************************************
-- nimfTr.ipConnGet- get ip configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.IP.Interface.0.IPv4Address.0.
--
-- Enable
-- IPAddress
-- SubnetMask
-- AddresingType
--
-- Returns: status, value
]]--
function nimfTr.ipConnGet (input)

    local status = "0"
    local value = "0"
    local row = {}
    local rowId
    local query = nil
    local ipaddrRow = {}
    local nwRow = {}
    local param = input["param"]
    local parentObjInstance = ""

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", value
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "IPv4Address.")
    parentObjInstance = string.sub(param, 1, endIdx+2)

    --read the rowId mapping to NimfConf
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", value
    end

    --get corresponding db entry from NimfConf
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("NimfConf", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from networkInterface
    query = "LogicalIfName='" .. row["LogicalIfName"] .. "'"
    nwRow = db.getRowWhere ("networkinterface", query, false)
    if(nwRow == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --if wan iface then check connection type
    if(nwRow["zoneType"] == "insecure" and nwRow["LogicalIfName"] == "IF1") then
        --possible connection types: dhcpc,ifStatic,pppoe,pptp,l2tp
        if(row["ConnectionType"] ~= "dhcpc" and row["ConnectionType"] ~= "ifStatic" and row["ConnectionType"] ~= "pppoe" and row["ConnectionType"] ~= "pptp" and row["ConnectionType"] ~= "l2tp") then
            if(string.find(input["param"], "Enable")) then
                -- Enable
                value = "0"
            elseif(string.find(input["param"], "IPAddress")) then
                -- IPAddress
                value = "0.0.0.0"
            elseif(string.find(input["param"], "SubnetMask")) then
                -- SubnetMask
        		value = "0.0.0.0"
            elseif(string.find(input["param"], "AddressingType")) then
                -- AddressingType
       			value = "None"
            elseif(string.find(input["param"], "Status")) then
                -- Status
       			value = "Error_Misconfigured"
            else
                return "1", "DB_ERROR_TRY_AGAIN"
            end
            
            return status, value
        end
    end
    
    --get corresponding db entry from ipAddressTable
    query = "LogicalIfName='" .. row["LogicalIfName"] .. "'"
    query = query .. " and ConnectionKey='" .. row["ConnectionKey"] .. "'" .. " and addressFamily=2"
    ipaddrRow = db.getRowWhere ("ipAddressTable", query, false)
    if (ipaddrRow ~= nil) then
        if(string.find(input["param"], "IPAddress")) then
            -- IPAddress
            value = ipaddrRow["ipAddress"]
        elseif(string.find(input["param"], "SubnetMask")) then
            -- SubnetMask
            value = ipaddrRow["subnetMask"]
        elseif(string.find(input["param"], "Status")) then
            -- Status
            value = "Enabled"
        end
    else
        if(string.find(input["param"], "IPAddress")) then
            -- IPAddress
            value = "0.0.0.0"
        elseif(string.find(input["param"], "SubnetMask")) then
            -- SubnetMask
            value = "0.0.0.0"
        elseif(string.find(input["param"], "Status")) then
            -- Status
            value = "Error_Misconfigured"
        end
    end

    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = row["Enable"]
    elseif(string.find(input["param"], "AddressingType")) then
        -- AddressingType
		if (row["ConnectionType"] == "ifStatic") then
			value = "Static"
		elseif(row["ConnectionType"] == "dhcpc") then
			value = "DHCP"
                elseif(row["ConnectionType"] == "pppoe" or row["ConnectionType"] == "pptp" or row["ConnectionType"] == "l2tp") then
			value = "IPCP"
		end
    end

    return status, value
end

--[[
--*****************************************************************************
-- nimfTr.ipConnSet- set ip configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.IP.Interface.0.IPv4Address.0.
--
-- Enable
-- IPAddress
-- SubnetMask
--
-- Returns: status, value
]]--
function nimfTr.ipConnSet (input, rowids, actionType, tr69Param)

    local status = OK 
    local row = {}
    local rowId
    local query = nil
    local ipConfTbl = {}
    local nwRow = {}
    local faultTbl = {}
    local index = 0
--[[
    local valTable = {}
    valTable = input["ipConf"]
    for k,v in pairs(valTable) do
        tr69Glue.tf1Dbg(k .. " -- " .. v)
    end
]]--

    if(input["ipAddressTable"]["ipAddressTable.ipAddress"] ~= nil) then
       if(tr69Glue.tf1IpAddressValidate(input["ipAddressTable"]["ipAddressTable.ipAddress"],"","","") ~= "OK") then
          status = ERROR 
          index = index + 1
          faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."IPAddress", error_code.INVALID_PARAM_VALUE)
       else
          ipConfTbl["ipAddress"] = input["ipAddressTable"]["ipAddressTable.ipAddress"]
       end
    end

    if(input["ipAddressTable"]["ipAddressTable.subnetMask"] ~= nil) then
        if(tr69Glue.tf1CheckSubnetValue(input["ipAddressTable"]["ipAddressTable.subnetMask"], "") == 1) then
          status =  ERROR
          index = index + 1
          faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."SubnetMask", error_code.INVALID_PARAM_VALUE)
       else
          ipConfTbl["subnetMask"] = input["ipAddressTable"]["ipAddressTable.subnetMask"]
       end
    end

    if(status == ERROR) then
      return status, faultTbl
    end

    if(ipConfTbl["ipAddress"] == nil and ipConfTbl["subnetMask"] == nil) then
       return 0;
    end

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR 
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --extract the Device.IP.Interface.{i}.IPv4Address.{i}. part from tr69Param
    local startIdx, endIdx
    local parentObjInstance
    startIdx, endIdx = string.find(tr69Param, "IPv4Address.")
    parentObjInstance = string.sub(tr69Param, 1, endIdx+2)

    --read the rowId mapping of the corresponding Device.IP.Interface.{i}.IPv4Address.{i}.
    --object to NimfConf
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        status = ERROR 
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get correspnding db entry from NimfConf
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("NimfConf", query, false)
    if(row == "nil") then
        status = ERROR 
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get corresponding db entry from networkInterface
    query = "LogicalIfName='" .. row["LogicalIfName"] .. "'"
    nwRow = db.getRowWhere ("networkinterface", query, false)
    if(nwRow == nil) then
        status = ERROR 
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --if wan iface then check connection type
    if(nwRow["zoneType"] == "insecure" and nwRow["LogicalIfName"] == "IF1") then
        --possible connection types: dhcpc,ifStatic,pppoe,pptp,l2tp
        if(row["ConnectionType"] ~= "dhcpc" and row["ConnectionType"] ~= "ifStatic") then
            status =  ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl;
        end
    end
        
    if(row["LogicalIfName"] == "IF1") then
        ipConfTbl["LogicalIfName"] = "IF1"
        nimfTr.wanIPConnSet(ipConfTbl)
    elseif(row["LogicalIfName"] == "IF2") then
        ipConfTbl["LogicalIfName"] = "IF2"
        nimfTr.lanIPConnset(ipConfTbl)
    else
        return 0;
    end
    
    db.save ()
    return 0;
end

function nimfTr.lanIPConnset(ipConfTbl)
    require "teamf1lualib/nimf"
    require "teamf1lualib/nimfConn"
    require "teamf1lualib/gui"

    local lanObjConfig = {}
    local lanConf = {}
    local stat, err
    local nwName
    local status = "0"

    --ipConfTbl["ipAddress"]
    --ipConfTbl["subnetMask"]
    --ipConfTbl["LogicalIfName"]

    -- get the network info for interfacename 
    nwName = db.getAttribute ("networkInterface", "LogicalIfName", ipConfTbl["LogicalIfName"], "networkName")

    -- get lan configuration in device
    stat, err, lanConf = gui.networking.network.ipv4.get (nwName)

    -- fill entries as required by nimfConn.configure routine
    lanObjConfig["Enable"] = lanConf["Enable"] 
    lanObjConfig["ConnectionKey"] = "0" -- default lan network
    lanObjConfig["GetDnsFromIsp"] = lanConf["GetDnsFromIsp"] 
    lanObjConfig["PrimaryDns"] = lanConf["PrimaryDns"] 
    lanObjConfig["SecondaryDns"] = lanConf["SecondaryDns"]
    lanObjConfig["LogicalIfName"] = lanConf["LogicalIfName"]
    lanObjConfig["AddressFamily"] = "2" -- lan ipv4 configuration
    lanObjConfig["ConnectionType"] = lanConf["ConnectionType"] 
    lanObjConfig["DomainName"] = lanConf["DomainName"] 
    lanObjConfig["DNSServers"] = lanConf["DNSServers"] 
    lanObjConfig["ReleaseLease"] = "0" 
    lanObjConfig["ConfigureRoute"] = "1" 
    lanObjConfig["IspName"] = "0" 
    lanObjConfig["ConfigureDNS"] = "1"
    lanObjConfig["WarnDisconnectDelay"] = "0" 
    lanObjConfig["DefaultConnection"] = "0"
    -- update with the values received from acs
    if(ipConfTbl["ipAddress"] ~= nil) then
        lanObjConfig["StaticIp"] = ipConfTbl["ipAddress"]
    else
        lanObjConfig["StaticIp"] = lanConf["StaticIp"]
    end

    if(ipConfTbl["subnetMask"] ~= nil) then
        lanObjConfig["NetMask"] = ipConfTbl["subnetMask"]
    else
        lanObjConfig["NetMask"] = lanConf["NetMask"]
    end

    -- configure lan connection with new lan properties
    status = nimfConn.configure(lanObjConfig);
    if (status ~= "OK") then
        tr69Glue.tf1Dbg("nimfConn.configure failed to configure the lan interface..")
    else
        tr69Glue.tf1Dbg("nimfConn.configure Successfully updated lan settings..")
    end

end

function nimfTr.wanIPConnSet(ipConfTbl)
	require "teamf1lualib/nimf"
    require "teamf1lualib/nimfConn"
	local wanObjConfig = {}
	local wanTypeConfig = {}
	local tmpVal = nil
	local wanConnObj = {}
    local wanDefConn = {}
    local connID = {}
    local stat
    local err
    local status = "0"
    
    --ipConfTbl["ipAddress"]
    --ipConfTbl["subnetMask"]
    --ipConfTbl["LogicalIfName"]

    wanTypeConfig["ifStatic.StaticIp"] = ipConfTbl["ipAddress"]
    wanTypeConfig["ifStatic.NetMask"] = ipConfTbl["subnetMask"]

    --get configuration in device
    wanDefConn = nimf.getDefConnCfg ();

    -- get default wan connection object
	if (wanDefConn ~= nil) then
		connID ["LogicalIfName"] = ipConfTbl["LogicalIfName"];
        connID ["AddressFamily"] = "2";
	    connID ["ConnectionType"] = wanDefConn["connection_type"];
        
        stat, err, wanConnObj = nimfConn.defConfGet(connID)
        if (wanConnObj == nil) then
            return 1;
        end
	end

    -- filling in al fields so that we don't loose configuration while setting
    -- dnsserver/interface enable/disable/gateway individually. 
    if(ipConfTbl["ipAddress"] ~= nil) then
        wanConnObj["StaticIp"] = ipConfTbl["ipAddress"]
    else
        wanConnObj["StaticIp"] = wanDefConn["ipAddress"]
    end

    if(ipConfTbl["subnetMask"] ~= nil) then
        wanConnObj["NetMask"] = ipConfTbl["subnetMask"]
    else
        wanConnObj["NetMask"] = wanDefConn["subnetMask"];
    end

    wanConnObj["Gateway"] = wanDefConn["Gateway"];
    wanConnObj["PrimaryDns"] = wanDefConn["nameserver1"];
    wanConnObj["SecondaryDns"] = wanDefConn["nameserver2"];
    wanConnObj["ConnectionType"] = wanDefConn["connection_type"];

    if (wanDefConn["status"] == "UP") then
       wanConnObj["Enable"] = "1"
    end

    -- set configure route
    local query = "LogicalIfName='" .. ipConfTbl["LogicalIfName"] .. "' and AddressFamily=2"
    local nimfConfRow = db.getRowWhere ("NimfConf", query, false);
    tmpVal = nimfConfRow["DefaultConnection"]
    if (tmpVal ~= nil) then
        wanConnObj["DefaultConnection"] = tmpVal
    end

    local status = nimfConn.configure(wanConnObj);
    if (status ~= "OK") then
        tr69Glue.tf1Dbg("nimfConn.configure failed to configure the wan interface..")
    else
        tr69Glue.tf1Dbg("nimfConn.configure Successfully updated wan settings..")
    end

end

--[[
--*****************************************************************************
-- nimfTr.lanDhcpsGet- get lan dhcp server configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.DHCPv4.Server.Enable &
-- Device.DHCPv4.Server.Pool.0.
--
-- Enable
-- Status
-- Order
-- Interface
-- MinAddress
-- MaxAddress
-- SubnetMask
-- DNSServers
-- IPRouters
--
-- Returns: status, value
]]--
function nimfTr.lanDhcpsGet (input)
    local status = "0"
    local value = "0"
    local row = {}
    local query = nil
    local query1 = nil
    local param = input["param"]
    local lanIpRow = {}

    --get corresponding db entry from DhcpServerPools
    query = "_ROWID_=1"
    row = db.getRowWhere ("DhcpServerPools", query, false)
    if (row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end


    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = row["Enable"]
    elseif(string.find(input["param"], "Status")) then
        -- Status
		if (row["Enable"] == "1") then
			value="Enabled"
		else
			value="Disabled"
		end
    elseif(string.find(input["param"], "Order")) then
        -- Order
        value = row["PoolID"]
    elseif(string.find(input["param"], "Interface")) then
        -- Interface
        -- find the corresponding interface entry from instanceMap using rowId
        -- fetched from bridgeTable by row["LogicalIfName"]
        local lanDhcpIfaceObj = ""
        lanDhcpIfaceObj = nimfTr.getIfaceObjFromIfname(row["LogicalIfName"])
        value = lanDhcpIfaceObj
        if(value == nil or value == "") then
            return "1", "DB_ERROR_TRY_AGAIN"
        end
    elseif(string.find(input["param"], "MinAddress")) then
        -- MinAddress
        value = row["MinAddress"]
    elseif(string.find(input["param"], "MaxAddress")) then
        -- MaxAddress
        value = row["MaxAddress"]
    elseif(string.find(input["param"], "SubnetMask")) then
        -- SubnetMask 
        -- find the value from corresponding ifStatic entry
        query = "LogicalIfName='" .. row["LogicalIfName"] .. "'" .. " and "
        query = query .. "AddressFamily=2"
        lanIpRow = db.getRowWhere ("ifStatic", query, false)
        if (lanIpRow == nil) then
            return "1", "DB_ERROR_TRY_AGAIN"
        end
        value = lanIpRow["NetMask"]
    elseif(string.find(input["param"], "DNSServers")) then
        -- DNSServers
        -- fetch DNSServer1, DNSServer2, DNSServer3 and concatenate them
        local dnsServerList = nil
        if(row["DNSServers"] == "3" ) then
             if(row["DNSServer1"] ~= nil and row["DNSServer1"] ~= "") then
                 dnsServerList = row["DNSServer1"]
             end
             if(row["DNSServer2"] ~= nil and row["DNSServer2"] ~= "") then
                 dnsServerList = dnsServerList .. "," .. row["DNSServer2"]
             end
        elseif(row["DNSServers"] == "2" ) then
             query1 = "AddressFamily=2" 
             row1 = db.getRowWhere ("resolverConfig", query1, false)
             if (row1 == nil) then
                 return "1", "DB_ERROR_TRY_AGAIN"
             end
              if(row1["nameserver1"] ~= nil and row1["nameserver1"] ~= "") then
                 dnsServerList = row1["nameserver1"]
             end
             if(row1["nameserver2"] ~= nil and row1["nameserver2"] ~= "") then
                 dnsServerList = dnsServerList .. "," .. row1["nameserver2"]
             end
        else
            dnsServerList = row["IPRouters"]
        end

        if(dnsServerList == nil) then 
            value = "0.0.0.0"
        else
            value = dnsServerList
        end
    elseif(string.find(input["param"], "DomainName")) then
        -- DomainName
        value = row["DomainName"]
    elseif(string.find(input["param"], "IPRouters")) then
        -- IPRouters
        -- Return LAN IPv4 address here
        query = "LogicalIfName='" .. row["LogicalIfName"] .. "'" .. " and "
        query = query .. "AddressFamily=2"
        lanIpRow = db.getRowWhere ("ifStatic", query, false)
        if (lanIpRow == nil) then
            return "1", "DB_ERROR_TRY_AGAIN"
        end
        value = lanIpRow["StaticIp"]
    elseif(string.find(input["param"], "LeaseTime")) then
        -- LeaseTime
        local time = util.split(row["DHCPLeaseTime"], ".")
        value = tonumber(time[1]) * 3600
    elseif(string.find(input["param"], "X_RJIL_COM_MultiSubnet")) then
        -- X_RJIL_COM_MultiSubnet
        value = rowMultiSubnet["status"]
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- nimfTr.getIfaceObjFromIfname - get object instance name from logicalIfName
-- 
-- Returns: ifaceObjInstanceName or nil
]]--
function nimfTr.getIfaceObjFromIfname(logicalIfName)
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return
    end
    local ifaceObj = "Device.IP.Interface."

    --get correspnding db entry from bridgeTable 
    local netInterfaceRow = {}
    local query = nil
    query = "LogicalIfName='" .. logicalIfName .. "'"
    netInterfaceRow = db.getRowWhere ("networkInterface", query, false)
    if(netInterfaceRow == nil) then
        return 
    end
    
    local numNetInterfaceRows = db.getTable ("networkInterface")

    local i
    for i = 1,#numNetInterfaceRows,1 do
        if(instanceMap[ifaceObj .. i .. "."] == nil) then 
            return
        end

        if(instanceMap[ifaceObj .. i .. "."] == netInterfaceRow["_ROWID_"]) then 
            return(ifaceObj .. i .. ".")
        end
    end
end

--[[
--*****************************************************************************
-- nimfTr.lanDhcpsSet- set lan dhcp server configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.DHCPv4.Server.Enable &
-- Device.DHCPv4.Server.Pool.0.
--
-- Enable
-- Order
-- Interface
-- MinAddress
-- MaxAddress
-- SubnetMask
-- DNSServers
-- IPRouters
--
-- Returns: status, value
]]--
function nimfTr.lanDhcpsSet(input, rowids, actionType, tr69Param)
    local status = OK
    local inRow = {}
    local dhcpServerPoolRow = {}
    local updateFlag = 0;
    local k,v
    local inputTable = {}
    local faultTbl = {}
    local index = 0
    local errorFlag = "OK"
    local startIPflag = 0;
    local stopIPflag = 0;
    local IPRoutersflag = 0;

    inRow = input["DhcpServerPools"]

    -- Enable
    -- MinAddress
    -- MaxAddress
    -- SubnetMask
    -- DNSServers, DNSServer1, DNSServer2

    local dhcpPoolRow = db.getRow("DhcpServerPools", "_ROWID_", "1")

    local query = "LogicalIfName='IF2' and AddressFamily=2"
    local ifStaticRow = db.getRowWhere("ifStatic",  query, false)

    inputTable["StaticIp"] = dhcpPoolRow["DhcpServerPools.IPRouters"]
    inputTable["dhcpStopIP"] = dhcpPoolRow["DhcpServerPools.MaxAddress"]
    inputTable["DNSServers"] = dhcpPoolRow["DhcpServerPools.DNSServers"]
    inputTable["NetMask"] = ifStaticRow["NetMask"]
    inputTable["DomainName"] = dhcpPoolRow["DhcpServerPools.DomainName"]
    inputTable["networkType"] = "LAN"
    inputTable["dhcpStartIP"] = dhcpPoolRow["DhcpServerPools.MinAddress"]
    inputTable["dhcpLeaseTime"] = dhcpPoolRow["DhcpServerPools.DHCPLeaseTime"]
    inputTable["PrimaryDns"] = dhcpPoolRow["DhcpServerPools.DNSServer1"]
    inputTable["SecondaryDns"] = dhcpPoolRow["DhcpServerPools.DNSServer2"]
    inputTable["dhcpMode"] = dhcpPoolRow["DhcpServerPools.Enable"] 
   
    if(inRow["DhcpServerPools.Enable"] ~= nil) then
        if(inRow["DhcpServerPools.Enable"] == "0") then
            inputTable["dhcpMode"] = "0"
        elseif(inRow["DhcpServerPools.Enable"] == "1") then
            inputTable["dhcpMode"] = "1"
        end
        updateFlag = 1
    end 
    if((inRow["DhcpServerPools.IPRouters"]) ~= nil) then
        if(inputTable["dhcpMode"] == "1") then
            if(tr69Glue.tf1IpAddressValidate(inRow["DhcpServerPools.IPRouters"], "","IPRouters","") ~= "OK" and (ifDev.validateAddrInNetwork(inRow["DhcpServerPools.IPRouters"],inputTable["interfaceName"]) ~= 1)) then
                IPRoutersflag = 1 
            end
            if((inRow["DhcpServerPools.MinAddress"]) == nil ) then
                if(ifDevLib.subnetCompare(inRow["DhcpServerPools.IPRouters"],inputTable["dhcpStartIP"],inputTable["NetMask"]) ~= 1 ) then
                    IPRoutersflag = 1 
                end
            end
            if((inRow["DhcpServerPools.MaxAddress"]) == nil) then
                if(ifDevLib.subnetCompare(inRow["DhcpServerPools.IPRouters"],inputTable["dhcpStopIP"],inputTable["NetMask"]) ~= 1) then
                    IPRoutersflag = 1 
                end
            end
            if(IPRoutersflag == 1) then 
               status = ERROR
               index = index + 1
               faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."IPRouters", error_code.INVALID_PARAM_VALUE)
            else
               inputTable["StaticIp"] = inRow["DhcpServerPools.IPRouters"]
               updateFlag = 1
            end
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."IPRouters", error_code.REQUEST_DENIED)
        end
    end

    if(inRow["DhcpServerPools.SubnetMask"] ~= nil) then
        if(inputTable["dhcpMode"] == "1") then
            if(tr69Glue.tf1CheckSubnetValue(inRow["DhcpServerPools.SubnetMask"], "") == 1) then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."SubnetMask", error_code.INVALID_PARAM_VALUE)
            end
            inputTable["NetMask"] = inRow["DhcpServerPools.SubnetMask"]
            updateFlag = 1
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."SubnetMask", error_code.REQUEST_DENIED)
        end
    end

    if((inRow["DhcpServerPools.MinAddress"]) ~= nil) then
        if(inputTable["dhcpMode"] == "1") then
            if (tr69Glue.tf1IpAddressValidate(inRow["DhcpServerPools.MinAddress"],"","MinAddress","") ~= "OK" or ifDevLib.subnetCompare(inputTable["StaticIp"],inRow["DhcpServerPools.MinAddress"],inputTable["NetMask"]) ~= 1 ) then
                startIPflag = 1
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."MinAddress", error_code.INVALID_PARAM_VALUE)
            end
            inputTable["dhcpStartIP"] = inRow["DhcpServerPools.MinAddress"]
            updateFlag = 1
        else
            startIPflag = 1
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."MinAddress", error_code.REQUEST_DENIED)
        end
    end

    if((inRow["DhcpServerPools.MaxAddress"]) ~= nil) then
        if(inputTable["dhcpMode"] == "1") then
            if(tr69Glue.tf1IpAddressValidate(inRow["DhcpServerPools.MaxAddress"],"","MaxAddress","") ~= "OK" or ifDevLib.subnetCompare(inputTable["StaticIp"],inRow["DhcpServerPools.MaxAddress"],inputTable["NetMask"]) ~= 1) then
                stopIPflag = 1
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."MaxAddress", error_code.INVALID_PARAM_VALUE)
            end
            inputTable["dhcpStopIP"] = inRow["DhcpServerPools.MaxAddress"]
            updateFlag = 1
        else
            stopIPflag = 1
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."MaxAddress", error_code.REQUEST_DENIED)
        end
    end

    if((inRow["DhcpServerPools.MinAddress"]) ~= nil or (inRow["DhcpServerPools.MaxAddress"]) ~= nil) then
        if (validations.tf1compareIP(inputTable["dhcpStartIP"],inputTable["dhcpStopIP"]) ~= "OK") then
            if((inRow["DhcpServerPools.MinAddress"]) ~= nil and startIPflag == 0) then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."MinAddress", error_code.INVALID_PARAM_VALUE)
            elseif((inRow["DhcpServerPools.MaxAddress"]) ~= nil and stopIPflag == 0) then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."MaxAddress", error_code.INVALID_PARAM_VALUE)
            end
        end
    end
        
    if(inRow["DhcpServerPools.DNSServer1"] ~= nil) then
        --parse the value and assign to corresponding fields
        if(inputTable["dhcpMode"] == "1") then
        local tab = util.split(inRow["DhcpServerPools.DNSServer1"], ",")
            if(tab[1] ~= nil and tab[2] ~= nil) then
                local server1 = ""
                inputTable["DNSServers"] = "3"
                inputTable["PrimaryDns"] = tab[1]
                if(tr69Glue.tf1IpAddressValidate(inputTable["PrimaryDns"], "","PrimaryDns","") ~= "OK") then
                    server1 = ERROR
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."DNSServers", error_code.INVALID_PARAM_VALUE)
                end

                inputTable["SecondaryDns"] = tab[2]
                if(tr69Glue.tf1IpAddressValidate(inputTable["SecondaryDns"], "","SecondaryDns","") ~= "OK") then
                    if(server1 ~= ERROR) then
                        status = ERROR
                        index = index + 1
                        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."DNSServers", error_code.INVALID_PARAM_VALUE)
                    end
                end
                updateFlag = 1
            else
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."DNSServers", error_code.INVALID_PARAM_VALUE)
            end

        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."DNSServers", error_code.REQUEST_DENIED)
        end
    end

    if(inRow["DhcpServerPools.DomainName"] ~= nil) then
        if(inputTable["dhcpMode"] == "1") then
            local Tbl = {}
            local lastEntry = ""
            Tbl= util.split(inRow["DhcpServerPools.DomainName"], ".")
            if (util.tableSize(Tbl)) then
                lastEntry = Tbl[util.tableSize(Tbl)]
            end
            if(tr69Glue.tf1IpAddressValidate(inRow["DhcpServerPools.DomainName"],"","DomainName","") ~= "OK" and validations.tf1domainNameValidate(inRow["DhcpServerPools.DomainName"],lastEntry) ~= "OK") then
                tr69Glue.tf1Dbg("Debug APR domain name" .. inRow["DhcpServerPools.DomainName"] .. "lastEntry" .. lastEntry)
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."DomainName", error_code.INVALID_PARAM_VALUE)
            end 
            inputTable["DomainName"] = inRow["DhcpServerPools.DomainName"]
            updateFlag = 1
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."DomainName", error_code.REQUEST_DENIED)
        end
    end

    if(inRow["DhcpServerPools.LeaseTime"] ~= nil) then
    local leaseTime = tonumber(inRow["DhcpServerPools.LeaseTime"])
    time = leaseTime / 3600
        if(inputTable["dhcpMode"] == "1") then
            if((time >= 1 and time <= 24) and (time % 1 == 0)) then
                inputTable["dhcpLeaseTime"] = time
                updateFlag = 1
            else
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."LeaseTime", error_code.INVALID_PARAM_VALUE)
            end
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."LeaseTime", error_code.REQUEST_DENIED)
        end
    end

    tr69Glue.tf1Dbg("inputTable" ..util.tableToStringRec(inputTable))
 
    if(status == ERROR) then
       return status, faultTbl
    end

    --update the values in db
    if (updateFlag == 1) then
        require "teamf1lualib/gui"
        errorFlag, statusCode = gui.networking.network.ipv4.set("Local", inputTable)
    end
    if(errorFlag ~= "OK") then
       status = ERROR
       index = index + 1
       tr69Glue.tf1Dbg("statusCode = " ..statusCode)
       faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
    end
       
    return status, faultTbl
end

--[[
--*****************************************************************************
-- nimfTr.pppCfgGet- get ppp configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.PPP.Interface.0.
-- Enable
-- Status
-- Name
-- Username
-- Password
-- ConnectionTrigger
-- 
-- &
--
-- Device.PPP.Interface.0.PPPoE.
-- SessionID
--
-- Returns: status, value
]]--
function nimfTr.pppCfgGet (input)

    local status = "0"
    local value = "0"
    local row = {}
    local rowId
    local query = nil
    local nimfRow = {}
    local param = input["param"]

    --get corresponding db entry from 'Pppoe'
    query = "_ROWID_=1"
    row = db.getRowWhere ("Pppoe", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from 'NimfConf'
    query = "LogicalIfName='IF1' and AddressFamily=2"
    nimfRow = db.getRowWhere ("NimfConf", query, false)
    if (nimfRow == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --check connection type

    --possible connection types: dhcpc,ifStatic,pppoe,pptp,l2tp
    if(nimfRow["ConnectionType"] ~= "pppoe" and nimfRow["ConnectionType"] ~= "dhcpc" and nimfRow["ConnectionType"] ~= "ifStatic" and nimfRow["ConnectionType"] ~= "l2tp" and nimfRow["ConnectionType"] ~= "pptp") then
        if(string.find(input["param"], "Enable")) then
            -- Enable
            value = "0"
        elseif(string.find(input["param"], "Status")) then
            -- Status
            value="Down"
        elseif(string.find(input["param"], "Name")) then
            -- Name
            value = " "
        elseif(string.find(input["param"], "Username")) then
            -- Username
            value = row["UserName"]
        elseif(string.find(input["param"], "Password")) then
            -- Password
            value = row["Password"]
        elseif(string.find(input["param"], "SessionID")) then
            -- SessionID
            value = "0"
        else
            return "1", "DB_ERROR_TRY_AGAIN"
        end

        return status, value
    end

    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = "1"
    elseif(string.find(input["param"], "Status")) then
        -- Status
        value = "Up"
    elseif(string.find(input["param"], "Name")) then
        -- Name
        value = " "

        --read interfacename from the file written by pppd
        local fh = io.open("/var/pppIfaceName", "r")
        if(fh == nil) then
            tr69Glue.tf1Dbg("Couldn't open file: /var/pppIfaceName")
            return status, value
        end

        local ifname = fh:read("*all")
        if(ifname == "" or ifname == nil) then
            tr69Glue.tf1Dbg("Couldn't read anything from the file: /var/pppIfaceName")
            return status, value
        end

        value = ifname
        io.close(fh)
        return status, value
    elseif(string.find(input["param"], "Username")) then
        -- Username
        value = row["UserName"]
    elseif(string.find(input["param"], "Password")) then
        -- Password
        value = row["Password"]
    elseif(string.find(input["param"], "SessionID")) then
        -- SessionID
        value = "0"

        --read session id from the file written by pppd
        local fh = io.open("/var/pppoeSessionId", "r")
        if(fh == nil) then
            tr69Glue.tf1Dbg("Couldn't open file: /var/pppoeSessionId")
            return status, value
        end

        local sessionId = fh:read("*all")
        if(sessionId == "" or sessionId == nil) then
            tr69Glue.tf1Dbg("Couldn't read anything from the file: /var/pppoeSessionId")
            return status, value
        end

        value = sessionId
        io.close(fh)
        return status, value
    elseif(string.find(input["param"], "LowerLayers")) then
            -- LowerLayers
            local gponStatus = db.getAttribute("gpon", "_ROWID_", "1", "status")

            if((nimfRow["ConnectionType"] == "pppoe" or nimfRow["ConnectionType"] == "pptp" or nimfRow["ConnectionType"] == "l2tp") and gponStatus == "0") then
                value = "Device.Ethernet.Interface.1."
            elseif((nimfRow["ConnectionType"] == "pppoe" or nimfRow["ConnectionType"] == "pptp" or nimfRow["ConnectionType"] == "l2tp") and gponStatus == "1") then
                value = "Device.Optical.Interface.1."
            else
                value = ""
            end
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- nimfTr.pppCfgSet- set ppp configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.PPP.Interface.0.
-- Enable
-- Username
-- Password
--
-- Returns: status
]]--
function nimfTr.pppCfgSet(input, rowids, actionType, tr69Param)
    local status = "0"
    local row = {}
    local rowId
    local query = nil
    local nimfRow = {}
    local pppConfTbl = {}
    local updateFlag = "0"

    --get corresponding db entry from 'Pppoe'
    query = "_ROWID_=1"
    row = db.getRowWhere ("Pppoe", query, false)
    if(row == nil) then
        tr69Glue.tf1Dbg("Couldn't fetch corresponding Pppoe row..")
        status = "1"
        return "1";
    end

    --get corresponding db entry from 'NimfConf'
    query = "LogicalIfName='IF1' and AddressFamily=2"
    nimfRow = db.getRowWhere ("NimfConf", query, false)
    if (nimfRow == nil) then
        tr69Glue.tf1Dbg("Couldn't fetch corresponding NimfConf row..")
        status = "1"
        return "1";
    end

    --check connection type and if its not pppoe then return immediately
    --possible connection types: dhcpc,ifStatic,pppoe,pptp,l2tp
    if(nimfRow["ConnectionType"] ~= "pppoe") then
        tr69Glue.tf1Dbg("Connection tytpe is not pppoe, just return..")
        status = "1"
        return "1";
    end

    --read the set values 
    if(input["Pppoe"]["Pppoe.UserName"] ~= nil) then
        pppConfTbl["UserName"] = input["Pppoe"]["Pppoe.UserName"]
        updateFlag = "1"
    end

    if(input["Pppoe"]["Pppoe.Password"] ~= nil) then
        pppConfTbl["Password"] = input["Pppoe"]["Pppoe.Password"]
        updateFlag = "1"
    end
    
    if(updateFlag ~= "1") then
        status = "0"
        return 0;
    end

    --TODO configure the ppp connection accordingly
    pppConfTbl["LogicalIfName"] = "IF1"
    nimfTr.wanPPPConnSet(pppConfTbl)

    return 0;
end

function nimfTr.wanPPPConnSet(pppConfTbl)
	require "teamf1lualib/nimf"
    require "teamf1lualib/nimfConn"
	local wanObjConfig = {}
	local wanTypeConfig = {}
	local tmpVal = nil
	local wanConnObj = {}
	local wanObj = {}
    local wanDefConn = {}
    local connID = {}
    local stat
    local err
    local status = "0"
    
    --tr69Glue.tf1Dbg("")
    --pppConfTbl["UserName"]
    --pppConfTbl["Password"]

    wanTypeConfig["Pppoe._ROWID_"] = "1"
    wanTypeConfig["Pppoe.UserName"] = pppConfTbl ["UserName"]
    wanTypeConfig["Pppoe.Password"] = pppConfTbl ["Password"]
   
    --get configuration in device
    wanDefConn = nimf.getDefConnCfg ();

    -- get default wan connection object
	if (wanDefConn ~= nil) then
		connID ["LogicalIfName"] = pppConfTbl["LogicalIfName"];
        connID ["AddressFamily"] = "2";
	    connID ["ConnectionType"] = wanDefConn["connection_type"];
        
        stat, err, wanConnObj = nimfConn.defConfGet(connID)
        if (wanConnObj == nil) then
            status = "1"
            return 1;
        end
        stat, err, wanObj = nimfConn.confGet(connID)
         if (wanObj == nil) then
            status = "1"
            return 1;
        end
	end
    
        
    -- filling in all fields so that we don't loose configuration while setting
    -- dnsserver/interface enable/disable/gateway individually. 
    wanConnObj["StaticIp"] = wanDefConn["ipAddress"]
    wanConnObj["NetMask"] = wanDefConn["subnetMask"];
    wanConnObj["Gateway"] = wanDefConn["Gateway"];
    
    wanConnObj["GetDnsFromIsp"] = wanObj ["GetDnsFromIsp"]
    wanConnObj["PrimaryDns"] = wanObj["PrimaryDns"]
    wanConnObj["SecondaryDns"] = wanObj["SecondaryDns"]
    wanConnObj["ConnectionType"] = wanDefConn["connection_type"];

    --PPPoE params
    if(pppConfTbl["UserName"] ~= nil) then
        wanConnObj["UserName"] = pppConfTbl["UserName"]
    else
        wanConnObj["UserName"] = wanDefConn["pppoe_UserName"]
    end

    if(pppConfTbl["Password"] ~= nil) then
        wanConnObj["Password"] =  pppConfTbl["Password"]
    else
        wanConnObj["Password"] =  wanDefConn["pppoe_Password"]
    end

    wanConnObj["AuthOpt"] =  "1"    
    wanConnObj["IdleTimeOutValue"] =  wanDefConn["pppoe_IdleTimeOutValue"]
    wanConnObj["IdleTimeOutFlag"] =  wanDefConn["pppoe_IdleTimeOutFlag"]
    wanConnObj["DomainName"] =  wanDefConn["pppoe_DomainName"]

    if (wanDefConn["status"] == "UP") then
       wanConnObj["Enable"] = "1"
    end
    
    -- set configure route
    local query = "LogicalIfName='" .. pppConfTbl["LogicalIfName"] .. "' and AddressFamily=2"
    local nimfConfRow = db.getRowWhere ("NimfConf", query, false);
    tmpVal = nimfConfRow["DefaultConnection"]
    if (tmpVal ~= nil) then
        wanConnObj["DefaultConnection"] = tmpVal
    end

    local status = nimfConn.configure(wanConnObj);
    if (status ~= "OK") then
        tr69Glue.tf1Dbg("nimfConn.configure failed to configure the wan interface..")
    else
        tr69Glue.tf1Dbg("nimfConn.configure Successfully updated wan settings..")
    end

end


--[[
--*****************************************************************************
-- nimfTr.ipcpCfgGet- get ipcp configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.PPP.Interface.0.IPCP.
--
-- LocalIPAddress
-- RemoteIPAddress
--
-- Returns: status, value
]]--
function nimfTr.ipcpCfgGet (input)

    local status = "0"
    local value = "0"
    local row = {}
    local rowId
    local query = nil
    local nimfRow = {}
    local param = input["param"]

    --get corresponding db entry from 'Pppoe'
    query = "_ROWID_=1"
    row = db.getRowWhere ("Pppoe", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from 'NimfConf'
    query = "LogicalIfName='IF1' and AddressFamily=2"
    nimfRow = db.getRowWhere ("NimfConf", query, false)
    if (nimfRow == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --check connection type

    --possible connection types: dhcpc,ifStatic,pppoe,pptp,l2tp
    if(nimfRow["ConnectionType"] ~= "pppoe") then
        if(string.find(input["param"], "LocalIPAddress")) then
            -- LocalIPAddress
            value = "0.0.0.0"
        elseif(string.find(input["param"], "RemoteIPAddress")) then
            -- RemoteIPAddress
            value = "0.0.0.0"
        else
            return "1", "DB_ERROR_TRY_AGAIN"
        end

        return status, value
    end

    -- get corresponding db entry from 'ipAddressTable'
    local ipAddrRow = {}
    query = "LogicalIfName='IF1' and AddressFamily=2 and ConnectionKey=0"
    ipAddrRow = db.getRowWhere ("ipAddressTable", query, false)
    if (ipAddrRow == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    if(string.find(input["param"], "LocalIPAddress")) then
        -- LocalIPAddress
        if(ipAddrRow["ipAddress"] == nil or ipAddrRow["ipAddress"] == "") then
            value = "0.0.0.0"
        else
            value = ipAddrRow["ipAddress"]
        end
    elseif(string.find(input["param"], "RemoteIPAddress")) then
        -- RemoteIPAddress
        if(ipAddrRow["ipDstAddres"] == nil or ipAddrRow["ipDstAddres"] == "") then
            value = "0.0.0.0"
        else
            value = ipAddrRow["ipDstAddres"]
        end
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- nimfTr.vlanEncapIfAdd - Add VLAN for BridgeMode configuration
-- 
-- This function is called to set the following parameters
-- Device.Bridging.Bridge.0.VLAN.0.
--
-- Enable
-- vlanID
-- Name
--
-- Returns: status
]]--
function nimfTr.vlanEncapIfAdd(input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering vlanEncapIfAdd..")

    require "teamf1lualib/ethernet"
    require "teamf1lualib/swMgr"
    require "teamf1lualib/bridgeLib"
    require "teamf1lualib/gui"

    local status = "0"
    local errorFlag
    local row = {}
    local query = nil
    local insertFlag = "1"
    local LogicalIfName = "IF1"
    local networkName = "LAN"

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = "1"
        return "1";
    end

    local addStatus = gui.networking.network.vlan.maxStatusGet (networkName)
    if (addStatus) then
        tr69Glue.tf1Dbg("Max number of allowed vlans are configured..")
        return error_code.REQUEST_DENIED;
    end

    -- Filling the parameters of vlanEncapIf when Add Object for vlanEncapIfAdd is called
    local vlanID = 2
    local vlanRows = db.getRowsWithCustomQuery("vlanEncapIf", "ORDER by vlanId ASC")
    for k,v in pairs(vlanRows) do
        if(k ~= 1) then
            if(vlanID == tonumber(v["vlanEncapIf.vlanId"])) then
                vlanID = tonumber(v["vlanEncapIf.vlanId"]) + 1
            end
        end
    end

    tr69Glue.tf1Dbg("adding with vlanID = ".. vlanID)

    if(vlanID < 2 or vlanID > 4094) then
        tr69Glue.tf1Dbg("All vlans are configured..")
        return error_code.REQUEST_DENIED;
    end

    local duplicateStatus = gui.networking.network.vlan.duplicateStatusGet (networkName, vlanID)
    if (duplicateStatus) then
        tr69Glue.tf1Dbg("Added VLAN ID is already present..")
        return error_code.REQUEST_DENIED;
    end

    local bridgeVlanRow = db.getRow ("bridgeMode", "_ROWID_", "1")
    if (bridgeVlanRow["bridgeMode.status"] == "1" and bridgeVlanRow["bridgeMode.vlanID"] == vlanID) then
        tr69Glue.tf1Dbg("Added VLAN is already configured in bridge mode..")
        return error_code.REQUEST_DENIED;
    end

    local gponRow = db.getRow ("gpon", "_ROWID_", "1")
    if (networkName == "WAN" and gponRow ~= nil and gponRow["gpon.status"] == "1" and gponRow["gpon.vlanID"] == vlanID) then
        tr69Glue.tf1Dbg("Added VLAN is already configured in GPON mode..")
        return error_code.REQUEST_DENIED;
    end
    
    if (networkName == "WAN") then
        local vconf = {}
        vconf["LogicalIfName"] = LogicalIfName
        vconf["vlanId"] = vlanID
        vconf = util.addPrefix (vconf, "ethernetVLAN.");
        
        status,errCode =  ethernetVLAN.ethernetVLAN_config(vconf, "-1","add")
    elseif (networkName == "LAN") then
        local defaultFwdMap = ""
        for i=1,3 do
            if (i ~= tonumber(bridgeVlanRow["bridgeMode.portNumber"])) then
                if (defaultFwdMap == "") then
                    defaultFwdMap = i
                else
                    defaultFwdMap = defaultFwdMap..","..i
                end
            end
        end
        
        -- for lan side there are 2 operations. updating vlanEncapIf and bridgePorts
        if (not util.fileExists ("/pfrm2.0/BRIDGE_MODE")) then
            iface = db.getAttribute ("ethernet", "LogicalIfName", LogicalIfName, "interfaceName")
        else
            iface = "eth0"
        end
        
        local vconf = {}
        if (iface ~= nil or iface ~= "") then
            vconf["vlanId"] = vlanID
            vconf["vlanName"] = LogicalIfName
            vconf["interfaceName"]  = iface
            vconf["ingressMap"] = ""
            vconf["egressMap"] = ""
            vconf["fwdMap"] = defaultFwdMap
            vconf["untagMap"] = ""
            vconf["inSwitchOnly"] = "0"
            vconf["LogicalIfName"] = LogicalIfName
            vconf = util.addPrefix (vconf, "vlanEncapIf.");
            
            status,errCode = swMgr.dbConfig ("vlanEncapIf", vconf, -1  , "add")

            vconf = {}
            local bridgeName= bridge.ifNameGet(LogicalIfName)
            vconf[1] = {}
            vconf[1]["ifname"] =  iface.."."..vlanID
            status, errorCode = bridge.portAdd(bridgeName, vconf)
        end
    end

    if (status == "OK") then
        tr69Glue.tf1Dbg("adding vlan success..")
        db.save()
    end

    tr69Glue.tf1Dbg("Leaving vlanEncapIfAdd..")
    return 0;
end

--[[
--*****************************************************************************
-- nimfTr.vlanCfgGet- get vlan configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.Ethernet.VLANTermination.0.
--
-- Enable
-- Status
-- Alias
-- Name
-- LastChange
-- LowerLayers
-- VLANID
--
-- Returns: status, value
]]--
function nimfTr.vlanCfgGet (input)

    local status = "0"
    local value = "0"
    local row = {}
    local rowId
    local query = nil
    local ethRow = {}
    local nwRow = {}
    local param = input["param"]
    local parentObjInstance = ""

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", value
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "VLANTermination.")
    parentObjInstance = string.sub(param, 1, endIdx+2)

    --read the rowId mapping to bridgeTable
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", value
    end

    --get correspnding db entry from vlanEncapIf 
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("vlanEncapIf", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- when row is there then Enable is always on
        value = 1
    elseif(string.find(input["param"], "Status")) then
        value="Up"
    elseif(string.find(input["param"], "Alias")) then
        -- Name
        value = "default" .. rowId
    elseif(string.find(input["param"], "Name")) then
        -- Name
        value = "VLAN" .. rowId
    elseif(string.find(input["param"], "LastChange")) then
        require "ifDevLib"
        require "teamf1lualib/ifDevTrExtn"
        uptime = ifDevLib.vlanUptimeGet(row["vlanId"])
        if (uptime ~= nil) then
            value = ifDevTr.timeInSecs(uptime)
        else
            value = "0"
        end
    elseif(string.find(input["param"], "LowerLayers")) then
        if (row["LogicalIfName"] == "IF2") then
            value = "Device.IP.Interface.2."
        else
            value = "Device.IP.Interface.1."
        end
    elseif(string.find(input["param"], "VLANID")) then
        value = row["vlanId"]
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- nimfTr.vlanCfgSet- set vlan configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.Ethernet.VLANTermination.0.
--
-- Enable
-- Alias
-- LowerLayers
-- VLANID
--
-- Returns: status
]]--
function nimfTr.vlanCfgSet(input, rowids, actionType, tr69Param)
    require "teamf1lualib/bridgeLib"

    tr69Glue.tf1Dbg("Entering & Leaving nimfTr.vlanCfgSet..")

    --[[
    local status = "0"
    local row = {}
    local rowId
    local query = nil
    local vlanConfRow = {}
    local vlanID = ""
   
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = "1"
        return "1";
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(tr69Param, "VLANTermination.")
    parentObjInstance = string.sub(tr69Param, 1, endIdx+2)

    --read the rowId mapping to vlanEncapIf
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        status = "1"
        return "1";
    end

    --get corresponding db entry from vlanEncapIf
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("vlanEncapIf", query, false)
    if(row == nil) then
        status = "1"
        return "1";
    end

    --VLANID
    if(input["vlanEncapIf"]["vlanEncapIf.VLANID"] ~= nil) then
        vlanID = input["vlanEncapIf"]["vlanEncapIf.VLANID"]
    end

    -- check if row exists in vlanEncapIf with this vlanId
    local vlanRow = db.getRows ("vlanEncapIf", "vlanId", vlanID)
    if ((vlanRow ~= nil) and (#vlanRow > 0)) then
		status = "1"
        return "1";
    end

    local bridgeVlanRow = db.getRow ("bridgeMode", "_ROWID_", "1")
	if (bridgeVlanRow["bridgeMode.status"] == "1" and bridgeVlanRow["bridgeMode.vlanID"] == vlanID) then
        status = "11"
		return "1";
	end

    -- Ready for db update.
    -- First get bridge conf.
    local iface = db.getAttribute ("vlanEncapIf", "LogicalIfName", row["LogicalIfName"], "interfaceName")
	local vconf = {}
	local bridgeName= bridge.ifNameGet(row["LogicalIfName"])
	vconf[1] = {}
	vconf[1]["ifname"] =  iface.."."..row["vlanId"]

    -- delete port from bridge
	bridge.portDelete(bridgeName, vconf)

    vlanConfRow = row
    
    --VLANID
    vlanConfRow["vlanId"] = vlanID

    vlanConfRow = util.addPrefix(vlanConfRow, "vlanEncapIf.")
    local valid, errstr = db.update("vlanEncapIf", row, row["vlanEncapIf._ROWID_"])


    if (not valid) then
        -- need to add port if db update failed
        bridge.portAdd(bridgeName, vconf)
        status = "1"
        return "1";
    end     

    -- add need port to bridge
    vconf[1]["ifname"] =  iface .. "." .. vlanID
	bridge.portAdd(bridgeName, vconf)

    ]]--
    return 0;
end

--[[
--*****************************************************************************
-- nimfTr.ipConfGet- get ipConf configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.IP.
--
-- 
-- 
--
-- Returns: status, value
]]--
function nimfTr.ipConfGet (input)

    local status = "0"
    local value = "0"
    local row = {}
    local rowId
    local query = nil
    local ipConfRow = {}
    local param = input["param"]

    --get corresponding db entry from 'ipConf'
    query = "_ROWID_=1"
    row = db.getRowWhere ("ipConf", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    if(string.find(input["param"], "IPv4Capable")) then
        value = row["IPv4Capable"]
    elseif(string.find(input["param"], "IPv4Enable")) then
        value = row["IPv4Enable"]
    elseif(string.find(input["param"], "IPv4Status")) then
        if(row["IPv4Enable"] == "1") then
            value = "Enabled"
        else
            value = "Disabled"
        end
    elseif(string.find(input["param"], "IPv6Capable")) then
        value = row["IPv6Capable"]
    elseif(string.find(input["param"], "IPv6Enable")) then
        value = row["IPv6Enable"]
    elseif(string.find(input["param"], "IPv6Status")) then
        if(row["IPv6Enable"] == "1") then
            value = "Enabled"
        else
            value = "Disabled"
        end
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- nimfTr.ipConfSet- set ipConf configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.IP.
--
-- 
--
-- Returns: status
]]--
function nimfTr.ipConfSet(input, rowids, actionType, tr69Param)
    require "teamf1lualib/reboot"

    tr69Glue.tf1Dbg("Entering & Leaving nimfTr.ipConfSet..")

    local status = "0"
    local row = {}
    local rowId
    local query = nil
    local ipConfRow = {}
    local reboot = "0"
    local faultTbl = {}
    local index = 0

    --get corresponding db entry from ipConf
    query = "_ROWID_=1"
    row = db.getRowWhere ("ipConf", query, false)
    if(row == nil) then
        status = "1"
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    ipConfRow = row

    if(input["ipConf"]["ipConf.IPv6Enable"] ~= nil) then
        ipConfRow["IPv6Enable"] = input["ipConf"]["ipConf.IPv6Enable"]
        reboot = "1"
    end

    ipConfRow = util.addPrefix(ipConfRow, "ipConf.")
    local valid, errstr = db.update("ipConf", ipConfRow, ipConfRow["ipConf._ROWID_"])

    if (not valid) then
        status = "1"
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end     

    -- save the set operation.
	SETTINGS_FILE=db.getAttribute("environment", "name", "TEAMF1_CFG_ASCII", "value")

    db.save2()

    if(reboot == "1") then
        tr69Glue.reboot(10);
    end

    return 0;
end

--[[
--*****************************************************************************
-- nimfTr.getDNSType- get object Type of WAN Configuration
-- 
-- Returns: value or nil
]]--

function nimfTr.getDNSType(row) 
    local value = nil
    local nimfConfRow = db.getRowWhere ("NimfConf", "LogicalIfName = '" .. row["LogicalIfName"] .. "' AND AddressFamily = '" .. row["addressFamily"] .. "'")

    if(row["addressFamily"] == "2") then
        local dhcpcRow = db.getRowWhere("Dhcpc", "_ROWID_=1", false)
        local pppoeRow = db.getRowWhere("Pppoe", "_ROWID_=1", false)
        
        if(nimfConfRow["NimfConf.ConnectionType"] == "dhcpc" and (dhcpcRow["PrimaryDns"] == "0.0.0.0" and dhcpcRow["SecondaryDns"] == "0.0.0.0")) then
            value = "DHCPv4"
        elseif(nimfConfRow["NimfConf.ConnectionType"] == "pppoe" and pppoeRow["GetDnsFromIsp"] == "1") then
            value = "IPCP"
        elseif(nimfConfRow["NimfConf.ConnectionType"] == "ifStatic" or (dhcpcRow["PrimaryDns"] ~= "0.0.0.0" and dhcpcRow["SecondaryDns"] ~= "0.0.0.0") or (pppoeRow["GetDnsFromIsp"] == "0")) then
            value = "Static"
        end
    else
        if(nimfConfRow["NimfConf.ConnectionType"] == "ifStatic6") then
            value = "Static"
        elseif(nimfConfRow["NimfConf.ConnectionType"] == "dhcp6c-stateless" or nimfConfRow["NimfConf.ConnectionType"] == "dhcp6c") then
            value = "DHCPv6"
        end
    end
    return value
end

--[[
--*****************************************************************************
-- nimfTr.resolvGet- get DNS resolver configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.DNS.Client.Server.0.
--
-- Enable
-- Status
--
-- Returns: status, value
]]--
function nimfTr.resolvGet (input)

    local status = "0"
    local value = "0"
    local rowId
    local query = nil
    local param = input["param"]
    local parentObjInstance = ""

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", value
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "Server.")
    parentObjInstance = string.sub(param, 1, endIdx+2)

    --read the rowId mapping to bridgeTable
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", value
    end

    -- get correspnding db entry from resolverConfig where
    -- rowId 1: IPv4 Primary DNS
    -- rowId 2: IPv4 Secondary DNS
    -- rowId 3: IPv6 Primary DNS
    -- rowId 4: IPv6 Secondary DNS

    local nameserver = ""
    if(rowId == "1" or rowId == "2") then
        query = "LogicalIfName='IF1' and addressFamily=2"
        nameserver = "nameserver"..rowId
    elseif(rowId == "3" or rowId == "4") then
        query = "LogicalIfName='IF1' and addressFamily=10"
        rowId = tonumber(rowId)-2
        nameserver = "nameserver"..rowId
    end
    resolverConfigRow = db.getRowWhere ("resolverConfig", query, false)

    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        if(resolverConfigRow ~= nil and resolverConfigRow[nameserver] ~= nil and resolverConfigRow[nameserver] ~= "0::0" and resolverConfigRow[nameserver] ~= "0.0.0.0") then
            value = "1"
        else
            value = "0"
        end
    elseif(string.find(input["param"], "Status")) then
        -- Status
        if(resolverConfigRow ~= nil and resolverConfigRow[nameserver] ~= nil and resolverConfigRow[nameserver] ~= "0::0" and resolverConfigRow[nameserver] ~= "0.0.0.0") then
            value="Enabled"
        else
            value="Disabled"
        end 
    elseif(string.find(input["param"], "DNSServer")) then
        -- DNSServer
        if(resolverConfigRow ~= nil and resolverConfigRow[nameserver] ~= nil and resolverConfigRow[nameserver] ~= "0::0" and resolverConfigRow[nameserver] ~= "0.0.0.0") then
            value = resolverConfigRow[nameserver]
        else
            value = "" 
        end
    elseif(string.find(input["param"], "Interface")) then
        -- Interface
        if(resolverConfigRow ~= nil and resolverConfigRow[nameserver] ~= nil and resolverConfigRow[nameserver] ~= "0::0" and resolverConfigRow[nameserver] ~= "0.0.0.0") then
            value = nimfTr.getIfaceObjFromIfname(resolverConfigRow["LogicalIfName"])
            if(value == nil or value == "") then
                return "1", "DB_ERROR_TRY_AGAIN"
            end
        else
            value = "" 
        end
    elseif(string.find(input["param"], "Type")) then
        -- Type
        if(resolverConfigRow ~= nil and resolverConfigRow[nameserver] ~= nil and resolverConfigRow[nameserver] ~= "0::0" and resolverConfigRow[nameserver] ~= "0.0.0.0") then
            value = nimfTr.getDNSType(resolverConfigRow)
            if(value == nil or value == "") then
                return "1", "DB_ERROR_TRY_AGAIN"
            end
        else
            value = "" 
        end
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- nimfTr.resolvSet- set dns configuration parameters
-- 
-- This function is called to set the following parameter in
-- Device.DNS.Client.Server.0.
--
-- DNSServer
--
-- Returns: status, value
]]--
function nimfTr.resolvSet (input, rowids, actionType, tr69Param)
    require "teamf1lualib/util"

    local status = OK
    local row = {}
    local rowId
    local query = nil
    local ncRow = {}
    local faultTbl = {}
    local index = 0

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --extract the Device.DNS.Client.Server.{i}. part from tr69Param
    local startIdx, endIdx
    local parentObjInstance
    startIdx, endIdx = string.find(tr69Param, "Server.")
    parentObjInstance = string.sub(tr69Param, 1, endIdx+2)

    --read the rowId mapping of the corresponding Device.DNS.Client.Server.{i}.
    --object to resolverConfig
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    -- configure DNSServer
    -- rowId 1: IPv4 Primary DNS
    -- rowId 2: IPv4 Secondary DNS
    -- rowId 3: IPv6 Primary DNS
    -- rowId 4: IPv6 Secondary DNS
    
    local dnsServer = ""
    dnsServer = input["dnsClientServer"]["dnsClientServer.DNSServer"]
    if(dnsServer == nil or dnsServer == "") then
        tr69Glue.tf1Dbg("return if its not DNSServer..")
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."DNSServer", error_code.INVALID_PARAM_VALUE)
        return status, faultTbl;
    end

    if(rowId == "1" or rowId == "2") then
        query = "LogicalIfName='IF1' and addressFamily=2"
        if(dnsServer ~= nil and dnsServer ~= "") then
            if(tr69Glue.tf1IpAddressValidate(dnsServer,"","dnsServer","") ~= "OK") then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."DNSServer", error_code.INVALID_PARAM_VALUE)
            end
        end
    elseif(rowId == "3" or rowId == "4") then
        query = "LogicalIfName='IF1' and addressFamily=10"
        if(dnsServer ~= nil and dnsServer ~= "") then
            local ipv6Status,ipv6Valid = tr69Glue.tf1ValidateIpv6Address(dnsServer)
            if(ipv6Status == 1) then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."DNSServer", error_code.INVALID_PARAM_VALUE)
            end
        end
    end
       
    if(status == ERROR) then
       return status, faultTbl
    end
 
    --get correspnding db entry from resolverConfig
    row = db.getRowWhere ("resolverConfig", query, false)
    if(row == "nil" or row == "") then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get corresponding db entry from NimfConf
    query = "LogicalIfName = '" .. row["LogicalIfName"] .. "' AND AddressFamily = '" .. row["addressFamily"] .. "'"

    ncRow = db.getRowWhere ("NimfConf", query, false)
    if(ncRow == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    local dhcpcRow = db.getRowWhere("Dhcpc", "_ROWID_=1", false)
    if(dhcpcRow == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    local pppoeRow = db.getRowWhere("Pppoe", "_ROWID_=1", false)
    if(pppoeRow == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --set the dnsServers only if ConnectionType is ifStatic or ifStatic6
    local valid = false 
    local errstr = ""

    if(ncRow["ConnectionType"] == "ifStatic" or ncRow["ConnectionType"] == "ifStatic6") then
        if(rowId == "1") then
            valid, errstr = db.setAttributeWhere("ifStatic", query, "PrimaryDns",dnsServer) 
        elseif(rowId == "2") then
            valid, errstr = db.setAttributeWhere("ifStatic", query, "SecondaryDns",dnsServer)
        elseif(rowId == "3") then
            valid, errstr = db.setAttributeWhere("ifStatic", query, "PrimaryDns",dnsServer)
        elseif(rowId == "4") then
            valid, errstr = db.setAttributeWhere("ifStatic", query, "SecondaryDns",dnsServer)
        end
    elseif(ncRow["ConnectionType"] == "dhcpc" and dhcpcRow["PrimaryDns"] ~= "0.0.0.0" and dhcpcRow["SecondaryDns"] ~= "0.0.0.0") then
        if(rowId == "1") then
            valid, errstr = db.setAttributeWhere("Dhcpc", "_ROWID_=1", "PrimaryDns", dnsServer) 
        elseif(rowId == "2") then
            valid, errstr = db.setAttributeWhere("Dhcpc", "_ROWID_=1", "SecondaryDns", dnsServer)
        end
    elseif(ncRow["ConnectionType"] == "pppoe" and pppoeRow["PrimaryDns"] ~= "0.0.0.0" and pppoeRow["PrimaryDns"] ~= "" and pppoeRow["SecondaryDns"] ~= "0.0.0.0" and pppoeRow["SecondaryDns"] ~= "") then
        if(rowId == "1") then
            valid, errstr = db.setAttributeWhere("Pppoe", "_ROWID_=1", "PrimaryDns", dnsServer) 
        elseif(rowId == "2") then
            valid, errstr = db.setAttributeWhere("Pppoe", "_ROWID_=1", "SecondaryDns", dnsServer)
        end
    end
        
    if(valid == false) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."DNSServer", error_code.REQUEST_DENIED)
        return status, faultTbl;
    end

    ncRow = util.addPrefix(ncRow, "NimfConf.")
    local valid, errstr = db.update ("NimfConf", ncRow, ncRow["NimfConf._ROWID_"])
    if(valid == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    db.save ()
    return 0;
end

--[[
--*****************************************************************************
-- nimfTr.ipV6ConnGet- get ipv6 configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.IP.Interface.0.IPv6Address.0.
--
--
-- Returns: status, value
]]--
function nimfTr.ipV6ConnGet (input)
    local status = "0"
    local value = "0"
    local rowId
    local query = nil
    local param = input["param"]
    local parentObjInstance = ""
    local row = {}
    local nimfRow = {}
    local ifStaticRow = {}

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", value
    end

    --read the rowId mapping to ipaddressTable
    rowId = instanceMap[param]
    if (rowId == nil) then
        return "1", value
    end
   
    --get corresponding db entry from ipAddressTable
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("ipAddressTable", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from nimfConf
    query = "LogicalIfName='" .. row["LogicalIfName"] .. "'"
    query = query .. " and ConnectionKey='" .. row["ConnectionKey"] .. "'" .. " and addressFamily=10"
    nimfRow = db.getRowWhere ("NimfConf", query, false)
    if(nimfRow == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from ifStatic
    query = "LogicalIfName='" .. row["LogicalIfName"] .. "'"
    query = query .. " and ConnectionKey='" .. row["ConnectionKey"] .. "'" .. " and addressFamily=10"
    ifStaticRow = db.getRowWhere ("ifStatic", query, false)

    -- set default values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        if(row["ipAddress"] == "0::0") then
            value = "0"
        else
            value = "1"
        end
    elseif(string.find(input["param"], "IPAddressStatus")) then
        -- IPAddressStatus
        if(row["ipAddress"] == "0::0") then
            value = "Invalid"
        else
            value = "Preferred"
        end
    elseif(string.find(input["param"], "Status")) then
        -- Status
        if(row["ipAddress"] == "0::0") then
            value = "Error_Misconfigured"
        else
            value = "Enabled"
        end
    elseif(string.find(input["param"], "IPAddress")) then
        -- IPAddress
        value = row["ipAddress"]
    elseif(string.find(input["param"], "Origin")) then
        -- Origin
        local connectionType = ""
        local staticFlag = 0
        if(ifStaticRow ~= nil) then
            require "platformLib"
            -- if IPv6 address is present in ifStatic table, it is a static IP
            errorCode, errorString = platformLib.ipv6AddressesCompare(row["ipAddress"], ifStaticRow["StaticIp"])
            if(errorCode == 0) then
                staticFlag = 1 
            end
        end

        if(staticFlag == 1) then
            if (nimfRow["ConnectionType"] == "ifStatic6") then
                -- if ipv6 address is assgined statically
                connectionType = "Static"
            end
        else
            if((string.sub(row["ipAddress"], 1, 4) == "fe80") or (row["ipAddress"] == "0::0") or (nimfRow["ConnectionType"] == "dhcp6c-stateless")) then
                -- if ipv6 address is link local or 0::0 or assigned via stateless mode
                connectionType = "AutoConfigured"
            elseif (nimfRow["ConnectionType"] == "dhcp6c") then
                -- if ipv6 address is assigned via statefull mode
                connectionType = "DHCPv6"
            else
                -- if all the above cases fail, the IPv6 address will be
                -- autoconfigured
                connectionType = "AutoConfigured"
            end
        end

        value = connectionType
    elseif(string.find(input["param"], "Prefix")) then
        -- Prefix
        if(row ~= nil) then
            local prefixRefObj = ""
            prefixRefObj = nimfTr.getPrefixObj(row)
            if(prefixRefObj ~= nil and prefixRefObj ~= "") then
                value = prefixRefObj
            else
                value = ""
            end
        else
            value = ""
        end
    elseif(string.find(input["param"], "PreferredLifetime")) then
        -- PreferredLifetime
        if (connectionType == "Static") then
            -- infinite time
            value = "9999-12-31T23:59:59Z"
        else
            -- unknown time
            value = "0001-01-01T00:00:00Z"
        end
    elseif(string.find(input["param"], "ValidLifetime")) then
        -- ValidLifetime
        if (connectionType == "Static") then
            -- infinite time
            value = "9999-12-31T23:59:59Z"
        else
            -- unknown time
            value = "0001-01-01T00:00:00Z"
        end
    elseif(string.find(input["param"], "Anycast")) then
        -- Anycast
        value = "0"
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    
    return status, value
end

--[[
--*****************************************************************************
-- nimfTr.ipv6ConnSet- set ipv6 configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.IP.Interface.0.IPv6Address.0.
--
-- 
--
-- Returns: status, value
]]--
function nimfTr.ipV6ConnSet (input, rowids, actionType, tr69Param)

    local status = OK 
    local row = {}
    local rowId
    local query = nil
    local ipConfTbl = {}
    local nwRow = {}
    local connConfFlg = "0"
    local faultTbl = {}
    local index = 0

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --extract the Device.IP.Interface.{i}.IPv6Address.{i}. part from tr69Param
    local startIdx, endIdx
    local parentObjInstance
    startIdx, endIdx = string.find(tr69Param, "IPv6Address.")
    parentObjInstance = string.sub(tr69Param, 1, endIdx+2)

    --read the rowId mapping of the corresponding Device.IP.Interface.{i}.IPv6Address.{i}.
    --object to ipAddressTable
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        status = ERROR 
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get corresponding db entry from ipAddressTable
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("ipAddressTable", query, false)
    if(row == nil) then
        status = ERROR 
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get corresponding db entry from networkInterface
    query = "LogicalIfName='" .. row["LogicalIfName"] .. "'"
    nwRow = db.getRowWhere ("networkinterface", query, false)
    if(nwRow == nil) then
        status = ERROR 
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get corresponding db entry from nimfConf
    query = "LogicalIfName='" .. row["LogicalIfName"] .. "'"
    query = query .. " and ConnectionKey='" .. row["ConnectionKey"] .. "'" .. " and addressFamily=10"
    nimfRow = db.getRowWhere ("NimfConf", query, false)
    if(nimfRow == nil) then
        status = ERROR 
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    if(nimfRow["ConnectionType"] ~= "ifStatic6") then
        -- connection is not static so return
        status = ERROR 
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get corresponding db entry from ifStatic
    local connectionType = ""
    query = "LogicalIfName='" .. row["LogicalIfName"] .. "'"
    query = query .. " and ConnectionKey='" .. row["ConnectionKey"] .. "'" .. " and addressFamily=10"
    ifStaticRow = db.getRowWhere ("ifStatic", query, false)
    if (ifStaticRow == nil) then
        status = ERROR 
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    -- to check whether ip is configured statically
    if(ifStaticRow["StaticIp"] == row["ipAddress"]) then
        -- need to configured to interface
        if(input["ipAddressTable"]["ipAddressTable.IPAddress"] ~= nil) then
            ipConfTbl["ipAddress"] = input["ipAddressTable"]["ipAddressTable.IPAddress"]
        end
        ipConfTbl["LogicalIfName"] = row["LogicalIfName"]
        ipConfTbl["PrefixLength"] = ifStaticRow["PrefixLength"]
        ipConfTbl["Gateway"] = ifStaticRow["Gateway"]
        ipConfTbl["PrimaryDns"] = ifStaticRow["PrimaryDns"]
        ipConfTbl["SecondaryDns"] = ifStaticRow["SecondaryDns"]
        connConfFlg = "1"
    end
  
    if (connConfFlg == "1") then
        nimfTr.netIpv6ConnSet(ipConfTbl)
    end
    
    db.save ()
    return 0;
end

function nimfTr.netIpv6ConnSet(confTbl)
    require "teamf1lualib/network"
    
	local objConfig = {}
    local stat
    local errCode="OK"
    local status="STATUS_OK"
    local name=""
    
    if(confTbl == nil) then
        return 0;
    end

    objConfig["Enable"]=1
    objConfig["NetMask"]=0
    objConfig["GetDnsFromIsp"]=0
    objConfig["ConnectionType"]="ifStatic6"
    objConfig["StaticIp"]=confTbl["ipAddress"]
    objConfig["PrefixLength"]=confTbl["PrefixLength"]
    objConfig["AddressFamily"]="ipv6"
    objConfig["GetIpFromIsp"]=0
    objConfig["Gateway"]=confTbl["Gateway"]
    objConfig["PrimaryDns"]=confTbl["PrimaryDns"]
    objConfig["SecondaryDns"]=confTbl["SecondaryDns"]

    --if wan
    if (confTbl["LogicalIfName"]=="IF1") then
        name="Internet"
        objConfig["ConfigureRoute"]=1
        objConfig["networkType"]="WAN"
        objConfig["ConfigureDNS"]=1
    elseif(confTbl["LogicalIfName"]=="IF2") then
        --if lan
        name="Local"
        objConfig["networkType"]="LAN"
        objConfig["requireLogin"]=0
    else
        return 0;
    end


    status, errCode = network.configure (name, objConfig)
    
    return status, errCode
end

--[[
--*****************************************************************************
-- nimfTr.wanGponGet- get gpon configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.X_TEAMF1.X_CT-COM_WANGponLinkConfig.
--
-- Enable
-- Mode
-- VLANIDMark
-- P_802-1pMark
--
-- Returns: status, value
]]--
function nimfTr.wanGponGet (input)

	require "teamf1lualib/dot11"

    local status = "0"
    local value = "0"
    local row = {}
    local rowId
    local query = nil
    local param = input["param"]
	
    --get corresponding db entry from 'gpon'
    query = "_ROWID_=1"
    row = db.getRowWhere ("gpon", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = row["status"] 
    elseif(string.find(input["param"], "VLANIDMark")) then
        -- VLANIDMark
        value = row["vlanID"] 
    elseif(string.find(input["param"], "WifiOffloadVLAN")) then
        -- VLANIDMark
        query = "_ROWID_=2"
        row = db.getRowWhere ("gpon", query, false)
        if(row == nil) then
            return "1", "DB_ERROR_TRY_AGAIN"
        end
        value = row["vlanID"] 
    elseif(string.find(input["param"], "P_802")) then
        -- P_802-1pMark
		value = row["vlanPriority"]
		if ( util.fileExists(DSCP_PBIT_FLASH_FILE) == true ) then
		value = ""
		dofile (DSCP_PBIT_FLASH_FILE) 
        for i = 0,63 do
            if (i == 63) then
                value = value..i..":"..dscp1P["dscpToCosMapping.dscpCosMap" .. i]
            else
                value = value..i..":"..dscp1P["dscpToCosMapping.dscpCosMap" .. i]..","
            end
        end
		end
    else
         return "1", "DB_ERROR_TRY_AGAIN"
    end
    return status, value
end

--[[
--*****************************************************************************
-- nimfTr.wanGponSet- set gpon configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.X_TEAMF1.X_CT-COM_WANGponLinkConfig.
--
-- Enable
-- VLANIDMark
-- P_802-1pMark
--
-- Returns: status, value
]]--
function nimfTr.wanGponSet (input, rowids, actionType, tr69Param)
	require "teamf1lualib/gpon"
    require "teamf1lualib/dot11"
    local status = OK
    local row = {}
    local rowId
    local query = nil
    local gponTbl = {}
    local nwRow = {}
    local rebootFlag = 0
    local faultTbl = {}
    local index = 0

    --get corresponding db entry from 'gpon'
    query = "_ROWID_=1"
    gponTbl = db.getRowWhere ("gpon", query,true)
    if(gponTbl == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    if(input["gpon"]["gpon.status"] ~= nil) then
        gponTbl["gpon.status"] = input["gpon"]["gpon.status"]
        rebootFlag = 1
    end
   
    if(gponTbl["gpon.status"] == "1") then 
        if(input["gpon"]["gpon.vlanID"] ~= nil) then
            if((tonumber(input["gpon"]["gpon.vlanID"]) >= VLANID_MIN_VAL) and (tonumber(input["gpon"]["gpon.vlanID"]) < (VLANID_MAX_VAL - 1))) then
                gponTbl["gpon.vlanID"] = input["gpon"]["gpon.vlanID"]
                rebootFlag = 1
            else
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."VLANIDMark", error_code.INVALID_PARAM_VALUE)
            end
        end

        if(input["gpon"]["gpon.vlanPriority"] ~= nil) then
            local inputTable = {}
            local arr = {}
            local arr2 = {}
            arr = util.split (input["gpon"]["gpon.vlanPriority"],",")
            
            -- check that we have got 64 values
            if (#arr ~= 64 ) then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."P_802-1pMark", error_code.INVALID_PARAM_VALUE)
                tr69Glue.tf1Dbg("only 64 values allowed..")
                return status, faultTbl
            end
            
            for k,v in pairs (arr) do
                arr2 = util.split(v,":")
                
                -- dscp value can be 0-63 only
                if (arr2[1] == nil or arr2[1] == "" or tonumber(arr2[1]) > 63 or ( string.find(arr2[1],"%.")) ) then
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."P_802-1pMark", error_code.INVALID_PARAM_VALUE) 
                    tr69Glue.tf1Dbg("dscp value can be 0-63 only..")
                    return status, faultTbl
                end
                
                -- 802.1p value can be 0-7 only
                if (arr2[2] == nil or arr2[2] == "" or tonumber(arr2[2]) > 7 or ( string.find(arr2[2],"%.")) ) then
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."P_802-1pMark", error_code.INVALID_PARAM_VALUE)
                    tr69Glue.tf1Dbg("802.1p value can be 0-7 only..")
                    return status, faultTbl
                end
                inputTable["dscpToCosMapping.dscpCosMap" .. arr2[1]] = arr2[2] 
            end
			inputTable["dscpToCosMapping.dscpMapSetFromTr"] = "1"
            dot11.dscpToCosMapping_config (inputTable, "1", "edit")
        	db.save ()

        	require "teamf1lualib/tr69Glue"
        	require "teamf1lualib/reboot"
        	tr69Glue.reboot(50)
			return 0;
        end
    end

    if(status == ERROR) then
       return status, faultTbl
    end

    gpon.configure (gponTbl, "1", "edit")
    db.save () 
    
    -- reboot if status or VLANID is changed
    if(rebootFlag == 1) then
        require "teamf1lualib/tr69Glue"
        require "teamf1lualib/reboot"
        tr69Glue.reboot(50)
    end

    return 0;
end

--[[
--*****************************************************************************
-- nimfTr.wanGponCfgSet- set gpon configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.X_TEAMF1.X_CT-COM_WANGponLinkConfig.
--
-- Enable
-- VLANIDMark
-- P_802-1pMark
--
-- Returns: status, value
]]--
function nimfTr.wanGponCfgSet (input, rowids, actionType, tr69Param)

    require "teamf1lualib/gpon"
    require "teamf1lualib/dot11"
    local status = OK
    local row = {}
    local rowId
    local query = nil
    local gponTbl = {}
    local nwRow = {}
    local rebootFlag = 0
    local faultTbl = {}
    local index = 0
    local eogregponTbl = {}
    local vlanIDFlag = 0
    local vlanPriorityFlag = 0
    local wifiVlanIDFlag = 0
    local gponConfigure = 0
    local vlanPriorityConfigure = 0
    local eogreConfigure = 0
    local inputTable = {}

    --get corresponding db entry from 'gpon'
    query = "_ROWID_=1"
    gponTbl = db.getRowWhere ("gpon", query,true)
    if(gponTbl == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    --get corresponding db entry from 'bridgeModeVlan'
    bridgeModeVlanTbl = db.getTable ("bridgeModeVlan", false)
    if(bridgeModeVlanTbl == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    --get corresponding db entry from 'bridgeMode'
    query = "_ROWID_=1"
    bridgeModeTbl = db.getRowWhere ("bridgeMode",query, false)
    if(bridgeModeTbl == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl
    end

    local jioPrivateNetSupport = "0"
    jioPrivateNetSupport = db.getAttribute ("Eogre", "_ROWID_", 1, "jioPrivateNet")
    --jioPrivateNetSupport = db.getAttribute ("environment", "name", "JIO_PRIVATE_NET" ,"value")
    if (jioPrivateNetSupport == "1") then
        --get corresponding db entry from 'gpon'
        query = "_ROWID_=2"
        eogregponTbl = db.getRowWhere ("gpon", query,true)
        if(eogregponTbl == nil) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl
        end
    end

    if(gponTbl["gpon.status"] == "1") then 
        if(input["gpon"]["gpon.vlanID"] ~= nil) then
            if((tonumber(input["gpon"]["gpon.vlanID"]) >= VLANID_MIN_VAL) and (tonumber(input["gpon"]["gpon.vlanID"]) < (VLANID_MAX_VAL - 1))) then
                gponTbl["gpon.vlanID"] = input["gpon"]["gpon.vlanID"]

                if (util.fileExists("/pfrm2.0/ae_wan_type")or util.fileExists("/pfrm2.0/MULTI_VLAN_BRIDGE"))then
                    -- check if the vlan id is configured in bridgeModeVlan
                    for i,v in pairs(bridgeModeVlanTbl) do
                        if((bridgeModeTbl["status"] == "1") and tonumber(gponTbl["gpon.vlanID"]) == tonumber(v["vlanID"])) then
                            vlanIDFlag = 1
                            break;
                        end
                    end
                end
                
                -- check if the vlan id is configured in bridgeMode or is same
                -- as GPON/AE vlan ID
                if((tonumber(gponTbl["gpon.vlanID"]) == tonumber(bridgeModeTbl["vlanID"])) or (tonumber(gponTbl["gpon.vlanID"]) == tonumber(eogregponTbl["gpon.vlanID"]) )) then
                    vlanIDFlag = 1
                end

                if(vlanIDFlag == 1) then
                    status = ERROR
                    index = index + 1
                    tr69Glue.tf1Dbg("gpon vlan configured in bridge mode..")
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."VLANIDMark", error_code.INVALID_PARAM_VALUE)
                else
                    rebootFlag = 1
                    gponConfigure = 1
                end
            else
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."VLANIDMark", error_code.INVALID_PARAM_VALUE)
            end
        end

        if(input["gpon"]["gpon.vlanPriority"] ~= nil) then
            local arr = {}
            local arr2 = {}
            arr = util.split (input["gpon"]["gpon.vlanPriority"],",")
            
            -- check that we have got 64 values
            if (#arr ~= 64 ) then
                vlanPriorityFlag = 1
                tr69Glue.tf1Dbg("only 64 values allowed..")
            end
            
            for k,v in pairs (arr) do
                arr2 = util.split(v,":")

                -- dscp value can be 0-63 only
                if (arr2[1] == nil or arr2[1] == "" or tonumber(arr2[1]) > 63 or ( string.find(arr2[1],"%."))  ) then
                    vlanPriorityFlag = 1
                    tr69Glue.tf1Dbg("dscp value can be 0-63 only..")
                end
                
                -- 802.1p value can be 0-7 only
                if (arr2[2] == nil or arr2[2] == "" or tonumber(arr2[2]) > 7 or ( string.find(arr2[2],"%.")) ) then
                    vlanPriorityFlag = 1
                    tr69Glue.tf1Dbg("802.1p value can be 0-7 only..")
                end
                inputTable["dscpToCosMapping.dscpCosMap" .. arr2[1]] = arr2[2] 
            end

            if (vlanPriorityFlag == 1) then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."P_802-1pMark", error_code.INVALID_PARAM_VALUE)
            else
                inputTable["dscpToCosMapping.dscpMapSetFromTr"] = "1"
                vlanPriorityConfigure = 1
                rebootFlag = 1
            end
        end
    end

    if(input["gpon"]["gpon.wifiVlanID"] ~= nil and jioPrivateNetSupport == "1") then
        if((tonumber(input["gpon"]["gpon.wifiVlanID"]) >= VLANID_MIN_VAL) and (tonumber(input["gpon"]["gpon.wifiVlanID"]) < (VLANID_MAX_VAL - 1))) then
            eogregponTbl["gpon.vlanID"] = input["gpon"]["gpon.wifiVlanID"]

            if (util.fileExists("/pfrm2.0/ae_wan_type")or util.fileExists("/pfrm2.0/MULTI_VLAN_BRIDGE"))then
                -- check if the wifi vlan id is configured in bridgeModeVlan
                for i,v in pairs(bridgeModeVlanTbl) do
                    if((bridgeModeTbl["status"] == "1") and tonumber(eogregponTbl["gpon.vlanID"]) == tonumber(v["vlanID"])) then
                        wifiVlanIDFlag = 1
                        break;
                    end
                end
            end
               
            -- check if the wifi vlan id is configured in bridgeMode or is same
            -- as GPON/AE vlan ID
            if((tonumber(eogregponTbl["gpon.vlanID"]) == tonumber(bridgeModeTbl["vlanID"])) or (tonumber(eogregponTbl["gpon.vlanID"]) == tonumber(gponTbl["gpon.vlanID"]) )) then
                wifiVlanIDFlag = 1
            end

            if(wifiVlanIDFlag == 1) then
                status = ERROR
                index = index + 1
                tr69Glue.tf1Dbg("wifif vlan configured in bridge mode..")
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."WifiOffloadVLAN", error_code.INVALID_PARAM_VALUE)
            else
                eogreConfigure = 1
                rebootFlag = 1
            end
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."WifiOffloadVLAN", error_code.INVALID_PARAM_VALUE)
        end
    end


    if (status == ERROR) then
        return status, faultTbl
    end

    if(gponConfigure == 1) then
        gpon.configure (gponTbl, "1", "edit")
    end
    if(vlanPriorityConfigure == 1) then
        dot11.dscpToCosMapping_config (inputTable, "1", "edit")
    end
    if(eogreConfigure == 1) then
        gpon.eogreWanconfigure(eogregponTbl, "2", "edit")
    end

    db.save2() 
    
    -- reboot if status or VLANID is changed
    if(rebootFlag == 1) then
        require "teamf1lualib/tr69Glue"
        require "teamf1lualib/reboot"
        tr69Glue.reboot(50)
    end

    return status, faultTbl
end

--[[
--*****************************************************************************
-- nimfTr.wanGponXmlSet - set gpon configuration parameters
-- 
-- This function is called to set the following parameters in
-- WANConnectionDevice.2.X_CT-COM_WANGponLinkConfig.VLANIDMark
-- WANConnectionDevice.2.WANIPConnection.1.X_ASB_COM_VlanMuxID
--
-- VLANIDMark
-- X_ASB_COM_VlanMuxID
--
-- Returns: status, value
]]--
function nimfTr.wanGponXmlSet (filename)
    require "teamf1lualib/tr69Glue"
    require "teamf1lualib/gpon"
    require "teamf1lualib/reboot"
    local vlanIdVal
    local vlanMuxVal
    local query
    local gponTbl = {}
    local rebootFlag = 0
    
    --get corresponding db entry from 'gpon'
    query = "_ROWID_=1"
    gponTbl = db.getRowWhere ("gpon", query,true)
    if(gponTbl == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    -- VLANIDMark
    vlanIdVal = tr69Glue.getValueFromXml (filename, "WANConnectionDevice.2", "COM_WANGponLinkConfig", "VLANIDMark")   
    -- vlanMuxVal = tr69Glue.getValueFromXml (filename, "WANConnectionDevice.2", "WANIPConnection.1", "X_ASB_COM_VlanMuxID")
   
    if(gponTbl["gpon.status"] == "1") then 
        if (vlanIdVal ~= nil) then
            if(vlanIdVal>1 and vlanIdVal<4095) then
                gponTbl["gpon.vlanID"] = vlanIdVal
                rebootFlag = 1
            end
        end
    end

    -- save and reboot if VLANID is changed
    if(rebootFlag == 1) then
        -- configure 
        gpon.configure (gponTbl, "1", "edit")
	db.save ()
        tr69Glue.reboot(50)
    end

    return "OK", "STATUS_OK";
end

--[[
--*****************************************************************************
-- nimfTr.opticalInterfaceGet- get optical configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.Optical.Interface.0.
--
-- Enable
-- Status
-- Name
-- LastChange
-- LowerLayers
-- Upstream
-- OpticalSignalLevel
-- LowerOpticalThreshold
-- UpperOpticalThreshold
-- TransmitOpticalLevel
-- LowerTransmitPowerThreshold
-- UpperTransmitPowerThreshold
--
-- Returns: status, value
]]--
function nimfTr.opticalInterfaceGet(input)

    local status = "0"
    local value = "0"
    local row = {}
    local rowId
    local query = nil
    local ethRow = {}
    local nwRow = {}
    local param = input["param"]
    local parentObjInstance = ""

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", value
    end

    --find the immediate parent object with instance number
    local startIdx, endIdx
    startIdx, endIdx = string.find(param, "Interface.")
    parentObjInstance = string.sub(param, 1, endIdx+2)

    --read the rowId mapping to bridgeTable
    rowId = instanceMap[parentObjInstance]
    if (rowId == nil) then
        return "1", value
    end
	
    --get corresponding db entry from 'gpon'
    query = "_ROWID_=1"
    row = db.getRowWhere ("gpon", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = row["status"] 
    elseif(string.find(input["param"], "Status")) then
        -- Status
        if(row["status"] == "1") then
            value = "Up"
        elseif(row["status"] == "0") then
            value = "Down"
        end 
    elseif(string.find(input["param"], "Name")) then
        -- Name
        local file = io.open("/tmp/gponSerialNumber", "r")
        if(file ~= nil) then
            value = file:read ("*line") 
        else
            local bridgeModeRow = db.getRow ("bridgeMode", "_ROWID_", "1")
            if(row["status"] == "1") then
                value = bridgeModeRow["bridgeMode.wanIface"]
            else
                value = "pon0"
            end
        end
    elseif(string.find(input["param"], "LastChange")) then
        -- LastChange
        value = "0" 
    elseif(string.find(input["param"], "LowerLayers")) then
        -- LowerLayers
        value = ""
    elseif(string.find(input["param"], "Upstream")) then
        -- Upstream
        value = "1" 
    elseif(string.find(input["param"], "OpticalSignalLevel")) then
        -- OpticalSignalLevel
        value = "0" 
    elseif(string.find(input["param"], "LowerOpticalThreshold")) then
        -- LowerOpticalThreshold
        value = "0" 
    elseif(string.find(input["param"], "UpperOpticalThreshold")) then
        -- UpperOpticalThreshold
        value = "0" 
    elseif(string.find(input["param"], "TransmitOpticalLevel")) then
        -- TransmitOpticalLevel
        value = "0"  
    elseif(string.find(input["param"], "LowerTransmitPowerThreshold")) then
        -- LowerTransmitPowerThreshold
        value = "0"  
    elseif(string.find(input["param"], "UpperTransmitPowerThreshold")) then
        -- UpperTransmitPowerThreshold
        value = "0"
    else
         return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- nimfTr.opticalInterfaceSet- set optical configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.Optical.Interface.0.
--
-- Enable
-- LowerLayers
--
-- Returns: status
]]--

function nimfTr.opticalInterfaceSet(input, rowids, actionType, tr69Param)

    --Setting of any of these values is currently not supported in this device
    local status = "0"
    return 0;
end

--*****************************************************************************
-- nimfTr.InterfaceStackNumOfEntriesGet- get the number of interface Stacks
-- 
-- This function is called to get the following parameter in
-- Device.
--
-- Device.InterfaceStackNumberOfEntries.
--
-- Returns: status, value

function nimfTr.InterfaceStackNumOfEntriesGet (input)

    local status = "0"
    local value = "0"
    local i = 0
    local interfaceStackTbl = {}
    local parentObjInstance = nil
    local inTbl = {}

    parentObjInstance = "Device.IP.Interface.1."
    inTbl["param"] = parentObjInstance .. "LowerLayers"
    s,v = nimfTr.ipCfgGet (inTbl)
    if(v ~= nil and v ~= "" and (string.find(v, "Device."))) then
        local tmp = util.split(v, ",")
        for m,n in pairs (tmp) do
            if(n ~= nil and n ~= "") then
                i = i + 1
                interfaceStackTbl[i] = {}
                interfaceStackTbl[i]["wan"] = n
            end
        end
    end

    parentObjInstance = "Device.PPP.Interface.1."
    inTbl["param"] = parentObjInstance .. "LowerLayers"
    s,v = nimfTr.pppCfgGet (inTbl)
    if(v ~= nil and v ~= "" and (string.find(v, "Device."))) then
        i = i + 1
        interfaceStackTbl[i] = {}
        interfaceStackTbl[i]["wan"] = v
    end

    parentObjInstance = "Device.Optical.Interface.1."
    inTbl["param"] = parentObjInstance .. "LowerLayers"
    s,v = nimfTr.opticalInterfaceGet (inTbl)
    if(v ~= nil and v ~= "" and (string.find(v, "Device."))) then
        i = i + 1
        interfaceStackTbl[i] = {}
        interfaceStackTbl[i]["wan"] = v
    end

    parentObjInstance = "Device.Ethernet.Interface.1."
    inTbl["param"] = parentObjInstance .. "LowerLayers"
    s,v = ifDevTr.nwEthStatsGet (inTbl)
    if(v ~= nil and v ~= "" and (string.find(v, "Device."))) then
        i = i + 1
        interfaceStackTbl[i] = {}
        interfaceStackTbl[i]["wan"] = v
    end

    parentObjInstance = "Device.IP.Interface.2."
    inTbl["param"] = parentObjInstance .. "LowerLayers"
    s,v = nimfTr.ipCfgGet (inTbl)
    if(v ~= nil and v ~= "" and (string.find(v, "Device."))) then
        local tmp = util.split(v, ",")
        for m,n in pairs (tmp) do
            if(n ~= nil and n ~= "") then
                i = i + 1
                interfaceStackTbl[i] = {}
                interfaceStackTbl[i]["lan"] = n
            end
        end
    end

    parentObjInstance = "Device.Ethernet.Interface.2."
    inTbl["param"] = parentObjInstance .. "LowerLayers"
    s,v = ifDevTr.nwEthStatsGet (inTbl)
    if(v ~= nil and v ~= "" and (string.find(v, "Device."))) then
        i = i + 1
        interfaceStackTbl[i] = {}
        interfaceStackTbl[i]["lan"] = v
    end

    local qry = "band='b'"
    local radioTbl = db.getRowWhere("dot11Radio", qry, false)
    
    if(radioTbl ~= nil and radioTbl ~= "" ) then
        parentObjInstance = "Device.WiFi.SSID.1."
        inTbl["param"] = parentObjInstance .. "LowerLayers"
        s,v1 = dot11Tr.ssidProfileGet (inTbl)

        parentObjInstance = "Device.WiFi.SSID.2."
        inTbl["param"] = parentObjInstance .. "LowerLayers"
        s,v2 = dot11Tr.ssidProfileGet (inTbl)

        parentObjInstance = "Device.WiFi.SSID.3."
        inTbl["param"] = parentObjInstance .. "LowerLayers"
        s,v3 = dot11Tr.ssidProfileGet (inTbl)

        if( (v1 ~= nil and v1 ~= "" and (string.find(v1, "Device."))) or (v2 ~= nil and v2 ~= "" and (string.find(v2, "Device."))) or (v3 ~= nil and v3 ~= "" and (string.find(v3, "Device."))) ) then
            i = i + 1
            interfaceStackTbl[i] = {}
            if(string.find(v1, "Device.")) then
                interfaceStackTbl[i]["lan"] = v1
            elseif(string.find(v2, "Device.")) then
                interfaceStackTbl[i]["lan"] = v2
            elseif(string.find(v3, "Device.")) then
                interfaceStackTbl[i]["lan"] = v3
            end
        end
    end

    local qry = "band='a'"
    local radioTbl = db.getRowWhere("dot11Radio", qry, false)
    
    if(radioTbl ~= nil and radioTbl ~= "") then
        parentObjInstance = "Device.WiFi.SSID.4."
        inTbl["param"] = parentObjInstance .. "LowerLayers"
        s,v4 = dot11Tr.ssidProfileGet (inTbl)

        parentObjInstance = "Device.WiFi.SSID.5."
        inTbl["param"] = parentObjInstance .. "LowerLayers"
        s,v5 = dot11Tr.ssidProfileGet (inTbl)

        parentObjInstance = "Device.WiFi.SSID.6."
        inTbl["param"] = parentObjInstance .. "LowerLayers"
        s,v6 = dot11Tr.ssidProfileGet (inTbl)

        if( (v4 ~= nil and v4 ~= "" and (string.find(v4, "Device."))) or (v5 ~= nil and v5 ~= "" and (string.find(v5, "Device."))) or (v6 ~= nil and v6 ~= "" and (string.find(v6, "Device."))) ) then
            i = i + 1
            interfaceStackTbl[i] = {}
            if(string.find(v4, "Device.")) then
                interfaceStackTbl[i]["lan"] = v4
            elseif(string.find(v5, "Device.")) then
                interfaceStackTbl[i]["lan"] = v5
            elseif(string.find(v6, "Device.")) then
                interfaceStackTbl[i]["lan"] = v6
            end
        end
    end

    if(string.find(input["param"], "InterfaceStackNumberOfEntries")) then
        -- InterfaceStackNumberOfEntries
        value = #interfaceStackTbl
    end

    return status, value
end

--[[
--*****************************************************************************
-- nimfTr.getAssocObj - get AssociatedDevice object instance name
-- 
-- Returns: mainVal or nil
]]--
function nimfTr.getAssocObj(macAddr)
    local dot11STARow = {}
    local query = nil
    local mainVal = nil
    local APObj = ""

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return nil
    end

    --get correspnding db entry from dot11STA 
    macAddrUpperCase = string.upper(macAddr)
    query = "macAddress='" .. macAddr .. "' or macAddress='" .. macAddrUpperCase .. "'"
    dot11STARow = db.getRowWhere ("dot11STA", query, false)
    if(dot11STARow == nil) then
        return nil 
    end

    --get correspnding db entry from dot11Interface 
    query = "interfaceName='" .. dot11STARow["interfaceName"] .. "'"
    dot11InterfaceRow = db.getRowWhere ("dot11Interface", query, false)
    if(dot11InterfaceRow == nil) then
        return nil 
    end

    APObj = "Device.WiFi.AccessPoint."..dot11InterfaceRow["_ROWID_"]..".AssociatedDevice."

    for name,val in pairs (instanceMap) do
        if((string.find(name, APObj)) and (string.find(name, "MACAddress"))) then
            if(tonumber(val) == tonumber(dot11STARow["_ROWID_"])) then
                local startIdx, endIdx
                startIdx, endIdx = string.find(name, "AssociatedDevice.")
                mainVal = string.sub(name, 1, -11)
                break ; 
            end
        end
    end

    return mainVal
end

--[[
--*****************************************************************************
-- nimfTr.getLayer1Obj - get layer1 object instance name
-- 
-- Returns: mainVal or nil
]]--
function nimfTr.getLayer1Obj(macAddr)
    local dot11STARow = {}
    local query = nil
    local mainVal = nil
    local APObj = ""

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return nil
    end

    --get correspnding db entry from dot11STA 
    macAddrUpperCase = string.upper(macAddr)
    query = "macAddress='" .. macAddr .. "' or macAddress='" .. macAddrUpperCase .. "'"
    dot11STARow = db.getRowWhere ("dot11STA", query, false)
    if(dot11STARow == nil) then
        mainVal = "Device.Ethernet.Interface.2."
        return mainVal 
    end

    --get correspnding db entry from dot11Interface 
    query = "interfaceName='" .. dot11STARow["interfaceName"] .. "'"
    dot11InterfaceRow = db.getRowWhere ("dot11Interface", query, false)
    if(dot11InterfaceRow == nil) then
        return nil 
    end

    mainVal = "Device.WiFi.SSID."..dot11InterfaceRow["_ROWID_"].."."
    return mainVal
end

--[[
--*****************************************************************************
-- nimfTr.lanHostsGet- get lan hosts parameters
-- 
-- This function is called to get the following parameters in
-- Device.Hosts.Host.0.
--
-- Alias
-- PhysAddress
--
-- Returns: status, value
]]--
function nimfTr.lanHostsGet(input)

    local status = "0"
    local value = "0"
    local row = {}
    local rowId
    local query = nil
    local ethRow = {}
    local nwRow = {}
    local param = input["param"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", value
    end

    --read the rowId mapping to LanHosts
    rowId = instanceMap[param]
    if (rowId == nil) then
        return "1", value
    end

    --get corresponding db entry from 'LanHosts'
    query = "_ROWID_="..rowId
    row = db.getRowWhere ("LanHosts", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    if(string.find(input["param"], "Alias")) then
        -- Alias
        value = row["HostName"] 
    elseif(string.find(input["param"], "PhysAddress")) then
        -- PhysAddress
        value = row["MACAddress"]
    elseif (string.find(input["param"], "IPAddress")) then
        -- IPAddress
        if((row["IPv6Address"] ~= nil) and (row["IPv6Address"] ~= '') and (row["IPAddress"] ~=nil) and (row["IPAddress"] ~= '')) then
            value = row["IPAddress"] .. " , " .. row["IPv6Address"]
        elseif((row["IPv6Address"] ~= nil) and (row["IPv6Address"] ~= '')) then
            value = row["IPv6Address"]
        elseif((row["IPAddress"] ~= nil) and (row["IPAddress"] ~= '')) then
            value = row["IPAddress"]
        end
    elseif(string.find(input["param"], "AssociatedDevice")) then
        -- AssociatedDevice
        value = nimfTr.getAssocObj(row["MACAddress"])
        if(value == nil) then
            value = ""
        end
    elseif(string.find(input["param"], "Layer1Interface")) then
        -- Layer1Interface
        value = nimfTr.getLayer1Obj(row["MACAddress"])
        if(value == nil) then
            value = ""
        end
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- nimfTr.lanHostsSet- set Hosts configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.Hosts.Host.0.
--
-- Alias 
--
-- Returns: status
]]--
function nimfTr.lanHostsSet(input, rowids, actionType, tr69Param)
    --Setting of any of these values is currently not supported in this device
    local status = "0"
    tr69Glue.tf1Dbg("Entering & Leaving nimfTr.lanHostsSet..")

    local status = "0"
    local row = {}
    local rowId
    local query = nil
    local lanHostsTbl = {}
    local faultTbl = {}
    local index = 0

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --read the rowId mapping to FirewallRules
    rowId = instanceMap[tr69Param]
    if (rowId == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get corresponding db entry from LanHosts
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("LanHosts", query, false)
    if(row == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    lanHostsTbl = row
    -- Alias
    if(input["LanHosts"]["LanHosts.HostName"] ~= nil) then
        lanHostsTbl["HostName"] = input["LanHosts"]["LanHosts.HostName"]
    end

    --apply rule settings
    lanHostsTbl = util.addPrefix(lanHostsTbl, "LanHosts.")
    local valid, errstr = db.update("LanHosts", lanHostsTbl, lanHostsTbl["LanHosts._ROWID_"])
    if (not valid) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    db.save()

    return 0;
end

--[[
--*****************************************************************************
-- nimfTr.lanDhcpFixedIpAdd - Add LAN reserved IP 
-- 
-- This function is called to add a default row in DhcpfixedIpAddress table
-- for Device.DHCPv4.Server.Pool.0.StaticAddress.0.
--
-- Returns: status
]]--
function nimfTr.lanDhcpFixedIpAdd(input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering lanDhcpFixedIpAdd..")

    require "teamf1lualib/gui"

    local status = "OK"
    local errorFlag
    local row = {}
    local query = nil
    local lanIPRow = {}
    local inputTable = {}
    local defMacAddress = "00:12:22:33:44:"

    -- Filling the parameters of DhcpfixedIpAddress when Add Object for
    -- StaticAddress.{i}. is called
    rows = db.getTable ("DhcpfixedIpAddress")
    tr69Glue.tf1Dbg("Number of Rows Present .." ..#rows)
   
    local maxRowId = db.getMaxVal ("DhcpfixedIpAddress", "_ROWID_")
    if(maxRowId == nil or maxRowId == "") then
        maxRowId = 0
    end

    maxRowId = tonumber(maxRowId)
    query = "LogicalIfName = 'IF2' AND AddressFamily = 2"
    lanIPRow = db.getRowWhere("ifStatic", query, false)

    --Cname
    cnt = maxRowId+1
    cName = "cname"..cnt
    for k,v in pairs (rows) do
        if(v["DhcpfixedIpAddress.Cname"] == cName) then
            cnt = cnt + 1
            cName = "cname"..cnt
        end
    end
    inputTable["Cname"] = cName

    --IpAddr
    lanIP = util.split(lanIPRow["StaticIp"], ".")
    fixedIP = string.format("%d.%d.%d.", lanIP[1], lanIP[2], lanIP[3])
    fixedIPAddr = fixedIP.."2"

    --sort the IP address in order
    a = {}
    for k,v in pairs(rows) do
        b = util.split(v["DhcpfixedIpAddress.IpAddr"], ".")
        a[k] = tonumber(b[4])
    end
    table.sort(a)
    lanIPTbl = {}
    for k,v in pairs(a) do
        lanIPTbl[k] = fixedIP..v
    end

    --get the next IP
    for k,v in pairs (lanIPTbl) do
        if(v == fixedIPAddr) then
            tbl = util.split(fixedIPAddr, ".")
            val = tbl[4] + 1
            fixedIPAddr = fixedIP..val
        end
    end
    inputTable["startAddr"] = fixedIPAddr
 
    -- MacAddr
    macLastOctet = string.format("%x", maxRowId+1)
    if(string.len(macLastOctet) == 1) then
        fixedMacAddr = defMacAddress.."0"..macLastOctet
    else
        fixedMacAddr = defMacAddress..macLastOctet
    end

    for k,v in pairs (rows) do
        if(fixedMacAddr == v["DhcpfixedIpAddress.MacAddr"]) then
            macTbl = util.split(fixedMacAddr, ":")
            macNum = tonumber(macTbl[6])
            macCnt = string.format("%d", macNum+1)
            if(string.len(macCnt) == 1) then
                fixedMacAddr = defMacAddress.."0"..macCnt
            else
                fixedMacAddr = defMacAddress..macCnt
            end
        end
    end
    inputTable["macAddr"] = fixedMacAddr

    tr69Glue.tf1Dbg("inputTable : " .. util.tableToStringRec(inputTable))
    status, errorFlag = gui.networking.reservedDhcpClient.add.set (inputTable, dbFlag)

    if (status ~= "OK") then
        tr69Glue.tf1Dbg("errorFlag : " .. errorFlag)
        return error_code.REQUEST_DENIED;
    end

    tr69Glue.tf1Dbg("Leaving lanDhcpFixedIpAdd..")
    return 0;
end

--[[
--*****************************************************************************
-- nimfTr.lanDhcpFixedIpGet- get lan dhcp server fixed IP Address configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.DHCPv4.Server.Pool.0.StaticAddress.0.
--
-- Alias
-- Yiaddr
-- Chaddr
--
-- Returns: status, value
]]--
function nimfTr.lanDhcpFixedIpGet (input)
    local status = "0"
    local value = "0"
    local row = {}
    local query = nil
    local param = input["param"]
    local macSplit = {}
    local macStr = ""

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", value
    end

    --read the rowId mapping to Device.DHCPv4.Server.Pool.{i}.StaticAddress.{i}.
    rowId = instanceMap[param]
    if (rowId == nil) then
        return "1", value
    end

    --get corresponding db entry from DhcpfixedIpAddress
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("DhcpfixedIpAddress", query, false)
    if (row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    
    --find & return parameter values
    if(string.find(input["param"], "Alias")) then
        -- Alias
        value = row["Cname"]
    elseif(string.find(input["param"], "Yiaddr")) then
        -- Yiaddr
        value = row["IpAddr"]
    elseif(string.find(input["param"], "Chaddr")) then
        -- Chaddr
        value = row["MacAddr"]
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- nimfTr.lanDhcpFixedIpSet- set lan dhcp server fixed IPAddress configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.DHCPv4.Server.Pool.0.StaticAddress.
--
-- Alias
-- Yiaddr
-- Chaddr
--
-- Returns: status, faultTbl
]]--
function nimfTr.lanDhcpFixedIpSet(input, rowids, actionType, tr69Param)
    local status = OK
    local index = 0
    local faultTbl = {}
    local row = {}
    local rowId 
    local inputTable = {}

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR) 
        return status, faultTbl;
    end

    --read the rowId mapping of the corresponding Device.DHCPv4.Server.Pool.{i}.StaticAddress.{i}.
    rowId = instanceMap[tr69Param]
    if (rowId == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR) 
        return status, faultTbl;
    end

    --get correspnding db entry from DhcpfixedIpAddress
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("DhcpfixedIpAddress", query, false)
    if(row == "nil") then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR) 
        return status, faultTbl;
    end

    -- Alias
    if(input["DhcpfixedIpAddress"]["DhcpfixedIpAddress.Cname"] ~= nil) then
        row["Cname"] = input["DhcpfixedIpAddress"]["DhcpfixedIpAddress.Cname"]
    end

    -- Yiaddr
    if(input["DhcpfixedIpAddress"]["DhcpfixedIpAddress.IpAddr"] ~= nil) then
        if(tr69Glue.tf1IpAddressValidate(input["DhcpfixedIpAddress"]["DhcpfixedIpAddress.IpAddr"],"","","") ~= "OK" or input["DhcpfixedIpAddress"]["DhcpfixedIpAddress.IpAddr"] == LOOP_BACK_ADDRESS) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Yiaddr", error_code.INVALID_PARAM_VALUE)
        else
            row["IpAddr"] = input["DhcpfixedIpAddress"]["DhcpfixedIpAddress.IpAddr"]
        end
    end

    -- Chaddr
    if(input["DhcpfixedIpAddress"]["DhcpfixedIpAddress.MacAddr"] ~= nil) then
        if(tr69Glue.tf1ValidateMacAddr(input["DhcpfixedIpAddress"]["DhcpfixedIpAddress.MacAddr"],"") ~= 0) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Chaddr", error_code.INVALID_PARAM_VALUE)
        else
            row["MacAddr"] = input["DhcpfixedIpAddress"]["DhcpfixedIpAddress.MacAddr"]
        end
    end

    if(status ~= OK) then
       return status, faultTbl
    end

    require "teamf1lualib/gui"

    inputTable["_ROWID_"] = rowId
    inputTable["Cname"] = row["Cname"]
    inputTable["startAddr"] = row["IpAddr"]
    inputTable["macAddr"] = row["MacAddr"]

    errorFlag, statusCode = gui.networking.reservedDhcpClient.edit.set (inputTable, dbFlag)

    if(errorFlag == "OK") then
        db.save ();
    else
        if(input["DhcpfixedIpAddress"]["DhcpfixedIpAddress.IpAddr"] ~= nil) then
            if(statusCode == "IPADDRESS_NOT_IN_NETWORK_SUBNET" or statusCode == "RESERVED_DEVICE_IP" or statusCode == "DHCPD_ADDRESS_NOT_IN_LAN_SUBNET" or statusCode == "DHCPD_RESERVATION_EXISTS") then
                tr69Glue.tf1Dbg("IpAddr config failed with error = ".. statusCode)
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Yiaddr", error_code.REQUEST_DENIED)
            end
        end

        if(input["DhcpfixedIpAddress"]["DhcpfixedIpAddress.MacAddr"] ~= nil) then
            if(statusCode == "DHCPD_INVALID_MAC_ADDRESS" or statusCode == "RESERVED_DEVICE_IP" or statusCode == "DHCPD_RESERVATION_EXISTS") then
                tr69Glue.tf1Dbg("MacAddr config failed with error = ".. statusCode)
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Chaddr", error_code.REQUEST_DENIED)
            end
        end

        if(input["DhcpfixedIpAddress"]["DhcpfixedIpAddress.Cname"] ~= nil) then
            if(statusCode == "DHCPD_RESERVATION_EXISTS") then
                tr69Glue.tf1Dbg("Cname config failed with error = ".. statusCode)
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Alias", error_code.REQUEST_DENIED)
            end
        end

        if(status == ERROR) then
            return status, faultTbl
        else
            tr69Glue.tf1Dbg("StaticAddress config failed with error = ".. statusCode)
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        end
    end

    return status, faultTbl
end

--[[
--*****************************************************************************
-- nimfTr.dhcpv6ServerGet - get dhcpv6 server configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.DHCPv6.Server.
--
-- Enable
--
-- Returns: status, value
]]--
function nimfTr.dhcpv6ServerGet(input)
    local status = "0"
    local value = "0"
    local row = {}
    local query = nil
    local param = input["param"]
    local macSplit = {}
    local macStr = ""

    --get corresponding db entry from dhcpv6s
    query = "_ROWID_=1" 
    row = db.getRowWhere ("dhcpv6s", query, false)
    if (row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    
    --find & return parameter values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = row["isEnabled"]
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- nimfTr.dhcpv6ServerSet- set dhcpv6 server configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.DHCPv6.Server.
--
-- Enable
--
-- Returns: status, faultTbl
]]--
function nimfTr.dhcpv6ServerSet(input, rowids, actionType, tr69Param)
    require "teamf1lualib/gui"

    local status = OK
    local index = 0
    local faultTbl = {}
    local row = {}
    local rowId 
    local name = "Local"

    --get correspnding db entry from dhcpv6s
    query = "_ROWID_=1" 
    row = db.getRowWhere ("dhcpv6s", query, false)
    if(row == "nil") then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR) 
        return status, faultTbl;
    end

    -- get default values
    errorFlag, statusCode, configRow = gui.networking.network.ipv6.get (name)
    if(configRow == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR) 
        return status, faultTbl;
    end

    if(input["dhcpv6s"]["dhcpv6s.isEnabled"] ~= nil) then
        configRow["dhcpv6Mode"] = input["dhcpv6s"]["dhcpv6s.isEnabled"]
    end

    inputTable = {}
    inputTable["prefixDelegation"] = configRow["prefixDelegation"]
    inputTable["dhcpMode"] = configRow["dhcpMode"]
    inputTable["StaticIp"] = configRow["StaticIp"]
    inputTable["PrefixLength"] = configRow["PrefixLength"]
    inputTable["DNSServers"] = configRow["DNSServers"]
    inputTable["DomainName"] = configRow["DomainName"]
    inputTable["ConnectionType"] = configRow["ConnectionType"]
    inputTable["networkType"] = configRow["networkType"]
    inputTable["sipServerType"] = configRow["sipServerType"]
    inputTable["dhcpv6Mode"] = configRow["dhcpv6Mode"]
    inputTable["preference"] = configRow["preference"]
    inputTable["dhcpLeaseTime"] = configRow["dhcpLeaseTime"]

    errorFlag, statusCode = gui.networking.network.ipv6.set(name, inputTable, dbFlag)
    if(errorFlag ~= "OK") then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, "Device.DHCPv6.Server.Enable", error_code.INTERNAL_ERROR)
        return status, faultTbl
    end 

    db.save()

    return status, faultTbl
end

--[[
--*****************************************************************************
-- nimfTr.getLanPrefixObj - get IPv6Prefix object instance name
-- 
-- Returns: IPv6Prefix instance name or nil
]]--
function nimfTr.getLanPrefixObj(serverPoolType, dhcpv6ServerPoolsRow)
    local ipv6TableRow = {}
    local query = nil
    local mainVal = ""
    local staticIP = ""

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return mainVal
    end
    local prefixObj = "Device.IP.Interface.2.IPv6Prefix."
    
    if(serverPoolType == "IANA") then
        query = "startAddress='" .. dhcpv6ServerPoolsRow["addrPoolAddress"] .. "'"
    else
        query = "delegationPrefix='" .. dhcpv6ServerPoolsRow["prefixPoolAddress"] .. "'"
    end

    ipv6TableRow = db.getRowWhere ("ipv6PrefixTable", query, false)
    if(ipv6TableRow == nil) then
        return mainVal 
    end
    
    for name,val in pairs (instanceMap) do
        if(string.find(name, prefixObj) and string.find(name, "Enable") ) then
            if(tonumber(val) == tonumber(ipv6TableRow["_ROWID_"])) then
                len = string.len(name)
                mainVal = string.sub(name, 1, len-6)
                break ; 
            end
        end
    end

    return mainVal
end

--[[
--*****************************************************************************
-- nimfTr.getPrefixObj - get IPv6Prefix instance name
-- 
-- Returns: IPv6Prefix instance name or nil
]]--
function nimfTr.getPrefixObj(ipaddressTblRow)
    local ipv6TableRow = {}
    local query = nil
    local mainVal = ""
    local staticIP = ""
    local prefixObj = ""

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return mainVal
    end

    if(ipaddressTblRow["LogicalIfName"] == "IF1") then
        prefixObj = "Device.IP.Interface.1.IPv6Prefix."
    else
        prefixObj = "Device.IP.Interface.2.IPv6Prefix."
    end
    
    query = "ipAddress='" .. ipaddressTblRow["ipAddress"] .. "' and prefixType='AUTO'"
    ipv6TableRow = db.getRowWhere ("ipv6PrefixTable", query, false)
    if(ipv6TableRow == nil) then
        return mainVal 
    end
    
    for name,val in pairs (instanceMap) do
        if(string.find(name, prefixObj) and string.find(name, "Enable") ) then
            if(tonumber(val) == tonumber(ipv6TableRow["_ROWID_"])) then
                len = string.len(name)
                mainVal = string.sub(name, 1, len-6)
                break ; 
            end
        end
    end

    return mainVal
end

--[[
--*****************************************************************************
-- nimfTr.dhcpv6ServerPoolGet - get dhcpv6 server pool configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.DHCPv6.Server.Pool.0.
--
-- Enable
-- Interface
-- DUID
-- IANAEnable
-- IANAManualPrefixes
-- IANAPrefixes
-- IAPDEnable
-- IAPDManualPrefix
-- IAPDPrefix
-- IAPDAddLength
-- 
-- Returns: status, value
]]--
function nimfTr.dhcpv6ServerPoolGet(input)
    local status = "0"
    local value = "0"
    local row = {}
    local query = nil
    local param = input["param"]
    local macSplit = {}
    local macStr = ""

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", value
    end

    --read the rowId mapping to Device.DHCPv6.Server.Pool.0.
    rowId = instanceMap[param]
    if (rowId == nil) then
        return "1", value
    end

    --get correspnding db entry from dhcpv6s
    query = "_ROWID_=1"
    row = db.getRowWhere ("dhcpv6s", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end
 
    query = "_ROWID_=" ..rowId
    dhcpv6ServerPoolsRow = db.getRowWhere ("dhcpv6ServerPools", query, false)
    if(dhcpv6ServerPoolsRow == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    if(string.find(input["param"], "Interface")) then
        -- Interface
        -- find the corresponding interface entry from instanceMap using rowId
        -- fetched from dhcpv6s by row["LogicalIfName"]
        local lanDhcpIfaceObj = ""
        lanDhcpIfaceObj = nimfTr.getIfaceObjFromIfname(row["LogicalIfName"])
        value = lanDhcpIfaceObj
        if(value == nil or value == "") then
            return "1", "DB_ERROR_TRY_AGAIN"
        end
    elseif(string.find(input["param"], "DUID")) then
        -- DUID
        value = string.gsub(dhcpv6ServerPoolsRow["DUID"], ":", "")
    elseif((string.sub(input["param"], -10, -1)) == "IANAEnable") then
        -- IANAEnable
        if(dhcpv6ServerPoolsRow["serverPoolType"] == "IANA") then
            if(row["statelessMode"] == "0") then
                value = "1"
            else
                value = "0"
            end
        else
            value = "0"
        end
    elseif(string.find(input["param"], "IANAManualPrefixes")) then
        -- IANAManualPrefixes
        -- since IANA prefixes cannot be configured manually, this value will be
        -- empty
        value = ""
    elseif(string.find(input["param"], "IANAPrefixes")) then
        -- IANAPrefixes
        if(dhcpv6ServerPoolsRow["serverPoolType"] == "IANA") then
            local prefixRefObj = ""
            prefixRefObj = nimfTr.getLanPrefixObj(dhcpv6ServerPoolsRow["serverPoolType"], dhcpv6ServerPoolsRow)
            if(prefixRefObj ~= nil and prefixRefObj ~= "") then
                value = prefixRefObj
            else
                value = ""
            end
        else
            value = ""
        end
    elseif((string.sub(input["param"], -10, -1)) == "IAPDEnable") then
        -- IAPDEnable
        if(dhcpv6ServerPoolsRow["serverPoolType"] == "IAPD") then
            if(row["statelessMode"] == "1" and row["prefixDelegation"] == "1") then
                value = "1"
            else
                value = "0"
            end
        else
            value = "0"
        end
    elseif(string.find(input["param"], "IAPDManualPrefixes")) then
        -- IAPDManualPrefixes
        if(dhcpv6ServerPoolsRow["serverPoolType"] == "IAPD") then
            local prefixRefObj = ""
            prefixRefObj = nimfTr.getLanPrefixObj(dhcpv6ServerPoolsRow["serverPoolType"], dhcpv6ServerPoolsRow)
            if(prefixRefObj ~= nil and prefixRefObj ~= "") then
                value = prefixRefObj
            else
                value = ""
            end
        else
            value = ""
        end
    elseif(string.find(input["param"], "IAPDPrefixes")) then
        -- IAPDPrefixes
        -- IAPD prefixes are configured only manually, so IAPDPrefixes is empty
        value = ""
    elseif(string.find(input["param"], "IAPDAddLength")) then
        -- IAPDAddLength
        if(dhcpv6ServerPoolsRow["serverPoolType"] == "IAPD") then
            value = dhcpv6ServerPoolsRow["IAPDAddLength"]
        else
            value = "0"
        end
    elseif(string.find(input["param"], "Enable")) then
        -- Enable
        if(row["isEnabled"] == "1") then
            value = "1"
        else
            value = "0"
        end
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- nimfTr.dhcpv6ServerPoolSet- set dhcpv6 server pool configuration parameters
-- 
-- This function is called to set the following parameters in
-- Device.DHCPv6.Server.Pool.0.
--
-- Enable
-- Interface
-- IANAEnable
-- IANAManualPrefixes
-- IANAPrefixes
-- IAPDEnable
-- IAPDManualPrefix
-- IAPDPrefix
-- IAPDAddLength
--
-- Returns: status, faultTbl
]]--
function nimfTr.dhcpv6ServerPoolSet(input, rowids, actionType, tr69Param)
    require "teamf1lualib/gui"

    local status = OK
    local index = 0
    local faultTbl = {}
    local rowId 
    local inRow = {}
    local dhcpv6sLanPrefixPoolRow = {}
    local ipv6PrefixTableRow = {}
    local dhcpv6sServerPoolRow = {}
    local configRow = {}
    local updateIAPD = 0
    local updateDHCPv6Conf = 0
    local name = "Local"

    inRow = input["dhcpv6ServerPools"]

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR) 
        return status, faultTbl;
    end

    --read the rowId mapping of the corresponding Device.DHCPv6.Server.Pool.0.
    rowId = instanceMap[tr69Param]
    if (rowId == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR) 
        return status, faultTbl;
    end

    --get correspnding db entry from dhcpv6ServerPools
    query = "_ROWID_=" .. rowId
    dhcpv6sServerPoolRow = db.getRowWhere ("dhcpv6ServerPools", query)
    if(dhcpv6sServerPoolRow == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR) 
        return status, faultTbl;
    end

    --get correspnding db entry from dhcpv6sLANPrefixPool
    if(dhcpv6sServerPoolRow["dhcpv6ServerPools.serverPoolType"] == "IAPD") then
        query = "delegationPrefix='" .. dhcpv6sServerPoolRow["dhcpv6ServerPools.prefixPoolAddress"] .. "'"
        dhcpv6sLanPrefixPoolRow = db.getRowWhere ("dhcpv6sLANPrefixPool", query)
        if(dhcpv6sLanPrefixPoolRow == nil) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR) 
            return status, faultTbl;
        end

        --get correspnding db entry from ipv6PrefixTable
        query = "delegationPrefix='" .. dhcpv6sServerPoolRow["dhcpv6ServerPools.prefixPoolAddress"] .. "'"
        ipv6PrefixTableRow = db.getRowWhere ("ipv6PrefixTable", query)
        if(ipv6PrefixTableRow == nil) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl;
        end
    end

    --get default values
    errorFlag, statusCode, configRow = gui.networking.network.ipv6.get (name)
    if(configRow == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR) 
        return status, faultTbl;
    end

    -- DUID
    if(inRow["dhcpv6ServerPools.DUID"] ~= nil) then
        if(dhcpv6sServerPoolRow["dhcpv6ServerPools.serverPoolType"] == "IAPD") then
            -- 1 octet is 2 digit number, so 130*2
            if(string.len(inRow["dhcpv6ServerPools.DUID"]) > (130*2)) then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."DUID", error_code.INVALID_PARAM_VALUE)
                tr69Glue.tf1Dbg("Invalid DUID = ".. inRow["dhcpv6ServerPools.DUID"])
            else
                local duid
                local left,num = string.match(inRow["dhcpv6ServerPools.DUID"],'^([^%x]*%x)(%x*)$')
                duid = left..(num:reverse():gsub('(%x%x)','%1:'):reverse())
                tr69Glue.tf1Dbg("duid: ".. duid)

                if(tr69Glue.tf1ValidateDUID(duid, "") ~= 0) then
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."DUID", error_code.INVALID_PARAM_VALUE)
                    tr69Glue.tf1Dbg("Invalid DUID: ".. duid)
                else
                    dhcpv6sLanPrefixPoolRow["dhcpv6sLANPrefixPool.hostDuid"] = duid
                    dhcpv6sServerPoolRow["dhcpv6ServerPools.DUID"] = duid
                    ipv6PrefixTableRow["ipv6PrefixTable.hostDuid"] = duid
                    updateIAPD = 1
                end
            end
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."DUID", error_code.REQUEST_DENIED)
            tr69Glue.tf1Dbg("Cannot edit DUID as this is not IAPD pool..")
        end
    end

    -- IAPDAddLength
    if(inRow["dhcpv6ServerPools.IAPDAddLength"] ~= nil) then
        if(dhcpv6sServerPoolRow["dhcpv6ServerPools.serverPoolType"] == "IAPD") then
            if(tonumber(inRow["dhcpv6ServerPools.IAPDAddLength"]) >= PREFIX_LEN_MIN and tonumber(inRow["dhcpv6ServerPools.IAPDAddLength"]) <= PREFIX_LEN_MAX) then
                dhcpv6sLanPrefixPoolRow["dhcpv6sLANPrefixPool.delegationPrefixLen"] = inRow["dhcpv6ServerPools.IAPDAddLength"]
                dhcpv6sServerPoolRow["dhcpv6ServerPools.IAPDAddLength"] = inRow["dhcpv6ServerPools.IAPDAddLength"]
                ipv6PrefixTableRow["ipv6PrefixTable.delegationPrefixLen"] = inRow["dhcpv6ServerPools.IAPDAddLength"]
                updateIAPD = 1
            else
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."IAPDAddLength", error_code.INVALID_PARAM_VALUE)
                tr69Glue.tf1Dbg("Invalid prefix length..")
            end
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."IAPDAddLength", error_code.REQUEST_DENIED)
            tr69Glue.tf1Dbg("Cannot edit IAPDAddLength as this is not IAPD pool..")
        end
    end

    -- IANAEnable
    if(inRow["dhcpv6ServerPools.IANAEnable"] ~= nil) then
        if(dhcpv6sServerPoolRow["dhcpv6ServerPools.serverPoolType"] == "IANA") then
            if(inRow["dhcpv6ServerPools.IANAEnable"] == "1") then
                configRow["dhcpMode"] = "0" -- statefull
            else
                configRow["dhcpMode"] = "1" -- stateless
            end
            updateDHCPv6Conf = 1
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."IANAEnable", error_code.REQUEST_DENIED)
            tr69Glue.tf1Dbg("Cannot edit IANAEnable as this is not IANA pool")
        end
    end
   
    -- IAPDEnable
    if(inRow["dhcpv6ServerPools.IAPDEnable"] ~= nil) then
        if(dhcpv6sServerPoolRow["dhcpv6ServerPools.serverPoolType"] == "IAPD") then
            -- enable IAPD only if it is in stateless mode
            if(configRow["dhcpMode"] == "1") then
                configRow["prefixDelegation"] = inRow["dhcpv6ServerPools.IAPDEnable"]
                updateDHCPv6Conf = 1
            else
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."IAPDEnable", error_code.REQUEST_DENIED)
                tr69Glue.tf1Dbg("Cannot edit as IAPDEnable as server is in statefull mode..")
            end
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."IAPDEnable", error_code.REQUEST_DENIED)
            tr69Glue.tf1Dbg("Cannot edit IAPDEnable as this is not IAPD pool..")
        end
    end

    if(status ~= OK) then
        return status, faultTbl
    end

    -- update the values in db
    if (updateIAPD == 1) then
        valid, errstr = db.update ("dhcpv6sLANPrefixPool", dhcpv6sLanPrefixPoolRow, dhcpv6sLanPrefixPoolRow["dhcpv6sLANPrefixPool._ROWID_"]);
        if (not valid) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl
        end

        valid, errstr = db.update ("dhcpv6ServerPools", dhcpv6sServerPoolRow, dhcpv6sServerPoolRow["dhcpv6ServerPools._ROWID_"]);
        if (not valid) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl
        end

        valid, errstr = db.update ("ipv6PrefixTable", ipv6PrefixTableRow, ipv6PrefixTableRow["ipv6PrefixTable._ROWID_"]);
        if (not valid) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl
        end
    end

    if(updateDHCPv6Conf == 1) then
        tr69Glue.tf1Dbg("configRow" .. util.tableToStringRec(configRow))

        inputTable = {}
        inputTable["prefixDelegation"] = configRow["prefixDelegation"]
        inputTable["dhcpMode"] = configRow["dhcpMode"]
        inputTable["StaticIp"] = configRow["StaticIp"]
        inputTable["PrefixLength"] = configRow["PrefixLength"]
        inputTable["DNSServers"] = configRow["DNSServers"]
        inputTable["DomainName"] = configRow["DomainName"]
        inputTable["ConnectionType"] = configRow["ConnectionType"]
        inputTable["networkType"] = configRow["networkType"]
        inputTable["sipServerType"] = configRow["sipServerType"]
        inputTable["dhcpv6Mode"] = configRow["dhcpv6Mode"]
        inputTable["preference"] = configRow["preference"]
        inputTable["dhcpLeaseTime"] = configRow["dhcpLeaseTime"]

        tr69Glue.tf1Dbg("inputTable" .. util.tableToStringRec(inputTable))

        errorFlag, statusCode = gui.networking.network.ipv6.set(name, inputTable, dbFlag)
        if(errorFlag ~= "OK") then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl
        end
    end

    db.save ();

    return status, faultTbl
end

--[[
--*****************************************************************************
-- nimfTr.dhcpv6ServerPoolAdd - Add dhcpv6 server pools, only IAPD  
-- 
-- This function is called to add a default row in dhcpv6ServerPools table
-- for Device.DHCPv6.Server.Pool.0.
--
-- Returns: status
]]--
function nimfTr.dhcpv6ServerPoolAdd(input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering dhcpv6ServerPoolAdd..")

    require "teamf1lualib/gui"

    local status = "OK"
    local errorFlag
    local row = {}
    local query = nil
    local lanIPRow = {}
    local inputTable = {}

    -- Filling the parameters of dhcpv6ServerPools when Add Object for
    -- Device.DHCPv6.Server.Pool.{i}. is called
    rows = db.getTable ("dhcpv6ServerPools")
    tr69Glue.tf1Dbg("Number of Rows Present .." ..#rows)
   
    -- set default values
    inputTable["hostDuid"] = "00:11:22:33:44:55:66:77"
    inputTable["delegationPrefix"] = "fd00::"
    inputTable["delegationPrefixLen"] = "64"
    tr69Glue.tf1Dbg("inputTable : " .. util.tableToStringRec(inputTable))

    -- check if the prefix pool is already present
    local dhcpTbl = db.getTable("dhcpv6sLANPrefixPool", false)
    for i,v in pairs (dhcpTbl) do
        if ((v["delegationPrefix"] == inputTable["delegationPrefix"]) and (v["delegationPrefixLen"] == inputTable["delegationPrefixLen"])) then
            tr69Glue.tf1Dbg("Prefix already exits.." )
            return error_code.REQUEST_DENIED;
        end
    end

    -- insert row in dhcpv6sLANPrefixPool
    local dhcpv6sLANPrefixPoolRow = {}
    dhcpv6sLANPrefixPoolRow["dhcpv6sLANPrefixPool.hostDuid"] = inputTable["hostDuid"]
    dhcpv6sLANPrefixPoolRow["dhcpv6sLANPrefixPool.delegationPrefix"] = inputTable["delegationPrefix"]
    dhcpv6sLANPrefixPoolRow["dhcpv6sLANPrefixPool.delegationPrefixLen"] = inputTable["delegationPrefixLen"]

    local valid, errstr, rowid  = db.insert("dhcpv6sLANPrefixPool", dhcpv6sLANPrefixPoolRow)
    if (not valid) then
        tr69Glue.tf1Dbg("Failed to add dhcpv6sLANPrefixPool configuration")
        return error_code.REQUEST_DENIED;
    end            
        
    -- insert row in dhcpv6ServerPools
    local dhcpv6ServerPoolstbl = {}
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.addrPoolAddress"] = ""
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.IANAManualPrefixes"] = ""
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.IANAPrefixes"] = ""
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.DUID"] = inputTable["hostDuid"]
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.prefixPoolAddress"] = inputTable["delegationPrefix"]
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.IAPDManualPrefixes"] = ""
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.IAPDPrefixes"] = ""
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.IAPDAddLength"] = inputTable["delegationPrefixLen"]
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.prefix"] = inputTable["delegationPrefix"].."/"..inputTable["delegationPrefixLen"]
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.LogicalIfName"] = "IF2" 
    dhcpv6ServerPoolstbl["dhcpv6ServerPools.serverPoolType"] = "IAPD"
        
    local valid, errstr, rowid = db.insert("dhcpv6ServerPools", dhcpv6ServerPoolstbl) 
    if (not valid) then
        tr69Glue.tf1Dbg("Failed to add dhcpv6ServerPools configuration")
        return error_code.REQUEST_DENIED;
    end

    -- insert row in ipv6PrefixTable
    local ipv6PrefixTbl = {}
    ipv6PrefixTbl["ipv6PrefixTable.LogicalIfName"] = "IF2"
    ipv6PrefixTbl["ipv6PrefixTable.prefixType"] = "IAPD"
    ipv6PrefixTbl["ipv6PrefixTable.addressFamily"] = "10"
    ipv6PrefixTbl["ipv6PrefixTable.ConnectionKey"] = "0"
    ipv6PrefixTbl["ipv6PrefixTable.isStatic"] = "0"
    ipv6PrefixTbl["ipv6PrefixTable.ipAddress"] = ""
    ipv6PrefixTbl["ipv6PrefixTable.ipDstAddres"] = ""
    ipv6PrefixTbl["ipv6PrefixTable.ipv6PrefixLen"] = "0"
    ipv6PrefixTbl["ipv6PrefixTable.subnetMask"] = ""
    ipv6PrefixTbl["ipv6PrefixTable.hostDuid"] = inputTable["hostDuid"]
    ipv6PrefixTbl["ipv6PrefixTable.delegationPrefix"] = inputTable["delegationPrefix"]
    ipv6PrefixTbl["ipv6PrefixTable.delegationPrefixLen"] = inputTable["delegationPrefixLen"]
    ipv6PrefixTbl["ipv6PrefixTable.startAddress"] = ""
    ipv6PrefixTbl["ipv6PrefixTable.endAddress"] = ""
    ipv6PrefixTbl["ipv6PrefixTable.prefixLength"] = "0"

    local valid, errstr, rowid = db.insert("ipv6PrefixTable", ipv6PrefixTbl) 
    if (not valid) then
        tr69Glue.tf1Dbg("Failed to add ipv6PrefixTable configuration")
        return error_code.REQUEST_DENIED;
    end 

    tr69Glue.tf1Dbg("Leaving dhcpv6ServerPoolAdd..")
    return 0;
end

--[[
--*****************************************************************************
-- nimfTr.ipV6PrefixGet- get ipv6 prefix parameters
-- 
-- This function is called to get the following parameters in
-- Device.IP.Interface.0.IPv6Prefix.0.
--
-- Enable
-- Status
-- PrefixStatus
-- Prefix
-- Origin
--
-- Returns: status, value
]]--
function nimfTr.ipV6PrefixGet (input)
    local status = "0"
    local value = "0"
    local rowId
    local query = nil
    local param = input["param"]
    local parentObjInstance = ""
    local row = {}
    local nimfRow = {}
    local ifStaticRow = {}

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", value
    end

    --read the rowId mapping to Device.IP.Interface.{i}.IPv6Prefix.{i}.
    rowId = instanceMap[param]
    if (rowId == nil) then
        return "1", value
    end
   
    --get corresponding db entry from ipv6PrefixTable
    query = "_ROWID_=" .. rowId
    row = db.getRowWhere ("ipv6PrefixTable", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --get corresponding db entry from nimfConf
    query = "LogicalIfName='" .. row["LogicalIfName"] .. "'"
    query = query .. " and ConnectionKey='" .. row["ConnectionKey"] .. "'" .. " and addressFamily=10"
    nimfRow = db.getRowWhere ("NimfConf", query, false)
    if(nimfRow == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    if(row["prefixType"] == "AUTO") then
        ipv6Prefix = nimfLib.prefixGet(row["ipAddress"], row["ipv6PrefixLen"]) 
        ipv6PrefixLength = row["ipv6PrefixLen"]
    elseif(row["prefixType"] == "IAPD") then
        ipv6Prefix = row["delegationPrefix"] 
        ipv6PrefixLength = row["delegationPrefixLen"]
    elseif(row["prefixType"] == "IANA") then
        ipv6Prefix = nimfLib.prefixGet(row["startAddress"], row["prefixLength"]) 
        ipv6PrefixLength = row["prefixLength"]
    end

    --get corresponding db entry from ifStatic
    query = "LogicalIfName='" .. row["LogicalIfName"] .. "'"
    query = query .. " and ConnectionKey='" .. row["ConnectionKey"] .. "'" .. " and addressFamily=10"
    ifStaticRow = db.getRowWhere ("ifStatic", query, false)

    --get corresponding db entry from radvdLANPrefixPool
    query = "LogicalIfName='" .. row["LogicalIfName"] .. "'"
    radvdLANPrefixPoolRow = db.getRowsWhere ("radvdLANPrefixPool", query, false)

    -- set default values
    if(string.find(input["param"], "Enable")) then
        -- Enable
        if(ipv6Prefix == "::") then
            value = "0"
        else
            value = "1"
        end
    elseif(string.find(input["param"], "PrefixStatus")) then
        -- PrefixStatus
        if(ipv6Prefix == "::") then
            value = "Invalid"
        else
            value = "Preferred"
        end
    elseif(string.find(input["param"], "Status")) then
        -- Status
        if(ipv6Prefix == "::") then
            value = "Error_Misconfigured"
        else
            value = "Enabled"
        end
    elseif((string.sub(input["param"], -6, -1)) == "Origin") then
        -- Origin
        local connectionType = ""
        require "platformLib"

        if(row["prefixType"] == "AUTO") then
            local staticFlag = 0
            if(ifStaticRow ~= nil) then
                -- if IPv6 address is present in ifStatic table, it is static prefix
                errorCode, errorString = platformLib.ipv6AddressesCompare(row["ipAddress"], ifStaticRow["StaticIp"])
                if(errorCode == 0) then
                    staticFlag = 1 
                end
            end

            local radvdFlag = 0
            if(radvdLANPrefixPoolRow ~= nil) then
                for k,v in pairs (radvdLANPrefixPoolRow) do
                    -- if IPv6 address is present in radvdLANPrefixPool table, it is RA prefix
                    local rdvdPrefix = nimfLib.prefixGet(v["radvdAdvPrefix"], v["radvdAdvPrefixLength"])
                    if(ipv6Prefix == rdvdPrefix) then
                        radvdFlag = 1
                        radvdRow = v
                        break;
                    end
                end
            end

            if(staticFlag == 1) then
                if (nimfRow["ConnectionType"] == "ifStatic6") then
                    -- if ipv6 address is assgined statically
                    connectionType = "Static"
                end
            elseif(radvdFlag == 1) then
                if(radvdRow["radvdPrefixType"] == "2") then
                    connectionType = "Static"
                elseif(radvdRow["radvdPrefixType"] == "3" and staticFlag == 1) then
                    connectionType = "Static"
                elseif(radvdRow["radvdPrefixType"] == "3" and staticFlag == 0) then
                    connectionType = "PrefixDelegation"
                else
                    connectionType = "RouterAdvertisement"
                end
            else
                if((string.sub(row["ipAddress"], 1, 4) == "fe80") or (row["ipAddress"] == "0::0") or (nimfRow["ConnectionType"] == "dhcp6c-stateless")) then
                    -- if ipv6 address is link local or 0::0 or assigned via stateless mode
                    connectionType = "AutoConfigured"
                elseif (nimfRow["ConnectionType"] == "dhcp6c") then
                    -- if ipv6 address is assigned via statefull mode
                    connectionType = "DHCPv6"
                else
                    -- if all the above cases fail, the IPv6 address will be
                    -- autoconfigured
                    connectionType = "AutoConfigured"
                end
            end
        elseif(row["prefixType"] == "IAPD") then
            connectionType = "PrefixDelegation"
        elseif(row["prefixType"] == "IANA") then
            connectionType = "AutoConfigured"
        end
        value = connectionType
    elseif(string.find(input["param"], "Prefix")) then
        -- Prefix
        value = ipv6Prefix.."/"..ipv6PrefixLength
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    
    return status, value
end

--[[
--*****************************************************************************
-- nimfTr.ipV6PrefixSet- set ipv6 prefix parameters
-- 
-- This function is called to set the following parameters in
-- Device.IP.Interface.0.IPv6Prefix.0.
--
-- Prefix
--
-- Returns: status, faultTbl
]]--
function nimfTr.ipV6PrefixSet (input, rowids, actionType, tr69Param)
    local status = OK 
    local faultTbl = {}
    local index = 0
    local row = {}
    local rowId
    local query = nil

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --read the rowId mapping of the corresponding Device.IP.Interface.{i}.IPv6Prefix.{i}.
    --object to ipAddressTable
    rowId = instanceMap[tr69Param]
    if (rowId == nil) then
        status = ERROR 
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --get corresponding db entry from ipv6PrefixTable
    query = "_ROWID_=" .. rowId
    ipv6PrefixTableRow = db.getRowWhere ("ipv6PrefixTable", query, false)
    if(ipv6PrefixTableRow == nil) then
        status = ERROR 
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end
    
    -- configure prefix
    if(input["ipv6PrefixTable"]["ipv6PrefixTable.Prefix"] ~= nil) then
        -- cannot configure IANA prefixes
        if(ipv6PrefixTableRow["prefixType"] == "IANA") then
            status = ERROR 
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Prefix", error_code.REQUEST_DENIED)
            tr69Glue.tf1Dbg ("cannot edit AUTO or IANA prefixes..")
            return status, faultTbl
        -- configure IAPD prefix
        elseif(ipv6PrefixTableRow["prefixType"] == "IAPD") then
            -- get corresponding db entry from dhcpv6sLANPrefixPool
            query = "delegationPrefix='" .. ipv6PrefixTableRow["delegationPrefix"] .. "'"
            dhcpv6sLANPrefixPoolRow = db.getRowWhere ("dhcpv6sLANPrefixPool", query, false)
            if(dhcpv6sLANPrefixPoolRow == nil) then
                status = ERROR 
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
                return status, faultTbl;
            end
    
            -- get corresponding db entry from dhcpv6ServerPools
            query = "prefixPoolAddress='" .. ipv6PrefixTableRow["delegationPrefix"] .. "'"
            dhcpv6ServerPoolsRow = db.getRowWhere ("dhcpv6ServerPools", query, false)
            if(dhcpv6ServerPoolsRow == nil) then
                status = ERROR 
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
                return status, faultTbl;
            end

            ipv6Prefix = util.split(input["ipv6PrefixTable"]["ipv6PrefixTable.Prefix"], "/")

            dhcpv6sLANPrefixPoolRow["delegationPrefix"] = ipv6Prefix[1]
            dhcpv6sLANPrefixPoolRow["delegationPrefixLen"] = ipv6Prefix[2]
        
            dhcpv6ServerPoolsRow["prefixPoolAddress"] = ipv6Prefix[1]
            dhcpv6ServerPoolsRow["IAPDAddLength"] = ipv6Prefix[2]
            dhcpv6ServerPoolsRow["prefix"] = ipv6Prefix[1] .."/"..ipv6Prefix[2]
        
            ipv6PrefixTableRow["delegationPrefix"] = ipv6Prefix[1]
            ipv6PrefixTableRow["delegationPrefixLen"] = ipv6Prefix[2]
       
            -- update in dhcpv6sLANPrefixPool
            dhcpv6sLANPrefixPoolRow = util.addPrefix(dhcpv6sLANPrefixPoolRow, "dhcpv6sLANPrefixPool.")
            local valid, errstr = db.update("dhcpv6sLANPrefixPool", dhcpv6sLANPrefixPoolRow, dhcpv6sLANPrefixPoolRow["dhcpv6sLANPrefixPool._ROWID_"])
            if (not valid) then
                status = ERROR 
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
                return status, faultTbl
            end            
        
            -- update row in dhcpv6ServerPools
            dhcpv6ServerPoolsRow = util.addPrefix(dhcpv6ServerPoolsRow, "dhcpv6ServerPools.")
            local valid, errstr = db.update("dhcpv6ServerPools", dhcpv6ServerPoolsRow, dhcpv6ServerPoolsRow["dhcpv6ServerPools._ROWID_"])
            if (not valid) then
                status = ERROR 
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
                return status, faultTbl
            end

            -- update row in ipv6PrefixTable
            ipv6PrefixTableRow = util.addPrefix(ipv6PrefixTableRow, "ipv6PrefixTable.")
            local valid, errstr = db.update("ipv6PrefixTable", ipv6PrefixTableRow, ipv6PrefixTableRow["ipv6PrefixTable._ROWID_"])
            if (not valid) then
                status = ERROR 
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
                return status, faultTbl
            end
            os.execute("touch /tmp/restartDhcpv6s")
        -- configure radvd prefix
        elseif(ipv6PrefixTableRow["prefixType"] == "AUTO") then
            require "nimfLib"

            local prefix = ""
            local radvdPre = ""
            local radvdPrefixRow = {}

            -- get corresponding db entry from radvdLANPrefixPool
            prefix = nimfLib.prefixGet(ipv6PrefixTableRow["ipAddress"], ipv6PrefixTableRow["ipv6PrefixLen"])
        
            radvdLANPrefixPoolTbl = db.getRowsWhere("radvdLANPrefixPool", "LogicalIfName='IF2'", false)
            if(#radvdLANPrefixPoolTbl == 0) then
                status = ERROR 
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
                return status, faultTbl;
            end

            for k,v in pairs(radvdLANPrefixPoolTbl) do
                radvdPre = nimfLib.prefixGet(v["radvdAdvPrefix"], v["radvdAdvPrefixLength"])
                if(radvdPre == prefix) then
                    radvdPrefixRow[1] = v
                    break;
                end
            end

            if(#radvdPrefixRow > 0) then
                ipv6Prefix = util.split(input["ipv6PrefixTable"]["ipv6PrefixTable.Prefix"], "/")

                radvdPrefixRow[1]["radvdAdvPrefix"] = ipv6Prefix[1]
                radvdPrefixRow[1]["radvdAdvPrefixLength"] = ipv6Prefix[2]
                radvdPrefixRow[1]["NetworkName"] = "Local"
                radvdPrefixRow[1]["SLAIdentifier"] = ""
                radvdPrefixRow[1]["Base6to4Interface"] = ""
                radvdPrefixRow[1]["radvdPrefixType"] = "2"
       
                local updateRadvdRow = {}
                updateRadvdRow = radvdPrefixRow[1]

                require "teamf1lualib/gui"
                require "teamf1lualib/netipv6dhcp"

                -- update row in radvdLANPrefixPool
                errorFlag, statusCode = gui.networking.radvdPrefix.edit.set ("IF2", updateRadvdRow, dbFlag)
                if(errorFlag ~= "OK") then
                    tr69Glue.tf1Dbg("statusCode:" .. statusCode)
                    status = ERROR 
                    index = index + 1
                    if (statusCode == "RADVD_UPDATE_FAILED") then
                        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Prefix", error_code.INTERNAL_ERROR)
                    else
                        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Prefix", error_code.REQUEST_DENIED)
                    end
                    return status, faultTbl
                end
                os.execute("touch /tmp/restartRadvd")
            else
                status = ERROR 
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Prefix", error_code.REQUEST_DENIED)
                tr69Glue.tf1Dbg("Not radvd Prefix..")
                return status, faultTbl
            end
        end
    end

    db.save ()
    return status, faultTbl
end

--[[
--*****************************************************************************
-- nimfTr.dhcpOption77Get- get dhcp option 77 configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.X_RJIL_COM_DHCPOption77.
--
-- Enable
-- UserClassID
--
-- Returns: status, value
]]--
function nimfTr.dhcpOption77Get (input)
    local status = "0"
    local value = "0"
    local row = {}
    local query = nil

    --get corresponding db entry from 'DhcpcOptions'
    query = "OptionNumber=77"
    row = db.getRowWhere ("DhcpcOptions", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    if(string.find(input["param"], "Enable")) then
        -- Enable
        value = row["Enable"]
    elseif(string.find(input["param"], "UserClassID")) then
        -- UserClassID
        value = row["Value"]
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

--[[
--*****************************************************************************
-- nimfTr.dhcpOption77Get- set dhcp option 77 configuration parameters
-- 
-- This function is called to get the following parameters in
-- Device.X_RJIL_COM_DHCPOption77.
--
-- Enable
-- UserClassID
--
-- Returns: status, value
]]--
function nimfTr.dhcpOption77Set(input, rowids, actionType, tr69Param)
    local status = OK
    local faultTbl = {}
    local index = 0
    local row = {}
    local rowId
    local query = nil

    --get corresponding db entry from DhcpcOptions
    query = "OptionNumber=77"
    row = db.getRowWhere ("DhcpcOptions", query, false)
    if(row == nil) then
        status = "1"
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    dhcpOption77Row = row

    local resetFlag = 0


    if(input["DhcpcOptions"]["DhcpcOptions.UserClassID"] ~= nil) then
        dhcpOption77Row["Value"] = input["DhcpcOptions"]["DhcpcOptions.UserClassID"]
    end

    if(input["DhcpcOptions"]["DhcpcOptions.Enable"] ~= nil) then
        dhcpOption77Row["Enable"] = input["DhcpcOptions"]["DhcpcOptions.Enable"]
        if( tonumber(dhcpOption77Row["Enable"]) == 1 and (dhcpOption77Row["Value"] == nil or dhcpOption77Row["Value"] == "")) then
            tr69Glue.tf1Dbg("DhcpOption 77 Class ID is nil")
            status = "1"
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."Enable", error_code.REQUEST_DENIED)
            return status, faultTbl;
        end
        resetFlag = 1
    end

    dhcpOption77Row = util.addPrefix(dhcpOption77Row, "DhcpcOptions.")
    local valid, errstr = db.update("DhcpcOptions", dhcpOption77Row, dhcpOption77Row["DhcpcOptions._ROWID_"])
    if (not valid) then
        status = "1"
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end    

    query = "LogicalIfName='" .. dhcpOption77Row["DhcpcOptions.LogicalIfName"] .. "' AND AddressFamily=2"

    -- reset WAN connection
    if(resetFlag == 1 or dhcpOption77Row["DhcpcOptions.Enable"] == "1")  then
        tr69Glue.tf1Dbg("resetting IPv4 wan connection .. ")
        db.setAttributeWhere("NimfConf", query, "Enable", "0")
        db.setAttributeWhere("NimfConf", query, "Enable", "1")
    end
            
    db.save()

    return status, faultTbl;
end

--[[
--*****************************************************************************
-- nimfTr.VLANMembershipPortCfgGet - get Port vlan membership configuration
-- 
-- TR69 Parameter: Device.Ethernet.X_RJIL_COM_VLANMembership.0.
--
]]--
function nimfTr.VLANMembershipPortCfgGet (input)
    local status = "0"
    local value = "0"
    local param = input["param"]
    local startIdx
    local endIdx
    local rowId

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --read the rowId mapping to Device.Ethernet.X_RJIL_COM_VLANMembership.0. 
    rowId = instanceMap[param]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    local chipsetInfo = db.getAttribute("chipsetInfo", "_ROWID_", "1", "Chipset")

    if(util.fileExists("/pfrm2.0/HW_HG260ES") or util.fileExists("/pfrm2.0/DUAL_ONLY")) then
        if(rowId == "1")then
            rowId = "3"
        elseif(rowId == "3")then
            rowId = "1"
        end
    end

    if(chipsetInfo == "econet" and (not (util.fileExists("/pfrm2.0/HW_JCO4032") or util.fileExists("/pfrm2.0/HW_JCOW407") or util.fileExists("/pfrm2.0/HW_JCOW402"))) ) then
        if(rowId == "1")then
            rowId = "4"
        elseif(rowId == "2")then
            rowId = "3"
        end
    end

    --get the db entry from vlanEncapIf 
    local vlanEncapTbl = db.getTable("vlanEncapIf", false)
    
    if(string.find(input["param"], "PortEnable")) then
        -- PortEnable
        value = "0"
        for k,v in pairs (vlanEncapTbl) do
            if(string.find(v["fwdMap"], rowId)) then
                value = "1"
                break;
            end
        end
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    
    return status, value
end

--[[
--*****************************************************************************
-- nimfTr.sortConcatTbl - sort and concatinate the table in CSV format
-- 
-- returns CSV format string
--
]]--
function nimfTr.sortConcatTbl(val)
    local tbl = {}
    local str = ""

    tbl = util.split(val, ",")
    table.sort(tbl)
    str = table.concat(tbl, ",")

    return str
end

--[[
--*****************************************************************************
-- nimfTr.VLANMembershipPortCfgSet - port vlan membership configuration
-- 
-- TR69 Parameter: Device.Ethernet.X_RJIL_COM_VLANMembership.0.
--
]]--
function nimfTr.VLANMembershipPortCfgSet (input, rowids, actionType, tr69Param)
    tr69Glue.tf1Dbg("Entering VLANMembershipPortCfgSet..")
    
    require "teamf1lualib/swVlan"

    local index = 0
    local status = OK
    local rowId = nil
    local faultTbl = {}
    local LogicalIfName = "IF2"
    local networkName = "LAN"
    local vlanIndex = 0
    local WIFIPORT = "7,8,9"
    local WANPORT = "5"
    local gponRow = {}
   
    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    --read the rowId mapping to Device.Ethernet.X_RJIL_COM_VLANMembership.0. 
    rowId = instanceMap[tr69Param]
    if (rowId == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    local chipset = db.getAttribute("chipsetInfo", "_ROWID_", "1", "Chipset")

    if(util.fileExists("/pfrm2.0/HW_HG260ES") or util.fileExists("/pfrm2.0/DUAL_ONLY")) then
        if(rowId == "1")then
            rowId = "3"
        elseif(rowId == "3")then
            rowId = "1"
        end
    end
   
    if(chipset == "econet" and (not ( util.fileExists("/pfrm2.0/HW_JCO4032") or util.fileExists("/pfrm2.0/HW_JCOW407") or util.fileExists("/pfrm2.0/HW_JCOW402") ))) then
        if(rowId == "1")then
            rowId = "4"
        elseif(rowId == "2")then
            rowId = "3"
        end
    end

    if (util.fileExists ("/pfrm2.0/HW_FOXCONN_JCO500") or util.fileExists ("/pfrm2.0/HW_FOXCONN") or util.fileExists ("/pfrm2.0/HW_JCO110") or util.fileExists ("/pfrm2.0/HW_HG260ES") or util.fileExists ("/pfrm2.0/HW_FIBERHOME_JCO300") or util.fileExists ("/pfrm2.0/HW_JCO410") or util.fileExists ("/pfrm2.0/HW_JCE410") or util.fileExists ("/pfrm2.0/DUAL_ONLY") or  util.fileExists ("/pfrm2.0/ETHERNET_ONLY")) then
        vlanIndex = 3
    else
        vlanIndex = 4
    end
    
    if (util.fileExists ("/pfrm2.0/HW_HG261GU") or chipset == "econet") then
        vlanIndex = 2
    end

    local bridgeRow = db.getRow ("bridgeMode", "_ROWID_", "1")
    for i = 1,vlanIndex do
        if(input["vlanMembershipPort"]["vlanMembershipPort.PortEnable"] == "1" and bridgeRow["bridgeMode.status"] == "1" and (tonumber(bridgeRow["bridgeMode.portNumber"]) == tonumber(rowId))) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."PortEnable", error_code.REQUEST_DENIED)
            tr69Glue.tf1Dbg("Selected Port is configured in Bridge Mode")
            return status, faultTbl;
        end
    end

    if(chipset == "Lantiq") then
        gponRow = db.getRow ("gpon", "_ROWID_", "1")
        if (gponRow == nil) then
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
            return status, faultTbl;
        end
    end

    --get the db entry from vlanEncapIf 
    local vlanRows = db.getRows ("vlanEncapIf", "LogicalIfName", LogicalIfName)

    for k,v in pairs (vlanRows) do
        if(chipset == "Lantiq") then
            if(v["vlanEncapIf.vlanId"] == "1")then
                v["vlanEncapIf.fwdMap"] = string.gsub(v["vlanEncapIf.fwdMap"], ","..WIFIPORT, "") 
                v["vlanEncapIf.untagMap"] = string.gsub(v["vlanEncapIf.untagMap"], ","..WIFIPORT, "") 
            end
        end

        --set fwdMap
        if(input["vlanMembershipPort"]["vlanMembershipPort.PortEnable"] == "1") then 
            v["vlanEncapIf.fwdMap"] = v["vlanEncapIf.fwdMap"] .. "," .. rowId 
        else
            if(string.find(v["vlanEncapIf.fwdMap"], ",")) then
                if((rowId == "1") or ((chipset == "econet") and (tonumber(rowId) == 3))) then
                    v["vlanEncapIf.fwdMap"] = string.gsub(v["vlanEncapIf.fwdMap"], rowId..",", "") 
                else
                    v["vlanEncapIf.fwdMap"] = string.gsub(v["vlanEncapIf.fwdMap"], ","..rowId, "") 
                end
            else
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."PortEnable", error_code.REQUEST_DENIED)
                tr69Glue.tf1Dbg("Disabling all ports will result in connection loss with device. Please enable at least one port.")
                return status, faultTbl;
            end
        end

        --set untagMap
        if(input["vlanMembershipPort"]["vlanMembershipPort.PortEnable"] == "1") then 
            if(v["vlanEncapIf.vlanId"] == "1")then
                if(string.len(v["vlanEncapIf.untagMap"]) == 0) then
                    v["vlanEncapIf.untagMap"] = rowId 
                else
                    v["vlanEncapIf.untagMap"] = v["vlanEncapIf.untagMap"] .. "," .. rowId
                end 
            end
        else
            if(string.find(v["vlanEncapIf.untagMap"], rowId))then
                if((rowId == "1") or ((chipset == "econet") and (tonumber(rowId) == 3))) then
                    v["vlanEncapIf.untagMap"] = string.gsub(v["vlanEncapIf.untagMap"], rowId..",", "") 
                else
                    if(string.find(v["vlanEncapIf.untagMap"], ",")) then
                        v["vlanEncapIf.untagMap"] = string.gsub(v["vlanEncapIf.untagMap"], ","..rowId, "") 
                    else
                        v["vlanEncapIf.untagMap"] = string.gsub(v["vlanEncapIf.untagMap"], rowId, "") 
                    end
                end
            end
        end
        
        v["vlanEncapIf.fwdMap"] = nimfTr.sortConcatTbl(v["vlanEncapIf.fwdMap"]) 
        v["vlanEncapIf.untagMap"] = nimfTr.sortConcatTbl(v["vlanEncapIf.untagMap"]) 

        if(chipset == "Lantiq") then
            if(v["vlanEncapIf.vlanId"] == "1")then
                v["vlanEncapIf.fwdMap"] = v["vlanEncapIf.fwdMap"]..","..WIFIPORT
                v["vlanEncapIf.untagMap"] = v["vlanEncapIf.untagMap"]..","..WIFIPORT
            end

            if(gponRow["gpon.status"] == "1" and gponRow["gpon.vlanID"] == v["vlanEncapIf.vlanId"]) then
                v["vlanEncapIf.fwdMap"] = v["vlanEncapIf.fwdMap"]..","..WANPORT
            end
        end

        if (chipset == "econet") then
            if (v["vlanEncapIf.fwdMap"] == nil or v["vlanEncapIf.fwdMap"] == "") then
			    fwdMap = "NO"
		    else
			    fwdMap = v["vlanEncapIf.fwdMap"]
		    end
        end

        tr69Glue.tf1Dbg("vlanEncapIf v = " .. util.tableToStringRec(v))
        
        errorFlag, statusCode = swMgr.dbConfig ("vlanEncapIf", v, v["vlanEncapIf._ROWID_"], "edit")

        if(chipset == "Broadcom" or chipset == "Lantiq") then
            local cmd = "/pfrm2.0/bin/vlanUpdate.sh DEL " .. v["vlanEncapIf.vlanId"] .. " > /dev/null 2>&1"
            os.execute(cmd)

            local cmd = "/pfrm2.0/bin/vlanUpdate.sh ADD " .. v["vlanEncapIf.vlanId"] .. " " .. v["vlanEncapIf.fwdMap"] .. " " .. v["vlanEncapIf.untagMap"] .. " > /dev/null 2>&1"
            os.execute(cmd)
        end

        if (chipset == "econet") then
		    local cmd="/pfrm2.0/bin/vlanUpdate.sh DEL " .. v["vlanEncapIf.vlanId"] .. " > /dev/null 2>&1"
		    os.execute(cmd)
		    local cmd="/pfrm2.0/bin/vlanUpdate.sh ADD " .. v["vlanEncapIf.vlanId"] .. " " .. fwdMap .. " " ..v["vlanEncapIf.inSwitchOnly"] .. " " .. v["vlanEncapIf.untagMap"] .. " > /dev/null 2>&1"
		    os.execute(cmd)
        end
    end

    if (errorFlag == "OK") then
        db.save2()
        if(chipset == "Broadcom") then
            swMgr.l2_vlan_rules_update (1)
        elseif(chipset == "econet") then
		    swMgr.l2_vlan_rules_update_ECONET (1)
        end
    end

    tr69Glue.tf1Dbg("Leaving VLANMembershipPortCfgSet..")
    return status, faultTbl;
end

function nimfTr.pktCaptureGet (input)
    local status = "0"
    local value = "0"
    local param = input["param"]
    local startIdx
    local endIdx
    local rowId
    local tcpdumpStatus

    --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    --read the rowId mapping to tcpdump
    rowId = instanceMap[param]
    if (rowId == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    require "teamf1lualib/gui"
    errorFlag, statuMessage, configRow, networkRow = gui.networking.packetTrace.get()

    if(string.find(input["param"], "Enable")) then
        if (configRow["networkName"] ~= nil) then 
            value = 1
        else
            value = 0
        end
    elseif (string.find(input["param"], "Interface")) then
        if (configRow["networkName"] ~= nil) then
            if (configRow["networkName"] == "Local") then 
                value = "LAN"
            end
            if (configRow["networkName"] == "Internet") then 
                value = "WAN"
            end
        else
            value = ""
        end 
    elseif (string.find(input["param"], "UploadURL")) then
        value = ""
    elseif (string.find(input["param"], "UploadUsername")) then
        value = ""
    elseif (string.find(input["param"], "UploadPassword")) then
        value = ""
    elseif (string.find(input["param"], "UploadResult")) then
        tcpdumpStatus = db.getAttribute ("tcpdumpUpload", "_ROWID_", "1", "Status")
        if (tcpdumpStatus ~= nil) then
            value = tcpdumpStatus
        else
            value = ""
        end
    else
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    
    return status, value
end

function nimfTr.pktCaptureSet (input, rowids, actionType, tr69Param)

    require "teamf1lualib/networking"
    local status = OK 
    local row = {}
    local rowId
    local query = nil
    local pktCaptureTbl = {}
    local nwRow = {}
    local faultTbl = {}
    local index = 0
    local uploadCmd
    local Url
    local UserName
    local Password

       --load instanceMap
    local instanceMap = tr69Glue.instanceMapLoad()
    if (instanceMap == nil) then
        status = ERROR 
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end


    if (input["tcpdump"]["tcpdump.tcpdumpEnabled"] ~= nil) then
        pktCaptureTbl["tcpdumpEnabled"] = input["tcpdump"]["tcpdump.tcpdumpEnabled"]
        if (tonumber(pktCaptureTbl["tcpdumpEnabled"]) == 0) then
            errorFlag, statuMessage, configRow, networkRow = gui.networking.packetTrace.get()
            if (configRow["networkName"] ~= nil) then
                pktCaptureTbl["networkName"] = configRow["networkName"]
            end
        end
        if (tonumber(pktCaptureTbl["tcpdumpEnabled"]) == 1) then
            UserName = input["tcpdump"]["tcpdump.UploadUsername"]
            Password = input["tcpdump"]["tcpdump.UploadPassword"]
            Url = input["tcpdump"]["tcpdump.UploadURLVal"]
            if (UserName ~= nil) then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."UploadUsername", error_code.REQUEST_DENIED)
                return status, faultTbl;
            end
            if (Password ~= nil) then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."UploadPassword", error_code.REQUEST_DENIED)
                return status, faultTbl;
            end
            if (Url ~= nil) then
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."UploadURLVal", error_code.REQUEST_DENIED)
                return status, faultTbl;
            end
            if (input["tcpdump"]["tcpdump.interfaceName"] ~= nil) then
                if (input["tcpdump"]["tcpdump.interfaceName"] == "LAN") then
                    pktCaptureTbl["networkName"] = "Local"
                    os.execute("/bin/touch /tmp/pktCapAcs")
                elseif (input["tcpdump"]["tcpdump.interfaceName"] == "WAN") then
                    pktCaptureTbl["networkName"] = "Internet"
                    os.execute("/bin/touch /tmp/pktCapAcs")
                else
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."interfaceName", error_code.INVALID_PARAM_VALUE)
                    return status, faultTbl;
                end
            else
                    status = ERROR
                    index = index + 1
                    faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."interfaceName", error_code.INVALID_PARAM_VALUE)
                    return status, faultTbl;
            end
        end
    else
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."tcpdumpEnabled", error_code.INVALID_PARAM_VALUE)
        return status, faultTbl;
    end
    
    errorFlag, statusMessage = gui.networking.packetTrace.set(pktCaptureTbl)

    if (errorFlag == "OK") then
        if (tonumber(input["tcpdump"]["tcpdump.tcpdumpEnabled"]) == 0) then
            if (util.fileExists("/var/pkt-acs.cap")) then
                    local timeValSec = os.date("%S")
                    local timeValMin = os.date("%M")
                    local timeValHour = os.date("%H")
                    local timeValDay = os.date("%d")
                    local timeValMonth = os.date("%m")
                    local timeValYear = os.date("%Y")
                    local timeVal = timeValYear .. timeValMonth .. timeValDay .. timeValHour .. timeValMin .. timeValSec
                    os.execute("/bin/cp /var/pkt-acs.cap /var/" ..  timeVal .. "-pkt.cap")
                    Url = input["tcpdump"]["tcpdump.UploadURLVal"]
                    if (Url == nil) then
                        status = ERROR
                        index = index + 1
                        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."UploadURLVal", error_code.INVALID_PARAM_VALUE)
                        return status, faultTbl;
                    end
                    UserName = input["tcpdump"]["tcpdump.UploadUsername"]
                    Password = input["tcpdump"]["tcpdump.UploadPassword"]
                    if (UserName ~= nil and Password ~= nil) then
                        uploadCmd = "/pfrm2.0/bin/curl --upload-file /var/" .. timeVal .. "-pkt.cap --user " .. UserName .. ":" .. Password .. " -ik " .. Url
                    else
                        uploadCmd = "/pfrm2.0/bin/curl --upload-file /var/" .. timeVal .. "-pkt.cap --user anonymous:guest -ik " .. Url
                    end
                    local transferStatus  = -1
                    transferStatus = os.execute(uploadCmd)
                    if(transferStatus ~= 0) then
                       db.setAttribute("tcpdumpUpload", "_ROWID_", "1", "Status", "Upload Failed")
                    else
                       db.setAttribute("tcpdumpUpload", "_ROWID_", "1", "Status", "Upload Succeed")
                    end
                    os.execute("/bin/rm /var/" ..  timeVal .. "-pkt.cap")
                    os.execute("/bin/rm /var/pkt-acs.cap")
                    os.execute("/bin/rm /tmp/pktCapAcs")
            end
        elseif (tonumber(input["tcpdump"]["tcpdump.tcpdumpEnabled"]) == 1) then
                       db.setAttribute("tcpdumpUpload", "_ROWID_", "1", "Status", " ")
        end
    else
                if (input["tcpdump"]["tcpdump.interfaceName"] ~= nil) then
                    os.execute("/bin/rm /tmp/pktCapAcs")
                end
                status = ERROR
                index = index + 1
                faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."tcpdumpEnabled", error_code.INTERNAL_ERROR)
                return status, faultTbl;
    end

    -- upoad file
    -- if pass -- no need to set result
    --
    return 0
end

function nimfTr.voipCfgSet (input, rowids, actionType, tr69Param)
    local status = OK
    local faultTbl = {}
    local index = 0
    local row = {}
  
    -- get corresponding db entry from 'voipSetting'
    row = db.getRowWhere ("voipSetting","_ROWID_=1",false)
    if (row == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    if (input["voipSetting"]["voipSetting.VoIPValues"] ~= nil) then    
        local t = util.split(input["voipSetting"]["voipSetting.VoIPValues"], ",")        
        for i,v in pairs(t) do
            local t1 = util.split(v, ":")
            row[t1[1]]=t1[2]
        end
    end
    
    if (input["voipSetting"]["voipSetting.WatchDogEnable"] ~= nil) then    
        row["WatchDogEnable"] = tonumber(input["voipSetting"]["voipSetting.WatchDogEnable"])
        if (row["WatchDogEnable"] == 1) then
            os.execute("tcwdog -t 1 /dev/watchdog &");
        else
            os.execute("killall -9 tcwdog");
        end
    end
    
    if (input["voipSetting"]["voipSetting.LogLevel"] ~= nil) then    
        -- write the logic
        row["LogLevel"] = tonumber(input["voipSetting"]["voipSetting.LogLevel"])
        if (row["LogLevel"] >= 1 and row["LogLevel"] <= 8) then
            os.execute("echo " ..row["LogLevel"].. " > /proc/sys/kernel/printk")
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."LogLevel", error_code.INVALID_PARAM_VALUE)
        end
    end

    if (input["voipSetting"]["voipSetting.WirelessLogs"] ~= nil) then    
        -- write the logic
        row["WirelessLogs"] = tonumber(input["voipSetting"]["voipSetting.WirelessLogs"])
        if (row["WirelessLogs"] >= 0 and row["WirelessLogs"] <= 5) then
            local dot11InterfaceTbl = db.getTable("dot11Interface", "false")
            for i, j in pairs(dot11InterfaceTbl) do
	        local phyIfName = j["dot11Interface.interfaceName"]
	        os.execute("iwpriv " .. phyIfName.. " set Debug=" .. row["WirelessLogs"])
            end
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."WirelessLogs", error_code.INVALID_PARAM_VALUE)
        end
    end

    if (input["voipSetting"]["voipSetting.VoipVdspLogs"] ~= nil) then
         row["VoipVdspLogs"] = tonumber(input["voipSetting"]["voipSetting.VoipVdspLogs"])
         if (row["VoipVdspLogs"] == 0) then
             os.execute("echo vdsp off > /proc/vdsp/debug/log")
         elseif (row["VoipVdspLogs"] == 1) then
             os.execute("echo vdsp on 0xf 0x80 > /proc/vdsp/debug/log")
         else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."VoipVdspLogs", error_code.INVALID_PARAM_VALUE)
         end
    end
    
    if (input["voipSetting"]["voipSetting.VoipFxsLogs"] ~= nil) then
         row["VoipFxsLogs"] = tonumber(input["voipSetting"]["voipSetting.VoipFxsLogs"])
         if (row["VoipFxsLogs"] == 0) then
             os.execute("echo 0x0 0x0 > /proc/fxs/dbg")
         elseif (row["VoipFxsLogs"] == 1) then
             os.execute("echo 0xf 0x32 > /proc/fxs/dbg")
         else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."VoipFxsLogs", error_code.INVALID_PARAM_VALUE)
         end
    end
    
    if (input["voipSetting"]["voipSetting.VoipLecLogs"] ~= nil) then
         row["VoipLecLogs"] = tonumber(input["voipSetting"]["voipSetting.VoipLecLogs"])
         if (row["VoipLecLogs"] ==  0) then
             os.execute("echo 1 > /proc/lec/logdbg")
         elseif (row["VoipLecLogs"] ==  1) then
             os.execute("echo 4 > /proc/lec/logdbg")
         else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."VoipLecLogs", error_code.INVALID_PARAM_VALUE)
         end
    end
    
    if (input["voipSetting"]["voipSetting.VoipAdamGdiLogs"] ~= nil) then
         row["VoipAdamGdiLogs"] = tonumber(input["voipSetting"]["voipSetting.VoipAdamGdiLogs"])
         if (row["VoipAdamGdiLogs"] ==  0) then 
             os.execute("echo adam logtype 0  > /proc/vdsp/debug/log")
             os.execute("echo adam on 0x3 > /proc/vdsp/debug/log")
             os.execute("echo gdi on 0x3 > /proc/vdsp/debug/log")
         elseif (row["VoipAdamGdiLogs"] ==  1) then
             os.execute("echo adam logtype 1 > /proc/vdsp/debug/log")
             os.execute("echo adam on 0xf > /proc/vdsp/debug/log")
             os.execute("echo gdi on 0xf > /proc/vdsp/debug/log")
         else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."VoipAdamGdiLogs", error_code.INVALID_PARAM_VALUE)
         end
    end
    
    row = util.addPrefix (row,"voipSetting.")
    local valid, errstr = db.update("voipSetting", row, "1")
    if (not valid) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
       return status, faultTbl;
    end

    -- saving DB
    db.save()

    return status, faultTbl;
end    

function nimfTr.voipCfgGet (input)
    local status = "0"
    local value = ""
    local row = {}
    local query = nil
    local param = input["param"]

    --get corresponding db entry from 'gpon'
    query = "_ROWID_=1"
    row = db.getRowWhere ("voipSetting", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    row=util.removePrefix(row,"voipSetting.")
    
    if(string.find(input["param"], "VoIPValues")) then
        for i,v in pairs(row)  do
            if(i~="_ROWID_") then
                if(string.find(value,":") )then
                    value=value..","
                end
                value=value..i..":"..v
                if(i == "DialingTimeout") then
                    os.execute("echo " ..v.. " > /tmp/voipdialingTimeOut.config")
                end
            end
        end
        tr69Glue.tf1Dbg(" nimfTr.voipCfgGet debug value=" ..value)
    elseif(string.find(input["param"], "WatchDog")) then
        value = row["WatchDogEnable"]
        tr69Glue.tf1Dbg(" nimfTr.voipCfgGet WatchDog value=" ..value)
    elseif(string.find(input["param"], "LogLevel")) then
        value = row["LogLevel"]
        tr69Glue.tf1Dbg(" nimfTr.voipCfgGet LogLevel value=" ..value)
    elseif(string.find(input["param"], "WirelessLogs")) then
        value = row["WirelessLogs"]
        tr69Glue.tf1Dbg(" nimfTr.voipCfgGet WirelessLogs value=" ..value)
    elseif(string.find(input["param"], "VoipVdspLogs")) then
        value = row["VoipVdspLogs"]
        tr69Glue.tf1Dbg(" nimfTr.voipCfgGet VoipVdspLogs value=" ..value)
    elseif(string.find(input["param"], "VoipFxsLogs")) then
        value = row["VoipFxsLogs"]
        tr69Glue.tf1Dbg(" nimfTr.voipCfgGet VoipFxsLogs value=" ..value)
    elseif(string.find(input["param"], "VoipLecLogs")) then
        value = row["VoipLecLogs"]
        tr69Glue.tf1Dbg(" nimfTr.voipCfgGet VoipLecLogs value=" ..value)
    elseif(string.find(input["param"], "VoipAdamGdiLogs")) then
        value = row["VoipAdamGdiLogs"]
        tr69Glue.tf1Dbg(" nimfTr.voipCfgGet VoipAdamGdiLogs value=" ..value)
    else
         return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

function nimfTr.miscCfgSet (input, rowids, actionType, tr69Param)
    local status = OK
    local faultTbl = {}
    local index = 0
    local row = {}
    local reboot = "0"
  
    -- get corresponding db entry from 'miscSetting'
    row = db.getRowWhere ("miscSetting","_ROWID_=1",false)
    if (row == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    if (input["miscSetting"]["miscSetting.LogLevel"] ~= nil) then    
        -- write the logic
        row["LogLevel"] = tonumber(input["miscSetting"]["miscSetting.LogLevel"])
        if (row["LogLevel"] >= 1 and row["LogLevel"] <= 8) then
            os.execute("echo " ..row["LogLevel"].. " > /proc/sys/kernel/printk")
        else
            status = ERROR
            index = index + 1
            faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param.."LogLevel", error_code.INVALID_PARAM_VALUE)
        end
    end

    if (input["miscSetting"]["miscSetting.WatchDogEnable"] ~= nil) then    
        row["WatchDogEnable"] = tonumber(input["miscSetting"]["miscSetting.WatchDogEnable"])
        if (row["WatchDogEnable"] == 1) then
            if( (util.fileExists("/pfrm2.0/HW_JCOW401")) or (util.fileExists("/pfrm2.0/HW_JCOW403")) ) then
                os.execute("wdtctl -d -t 30 start");
            end
        else
            if( (util.fileExists("/pfrm2.0/HW_JCOW401")) or (util.fileExists("/pfrm2.0/HW_JCOW403")) ) then
                os.execute("killall wdtd");
                reboot = "1"
            end
        end
    end
    
    row = util.addPrefix (row,"miscSetting.")
    local valid, errstr = db.update("miscSetting", row, "1")
    if (not valid) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
       return status, faultTbl;
    end

    -- saving DB
    db.save2()

    if(reboot == "1") then
        tr69Glue.reboot(10);
    end

    return status, faultTbl;
end    

function nimfTr.miscCfgGet (input)
    local status = "0"
    local value = ""
    local row = {}
    local query = nil
    local param = input["param"]

    --get corresponding db entry from 'gpon'
    query = "_ROWID_=1"
    row = db.getRowWhere ("miscSetting", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end
    row=util.removePrefix(row,"miscSetting.")
    if(string.find(input["param"], "LogLevel")) then
        value = row["LogLevel"]
    elseif(string.find(input["param"], "WatchDog")) then
        value = row["WatchDogEnable"]
    else
         return "1", "DB_ERROR_TRY_AGAIN"
    end

    return status, value
end

function nimfTr.allotCfgSet (input, rowids, actionType, tr69Param)
    local status = OK
    local faultTbl = {}
    local index = 0
    local row = {}

    -- get corresponding db entry from 'Allot'
    row = db.getRowWhere ("Allot","_ROWID_=1",false)
    if (row == nil) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
        return status, faultTbl;
    end

    if (input["Allot"]["Allot.Enable"] ~= nil) then
        row["Enable"] = input["Allot"]["Allot.Enable"]
        if( row["Enable"] == "1") then
            os.execute("/pfrm2.0/etc/cyberInit > /dev/null")
	    os.execute("touch /tmp/AllotEnable")
        elseif( row["Enable"] == "0") then
	    os.execute("ps  | grep cyberiot_bkg_init.sh |grep -v grep| awk '{print $1}' | xargs kill -9")
        os.execute("ps  | grep nget2 |grep -v grep| awk '{print $1}' | xargs kill -9")
            os.execute("rm -rf /tmp/AllotEnable")
        end
    end

    row = util.addPrefix (row,"Allot.")
    local valid, errstr = db.update("Allot", row, "1")
    if (not valid) then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)
       return status, faultTbl;
    end

    -- saving DB
    db.save()

    return status, faultTbl;
end

function nimfTr.allotCfgGet (input)
    local status = "0"
    local value = ""
    local row = {}
    local query = nil
    local param = input["param"]

    --get corresponding db entry from 'Allot'
    query = "_ROWID_=1"
    row = db.getRowWhere ("Allot", query, false)
    if(row == nil) then
        return "1", "DB_ERROR_TRY_AGAIN"
    end

    if(string.find(input["param"], "Allot")) then
        value = row ["Enable"]
    end

    return status, value
end

