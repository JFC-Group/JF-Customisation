-- @copyright Copyright (c) 2012, TeamF1, Inc. 

require "teamf1lualib/evtDsptch"
require "radvdLib"
require "appExtn/AppExtn"

RadvdExtn = OoUtil.inheritsFrom(AppExtn)
RadvdExtn.name    = "Router Advertisement Daemon"
RadvdExtn.className  = "RadvdExtn"
RadvdExtn.classId = "radvd"
RadvdExtn.dbTable = ""
RadvdExtn.logger  = nil

local SUPER = require("appExtn.AppExtn")

local netEvents  = {}
netEvents[evtDsptch.event.IFDEV_EVENT_IP6_NET_UP] =  1
netEvents[evtDsptch.event.IFDEV_EVENT_IP6_NET_DOWN] =  1

local cfgEvents = {}
cfgEvents[db.event.SQLITE_INSERT] = 1
cfgEvents[db.event.SQLITE_UPDATE] = 1
cfgEvents[db.event.SQLITE_DELETE] = 1

-------------------------------------------------------------------------------
-- @name RadvdExtn:new
--
-- @description This function creates a new instance object for radvd, loads
-- the configuration and event subcriptions
--
-- @return  0 for success and -1 for error
--

function RadvdExtn:new(instanceId, props)

    assert(instanceId, "Instance ID must be specified")

    -- create a new instance
    self = RadvdExtn.create()

    SUPER.new(self, RadvdExtn.classId, instanceId, props)

    self.name  = RadvdExtn.name
    self.dbTable = RadvdExtn.dbTable
    self.dbconn = RadvdExtn.dbconn
    self.logger = RadvdExtn.logger

    -- initialize events for this instance
    self.netEvents = netEvents              
    self.cfgEvents = cfgEvents

    -- load the configuration for this instance          
    local status, errCode, self = self:load()
    if (status == nil) then
        LOG:error("failed to load " .. classId .. 
                  "(" .. instanceId .. ")")
        return nil
    end        

    local handle = db.gethandle(self.dbconn)
    radvdLib.init(handle)

    -- register with appd
    appd.appExtnRegister(self)                    

    return self
end

-------------------------------------------------------------------------------
-- @name RadvdExtn:load
--
-- @description This function loads the radvd configuration
--
-- @return  
--

function RadvdExtn:load() 

    self.ifTbl = {}
    self.prefixTbl = {}

    -- load all interfaces
    local ifTbl = db.getTable("radvd", false)
    if (ifTbl ~= nil) then
        self.ifTbl = ifTbl
    end        

    -- load all prefixes
    local prefixTbl = db.getTable("radvdLANPrefixPool", false)
    if (prefixTbl ~= nil) then
        self.prefixTbl = prefixTbl
    end        

    return  "OK", "STATUS_OK", self
end        

-------------------------------------------------------------------------------
-- @name RadvdExtn:delete
--
-- @description This function destroys an instance of this extension
--
-- @return  
--

function RadvdExtn:delete() 
    appd.appExtnUnregister(self)
    return 
end        

-------------------------------------------------------------------------------
-- @name RadvdExtn:isRadvdNetworkUp check if ipv6 network is UP 
--
-- @description This function checks if ipv6 network is UP on any of the 
-- radvd enabled interfaces.
--
-- @return  true or false
--

function RadvdExtn:isRadvdNetworkUp()
    require "teamf1lualib/nimfConn"
    local status = "ERROR"
    local errCode = ""
    local objList = {}

    objList = self.ifTbl
    if ((objList == nil) or (#objList == 0)) then
        return false
    end        

    for k,v in pairs(objList) do
        if (nimfConn.isIPv6Up(v.LogicalIfName) == true) then
            return true
        end        
    end        

    return false
end

-------------------------------------------------------------------------------
-- @name RadvdExtn:isRadvdEnabled
--
-- @description This function checks if radvd is enabled on this network
--
-- @param  LogicalIfName
--
-- @return  true or false
--

function RadvdExtn:isRadvdEnabled(LogicalIfName)
    local status = "ERROR"
    local errCode = ""
    local objList = {}

    objList = self.ifTbl
    if ((objList == nil) or (#objList == 0)) then
        return false
    end        

    for k,v in pairs(objList) do
        if ((strlib.strcasecmp(v.LogicalIfName, LogicalIfName) == 0) and
            (tonumber(v.isEnabled) > 0)) then
            return true            
        end            
    end        
    
    return false
end

-------------------------------------------------------------------------------
-- @name RadvdExtn:start
--
-- @description This function starts radvd
--
-- @return  0 for success and -1 for error
--

function RadvdExtn:start ()
    require "teamf1lualib/nimf"

    -- check if ipv6 network is UP
    if (self:isRadvdNetworkUp() == false) then
        radvdLib.stop();
        return -1
    end        

    LOG:info("Starting " .. self.name)

    local status = radvdLib.start()
    if (status < 0) then
        LOG:error(self.name .. " start failed")
        return status
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name RadvdExtn:restart
--
-- @description This function restarts radvd
--
-- @return  0 for success and -1 for error
--

function RadvdExtn:restart ()

    -- Changes for ipv6 internet optimization while radvd is on, Removing
    -- check to check for IPv6 LAN network UP, as LAN will never get down
    -- after device boots up

    -- check if ipv6 network is UP
    --if (self:isRadvdNetworkUp() == false) then
    --    radvdLib.stop();
    --    return -1;
    --end        

    LOG:info("Re-starting " .. self.name)
    local status = radvdLib.restart()
    if (status < 0) then
        LOG:error(self.name .. " restart failed")
        return status
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name RadvdExtn:getAppName
--
-- @description This function gets the name of this extension
--
-- @return  
--

function RadvdExtn:getAppName()
   return self.name
end

-------------------------------------------------------------------------------
-- @name RadvdExtn:getDbTableName
--
-- @description This function gets the database table name which contains
-- configuration records for all instances of this application.
--
-- @return  
--

function RadvdExtn:getDbTableName()
   return self.dbTable
end

-------------------------------------------------------------------------------
-- @name RadvdExtn:onNetEvent
--
-- @description This function handles network events for radvd
--
-- @param  netevent event info
--
-- @return  0 for success and -1 for error
--

function RadvdExtn:onNetEvent(netevent)

    if (self:isEventSubscribed(netevent) == false) then
        LOG:ddebug(self.name .. " not subscribed to event: " ..
                  netevent.event .. " on " .. netevent.ifname)
        return 0
    end        

--    self:restart()

    return 0
end

-------------------------------------------------------------------------------
-- @name RadvdExtn:isEventSubscribed
--
-- @description This function checks if this instance is subcribed to
-- the event pass as input
--
-- @param event event info
--
-- @return  0 for success and -1 for error
--

function RadvdExtn:isEventSubscribed(event)

    if (event.type == appd.eventType.APPD_EV_NET) then
        require "teamf1lualib/network"
        
        -- if it is not LAN, then skip 
        if (not network.isLAN(event.ifname)) then
            return false
        end

        -- check if radvd is configured on this network
        if (self:isRadvdEnabled(event.ifname) == false) then
            return false
        end            

        local evstate = self.netEvents[event.event]
        if (evstate == nil) then
            return false
        end            
                    
        if (evstate > 0) then
            return true
        end        

    elseif (event.type == appd.eventType.APPD_EV_CFG) then

        -- are we subscribed to this event                        
        local evstate = self.cfgEvents[event.event]
        if (evstate == nil) then
            return false
        end            

        if (evstate > 0) then
            return true
        end        
    end

    return false
end

-------------------------------------------------------------------------------
-- @name RadvdExtn:onCfgEvent
--
-- @description This function is called by appd to handle configuration events
-- 
-- @param  cfgevent event information
--
-- @return  
--

function RadvdExtn:onCfgEvent(cfgevent)

    if (self:isEventSubscribed(cfgevent) == false) then
        LOG:ddebug(self.name .. " not subscribed to event: " ..
                   cfgevent.event .. " on " .. cfgevent.dbTable)
        return
    end        

    -- restart radvd
    self:restart()

    return
end

-------------------------------------------------------------------------------
-- @name RadvdExtn:print
--
-- @description This function is called by appd to bootstrap all instances of 
-- this application. 
--
-- @param  
--
-- @return  
--

function RadvdExtn:print()
    require "util/strlib"

    LOG:info("Class     : " .. self.classId)
    LOG:info("Instance  : " .. self.instanceId)
    LOG:info("App Name  : " .. self:getAppName())
    LOG:info("Conf      : " .. strlib.serializeTbl(self:getProps()))
    return
end

-------------------------------------------------------------------------------
-- @name RadvdExtn.cfgEventCallback
--
-- @description This function is called by appd whenever there is a configuration
-- event.
--
-- @param  
--
-- @return  
--

function RadvdExtn.cfgEventCallback(obj, info)
    local status
    local errCode

    LOG:debug(RadvdExtn.classId .. " configuration callback called  " .. 
              "for event: " ..  info.event .. " on rowId " .. info.rowId)

    local obj = appd.appExtnFind(RadvdExtn.classId, "1")
    if (obj) then 
        status, errCode, obj = obj:load()
        if (status == "OK") then
            obj:onCfgEvent(info) 
        end
    end

    return 0
end

-------------------------------------------------------------------------------
-- @name RadvdExtn.bootstrap
--
-- @description This function is called by appd on startup to bootstrap all 
-- instances of this application. 
--
-- @param  
--
-- @return  
--

function RadvdExtn.bootstrap()
    local callbackTable= {}

    local callback = {}
    callback.type = appd.eventType.APPD_EV_CFG
    callback.dbTable = "radvd"
    callback.routine = RadvdExtn.cfgEventCallback
    table.insert(callbackTable, callback)

    local callback = {}
    callback.type = appd.eventType.APPD_EV_CFG
    callback.dbTable = "radvdLANPrefixPool"
    callback.routine = RadvdExtn.cfgEventCallback
    table.insert(callbackTable, callback)

    appd.callbackRegister (RadvdExtn.classId, callbackTable)

    -- create an instance 
    local instanceId = "1"
    local obj = RadvdExtn:new(instanceId)
    if (obj) then
        obj:start()
    end                        

    return 0
end

return RadvdExtn
