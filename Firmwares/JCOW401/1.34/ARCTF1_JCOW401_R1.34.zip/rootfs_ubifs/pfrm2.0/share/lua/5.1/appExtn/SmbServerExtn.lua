-- @copyright Copyright (c) 2012, TeamF1, Inc. 

require "teamf1lualib/evtDsptch"
require "appExtn/AppExtn"
require "smbLib"

SmbServerExtn = OoUtil.inheritsFrom(AppExtn)
SmbServerExtn.name    = "Samba Server"
SmbServerExtn.classId = "sambaServer"
SmbServerExtn.className  = "SmbServerExtn"
SmbServerExtn.dbTable = "smbGlobalConfig"
SmbServerExtn.logger  = nil

local SUPER = require("appExtn.AppExtn")

-- network events
local netEvents = {}
netEvents[evtDsptch.event.IFDEV_EVENT_IP_ADDR_CHG]   =  1
netEvents[evtDsptch.event.IFDEV_EVENT_IP4_NET_UP]   =  1

-- configuration events
local cfgEvents = {}
cfgEvents[db.event.SQLITE_INSERT] = 1
cfgEvents[db.event.SQLITE_UPDATE] = 1
cfgEvents[db.event.SQLITE_DELETE] = 1

-------------------------------------------------------------------------------
-- @name SmbServerExtn.cfgEventCallback
--
-- @description 
--
-- @param  
--
-- @return  
--

function SmbServerExtn.cfgEventCallback(obj, info)
    local status = "ERROR"
    local errcode = ""

    LOG:ddebug(SmbServerExtn.classId .. " configuration callback called  " .. 
              "for event: " ..  info.event .. " on rowId " .. info.rowId)

    if (info.event == db.event.SQLITE_INSERT) then
        if (obj ~= nil) then 
            assert(nil, SmbServerExtn.classId .. "(" .. info.rowId  .. ")" ..
                   "already created")
            return -1
        end        

        -- create instance and process event
        obj = SmbServerExtn:new(info.rowId)
        if (obj) then 
            obj:onCfgEvent(info) 
        end

    elseif (info.event == db.event.SQLITE_UPDATE) then
        -- re-load and process event
        if (obj) then 
            status, errCode, obj = obj:load()
            if (status == "OK") then
                obj:onCfgEvent(info) 
            end            
        end
    elseif (info.event == db.event.SQLITE_DELETE) then
        -- process event and destroy instance
        if (obj) then
            obj:onCfgEvent(info)
            obj:delete()
        end
    end        

    return 0
end

-------------------------------------------------------------------------------
-- @name SmbServerExtn.bootstrap
--
-- @description This function is called by appd on startup to bootstrap all 
-- instances of this application. 
--
-- @param  
--
-- @return  
--

function SmbServerExtn.bootstrap()
    local instanceId
    local callbackTable= {}

    smbLib.killAll()

    local callback = {}
    callback.type = appd.eventType.APPD_EV_CFG
    callback.dbTable = SmbServerExtn.dbTable
    callback.routine = SmbServerExtn.cfgEventCallback
    table.insert(callbackTable, callback)
    appd.callbackRegister (SmbServerExtn.classId, callbackTable)

    local cfg = db.getTable(SmbServerExtn.dbTable, false)
    if (cfg == nil) then
        return 0
    end        

    for index, record in pairs(cfg) do
        instanceId = record["_ROWID_"]
        local obj = SmbServerExtn:new(instanceId)
        if (obj and obj:isEnabled()) then
            obj:start()
        end                        
    end

    return 0
end

-------------------------------------------------------------------------------
-- @name SmbServerExtn:new
--
-- @description This function creates a new instance object for DMS, loads
-- the configuration and event subcriptions
--
-- @return  0 for success and -1 for error
--

function SmbServerExtn:new(instanceId, props)

    -- create a new instance
    self = SmbServerExtn.create()

    SUPER.new(self, SmbServerExtn.classId, instanceId, props)

    self.name  = SmbServerExtn.name
    self.dbTable =  SmbServerExtn.dbTable

    -- initialize events for this instance
    self.netEvents = netEvents              
    self.cfgEvents = cfgEvents

    local handle = db.gethandle(self.dbconn)
    smbLib.init(handle)

    -- load the instance          
    local status, errCode, self = self:load()
    if (status == nil) then
        LOG:error("failed to load " .. classId .. 
                  "(" .. instanceId .. ")")
        return nil
    end        

    -- register with appd
    appd.appExtnRegister(self)                    

    return self
end

-------------------------------------------------------------------------------
-- @name SmbServerExtn:delete
--
-- @description This function deletes an instance of this extension
--
-- @param instanceId
--
-- @return  
--

function SmbServerExtn:delete()
    appd.appExtnUnregister(self)
end

-------------------------------------------------------------------------------
-- @name SmbServerExtn:stop
--
-- @description This function starts DMS
--
-- @return  0 for success and -1 for error
--

function SmbServerExtn:stop ()

    LOG:info("Stopping " .. self.name .. 
             "(" ..  self.instanceId .. ")")

    smbLib.stop()

    return 0
end

-------------------------------------------------------------------------------
-- @name SmbServerExtn:isEnabled
--
-- @description This function checks if this instance is enabled
--
-- @return  true if enabled else false
--

function SmbServerExtn:isEnabled()

    local props = self:getProps()

    if (tonumber(props.serverEnable) > 0) then
        return true
    end        

    return false
end

-------------------------------------------------------------------------------
-- @name SmbServerExtn:start
--
-- @description This function starts DMS
--
-- @return  0 for success and -1 for error
--

function SmbServerExtn:start ()
    require "teamf1lualib/nimf"
    local props = self:getProps()

    if (self:isEnabled()) then

        -- check if the network is UP
        if (nimfConn.isIPv4Up(props.LogicalIfName) == false) then
            LOG:debug(self.name .. ": Network(" .. props.LogicalIfName  .. ") is not UP")
            return -1
        end        

        LOG:info("Starting " .. self.name ..  "(" ..  self.instanceId .. ")")

        if (smbLib.start() < 0) then
            return -1
        end            
    end

    return 0
end

-------------------------------------------------------------------------------
-- @name SmbServerExtn:restart
--
-- @description This function restarts DMS
--
-- @return  0 for success and -1 for error
--

function SmbServerExtn:restart ()

    -- stop the server
    self:stop() 

    -- start the server
    if (self:start() < 0) then
        return -1
    end                

    return 0
end

-------------------------------------------------------------------------------
-- @name SmbServerExtn:getAppName
--
-- @description This function gets the name of this extension
--
-- @return  
--

function SmbServerExtn:getAppName()
   return self.name
end

-------------------------------------------------------------------------------
-- @name SmbServerExtn:getDbTableName
--
-- @description This function gets the database table name which contains
-- configuration records for all instances of this application.
--
-- @return  
--

function SmbServerExtn:getDbTableName()
   return self.dbTable
end

-------------------------------------------------------------------------------
-- @name SmbServerExtn:onNetEvent
--
-- @description This function handles network events
--
-- @param  netevent  network event
--
-- @return  0 for success and -1 for error
--

function SmbServerExtn:onNetEvent(netevent)

    if (self:isEventSubscribed(netevent) == false) then
        LOG:ddebug(self.name .. " not subscribed to event: " ..
                   netevent.event .. " on " .. netevent.ifname)
        return 0
    end        

    self:restart()

    return 0
end

-------------------------------------------------------------------------------
-- @name SmbServerExtn:isEventSubscribed
--
-- @description This function checks if this instance is subcribed to
-- the event pass as input
--
-- @param event event information
--
-- @return  0 for success and -1 for error
--

function SmbServerExtn:isEventSubscribed(event)
    local props = self:getProps()

    if (event.type == appd.eventType.APPD_EV_NET) then

        if (strlib.strcasecmp(props.LogicalIfName, event.ifname) ~= 0) then
            return false
        end            
        
        local evstate = self.netEvents[event.event]
        if (evstate == nil) then
            return false
        end            
                    
        if (evstate > 0) then
            return true
        end        

    elseif (event.type == appd.eventType.APPD_EV_CFG) then

        -- are we subscribed to this event                        
        local evstate = self.cfgEvents[event.event]
        if (evstate == nil) then
            return false
        end            

        if (evstate > 0) then
            return true
        end        
    end

    return false
end

-------------------------------------------------------------------------------
-- @name SmbServerExtn:onCfgEvent
--
-- @description This function is to handle configuration events
-- 
-- @param  cfgevent event information
--
-- @return  
--

function SmbServerExtn:onCfgEvent(cfgevent)
    local props = self:getProps()

    if (self:isEventSubscribed(cfgevent) == false) then
        LOG:ddebug(self.name .. " not subscribed to event: " ..
                   cfgevent.event .. " on " .. cfgevent.dbTable)
        return
    end        

    if (cfgevent.event == db.event.SQLITE_INSERT) then
       self:start()
    elseif (cfgevent.event == db.event.SQLITE_UPDATE) then
        self:restart()
    elseif (cfgevent.event == db.event.SQLITE_DELETE) then
        self:stop()
    end                

    return
end

-------------------------------------------------------------------------------
-- @name SmbServerExtn:print
--
-- @description This function prints the properties of this application instance
--
-- @param  
--
-- @return  
--

function SmbServerExtn:print()
    require "util/strlib"

    LOG:info("Class     : " .. self.classId)
    LOG:info("Instance  : " .. self.instanceId)
    LOG:info("App Name  : " .. self:getAppName())
    LOG:info("Conf      : " .. strlib.serializeTbl(self:getProps()))
    return
end

return SmbServerExtn
