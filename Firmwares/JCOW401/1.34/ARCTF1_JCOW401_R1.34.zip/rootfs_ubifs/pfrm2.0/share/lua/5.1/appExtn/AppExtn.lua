-- @copyright Copyright (c) 2012, TeamF1, Inc. 

require("oo/OoUtil")
require("ds/Ds")

--[[
--
--
--
--
--
--
--]]

AppExtn = OoUtil.inheritsFrom(Ds)

-------------------------------------------------------------------------------
-- @name AppExtn:new
--
-- @description This function creates an in-memory object for a given 
-- application.
--
-- @param  
--
-- @return  
--

function AppExtn:new(classId, instanceId, props)
    if (not self) then
        self = AppExtn.create()
    end

    Ds.new(self, classId, instanceId, props)

    -- get database connection
    self.dbconn = db.get_connection()
    if (self.dbconn == nil) then
        return nil
    end        

    -- initialize logger
    if (LOG == nil) then
        LOG = logging.syslog(classId)
    end
    self.logger = LOG

    return self
end

-------------------------------------------------------------------------------
-- @name AppExtn:getAppName
--
-- @description This function gets the name of the application
--
-- @param  
--
-- @return  
--

function AppExtn:getAppName()
    return "NOT SET"
end

-------------------------------------------------------------------------------
-- @name AppExtn:load
--
-- @description This function initalizes the configuration of the application
-- from the persitent storage.
--
-- @param  
--
-- @return  
--

function AppExtn:load()
    return Ds.load(self, self.classId, self.instanceId)
end

-------------------------------------------------------------------------------
-- @name AppExtn:isEventSubscribed
--
-- @description This function registers the application to various system
-- events
--
-- @param  
--
-- @return  
--

function AppExtn:isEventSubscribed(event)
    return false
end

-------------------------------------------------------------------------------
-- @name AppExtn:save
--
-- @description This function saves the configuration of the application
--
-- @param  
--
-- @return  
--

function AppExtn:save()
end

-------------------------------------------------------------------------------
-- @name AppExtn:cfgFileWrite
--
-- @description This function writes the configuration file for the application
--
-- @param  
--
-- @return  
--

function AppExtn:cfgFileWrite()
end

-------------------------------------------------------------------------------
-- @name AppExtn:start
--
-- @description This function starts the application
--
-- @param  
--
-- @return  
--

function AppExtn:start()
end

-------------------------------------------------------------------------------
-- @name AppExtn:stop
--
-- @description This function stops the application
--
-- @param  
--
-- @return  
--

function AppExtn:stop()
end

-------------------------------------------------------------------------------
-- @name AppExtn:disable
--
-- @description This function disables the application
--
-- @param  
--
-- @return  
--

function AppExtn:disable()
end

-------------------------------------------------------------------------------
-- @name AppExtn:pidGet
--
-- @description This function gets the pid of the application
--
-- @param  
--
-- @return  
--

function AppExtn:pidGet()
end

-------------------------------------------------------------------------------
-- @name AppExtn:cmdLineGet
--
-- @description This function gets the command line that was used to start
-- the application
--
-- @param  
--
-- @return  
--

function AppExtn:cmdLineGet()
end

-------------------------------------------------------------------------------
-- @name AppExtn:restart
--
-- @description This function restarts the application
--
-- @param  
--
-- @return  
--

function AppExtn:restart()
end

-------------------------------------------------------------------------------
-- @name AppExtn:monitor
--
-- @description This function is called when the  application needs to be 
-- mointored. for example: it can tell the if the application is running or not
-- 
-- @param  
--
-- @return  
--

function AppExtn:monitor()
end

-------------------------------------------------------------------------------
-- @name AppExtn:onCfgEvent
--
-- @description This function is invoked when a configuration change
-- event is received for the application
--
-- @param  
--
-- @return  
--

function AppExtn:onCfgEvent()
end

-------------------------------------------------------------------------------
-- @name AppExtn:onNetEvent
--
-- @description This function is invoked when a network event that an
-- application has registered for has occured.
--
-- @param  
--
-- @return  
--

function AppExtn:onNetEvent()
   return 0
end

-------------------------------------------------------------------------------
-- @name AppExtn:onLowMemory
--
-- @description This function defines a procedure that can be invoked for the
-- application during low memory conditions (e.g firmware upgrade scenarios..)
-- 
-- @param  
--
-- @return  
--

function AppExtn:onLowMemory()
end

-------------------------------------------------------------------------------
-- @name AppExtn:cpuUsageGet
--
-- @description This function gets the CPU usage of the given application
-- The CPU usage provided is a weighted average over a period of time (EWMA)
--
-- @param  
--
-- @return  
--

function AppExtn:cpuUsageGet()
end

-------------------------------------------------------------------------------
-- @name AppExtn:vmUsageGet
--
-- @description This function gets the VM usage of the given application
-- The VM usage provided is a weighted average over a period of time(EWMA)
--
-- @param  
--
-- @return  
--

function AppExtn:vmUsageGet()
end

-------------------------------------------------------------------------------
-- @name AppExtn:print
--
-- @description 
--
-- @param  
--
-- @return  
--

function AppExtn:print()
    return 0
end

return AppExtn
