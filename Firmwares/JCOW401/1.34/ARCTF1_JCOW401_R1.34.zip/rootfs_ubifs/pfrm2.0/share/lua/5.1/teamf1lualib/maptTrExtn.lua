--[[
#### 
#### File: maptTrExtn.lua
#### Description: 
#### TR-181 handlers for configuring MAP-T settings in the device.
#### This file is included from tr69Glue code.
####
]]--

maptTr = {}

function maptTr.maptTrSet(input, rowids, actionType, tr69Param)
    local status = "0"
    local errMsg = ""
    local faultTbl = {}
    local index = 0

    tr69Glue.tf1Dbg("Entering maptTr.maptTrSet..")
   
    --get correspnding db entry from maptConfig 
    query = "_ROWID_=1"
    local row = db.getRowWhere ("maptConfig", query, false)
    if(row == "nil") then
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)        
        return status, faultTbl 
    end
    
    -- Device.MAP.Enable
    if(input["maptConfig"]["maptConfig.enable"] ~= nil) then
        row["enable"] = input["maptConfig"]["maptConfig.enable"]
    end

    if(row["enable"] == "1") then
        -- Device.MAP.Domain.0.DefaultMappingRule
        if(input["maptConfig"]["maptConfig.brIpv6Prefix"] ~= nil) then
            row["brIpv6Prefix"] = input["maptConfig"]["maptConfig.brIpv6Prefix"]
        end

        -- Device.MAP.Domain.0.X_RJIL_COM_BRIPv6PrefixLen
        if(input["maptConfig"]["maptConfig.brIpv6PrefixLen"] ~= nil) then
            row["brIpv6PrefixLen"] = input["maptConfig"]["maptConfig.brIpv6PrefixLen"]
   	end

    	-- Device.MAP.Domain.0.Rule.0.IPv4Prefix
    	if(input["maptConfig"]["maptConfig.ipv4Prefix"] ~= nil) then
            row["ipv4Prefix"] = input["maptConfig"]["maptConfig.ipv4Prefix"]
    	end

    	-- Device.MAP.Domain.0.Rule.0.IPv6Prefix
    	if(input["maptConfig"]["maptConfig.ipv6Prefix"] ~= nil) then
            row["ipv6Prefix"] = input["maptConfig"]["maptConfig.ipv6Prefix"]
    	end

    	-- Device.MAP.Domain.0.Rule.0.EABitsLength
    	if(input["maptConfig"]["maptConfig.eaLength"] ~= nil) then
            row["eaLength"] = input["maptConfig"]["maptConfig.eaLength"]
    	end

    	-- Device.MAP.Domain.0.Rule.0.X_RJIL_COM_IPv4PrefixLen
    	if(input["maptConfig"]["maptConfig.ipv4PrefixLen"] ~= nil) then
            row["ipv4PrefixLen"] = input["maptConfig"]["maptConfig.ipv4PrefixLen"]
    	end

    	-- Device.MAP.Domain.0.Rule.0.X_RJIL_COM_IPv6PrefixLen
    	if(input["maptConfig"]["maptConfig.ipv6PrefixLen"] ~= nil) then
            row["ipv6PrefixLen"] = input["maptConfig"]["maptConfig.ipv6PrefixLen"]
    	end

    	-- Device.MAP.Domain.0.Rule.0.X_RJIL_COM_EAbits
    	if(input["maptConfig"]["maptConfig.eabitsVal"] ~= nil) then
           row["eabitsVal"] = input["maptConfig"]["maptConfig.eabitsVal"]
    	end
    end
    
    tr69Glue.tf1Dbg("conf.." .. util.tableToStringRec(row))
    
    -- require
    require "teamf1lualib/maptConfig"
    
    --setting the new configuration in the table
    status = mapt.tr69configure(row) 
    if(status == "OK") then
        db.save()
    else
        status = ERROR
        index = index + 1
        faultTbl = tr69Glue.tf1SetFaultCode(faultTbl, index, tr69Param, error_code.INTERNAL_ERROR)        
        return status, faultTbl 

    end
    
    return "0", "STATUS_OK"
end


