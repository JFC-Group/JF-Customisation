--[[
#### Adarsh Uppula
#### TeamF1
#### www.TeamF1.com
#### June 29, 2007

#### File: bridgeLib.lua
#### Description: bridgeLib functions

#### Revisions:
01b,30May17,swr  Changes for SPR 61006
01a,28Sep15,swr  Changes for SPR 52552
]]--


--************* Requires *************

--************* Initial Code *************

--package bridgePorts
bridge = {}
bridgePorts = {}
bridgeIpAddrMgmt = {}
bridgeDscpTo8021pMapping = {}
bridgeMode = {}
bridgeModeVlan = {}

bridge.MAX_ENTRIES = 4095
bridge.WAN_IFNAME = "bdg1"
bridge.LAN_IFNAME = "bdg2"

local wlaninterfaceName = {
    "wl0.1" ,
    "wl0.2" ,
    "wl1.1" ,
    "wl1.2"    
}
local bridgeIfname = {
    "bdg4" ,
    "bdg5" ,
    "bdg6" ,
    "bdg7"
}

local IFCONFIG_CMD  = "/sbin/ifconfig "
local BRCTL_CMD     = "/usr/sbin/brctl "
local SHELL_CMD     = "/bin/sh "
local VLAN_UPDATE_BDG = "/pfrm2.0/bin/vlanUpdateBdg_AE.sh "
local VLAN_UPDATE_BDG_GPON = "/pfrm2.0/bin/vlanUpdateBdg.sh "

-------------------------------------------------------------------------------
-- @name bridge.portDisable
--
-- @description The function disables the ports in the bridge
--
-- @param bdgIfName interface name of the bridge
-- @param ifTbl     list of bridge ports
--
-- @return  status OK or ERROR
-- @return  errCode error string
--

function bridge.portDisable(bdgIfName, ifTbl)

    if ((bdgIfName == nil) or (ifTbl == nil)) then
        return "ERROR","BDG_ERR_INVALID_PARAMS"
    end        
 
    --
    -- Disable bridge ports
    --
    for i,v in pairs (ifTbl) do
        local port = {}
        port["interfaceName"] = v["ifname"]
        port["portEnabled"] = 0
        port["bridgeInterface"] = bdgIfName

        port = util.addPrefix (port, "bridgePorts.");
        local rowid = db.existsRow ("bridgePorts", "interfaceName", port["bridgePorts.interfaceName"])
        if (rowid ~= false) then
            local valid, errstr = bridgePorts.config (port, rowid, "edit")
            if (not valid) then
                return "ERROR","BDG_ERR_UPDATE_FAILED"        
            end        
        end
    end

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name bridge.portEnable
--
-- @description The function enables ports in the bridge
--
-- @param bdgIfName interface name of the bridge
-- @param ifTbl     list of bridge ports
--
-- @return  status OK or ERROR
-- @return  errCode error string
--

function bridge.portEnable(bdgIfName, ifTbl)

    if ((bdgIfName == nil) or (ifTbl == nil)) then
        return "ERROR","BDG_ERR_INVALID_PARAMS"
    end        
 
    --
    -- Disable bridge ports
    --
    for i,v in pairs (ifTbl) do
        local port = {}
        port["interfaceName"] = v["ifname"]
        port["portEnabled"] = 1
        port["bridgeInterface"] = bdgIfName

        port = util.addPrefix (port, "bridgePorts.");
        local rowid = db.existsRow ("bridgePorts", "interfaceName", port["bridgePorts.interfaceName"])
        if (rowid ~= false) then
            local valid, errstr = bridgePorts.config (port, rowid, "edit")
            if (not valid) then
                return "ERROR","BDG_ERR_UPDATE_FAILED"        
            end        
        end
    end

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name bridge.portAdd
--
-- @description The function adds ports to the given bridge
--
-- @param bdgIfName interface name of the bridge
--
-- @return  status OK or ERROR
-- @return  errCode error string
--

function bridge.portAdd(bdgIfName, ifTbl)

    if ((bdgIfName == nil) or (ifTbl == nil)) then
        return "ERROR","BDG_ERR_INVALID_PARAMS"
    end        
 
    --
    -- Add bridge ports
    --
    for i,v in pairs (ifTbl) do
        local port = {}
        port["interfaceName"] = v["ifname"]
        port["portEnabled"] = 1
        port["vlanEnabled"] = 0 --TODO change when vlan ifname is a vlan??
        port["bridgeInterface"] = bdgIfName
        port["portType"] = v["type"]

        port = util.addPrefix (port, "bridgePorts.");
        local rowid = db.existsRow ("bridgePorts", "interfaceName", port["bridgePorts.interfaceName"])
        if (rowid == false) then
            local valid, errstr, rowid = bridgePorts.config (port, -1, "add")
            if (not valid) then
                return "ERROR","BDG_ERR_CREATE_FAILED"        
            end        
        else
            local valid, errstr = bridgePorts.config (port, rowid, "edit")
            if (not valid) then
                return "ERROR","BDG_ERR_UPDATE_FAILED"        
            end        
        end
    end

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name bridge.portDelete
--
-- @description This function deletes ports from the given bridge.
--
-- @param bdgIfName interface name of the bridge
--
-- @return  status OK or ERROR
-- @return  errCode error string
--

function bridge.portDelete(bdgIfName, ifTbl)

    if ((bdgIfName == nil) or (ifTbl == nil)) then
        return "ERROR","BDG_ERR_INVALID_PARAMS"
    end        

   if (type(ifTbl) ~= "table") then
        return "ERROR","BDG_ERR_INVALID_PARAMS"
    end
            
    --
    -- Delete bridge ports
    --
    for i,v in ipairs (ifTbl) do
        local query = "bridgeInterface='" .. bdgIfName .. "' and " ..
                      "interfaceName='" .. v["ifname"]  .. "'"

        if (db.existsRowWhere ("bridgePorts", query)) then
            local valid, errstr = db.deleteRowWhere ("bridgePorts", query)
            if (not valid) then
                return "ERROR","BDG_ERR_CREATE_FAILED"        
            end        
        end
    end
    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name bridge.destroy
--
-- @description  This function destroys the given bridge interface.
--
-- @param bdgIfName interface name of the bridge
--
-- @return  status OK or ERROR
-- @return  errCode error string
--

function bridge.destroy(bdgIfName)

    if (bdgIfName == nil) then
        return "ERROR","BDG_ERR_INVALID_PARAMS"
    end        

    local query = "interfaceName='" .. bdgIfName .. "'"
    local records = db.getRowWhere("bridgePorts", query, false) 
    if (records ~= nil) then
        return "ERROR","BDG_ERR_PORT_EXISTS"
    end        

    local valid, errstr = db.deleteRowWhere ("bridgeTable", query)
    if (not valid) then
        return "ERROR","BDG_ERR_CREATE_FAILED"        
    end        

    return "OK","STATUS_OK"
end

-------------------------------------------------------------------------------
-- @name  bridge.create
--
-- @description This function creates the given bridge interface.
--
-- @param conf.ifTbl            table of interface(s) which will be part of the bridge. 
-- @param conf.LogicalIfName    LogicalInterface to which the bridge belongs
--
-- Each table entry has the following fields.
-- <ul>
-- <li><i>ifname</i>            interface name
-- <li><i>type</i>              type of the bridge port
-- </ul>
--
-- @return  status OK or ERROR
-- @return  errCode error string
-- @return  bdgIfName       
--

function bridge.create(conf)
    local status = "ERROR"
    local errCode = "BDG_ERR_INVALID_PARAMS"

    --
    -- Generate a bridge name
    --
    local count = 1
    local bridgeTable = db.getTable ("bridgeTable", false)
    while (count < bridge.MAX_ENTRIES) do
        bdgIfName = "bdg" .. count
        if (bridge.byNameFind(bdgIfName, bridgeTable) == nil) then
            break
        end            
        count = count + 1
    end        

    if (bdgIfName == nil) then
        return "ERROR","BDG_ERR_NAME_FAILED"        
    end        

    -- 
    -- Add the bridge
    --
    local bdgTbl = {}
    bdgTbl["interfaceName"] = bdgIfName
    bdgTbl["LogicalIfName"] = conf["LogicalIfName"] or ""
    bdgTbl["igmpSnooping"] = conf["igmpSnooping"] or ""
    bdgTbl["macAddress"] = '' -- TODO
    bdgTbl = util.addPrefix (bdgTbl, "bridgeTable.");
    local valid, errstr, rowid = db.insert ("bridgeTable", bdgTbl)
    if (not valid) then
        return "ERROR","BDG_ERR_CREATE_FAILED"        
    end        

    if (conf.ifTbl ~= nil) then
        status,errCode = bridge.portAdd(bdgIfName, conf.ifTbl) 
        if (status ~= "OK") then
            return status, errCode
        end
    end

    return "OK", "STATUS_OK", bdgIfName
end


-------------------------------------------------------------------------------
-- @name  bridge.edit
--
-- @description This function updates igmpSnooping for the given logical interface.
--
-- @param conf.igmpSnooping     igmpSnooping value  to be set
-- @param conf.LogicalIfName    LogicalInterface to which the bridge belongs
--
-- @return  status OK or ERROR
-- @return  errCode error string
--       

function bridge.edit(conf)
    local statusFlag = true
    -- 
    -- edit the bridge
    --
    local snooping
    if(conf ["igmpSnooping"] ~= nil) then
        snooping = tonumber(conf["igmpSnooping"])
    else
        snooping = tonumber (db.getAttribute("bridgeTable", "LogicalIfName", conf["LogicalIfName"], "igmpSnooping"))
    end

    if ((snooping < 0) or (conf ["LogicalIfName"] == nil)) then
          return "ERROR","BDG_ERR_INVALID_PARAMS"
    end

    --set IGMP Snoop
    statusFlag = db.setAttribute ("bridgeTable", "LogicalIfName", conf["LogicalIfName"], "igmpSnooping", snooping)
    if(statusFlag) then
    	return "OK", "STATUS_OK"
    else
    	return "ERROR", "BDG_ERR_UPDATE_FAILED"
    end
end

-------------------------------------------------------------------------------
-- @name  bridge.portTblGet
--
-- @description This function creates the given bridge interface.
--
-- @param bdgIfName interface name of the bridge
--
-- @return  status OK or ERROR
-- @return  errCode error string
-- @return  portTbl list of port.
--
-- Each table entry has the following fields.
-- <ul>
-- <li><i>ifname</i>            interface name
-- <li><i>type</i>              type of the bridge port
-- </ul>
--

function bridge.portTblGet (bdgIfName)
    local portTbl = {}
    local status = "ERROR"
    local errCode = "BDG_ERR_INVALID_PARAMS"

    if (bdgIfName == nil) then
        return status, errCode
    end

    local query = "bridgeInterface='" .. bdgIfName ..  "'"
    local records = db.getRowsWhere("bridgePorts", query, false) 
    if (records == nil) then
        return status, errCode        
    end        

    local index = 1
    for k,v in pairs(records) do
        portTbl[index] = {}
        portTbl[index]["ifname"] = v["interfaceName"]
        portTbl[index]["type"] = v["portType"]
        index = index + 1
    end        

    return "OK", "STATUS_OK", portTbl
end

-------------------------------------------------------------------------------
-- @name bridge.confGet
--
-- @description This function queries the bridge configuration
--
-- @param dbtable   bridge configuration table
-- @param query     sql query
--
-- @return  table of records or nil
--

function bridge.confGet(dbtable, query)
    local records = {}

    if (query ~= nil) then
        records = db.getRowsWhere (dbtable, query, false)
        if (records == nil) then
            return nil
        end        
    else
        records = db.getTable (dbtable, false)
        if (records == nil) then
            return nil
        end        
    end        

    return records
end

-------------------------------------------------------------------------------
-- @name bridge.ifNameGet
--
-- @description This function get the bridge interface name for the given
-- LogicalIfName
--
-- @param LogicalIfName LogicalIfName of the network
--
-- @return  nil or bridge interface name
--

function bridge.ifNameGet(LogicalIfName)
    local query

    if (LogicalIfName == nil) then
        return nil
    end
            
    query ="LogicalIfName='" .. LogicalIfName .. "'"
    bdgIf = bridge.confGet("bridgeTable", query)
    if ((bdgIf == nil) or (bdgIf[1] == nil)) then
        return nil
    end        

    return bdgIf[1]["interfaceName"] 
end

--************* INTERNAL Functions *************

--[[
*******************************************************************************
-- @name 
--
-- @description 
--
-- @param
--
-- @return  
-- @return 
--]]

function bridgePorts.config (inputTable, rowid, operation)

    if (bridgePorts.inputvalidate(inputTable, operation)) then
        if (operation == "add") then
            return db.insert("bridgePorts", inputTable)
        elseif (operation == "edit") then
            return db.update("bridgePorts", inputTable, rowid)
        elseif (operation == "delete") then
            return false
        end
    end
    return false

end

--[[
*******************************************************************************
-- @name 
--
-- @description 
--
-- @param
--
-- @return  
-- @return 
--]]

function bridgeMode.config (inputTable, rowid, operation)
    if (operation == "add") then
        return db.insert("bridgeMode", inputTable)
    elseif (operation == "edit") then
        return db.update("bridgeMode", inputTable, rowid)
    elseif (operation == "delete") then
        return db.delete ("bridgeMode", inputTable)
    end
    return false
end

--[[
*******************************************************************************
-- @name 
--
-- @description 
--
-- @param
--
-- @return  
-- @return 
--]]

function bridgeModeVlan.config (inputTable, rowid, operation)
    if (operation == "add") then
        return db.insert("bridgeModeVlan", inputTable)
    elseif (operation == "edit") then
        return db.update("bridgeModeVlan", inputTable, rowid)
    elseif (operation == "delete") then
        return db.delete ("bridgeModeVlan", inputTable)
    end
    return false
end

--[[
*******************************************************************************
-- @name 
--
-- @description 
--
-- @param
--
-- @return  
-- @return 
--]]

function bridgeMode.get ()
	local bridgeModeRow = db.getRow ("bridgeMode", "_ROWID_", "1")
    return bridgeModeRow
end

function bridgeMode.deleteBridgeModeVlan(vlanId, lanphyName)

    os.execute(SHELL_CMD .. VLAN_UPDATE_BDG .. "DEL " .. vlanId .. " " .. lanphyName .. " > /dev/null")
end

function bridgeMode.addBridgeModeVlan(vlanId, lanphyName)

    os.execute(SHELL_CMD .. VLAN_UPDATE_BDG .. "ADD " .. vlanId .. " " .. lanphyName .. " > /dev/null")
end
function bridgeMode.deleteBridgeModeVlanGpon(vlanId)

    os.execute(SHELL_CMD .. VLAN_UPDATE_BDG_GPON .. "DEL " .. vlanId .. " > /dev/null")
end

function bridgeMode.addBridgeModeVlanGpon(vlanId)

    os.execute(SHELL_CMD .. VLAN_UPDATE_BDG_GPON .. "ADD " .. vlanId .. " > /dev/null")
end

function bridgeModeVlan.get(dbtable, query)
    local records = {}
    
    records = db.getTable ("bridgeModeVlan", false)
    if (records == nil) then
        return nil
    end        

    return records
end

--[[
*******************************************************************************
-- @name 
--
-- @description 
--
-- @param
--
-- @return  
-- @return 
--]]

function bridgeIpAddrMgmt.config (inputTable, rowid, operation)
    if (operation == "add") then
        return db.insert("bridgeIpAddrMgmt", inputTable)
    elseif (operation == "edit") then
        return db.update("bridgeIpAddrMgmt", inputTable, rowid)
    elseif (operation == "delete") then
        return db.delete ("bridgeIpAddrMgmt", inputTable)
    end
    return false
end

--[[
*******************************************************************************
-- @name 
--
-- @description 
--
-- @param
--
-- @return  
-- @return 
--]]

function bridgeDscpTo8021pMapping.config (inputTable, rowid, operation)
    if (operation == "add") then
        return db.insert("bridgeDscpTo8021pMapping", inputTable)
    elseif (operation == "edit") then
        return db.update("bridgeDscpTo8021pMapping", inputTable, rowid)
    elseif (operation == "delete") then
        return db.delete ("bridgeDscpTo8021pMapping", inputTable)
    end
    return false
end

--[[
*******************************************************************************
-- @name 
--
-- @description 
--
-- @param
--
-- @return  
-- @return 
--]]

function bridgePorts.inputvalidate (inputTable, operation)
    if (true) then
        return db.typeAndRangeValidate(inputTable)
    end
    return false
end

function bridgeMode.configure(inputTable, rowid, operation, dbFlag)

	local bridgeRow = {}
    local bridgeVlanRows={}
    local bridgeRowCurr = {}
    local vlanRows = {}
    local gponRows = {}
	local valid  = true
	
    bridgeRow["bridgeMode.status"]      = inputTable["bridgeModeStatus"] or inputTable["status"] or "0"
    bridgeRow["bridgeMode.portNumber"]  = inputTable["portNumber"]  or "1"
    bridgeRow["bridgeMode.vlanID"]      = inputTable["vlanID"]      or "0"
    bridgeRow["bridgeMode.lanIface"]    = inputTable["lanIface"]    or "eth1"
    bridgeRow["bridgeMode.wanIface"]    = inputTable["wanIface"]    or "eth4"
        
    if (operation == "delete") then
        errMsg = "OK"
        statusMsg = "STATUS_OK"
        return errMsg, statusMsg
    end
            
    if (operation == "edit") then
            
        bridgeRowCurr = bridgeMode.get ()
        if (bridgeRowCurr == nil) then
            return  "ERROR", "DB_ERROR_TRY_AGAIN"
        end
            
        vlanRows = db.getTable("bridgeModeVlan", false)
        if (vlanRows == nil) then
            return  "ERROR", "DB_ERROR_TRY_AGAIN"
        end
        
        gponRows = db.getTable("gpon", false)
    end


	if ((inputTable["bridgeModeStatus"] == "1") or (tonumber(inputTable["status"]) == 1)) then
        --[[ If Bridge Mode is Enabled. ]]--

        for i=1,10,1 do
            if (tonumber(inputTable["vlanId"..i]) ~= 0) then

                if (inputTable["vlanId" .. i] ~= nil) then
                    if ((tonumber(inputTable["vlanId"..i]) ~= 0) and 
                        (tonumber(inputTable["vlanId" .. i]) > 4094 or tonumber(inputTable["vlanId" .. i]) < 2)) then
                        return "ERROR", "INVALID_VLAN_ID"
                    end
                else
                    return "ERROR", "BRIDGE_MODE_CONFIG_FAILED"
                end

                -- Check Duplicate VlanIds in the given bridgeMode Vlans.
                j=i+1
                while(j<=10) do
                    if(tonumber(inputTable["vlanId"..i]) == tonumber(inputTable["vlanId"..j])) then
                        return "ERROR", "DUPLICATE_VLAN_ID"
                    end
                    j=j+1
                end
		
                -- do the sanity checks
		        local wanVlanRows = db.getRows ("ethernetVLAN", "vlanId", inputTable["vlanId".. i])
		        if (#wanVlanRows ~= 0) then
			        return "ERROR", "SELECTED_VLAN_ID_PRESENT_ON_WAN"
		        end

		        local lanVlanRows = db.getRows ("vlanEncapIf", "vlanId", inputTable["vlanId".. i])
		        if (#lanVlanRows ~= 0) then
			        return "ERROR", "SELECTED_VLAN_ID_PRESENT_ON_LAN"
		        end
		
                if (operation == "edit") then
                    if (#gponRows > 0) then
                        for gi,row in pairs(gponRows) do
		                    if ((row ~= nil) and (row["status"] == "1") and 
                                (row["vlanStatus"] == "1") and 
                                (row["vlanID"] == inputTable["vlanId"..i])) then
			                        return "ERROR", "SELECTED_VLAN_ID_PRESENT_ON_GPON"
		                    end -- end if
		                end -- end for
		            end -- end if gponRows
                end -- end if operation
            end -- end if vlan 0
        end -- end for

        lanVlanRows = db.getTable("vlanEncapIf")
		for k,v in pairs (lanVlanRows) do
			if (string.find (v["vlanEncapIf.fwdMap"], inputTable["portNumber"]) ~= nil ) then
				return "ERROR", "CONFIGURED_PORT_PRESENT_IN_FWD_MAP"
			end
		end

	    if (valid) then
            -- Add New VLANs
            for i=1,10,1 do

                if (operation ~= nil) then
                    local input = {}
                    input["bridgeModeVlan.Enable"] = "1" 
                    input["bridgeModeVlan.vlanID"] = inputTable["vlanId" .. i] 
                    if(dbFlag == 0) then
                        input["bridgeModeVlan.Name"] = inputTable["Name" .. i] 
                    end
                    valid = bridgeModeVlan.config (input, i, "edit")
                    if (not valid) then
                        break
                    end
                end
            end
        end

	else
        
        --[[ If Bridge Mode is Disabled. ]]--
	
        bridgeRow["bridgeMode.status"]      = inputTable["bridgeModeStatus"] or inputTable["status"] or "0"
        bridgeRow["bridgeMode.portNumber"]  = inputTable["portNumber"]  or "1"
		bridgeRow["bridgeMode.vlanID"]      = inputTable["vlanID"]      or "0"
		bridgeRow["bridgeMode.lanIface"]    = inputTable["lanIface"]    or "eth1"
		bridgeRow["bridgeMode.wanIface"]    = inputTable["wanIface"]    or "eth4"

	end

	
	if (valid) then
        
        local status = true

        if (operation ~= nil) then
            if (operation == "edit") then
                status = bridgeMode.config (bridgeRow, "1", "edit")
            else
                status = bridgeMode.config (bridgeRow, "-1", "add")
            end
        end
        
        if(status) then
            errMsg = "OK"
            statusMsg = "STATUS_OK"
        else
            errMsg = "ERROR"
            statusMsg = "BRIDGE_MODE_CONFIG_FAILED"
            return errMsg, statusMsg
        end
    else
        errMsg = "ERROR"
        statusMsg = "BRIDGE_MODE_CONFIG_FAILED"
        return errMsg, statusMsg
    end		
           
    --[[ Now Update system with bridge VLANs 
    --]]--
    if (operation == "edit") then
        if (#vlanRows > 0) then
            -- delete Old VLAN entries
            for i,row in pairs(vlanRows) do
                   
                if (tonumber(row["vlanID"]) ~= 0) then
                    local lanphyName  = "eth" .. bridgeRowCurr["bridgeMode.portNumber"]
                    if(util.fileExists("/pfrm2.0/HW_FOXCONN_JCO500") or util.fileExists("/pfrm2.0/HW_HG260X") or util.fileExists("/pfrm2.0/HW_HG261GU") or util.fileExists("/pfrm2.0/HW_JCOW401") or util.fileExists("/pfrm2.0/HW_JCOW404") or util.fileExists("/pfrm2.0/HW_JCOW403") or util.fileExists("/pfrm2.0/HW_JCOW411")) then
                        lanphyName  = "eth" .. bridgeRowCurr["bridgeMode.portNumber"] - 1
                    end
                    bridgeMode.deleteBridgeModeVlan(row["vlanID"], lanphyName)
		            local gponRow = db.getRow ("gpon", "_ROWID_", "1")
                    if(gponRow["gpon.status"] == "1") then
                        bridgeMode.deleteBridgeModeVlanGpon(row["vlanID"])
                    end
                end
            end
        end
    end

	if ((inputTable["bridgeModeStatus"] == "1") or (tonumber(inputTable["status"]) == 1)) then
    	for i=1,10,1 do
        	if (tonumber(inputTable["vlanId" .. i]) ~= 0) then
            	local lanphyName  = "eth" .. bridgeRow["bridgeMode.portNumber"]
                if(util.fileExists("/pfrm2.0/HW_FOXCONN_JCO500") or util.fileExists("/pfrm2.0/HW_HG260X") or util.fileExists("/pfrm2.0/HW_HG261GU") or util.fileExists("/pfrm2.0/HW_JCOW401") or util.fileExists("/pfrm2.0/HW_JCOW404") or util.fileExists("/pfrm2.0/HW_JCOW403") or util.fileExists("/pfrm2.0/HW_JCOW411")) then
                    lanphyName  = "eth" .. bridgeRow["bridgeMode.portNumber"] - 1 
                end
            	bridgeMode.addBridgeModeVlan(inputTable["vlanId" .. i], lanphyName)
		        local gponRow = db.getRow ("gpon", "_ROWID_", "1")
                if(gponRow["gpon.status"] == "1") then
                    bridgeMode.addBridgeModeVlanGpon(inputTable["vlanId" .. i])
                end
        	end
   		end
	end

	return errMsg, statusMsg

end

--[[
*******************************************************************************
-- @name 
--
-- @description 
--
-- @param
--
-- @return  
-- @return 
--]]

function bridge.import (inputTable, defaultCfg, removeCfg)
    if (inputTable == nil) then
        inputTable = defaultCfg
    end

    local globalTmp = {}
    local portsTmp = {}
    local dscptoQosMapTmp = {}
    local ipaddrlistTmp = {}

   
    local networkInterfaceTbl = {}
	local oldLanInterface = "eth0"
	local newLanInterface = "eth0.1"
    networkInterfaceTbl = db.getTable ("networkInterface", false)

	-- wl.x interfaces need to created before bridge handler is called , so call customSSIDAdd.sh. Not required for no wifi sku (hg261gu) 
	if (util.fileExists("/pfrm2.0/HW_NO_WIFI") == false ) then
		os.execute ("/pfrm2.0/bin/customSSIDAdd.sh &")
	end

   
    if (inputTable.global ~= nil) then
        globalTmp = config.update (inputTable.global, defaultCfg.global, removeCfg.global)
        if (globalTmp ~= nil and #globalTmp ~= 0) then
            for i,v in ipairs (globalTmp) do
                -- config merge new field..
                    for p,q in pairs (networkInterfaceTbl) do
                        if (v["interfaceName"] == q["interfaceName"])then
                            v["LogicalIfName"] = q["LogicalIfName"]
                        end
                    end
                    if(v["interfaceName"] ~= bridge.WAN_IFNAME and v["interfaceName"] ~= bridge.LAN_IFNAME) then 
                        v["acsDisplayEnable"] = "0"                                      
                    end
                v = util.addPrefix (v, "bridgeTable.");
                if (v["bridgeTable.LogicalIfName"] ~= "IF4" and v["bridgeTable.LogicalIfName"] ~= "IF5" and v["bridgeTable.LogicalIfName"] ~= "IF6" and v["bridgeTable.LogicalIfName"] ~= "IF7") then
                    db.insert ("bridgeTable", v)
                end
            end
        end
    end
    if (inputTable.ports ~= nil) then
        portsTmp = config.update (inputTable.ports, defaultCfg.ports, removeCfg.ports)
        if (portsTmp ~= nil and #portsTmp ~= 0) then
            for i,v in ipairs (portsTmp) do
                if (v["interfaceName"] == "wl0.1" and tonumber(v["_ROWID_"])== tonumber(1)) then
                    v["interfaceName"] = "wl0"
                end
                if(v["interfaceName"] == "wl0.2" and tonumber(v["_ROWID_"])== tonumber(2)) then
                    v["interfaceName"] = "wl0.1"
                end
                if(v["interfaceName"] == "wl0.3" and tonumber(v["_ROWID_"])== tonumber(3))then
                    v["interfaceName"] = "wl0.2"
                end
                if (v["interfaceName"] == "wl1.1" and tonumber(v["_ROWID_"])== tonumber(4)) then
                    v["interfaceName"] = "wl1"
                end
                if(v["interfaceName"] == "wl1.2" and tonumber(v["_ROWID_"])== tonumber(5)) then
                    v["interfaceName"] = "wl1.1"
                end
                if(v["interfaceName"] == "wl1.3" and tonumber(v["_ROWID_"])== tonumber(6))then
                    v["interfaceName"] = "wl1.2"
                end
                v = util.addPrefix (v, "bridgePorts.")

				if ((string.find (v["bridgePorts.interfaceName"],"wdev0")) ~= nil ) then
					v["bridgePorts.portEnabled"] = "1"
				end
                v["bridgePorts.bridgeInterface"] = bridge.LAN_IFNAME
                bridgePorts.config (v, i, "add")
            end
        end
    end
    if (inputTable.dscptoQosMap ~= nil) then 
        dscptoQosMapTmp = config.update (inputTable.dscptoQosMap, defaultCfg.dscptoQosMap, removeCfg.dscptoQosMap)
        if (dscptoQosMapTmp ~= nil and #dscptoQosMapTmp ~= 0) then
            for i,v in ipairs (dscptoQosMapTmp) do
                v = util.addPrefix (v, "bridgeDscpTo8021pMapping.");
                bridgeDscpTo8021pMapping.config (v, i, "add")
            end
        end
    end
    if (inputTable.ipaddrlist ~= nil) then
        ipaddrlistTmp = config.update (inputTable.ipaddrlist, defaultCfg.ipaddrlist, removeCfg.ipaddrlist)
        if (ipaddrlistTmp ~= nil and #ipaddrlistTmp ~= 0) then
            for i,v in ipairs (ipaddrlistTmp) do
                v = util.addPrefix (v, "bridgeIpAddrMgmt.");
                bridgeIpAddrMgmt.config (v, i, "add")
            end
        end
    end

    if (inputTable.bridgeMode ~= nil) then
        bridgeModeTmp = config.update (inputTable.bridgeMode, defaultCfg.bridgeMode, removeCfg.bridgeMode)
        if (bridgeModeTmp ~= nil and #bridgeModeTmp ~= 0) then
            for i,v in ipairs (bridgeModeTmp) do
                if (util.fileExists("/pfrm2.0/ae_wan_type"))then
                    v["wanIface"] = "eth4"
                end
                v = util.addPrefix (v, "bridgeMode.");
                bridgeMode.config (v, i, "add")
            end
        end
    end

    if (inputTable.bridgeModeVlan ~= nil) then
        bridgeModeVlanTmp = config.update (inputTable.bridgeModeVlan, defaultCfg.bridgeModeVlan, removeCfg.bridgeModeVlan)
        if (bridgeModeVlanTmp ~= nil and #bridgeModeVlanTmp ~= 0) then
            for i,v in ipairs (bridgeModeVlanTmp) do
                v = util.addPrefix (v, "bridgeModeVlan.");
                bridgeModeVlan.config (v, i, "add")
            end
        end
    end
end

--[[
*******************************************************************************
-- @name 
--
-- @description 
--
-- @param
--
-- @return  
-- @return 
--]]

function bridge.export ()
    local bridgeConfig = {}
    local ports = db.getTable ("bridgePorts", false)
    local bridgeTable = db.getTable ("bridgeTable", false)
    local ipaddrlist = db.getTable ("bridgeIpAddrMgmt", false);
    local dscpMapping = db.getTable ("bridgeDscpTo8021pMapping", false);
    local bridgeMode = db.getTable ("bridgeMode", false);
    local bridgeModeVlan = db.getTable ("bridgeModeVlan", false);
    bridgeConfig.ports = ports
    bridgeConfig.global = bridgeTable
    bridgeConfig.ipaddrlist = ipaddrlist
    bridgeConfig.dscptoQosMap = dscpMapping
    bridgeConfig.bridgeMode = bridgeMode
    bridgeConfig.bridgeModeVlan = bridgeModeVlan

    return bridgeConfig
end

function bridge.byNameFind (bdgIfName, bridgeTable)
    for k, v in pairs(bridgeTable) do
        if (v["interfaceName"] == bdgIfName) then
            return v
        end            
    end        

    return nil
end            

if (config.register) then
   config.register("bridge", bridge.import, bridge.export, "1")
end
