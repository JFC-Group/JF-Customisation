-- ethernetCLI.lua
-- Gaurav Mathur
-- TeamF1
-- www.TeamF1.com

-- Modification History
-- 25dec07,gnm Added mac address field to ethCLISingleGet(); changed
--	       routine name ethCLIsingleGet() to ethCLISingleGet()
-- 06nov07,gnm written
--
-- Description
-- CLI ethernet set and get routines

require "teamf1lualib/ethernet"
require "teamf1lualib/bridgeLib"

--
--
function ethCfgInputVal(configRow)
    -- Check if the row id field exists. If it does not then we cannot
    -- do anyting
    if (configRow["ethernet._ROWID_"] == nil) then
       printCLIError ("Interface not found.")
       return false
    end

    if (configRow["ethernet.vlanId"] == nil or 
       configRow["ethernet.vlanId"] == "") then
       printCLIError ("Invalid VLAN Id for ethernet port.")
       return false
    end
    return true	 
end

--
--
function ethCfgSave(configRow)
    local errorFlag = "ERROR" -- default 
    local statusMessage = ""
    local statusCode = ""

    -- 
    configRow["vlan.vlanId"] = configRow["ethernet.vlanId"]
    local ifName = db.getAttribute("ethernet","_ROWID_", 
	  configRow["ethernet._ROWID_"],"interfaceName")
    if (ifName == "eth0")  then
        configRow["bridgePorts.trunk"] = 1
    end

    errorFlag, statusCode = ethernet.ethernet_config (configRow, 
	       configRow["ethernet._ROWID_"], "edit")

    if (errorFlag == "OK") then db.save() end
    statusMessage = db.getAttribute("stringsMap", "stringId", statusCode, LANGUAGE)
    return errorFlag, statusMessage    
end

--
--
function ethCfgInit(args)
    local primKey = args[1] -- Interface name
    local rowId = -1

    configRow = db.getRow("ethernet", "ethernet.interfaceName", primKey)
    if configRow == nil then
       return rowId, {}
    end
    -- get the information regaring the vlan configuration for the interface
    configRow['vlan.native'] = db.getAttribute ('vlan', 'vlanId',
			     configRow['ethernet.vlanId'], 'native')

    return rowId, configRow
end

--
-- This routine gets information for the specified ethernet interface
function ethCLISingleGet (iface)
    local resultTab = {}

    local row = db.getRow ("ethernet", "ethernet.interfaceName", iface)
    if (row == nil) then
       resTab.insertField (resultTab, "", "No such interface")
       return resultTab
    end
    local nativeVlan = db.getAttribute("vlan", "vlanId", row["ethernet.vlanId"], 
		     "native")
    resTab.insertField (resultTab, "MAC Address", 
		       row["ethernet.macAddress"] or "")
    resTab.insertField (resultTab, "VLAN ID", row["ethernet.vlanId"])
    resTab.insertField (resultTab, "Interface Name", row["ethernet.interfaceName"])
    resTab.insertYNField (resultTab, row["ethernet.vlanEnabled"] == "1", 
			 "VLAN Enabled")
    resTab.insertYNField (resultTab, nativeVlan == "1" , "Native VLAN")
    return resultTab
end

--
-- This routine gets information for all the ethernet interfaces in
-- the system.
function ethCLIallGet (iface)
    local resultTab = {}

    local row = db.getRow ("ethernet", "ethernet.interfaceName", "eth0")
    if (row == nil) then
       return resultTab
    end
    resTab.insertField (resultTab, "VLAN ID", row["ethernet.vlanId"])
    resTab.insertField (resultTab, "Interface Name", row["ethernet.interfaceName"])
    resTab.insertYNField (resultTab, row["ethernet.vlanEnabled"] == "1", "VLAN Enabled")
    local nativeVlan = db.getAttribute("vlan", "vlanId", row["ethernet.vlanId"], 
		     "native")
    resTab.insertYNField (resultTab, nativeVlan == "1" , "Native VLAN")

    row = db.getRow ("ethernet", "ethernet.interfaceName", "eth1")	
    if (row == nil) then
       return resultTab
    end
    resTab.insertField (resultTab, "VLAN ID", row["ethernet.vlanId"])
    resTab.insertField (resultTab, "Interface Name", row["ethernet.interfaceName"])
    resTab.insertYNField (resultTab, row["ethernet.vlanEnabled"] == "1", "VLAN Enabled")
    local nativeVlan = db.getAttribute("vlan", "vlanId", row["ethernet.vlanId"], 
		     "native")
    resTab.insertYNField (resultTab, nativeVlan == "1" , "Native VLAN")
    return resultTab
end
        
--
-- main function for ethernet get
-- 
function ethCLIGet (args)
    local iface = args[1]

    if (iface == "all") then
        printLabel ("Ethernet Interfaces")
	resultTab = ethCLIallGet ()
        resTab.print (resultTab, 0)
    else	
   	resultTab = ethCLISingleGet (iface)
	resTab.print (resultTab, 0)
    end
end   

--
-- This routine implements the CLI command to display ethernet interface
-- statistics.
function ethCLIStatsGet (args)
    -- run program to read the stats and update DB
    local prog = db.getAttribute("environment", "name", "IFDEVSTATS_PROGRAM", "value")
    os.execute(prog .. " " .. DB_FILE_NAME)

    local table = db.getTable ("ethernet")
    local resultTab = {}

    for _,v in pairs(table) do
        local row = db.getRow("interfaceStats", "interfaceStats.interfaceName", 
	      v["ethernet.interfaceName"])

	resTab.insertField (resultTab, "IFACE", row["interfaceStats.interfaceName"])
	resTab.insertField (resultTab, "PktRx", row["interfaceStats.rx_packets"])
	resTab.insertField (resultTab, "PktTx", row["interfaceStats.tx_packets"])
	resTab.insertField (resultTab, "ByteRx", row["interfaceStats.rx_bytes"])
	resTab.insertField (resultTab, "ByteTx", row["interfaceStats.tx_bytes"])
	resTab.insertField (resultTab, "ErrRx", row["interfaceStats.rx_errors"])
	resTab.insertField (resultTab, "ErrTx", row["interfaceStats.tx_errors"])
	resTab.insertField (resultTab, "DropRx", row["interfaceStats.rx_dropped"])
	resTab.insertField (resultTab, "DropTx", row["interfaceStats.tx_dropped"])
	resTab.insertField (resultTab, "Mcast", row["interfaceStats.multicast"])
	resTab.insertField (resultTab, "Coll", row["interfaceStats.collisions"])
    end

    printLabel ("Ethernet Statistics")
    resTab.print (resultTab, 0)
end   
