--[[ easymeshDebug.lua - Library for Mesh API Debugging.
--
-- Copyright (c) 2008-2019, TeamF1 Networks Pvt. Ltd.
-- [Subsidiary of D-Link (India) Ltd]
-- 
-- File: easymeshDebug.lua
-- Description: Library for Mesh API Debugging.
-- 
-- modification history
-- --------------------
-- 01a, 16Oct19, ar written.
--
--]]

--[[
-- change following debug = 1 to get logs on the serial cosole
--]]
mesh.debug = 1
mesh.console_debug = 1

---------------------------------------------------------------
-- mesh.dprintf - Prints debugs to serial console.
--
---------------------------------------------------------------
function mesh.dprintf(msg)

    if (mesh.debug == 0) then
        return
    end

    if (msg) then
            os.execute ("echo " .. msg .. " >> /tmp/meshResponse.txt")
    end
end

---------------------------------------------------------------
-- printX - Redirect all print output to a Debug window
--
---------------------------------------------------------------
function printX (...)
    local p = "";
    for i,v in ipairs(arg) do
        p = p .. string.gsub(tostring(v),"\r?\n","\r\n") .. "\t";
    end
    p = p .. "\r\n";
    print(p);
end


