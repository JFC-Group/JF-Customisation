#!/pfrm2.0/bin/lua 

--[[
####File: fwIpBasedQOSScript.lua

Copyright (c) 2016, TeamF1 Networks Pvt. Ltd.
(Subsidiary of D-Link India)

modification history
--------------------
 01a,25nov16,vik written

DESCRIPTION - This script will be called for setDestinationIP() from the third party App to add/remove destination IP based QoS rules.

]]--


--************* Requires *************
require "teamf1lualib/util"
require "teamf1lualib/db"

--************* Initial Code *************

--************* Logic *************
local dbFilename = "/tmp/system.db"
local DBTable = "IpBasedQOS"
local ipAddr = arg[1];
local status = arg[2];
local valid = false
local str

if (ipAddr == nil or status == nil) then
    return "UNKOWN PARAMETER"
end

db.connect(dbFilename)

if (status == "add") then
   local dbCmd = "INSERT into " .. DBTable .. " values ('" .. ipAddr .. "')"
   db.execute(dbCmd) 
elseif (status == "remove") then
   local dbCmd = "DELETE from " .. DBTable .. " where ipAddr = '" .. ipAddr .. "'"
   str, valid = db.execute(dbCmd) 
else
    return "UNKNOWN OPERATION"
end

