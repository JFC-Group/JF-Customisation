#!/bin/bash

echo "Start BOSA FIR script"
# Based on the workaround from CSP CS00011008015
# Increase SoC transmitter driver amplitude to work around BOSA reduced sensitivity in high temperature 

GPIOVAL=$(gpioctl get 51 data | cut -d 's' -f 2)
# value of gpio 51 is 1
echo "GPIOVAL=$GPIOVAL"

  if [[ "$GPIOVAL" == " 1" ]];  then
    echo "Need do BOSA FIR"
    #wait PMD module loaded
    sleep 10
    #adjust SoC TX FIR
    serdesctrl tx_fir 0 0
    serdesctrl tx_fir 1 86
    serdesctrl tx_fir 2 0
    serdesctrl tx_fir 3 0
    serdesctrl tx_fir 4 0
  else
    echo "No need do BOSA FIR"
  fi

echo "BOSA FIR DONE"
